"""Parent-owned serial native lifecycle runner. Never launches a subprocess."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import traceback

from sludge_sandbox.run_service import read_run, replay_run, resume_run, run_case, runtime_identity

HERE = Path(__file__).resolve().parent
REPO = Path('/Users/wanggaoying/Desktop/brickmodel-github')
CASE = REPO/'data/sandbox/cases/reacting-wet-free-paired-events-v1.json'
WATER = Path('/private/tmp/brick-free-native-events-v1/attempt01/water')


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('command', choices=('start','resume','replay'))
    args=parser.parse_args()
    output=HERE/args.command
    summary_path=HERE/(args.command+'-summary.json')
    require(not output.exists() and not summary_path.exists(), 'fresh stage output required')
    before=runtime_identity()
    write(HERE/(args.command+'-runtime-before.json'), before)
    started=time.monotonic()
    summary={'command':args.command,'status':'failed','output':str(output),
             'case_sha256':hashlib.sha256(CASE.read_bytes()).hexdigest(),
             'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    parent_manifest=None
    parent=None
    try:
        if args.command=='start':
            returned=run_case(CASE,WATER,output,evidence_directory=REPO/'data/sandbox',
                              cancel=lambda: time.monotonic()-started>=60.)
        else:
            parent_dir=HERE/('start' if args.command=='resume' else 'resume')
            parent,parent_manifest=read_run(parent_dir)
            parent_seal=(parent_dir/'manifest.json').read_bytes()
            operation=resume_run if args.command=='resume' else replay_run
            returned=operation(parent_dir,output)
            require((parent_dir/'manifest.json').read_bytes()==parent_seal,'parent seal changed')
            require(read_run(parent_dir)==(parent,parent_manifest),'parent artifacts changed')
        result,manifest=read_run(output)
        require(result==returned,'returned/saved result mismatch')
        summary['read_run_verified']=True
        record=result['integration']
        require(record==json.loads((output/'depletion_result.json').read_bytes()),'raw/audited record mismatch')
        summary.update(run_status=result['status'],reason=result.get('reason'),steps=len(record['steps']),
                       events=len(record['events']),final_time_s=record['times_s'][-1],
                       integration_elapsed_seconds=record['elapsed_seconds'],
                       evaluations=record['evaluations'],attempted_steps=record['attempted_steps'],
                       rejected_trials=record['rejected_trials'],phase_costs=record['phase_costs'],
                       artifacts=len(manifest['files']))
        if args.command=='start':
            require(result['status']=='cancelled','cooperative cancellation required')
            require(len(record['steps'])>0,'nonempty accepted prefix required')
            case=json.loads(CASE.read_bytes())
            require(case['numerics']['start_s']<record['times_s'][-1]<case['numerics']['end_s'],
                    'interior accepted checkpoint required')
        else:
            require(result['status']=='completed','completed lifecycle stage required')
            require(record['times_s'][-1]==json.loads(CASE.read_bytes())['numerics']['end_s'],'original fixed horizon')
            old=parent['integration']
            if args.command=='resume':
                for key in ('times_s','states','steps','events','corrections','refinements'):
                    require(record[key][:len(old[key])]==old[key],'original accepted prefix: '+key)
                for key in ('evaluations','attempted_steps','rejected_trials','elapsed_seconds'):
                    require(record[key]>=old[key],'cumulative cost reset: '+key)
                require(result['policy']==parent['policy'] and result['depletion_policy']==parent['depletion_policy'],
                        'original policies changed')
            else:
                summary['exact_replay_fields']={key:record[key]==old[key]
                    for key in ('times_s','states','steps','events','corrections')}
                require(all(summary['exact_replay_fields'].values()),'full numerical replay mismatch')
        summary['status']='passed'
    except Exception as exc:
        summary['exception']={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
        # Preserve diagnostic results even when the service returned a sealed failure.
        if (output/'manifest.json').exists():
            try:
                failed,_=read_run(output)
                summary['failure_read_run_verified']=True
                summary['failure_run_status']=failed.get('status')
                summary['failure_reason']=failed.get('reason')
            except Exception as verify_error:
                summary['failure_verification_error']=str(verify_error)
    finally:
        summary['wall_seconds']=time.monotonic()-started
        after=runtime_identity()
        write(HERE/(args.command+'-runtime-after.json'),after)
        summary['runtime_unchanged']=before==after
        if not summary['runtime_unchanged']:summary['status']='failed'
        write(summary_path,summary)
    require(summary['status']=='passed',str(summary.get('exception',summary)))


if __name__=='__main__':
    main()
