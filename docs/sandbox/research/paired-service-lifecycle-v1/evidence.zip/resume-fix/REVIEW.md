# Independent service resume preflight and lifecycle-runner review

APPROVE scoped fix and preregistered lifecycle runner. Read-only, no EOS/native execution or test reruns.

Inspected run_service.py SHA256 8231c94acc0e6b838579dda02b3d7f6d7d4a4084c38ac47df24be4144e106fa3; test_paired_service_resume_policy.py SHA256 a578897051fa433d36ac9ff6fdb207f3d312b8e8209b28c5164835be1b1efc17; lifecycle run.py SHA256 cb50962576bb9f28a2399ebbdd33acd2fd5630b5abe4b5d1d8a89561d41636f9 and PLAN.md.

The new preflight validates the exact case declaration and scalar settings without trying to construct source-bound boxes before the operator exists. For v2 it reconstructs the saved typed comparison policy strictly, removes that field only from a fresh local copy, and compares remaining settings to the validated case's scalar policy. It does not claim saved box identity is already authenticated. The actual _run_event path still builds the operator, compares the complete encoded fresh policy to the saved policy, verifies original initial states, and audits/restores the record before integration. Thus the preflight fixes the construction-order failure without bypassing actual box/source binding. V1 policy comparison remains exact and refuses an injected family.

Tests cover accepted v2 preflight without an operator, nonmutation of saved policy, changed budget, missing/null/malformed comparison family, malformed Fraction, old v1 behavior and explicit declaration refusal. Original red.xml retains nine failures; green.xml records 42 tests, zero failures/errors/skips, 3.141 seconds. These preflight tests do not substitute for the actual lifecycle run.

The lifecycle runner uses three fresh, serial output directories. Start requests cooperative cancellation at 60 seconds measured before run_case, including setup. It requires a sealed cancelled result with accepted work and an interior checkpoint; a watchdog alone cannot satisfy those assertions. Resume reads and preserves the exact sealed parent, checks all six saved history prefixes, original policies and nondecreasing cumulative costs, and requires completion at the original end. Replay uses the completed resume parent and demands exact times/states/steps/events/corrections, excluding timing-sensitive refinement diagnostics as explicitly planned. A mismatch is retained as failure, not suppressed.

Every returned result is checked against read_run and its raw depletion_result.json; parent seal bytes and parent artifact reads are checked after use. Stage summaries and runtime identities are stored outside sealed directories. Failed sealed service results are re-read into diagnostic summaries. Runtime changes mark failure. The script does not launch native processes or enforce hard deadlines itself; root owns the stated external watchdogs of 90/840/840 seconds. All original case/source/physics/gates remain untouched by the runner.

No blocking issue found for this scope. Successful cancellation, resumed completion and deterministic replay are still hypotheses to test with the actual service, not outcomes established by this review. Material qualification/full firing-cycle and full inverse-temperature pressure uncertainty remain outside this numerical lifecycle experiment.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE scoped resume fix and serial lifecycle validation plan.

## Final targeted test addition

Final test SHA256 e567feb5d9ab6f32781ff3b52c9530f0cb17af6b7e2d7ab617a14a7f21083ab4. Source remains unchanged. The added test deliberately supplies a structurally valid but changed reference-volume box: preflight admits its structure, then the actual _run_event complete fresh-policy comparison raises resume_event_original_policy_mismatch before a forbidden integrate_depletion sentinel can run. This directly tests the intended two-stage trust boundary, rather than treating preflight as source authentication. green02.xml independently read: 43 tests, zero failures/errors/skips, 3.175 seconds. APPROVE this test addition.
