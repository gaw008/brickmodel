# One conditional Cedrone CHONS TP execution, after a complete accepted virtual series

This is a not-yet-run scratch driver. Source/model material qualification remains false. No EOS/provider/equilibrium is run while preparing or reviewing this script. The first historical virtual native01 failed the original element gate at its first 1000 K point and stopped; that failure is retained and cannot admit the source case.

Prerequisite is an **explicit** `--validated-virtual-directory` containing one complete four-point series: 1000 K element_basis, 1000 K methane_shift, 800 K element_basis, 1200 K element_basis. There is no default old directory, newest-directory discovery, or combination of points from different series. Require SERIES status completed, four accepted point records and their matching actual file SHAs, each module's actual_source_properties_checked, 152 saved independent standard-property checks per point, successful seed comparison, and common loaded definitions/provider identity/model. ROOT must also have accepted that series and its external supervisor/unchanged-input evidence before launching. The driver does not replace the independent saved-data review of that earlier run.

Before any solve, read the fixed public printed-pool.json SHA `92feba43d25479d99a2607466fb902841d0afcffc5b1108ca2ff74a42145f7fd`. Copy its bytes, the selected SERIES bytes and all four point-file byte streams into the new attempt's inputs directory; hash the same bytes that are parsed. From that directory's point01_1000_element_basis.json **initial.loaded_definition.gas_atomic_weights_kg_kmol**, require precisely C,H,O,N,S with finite positive actual float values and identical initial/final definitions. Do not guess weights or construct a provider to fetch them.

Use public exact fractions m_C=9/25, m_H=53/1000, m_O=111/500, m_N=29/500, m_S=11/1000 kg per nominal one-kilogram prepared-sample analysis basis. Their sum is 0.704 kg. Convert `b_e=1000*m_e/Fraction.from_float(A_e)`. Save original float weights, hexadecimal forms, exact fractions, five derived atom inventories, the entire source JSON, basis/exclusion/uncertainty statements and installed module file hash in INPUT.json. The module must come from the new isolated runtime and match reviewed repository source bytes; its model SHA must match the selected virtual series. Atomic amounts are passed as Fractions to TPPool, retaining the module's normal kmol projection and element gates.

Create one TPPool at **800 K, 100000 Pa**, classification `derived_from_evidence`, with source IDs for Cedrone Table4, the explicit all-reported-CHONS-available-to-selected-gas/graphite approximation, and the selected closed TP controls. Call `solve_tp` exactly once with element_basis, fixed gibbs/rtol1e-10/max_steps1000 and original maximum_elapsed_s=10.0. No fallback, solver change or retry. **Immediately serialize and flush the complete returned TPResult to RESULT.json before checking driver time, result status or derived outputs.** A failed module result is preserved and stops the attempt.

For a completed result, require actual source-property checks and loaded definitions/identity identical to the atomic-weight source. Derive n_i[mol] as exact Fractions of actual returned kmol times1000; require all19 names/order, nonnegative inventories, and equality to module diagnostics. Compute model species masses from actual loaded atom compositions and the same actual atomic weights; report all19 mol/mass values, gas mole fractions, and separately graphite carbon mol/kg. These masses are derived bookkeeping, not another backend molecular-weight/property read.

Independently recompute the five returned atom inventories and their residuals r_e. Retain the original exact module gate `|r_e|<=10^-10(1+|b_e|)`. The nominal mass audit is

```text
M_out - 0.704 = sum_e A_e*r_e/1000
|M_out - 0.704| <= sum_e A_e*|r_e|/1000
                 <= sum_e A_e*10^-10*(1+|b_e|)/1000.
```

All these quantities use exact Fraction arithmetic on represented input/output values. The bound propagates numerical element tolerances; it is neither source uncertainty nor a whole-sludge mass closure. Keep ash0.292kg, Cl0.0005kg, n.d.Br and the0.0035kg printed arithmetic remainder outside the CHONS calculation. Do not add residual water again, normalize the pool to1kg, label graphite a measured char yield, report actual heat duty, or claim TG validation. Numerical H/G retained in the raw module result do not provide Cedrone initial energy or process heat.

Driver budget is **20 s**, measured from entry including prereads/import/copies/saving; checks are at safe return boundaries and include after the final status write. The module10s gate is unchanged. Future external supervision must be **30 s plus5 s cleanup**, using the existing supervisor, a fresh new native01 attempt directory and no retry. The script itself creates native01 and refuses any prior attempt. Do not pre-create it in the launcher. Before a nonreturning call, STATUS records a single-call boundary with an explicitly unfinalized attempt count; final counts are written after return/exception. A supervisor kill must not be relabeled a clean module failure. I/O failure may leave a partial output; preserve it and reject the attempt.

Future invocation, after the chosen series and installed code are reviewed, is:

```sh
/usr/bin/env -u PYTHONPATH /private/tmp/sludge-tp-equilibrium-v1/runtime/bin/python -I \
  /private/tmp/sludge-tp-equilibrium-v1/cedrone-execution/run_cedrone.py \
  --validated-virtual-directory /EXPLICIT/ACCEPTED/FOUR_POINT_SERIES
```

This command is illustrative and has not been run. The future wrapper must include the actual selected SERIES/four point paths, public pool/README, this script/PLAN, source pack, repository/installed module, new runtime dependencies and executable, and existing supervisor in its input observations. Record the explicit argument; do not substitute latest or omit failed history. On return, review RESULT/OBSERVABLES/STATUS and supervisor termination/unchanged-input evidence independently before any successful-run publication.
