# Cedrone 单来源池入口：有限独立代码审查

2026-09-12。**APPROVE 以下冻结字节用于计划中的唯一一次源池执行。** 本审查未构相、未导入 TP/Cantera、未执行 EOS、平衡或 launcher。真实四点 VCS 保存数据接受由另一独立 reviewer 负责；此报告不替代它，也不预称 Cedrone 新工况或材料已经通过。

## 范围与结论

只读 run_cedrone.py、PLAN.md、ROOT 的 launch.py 和已公开固定 printed-pool.json。脚本导入无 I/O；实际 main 拒绝旧 native01，命令行指定唯一旧四点目录，不自动寻找、拼接或回退。要求四点顺序、完整成功/来源物性/152标准物性/同根门、同一加载定义/完整provenance/policy/provider identity；另核同级原 supervisor metadata/status 的命令、完整/0退出/未变/leader已回收及前后输入 SHA，同一库源码和安装源码须先彼此匹配，再等于本次实际导入的隔离安装文件。旧首次 Gibbs 失败不能通过这项 VCS 前置条件。

源 JSON 使用固定 SHA92feba43d25479d99a2607466fb902841d0afcffc5b1108ca2ff74a42145f7fd，复制、哈希、解析同一字节。C/H/O/N/S名义kg分别9/25、53/1000、111/500、29/500、11/1000，总数恰0.704；对实际已保存正有限atomic weight使用Fraction.from_float，按1000m/A转换mol原子，不推测原子量、不加水、不把池归一化到1kg。

实际求解入口只出现一次 solve_tp，显式800K/100000Pa、VCS/传入rtol1e−10/1000步/10秒、element_basis，无retry/fallback。VCS不消费err的真实语义随policy.definition保留，并要求与已接受四点的整个policy一致。输入/源副本先保存，返回的完整 TPResult 在时间/status/派生输出检查前写盘；status记录未结束调用边界，不能把外层杀死误当成模块正常失败。driver20秒在安全边界及最后保存之后分类，module10秒未变；launcher为30秒+5秒清理，使用旧监督器和新的单次输出目录，不提前mkdir driver的native01。

派生输出按实际kmol×1000的Fraction库存重算所有19物种质量及五元素残差；A_e与原入池换算相同。质量差=ΣA_e*r_e/1000精确成立，三角界与原元素接受门的传播界分开保存，未称来源/材料不确定性。灰0.292、Cl0.0005、未知Br、打印算术余量0.0035在外；额外水没有重复加入，石墨明确叫graphite carbon而非实测char产率，也不推断初始能量、工艺热耗或TG符合。

## 实际独立验证

review/test_cedrone_edges.py仅执行纯函数/实际main终态AST：

1. 用已有保存原子量记录配制造的元素基库存，核1000m/A、0.704kg以及质量差与权重元素残差/双界精确恒等式。
2. 人工多加0.024kg水到账目小计必须拒绝，不能藏入闭合账。
3. 最后status写出才越20秒时，终态实际保存resource_limit、一次调用计数且非零返回。

INDEPENDENT01.log/xml：**3 passed in0.02s**。制造库存不是已有实际平衡组成，也没有被整个driver或任何provider实际接受。未重复作者四点前置纯读检查，未运行旧物性测试。

最初launcher静态漏列PLAN承诺的源README和真实Python执行文件；ROOT已仅补这两项并保持inputs[10]监督器索引。实际只读确认README存在、PYTHON.resolve(strict=True)指向真实Python3.12.13文件，已进入新输入清单。此为静态合同补齐，没有伪造运行RED。当前无未解决确定CRITICAL/HIGH/MEDIUM问题。操作系统/存储异常仍可能留下部分文件；计划已将此视为失败，不保证不可中断日志。

## 冻结 SHA256

- run_cedrone.py: `d388fa0d3747131aa8f81053d860913e728c781434b96cd648523972aab4a10e`
- PLAN.md: `122cd64eb6852940b4a5f2bb54544624f887375975889b81e793f0c44f8fce97`
- launch.py: `b1a138772f7c76861b2662c74360ec77cd50263406bae1b7bf017141bc160c52`
