"""One source-pool saved audit; stdlib only, no model import/EOS/replay."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json, math
W=Path('/private/tmp/sludge-tp-equilibrium-v1');D=W/'cedrone-execution';O=D/'native01';ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
def hook(d):return F(d['numerator'],d['denominator']) if set(d)=={'numerator','denominator'} and all(type(v)is int for v in d.values()) else d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def sha(p):return sha256(p.read_bytes()).hexdigest()
def wire(v):
 if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
 if isinstance(v,dict):return {k:wire(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [wire(x) for x in v]
 return v
def norm(m):return {k:v['sha256'] if isinstance(v,dict) else v for k,v in m.items()}
checks=[]
def check(k,v):checks.append({'name':k,'passed':bool(v)})
inp=read(O/'INPUT.json');r=read(O/'RESULT.json');obs=read(O/'OBSERVABLES.json');status=read(O/'STATUS.json');src=read(O/'inputs/printed-pool.json');derived=inp['derivation'];diag=r['diagnostics'];E=['C','H','O','N','S']
check('public_source_exact_bytes_and_full_copy',sha(O/'inputs/printed-pool.json')==sha(ROOT/'data/sandbox/research/cedrone2024-element-pool-v1/printed-pool.json')=='92feba43d25479d99a2607466fb902841d0afcffc5b1108ca2ff74a42145f7fd' and src==inp['source_record'])
check('all_eight_source_evidence_streams_match',len(inp['source_byte_evidence'])==8 and all(Path(v['copied_path']).stat().st_size==v['bytes'] and sha(Path(v['copied_path']))==sha(Path(v['original_path']))==v['sha256'] for v in inp['source_byte_evidence'].values()))
previous=read(W/'review/VCS_NATIVE_REVIEW_SHA01.json')
check('prerequisite_series_is_independently_reviewed',all(str(v['original_path']) in previous and previous[str(v['original_path'])]['sha256']==v['sha256'] for k,v in inp['source_byte_evidence'].items() if k!='printed-pool.json'))
series=read(O/'inputs/SERIES.json');prior=[read(O/'inputs'/x['output'])['result'] for x in series['points']]
check('prerequisite_four_actual_VCS_points_accepted',series['status']=='completed' and len(prior)==4 and series['seed_comparison']['passed'] and all(x['status']=='completed' and x['actual_source_properties_checked'] and all(x['diagnostics']['checks'].values()) and x['policy']['solver']=='vcs' for x in prior))
vmeta=read(O/'inputs/virtual-supervisor-metadata.json');vstatus=read(O/'inputs/virtual-supervisor-status.json');vb=norm(vmeta['inputs_before']);va=norm(vstatus['inputs_after']);ident=inp['accepted_VCS_series_code_identity']
check('accepted_prior_supervision_and_module_binding',vb==va and vstatus['status']=='complete' and vstatus['returncode']==0 and vstatus['inputs_unchanged'] and vstatus['cleanup']['leader_reaped'] and vb[ident['repository_module_path']]==vb[ident['installed_module_path']]==ident['repository_module_sha256']==ident['installed_module_sha256']=='da382eead7211e5a91a1630fbe30a75a8c7feca9cb1af6814398c57f8914849c')
masses={e:F(src['printed_values'][e]['printed_wt_percent'])/100 for e in E}
nominal={e:F(int(src['nominal_CHONS_kg'][e]['numerator']),int(src['nominal_CHONS_kg'][e]['denominator'])) for e in E}
check('printed_percent_to_exact_kg',masses==nominal==derived['masses_kg'] and sum(masses.values(),F())==F('0.704'))
Aw=prior[0]['initial']['loaded_definition']['gas_atomic_weights_kg_kmol'];A={e:F(Aw[e]) for e in E};b=[1000*masses[e]/A[e] for e in E]
check('actual_atomic_weights_and_all_representations',set(Aw)==set(E) and derived['actual_atomic_weights_kg_kmol']==Aw and derived['atomic_weights_exact_binary64']==A and derived['atomic_weights_binary64_hex']=={e:Aw[e].hex() for e in E})
check('exact_mass_to_atom_pool_and_actual_request',b==derived['element_mol']==inp['request']['element_mol']==r['request']['element_mol'] and r['request']==inp['request'])
source_ids=['cedrone2024:doi10.3390/environments11100210:Table4:reported_sample_CHONS','conditional_assumption:reported_CHONS_available_to_gas_graphite:mineral_allocation_unknown','virtual_design:closed_pool_800K_100000Pa']
check('request_source_ids_basis_TP',r['request']['temperature_k']==800 and r['request']['pressure_pa']==100000 and r['request']['classification']=='derived_from_evidence' and r['request']['basis_id']=='CEDRONE_TABLE4_REPORTED_SAMPLE_1KG_CONDITIONAL_CHONS' and r['request']['source_ids']==source_ids)
check('CHONS_no_added_water_or_normalization',derived['CHONS_subtotal_kg']==F('.704') and derived['nominal_reported_sample_basis_kg']==1 and derived['ash_Cl_Br_and_gap_are_not_added_to_CHONS'] and not src['basis']['additional_separate_water_added_to_pool'] and not src['basis']['renormalize_CHONS_to_1kg'] and not src['basis']['renormalize_known_columns_to_100percent'] and derived['source_basis']==src['basis'] and derived['printed_analysis_and_uncertainty']==src['analysis'])
check('exclusions_and_qualifications_retained',obs['excluded_and_unidentified']==derived['excluded_and_unidentified']==src['excluded_and_unidentified'] and src['material_validated'] is False and src['energy_initial_state_qualified'] is False and r['material_qualified'] is False and r['training_eligible'] is False and src['analysis']['admitted_statistical_or_hard_uncertainty_interval'] is None)
check('source_provider_policy_matches_accepted_VCS',r['provider_identity']==prior[0]['provider_identity'] and r['provenance']==prior[0]['provenance'] and r['policy']==prior[0]['policy']==inp['policy'] and r['actual_source_properties_checked'] and r['policy']['effective_native_tolerances']['requested_rtol_consumed'] is False)
loaded=r['final']['loaded_definition'];names=[x['name'] for x in loaded['species']];at=[[F(x['composition'].get(e,0)) for e in E] for x in loaded['species']]
check('actual_loaded_definitions_still_bound',r['initial']['loaded_definition']==loaded==prior[0]['initial']['loaded_definition'])
G={};mu={};invs={};element_rows=[];props=[];ref=read(W/'source-reference/REFERENCE.json')
for label in ['initial','final']:
 s=r[label];n=[F(x)*1000 for x in s['amounts_kmol']];bout=[sum((n[i]*at[i][e] for i in range(19)),F()) for e in range(5)];res=[x-y for x,y in zip(bout,b)];invs[label]=(n,bout,res)
 check(label+'_19_inventories_TP',len(n)==19 and all(math.isfinite(x) and x>=0 for x in s['amounts_kmol']) and s['temperature_k']==800 and s['pressure_pa']==100000)
 for e,x,be in zip(E,res,b):
  limit=F(1,10**10)*(1+abs(be));element_rows.append({'snapshot':label,'element':e,'residual_mol':x,'residual_float_mol':float(x),'original_limit_mol':limit,'passed':abs(x)<=limit})
 check(label+'_all_five_original_element_gates',all(x['passed'] for x in element_rows if x['snapshot']==label))
 rt=s['gas_constant_j_mol_k']*800;Ng=sum(n[:18],F());mu[label]=[s['standard_g_j_mol'][i]+rt*(math.log(n[i])-math.log(Ng)) if n[i] else None for i in range(18)]+[s['standard_g_j_mol'][18]];G[label]=sum((x*F(y) for x,y in zip(n,mu[label]) if x),F())
 for i,sp in enumerate(ref['records']):
  p=next(x for x in sp['points'] if x['temperature_k']==800)
  for key,rkey,tflag in [('standard_cp_j_mol_k','cp_over_R',False),('standard_h_j_mol','h_over_RT',True),('standard_s_j_mol_k','s_over_R',False),('standard_g_j_mol','g_over_RT',True)]:
   target=float(p['binary64_coefficients'][rkey]['decimal_90_digits']);actual=s[key][i]/(s['gas_constant_j_mol_k']*(800 if tflag else 1));error=actual-target;limit=2e-10+5e-12*abs(target)
   props.append({'snapshot':label,'species':sp['species'],'property':rkey,'difference':error,'original_tolerance':limit,'passed':math.isfinite(error) and abs(error)<=limit})
check('152_independent_standard_properties',len(props)==152 and all(p['passed'] for p in props) and [x['species'] for x in ref['records']]==names)
n,bout,res=invs['final'];B=sum(bout,F());rt=r['final']['gas_constant_j_mol_k']*800
check('exact_result_moles_elements_G_mu',n==diag['amounts_mol'] and bout==diag['elements_mol'] and res==diag['element_residual_mol'] and G['initial']==diag['seed_gibbs_j'] and G['final']==diag['gibbs_j'] and mu['final']==diag['chemical_potentials_j_mol'])
lam=diag['element_potentials_j_mol_atoms'];imp=[math.fsum(float(a)*v for a,v in zip(row,lam)) for row in at];std=r['final']['standard_g_j_mol'];logs=[(imp[i]-std[i])/rt for i in range(18)];mx=max(logs);lz=mx+math.log(math.fsum(math.exp(x-mx) for x in logs));dc=(std[18]-lam[0])/rt;delta=max(0.,lz,-dc);penalty=F(rt)*F(delta)
Lout=sum((F(v)*x for v,x in zip(lam,bout)),F())-penalty*B;Lreq=sum((F(v)*x for v,x in zip(lam,b)),F())-penalty*sum(b,F());gap=G['final']-Lout;greq=G['final']-Lreq;correction=sum((F(v)*x for v,x in zip(lam,res)),F())-penalty*sum(res,F())
check('full_candidate_partition_and_both_pool_G',lz==diag['log_partition_sum'] and delta==diag['partition_penalty'] and gap==diag['gap_out_j'] and greq==diag['gap_requested_j'] and greq-gap==correction==diag['requested_pool_gap_correction_j'])
active=[i for i in range(19) if n[i]>B*F(1,10**12)];ar=[(mu['final'][i]-imp[i])/rt for i in active]
check('all_original_G_chemical_carbon_gates',-F(1,10**10)<=gap/(F(rt)*B)<=F(1,10**7) and gap/(F(rt)*B)==diag['scaled_gap_out'] and ar==diag['active_residuals_over_RT'] and max(map(abs,ar))<=1e-7 and abs(dc)<=1e-7 and G['final']<=G['initial']+F(rt)*B*F(1,10**7) and all(diag['checks'].values()))
species_masses=[n[i]*sum((at[i][j]*A[e] for j,e in enumerate(E)),F())/1000 for i in range(19)];M=sum(species_masses,F());mres=M-F('.704');weighted=sum((A[e]*x for e,x in zip(E,res)),F())/1000;triangle=sum((A[e]*abs(x) for e,x in zip(E,res)),F())/1000;bound=sum((A[e]*F(1,10**10)*(1+abs(be)) for e,be in zip(E,b)),F())/1000
check('all_19_species_masses_and_gas_fractions',len(obs['species'])==19 and all(x['name']==names[i] and x['amount_mol']==n[i] and x['model_mass_kg']==species_masses[i] and (x['gas_mole_fraction']==n[i]/sum(n[:18],F()) if i<18 else x['gas_mole_fraction'] is None) for i,x in enumerate(obs['species'])))
check('exact_mass_residual_and_both_propagated_bounds',M==obs['model_CHONS_mass_kg'] and obs['nominal_input_CHONS_mass_kg']==F('.704') and mres==weighted==obs['nominal_mass_check']['residual_kg']==obs['nominal_mass_check']['weighted_element_residual_kg'] and triangle==obs['nominal_mass_check']['triangle_bound_from_actual_residuals_kg'] and bound==obs['nominal_mass_check']['bound_from_original_element_tolerances_kg'] and abs(mres)<=triangle<=bound)
check('graphite_model_mass_readout',obs['graphite_carbon_mol']==n[18] and obs['graphite_carbon_mass_kg']==n[18]*A['C']/1000 and obs['gas_total_mol']==sum(n[:18],F()) and obs['element_residual_mol']==dict(zip(E,res)))
meta=read(D/'supervised-native01/metadata.json');sup=read(D/'supervised-native01/status.json');before=norm(meta['inputs_before']);after=norm(sup['inputs_after'])
check('all_supervised_inputs_before_after',before==after and sup['inputs_unchanged'] is True)
current_changes={p:{'at_run_sha256':h,'current_sha256':sha(Path(p)) if Path(p).is_file() else None} for p,h in before.items() if not Path(p).is_file() or sha(Path(p))!=h}
readme=str(ROOT/'data/sandbox/research/cedrone2024-element-pool-v1/README.md');archive=W/'cedrone-pool/PUBLIC_README_AT_NATIVE01.md'
check('sole_current_change_is_archived_postrun_README',set(current_changes)=={readme} and sha(archive)==before[readme]=='c8148e94351ab4944a1a18c71fe608434c28065956ea0210749c983adfba4a3d' and current_changes[readme]['current_sha256']=='e7bb50fb9fff5145ab7b0a9e6d8daeab49351d90c6f1db08584539390efbcba9')
check('module_identity_from_prior_to_actual_install',sha(Path(inp['installed_module_path']))==sha(Path(ident['repository_module_path']))==inp['installed_module_sha256']==ident['installed_module_sha256']==before[inp['installed_module_path']])
check('one_completed_call_original_budgets_and_reaping',status['status']==r['status']=='completed' and status['solve_attempts']==1 and status['solve_attempts_are_final'] is True and r['provider_calls_attempted']==r['provider_calls_completed']==3 and r['elapsed_seconds']<status['module_budget_s']==10 and status['driver_elapsed_before_final_save_s']<status['driver_budget_s']==20 and meta['timeout_s']==30 and meta['cleanup_grace_s']==5 and sup['elapsed_s']<30 and sup['status']=='complete' and sup['returncode']==0 and sup['cleanup']['leader_reaped'])
old=read(W/'review/VCS_FINAL_READ01.json')['files'];check('old_Gibbs_failure_unchanged',all(sha(Path(p))==x['sha256'] for p,x in old.items() if '/root-execution/native01/' in p or '/root-execution/supervised-native01/' in p))
output={'audit_verdict':'PASS' if all(c['passed'] for c in checks) else 'FAIL','checks':checks,'mass_to_elements':[{'element':e,'mass_kg':masses[e],'actual_A_kg_kmol':Aw[e],'atom_mol':b[i],'atom_mol_float':float(b[i])} for i,e in enumerate(E)],'elements':element_rows,'standard_properties':props,'CHONS_mass_kg':float(M),'mass_residual_kg':float(mres),'original_tolerance_propagated_mass_bound_kg':float(bound),'graphite_carbon_mol':float(n[18]),'graphite_carbon_kg':float(n[18]*A['C']/1000),'scaled_gap':float(gap/(F(rt)*B)),'supervision_inputs':len(before),'post_run_documentation_changes':current_changes,'elapsed_seconds':{'solve':r['elapsed_seconds'],'driver':status['driver_elapsed_before_final_save_s'],'supervisor':sup['elapsed_s']},'eos_or_native_calls_by_audit':0,'material_qualified':False,'training_eligible':False}
with (D/'review/SAVED_AUDIT02.json').open('x') as f:json.dump(wire(output),f,indent=2,allow_nan=False)
print(output['audit_verdict'],len(checks),'groups',len(props),'property comparisons',len(before),'inputs')
print({k:v for k,v in output.items() if k not in ['checks','mass_to_elements','elements','standard_properties']})
print('failed',[c for c in checks if not c['passed']])
raise SystemExit(0 if output['audit_verdict']=='PASS' else 1)
