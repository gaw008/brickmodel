"""Manufactured inventories / terminal clock, saved real weight records; no EOS."""
import ast
import importlib.util
import json
from fractions import Fraction as F
from pathlib import Path
from types import SimpleNamespace

import pytest

WORK=Path('/private/tmp/sludge-tp-equilibrium-v1/cedrone-execution')
SCRIPT=WORK/'run_cedrone.py'
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')


def fixture():
    spec=importlib.util.spec_from_file_location('cedrone_review_entry',SCRIPT)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    source=json.loads((ROOT/'data/sandbox/research/cedrone2024-element-pool-v1/printed-pool.json').read_text())
    prior=json.loads((WORK.parent/'root-vcs-execution/native01/point01_1000_element_basis.json').read_text())['result']
    derived=module.derive_input(source,prior)
    b=derived['element_mol']
    nmol=[F()]*19
    for index,element in ((0,1),(5,2),(6,3),(17,4)): nmol[index]=b[element]/2
    nmol[18]=b[0]
    raw=tuple(float(n/1000) for n in nmol)
    n=tuple(F(v)*1000 for v in raw)
    loaded=prior['initial']['loaded_definition']
    rows=[tuple(F(r['composition'].get(e,0)) for e in module.ELEMENTS) for r in loaded['species']]
    residual=tuple(sum((n[i]*rows[i][e] for i in range(19)),F())-b[e] for e in range(5))
    # Flags below exercise the pure bookkeeping path only. This manufactured
    # inventory is not the saved equilibrium composition and is never admitted
    # by the full driver or represented as a new provider calculation.
    result=SimpleNamespace(actual_source_properties_checked=True,
        initial={'loaded_definition':loaded},final={'loaded_definition':loaded,'amounts_kmol':raw},
        policy=prior['policy'],provider_identity=prior['provider_identity'],provenance=prior['provenance'],
        diagnostics={'amounts_mol':n,'element_residual_mol':residual})
    return module,derived,prior,result


def test_mass_is_exact_weighted_atom_residual_with_original_subtotal():
    module,derived,prior,result=fixture()
    assert derived['CHONS_subtotal_kg']==F(88,125)
    assert sum(derived['masses_kg'].values(),F())==F('0.704')
    for i,e in enumerate(module.ELEMENTS):
        assert derived['element_mol'][i]*derived['atomic_weights_exact_binary64'][e]/1000==derived['masses_kg'][e]
    out=module.derive_outputs(result,derived,prior)
    audit=out['nominal_mass_check']
    assert audit['residual_kg']==audit['weighted_element_residual_kg']
    assert abs(audit['residual_kg'])<=audit['triangle_bound_from_actual_residuals_kg']<=audit['bound_from_original_element_tolerances_kg']
    assert out['species'][-1]['name']=='C(gr)'
    assert 'not measured char' in out['scope']


def test_extra_water_mass_cannot_be_hidden_in_bookkeeping():
    module,derived,prior,result=fixture()
    derived['CHONS_subtotal_kg']+=F('0.024')
    with pytest.raises(ValueError,match='nominal_propagated_mass_check_failed'):
        module.derive_outputs(result,derived,prior)


def test_terminal_status_write_deadline_is_saved_as_resource_limit():
    tree=ast.parse(SCRIPT.read_text())
    main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    index=next(i for i,n in enumerate(main.body) if isinstance(n,ast.Expr)
               and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute)
               and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='status'
               and any(k.arg=='solve_attempts_are_final' for k in n.value.keywords))
    main.body=main.body[index:]
    clock=[0.]
    saved=[]
    def save(path,value,**kwargs):
        saved.append(json.loads(json.dumps(value)))
        if value['status']=='completed': clock[0]=21.
    namespace={'status':{'status':'completed'},'attempts':1,'started':0.,
               'time':SimpleNamespace(monotonic=lambda:clock[0]),'save':save,'OUT':WORK/'unused',
               'DRIVER_SECONDS':20.,'json':json}
    exec(compile(ast.Module(body=[main],type_ignores=[]),str(SCRIPT),'exec'),namespace)
    assert namespace['main']()==1
    assert saved[-1]['status']=='resource_limit'
    assert saved[-1]['solve_attempts']==1
