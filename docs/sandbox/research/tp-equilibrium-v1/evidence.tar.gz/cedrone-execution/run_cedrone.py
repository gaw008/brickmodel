"""One conditional Cedrone TP solve after the accepted four-point virtual series.

Importing this scratch driver performs no I/O, provider construction, or solve.
"""
from __future__ import annotations

import argparse
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from fractions import Fraction as F
import hashlib
import json
import math
import os
from pathlib import Path
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sludge_sandbox.tp_equilibrium import TPResult

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK = Path(__file__).resolve().parent
OUT = WORK / 'native01'
POOL_FILE = ROOT / 'data/sandbox/research/cedrone2024-element-pool-v1/printed-pool.json'
POOL_SHA = '92feba43d25479d99a2607466fb902841d0afcffc5b1108ca2ff74a42145f7fd'
ELEMENTS = ('C', 'H', 'O', 'N', 'S')
SPECIES = ('H2', 'H2O', 'CO', 'CO2', 'CH4', 'O2', 'N2', 'NH3', 'HCN',
           'NO', 'NO2', 'N2O', 'H2S', 'SO2', 'SO3', 'COS', 'CS2', 'S2', 'C(gr)')
POINTS = ((1000, 'element_basis'), (1000, 'methane_shift'),
          (800, 'element_basis'), (1200, 'element_basis'))
DRIVER_SECONDS = 20.0
SOURCE_IDS = ('cedrone2024:doi10.3390/environments11100210:Table4:reported_sample_CHONS',
              'conditional_assumption:reported_CHONS_available_to_gas_graphite:mineral_allocation_unknown',
              'virtual_design:closed_pool_800K_100000Pa')


def json_value(value: object) -> object:
    """Small value serializer patterned after the public CLI; no native objects."""
    if is_dataclass(value) and not isinstance(value, type):
        return {f.name: json_value(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, F):
        return {'numerator': value.numerator, 'denominator': value.denominator}
    if isinstance(value, Mapping):
        return {str(k): json_value(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_value(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return {'invalid_computed_float': str(value)}
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    raise TypeError(f'unsupported_output_value:{type(value).__name__}')


def save(path: Path, value: object, *, new: bool = True) -> None:
    text = json.dumps(json_value(value), indent=2, allow_nan=False) + '\n'
    with path.open('x' if new else 'w', encoding='utf-8') as stream:
        stream.write(text)
        stream.flush()
        os.fsync(stream.fileno())


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def guard(started: float) -> None:
    if time.monotonic() - started > DRIVER_SECONDS:
        raise TimeoutError('driver_budget_20s')


def read_saved(path: Path, label: str, evidence: dict) -> dict:
    """Copy and hash the same bytes that are decoded; never reread for parsing."""
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    copied = OUT / 'inputs' / label
    with copied.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    evidence[label] = {'original_path': str(path), 'copied_path': str(copied),
                       'bytes': len(raw), 'sha256': digest}
    record = json.loads(raw)
    require(isinstance(record, dict), 'expected_JSON_object:' + label)
    return record


def check_virtual_point(record: dict, item: dict, temperature: int, seed: str) -> dict:
    require(item['temperature_k'] == temperature and item['seed'] == seed,
            'virtual_point_order_mismatch')
    require(item['exit_code'] == 0 and item['status'] == 'completed'
            and item['property_checks_passed'] is True, 'virtual_point_not_accepted')
    rows = item['independent_standard_properties']
    require(len(rows) == 152 and all(r['passed'] is True for r in rows),
            'virtual_independent_property_checks_missing')
    result = record['result']
    require(record['status'] == result['status'] == 'completed'
            and result['actual_source_properties_checked'] is True,
            'virtual_actual_source_properties_not_checked')
    require(result['request']['temperature_k'] == temperature
            and result['request']['pressure_pa'] == 100000
            and result['seed']['variant'] == seed, 'virtual_saved_request_mismatch')
    require(result['provider_identity']['kind'] == 'actual_cantera'
            and result['provider_identity']['version'] == '3.2.0', 'virtual_provider_mismatch')
    policy = result['policy']
    require(policy['solver'] == 'vcs' and policy['rtol'] == 1e-10
            and policy['max_steps'] == 1000 and policy['maximum_elapsed_s'] == 10.0,
            'virtual_explicit_VCS_policy_required')
    identity = result['provider_identity']
    require(identity['requested_native_solver'] == 'vcs'
            and identity['requested_native_rtol'] == 1e-10
            and policy['effective_native_tolerances']['requested_rtol_consumed'] is False
            and identity['effective_native_tolerances'] == policy['effective_native_tolerances'],
            'virtual_VCS_effective_policy_not_recorded')
    require(bool(result['diagnostics']['checks'])
            and all(v is True for v in result['diagnostics']['checks'].values()),
            'virtual_module_check_failed')
    require(result['initial']['loaded_definition'] == result['final']['loaded_definition'],
            'virtual_loaded_definition_changed')
    return result


def virtual_code_identity(directory: Path, evidence: dict) -> dict:
    """Read the selected series' existing supervisor receipts, not a new manifest."""
    require(directory.name == 'native01', 'supervised_native01_directory_required')
    supervised = directory.parent / 'supervised-native01'
    metadata = read_saved(supervised / 'metadata.json', 'virtual-supervisor-metadata.json', evidence)
    status = read_saved(supervised / 'status.json', 'virtual-supervisor-status.json', evidence)
    require(metadata['attempt_dir'] == str(supervised)
            and metadata['attempt_id'] == status['attempt_id'] == 'supervised-native01',
            'virtual_supervisor_attempt_mismatch')
    runtime = (WORK.parent / 'runtime').resolve()
    require(metadata['command'] == ['/usr/bin/env', '-u', 'PYTHONPATH',
            str(runtime / 'bin/python'), '-I', str(directory.parent / 'native_series.py')],
            'virtual_supervisor_command_mismatch')
    require(status['status'] == 'complete' and status['returncode'] == 0
            and status['inputs_unchanged'] is True and status['cleanup']['leader_reaped'] is True,
            'virtual_supervisor_not_accepted')
    before, after = metadata['inputs_before'], status['inputs_after']
    require(set(before) == set(after)
            and all(v['sha256'] == after[p] for p, v in before.items()),
            'virtual_supervisor_inputs_changed')
    source_path = str(ROOT / 'src/sludge_sandbox/tp_equilibrium.py')
    installed_paths = [p for p in before if Path(p).is_relative_to(runtime)
                       and p.endswith('/site-packages/sludge_sandbox/tp_equilibrium.py')]
    require(len(installed_paths) == 1, 'unique_virtual_installed_module_required')
    installed_path = installed_paths[0]
    source_sha = before[source_path]['sha256']
    require(source_sha == before[installed_path]['sha256'], 'virtual_source_install_mismatch')
    return {'repository_module_path': source_path, 'repository_module_sha256': source_sha,
            'installed_module_path': installed_path, 'installed_module_sha256': source_sha,
            'evidence': 'selected series existing supervisor inputs_before and inputs_after'}


def prerequisites(directory: Path, evidence: dict) -> tuple[dict, dict, dict]:
    pool = read_saved(POOL_FILE, 'printed-pool.json', evidence)
    require(evidence['printed-pool.json']['sha256'] == POOL_SHA, 'printed_pool_hash_changed')
    series = read_saved(directory / 'SERIES.json', 'SERIES.json', evidence)
    require(series['status'] == 'completed' and len(series['points']) == 4,
            'virtual_series_incomplete')
    require(series['explicit_solver'] == 'vcs', 'explicit_VCS_series_required')
    code_identity = virtual_code_identity(directory, evidence)
    require(series['seed_comparison']['passed'] is True, 'virtual_seed_comparison_failed')
    prior = None
    for index, ((temperature, seed), item) in enumerate(zip(POINTS, series['points'], strict=True), 1):
        name = f'point{index:02d}_{temperature}_{seed}.json'
        require(item['output'] == name, 'unexpected_virtual_output_path')
        record = read_saved(directory / name, name, evidence)
        require(evidence[name]['sha256'] == item['sha256'], 'virtual_point_hash_changed:' + name)
        result = check_virtual_point(record, item, temperature, seed)
        if prior is None:
            prior = result
        else:
            require(result['initial']['loaded_definition'] == prior['initial']['loaded_definition']
                    and result['provider_identity'] == prior['provider_identity']
                    and result['provenance'] == prior['provenance']
                    and result['policy'] == prior['policy'],
                    'virtual_series_provider_or_definition_changed')
    require(prior is not None, 'missing_point01')
    return pool, prior, code_identity


def derive_input(source: dict, prior: dict) -> dict:
    masses = {}
    for e in ELEMENTS:
        r = source['nominal_CHONS_kg'][e]
        masses[e] = F(int(r['numerator']), int(r['denominator']))
        require(masses[e] == F(r['fraction']) and masses[e] > 0, 'invalid_source_mass:' + e)
    require(sum(masses.values(), F()) == F('0.704'), 'source_CHONS_subtotal_mismatch')
    actual = prior['initial']['loaded_definition']['gas_atomic_weights_kg_kmol']
    require(set(actual) == set(ELEMENTS), 'exactly_five_atomic_weights_required')
    weights = {}
    for e in ELEMENTS:
        a = actual[e]
        require(type(a) is float and math.isfinite(a) and a > 0, 'invalid_loaded_atomic_weight:' + e)
        weights[e] = F.from_float(a)
    moles = tuple(1000 * masses[e] / weights[e] for e in ELEMENTS)
    return {'element_order': ELEMENTS, 'masses_kg': masses,
            'actual_atomic_weights_kg_kmol': actual,
            'atomic_weights_binary64_hex': {e: actual[e].hex() for e in ELEMENTS},
            'atomic_weights_exact_binary64': weights, 'element_mol': moles,
            'formula': 'b_e_mol=1000*m_e_kg/A_e_kg_per_kmol; no normalization or extra water',
            'CHONS_subtotal_kg': sum(masses.values(), F()),
            'nominal_reported_sample_basis_kg': F(1), 'source_basis': source['basis'],
            'excluded_and_unidentified': source['excluded_and_unidentified'],
            'printed_analysis_and_uncertainty': source['analysis'],
            'ash_Cl_Br_and_gap_are_not_added_to_CHONS': True}


def derive_outputs(result: TPResult, derivation: dict, prior: dict) -> dict:
    """Mass bookkeeping using returned inventories, not another property call."""
    final = result.final
    require(result.actual_source_properties_checked is True, 'new_source_properties_not_checked')
    require(json_value(final['loaded_definition']) == prior['initial']['loaded_definition']
            and json_value(result.initial['loaded_definition']) == prior['initial']['loaded_definition'],
            'new_loaded_definition_differs_from_atomic_weight_source')
    require(json_value(result.provider_identity) == prior['provider_identity'], 'new_provider_identity_changed')
    require(json_value(result.provenance) == prior['provenance'], 'new_source_provenance_changed')
    require(json_value(result.policy) == prior['policy'], 'new_VCS_policy_changed')
    loaded = final['loaded_definition']['species']
    require(tuple(r['name'] for r in loaded) == SPECIES, 'returned_species_order_changed')
    weights = derivation['atomic_weights_exact_binary64']
    n = tuple(F(v) * 1000 for v in final['amounts_kmol'])
    require(len(n) == 19 and all(v >= 0 for v in n), 'invalid_returned_amounts')
    require(n == tuple(result.diagnostics['amounts_mol']), 'returned_mol_diagnostics_mismatch')
    atom_rows = [tuple(F(r['composition'].get(e, 0)) for e in ELEMENTS) for r in loaded]
    species_mass = tuple(n[i] * sum((atom_rows[i][j] * weights[e] for j, e in enumerate(ELEMENTS)), F()) / 1000
                         for i in range(19))
    b_out = tuple(sum((n[i] * atom_rows[i][j] for i in range(19)), F()) for j in range(5))
    residual = tuple(out - requested for out, requested in zip(b_out, derivation['element_mol'], strict=True))
    require(residual == tuple(result.diagnostics['element_residual_mol']), 'element_residual_mismatch')
    mass_residual = sum(species_mass, F()) - derivation['CHONS_subtotal_kg']
    weighted = sum((weights[e] * residual[j] / 1000 for j, e in enumerate(ELEMENTS)), F())
    observed_bound = sum((weights[e] * abs(residual[j]) / 1000 for j, e in enumerate(ELEMENTS)), F())
    tolerances = tuple(F(1, 10**10) * (1 + abs(v)) for v in derivation['element_mol'])
    policy_bound = sum((weights[e] * tolerances[j] / 1000 for j, e in enumerate(ELEMENTS)), F())
    require(all(abs(r) <= t for r, t in zip(residual, tolerances, strict=True)), 'original_element_gate_failed')
    require(mass_residual == weighted and abs(mass_residual) <= observed_bound <= policy_bound,
            'nominal_propagated_mass_check_failed')
    gas_total = sum(n[:18], F())
    require(gas_total > 0, 'empty_gas_phase')
    return {'scope': 'conditional_model_terminal_composition; not measured char, heat duty, or TG validation',
            'species': [{'name': name, 'amount_mol': n[i], 'model_mass_kg': species_mass[i],
                         'gas_mole_fraction': n[i] / gas_total if i < 18 else None}
                        for i, name in enumerate(SPECIES)],
            'gas_total_mol': gas_total, 'graphite_carbon_mol': n[18], 'graphite_carbon_mass_kg': species_mass[18],
            'model_CHONS_mass_kg': sum(species_mass, F()), 'nominal_input_CHONS_mass_kg': F('0.704'),
            'element_residual_mol': dict(zip(ELEMENTS, residual, strict=True)),
            'nominal_mass_check': {'residual_kg': mass_residual, 'weighted_element_residual_kg': weighted,
                                  'triangle_bound_from_actual_residuals_kg': observed_bound,
                                  'bound_from_original_element_tolerances_kg': policy_bound,
                                  'meaning': 'nominal represented-data arithmetic, not material uncertainty'},
            'excluded_and_unidentified': derivation['excluded_and_unidentified']}


def main() -> int:
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--validated-virtual-directory', required=True, type=Path,
                        help='explicit completed four-point series directory; never auto-discovered')
    directory = parser.parse_args().validated_virtual_directory.resolve(strict=True)
    require(directory.is_dir(), 'validated_virtual_directory_required')
    OUT.mkdir()  # A previous attempt, including failure, is never overwritten.
    (OUT / 'inputs').mkdir()
    evidence = {}
    attempts = 0
    status = {'status': 'preflight_started', 'solve_attempts': 0, 'driver_budget_s': DRIVER_SECONDS,
              'solve_attempts_are_final': False, 'validated_virtual_directory': str(directory),
              'module_budget_s': 10.0, 'future_supervisor_timeout_s': 30.0, 'cleanup_grace_s': 5.0}
    save(OUT / 'STATUS.json', status)
    try:
        source, prior, code_identity = prerequisites(directory, evidence)
        derivation = derive_input(source, prior)
        guard(started)
        from sludge_sandbox import tp_equilibrium as tp
        require(tp.ELEMENTS == ELEMENTS and tp.SPECIES == SPECIES, 'installed_module_column_order_changed')
        require(tp.MODEL_SHA256 == prior['provenance']['model_sha256'], 'virtual_source_model_changed')
        module_path = Path(tp.__file__).resolve()
        runtime = (WORK.parent / 'runtime').resolve()
        require(module_path.is_relative_to(runtime)
                and str(module_path) == code_identity['installed_module_path'],
                'same_isolated_installed_runtime_required')
        installed_bytes = module_path.read_bytes()
        require(installed_bytes == (ROOT / 'src/sludge_sandbox/tp_equilibrium.py').read_bytes(),
                'installed_module_differs_from_reviewed_source')
        installed_sha = hashlib.sha256(installed_bytes).hexdigest()
        require(installed_sha == code_identity['installed_module_sha256'],
                'installed_module_differs_from_accepted_VCS_series')
        pool = tp.TPPool(800.0, 100000.0, derivation['element_mol'],
                         'CEDRONE_TABLE4_REPORTED_SAMPLE_1KG_CONDITIONAL_CHONS',
                         'derived_from_evidence', SOURCE_IDS)
        policy = tp.TPPolicy(solver='vcs', rtol=1e-10, max_steps=1000, maximum_elapsed_s=10.0)
        require(json_value(policy.definition()) == prior['policy'], 'installed_VCS_policy_changed')
        save(OUT / 'INPUT.json', {'source_byte_evidence': evidence, 'source_record': source,
             'derivation': derivation, 'request': pool, 'policy': policy.definition(), 'seed_variant': 'element_basis',
             'atomic_weight_json_locator': 'point01_1000_element_basis.json/result/initial/loaded_definition/gas_atomic_weights_kg_kmol',
             'accepted_VCS_series_code_identity': code_identity,
             'installed_module_path': str(module_path), 'installed_module_sha256': installed_sha})
        status.update(status='input_saved', call_boundary='about_to_attempt_single_solve')
        save(OUT / 'STATUS.json', status, new=False)
        guard(started)
        attempts = 1
        result = tp.solve_tp(pool, ROOT, policy=policy, seed_variant='element_basis')
        save(OUT / 'RESULT.json', result)  # Always before timing or posterior rejection.
        guard(started)
        require(result.status == 'completed', 'module_returned:' + result.status + ':' + str(result.reason))
        outputs = derive_outputs(result, derivation, prior)
        save(OUT / 'OBSERVABLES.json', outputs)
        for item in evidence.values():
            require(hashlib.sha256(Path(item['original_path']).read_bytes()).hexdigest() == item['sha256'],
                    'read_input_changed:' + item['original_path'])
        guard(started)
        status['status'] = 'completed'
    except Exception as exc:
        status.update(status='resource_limit' if isinstance(exc, TimeoutError) else 'failed',
                      failure={'type': type(exc).__name__, 'reason': str(exc)})
    status.update(solve_attempts=attempts, solve_attempts_are_final=True)
    status['driver_elapsed_before_final_save_s'] = time.monotonic() - started
    if status['driver_elapsed_before_final_save_s'] > DRIVER_SECONDS:
        status.update(status='resource_limit', resource_reason='driver_budget_20s_at_return')
    save(OUT / 'STATUS.json', status, new=False)
    elapsed = time.monotonic() - started
    if elapsed > DRIVER_SECONDS:
        status.update(status='resource_limit', resource_reason='driver_budget_20s_after_final_save',
                      driver_elapsed_after_final_save_s=elapsed)
        save(OUT / 'STATUS.json', status, new=False)
    print(json.dumps({'status': status['status'], 'solve_attempts': status['solve_attempts']}))
    return 0 if status['status'] == 'completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
