# Explicit VCS four-point attempt, following the preserved Gibbs failure

The original root-execution/native01 remains failed and unchanged: only the first
1000 K point ran. All five final element residuals exceeded the original
1e-10*(1+abs(b_e)) mol gate. Source properties and same-pool Gibbs checks passed.
Its exit 1 and reaped child are preserved, not replaced by this plan.

Source inspection gives a concrete numerical reason to change the explicit
solver: Gibbs/MultiPhaseEquil uses independent trace-species updates below an
absolute 1e-12 kmol level and terminates on reaction delta-G, without the same
element check. VCS has element-abundance checks/correction. This is support for
testing an alternative, not proof that every observed residual is caused by
that line or that VCS will pass. No automatic fallback is added.

Use TPPolicy/CLI with solver explicitly `vcs`, same source-preserving
NASA1993_1BAR_EXPLICIT_REFERENCE_V1, Cantera 3.2.0, same fresh phases per call,
P=100000 Pa and virtual atom pool C/H/O/N/S=1/1.6/.6/.1/.01 mol. Input is not
one kg of sludge. Keep all physical choices and all posterior tolerances.

Requested native rtol remains 1e-10, but the inspected VCS TP implementation
does not consume its err argument. The reported native defaults are major
1e-8, minor1e-6 and secondary1e-10/1e-8. Do not claim requested rtol is the
effective VCS convergence criterion. The module's independent element,
chemical-potential, graphite and Gibbs gates remain the acceptance criteria.
Same max_steps1000, max_iter100, estimate_equil0; no retry/fallback.

At most four actual public CLI calls: 1000K/element_basis,
1000K/methane_shift, 800K/element_basis, 1200K/element_basis. Both 1000K points,
their independently saved property checks and seed comparison must pass before
800/1200 are attempted. Stop at the first failure. Retain every returned result.

Budgets remain10s/module solve,40s/driver,50s/existing supervisor plus5s cleanup.
Independent standard-state checks remain19 species x4 properties x2 snapshots
per point, against the exact-binary64-coefficient NASA7 reference: absolute
dimensionless difference<=2e-10+5e-12*abs(reference). Low branch owns1000K.
This is a nominal arithmetic tolerance, not a source-fit error certificate.

Same two-seed gates: each species difference<=1e-8mol+1e-7max(nA,nB), and
G difference<=1e-7*R*1000*3.31. No expected graphite-yield gate. Success remains
restricted composition only, no raw-sludge, TG, kinetics or heat-duty validation.

Freeze the new reviewed module/CLI installation and the existing source and
reference data in the supervisor. The old failed snapshots and supervisor stay
in their original directory. This new directory has one exclusive native01.
