"""Four predeclared public CLI calls; saved-data cross-check, no alternate solver."""
from fractions import Fraction as F
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import time

STARTED = time.monotonic()
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK = Path(__file__).resolve().parent
OUT = WORK / 'native01'
REFERENCE = WORK.parent / 'source-reference/REFERENCE.json'
if hashlib.sha256(REFERENCE.read_bytes()).hexdigest() != '388caee3d17027f64a4ced9bef56d3bb50760daaf28bf4e5d29d928e70c3047d':
    raise ValueError('reference_changed')
reference = json.loads(REFERENCE.read_text())
entry_spec = importlib.util.spec_from_file_location('tp_public_entry', ROOT / 'examples/sandbox/run_tp_equilibrium.py')
entry = importlib.util.module_from_spec(entry_spec)
entry_spec.loader.exec_module(entry)
summary = {'status': 'started', 'points': [], 'seed_comparison': None,
           'driver_budget_s': 40, 'max_equilibrium_calls': 4, 'explicit_solver': 'vcs'}


def save():
    encoded = json.dumps(summary, indent=2, allow_nan=False) + '\n'
    (OUT / 'SERIES.json').write_text(encoded)


def guard():
    if time.monotonic() - STARTED > 40:
        raise TimeoutError('driver_budget_40s')


def fraction(record):
    return F(record['numerator'], record['denominator'])


def properties(result, temperature):
    rows = []
    keys = [('standard_cp_j_mol_k', 'cp_over_R', False),
            ('standard_h_j_mol', 'h_over_RT', True),
            ('standard_s_j_mol_k', 's_over_R', False),
            ('standard_g_j_mol', 'g_over_RT', True)]
    for state_name in ('initial', 'final'):
        state = result[state_name]
        for i, species in enumerate(reference['records']):
            point = next(p for p in species['points'] if p['temperature_k'] == temperature)
            for actual_key, reference_key, times_t in keys:
                expected = float(point['binary64_coefficients'][reference_key]['decimal_90_digits'])
                divisor = state['gas_constant_j_mol_k'] * (temperature if times_t else 1)
                actual = state[actual_key][i] / divisor
                error = actual - expected
                tolerance = 2e-10 + 5e-12 * abs(expected)
                rows.append({'snapshot': state_name, 'species': species['species'],
                             'property': reference_key, 'actual': actual,
                             'reference': expected, 'difference': error,
                             'tolerance': tolerance,
                             'passed': math.isfinite(error) and abs(error) <= tolerance})
    return rows


def seed_comparison(first, second):
    rows = []
    for name, a, b in zip(first['seed']['species'], first['diagnostics']['amounts_mol'],
                          second['diagnostics']['amounts_mol'], strict=True):
        a, b = fraction(a), fraction(b)
        difference = abs(a - b)
        tolerance = F(1, 10**8) + F(1, 10**7) * max(a, b)
        rows.append({'species': name, 'difference_mol': float(difference),
                     'tolerance_mol': float(tolerance), 'passed': difference <= tolerance})
    difference = abs(fraction(first['diagnostics']['gibbs_j']) - fraction(second['diagnostics']['gibbs_j']))
    tolerance = F(1, 10**7) * F(first['final']['gas_constant_j_mol_k']) * 1000 * F('3.31')
    return {'species': rows, 'G_difference_j': float(difference),
            'G_tolerance_j': float(tolerance), 'G_passed': difference <= tolerance,
            'passed': all(r['passed'] for r in rows) and difference <= tolerance}


save()
results = []
try:
    for index, (temperature, seed) in enumerate(((1000, 'element_basis'), (1000, 'methane_shift'),
                                               (800, 'element_basis'), (1200, 'element_basis')), 1):
        guard()
        output = OUT / f'point{index:02d}_{temperature}_{seed}.json'
        code = entry.main(['--source-root', str(ROOT), '--output', str(output),
                           '--temperature-k', str(temperature), '--carbon-mol', '1',
                           '--hydrogen-mol', '1.6', '--oxygen-mol', '.6', '--nitrogen-mol', '.1',
                           '--sulfur-mol', '.01', '--basis-id', 'virtual_CHONS_C1_mol', '--seed', seed, '--solver', 'vcs'])
        item = {'temperature_k': temperature, 'seed': seed, 'exit_code': code,
                'output': output.name, 'status': 'entry_returned_output_not_read',
                'saved_before_budget_check': True}
        summary['points'].append(item)
        save()
        try:
            raw = output.read_bytes()
            record = json.loads(raw)
            item.update(status=record['status'], sha256=hashlib.sha256(raw).hexdigest())
        except Exception as exc:
            item['output_read_failure'] = {'type': type(exc).__name__, 'reason': str(exc)}
            raise
        save()
        guard()
        if code != 0 or record['status'] != 'completed':
            raise RuntimeError('public_CLI_point_failed')
        result = record['result']
        if result['policy']['solver'] != 'vcs':
            raise RuntimeError('explicit_VCS_policy_not_used')
        if not result['actual_source_properties_checked']:
            raise RuntimeError('actual_source_properties_not_checked')
        rows = properties(result, temperature)
        item['independent_standard_properties'] = rows
        item['property_checks_passed'] = all(r['passed'] for r in rows)
        results.append(result)
        save()
        if not item['property_checks_passed']:
            raise RuntimeError('independent_standard_property_check_failed')
        if index == 2:
            summary['seed_comparison'] = seed_comparison(*results)
            save()
            if not summary['seed_comparison']['passed']:
                raise RuntimeError('independent_seed_comparison_failed')
        guard()
    summary['status'] = 'completed'
except Exception as exc:
    summary['status'] = 'failed'
    summary['failure'] = {'type': type(exc).__name__, 'reason': str(exc)}
summary['driver_elapsed_before_final_write_s'] = time.monotonic() - STARTED
if summary['driver_elapsed_before_final_write_s'] > 40:
    summary['status'] = 'resource_limit'
    summary['failure'] = {'type': 'TimeoutError', 'reason': 'driver_budget_40s_at_return'}
save()
elapsed_after_write = time.monotonic() - STARTED
if elapsed_after_write > 40:
    summary['status'] = 'resource_limit'
    summary['failure'] = {'type': 'TimeoutError', 'reason': 'driver_budget_40s_after_final_write'}
    summary['driver_elapsed_after_final_write_s'] = elapsed_after_write
    save()
print(json.dumps({'status': summary['status'], 'points': len(summary['points']),
                  'driver_elapsed_after_final_write_s': time.monotonic() - STARTED}))
raise SystemExit(0 if summary['status'] == 'completed' else 1)
