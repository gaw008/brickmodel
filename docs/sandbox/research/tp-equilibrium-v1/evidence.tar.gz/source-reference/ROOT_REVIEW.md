# Independent read of the mathematical reference

ROOT read calculate_reference.py (SHA 8d69c15feadc8e99e702253e96f72fc7b85b1d38e08eaad1897144b63f4bad4a),
README, EXECUTION.json and CHECKS.json, separately from its author.

The source block extraction is pinned to the exact original YAML bytes and
checks all 14 decimal strings. The NASA7 indices in Cp, h and s are consistent;
g is formed as h-s. Equal-midpoint selects the low branch. Exact binary64
coefficient conversion is distinct from decimal source coefficients and from
runtime operation order. Logarithm endpoints use a fixed Decimal context;
ordering both signed products handles negative a0. High-minus-low uses the
shared log expression and does not mistake a source-fit jump for arithmetic
error. The reference pressure diagnostic has the correct gas sign and excludes
graphite's different pressure correction. These are source-equation checks,
not thermochemical fit or material uncertainty certificates.

The saved execution is exit 0 with byte-identical replay. No new run, Cantera
import, phase construction or equilibrium was needed for this review. Approved
as a nominal independent arithmetic reference at 800/1000/1200 K and 1 bar.
The actual backend comparison still requires its separately stated tolerance.
