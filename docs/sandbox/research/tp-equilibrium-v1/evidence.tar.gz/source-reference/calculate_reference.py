"""Independent NASA7 algebra at three temperatures; no property backend imports."""
from __future__ import annotations

import argparse
from decimal import Context, Decimal, DivisionByZero, InvalidOperation, Overflow
from decimal import ROUND_HALF_EVEN, localcontext
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import platform
import re
import sys

SOURCE = Path(__file__).resolve().parent.parent / 'source-admission'
EXPECTED = {
    'CANDIDATE.json': '35abac14a354a20d7aef76bd6e3bfc66b08f4f5fc8432efc25aa3431a553e731',
    'raw/nasa_gas.yaml': '4de6199d65d2d3db782e30573720c723130953707336add59713b02d8667e4db',
    'raw/graphite.yaml': '6074b6dd691785403dee1eeebf8e583b747681c34a148746bab2256282939cbd',
}
SPECIES = 'H2 H2O CO CO2 CH4 O2 N2 NH3 HCN NO NO2 N2O H2S SO2 SO3 COS CS2 S2'.split()
PROPERTIES = ('cp_over_R', 'h_over_RT', 's_over_R', 'g_over_RT')


def context(precision: int) -> Context:
    """Specify every Context field, independently of mutable Decimal defaults."""
    return Context(prec=precision, rounding=ROUND_HALF_EVEN, Emin=-999999,
                   Emax=999999, capitals=1, clamp=0, flags=[],
                   traps=[InvalidOperation, DivisionByZero, Overflow])


def ratio(value: Fraction) -> dict[str, str]:
    return {'numerator': str(value.numerator), 'denominator': str(value.denominator)}


def display(value: Fraction) -> str:
    with localcontext(context(90)):
        return str(Decimal(value.numerator) / Decimal(value.denominator))


def logarithm(integer: int) -> tuple[Fraction, Fraction, Fraction]:
    """Correctly rounded Decimal ln enclosed by its adjacent 120-digit values."""
    with localcontext(context(120)) as active:
        nominal = Decimal(integer).ln()
        return (Fraction(nominal), Fraction(nominal.next_minus(active)),
                Fraction(nominal.next_plus(active)))


def expressions(coefficients: list[Fraction], temperature: int) -> dict[str, tuple[Fraction, Fraction]]:
    """Return each property as constant + log_multiplier * ln(T), exactly."""
    a = coefficients
    t = Fraction(temperature)
    cp = sum((a[i] * t**i for i in range(5)), Fraction())
    h = sum((a[i] * t**i / (i + 1) for i in range(5)), Fraction()) + a[5] / t
    s_constant = sum((a[i] * t**i / i for i in range(1, 5)), Fraction()) + a[6]
    return {'cp_over_R': (cp, Fraction()), 'h_over_RT': (h, Fraction()),
            's_over_R': (s_constant, a[0]), 'g_over_RT': (h - s_constant, -a[0])}


def encode(expression: tuple[Fraction, Fraction], log: tuple[Fraction, Fraction, Fraction],
           logarithm_argument: str = 'T') -> dict:
    constant, multiplier = expression
    nominal = constant + multiplier * log[0]
    if not multiplier:
        return {'decimal_90_digits': display(nominal), 'exact_fraction': ratio(nominal)}
    bounds = sorted(constant + multiplier * endpoint for endpoint in log[1:])
    return {'decimal_90_digits': display(nominal),
            'exact_expression': {'constant': ratio(constant), 'logarithm_argument': logarithm_argument,
                                 'logarithm_multiplier': ratio(multiplier)},
            'numerical_enclosure': {'lower': ratio(bounds[0]), 'upper': ratio(bounds[1])}}


def evaluate(coefficients: list[Fraction], temperature: int) -> dict:
    return {key: encode(value, logarithm(temperature))
            for key, value in expressions(coefficients, temperature).items()}


def coefficient_records(candidate: dict, raw: dict[str, bytes]) -> list[dict]:
    records = list(candidate['gas_species']) + [candidate['condensed_phase']]
    names = [record.get('species', record.get('name')) for record in records]
    if names != SPECIES + ['C(gr)']:
        raise ValueError('frozen species order mismatch')
    for name, record in zip(names, records, strict=True):
        source_text = raw[record['file']].decode()
        match = re.search(r'^- name: ' + re.escape(name) + r'\n.*?(?=^- name: |\Z)',
                          source_text, re.MULTILINE | re.DOTALL)
        if match is None:
            raise ValueError(f'missing original block: {name}')
        block = match.group(0)
        if hashlib.sha256(block.encode()).hexdigest() != record['source_block_sha256']:
            raise ValueError(f'original block hash mismatch: {name}')
        data = block.split('    data:\n', 1)[1].split('    note:', 1)[0].split('  equation-of-state:', 1)[0]
        strings = re.findall(r'-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?', data)
        if strings != record['coefficient_strings'] or len(strings) != 14:
            raise ValueError(f'original decimal coefficient mismatch: {name}')
    return records


def generate() -> dict:
    if (sys.float_info.radix, sys.float_info.mant_dig, sys.float_info.max_exp) != (2, 53, 1024):
        raise RuntimeError('IEEE binary64 conversion required')
    raw = {name: (SOURCE / name).read_bytes() for name in EXPECTED}
    for name, expected in EXPECTED.items():
        if hashlib.sha256(raw[name]).hexdigest() != expected:
            raise ValueError(f'frozen input hash mismatch: {name}')
    candidate = json.loads(raw['CANDIDATE.json'])
    results = []
    for record in coefficient_records(candidate, raw):
        strings = record['coefficient_strings']
        decimal = [Fraction(value) for value in strings]
        binary = [Fraction.from_float(float(value)) for value in strings]
        points = []
        for temperature in (800, 1000, 1200):
            start = 0 if temperature <= 1000 else 7
            points.append({'temperature_k': temperature, 'selected_branch': 'low' if start == 0 else 'high',
                           'original_decimal': evaluate(decimal[start:start + 7], temperature),
                           'binary64_coefficients': evaluate(binary[start:start + 7], temperature),
                           'binary64_minus_original_decimal': evaluate(
                               [b - d for b, d in zip(binary[start:start + 7], decimal[start:start + 7], strict=True)], temperature)})
        jumps = {name: evaluate([a[i + 7] - a[i] for i in range(7)], 1000)
                 for name, a in [('original_decimal', decimal), ('binary64_coefficients', binary)]}
        results.append({'species': record.get('species', record['name']),
                        'yaml_coefficients_low_then_high': strings,
                        'binary64_coefficients_hex': [float(value).hex() for value in strings],
                        'points': points, 'join_1000_high_minus_low': jumps})
    ln_num, lower_num, upper_num = logarithm(101325)
    ln_den, lower_den, upper_den = logarithm(100000)
    pressure_delta = (ln_num - ln_den, lower_num - upper_den, upper_num - lower_den)
    return {'classification': 'independent_mathematical_reference_not_experiment_or_material_accuracy',
            'source_hashes': EXPECTED, 'formula': 'NASA7: Cp/R=sum(a_i*T^i,i=0..4); h/RT=sum(a_i*T^i/(i+1),i=0..4)+a5/T; s/R=a0*ln(T)+sum(a_i*T^i/i,i=1..4)+a6; g/RT=h/RT-s/R',
            'temperature_k': [800, 1000, 1200], 'state_pressure_pa': 100000,
            'derived_source_reference_pressure_pa': 100000,
            'join_convention': 'T <= 1000 K uses low; jump means high(1000)-low(1000)',
            'numerics': {'log_precision_decimal_digits': 120, 'display_precision_decimal_digits': 90,
                         'polynomial_and_enclosure_arithmetic': 'exact Fraction',
                         'display_strings_are_not_interval_endpoints': True,
                         'coefficient_quantization_is_distinct_from_evaluation_roundoff': True,
                         'does_not_emulate_binary64_runtime_operation_order': True,
                         'NASA7_input_decimal_strings_are_exact_rational_inputs': True},
            'gas_default_1atm_at_state_1bar_minus_derived_1bar': {
                'description': 'Same numerical coefficients, different pressure metadata: delta(s/R)=ln(101325/100000), delta(g/RT)=negative thereof; delta(Cp/R)=delta(h/RT)=0.',
                'delta_s_over_R': encode((Fraction(), Fraction(1)), pressure_delta, '101325/100000'),
                'delta_g_over_RT': encode((Fraction(), Fraction(-1)), pressure_delta, '101325/100000'),
                'graphite': 'Not a gas log shift. Wrong pref introduces Vm*(100000-101325)/(RT) into h/RT and g/RT; not evaluated here.'},
            'python': sys.version, 'platform': platform.platform(),
            'cantera_calls': 0, 'equilibrium_calls': 0, 'eos_backend_calls': 0,
            'source_fit_error': None, 'source_fit_covariance': None,
            'all_18_original_NASA_table_rows_individually_revalidated': False,
            'records': results}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='new JSON path in this scratch directory')
    output = parser.parse_args().output.resolve()
    if output.parent != Path(__file__).resolve().parent:
        parser.error('output must stay in the owned source-reference directory')
    result = generate()
    encoded = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    with output.open('xb') as stream:
        stream.write(encoded)
    print(f'Wrote {output}: {len(result["records"])} species, 57 selected points, 19 two-branch jumps, two coefficient representations')
    print(f'SHA256 {hashlib.sha256(encoded).hexdigest()}')
    print('Cantera calls=0; EOS backend calls=0; equilibrium calls=0; Fraction polynomial algebra + Decimal ln only')


if __name__ == '__main__':
    main()
