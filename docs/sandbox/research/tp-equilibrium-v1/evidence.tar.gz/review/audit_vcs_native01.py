"""Bounded saved four-point check; only stdlib and recorded values, zero EOS."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json, math
W=Path('/private/tmp/sludge-tp-equilibrium-v1');ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github');OUT=W/'root-vcs-execution/native01'
def hook(d):return F(d['numerator'],d['denominator']) if set(d)=={'numerator','denominator'} and all(type(v)is int for v in d.values()) else d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def sha(p):return sha256(p.read_bytes()).hexdigest()
def wire(v):
 if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
 if isinstance(v,dict):return {k:wire(x) for k,x in v.items()}
 if isinstance(v,(tuple,list)):return [wire(x) for x in v]
 return v
checks=[]
def check(n,ok):checks.append({'name':n,'passed':bool(ok)})
series=read(OUT/'SERIES.json');ref=read(W/'source-reference/REFERENCE.json')
pack=read(ROOT/'data/sandbox/research/tp-equilibrium-v1/derived.json');model=read(ROOT/'data/sandbox/research/tp-equilibrium-v1/model.json');source=read(ROOT/'data/sandbox/research/tp-equilibrium-v1/source.json')
names=[s['name'] for s in pack['species']];E=['C','H','O','N','S'];A=[[int(s['composition'].get(e,0)) for e in E] for s in pack['species']]
expected_order=[(1000,'element_basis'),(1000,'methane_shift'),(800,'element_basis'),(1200,'element_basis')]
check('four_calls_in_registered_order_only',series['status']=='completed' and series['explicit_solver']=='vcs' and [(p['temperature_k'],p['seed']) for p in series['points']]==expected_order and len(list(OUT.glob('point*.json')))==4)
check('reference_identity_and_species',sha(W/'source-reference/REFERENCE.json')=='388caee3d17027f64a4ced9bef56d3bb50760daaf28bf4e5d29d928e70c3047d' and [s['species'] for s in ref['records']]==names)
point_records=[];results=[];property_count=0;max_property_error=0.
for i,item in enumerate(series['points']):
 tag=f'point{i+1}';T,seed=expected_order[i];record=read(OUT/item['output']);r=record['result'];results.append(r);d=r['diagnostics'];breq=r['request']['element_mol'];policy=r['policy']
 check(tag+'_identity_status_and_policy',sha(OUT/item['output'])==item['sha256'] and item['exit_code']==0 and record['status']==r['status']=='completed' and all(d['checks'].values()) and r['failure'] is None and r['request']['temperature_k']==T and r['request']['pressure_pa']==100000. and breq==[F(1),F('1.6'),F('.6'),F('.1'),F('.01')] and record['request']['solver']==policy['solver']=='vcs' and r['seed']['variant']==seed)
 check(tag+'_effective_requested_semantics',policy['rtol']==policy['requested_native_rtol']==1e-10 and policy['policy_id']=='CHONS_TP_NOMINAL_ACCEPTANCE_V2' and policy['effective_native_tolerances']['requested_rtol_consumed'] is False and [policy['effective_native_tolerances'][k] for k in ['tolmaj','tolmin','tolmaj2','tolmin2']]==[1e-8,1e-6,1e-10,1e-8])
 check(tag+'_fixed_resource_policy',policy['max_steps']==1000 and policy['requested_estimate_equil']==0 and policy['maximum_elapsed_s']==10 and r['elapsed_seconds']<10 and r['provider_calls_attempted']==r['provider_calls_completed']==3)
 inv={};G={};mu={};element_rows=[];prop_rows=[]
 for label in ['initial','final']:
  s=r[label];n=[F(v)*1000 for v in s['amounts_kmol']];b=[sum((n[j]*A[j][e] for j in range(19)),F()) for e in range(5)];res=[x-y for x,y in zip(b,breq)];inv[label]=(n,b,res)
  check(tag+'_'+label+'_inventory_TP',len(n)==19 and all(math.isfinite(v) and v>=0 for v in s['amounts_kmol']) and s['temperature_k']==T and s['pressure_pa']==100000.)
  for name,x in zip(E,res):
   e=E.index(name);limit=F(1,10**10)*(1+abs(breq[e]));element_rows.append({'snapshot':label,'element':name,'residual_mol':x,'residual_float_mol':float(x),'original_limit_mol':limit,'abs_residual_over_limit':float(abs(x)/limit),'passed':abs(x)<=limit})
  check(tag+'_'+label+'_all_five_elements',all(z['passed'] for z in element_rows if z['snapshot']==label))
  rt=s['gas_constant_j_mol_k']*T;Ng=sum(n[:18],F());mu[label]=[s['standard_g_j_mol'][j]+rt*(math.log(n[j])-math.log(Ng)) if n[j] else None for j in range(18)]+[s['standard_g_j_mol'][18]]
  G[label]=sum((a*F(v) for a,v in zip(n,mu[label]) if a),F())
  loaded=s['loaded_definition']['species']
  check(tag+'_'+label+'_loaded_source',len(loaded)==19 and all(v['name']==src['name'] and v['composition']==src['composition'] and v['reference_pressure_pa']==100000. and v['coefficients_high_then_low']==[src['thermo']['temperature-ranges'][1],*src['thermo']['data'][1],*src['thermo']['data'][0]] for v,src in zip(loaded,pack['species'])))
  for j,sp in enumerate(ref['records']):
   p=next(p for p in sp['points'] if p['temperature_k']==T)
   for key,rkey,tflag in [('standard_cp_j_mol_k','cp_over_R',False),('standard_h_j_mol','h_over_RT',True),('standard_s_j_mol_k','s_over_R',False),('standard_g_j_mol','g_over_RT',True)]:
    expect=float(p['binary64_coefficients'][rkey]['decimal_90_digits']);actual=s[key][j]/(s['gas_constant_j_mol_k']*(T if tflag else 1));diff=actual-expect;tol=2e-10+5e-12*abs(expect)
    prop_rows.append({'snapshot':label,'species':sp['species'],'property':rkey,'actual':actual,'reference':expect,'difference':diff,'tolerance':tol,'passed':math.isfinite(diff) and abs(diff)<=tol})
 check(tag+'_152_source_properties_and_saved_rows',len(prop_rows)==152 and prop_rows==item['independent_standard_properties'] and all(v['passed'] for v in prop_rows) and item['property_checks_passed'] and r['actual_source_properties_checked'])
 property_count+=len(prop_rows);max_property_error=max(max_property_error,max(abs(v['difference']) for v in prop_rows))
 n,b,res=inv['final'];B=sum(b,F());rt=r['final']['gas_constant_j_mol_k']*T
 check(tag+'_exact_inventory_G_and_mu',n==d['amounts_mol'] and b==d['elements_mol'] and res==d['element_residual_mol'] and G['initial']==d['seed_gibbs_j'] and G['final']==d['gibbs_j'] and mu['final']==d['chemical_potentials_j_mol'])
 check(tag+'_supplied_seed_projection',r['seed']['supplied_amounts_kmol']==[float(v/1000) for v in r['seed']['exact_amounts_mol']])
 lam=d['element_potentials_j_mol_atoms'];implied=[math.fsum(a*v for a,v in zip(row,lam)) for row in A];std=r['final']['standard_g_j_mol'];logs=[(implied[j]-std[j])/rt for j in range(18)];mx=max(logs);logz=mx+math.log(math.fsum(math.exp(v-mx) for v in logs));dc=(std[18]-lam[0])/rt;delta=max(0.,logz,-dc)
 penalty=F(rt)*F(delta);Lout=sum((F(v)*x for v,x in zip(lam,b)),F())-penalty*B;Lreq=sum((F(v)*x for v,x in zip(lam,breq)),F())-penalty*sum(breq,F());gap=G['final']-Lout;greq=G['final']-Lreq;correction=sum((F(v)*x for v,x in zip(lam,res)),F())-penalty*sum(res,F())
 check(tag+'_all_candidate_partition',all(d['structurally_admitted']) and logz==d['log_partition_sum'] and dc==d['graphite_reduced_potential_over_RT'] and delta==d['partition_penalty'])
 check(tag+'_same_and_requested_pool_identity',Lout==d['lower_bound_out_j'] and Lreq==d['lower_bound_requested_j'] and gap==d['gap_out_j'] and greq==d['gap_requested_j'] and greq-gap==correction==d['requested_pool_gap_correction_j'])
 check(tag+'_original_scaled_gap_gate',gap/(F(rt)*B)==d['scaled_gap_out'] and -F(1,10**10)<=gap/(F(rt)*B)<=F(1,10**7))
 active=[j for j in range(19) if n[j]>B*F(1,10**12)];ar=[(mu['final'][j]-implied[j])/rt for j in active]
 check(tag+'_original_active_mu_graphite_Gdescent',ar==d['active_residuals_over_RT'] and max(map(abs,ar))<=1e-7 and (abs(dc)<=1e-7 if 18 in active else dc>=-1e-7) and G['final']<=G['initial']+F(rt)*B*F(1,10**7))
 h=sum((a*F(v) for a,v in zip(n,r['final']['standard_h_j_mol'])),F());check(tag+'_H_S_G_identity',h==d['mixture_enthalpy_j'] and (h-G['final'])/T==d['mixture_entropy_j_k'])
 ident=r['provider_identity'];check(tag+'_actual_provider_source_and_unknown',ident['kind']=='actual_cantera' and ident['version']=='3.2.0' and ident['requested_native_solver']=='vcs' and ident['effective_native_tolerances']==policy['effective_native_tolerances'] and r['provenance']['model']==model and r['provenance']['source']==source and r['material_qualified'] is False and r['training_eligible'] is False)
 point_records.append({'point':item['output'],'T_K':T,'seed':seed,'elapsed_seconds':r['elapsed_seconds'],'elements':element_rows,'G_j':float(G['final']),'gap_out_j':float(gap),'gap_requested_j':float(greq),'gap_correction_j':float(correction),'scaled_gap':float(d['scaled_gap_out']),'max_active_residual_over_RT':max(map(abs,ar)),'graphite_mol':float(n[18]),'source_property_checks':len(prop_rows),'source_property_max_abs_difference':max(abs(v['difference']) for v in prop_rows),'sha256':sha(OUT/item['output'])})
a,b=results[:2];comparison=series['seed_comparison'];rows=[]
for name,na,nb in zip(names,a['diagnostics']['amounts_mol'],b['diagnostics']['amounts_mol']):
 diff=abs(na-nb);limit=F(1,10**8)+F(1,10**7)*max(na,nb);rows.append({'species':name,'difference_mol':float(diff),'tolerance_mol':float(limit),'passed':diff<=limit})
gdiff=abs(a['diagnostics']['gibbs_j']-b['diagnostics']['gibbs_j']);glimit=F(1,10**7)*F(a['final']['gas_constant_j_mol_k'])*1000*F('3.31')
check('two_seed_19_inventory_and_G_comparison',rows==comparison['species'] and all(x['passed'] for x in rows) and float(gdiff)==comparison['G_difference_j'] and float(glimit)==comparison['G_tolerance_j'] and gdiff<=glimit and comparison['G_passed'] and comparison['passed'])
meta=read(W/'root-vcs-execution/supervised-native01/metadata.json');status=read(W/'root-vcs-execution/supervised-native01/status.json')
def normalized(x):return {p:(v['sha256'] if isinstance(v,dict) else v) for p,v in x.items()}
before=normalized(meta['inputs_before']);after=normalized(status['inputs_after'])
check('all_1218_before_after_current_inputs',len(before)==1218 and before==after and status['inputs_unchanged'] is True and all(Path(p).is_file() and sha(Path(p))==h for p,h in before.items()))
check('reviewed_module_and_CLI',before[str(ROOT/'src/sludge_sandbox/tp_equilibrium.py')]=='da382eead7211e5a91a1630fbe30a75a8c7feca9cb1af6814398c57f8914849c' and before[str(ROOT/'examples/sandbox/run_tp_equilibrium.py')]=='5553a152153f2bcc32feaaf5af2fe1a076d9f76c3f2c9bca54f4c47697910f82')
check('source_pack_all_pins',all(sha(ROOT/'data/sandbox/research/tp-equilibrium-v1'/p)==h for p,h in model['files'].items()))
install=read(W/'INSTALLED_IDENTITY03.json')
check('187_package_180_modules_installed_20_tests',install['package_files']==187 and install['python_modules']==180 and install['all_equal'] and all(sha(Path(x['source']))==sha(Path(x['installed']))==x['sha256'] for x in install['files']) and install['testsuites'][0]['tests']=='20' and install['testsuites'][0]['failures']==install['testsuites'][0]['errors']=='0')
check('completed_reaped_original_budgets',status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] and meta['timeout_s']==50 and meta['cleanup_grace_s']==5 and status['elapsed_s']<50 and series['driver_budget_s']==40 and series['driver_elapsed_before_final_write_s']<40)
prior=read(W/'review/VCS_FINAL_READ01.json')['files'];oldpaths=[p for p in prior if '/root-execution/native01/' in p or '/root-execution/supervised-native01/' in p]
check('original_Gibbs_failure_preserved',all(sha(Path(p))==prior[p]['sha256'] for p in oldpaths) and read(W/'root-execution/native01/SERIES.json')['status']=='failed')
output={'audit_verdict':'PASS' if all(v['passed'] for v in checks) else 'FAIL','checks':checks,'point_results':point_records,'source_property_comparisons':property_count,'source_property_max_abs_difference':max_property_error,'seed_comparison':comparison,'driver_elapsed_s':series['driver_elapsed_before_final_write_s'],'supervisor_elapsed_s':status['elapsed_s'],'supervision_input_count':len(before),'eos_or_native_runs_by_audit':0,'original_Gibbs_failure_preserved':checks[-1]['passed'],'material_qualified':False,'training_eligible':False}
with (W/'review/VCS_NATIVE_AUDIT01.json').open('x') as f:json.dump(wire(output),f,indent=2,allow_nan=False)
print(output['audit_verdict'],len(checks),'group checks',property_count,'property checks')
for p in point_records:print(p['point'], 'max element',max(abs(x['residual_float_mol']) for x in p['elements'] if x['snapshot']=='final'),'scaled gap',p['scaled_gap'],'graphite mol',p['graphite_mol'])
print('max property error',max_property_error,'seed G',float(gdiff),'max species difference',max(r['difference_mol'] for r in rows))
print('failed',[v for v in checks if not v['passed']])
raise SystemExit(0 if output['audit_verdict']=='PASS' else 1)
