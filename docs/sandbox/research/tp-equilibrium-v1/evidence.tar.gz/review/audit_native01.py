"""Single saved-result audit; stdlib only, no application imports or EOS."""
import json, math
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
W=Path('/private/tmp/sludge-tp-equilibrium-v1')
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
R=W/'review'
def hook(d):
    return F(d['numerator'],d['denominator']) if set(d)=={'numerator','denominator'} and all(type(v)is int for v in d.values()) else d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def wire(v):
    if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
    if isinstance(v,dict):return {k:wire(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [wire(x) for x in v]
    return v
checks=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)})
def hashed(p):return sha256(p.read_bytes()).hexdigest()
point=W/'root-execution/native01/point01_1000_element_basis.json'
record=read(point);result=record['result'];d=result['diagnostics'];req=result['request']['element_mol']
series=read(W/'root-execution/native01/SERIES.json')
meta=read(W/'root-execution/supervised-native01/metadata.json')
status=read(W/'root-execution/supervised-native01/status.json')
reference=read(W/'source-reference/REFERENCE.json')
pack=read(ROOT/'data/sandbox/research/tp-equilibrium-v1/derived.json')
species=[s['name'] for s in pack['species']];elements=['C','H','O','N','S']
atoms=[[F(s['composition'].get(e,0)) for e in elements] for s in pack['species']]
check('only_first_point_saved_stop_after_failure',len(series['points'])==1 and len(list(point.parent.glob('point*.json')))==1 and series['status']=='failed' and series['seed_comparison'] is None)
check('original_failure_is_only_elements',record['status']==result['status']=='postcheck_failed' and result['reason']=='nominal_posterior_checks_rejected' and [k for k,v in d['checks'].items() if not v]==['elements'])
check('series_binds_point',series['points'][0]['sha256']==hashed(point))
check('fixed_request_and_policy',req==[F(1),F('1.6'),F('.6'),F('.1'),F('.01')] and result['request']['temperature_k']==1000. and result['request']['pressure_pa']==100000. and result['policy']['solver']=='gibbs' and result['policy']['rtol']==1e-10 and result['policy']['max_steps']==1000 and result['policy']['maximum_elapsed_s']==10.)
inventories={};element_rows=[];Gs={};mus={}
for label in ['initial','final']:
    state=result[label];raw=state['amounts_kmol'];n=[F(x)*1000 for x in raw]
    b=[sum((n[i]*atoms[i][e] for i in range(19)),F()) for e in range(5)]
    residual=[x-y for x,y in zip(b,req)]
    inventories[label]=(n,b,residual)
    check(label+'_raw_shape_nonnegative',len(n)==19 and all(math.isfinite(x) and x>=0 for x in raw))
    check(label+'_TP',state['temperature_k']==1000. and state['pressure_pa']==100000.)
    for e,x,y,z in zip(elements,b,req,residual):
        limit=F(1,10**10)*(1+abs(y))
        element_rows.append({'snapshot':label,'element':e,'requested_mol':y,'returned_mol':x,'residual_mol':z,'residual_float_mol':float(z),'original_tolerance_mol':limit,'tolerance_float_mol':float(limit),'abs_residual_over_tolerance':float(abs(z)/limit),'original_gate_passed':abs(z)<=limit})
    rt=state['gas_constant_j_mol_k']*state['temperature_k'];ng=sum(n[:18],F())
    mu=[state['standard_g_j_mol'][i]+rt*(math.log(n[i])-math.log(ng)) if n[i] else None for i in range(18)]+[state['standard_g_j_mol'][18]]
    G=sum((x*F(y) for x,y in zip(n,mu) if x),F());Gs[label]=G;mus[label]=mu
check('initial_projection_passes_all_five',all(x['original_gate_passed'] for x in element_rows if x['snapshot']=='initial'))
n,b,residual=inventories['final'];B=sum(b,F());rt=result['final']['gas_constant_j_mol_k']*1000.
check('readback_Fractions_equal_saved',n==d['amounts_mol'] and b==d['elements_mol'] and residual==d['element_residual_mol'])
check('initial_exact_seed_preserved',result['initial']['amounts_kmol']==result['seed']['supplied_amounts_kmol'])
check('G_seed_final_and_mu_exact',Gs['initial']==d['seed_gibbs_j'] and Gs['final']==d['gibbs_j'] and mus['final']==d['chemical_potentials_j_mol'])
lam=d['element_potentials_j_mol_atoms'];std=result['final']['standard_g_j_mol']
implied=[math.fsum(float(a)*v for a,v in zip(row,lam)) for row in atoms]
logs=[(implied[i]-std[i])/rt for i in range(18)];mx=max(logs)
logz=mx+math.log(math.fsum(math.exp(x-mx) for x in logs));dc=(std[18]-lam[0])/rt;delta=max(0.,logz,-dc)
check('full_candidate_partition_recalculated',logz==d['log_partition_sum'] and dc==d['graphite_reduced_potential_over_RT'] and delta==d['partition_penalty'])
penalty=F(rt)*F(delta)
Lout=sum((F(x)*y for x,y in zip(lam,b)),F())-penalty*B
Lreq=sum((F(x)*y for x,y in zip(lam,req)),F())-penalty*sum(req,F())
gap=Gs['final']-Lout;greq=Gs['final']-Lreq
correction=sum((F(x)*y for x,y in zip(lam,residual)),F())-penalty*sum(residual,F())
check('same_pool_G_and_requested_correction',Lout==d['lower_bound_out_j'] and Lreq==d['lower_bound_requested_j'] and gap==d['gap_out_j'] and greq==d['gap_requested_j'] and greq-gap==correction==d['requested_pool_gap_correction_j'])
check('nominal_same_pool_gap_gate',gap/(F(rt)*B)==d['scaled_gap_out'] and -F(1,10**10)<=gap/(F(rt)*B)<=F(1,10**7))
active=[i for i in range(19) if n[i]>B*F(1,10**12)]
ar=[(mus['final'][i]-implied[i])/rt for i in active]
check('active_mu_and_graphite_gate',ar==d['active_residuals_over_RT'] and max(map(abs,ar))<=1e-7 and abs(dc)<=1e-7)
check('G_descent_gate',Gs['final']<=Gs['initial']+F(rt)*B*F(1,10**7))
h=sum((a*F(x) for a,x in zip(n,result['final']['standard_h_j_mol'])),F())
check('nominal_H_S_G_identity',h==d['mixture_enthalpy_j'] and (h-Gs['final'])/1000==d['mixture_entropy_j_k'])
property_rows=[]
keys=[('standard_cp_j_mol_k','cp_over_R',False),('standard_h_j_mol','h_over_RT',True),('standard_s_j_mol_k','s_over_R',False),('standard_g_j_mol','g_over_RT',True)]
check('reference_identity_and_order',hashed(W/'source-reference/REFERENCE.json')=='388caee3d17027f64a4ced9bef56d3bb50760daaf28bf4e5d29d928e70c3047d' and [x['species'] for x in reference['records']]==species)
for label in ['initial','final']:
    state=result[label]
    for i,ref in enumerate(reference['records']):
        p=next(p for p in ref['points'] if p['temperature_k']==1000)
        for key,rkey,timesT in keys:
            expected=float(p['binary64_coefficients'][rkey]['decimal_90_digits']);actual=state[key][i]/(state['gas_constant_j_mol_k']*(1000 if timesT else 1))
            diff=actual-expected;limit=2e-10+5e-12*abs(expected)
            property_rows.append({'snapshot':label,'species':species[i],'property':rkey,'actual':actual,'reference':expected,'difference':diff,'original_tolerance':limit,'passed':math.isfinite(diff) and abs(diff)<=limit})
check('all_152_independent_standard_comparisons',len(property_rows)==152 and all(x['passed'] for x in property_rows))
check('provider_identity_and_count',result['provider_identity']['kind']=='actual_cantera' and result['provider_identity']['version']=='3.2.0' and result['provider_identity']['gas_constant_j_mol_k']==8.31446261815324 and result['provider_calls_attempted']==result['provider_calls_completed']==3 and result['actual_source_properties_checked'] is True)
model=read(ROOT/'data/sandbox/research/tp-equilibrium-v1/model.json');source=read(ROOT/'data/sandbox/research/tp-equilibrium-v1/source.json')
check('saved_source_matches_fixed_pack',result['provenance']['model']==model and result['provenance']['source']==source and result['provenance']['model_sha256']==hashed(ROOT/'data/sandbox/research/tp-equilibrium-v1/model.json') and all(hashed(ROOT/'data/sandbox/research/tp-equilibrium-v1'/name)==expected for name,expected in model['files'].items()))
for label in ['initial','final']:
    loaded=result[label]['loaded_definition']['species']
    check(label+'_actual_loaded_19_definitions',len(loaded)==19 and all(x['name']==s['name'] and x['composition']==s['composition'] and x['reference_pressure_pa']==100000. and x['coefficients_high_then_low']==[s['thermo']['temperature-ranges'][1],*s['thermo']['data'][1],*s['thermo']['data'][0]] for x,s in zip(loaded,pack['species'])))
before={k:(v['sha256'] if isinstance(v,dict) else v) for k,v in meta['inputs_before'].items()};after={k:(v['sha256'] if isinstance(v,dict) else v) for k,v in status['inputs_after'].items()}
check('all_supervision_inputs_before_after',before==after and status['inputs_unchanged'] is True)
check('all_current_frozen_inputs',all(Path(p).is_file() and hashed(Path(p))==h for p,h in before.items()))
check('final_reviewed_module_and_CLI',before[str(ROOT/'src/sludge_sandbox/tp_equilibrium.py')]=='8f051abea50b4f21f9a12f92129f249967f591b5f2197760ed2f8015a7ce964f' and before[str(ROOT/'examples/sandbox/run_tp_equilibrium.py')]=='be1d1dd7ae2a93ffdd41dcda01dc0ac6bad40adad992786f98d42f16fec7dbac')
installed=read(W/'INSTALLED_IDENTITY02.json')
check('installed_187_180_and_15_tests',installed['package_files']==187 and installed['python_modules']==180 and installed['all_equal'] and all(hashed(Path(x['source']))==hashed(Path(x['installed']))==x['sha256'] for x in installed['files']) and installed['testsuites'][0]['tests']=='15' and installed['testsuites'][0]['failures']==installed['testsuites'][0]['errors']=='0')
check('supervisor_failed_reaped_and_original_budgets',status['status']=='failed' and status['returncode']==1 and status['cleanup']['leader_reaped'] and meta['timeout_s']==50 and meta['cleanup_grace_s']==5 and status['elapsed_s']<50 and result['elapsed_seconds']<10 and series['driver_elapsed_before_final_write_s']<40)
check('all_material_qualifications_false',result['material_qualified'] is False and result['training_eligible'] is False and record['qualification']['material_qualified'] is False and model['material_qualified'] is False and model['training_eligible'] is False)
output={'audit_verdict':'PASS' if all(x['passed'] for x in checks) else 'FAIL','native_verdict':'postcheck_failed','native_attempts':1,'unexecuted_planned_points':3,'eos_or_equilibrium_calls_by_audit':0,'checks':checks,'element_rows':element_rows,'independent_standard_properties':property_rows,'G':{'final_j':float(Gs['final']),'seed_j':float(Gs['initial']),'gap_out_j':float(gap),'scaled_gap_out':float(gap/(F(rt)*B)),'gap_requested_j':float(greq),'requested_pool_gap_correction_j':float(correction),'max_active_residual_over_RT':max(map(abs,ar))},'timings':{'solve_s':result['elapsed_seconds'],'driver_s':series['driver_elapsed_before_final_write_s'],'supervisor_s':status['elapsed_s']},'supervision_inputs':len(before),'point_sha256':hashed(point)}
with (R/'NATIVE01_AUDIT.json').open('x') as f:json.dump(wire(output),f,indent=2,allow_nan=False)
print(output['audit_verdict'],len(checks),'group checks;',len(property_rows),'property comparisons;',len(before),'inputs')
for row in element_rows:
 if row['snapshot']=='final': print(row['element'],row['residual_float_mol'],row['tolerance_float_mol'],row['abs_residual_over_tolerance'],row['original_gate_passed'])
print(output['G']);print([x for x in checks if not x['passed']])
raise SystemExit(0 if output['audit_verdict']=='PASS' else 1)
