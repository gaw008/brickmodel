"""Manufactured completed property read; zero native objects or EOS."""
from types import SimpleNamespace
import pytest
from sludge_sandbox.tp_equilibrium import _CanteraBackend


def test_completed_property_survives_later_readback_failure():
    class Phase:
        def __init__(self, count):
            self.count = count
        @property
        def standard_enthalpies_RT(self):
            return [2.] * self.count
        @property
        def standard_entropies_R(self):
            raise RuntimeError('manufactured_entropy_read_failure')
    backend = object.__new__(_CanteraBackend)
    backend.ct = SimpleNamespace(gas_constant=8000.)
    backend.gas, backend.carbon = Phase(18), Phase(1)
    backend.partial, backend.loaded = {}, {'marker': 'manufactured_loaded'}
    backend.mix = SimpleNamespace(T=1000., P=100000., species_moles=[.001]+[0.]*17+[.001],
        phase=lambda i: (backend.gas, backend.carbon)[i])
    with pytest.raises(RuntimeError, match='manufactured_entropy_read_failure'):
        backend.snapshot()
    saved = backend.partial.get('partial_snapshot', {})
    assert saved.get('standard_h_j_mol') == (16000.,) * 19, backend.partial
    assert 'standard_s_j_mol_k' not in saved
    assert saved['amounts_kmol'] == (.001,) + (0.,) * 17 + (.001,)
