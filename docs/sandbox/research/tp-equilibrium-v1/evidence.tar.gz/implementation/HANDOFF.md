# TP 实现交接（尚未实际构相或求平衡）

2026-09-12；候选字节见 CANDIDATE01.json。正式模块、测试、中文示例和来源包已落盘；未安装项目、未改旧物性/旧环境、未执行真实 Cantera Solution/Mixture/equilibrate。13 项作者测试仅使用数学构造或窄 fake backend，0.13 s；AUTHOR_RED01 为真实缺模块 RED，AUTHOR_GREEN01 为首 7 项，AUTHOR_GREEN02.log/xml 为当前 13 项。AST 解析通过；ruff/mypy/pylint/black 不可用，见 STATIC_TOOLS01.json。git diff --check 无输出。

## 调用

```python
from fractions import Fraction as F
from sludge_sandbox.tp_equilibrium import TPPool, TPPolicy, solve_tp
pool = TPPool(1000., 100000., (F(1), F('1.6'), F('.6'), F('.1'), F('.01')),
              'virtual_CHONS_C1_mol', 'virtual_design_choice', ('virtual:CHONS_C1_mol',))
result = solve_tp(pool, source_root, policy=TPPolicy(), seed_variant='element_basis')
```

另一个初猜仅设 seed_variant='methane_shift'；精确转移 0.1 mol C + 0.2 mol H2 → 0.1 mol CH4，不改变元素池。若池不足拒绝。构造器元素顺序固定 C/H/O/N/S、mol 原子；温度 800–1200 K、压力只准 100000 Pa。示例运行方法见 data/sandbox/research/tp-equilibrium-v1/README.md。CLI 要求每个元素显式输入、basis-id、source-root 和全新 output，入口先保存原输入。

## 返回和预算

三公开 dataclass：TPPool、TPPolicy、TPResult。后者嵌套 Mapping/tuple 复制为只读，包含 initial/final/seed/provenance/diagnostics/failure/provider_identity。状态 completed/construction_failed/solve_failed/postcheck_failed/resource_limit。构造、准备、求解共三个 wrapper 返回边界；provider_calls_attempted/completed 记录这三个操作，不是底层 NASA 多项式调用总数。原生求解成功返回后 partial.native_equilibrium_returned=True，后续读取出错保留 raw_inventory 或失败读取原因。每次正常返回的对象先保留再查时钟；最终 elapsed 同一次采样判终态，超时不伪报 completed。in-flight 原生调用需 ROOT 外部监督，模块没有后台强杀。

policy 固定 gibbs，无自动选择/重试，rtol 默认1e-10、最多1000步、墙钟默认10秒。数值门和物理限定与冻结设计相同，实际 source property 检查独立用 NASA7 T<=1000 低段；额外只读实际 Cantera docstring 已核参数名与 standard_* 属性，没有创建相对象。

## 核查内容及范围

真实包核 model.json 固定 SHA，再核固定五个文件的真实字节；加载 derived.json 闭合19条记录，明确所有 reference-pressure=100000，派生 graphite 使用同一配置的 C(gr)。原件及 LICENSE 不变。实际后端再核已加载物种/元素/系数/温域/参考压力/相模型/石墨密度，记录实际 R/原子量。禁止跨文件物种导入/扩展/额外形成焓。

返回独立保存精确表示 n_mol=F(raw_kmol)*1000 与 A n，绝不归一化/裁负。G 只用当前 P 标准势加一次理想混合项；全结构候选 partition 检查，包括零 trace。元素势仅在正元素子空间做一次最小二乘诊断，不调整 n。gap_out 使用 b_out；gap_requested 与精确代数修正同时保存。输出限定混合物 H/S/G 不是实际原泥能量/反应热。所有成功仍 material_qualified=false、training_eligible=false；完整热化学/对数误差和省略相误差 unknown。

作者13项覆盖：解析等摩尔平衡；保元素但非平衡组成拒绝；两池 gap 残差恒等式；非法 T/P/库存；已返回后越时；求解失败和只读部分状态；当前P标准G不重复校压；零元素子空间；kmol下溢/源变更；1000K低段；CLI拒绝覆盖与构造失败的原输入保存。它们不证明真实 Cantera 后端或材料已通过。

## 并行边界

ROOT 拥有 uv.lock、非 editable 安装和原计划最多四次真实点。source_execution_review 已获源码候选、正在独审；当前不改候选字节，若出现明确问题再有限修复并保留原失败。来源包 README 不纳入物性 hash，但其引用模型和实际数值由 model/source/derived 的 hash 绑定。

## 独审后候选02（替代候选01）

最终源码 SHA 8f051abea50b4f21f9a12f92129f249967f591b5f2197760ed2f8015a7ce964f；测试5deff05176ec68f78c461552e6fc5f3fad9f685e0a9d35f4e3a4c41444a0e86b；CLI/source数据未改。完整列表 CANDIDATE02.json。候选01原码另存 CANDIDATE01.py.txt，原失败保留。

独审取得官方 v3.2.0 mixture.pyx：Python phase(n)仅返回对象。C++ setTemperature/setMoles 可已同步，所以不存在已证明的真实准备/物性失败；stale-phase 制造反例只证明 snapshot 自身没有兑现原同步注释。现防御性修正为先保存原始T/P/全部kmol，核有限/非负/正气池/原域，显式用gas.TPX和carbon.TP更新物性相；不裁剪、不把归一化比例写回绝对库存。原stale反例1failed保留，STALE_PHASE_GREEN01为同项1pass/0.08s。

另一真实制造反例：完整h向量返回后s读取失败，旧partial仅保留库存。现每个完整向量立即复制进partial_snapshot；native本体失败可尝试读回失败状态，但native已经返回后的snapshot读取失败不重试，不覆盖真实已完成前缀。review/PARTIAL_RED01与独立PARTIAL_GREEN01保留。作者AUTHOR_GREEN03为当时14正式+独立partial1，共15pass/0.14s；再新增正式wrapper前缀/不重复读取回归，PARTIAL_WRAPPER_GREEN01单项1pass/0.09s。正式测试现15项，其它既有行为未改。仍0作者真实构相/EOS/equilibrium调用；只有库导入及docstring读取。ROOT负责重装和原登记试验。
