# First restricted TP execution, four calls maximum

2026-09-12. Fixed source-preserving NASA1993_1BAR_EXPLICIT_REFERENCE_V1,
Cantera 3.2.0, fresh objects per solve, P = 100000 Pa, closed virtual atom pool
C/H/O/N/S = 1/1.6/.6/.1/.01 mol. This is not one kg of any sludge.

After source/code review and a noneditable install into the new isolated runtime,
invoke the actual Chinese example CLI in this order: 1000 K element_basis,
1000 K methane_shift, 800 K element_basis, 1200 K element_basis. At most one
attempt per listed point; no retry/fallback. Stop on a CLI failure, failed saved
property comparison, failed seed comparison or elapsed driver budget. Initial
and final snapshots must match the independent NASA7 mathematical reference.
The first two points must both pass before the temperature endpoints are run.

Retain module policy: gibbs, rtol 1e-10, maximum 1000 steps, max_iter 100,
10 s per wrapper solve. Driver 40 s; existing external supervisor 50 s plus
5 s cleanup. These are resource policies, not physical times or hard kernel
deadlines. Timing checks are at return boundaries; the supervisor handles a
nonreturning native process. All point files are unique and retained on failure.

Keep all original module posterior gates. Additional predeclared numerical
cross-check: each dimensionless standard Cp/R, h/RT, s/R, g/RT compared with the
independent exact-binary64-coefficient mathematical reference at the requested
T must differ by <= 2e-10 + 5e-12*abs(reference). This deliberately exceeds
ordinary arithmetic rounding at these modest polynomial magnitudes, is much
smaller than the 1atm/1bar error, and is an arithmetic check, not a rigorous
roundoff bound or source-fit/material uncertainty. Low polynomial owns 1000 K;
do not compare with or average the high branch there. No mixing entropy goes
into standard-state comparisons. Module's own dimensional checks also remain.

The two 1000 K inventories must agree species by species within
1e-8 mol + 1e-7*max(n_A,n_B). Their saved G values must agree within
1e-7*R*T*(1+1.6+.6+.1+.01). Compare all 19 species, no expected graphite-yield
gate. Exact returned inventories and element residuals remain in each result.
Successful execution only supports this restricted virtual CHONS calculation.
Source fit, omitted phases, real char/mineral allocation, feed H/heat duty,
finite kinetics and real sludge validation remain unknown.

Freeze the installed project, Cantera/numpy runtime files, source pack, CLI,
reference, driver and this plan in the existing supervisor input observations.
Read back actual outcomes independently before publishing any acceptance.
