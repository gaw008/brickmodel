"""Actual driver loop/tail with narrow manufactured CLI; no Cantera import."""
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

DRIVER = Path('/private/tmp/sludge-tp-equilibrium-v1/root-execution/native_series.py')


def setup_driver(tmp_path, *, late_write=False, missing_output=False):
    tree = ast.parse(DRIVER.read_text())
    selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('save', 'guard')]
    start = next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Expr) and
                 isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='save')
    tail = tree.body[start:]
    clock=[0.]
    out=tmp_path/'output'
    out.mkdir()
    summary={'status':'started','points':[],'seed_comparison':None,
             'driver_budget_s':40,'max_equilibrium_calls':4}
    calls=[]
    def main(argv):
        calls.append(tuple(argv))
        if missing_output:
            return 2
        path=Path(argv[argv.index('--output')+1])
        path.write_text(json.dumps({'status':'completed','result':{'actual_source_properties_checked':True}}))
        return 0
    namespace={'summary':summary,'time':SimpleNamespace(monotonic=lambda:clock[0]),'STARTED':0.,
               'OUT':out,'ROOT':tmp_path,'entry':SimpleNamespace(main=main),'json':json,'hashlib':hashlib,
               'properties':lambda *a:[{'passed':True}],'seed_comparison':lambda *a:{'passed':True}}
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(DRIVER),'exec'),namespace)
    original_save=namespace['save']
    if late_write:
        def slow_save():
            original_save()
            if summary['status']=='completed':
                clock[0]=41.
        namespace['save']=slow_save
    error=None
    try:
        exec(compile(ast.Module(body=tail,type_ignores=[]),str(DRIVER),'exec'),namespace)
    except (SystemExit,TimeoutError) as exc:
        error=exc
    return json.loads((out/'SERIES.json').read_text()),error,calls


def test_final_write_deadline_does_not_leave_completed_record(tmp_path):
    saved,error,calls=setup_driver(tmp_path,late_write=True)
    assert len(calls)==4
    assert saved['status'] != 'completed', 'actual final write crossed40s but saved series still completed'


def test_returned_cli_code_survives_missing_output(tmp_path):
    saved,error,calls=setup_driver(tmp_path,missing_output=True)
    assert len(calls)==1
    assert saved['status']=='failed'
    assert saved['points'] and saved['points'][0]['exit_code']==2, 'actual returned CLIcode discarded before output read'
