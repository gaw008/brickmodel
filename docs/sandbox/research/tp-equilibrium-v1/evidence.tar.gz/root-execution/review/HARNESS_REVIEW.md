# Thin harness independent review

2026-09-12. **APPROVE exact bytes listed below for the planned four-call experiment.** No phase, EOS, equilibrium or native series was executed by this review. Production solver review remains separate.

## Scope and mathematical correspondence

Read PLAN.md, native_series.py and launch.py, the existing supervisor relevant completion/cleanup clauses, and the saved independent mathematical reference plus its generator. Reference order is exactly the fixed 18 gas species followed by C(gr). The dimensional-to-dimensionless divisors R and RT correspond to Cp/R, s/R and h/RT, g/RT; standard quantities do not receive mixing entropy. Both initial/final snapshots are compared at requested T. Reference 1000 K uses the low branch. Its precise coefficients, scalar dimensions and explicit 1bar source branch match the current model; this comparison is a numerical arithmetic gate, not a material error interval.

The loop contains exactly four ordered calls. Each actual public CLI creates its own solver backend, and the loop contains no retry/fallback. A failed first/second point, source-properties flag, any independent property gate or 1000 K same-pool comparison prevents endpoints. Species comparison uses all19 with strict zip. G comparison uses 1e-7 R(1000 K)(3.31 mol atoms), correctly summing1+1.6+.6+.1+.01. Exact source inventory/element/G checks remain in each result; no mixture is inferred to be one kg of sludge.

The launch uses the isolated interpreter with -I and PYTHONPATH removed, refuses prior native/supervisor output directories, and delegates to the existing50s+5s process supervisor. That supervisor only completes after leader reap and successful group-cleanup checks; before/after input hashes cover declared project/source/runtime/CLI/reference/harness files. Noneditable install and installed/repository correspondence are ROOT's separate pre-execution admission, not established by this mock review.

## Actual findings and closure

Two MEDIUM findings were reproduced against the original real driver loop/tail via AST with a narrow manufactured entry callback:

1. All four callbacks returned normally, but final write moved the clock to41s; SERIES.json still said completed while the following uncaught guard failed.
2. A callback returned code2 without creating output; reading the missing file happened before recording code, leaving points=[] and losing the completed callback fact.

BOUNDARY_RED01.log/xml preserves2 actual failures in0.03s. ROOT added returned-code prefix storage before output reading, explicit read-failure fields, and consistent terminal elapsed classification with a second persisted resource_limit record if the final write itself crosses40s. The exact same2 affected probes now pass: BOUNDARY_GREEN01.log/xml,2 passed. No physical or numerical thresholds changed. Source module candidates were untouched.

No remaining definite CRITICAL/HIGH/MEDIUM issue found in this bounded harness scope. Runtime/operating-system interruption and storage I/O can still prevent complete saving; neither the plan nor this approval establishes an uninterruptible logging guarantee or physical validation.

## Frozen SHA256

- PLAN.md: `a184c6a8779f6cfa8c199d37c1dbd032ebe27d7663c1c57db2d378a8d282be36`
- native_series.py: `d1359ed480aece9e674a681a70349f446ba36f5a65207aba97dfa949618195be`
- launch.py: `34c6cb3083d1251b1054dfe698100cc65b7bcc1da3d217f267c497e32fd783f2`
