from pathlib import Path
p=Path(__file__).with_name('depletion_integration.py');s=p.read_text()
s=s.replace('    terminal_evidence: object = None','    terminal_evidence: object = None\n    stretch_difference: float | None = None')
s=s.replace("    if initial.mechanical_stretches is not None:\n        raise DepletionIntegrationError('mechanical_depletion_integration_not_implemented')", """    mechanical=initial.mechanical_stretches is not None
    if mechanical:
        _number(integration_policy.stretch_absolute_tolerance,True)
        _number(integration_policy.stretch_scale,True)""")
s=s.replace('    evaluations=rejected=attempted=0','''    cumulative_stretch=([Fraction() for _ in initial.mechanical_stretches] if mechanical else [])
    cumulative_stretch_exact=list(cumulative_stretch)
    cumulative_stretch_roundoff=list(cumulative_stretch)
    evaluations=rejected=attempted=0''')
# Small exact panel helper; used by both terminal methods and predictor.
pos=s.index('    def affine_terminal(')
s=s[:pos]+'''    def mechanical_panel(state,first,h,second=None,hm=None):
        if not mechanical:return None,None,None
        values=first.mechanical_rates_per_s
        other=values if second is None else second.mechanical_rates_per_s
        if values is None or other is None or values.shape!=state.mechanical_stretches.shape or other.shape!=values.shape:
            raise DepletionIntegrationError('mechanical_panel_rate_shape')
        exact=[];after=[]
        for before,a,b in zip(state.mechanical_stretches,values,other):
            a=Fraction(float(a));slope=Fraction() if second is None else (Fraction(float(b))-a)/(2*hm)
            value=Fraction(float(before))
            if _quadratic_inventory_minimum(value,a,slope,h)<=0:
                raise _Failure('unsupported','mechanical_panel_nonpositive_path')
            integral=h*a+h*h*slope
            represented=float(integral)
            if not math.isfinite(represented) or (integral and represented==0):
                raise DepletionIntegrationError('unrepresentable_mechanical_panel_increment')
            result=float(value+Fraction(represented))
            if not math.isfinite(result) or result<=0:
                raise _Failure('unsupported','mechanical_panel_nonpositive_endpoint')
            exact.append(integral);after.append(result)
        increments=np.array([float(v) for v in exact])
        rounding=tuple(Fraction(float(v))-q for v,q in zip(increments,exact))
        return np.array(after),increments,rounding

'''+s[pos:]
s=s.replace('        def advance(fields):','        def advance(fields,stretches):')
s=s.replace('return ConservedState(amounts,energy,energy_model_identity=state.energy_model_identity)','return ConservedState(amounts,energy,energy_model_identity=state.energy_model_identity,\n                                  mechanical_stretches=stretches)')
s=s.replace('        predictor=advance(integrate_fields(hm))','        predicted_stretches,_,_=mechanical_panel(state,obs.rates,hm)\n        predictor=advance(integrate_fields(hm),predicted_stretches)')
s=s.replace('        fields=integrate_fields(h,middle);raw=advance(fields);fn,fu,rn,work=fields','''        stretches,stretch_increment,stretch_rounding=mechanical_panel(state,obs.rates,h,middle.rates,hm)
        fields=integrate_fields(h,middle);raw=advance(fields,stretches);fn,fu,rn,work=fields''')
s=s.replace('panel=StepLedger(t,endpoint,*fields,components,rounding)','panel=StepLedger(t,endpoint,*fields,components,rounding,\n            stretch_increment=stretch_increment,stretch_quadrature_roundoff=stretch_rounding)')
s=s.replace('        raw=ConservedState(amounts,energy,energy_model_identity=state.energy_model_identity);record=None','''        stretches,stretch_increment,stretch_rounding=mechanical_panel(state,obs.rates,interval)
        raw=ConservedState(amounts,energy,energy_model_identity=state.energy_model_identity,
                           mechanical_stretches=stretches);record=None''')
s=s.replace('        def difference_record(x,y):','''        ds=None
        if mechanical:
            ds=max(delta(a.event_state.mechanical_stretches,b.event_state.mechanical_stretches),
                   delta(a.states[-1].mechanical_stretches,b.states[-1].mechanical_stretches))
            passed=passed and math.isfinite(ds) and ds<=policy.stretch_absolute_tolerance
        def difference_record(x,y):''')
s=s.replace('        return passed,(dtime,dn,du,dt,dp),details','''        if mechanical:
            details=MappingProxyType(dict(details,
                event_stretches=difference_record(a.event_state.mechanical_stretches,b.event_state.mechanical_stretches),
                common_stretches=difference_record(a.states[-1].mechanical_stretches,b.states[-1].mechanical_stretches)))
        return passed,((dtime,dn,du,dt,dp,ds) if mechanical else (dtime,dn,du,dt,dp)),details''')
s=s.replace('        nonlocal cumulative_n,cumulative_u,totals,operator,component_residual_totals','''        nonlocal cumulative_n,cumulative_u,totals,operator,component_residual_totals
        nonlocal cumulative_stretch,cumulative_stretch_exact,cumulative_stretch_roundoff''')
s=s.replace('        for j,step in enumerate(path.steps):','''        cs=list(cumulative_stretch);ce=list(cumulative_stretch_exact);cr=list(cumulative_stretch_roundoff)
        for j,step in enumerate(path.steps):''')
s=s.replace('            after=path.states[j+1]','''            after=path.states[j+1]
            before=path.states[j]
            if (after.energy_model_identity!=energy_binding or before.energy_model_identity!=energy_binding
                    or (after.mechanical_stretches is not None)!=mechanical):
                raise DepletionIntegrationError('mechanical_prefix_binding_changed')
            if mechanical:
                inc=step.stretch_increment;rounding=step.stretch_quadrature_roundoff
                if (inc is None or rounding is None or inc.shape!=initial.mechanical_stretches.shape
                        or len(rounding)!=len(inc) or before.mechanical_stretches is None):
                    raise DepletionIntegrationError('complete_mechanical_prefix_ledger_required')
                tol=Fraction(policy.stretch_absolute_tolerance)
                for i,(v,q) in enumerate(zip(inc,rounding)):
                    represented=Fraction(float(v));exact=represented-q
                    cs[i]+=represented;ce[i]+=exact;cr[i]+=abs(q)
                    local=Fraction(float(after.mechanical_stretches[i]))-Fraction(float(before.mechanical_stretches[i]))
                    change=Fraction(float(after.mechanical_stretches[i]))-Fraction(float(initial.mechanical_stretches[i]))
                    if (abs(local-represented)>tol or abs(local-exact)>tol or
                            abs(change-cs[i])>tol or abs(change-ce[i])>tol or cr[i]>tol):
                        raise _Failure('failed','cross_segment_stretch_prefix_roundoff')''')
s=s.replace('        cumulative_n=cn;cumulative_u=cu;component_residual_totals=component_totals','''        cumulative_n=cn;cumulative_u=cu;component_residual_totals=component_totals
        cumulative_stretch=cs;cumulative_stretch_exact=ce;cumulative_stretch_roundoff=cr''')
s=s.replace('common_pressure_difference_pa=diffs[4])','common_pressure_difference_pa=diffs[4],\n                                    stretch_difference=diffs[5] if mechanical else None)')
p.write_text(s)
