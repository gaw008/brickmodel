import importlib.util
from pathlib import Path
import sys
import math
from dataclasses import replace
from fractions import Fraction as F
import numpy as np
import pytest
from sludge_sandbox.integration import ConservedState,Rates
from test_depletion_integration import policies

spec=importlib.util.spec_from_file_location('sludge_sandbox._mechanical_candidate',Path(__file__).with_name('depletion_integration.py'))
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)


def fixture(method='euler',missing=False):
    p,e=policies()
    p=replace(p,relative_tolerance=1e-11,stretch_absolute_tolerance=1e-9,stretch_scale=1.,maximum_wall_seconds=10.)
    e=m.DepletionPolicy(**{k:v for k,v in vars(e).items() if k!='terminal_method'},terminal_method=method)
    def callback(state,t,modes):
        n=state.mechanical_stretches[0]
        sink=.001 if modes[0]=='existing_liquid' else 0.
        rates=Rates(np.zeros((2,2)),np.zeros(2),[[-sink,sink]],[n],
                    mechanical_rates_per_s=None if missing else [n,.2])
        return m.DepletionEvaluation(rates,(sink,),(300.,),(0.,),(0.,),(0.,))
    op=m.ManufacturedDepletionAdapter(evaluate_callback=callback,liquid_index=0,water_vapor_index=1,
        interfaces=('existing_liquid',),program_knots_s=(),source_ids=('manufactured:mechanical-depletion',))
    initial=ConservedState([[1e-4,0.]],[600.],mechanical_stretches=[1.,1.])
    return p,e,op,initial


@pytest.mark.parametrize('method',['euler','affine_midpoint'])
def test_real_mechanical_event_and_original_prefix(method):
    p,e,op,initial=fixture(method)
    run=m.integrate_depletion(initial,op,start_s=0.,end_s=.2,integration_policy=p,event_policy=e)
    assert run.status=='completed',run.reason
    assert len(run.events)==1 and run.states[-1].amounts_mol[0,0]==0.
    assert abs(run.events[0].time_s-.1)<1e-8
    total=[F(),F()];exact=[F(),F()];rounding=[F(),F()]
    for step,t,state in zip(run.steps,run.times_s[1:],run.states[1:]):
        assert abs(state.mechanical_stretches[0]-math.exp(t))<1e-8
        assert abs(state.mechanical_stretches[1]-(1+.2*t))<1e-10
        assert abs(state.internal_energy_j[0]-(599.+math.exp(t)))<1e-8
        for i in range(2):
            inc=F(float(step.stretch_increment[i]));q=step.stretch_quadrature_roundoff[i]
            total[i]+=inc;exact[i]+=inc-q;rounding[i]+=abs(q)
            change=F(float(state.mechanical_stretches[i]))-F(1.)
            assert abs(change-total[i])<=F(p.stretch_absolute_tolerance)
            assert abs(change-exact[i])<=F(p.stretch_absolute_tolerance)
            assert rounding[i]<=F(p.stretch_absolute_tolerance)
    assert run.events[0].terminal_panel.stretch_increment is not None


def test_missing_rates_fails_without_commit():
    p,e,op,initial=fixture(missing=True)
    run=m.integrate_depletion(initial,op,start_s=0.,end_s=.2,integration_policy=p,event_policy=e)
    assert run.status!='completed' and run.states==(initial,) and not run.steps


def test_cancel_keeps_actual_mechanical_initial():
    p,e,op,initial=fixture()
    run=m.integrate_depletion(initial,op,start_s=0.,end_s=.2,integration_policy=p,event_policy=e,cancel=lambda:True)
    assert run.status=='cancelled' and run.states==(initial,) and not run.events
