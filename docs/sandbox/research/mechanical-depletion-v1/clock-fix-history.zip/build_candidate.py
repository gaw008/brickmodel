from pathlib import Path
import difflib,hashlib,json
out=Path('/private/tmp/brick-free-depletion-clock');source=Path('src/sludge_sandbox/depletion_integration.py').read_text()
old="""            extend(path,normal(path.op,current,at,min(tc,at+desired),policy.maximum_step_s,
"""
new="""            finish=min(tc,at+desired)
            # Choose the named common endpoint directly when its entire exact
            # interval fits both limits; subtract/add can leave a one-ULP tail.
            remaining=Fraction(tc)-Fraction(at)
            safe_duration=Fraction(ep.safe_inventory_fraction)*other[0] if other else None
            if (remaining<=Fraction(policy.maximum_step_s) and
                    (safe_duration is None or remaining<=safe_duration)):
                finish=tc
            extend(path,normal(path.op,current,at,finish,policy.maximum_step_s,
"""
assert source.count(old)==1
candidate=source.replace(old,new)
(out/'before.py').write_text(source);(out/'candidate.py').write_text(candidate)
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='a/src/sludge_sandbox/depletion_integration.py',tofile='b/src/sludge_sandbox/depletion_integration.py')))
(out/'SOURCE_BINDING.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest()},indent=2))
