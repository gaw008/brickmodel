"""No EOS: isolate outer dry-continuation endpoint arithmetic using a nearby clock.
The failing real level-2 event time was not saved; this is an illustrative
neighbor of the saved level-1 time, not reconstruction of that unknown value.
"""
from dataclasses import replace
from fractions import Fraction
import json,math
from sludge_sandbox.integration import ConservedState,Rates,IntegrationPolicy,integrate
start=3.041741714178811e-05
end=1e-4
state=ConservedState([[1.]],[1.],mechanical_stretches=[1.,1.])
policy=IntegrationPolicy(1e-4,1e-4,1e-14,1e-7,1e-12,1e-6,1e-4,1.,2000,100,5.,1e-9,1.)
def operator(state,t):
 return Rates([[0.],[0.]],[0.,0.],[[0.]],[0.],mechanical_rates_per_s=[0.,0.])
runs=[];at=start
for _ in range(2):
 desired=min(policy.maximum_step_s,end-at,policy.maximum_step_s)
 finish=min(end,at+desired)
 bounded=max(policy.minimum_step_s,min(policy.maximum_step_s,finish-at))
 run=integrate(state,operator,start_s=at,end_s=finish,policy=replace(policy,initial_step_s=bounded,maximum_step_s=bounded))
 runs.append({'start':at,'finish':finish,'times':run.times_s,'status':run.status,'reason':run.reason,'evaluations':run.evaluations,'panels':len(run.steps)})
 if run.status!='completed':break
 at=run.times_s[-1];state=run.states[-1]
assert runs[0]['status']=='completed' and runs[0]['finish']==math.nextafter(end,-math.inf)
assert runs[1]['reason']=='unresolvable_stage_time'
# Use exact endpoint only when it fits the exact declared maximum duration.
assert Fraction(end)-Fraction(start)<=Fraction(policy.maximum_step_s)
whole=integrate(state,operator,start_s=start,end_s=end,policy=replace(policy,initial_step_s=end-start,maximum_step_s=end-start))
assert whole.status=='completed' and whole.times_s[-1]==end
print(json.dumps({'qualification':'pure-clock-neighbor-reproduction-not-real-EOS-event-reconstruction','runs':runs,'direct_endpoint_status':whole.status},indent=2))
