import importlib.util,sys,json
from pathlib import Path
from dataclasses import replace
from fractions import Fraction as F
import numpy as np
from sludge_sandbox.integration import ConservedState,Rates
from test_depletion_integration import policies
base=Path(__file__).parent

def load(name):
 spec=importlib.util.spec_from_file_location('sludge_sandbox._clock_'+name,base/(name+'.py'));m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m

def run(m,method='euler',second=False,cap=1e-4):
 p,e=policies();p=replace(p,initial_step_s=cap,maximum_step_s=cap,maximum_wall_seconds=5.,stretch_absolute_tolerance=1e-9,stretch_scale=1.)
 e=m.DepletionPolicy(**(vars(e)|{'terminal_method':method,'terminal_window_s':4e-5,'common_time_horizon_s':1e-4,'time_absolute_s':1e-10}))
 cells=2 if second else 1
 def callback(s,t,modes):
  sinks=[1. if mode=='existing_liquid' else 0. for mode in modes]
  return m.DepletionEvaluation(Rates(np.zeros((cells+1,2)),np.zeros(cells+1),[[-x,x] for x in sinks],np.ones(cells),mechanical_rates_per_s=np.ones(cells+1)*.1),tuple(sinks),(300.,)*cells,(0.,)*cells,(0.,)*cells,(0.,)*cells)
 op=m.ManufacturedDepletionAdapter(evaluate_callback=callback,liquid_index=0,water_vapor_index=1,interfaces=('existing_liquid',)*cells,program_knots_s=(),source_ids=('manufactured:clock-reproduction',))
 rows=[[3.041741714178811e-05,0.]]+([[.0002,0.]] if second else [])
 initial=ConservedState(rows,[1.]*cells,mechanical_stretches=[1.]*(cells+1))
 result=m.integrate_depletion(initial,op,start_s=0.,end_s=1e-4,integration_policy=p,event_policy=e)
 return result,p,e
reports={}
for name in ('before','candidate'):
 m=load(name);r,p,e=run(m)
 reports[name]={'status':r.status,'reason':r.reason,'events':len(r.events),'steps':len(r.steps),'refinements':[x.status for x in r.refinements]}
 assert (r.status=='completed')==(name=='candidate'),reports
 if name=='candidate':
  assert len(r.events)==1 and r.times_s[-1]==1e-4
  for step,s in zip(r.steps,r.states[1:]):
   assert abs(F(float(s.internal_energy_j[0]))-F(1)-F(step.end_s))<F(1e-12)
   assert abs(F(float(s.mechanical_stretches[0]))-F(1)-F(.1)*F(step.end_s))<F(1e-9)
  for method,second,cap in [('affine_midpoint',False,1e-4),('euler',True,1e-4),('euler',False,1e-5)]:
   r,p,e=run(m,method,second,cap);assert r.status=='completed',(method,second,cap,r.reason)
   assert len(r.events)==1 and r.times_s[-1]==1e-4
   if second:
    event=r.events[0]
    dry_steps=[s for s in r.steps if s.start_s>=event.time_s]
    first=dry_steps[0]
    assert F(first.end_s)-F(first.start_s)<=F(e.safe_inventory_fraction)*(F(.0002)-F(first.start_s))
    assert len(dry_steps)>=2
   reports[str((method,second,cap))]={'status':r.status,'events':len(r.events),'steps':len(r.steps)}
(base/'verification.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(reports,indent=2))
