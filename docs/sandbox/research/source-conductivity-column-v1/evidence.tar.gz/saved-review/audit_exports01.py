"""Passive six-row export correspondence only; no application imports."""
from pathlib import Path
from fractions import Fraction as F
import csv
import hashlib
import json
import time
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK=Path('/private/tmp/sludge-sourced-conductivity-v1')
OUT=WORK/'saved-review'
start=time.monotonic();checks=[];inputs={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 inputs[str(p)]=sha(p)
 return json.loads(p.read_bytes())
def f(v):return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)
def check(k,v):checks.append({'id':k,'passed':bool(v)})
def nominal(w):return float(F('.056')+F('.006')*(F(w)-F(23,77))/(F(47,53)-F(23,77)))
r=read(WORK/'native01/RUN.json');initial=read(WORK/'native01/INITIAL.json');d=read(WORK/'DERIVED_SUMMARY.json')
main=read(OUT/'SAVED_REVIEW02.json');s=main['summary']
p=ROOT/'docs/sandbox/research/source-conductivity-column-v1/TRACE.csv';inputs[str(p)]=sha(p)
with p.open() as stream: rows=list(csv.DictReader(stream))
check('csv/six_rows',len(rows)==6)
columns=['time_s','cell','temperature_k','pressure_pa','moisture_kg_water_per_kg_dry','conductivity_w_m_k','condensed_water_mol','vapor_water_mol','total_internal_energy_j']
check('csv/columns',list(rows[0])==columns)
index=0
for n,states in enumerate(r['states']):
 points=initial['points'] if n==0 else [c['inverse']['point'] for c in r['observations'][n-1]['cells']]
 for i,(state,p) in enumerate(zip(states,points)):
  mech=p['fluid']['mechanical'];w=p['moisture_kg_water_per_kg_dry'];k=nominal(w)
  values=[float(f(r['times_s'][n])),i,mech['temperature_k'],mech['pressure_pa'],w,k,state['liquid_water_mol'],state['gas_amounts_mol'][2],state['internal_energy_j']]
  for column,value in zip(columns,values):check(f'csv/row{index}/{column}',float(rows[index][column])==value)
  if n:check(f'csv/row{index}/actual_provider_k',k==r['observations'][n-1]['conductivity_points'][i]['k_w_m_k'])
  index+=1
expected={'checks':149,'max_inverse_energy_plus_error_j':s['max_accepted_inverse_U_plus_error_j'],
 'max_inverse_temperature_bound_k':s['max_accepted_inverse_T_bound_k'],'energy_roundoff_used_j':s['energy_roundoff_used_j'],
 'inventory_roundoff_used_mol':s['inventory_roundoff_used_mol'],'temperature_changes_k':s['delta_temperature_k'],
 'initial_conductivity_w_m_k':[nominal(p['moisture_kg_water_per_kg_dry']) for p in initial['points']],
 'final_conductivity_w_m_k':s['final_k_w_m_k'],'middle_conduction_w':[v['Q'] for v in s['middle_thermal']],
 'max_conduction_arithmetic_residual_w':max(abs(v['Q_arithmetic_residual_w']) for v in s['middle_thermal'])}
check('derived/field_set',set(d)==set(expected))
for k,v in expected.items():check('derived/'+k,d[k]==v)
for p,digest in main['inputs'].items():check('main_inputs_still_unchanged/'+p,sha(Path(p))==digest)
report={'passed':all(c['passed'] for c in checks),'check_count':len(checks),'failed_count':sum(not c['passed'] for c in checks),
 'elapsed_seconds':time.monotonic()-start,'csv_rows':6,'csv_numeric_values':54,'accepted_provider_points_checked':4,
 'initial_k_scope':'initial k is passively derived from original printed source nodes and saved W; no initial operator rerun',
 'checks':checks,'inputs':inputs,'script_sha256':sha(Path(__file__))}
with (OUT/'EXPORT_REVIEW01.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('checks','inputs')},indent=2))
for c in checks:
 if not c['passed']:print('FAILED',c['id'])
raise SystemExit(0 if report['passed'] else 1)
