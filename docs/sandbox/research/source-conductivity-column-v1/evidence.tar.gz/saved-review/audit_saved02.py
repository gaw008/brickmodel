"""One-case passive JSON/Fraction audit; never imports application or calls EOS."""
from fractions import Fraction as F
from pathlib import Path
import csv
import hashlib
import json
import math
import time
import traceback
import xml.etree.ElementTree as ET

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK=Path('/private/tmp/sludge-sourced-conductivity-v1')
OUT=WORK/'saved-review'
START=time.monotonic()
CHECKS=[]
RECOMPUTED={}
INPUTS={}

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def hook(v):
    if set(v)=={'numerator','denominator'} and type(v['numerator']) is int and type(v['denominator']) is int:
        return F(v['numerator'],v['denominator'])
    return v

def read(path):
    path=Path(path); INPUTS[str(path)]=sha(path)
    return json.loads(path.read_bytes(),object_hook=hook)

def check(label,condition):
    CHECKS.append({'id':label,'passed':bool(condition)})

def original(label,condition):
    if label in RECOMPUTED: raise ValueError('duplicate original check '+label)
    RECOMPUTED[label]=bool(condition)
    check('original/'+label,condition)

def T(p): return p['fluid']['mechanical']['temperature_k']
def P(p): return p['fluid']['mechanical']['pressure_pa']
def total(states,kind):
    if kind=='U': return sum((F(s['internal_energy_j']) for s in states),F())
    if kind=='W': return sum((F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]) for s in states),F())
    return sum((F(s['gas_amounts_mol'][kind]) for s in states),F())
def default(value):
    if isinstance(value,F): return {'numerator':value.numerator,'denominator':value.denominator}
    raise TypeError(type(value).__name__)

SUMMARY={}
try:
    a=read(WORK/'native01/ACCEPTANCE.json'); run=read(WORK/'native01/RUN.json')
    ini=read(WORK/'native01/INITIAL.json'); prefix=read(WORK/'native01/CONSTRUCTION_PREFIX.json')
    meta=read(WORK/'supervised-native01/metadata.json'); status=read(WORK/'supervised-native01/status.json')
    freeze=read(WORK/'install/SOURCE_FREEZE.json')['files']
    facts=read(ROOT/'data/sandbox/research/septien-conductivity-v1/source.json')
    model=read(ROOT/'data/sandbox/research/septien-conductivity-v1/model.json')
    prov=ini['provenance']; initial=ini['states']; thermal=prov['thermal_provider']
    m=prov['cells'][0]['wet_definition']['water']['molar_mass_kg_mol']
    source_ids=(facts['source_id'],model['model_id'],facts['primary_asset']['sha256'],
                sha(ROOT/'data/sandbox/research/septien-conductivity-v1/source.json'),
                sha(ROOT/'data/sandbox/research/septien-conductivity-v1/model.json'))
    provider_id=hashlib.sha256(json.dumps((*source_ids[1:2],*source_ids[2:],(.3,.8),(308.15,368.15)),separators=(',',':')).encode()).hexdigest()
    check('provider/model_identity',provider_id==thermal['model_identity'])
    check('provider/provenance_facts',thermal['source_facts']==facts and thermal['model_definition']==model)
    check('classification',facts['classification']=='measured_public_data' and model['classification']=='derived_from_evidence'
        and model['usage_scope']=='hybrid_exploratory_donor_transport' and prov['transport_classification']=='mixed_source_exploratory'
        and prov['remaining_transport_classification']=='manufactured_test_fixture')
    check('unknown_errors',all(model['uncertainty_policy'][key] is None for key in ('interpolated_conductivity_confidence_interval',
        'interpolation_model_error','temperature_extension_model_error','pressure_extension_model_error','cross_material_transfer_error','total_model_uncertainty')))
    check('false_qualifications',all(x['material_qualified'] is False and x['training_eligible'] is False for x in (facts,model,thermal)))
    check('initial/prefix',prefix=={'states':initial,'points':ini['points']} and run['states'][0]==initial)
    check('initial/geometry',prov['cell_widths_m']==[.02,.02] and prov['face_area_m2']==.001 and prov['boundary_conditions']==['closed_no_flux']*2)
    check('initial/registered_inventory',[(s['solid_mass_kg'],s['liquid_water_mol'],s['gas_amounts_mol'],T(p)) for s,p in zip(initial,ini['points'])]
        ==[([.01],.2,[.000048,.000181,.000001],330.),([.01],.225,[.000045,.000168,.000001],333.)])
    # Read the pinned original table independently, selecting rows and physical columns.
    xmlpath=ROOT/'runs/sandbox/source-cache/septien2020/fecal2019-original.xml'; raw=xmlpath.read_bytes(); INPUTS[str(xmlpath)]=sha(xmlpath)
    check('original_xml_identity',sha(xmlpath)==source_ids[2] and len(raw)==102289)
    article=ET.fromstring(raw); table=article.find(".//table-wrap[@id='tbl0010']")
    text=lambda el:' '.join(''.join(el.itertext()).split())
    headers=[]
    for h in table.findall('table/thead/tr')[0].findall('th'): headers += [text(h)]*int(h.get('colspan','1'))
    wi=headers.index('Moisture content(% wet basis)'); ki=headers.index('Thermal conductivity (W/m/K)')
    rows={text(row.findall('td')[0]):[text(x) for x in row.findall('td')] for row in table.findall('table/tbody/tr')}
    nodes=[]
    for n,fact in enumerate(facts['points']):
        row=rows[fact['row_label']]; wy,wyerr=map(F,row[wi].split(' ± ')); kval,kerr=map(F,row[ki].split(' ± '))
        nodes.append((wy/(100-wy),kval))
        check(f'source_node{n}',row[wi]==fact['moisture_wet_percent_original'] and row[ki]==fact['conductivity_w_m_k_original']
            and nodes[-1]==(F(fact['moisture_dry_basis']),F(fact['conductivity_w_m_k']))
            and (wyerr,kerr)==(F(fact['moisture_wet_percent_half_width']),F(fact['conductivity_w_m_k_half_width'])))
    check('source_nodes_printed',nodes==[(F(23,77),F('.056')),(F(47,53),F('.062'))])
    def nominal(w):
        return nodes[0][1]+(nodes[1][1]-nodes[0][1])*(F(w)-nodes[0][0])/(nodes[1][0]-nodes[0][0])
    def moisture(s): return float(F(s['liquid_water_mol'])*F(m)/F(s['solid_mass_kg'][0]))
    def audit_k(label,point,state):
        w=moisture(state); expected=nominal(w); trace=json.loads(point['_provenance_json'])
        check(label+'/W',point['moisture_kg_water_per_kg_dry']==w)
        check(label+'/k',point['nominal_k_w_m_k']==expected and point['k_w_m_k']==float(expected)
              and point['binary64_projection_error_w_m_k']==abs(F(point['k_w_m_k'])-expected))
        check(label+'/domain',F(.3)<=F(w)<=F(.8) and F(308.15)<=F(point['temperature_k'])<=F(368.15))
        check(label+'/source',point['source_ids']==list(source_ids) and point['model_identity']==provider_id
              and trace['source_facts']==facts and trace['model_definition']==model)
        check(label+'/exact_coordinates',trace['evaluation_coordinates_exact']=={
              'temperature_k':[F(point['temperature_k']).numerator,F(point['temperature_k']).denominator],
              'moisture_kg_water_per_kg_dry':[F(w).numerator,F(w).denominator]})
        check(label+'/qualification',point['material_qualified'] is False and point['training_eligible'] is False
              and point['source_confidence_intervals_are_total_model_bounds'] is False
              and all(point[k] is None for k in ('interpolation_model_error','temperature_extension_model_error',
                   'pressure_extension_model_error','cross_material_transfer_error','total_model_uncertainty')))
    original('completed',run['status']=='completed' and run['reason'] is None)
    original('counts',len(run['states'])==3 and len(run['ledgers'])==len(run['observations'])==2 and run['evaluations_attempted']==run['evaluations_completed']==6)
    original('clock',run['times_s']==[F(),F(.05)/2,F(.05)])
    original('identity',run['model_identity']==prov['model_identity'])
    original('false_material',run['material_qualified'] is False)
    original('roundoff_energy_budget',run['energy_roundoff_used_j']<=F(1e-8))
    original('roundoff_inventory_budget',run['inventory_roundoff_used_mol']<=F(1e-12))
    cumulative={key:F() for key in ('U','W',0,1)}
    u_limits=[];t_limits=[];middle=[];inventory_cost=F();energy_floor=F()
    for n,(old,new,ledger,obs) in enumerate(zip(run['states'],run['states'][1:],run['ledgers'],run['observations'])):
        tag=f'step{n}'; dt=ledger['duration_s']; faces=ledger['faces']; f=faces[1]; witness=f['conductivity_witness']; err=ledger['roundoff']
        original(tag+'_clock',dt==run['times_s'][n+1]-run['times_s'][n])
        original(tag+'_closed',all(ff['energy_j']==0 and all(v==0 for v in ff['gas_mol']) for ff in (faces[0],faces[-1])))
        original(tag+'_active_heat',f['conduction_j']!=0)
        original(tag+'_middle_Q',f['conduction_j']==dt*F(witness['conduction_w']))
        original(tag+'_thermal_entropy',witness['entropy_production_w_k']>0)
        pl,pr=witness['conductivity_points']; dl,dr=(v/2 for v in prov['cell_widths_m']); area=prov['face_area_m2']
        G=F(area)/(F(dl)/F(pl['k_w_m_k'])+F(dr)/F(pr['k_w_m_k']))
        exactQ=G*(F(pl['temperature_k'])-F(pr['temperature_k']))
        kernelQ=area*((pl['temperature_k']-pr['temperature_k'])/(dl/pl['k_w_m_k']+dr/pr['k_w_m_k']))
        entropy=F(witness['conduction_w'])*(1/F(pr['temperature_k'])-1/F(pl['temperature_k']))
        original(tag+'_G',witness['conductance_w_k']==float(G))
        original(tag+'_actual_shared_Q',witness['conduction_w']==kernelQ)
        original(tag+'_thermal_arithmetic',witness['conduction_arithmetic_residual_w']==F(witness['conduction_w'])-exactQ)
        original(tag+'_entropy_value',witness['entropy_production_w_k']==float(entropy))
        original(tag+'_source_registration',set(source_ids).issubset(obs['source_ids']))
        check(tag+'/witness_false',witness['material_qualified'] is False)
        middle.append({'step':n,'W':[pl['moisture_kg_water_per_kg_dry'],pr['moisture_kg_water_per_kg_dry']],
            'k':[pl['k_w_m_k'],pr['k_w_m_k']],'T':[pl['temperature_k'],pr['temperature_k']],
            'G':float(G),'Q':kernelQ,'Q_arithmetic_residual_w':float(F(kernelQ)-exactQ),'sigma':float(entropy)})
        for i,kpoint in enumerate(witness['conductivity_points']):
            w=moisture(ledger['midpoint_states'][i]); expected=nominal(w)
            original(tag+f'_middle_W{i}',kpoint['moisture_kg_water_per_kg_dry']==w)
            original(tag+f'_source_k{i}',kpoint['nominal_k_w_m_k']==expected and kpoint['k_w_m_k']==float(expected))
            original(tag+f'_middle_not_endpoint{i}',kpoint['k_w_m_k']!=obs['conductivity_points'][i]['k_w_m_k'])
            original(tag+f'_source_false{i}',kpoint['material_qualified'] is False and kpoint['training_eligible'] is False)
            audit_k(tag+f'/middle{i}',kpoint,ledger['midpoint_states'][i])
            audit_k(tag+f'/endpoint{i}',obs['conductivity_points'][i],new[i])
            check(tag+f'/endpoint_T{i}',obs['conductivity_points'][i]['temperature_k']==T(obs['cells'][i]['inverse']['point']))
        original(tag+'_active_gas',any(v!=0 for v in f['gas_mol']))
        original(tag+'_active_enthalpy',any(v!=0 for v in (*f['diffusive_enthalpy_j'],*f['advective_enthalpy_j'])))
        original(tag+'_active_phase',all(v!=0 for v in ledger['phase_water_mol']))
        for ff in faces:
            original(tag+f"_face{ff['face_id']}_energy",ff['energy_j']==ff['conduction_j']+sum(ff['diffusive_enthalpy_j'],F())+sum(ff['advective_enthalpy_j'],F())+ff['energy_decomposition_roundoff_j'])
        for i,(before,after,cell) in enumerate(zip(old,new,obs['cells'])):
            label=tag+f'_cell{i}'; left,right=faces[i:i+2]; inv=cell['inverse']; p=inv['point']; eq=cell['phase']['equilibrium']
            residual=F(p['total_internal_energy_j'])-F(after['internal_energy_j'])
            original(label+'_U_ledger',F(after['internal_energy_j'])-F(before['internal_energy_j'])==left['energy_j']-right['energy_j']+err['energy_j'][i])
            original(label+'_Nc_ledger',F(after['liquid_water_mol'])-F(before['liquid_water_mol'])==-ledger['phase_water_mol'][i]+err['liquid_mol'][i])
            for k in range(3):
                original(label+f'_gas{k}_ledger',F(after['gas_amounts_mol'][k])-F(before['gas_amounts_mol'][k])==left['gas_mol'][k]-right['gas_mol'][k]+(ledger['phase_water_mol'][i] if k==2 else F())+err['gas_mol'][i][k])
            original(label+'_actual_target',inv['target_energy_j']==after['internal_energy_j'] and inv['energy_residual_j']==residual)
            u_limit=abs(residual)+F(p['energy_error_j']);u_limits.append(float(u_limit));t_limits.append(inv['temperature_error_bound_k'])
            original(label+'_inverse_U',u_limit<=F(1e-5))
            original(label+'_inverse_T',inv['temperature_error_bound_k']<=1e-6)
            original(label+'_T_domain',325<=T(p)<=338)
            original(label+'_W_domain',.15<=p['moisture_kg_water_per_kg_dry']<=.8)
            original(label+'_P_domain',90000<=P(p)-p['pressure_error_pa'] and P(p)+p['pressure_error_pa']<=110000)
            original(label+'_actual_liquid_P',eq['pure_equilibrium']['liquid']['state']['pressure_pa']==P(p))
            original(label+'_aw',eq['equilibrium_partial_pressure_pa']==float(F(p['activity'])*F(eq['pure_equilibrium']['equilibrium_partial_pressure_pa'])))
            original(label+'_mu',abs(eq['chemical_potential_residual_j_mol'])<=1e-7)
            original(label+'_entropy',cell['phase']['entropy_production_w_k'] is not None and cell['phase']['entropy_production_w_k']>0)
            original(label+'_positive',after['liquid_water_mol']>0 and all(v>=0 for v in after['gas_amounts_mol']))
            original(label+'_false_flags',p['material_qualified'] is False and p['training_eligible'] is False)
            check(label+'/inventory_binding',p['fluid']['mechanical']['liquid_inventory_mol']==after['liquid_water_mol']
                  and list(p['fluid']['mechanical']['gas_inventory_mol'].values())==after['gas_amounts_mol'])
            check(label+'/point_W',p['moisture_kg_water_per_kg_dry']==moisture(after))
        errors={'U':sum(err['energy_j'],F()),'W':sum(err['liquid_mol'],F())+sum((v[2] for v in err['gas_mol']),F())}
        errors.update({k:sum((v[k] for v in err['gas_mol']),F()) for k in range(2)})
        for kind,e in errors.items():
            cumulative[kind]+=e
            suffix=kind if isinstance(kind,str) else f'gas{kind}'
            original(tag+('_global_'+suffix if isinstance(kind,str) else '_'+suffix+'_global'),total(new,kind)-total(old,kind)==e)
            original(tag+('_prefix_'+suffix if isinstance(kind,str) else '_'+suffix+'_prefix'),total(new,kind)-total(initial,kind)==cumulative[kind])
        for e in (err,ledger['predictor_roundoff']):
            inventory_cost+=sum(map(abs,e['liquid_mol']),F())+sum((sum(map(abs,row),F()) for row in e['gas_mol']),F())
            energy_floor+=sum(map(abs,e['energy_j']),F())
        energy_floor+=sum((abs(ff['energy_decomposition_roundoff_j']) for ff in faces),F())
    for i,(first,cell,state) in enumerate(zip(ini['points'],run['observations'][-1]['cells'],run['states'][-1])):
        p=cell['inverse']['point']
        original(f'cell{i}_resolved_delta_T',abs(T(p)-T(first))>cell['inverse']['temperature_error_bound_k']+1e-6)
        original(f'cell{i}_changed_Nc',state['liquid_water_mol']!=initial[i]['liquid_water_mol'])
        original(f'cell{i}_changed_P',P(p)!=P(first))
        original(f'cell{i}_evolving_k',run['observations'][-1]['conductivity_points'][i]['k_w_m_k']!=float(nominal(first['moisture_kg_water_per_kg_dry'])))
    original('integrator_wall',run['elapsed_seconds']<60.)
    original('whole_driver_wall',a['driver_seconds']<80.)
    check('record/original_149',len(RECOMPUTED)==149 and len(a['checks'])==149 and len({c['id'] for c in a['checks']})==149)
    check('record/original_correspondence',{c['id']:c['passed'] for c in a['checks']}==RECOMPUTED and a['passed'] is True)
    check('record/exact_inventory_charge',inventory_cost==run['inventory_roundoff_used_mol'])
    check('record/energy_charge_saved_floor',energy_floor<=run['energy_roundoff_used_j'])
    check('record/budget_metadata',run['energy_roundoff_budget_j']==1e-8 and run['inventory_roundoff_budget_mol']==1e-12)
    check('record/summary',a['integrator_seconds']==run['elapsed_seconds'] and a['evaluations']==6 and a['model_duration_seconds']==.05
        and a['final_temperature_k']==[T(c['inverse']['point']) for c in run['observations'][-1]['cells']]
        and a['final_pressure_pa']==[P(c['inverse']['point']) for c in run['observations'][-1]['cells']]
        and a['material_qualified'] is False and a['spatial_temporal_convergence_demonstrated'] is False)
    check('supervisor/complete',status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] is True and status['cleanup']['signal_errors']==[])
    check('supervisor/scope',status['cleanup']['scope']=='original_process_group_only; escaped_sessions_not_contained')
    check('supervisor/resources',meta['timeout_s']==100. and meta['cleanup_grace_s']==5. and status['elapsed_s']<105. and a['driver_seconds']<=status['elapsed_s'])
    check('supervisor/isolated_command',meta['command']==['/usr/bin/env','-u','PYTHONPATH','/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python','-I',str(WORK/'native_driver.py')])
    check('supervisor/394_inputs',len(meta['inputs_before'])==len(status['inputs_after'])==394 and set(meta['inputs_before'])==set(status['inputs_after']) and status['inputs_unchanged'] is True)
    for path,info in meta['inputs_before'].items():
        check('input/'+path,info['sha256']==status['inputs_after'][path]==sha(Path(path)) and Path(path).stat().st_size==info['bytes'])
    for name,expected in read(WORK/'code-review/HARNESS_SNAPSHOT.json')['files'].items():
        check('preregistered/'+name,sha(WORK/name)==expected==meta['inputs_before'][str(WORK/name)]['sha256'])
    before=read(WORK/'install/INSTALL_IDENTITY_BEFORE_TESTS.json'); after=read(WORK/'install/INSTALL_IDENTITY_AFTER_TESTS.json')
    check('install/record_match',before==after and before['passed'] is True and before['file_count']==174
        and before['source']==before['installed']==before['frozen']==freeze)
    installed=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
    check('install/174_files',len(freeze)==174)
    for name,expected in freeze.items():
        check('installed/'+name,sha(ROOT/'src/sludge_sandbox'/name)==sha(installed/name)==expected)
    suite=ET.parse(WORK/'install/INSTALLED_TESTS01.xml').getroot().find('testsuite')
    check('install/66_tests',suite.get('tests')=='66' and suite.get('failures')==suite.get('errors')==suite.get('skipped')=='0')
    check('record/no_failure',(WORK/'native01/FAILURE.json').exists() is False)
    csvpath=ROOT/'docs/sandbox/research/source-conductivity-column-v1/TRACE.csv'
    csv_result={'present':csvpath.exists(),'checked':False}
    if csvpath.exists():
        INPUTS[str(csvpath)]=sha(csvpath); csv_result['columns']=next(csv.reader(csvpath.open()))
    SUMMARY={'original_checks_recomputed':len(RECOMPUTED),'original_input_count':len(meta['inputs_before']),
        'frozen_installed_file_count':len(freeze),'original_installed_tests':66,'integration_steps':len(run['ledgers']),
        'rhs_attempted':run['evaluations_attempted'],'rhs_completed':run['evaluations_completed'],'model_duration_s':float(run['times_s'][-1]),
        'integrator_seconds':run['elapsed_seconds'],'driver_seconds':a['driver_seconds'],'supervisor_seconds':status['elapsed_s'],
        'max_accepted_inverse_U_plus_error_j':max(u_limits),'max_accepted_inverse_T_bound_k':max(t_limits),
        'final_temperature_k':a['final_temperature_k'],'final_pressure_pa':a['final_pressure_pa'],
        'delta_temperature_k':[T(c['inverse']['point'])-T(p) for c,p in zip(run['observations'][-1]['cells'],ini['points'])],
        'final_k_w_m_k':[p['k_w_m_k'] for p in run['observations'][-1]['conductivity_points']],
        'middle_thermal':middle,'energy_roundoff_used_j':float(run['energy_roundoff_used_j']),
        'inventory_roundoff_used_mol':float(run['inventory_roundoff_used_mol']),
        'energy_cost_scope':'Verified saved charge and all saved lower-bound terms; initial predictor face decomposition is not saved, so its exact debit is not independently reconstructed.',
        'middle_inverse_scope':'Only midpoint conserved states and actual thermal witnesses are saved; no independent full midpoint inverse certificate check.',
        'csv':csv_result,'material_qualified':False,'training_eligible':False}
except BaseException as exc:
    CHECKS.append({'id':'audit_exception','passed':False,'exception':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
report={'passed':all(c['passed'] for c in CHECKS),'check_count':len(CHECKS),'failed_count':sum(not c['passed'] for c in CHECKS),
    'elapsed_seconds':time.monotonic()-START,'summary':SUMMARY,'checks':CHECKS,'inputs':INPUTS,'audit_script_sha256':sha(Path(__file__))}
with (OUT/'SAVED_REVIEW02.json').open('x') as f: json.dump(report,f,indent=2,default=default);f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('checks','inputs')},indent=2,default=default))
for c in CHECKS:
    if not c['passed']: print('FAILED',json.dumps(c))
raise SystemExit(0 if report['passed'] else 1)
