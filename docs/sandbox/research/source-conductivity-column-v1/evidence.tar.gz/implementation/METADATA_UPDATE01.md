# Metadata-only revision after the initial candidate

This revision supersedes only the four file hashes in `IMPLEMENTATION.md`. Earlier test logs and the actual original-source point read remain unchanged historical artifacts; no real-source point or EOS was rerun.

The source facts now explicitly classify original readings as `measured_public_data`, record `retrieved_on=2026-09-12`, and record `reading_status=full_original_jats_body_and_table_cells_read` from the actual earlier source review. The model now uses the contract classification `derived_from_evidence`; `hybrid_exploratory_donor_transport` is retained as `usage_scope`.

`input_classifications` distinguishes original readings, derived wet/dry conversion and nominal interpolation, virtual temperature/domain/material-transfer choices, numerical representation policy, and unknown total uncertainty. Only these requested metadata fields and cascading file SHA pins changed. `METADATA_ONLY_PROOF01.json` records a deep comparison of both JSON files after excluding exactly those edits, proving all original physical numbers, domains, unknown errors and qualification values remain unchanged. The Python provider edit consists only of the two SHA literal substitutions.

- `METADATA_RED01.log/xml`: the new metadata test actually failed on the missing source classification before the data edits.
- `METADATA_GREEN01.log/xml`: 33 manufactured tests passed in 0.12 s after the metadata/pin update.

| File | Current SHA256 |
|---|---|
| src/sludge_sandbox/septien_conductivity.py | d12b1670ebdb45849e9aa662eb5133a5663bb3c592f2fb7566201e9322512df5 |
| tests/sandbox/test_septien_conductivity.py | a865141c45fb03e7fedd79d1c7a9bc8d7adad105964d6ffb1557b2b0d2420bd3 |
| data/sandbox/research/septien-conductivity-v1/source.json | 5d68c9d8e4d2c2b263270b66af62d6f7b6d1dbd141bbdb9db53fa0d61cd16abd |
| data/sandbox/research/septien-conductivity-v1/model.json | c5d36c30be29b8f9aea569dde355ad0580b6c5d8474a0f85cc4a036c6976cb15 |

The independent reviewer and root agent were notified of these hashes. No other worker's files, installed runtime, original XML or prior stage evidence were edited.
