# Septien conductivity provider handoff

The four owned draft files were migrated to the matching repository paths after the parent authorized migration and completed the previous stage freeze. No previous storage code, source XML, Column core or other agent file was changed by this worker.

## API

```python
provider = SeptienConductivity(repository_root, source_directory)
point = provider.evaluate(temperature_k, moisture_kg_water_per_kg_dry)
```

`source_directory` explicitly contains `fecal2019-original.xml`. It is independent of the public facts/model directory. Construction and each public provider operation check original XML/facts/model SHA values. Original `tbl0010` column headings, both row labels, original moisture and conductivity cell strings, DOI and the original statistical confidence description are checked. Parameters are derived from the admitted original strings and checked against the facts and model coordinates.

Point fields required by the Column branch: `k_w_m_k`, `temperature_k`, `moisture_kg_water_per_kg_dry`, `source_ids`, `model_identity`. The exact nominal value and final float projection are `nominal_k_w_m_k` and `binary64_projection_error_w_m_k` (Fractions). `to_record()` supplies fresh JSON-compatible complete source/model provenance and exact input coordinates. `source_points()` exposes the two original measurements independently of the narrower evaluation domain; `binding()`, `definition()`, `source_ids`, and `model_identity` check current sources.

The provider uses exact wet-to-dry conversion to W1=23/77 and W2=47/53, then nominal linear interpolation. The domain W=.30--.80 is inside those two nominal nodes. T=308.15--368.15 K is explicitly exploratory. Float coordinates/endpoints mean represented binary64 values; exact Decimal/Fraction inputs remain exact. There is no clipping or extrapolation.

Original measurement temperature remains null; 85 degC remains a preparation-zone condition. The two source 90% intervals remain unchanged source repeatability data. No interpolated confidence envelope or cross-material uncertainty is invented. Temperature/pressure extension, interpolation, transfer and total model errors remain unknown, and material/training qualification remain false.

## Evidence

- `RED01.log/xml`: actual absent-provider test collection RED before provider implementation.
- `GREEN01.log/xml`: 32 manufactured source/XML and independent interpolation tests passed in 0.10 s.
- `MIGRATED_GREEN01.log/xml`: same 32 tests passed from the formal repository files in 0.12 s.
- `ORIGINAL_SOURCE_READ01.log` and `ORIGINAL_SOURCE_POINT01.json`: one read-only real-source provider construction and point evaluation. Original XML SHA and Table 2 cells passed; k(330 K, W=.5) = 0.05805375 W/(m K), exact 46443/800000. This is source/arithmetic admission only, not a transport trajectory or material validation.
- `STATIC01.log`: both Python files parsed. Ruff, mypy, black and pylint unavailable in the selected runtime. No packages installed.

Tests use minimal artificial JATS and repinned test-only source seams; the migrated unit tests have no dependence on private scratch XML. The root owns the ignored original-source cache, independent review, Column integration, installed runtime and any real native run. No EOS, network access, installation, commit or native trajectory was performed by this worker.

## Frozen candidate hashes

| Repository path | SHA256 |
|---|---|
| src/sludge_sandbox/septien_conductivity.py | 21b02fdfb47d27b69228212bc8af99f6c14badda70a1a103217c73efb56b2ad6 |
| tests/sandbox/test_septien_conductivity.py | 2fa3af99196a2f38732ea5b94134bb7e3430d97aacd47069bc931c8220a6f830 |
| data/sandbox/research/septien-conductivity-v1/source.json | 3b9f88a9b5f91d5fd811d7c6d6f55b5c53539f22d01abce4534cab76799ecfad |
| data/sandbox/research/septien-conductivity-v1/model.json | 8abaf5125b8e846f7f672addaa30a53a81225bbf4f95e1f266d4ec63a94fd83f |
