"""Thermal routing/arithmetic probes; source XML fixture, no EOS or integration."""
from dataclasses import replace
from fractions import Fraction as F
import math
from types import SimpleNamespace as NS

import pytest
from test_septien_conductivity import factory
from sludge_sandbox import source_wet_column as mod
from sludge_sandbox.arlabosse_rigid_sorption import ArlabosseSorptionStorage
from sludge_sandbox.exchanges import conduction_rate_w
from sludge_sandbox.mass_wet_transport import WetFace
from sludge_sandbox.septien_conductivity import SeptienConductivity


def case(factory, monkeypatch, *, temperatures=(330.,333.), moistures=(.4,.6), area=.001):
    provider=factory.make(); events=[]
    storages=[]
    for i in range(len(temperatures)):
        st=object.__new__(ArlabosseSorptionStorage)
        phases={k:NS(molar_mass_kg_mol=.02) for k in ('O2','N2','H2O')}
        base=NS(gas_ids=('O2','N2','H2O'),fluid_template=NS(gas_phases=phases),
            chemistry=NS(evaluate=lambda *a:NS()))
        object.__setattr__(st,'base',base)
        storages.append(st)
    column=object.__new__(mod.ArlabosseSorptionColumn)
    values=dict(storages=tuple(storages),inverse_policies=(None,)*len(storages),
        chemical=NS(source_ids=('manufactured:phase',),gas_constant_j_mol_k=8.),
        transfer_coefficients_mol_s_pa=(0.,)*len(storages),
        interface_modes=('existing_liquid',)*len(storages),coefficient_source_ids=('manufactured:transport',),
        thermal_provider=provider,liquid_transport=None,_identity='manufactured:thermal-column',
        faces=tuple(WetFace(area,(.01,.01),(0.,0.),(0.,0.,0.),0.,1.,('manufactured:face',))
                    for _ in range(len(storages)-1)))
    for key,value in values.items(): object.__setattr__(column,key,value)
    # Constructor/storage/phase chemistry are outside this arithmetic probe.
    # Actual thermal provider and actual new Column routing/witness/integral
    # code remain unpatched. This does not assert physical cell admissibility.
    monkeypatch.setattr(mod.SourceWetColumn,'_check_states',lambda *a:None)
    def inverse(self,state,policy):
        events.append(('inverse',state.i))
        return NS(point=NS(temperature_k=state.t,moisture_kg_water_per_kg_dry=state.w,
            gas_volume_m3=.001,source_ids=('manufactured:storage',)))
    monkeypatch.setattr(ArlabosseSorptionStorage,'invert',inverse)
    monkeypatch.setattr(mod,'evaluate_sorption_phase',lambda *a:NS(
        equilibrium=NS(source_ids=('manufactured:phase',)),phase_water_mol_s=0.))
    monkeypatch.setattr(mod,'ideal_gas_state',lambda *a,**kw:NS(temperature_k=kw['temperature_k']))
    observed=SeptienConductivity.evaluate
    def conductivity(self,t,w):
        events.append(('conductivity',t,w));return observed(self,t,w)
    monkeypatch.setattr(SeptienConductivity,'evaluate',conductivity)
    def shared(face,states,ids,phases):
        events.append(('face',))
        q=conduction_rate_w(states[0].temperature_k,states[1].temperature_k,
            area_m2=face.area_m2,left_distance_m=face.half_widths_m[0],right_distance_m=face.half_widths_m[1],
            left_conductivity_w_m_k=face.conductivities_w_m_k[0],right_conductivity_w_m_k=face.conductivities_w_m_k[1])
        return NS(conduction_w=q,face_energy_w=q,diffusive_enthalpy_w=(0.,)*3,advective_enthalpy_w=(0.,)*3,
            exchange=NS(net_mol_s={k:0. for k in ids}))
    monkeypatch.setattr(mod,'evaluate_wet_face',shared)
    states=tuple(NS(i=i,t=t,w=w,liquid_water_mol=1.,solid_mass_kg=(.1,),gas_amounts_mol=(.1,.1,.1))
                 for i,(t,w) in enumerate(zip(temperatures,moistures)))
    return column,states,events


def test_nonzero_shared_heat_underflow_is_refused(factory,monkeypatch):
    c,s,_=case(factory,monkeypatch,temperatures=(330.,math.nextafter(330.,math.inf)),area=1e-313)
    with pytest.raises(ValueError,match='nonzero_source_conduction_underflow'):
        c.evaluate(s)


def test_nonzero_entropy_underflow_is_refused(factory,monkeypatch):
    c,s,_=case(factory,monkeypatch,temperatures=(330.,math.nextafter(330.,math.inf)),area=1e-300)
    with pytest.raises(ValueError,match='nonzero_integral_underflow'):
        c.evaluate(s)


def test_equal_temperature_is_true_zero_with_finite_positive_G(factory,monkeypatch):
    c,s,_=case(factory,monkeypatch,temperatures=(330.,330.),area=1e-313)
    out=c.evaluate(s); w=out.faces[1].conductivity_witness
    assert w.conduction_w==0 and w.entropy_production_w_k==0 and w.conductance_w_k>0
    assert w.conduction_arithmetic_residual_w==0


def test_reversal_heat_sign_and_entropy_invariant(factory,monkeypatch):
    c,s,_=case(factory,monkeypatch)
    a=c.evaluate(s).faces[1].conductivity_witness
    b=c.evaluate(tuple(reversed(s))).faces[1].conductivity_witness
    assert a.conduction_w==-b.conduction_w
    assert a.entropy_production_w_k==b.entropy_production_w_k>0
    assert a.conductance_w_k==b.conductance_w_k


def test_each_cell_after_all_inverses_and_once_before_faces(factory,monkeypatch):
    c,s,events=case(factory,monkeypatch,temperatures=(330.,333.,336.),moistures=(.4,.5,.6))
    out=c.evaluate(s)
    assert [e[0] for e in events]==['inverse']*3+['conductivity']*3+['face']*2
    assert len(out.conductivity_points)==3
    assert out.faces[1].conductivity_witness.conductivity_points==(out.conductivity_points[0],out.conductivity_points[1])
    assert out.faces[2].conductivity_witness.conductivity_points==(out.conductivity_points[1],out.conductivity_points[2])


def test_single_cell_still_checks_source_and_domain(factory,monkeypatch):
    c,s,events=case(factory,monkeypatch,temperatures=(330.,),moistures=(.4,))
    out=c.evaluate(s)
    assert [e[0] for e in events]==['inverse','conductivity']
    assert set(c.thermal_provider.source_ids).issubset(out.source_ids)
    s[0].w=.29
    with pytest.raises(ValueError,match='conductivity_moisture_domain_exit'): c.evaluate(s)
    s[0].w=.4
    factory.xml.write_bytes(factory.xml.read_bytes()+b' ')
    with pytest.raises(ValueError,match='original_xml_changed'): c.evaluate(s)


def test_middle_evidence_kept_when_integrating_actual_shared_heat(factory,monkeypatch):
    c,s,_=case(factory,monkeypatch)
    middle=c.evaluate(s);dt=F(1,16)
    faces,phase=mod._integrals(middle,dt)
    assert type(faces[1]) is mod.ConductivityColumnFaceIntegral
    assert faces[1].conductivity_witness is middle.faces[1].conductivity_witness
    assert faces[1].conduction_j==dt*F(middle.faces[1].conduction_w)
    assert faces[1].energy_j==faces[1].conduction_j
    assert faces[1].energy_decomposition_roundoff_j==0
    s[0].w=.45
    final=c.evaluate(s)
    assert faces[1].conductivity_witness.conductivity_points[0].k_w_m_k!=final.conductivity_points[0].k_w_m_k
