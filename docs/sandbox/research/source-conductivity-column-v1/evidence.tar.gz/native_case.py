"""One N2 sorption case with dynamic donor conductivity and other fixture transport."""
from collections.abc import Mapping
from dataclasses import fields, is_dataclass, replace
from fractions import Fraction as F
import json
from pathlib import Path

from sludge_sandbox.septien_conductivity import SeptienConductivity
from sludge_sandbox.arlabosse_caloric import ArlabosseDryCaloric
from sludge_sandbox.arlabosse_wet_thermo import ArlabosseWetThermodynamics
from sludge_sandbox.arlabosse_rigid_sorption import ArlabosseSorptionStorage
from sludge_sandbox.source_mass_caloric import ArlabosseMassCaloric, ReactionDisabled
from sludge_sandbox.source_wet_storage import SourceWetStorage, ManufacturedFixedFluidVolume
from sludge_sandbox.source_wet_column import ArlabosseSorptionColumn
from sludge_sandbox.mass_wet_storage import WaterElementConvention
from sludge_sandbox.mass_wet_transport import WetFace
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.rigid_storage import RigidStorage, DeclaredNumericalEnvelope
from sludge_sandbox.rigid_water_gas import RigidWaterGas, PressurePolicy
from sludge_sandbox.phase_storage import IdealGasPhase, InversePolicy
from sludge_sandbox.thermochemistry import load_thermochemistry

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
IDS = ('O2', 'N2', 'H2O')
FIXTURE_ID = 'manufactured:arlabosse-rigid-sorption-n2-v1'


def serialize(value):
    if isinstance(value, F):
        return {'numerator': value.numerator, 'denominator': value.denominator}
    if is_dataclass(value):
        return {f.name: serialize(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, Mapping):
        return {key: serialize(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [serialize(item) for item in value]
    return value


def make_case(progress=None):
    wet = ArlabosseWetThermodynamics(ROOT, ROOT/'data/sandbox/water')
    chemical = wet._chemical  # Exactly the same actual water/caloric implementation.
    water, vapor = chemical.water, chemical.vapor
    facts = json.loads((ROOT/'data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json').read_bytes())
    rows = {row['species_id']: row for row in facts}
    thermo = load_thermochemistry(ROOT/'data/sandbox/thermochemistry/nist_gases_v1.json')
    phases = {key: IdealGasPhase(thermo.species(key), rows[key]['nominal_molar_mass_kg_mol'],
        0, (rows[key]['source_id'], rows[key]['cache_sha256'])) for key in IDS[:2]}
    phases['H2O'] = IdealGasPhase(vapor, vapor.molar_mass_kg_mol)
    mechanical = RigidWaterGas(water, IDS, 1e-5, (80000., 120000.),
        'planar_interface_no_capillary_pressure', PressurePolicy(1e-12, .1, 100,
        strategy='guarded_liquid_endpoint_interpolation_v1'))
    envelope = DeclaredNumericalEnvelope((325., 338.), (80000., 120000.),
        1e-8, 1e-16, 1e-4, {k: 1e-7 for k in IDS}, {k: 20. for k in IDS},
        'explicit_conditional_numerical_test_envelope_not_independent_eos_certificate',
        (FIXTURE_ID,))
    fluid = RigidStorage(mechanical, phases, envelope)
    caloric = ArlabosseMassCaloric(ArlabosseDryCaloric(
        ROOT/'data/sandbox/research/arlabosse2005/source.json', ROOT), F('313.15'))
    chemistry = ReactionDisabled((caloric.component_id,), IDS,
        'Fixed-composition source-sorption integration; reactions unsupported')
    volume = ManufacturedFixedFluidVolume(1e-5, 1e-12,
        'Manufactured fixed available liquid-plus-gas volume, not measured brick porosity')
    elements = WaterElementConvention.load(ROOT/'data/sandbox/research/water-element-convention-v1/facts.json')
    base = SourceWetStorage(caloric, .01, fluid, volume, (325., 338.), chemistry, elements)
    storage = ArlabosseSorptionStorage(base, wet, (90000., 110000.))
    source = (FIXTURE_ID,)
    face = WetFace(.001, (.01, .01), (.5, .7), (1e-5, 2e-5, 1.5e-5), 1e-15, 1.8e-5, source)
    column = ArlabosseSorptionColumn((storage, storage), (InversePolicy(1e-5, 1e-6, 100),)*2,
        chemical, (1e-10, 1e-10), (face,), (.02, .02), .001,
        ('existing_liquid',)*2, source)
    provider = SeptienConductivity(ROOT, ROOT/'runs/sandbox/source-cache/septien2020')
    column = replace(column, thermal_provider=provider,
        faces=(replace(face, conductivities_w_m_k=(0., 0.)),),
        transport_classification='mixed_source_exploratory')
    initial, points = [], []
    for liquid, gas, temperature in ((.2, (.000048, .000181, .000001), 330.),
                                    (.225, (.000045, .000168, .000001), 333.)):
        state = storage.state(liquid, gas, 0.)
        point = storage.evaluate(state, temperature)
        initial.append(replace(state, internal_energy_j=point.total_internal_energy_j))
        points.append(point)
        if progress is not None:
            progress({'states': tuple(initial), 'points': tuple(points)})
    return column, tuple(initial), tuple(points)
