from pathlib import Path
from dataclasses import replace
from fractions import Fraction as F
import hashlib,json,time
import numpy as np
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.exact_integration import integrate_exact_checkpointed
from sludge_sandbox.exact_integration_checkpoint import _same
from sludge_sandbox.exact_integration_checkpoint_codec import encode_exact_checkpoint,decode_exact_checkpoint,ExactCheckpointCodecError
from sludge_sandbox.integration import ConservedState,Rates,IntegrationPolicy
began=time.monotonic();calls=[]
initial=ConservedState([[1.]], [10.], energy_model_identity=('explicit-manufactured-review',))
p=IntegrationPolicy(initial_step_s=.125,maximum_step_s=.125,minimum_step_s=.01,relative_tolerance=1e-6,amount_absolute_tolerance_mol=1e-7,energy_absolute_tolerance_j=.001,amount_scale_mol=1.,energy_scale_j=1.,maximum_steps=4,maximum_rejections=4,maximum_wall_seconds=30.)
def operator(s,t):
 calls.append(t)
 return Rates(np.zeros((2,1)),np.zeros(2),np.zeros((1,1)),np.array([2.]))
cp=integrate_exact_checkpointed(initial,operator,start_s=T(F()),end_s=T(F(1)),policy=p,pause_after_commit=lambda _:True).checkpoint
before=len(calls);raw=encode_exact_checkpoint(cp);data=json.loads(raw)
restored=decode_exact_checkpoint(raw)
assert _same(restored,cp) and encode_exact_checkpoint(restored)==raw and len(calls)==before
rows=[{'name':'genuine_manufactured_control','status':'pass','observations':before}]
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
def run_case(name,mutator):
 altered=json.loads(raw);mutator(altered)
 altered['payload_sha256']=hashlib.sha256(canonical(altered['checkpoint'])).hexdigest()
 try:decode_exact_checkpoint(canonical(altered))
 except ExactCheckpointCodecError as e:rows.append({'name':name,'status':'rejected','reason':str(e)})
 else:rows.append({'name':name,'status':'ACCEPTED_UNEXPECTED'});raise AssertionError(name)
body=lambda d:d['checkpoint']['fields']
run_case('bool_as_policy_real',lambda d:body(d)['problem']['fields']['policy']['fields'].__setitem__('energy_scale_j',True))
run_case('wrong_known_record_class',lambda d:body(d)['problem']['fields'].__setitem__('initial',body(d)['result']))
run_case('oversized_energy_identity',lambda d:body(d)['problem']['fields']['initial']['fields'].__setitem__('energy_model_identity',{'tuple':['x'*65537]}))
run_case('negative_zero_fraction_denominator',lambda d:body(d).__setitem__('next_step_s',{'fraction':[0,0]}))
run_case('extra_array_dtype_tag',lambda d:body(d)['problem']['fields']['initial']['fields']['amounts_mol']['array'].__setitem__('byteorder','little'))
assert len(calls)==before
rows.append({'name':'no_new_operator_calls_during_codec','status':'pass','additional_calls':len(calls)-before})
output={'checks':len(rows),'elapsed_seconds':time.monotonic()-began,'native_eos_calls':0,'cases':rows}
Path(__file__).with_name('RESULT.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
