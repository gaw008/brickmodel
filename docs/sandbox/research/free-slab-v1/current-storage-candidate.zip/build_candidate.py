from pathlib import Path
p=Path('/private/tmp/brick-current-solid-storage-candidate')
s=Path('src/sludge_sandbox/dynamic_solid_storage.py').read_text()
s=s.replace(s[:s.index('from __future__')],'''"""Current global-geometry fixed-solid thermodynamics without a mechanical closure.

Explicit manufactured point storage, not a free traction solver or material model.
"""
''')
s=s.replace('from sludge_sandbox.free_skeleton_rates import FreeSkeletonRates, solve_free_rates','from sludge_sandbox.dynamic_solid_storage import DynamicStorageErrorBounds')
a=s.index('@dataclass(frozen=True)\nclass DynamicStorageErrorBounds:');b=s.index('@dataclass(frozen=True)\nclass DynamicDeformationPoint:',a);s=s[:a]+s[b:]
s=s.replace('DynamicDeformationPoint','CurrentDeformationPoint').replace('DynamicSolidState','CurrentSolidState').replace('DynamicSolidInverse','CurrentSolidInverse').replace('DynamicSolidStorage','CurrentSolidStorage')
s=s.replace('    normal_stretch: float\n','    normal_stretches: tuple[float, ...]\n    cell_index: int\n')
s=s.replace('    free_rates: FreeSkeletonRates\n','')
a=s.index('    rate_conditioning: str = (');b=s.index('\n\n\n@dataclass',a);s=s[:a]+s[b:]
a=s.index('        if self.skeleton.reference.cells != 1');b=s.index('        if solid_provider_identity',a);s=s[:a]+s[b:]
s=s.replace("'dynamic_fixed_solid_total_point_v1'","'current_fixed_solid_total_point_v1'")
s=s.replace('def _prepare(self, normal_stretch: float,','def _prepare(self, normal_stretches: tuple[float, ...],')
s=s.replace('        # Validate exact fixed inventory and original skeleton stretch domain.','''        reference = self.skeleton.reference
        # Global geometry validates complete numeric/positive shape first.
        geometry = reference.deform(normal_stretches, tangential_stretch=tangential_stretch)
        normals=tuple(float(v) for v in normal_stretches)
        for value in normals:
            if not self.error_bounds.normal_stretch_range[0] <= value <= self.error_bounds.normal_stretch_range[1]:
                raise DeformingStorageError('current_stretch_outside_error_domain')
        normal_stretch=normals[self.skeleton.cell_index]
        # Validate exact fixed inventory and original skeleton stretch domain.''')
s=s.replace('        geometry = reference.deform((normal,), tangential_stretch=tangent)\n','')
s=s.replace('deformation = CurrentDeformationPoint(normal, tangent, geometry)','deformation = CurrentDeformationPoint(normals, self.skeleton.cell_index, tangent, geometry)')
s=s.replace('Fraction(reference.half_thickness_m)\n','Fraction(reference.half_thickness_m)/reference.cells\n')
s=s.replace('float(geometry.volumes_m3[0])','float(geometry.volumes_m3[self.skeleton.cell_index])')
s=s.replace('error: float, bulk_error: float, external_pressure_pa: float)','error: float, bulk_error: float)')
a=s.index('        # Decoded P is now available');b=s.index('        return CurrentSolidState',a);s=s[:a]+s[b:]
s=s.replace('CurrentSolidState(thermal, skeleton, deformation, free, total','CurrentSolidState(thermal, skeleton, deformation, total')
s=s.replace('*, normal_stretch: float,','*, normal_stretches: tuple[float, ...],')
s=s.replace('solid_mol: Mapping[str, float],\n                external_pressure_pa: float)','solid_mol: Mapping[str, float])')
s=s.replace('solid_mol: Mapping[str, float], external_pressure_pa: float,','solid_mol: Mapping[str, float],')
s=s.replace("        external = _num(external_pressure_pa, 'external_pressure', nonnegative=True)\n",'')
s=s.replace('self._prepare(normal_stretch,','self._prepare(normal_stretches,')
s=s.replace('storage, error, bulk, external)','storage, error, bulk)')
(p/'current_solid_storage.py').write_text(s)
