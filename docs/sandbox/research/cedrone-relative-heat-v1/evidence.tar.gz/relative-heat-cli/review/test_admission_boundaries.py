"""Two corrupted-saved-value admission probes, no native provider/import."""
from copy import deepcopy
from fractions import Fraction as F
import builtins
import json
from pathlib import Path

import pytest
from sludge_sandbox.cedrone_heat import compare_cedrone_heat

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
DATA = ROOT / 'data/sandbox/research/cedrone-relative-heat-v1'

@pytest.fixture
def inputs(monkeypatch):
    original = builtins.__import__
    def no_cantera(name, *args, **kwargs):
        if name == 'cantera' or name.startswith('cantera.'):
            pytest.fail('no Cantera import authorized')
        return original(name, *args, **kwargs)
    monkeypatch.setattr(builtins, '__import__', no_cantera)
    return [json.loads((DATA/n).read_text()) for n in ('lambda0-result.json', 'lambda-quarter-result.json')]

def test_corrupted_initial_element_inventory_is_rejected(inputs):
    base, case = deepcopy(inputs)
    case['initial']['amounts_kmol'][0] += 1e-6
    # Completed labels and all final values are deliberately left untouched.
    with pytest.raises(ValueError):
        compare_cedrone_heat(base, case, source_root=ROOT, candidate_lambda=F(1,4))

def test_self_consistent_wrong_gas_constant_is_rejected(inputs):
    base, case = deepcopy(inputs)
    for record in (base, case):
        record['provider_identity']['gas_constant_j_mol_k'] *= 2
        for key in ('initial', 'final'):
            point = record[key]
            point['gas_constant_j_mol_k'] *= 2
            for field in ('standard_h_j_mol', 'standard_s_j_mol_k', 'standard_cp_j_mol_k',
                          'standard_g_j_mol', 'chemical_potentials_j_mol'):
                point[field] = [v * 2 for v in point[field]]
        record['diagnostics']['mixture_enthalpy_j']['numerator'] *= 2
    with pytest.raises(ValueError):
        compare_cedrone_heat(base, case, source_root=ROOT, candidate_lambda=F(1,4))
