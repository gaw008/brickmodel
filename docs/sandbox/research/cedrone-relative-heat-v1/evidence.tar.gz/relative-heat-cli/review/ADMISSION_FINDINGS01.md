# 实际负控发现（修复前证据，保留）

被审 helper SHA：d8ec97a3eea1866347881bb396b5210d0bb4fdff1b7338dbaf1cad4c919a15e8。
ADMISSION_RED01.log/xml 实际 **2 failed in 0.10 s**，均为应拒绝却未抛 ValueError；测试明确拦截 Cantera 导入。

[HIGH] 初始库存元素门未重新消费
File: src/sludge_sandbox/cedrone_heat.py:89
Issue: `_physical_point`核初始T/P/物性，`_diagnostics`从初库存只取amounts用于seed G，忽略原`_inventory`的checks。保留其余原值，只给candidate.initial.amounts_kmol[0]加1e−6 kmol即可通过。离线入口声称保留原验收门，但这会接受原初始元素门失败的保存记录。
Fix: 在新`_admit`对初/末点明确调用已有`_inventory`并要求所有原checks通过；不用修改旧core。

[HIGH] 热力学标度仅自洽而未绑定气体常数
File: src/sludge_sandbox/cedrone_heat.py:65
Issue: 原门只要求R为正float；provider和point可一同变。把两份记录R、全套h/s/Cp/g/μ各乘2，并把保存总H乘2，仍通过_property_check和后验检查，导致相对热差翻倍。源系数/相同provider版本没有约束这一遗漏的物理标度。
Fix: 新离线物理入口窄绑定原有固定SI R（N_A k_B的正确单位及名义binary64），并保留该来源说明；不建立运行真实性或通用依赖认证。

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 2 | warn |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: WARNING — 两项需在最终候选验收前修复；本文件仅记录原失败，最终结论另出。
