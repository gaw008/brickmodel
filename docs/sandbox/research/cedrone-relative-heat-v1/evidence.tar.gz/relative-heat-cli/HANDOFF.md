# Cedrone conditional relative heat: candidate 02

The three owned production files are frozen in `AUTHOR_SHA02.json` and copied under `candidate02/`. Historical candidate 01 and every actual RED remain unchanged. No install, Cantera import, phase construction, equilibrium solve, EOS or new native experiment was performed for this implementation.

## API and interpretation

`sludge_sandbox.cedrone_heat.compare_cedrone_heat(baseline_result, candidate_result, *, source_root, candidate_lambda: Fraction, baseline_lambda: Fraction = Fraction())` accepts raw saved TPResult JSON mappings and returns a deeply read-only value mapping. Baseline lambda must be 0; candidate accepts 0, 1/4 or 1. Inputs must describe the same reported Cedrone source basis at 800 K and 100000 Pa with the fixed 18 gases plus graphite and original VCS policy gates.

The exact represented-data arithmetic is `delta_Q = H_candidate - H_baseline - n_O2_added*h_O2(800 K) - n_N2_added*h_N2(800 K)`. All 19 product terms, both inlet terms, their property locators and thermochemical provenance are saved. The formal species equation is retained, and its actual element residual equals the difference between the two saved numerical element residuals; the strict target equation is separately zero. No inventory is clipped or corrected.

The physical conditions are the same unknown feed initial state and amount, identical changes of unmodeled subsystems, constant pressure with only pV work and no kinetic/potential difference, and ideal O2/N2 entering at 800 K. Unknown feed enthalpy cancels under these conditions; it is never assigned zero. Absolute heat duty, material error and upstream preheating energy remain unknown. A negative difference denotes less net heat than the baseline under these conditions and does not establish self-heating, fuel saving, real emissions or char yield.

## Admission and the two repaired negative controls

The API restores only ordinary JSON and the existing two-integer Fraction representation. It reuses source pack checks, Cedrone pool reconstruction, actual phase identity and atomic weights, NASA7 property checks, initial and final inventory checks, and original pure TP posterior diagnostics. Recomputed floating least-squares diagnostics need to pass the original gates; they are not required to match historical linalg floats bit for bit. Exact represented inventory and enthalpy identities are checked strictly. Legal serializer/timing metadata differences do not change the physical identity.

Independent review preserved two actual failures in `review/ADMISSION_RED01.log` and `.xml`: a corrupt initial inventory escaped the original admission, and a self-consistent doubled gas constant and property vectors escaped source checks. Candidate 02 now consumes every initial/final `_inventory` check and binds R to `float(Fraction("6.02214076e23") * Fraction("1.380649e-23")) = 8.31446261815324 J/(mol K)`. These are the already registered exact SI values in `data/sandbox/thermochemistry/sources.json`, source `nist-codata-2022`; output includes that source locator and exact factors. No original TP model, source file, physical gate or native result was modified.

## CLI

Run from a checkout with the package installed, substituting an absent output directory:

```sh
python examples/sandbox/compare_cedrone_heat.py \
  --source-root . \
  --baseline-result data/sandbox/research/cedrone-relative-heat-v1/lambda0-result.json \
  --candidate-result data/sandbox/research/cedrone-relative-heat-v1/lambda-quarter-result.json \
  --lambda 1/4 \
  --output-dir runs/sandbox/relative-heat-example
```

The CLI exclusively creates the result directory, saves the declared request before input reads, records actual input bytes/SHA and imported comparison module bytes/SHA, and writes `INPUT.json`, `RESULT.json` when returned, and `STATUS.json`. It rejects overwrite, nonfinite values, bad fractions, unsupported/failed records and mismatched physical inputs. It has 30-second boundary checks; this pure offline entry does not claim hard interruption of Python calls. Both provider counts are zero. An I/O error cannot promise complete output.

## Actual checks and final ownership

- `author-tests/RED01.*`: original missing-module collection failure, preserved.
- `author-tests/GREEN01.*`: original 19 formal cases passed in 0.29 s.
- `review/ADMISSION_RED01.*`: two independent negative controls failed in 0.10 s before the fix, preserved.
- `author-tests/ADMISSION_GREEN01.*`: three affected author cases passed in 0.18 s: existing positive heat sums and the two added negatives. The command also named the review file, but its `-k` filter deselected those two review probes; this log does not claim they ran.
- `author-tests/STATIC01.log`: available static-tool check and AST inspection; optional ruff/mypy/black/pylint were unavailable, with no installation attempted.
- `author-tests/STATIC02.log`: final three files parse successfully. Scoped `git diff --check` returned 0; files are currently untracked.

There are now 21 formal cases. ROOT owns the full final installed 21-case check and one offline lambda-quarter CLI comparison; the independent reviewer owns its original two-probe GREEN and final review. No old test suite or equilibrium experiment needs repeating.

Final SHA-256:

| File | SHA-256 |
|---|---|
| `src/sludge_sandbox/cedrone_heat.py` | `4d2b9e4df035b5d6c48feb388ae60bc0ae4a028c3b21bb8511943aa47f0a52b1` |
| `examples/sandbox/compare_cedrone_heat.py` | `b423ec4f36e021a4f0bcd03189e074fe2a4c07ef0a850804278c878f465c1586` |
| `tests/sandbox/test_cedrone_heat.py` | `e0bcbb7367fb41a18fc72b562cd0645acf5238e55e95cdcfdf11ee6eae3e309d` |
