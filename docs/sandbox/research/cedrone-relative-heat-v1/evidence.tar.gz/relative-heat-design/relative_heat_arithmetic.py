"""Read three saved states; compute a conditional isobaric heat difference."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path


WORK = Path(__file__).resolve().parent
BASE = WORK.parent
ELEMENTS = ('C', 'H', 'O', 'N', 'S')
CASES = ((F(0), BASE / 'cedrone-execution/native01'),
         (F(1, 4), BASE / 'finite-oxygen-execution/native01/point01'),
         (F(1), BASE / 'finite-oxygen-execution/native01/point02'))


def fraction(record: dict) -> F:
    """Decode exact saved fractions without converting through decimal/float."""
    return F(int(record['numerator']), int(record['denominator']))


def encode(value: object) -> object:
    """Retain exact arithmetic and separate display-only approximations."""
    if isinstance(value, F):
        return {'numerator': value.numerator, 'denominator': value.denominator,
                'approximate_display': float(value)}
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    return value


def calculate() -> dict:
    """Use only saved inventories and saved standard enthalpies, never Gibbs."""
    states, evidence = [], {}
    for lam, directory in CASES:
        records = {}
        for name in ('INPUT.json', 'RESULT.json', 'OBSERVABLES.json'):
            path = directory / name
            raw = path.read_bytes()
            records[name] = json.loads(raw)
            evidence[str(path)] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
        result, obs = records['RESULT.json'], records['OBSERVABLES.json']
        assert result['status'] == 'completed' and result['actual_source_properties_checked'] is True
        assert result['diagnostics']['checks'] and all(result['diagnostics']['checks'].values())
        for point in (result['initial'], result['final']):
            assert point['temperature_k'] == 800.0 and point['pressure_pa'] == 100000.0
        loaded = result['initial']['loaded_definition']
        assert loaded == result['final']['loaded_definition']
        species = tuple(s['name'] for s in loaded['species'])
        assert len(species) == 19 and species[5:7] == ('O2', 'N2') and species[-1] == 'C(gr)'
        atoms = tuple(tuple(F(s['composition'].get(e, 0)) for e in ELEMENTS)
                      for s in loaded['species'])
        n = tuple(1000 * F.from_float(v) for v in result['final']['amounts_kmol'])
        h = tuple(F.from_float(v) for v in result['final']['standard_h_j_mol'])
        assert n == tuple(map(fraction, result['diagnostics']['amounts_mol']))
        assert tuple(s['name'] for s in obs['species']) == species
        assert n == tuple(fraction(s['amount_mol']) for s in obs['species'])
        target = tuple(map(fraction, result['request']['element_mol']))
        returned = tuple(sum((n[i] * atoms[i][j] for i in range(19)), F()) for j in range(5))
        residual = tuple(returned[j] - target[j] for j in range(5))
        assert residual == tuple(map(fraction, result['diagnostics']['element_residual_mol']))
        enthalpy = sum((amount * value for amount, value in zip(n, h, strict=True)), F())
        assert enthalpy == fraction(result['diagnostics']['mixture_enthalpy_j'])
        states.append({'lambda': lam, 'records': records, 'n': n, 'h': h, 'target': target,
                       'atoms': atoms, 'residual': residual, 'H': enthalpy, 'species': species})
    base = states[0]
    first = base['records']['RESULT.json']
    base_input = base['records']['INPUT.json']
    assert base_input['request'] == first['request']
    incoming_h = tuple(F.from_float(v) for v in first['initial']['standard_h_j_mol'])
    assert incoming_h == base['h']
    b = base['target']
    demand = b[0] + b[1] / 4 + b[4] - b[2] / 2
    rows = []
    for state in states:
        result = state['records']['RESULT.json']
        assert result['provider_identity'] == first['provider_identity']
        assert result['provenance'] == first['provenance'] and result['policy'] == first['policy']
        assert result['initial']['loaded_definition'] == first['initial']['loaded_definition']
        assert state['species'] == base['species'] and state['h'] == incoming_h
        assert tuple(F.from_float(v) for v in result['initial']['standard_h_j_mol']) == incoming_h
        assert result['final']['gas_constant_j_mol_k'] == first['final']['gas_constant_j_mol_k']
        lam = state['lambda']
        oxygen, nitrogen = lam * demand, F(79, 21) * lam * demand
        increment = (F(0), F(0), 2 * oxygen, 2 * nitrogen, F(0))
        assert state['target'] == tuple(b[j] + increment[j] for j in range(5))
        if lam:
            record = state['records']['INPUT.json']
            assert record['pool'] == result['request']
            case = record['case']
            assert fraction(case['lambda']) == lam
            assert tuple(map(fraction, case['base_element_mol'])) == b
            assert fraction(case['added_O2_mol']) == oxygen and fraction(case['added_N2_mol']) == nitrogen
        added = tuple(oxygen if i == 5 else nitrogen if i == 6 else F(0) for i in range(19))
        nu = tuple(state['n'][i] - base['n'][i] - added[i] for i in range(19))
        incoming_o = oxygen * incoming_h[5]
        incoming_n = nitrogen * incoming_h[6]
        difference_h = state['H'] - base['H']
        difference_q = difference_h - incoming_o - incoming_n
        assert difference_q == sum((nu[i] * incoming_h[i] for i in range(19)), F())
        gauge_coefficients = tuple(sum((nu[i] * state['atoms'][i][j] for i in range(19)), F())
                                   for j in range(5))
        assert gauge_coefficients == tuple(state['residual'][j] - base['residual'][j] for j in range(5))
        target_zero = tuple(state['target'][j] - b[j] - increment[j] for j in range(5))
        assert target_zero == (F(0),) * 5
        if not lam:
            assert difference_q == 0 and all(v == 0 for v in nu)
        rows.append({'lambda': lam, 'saved_equilibrium_enthalpy_J': state['H'],
                     'recomputed_species_H_terms_J': dict(zip(state['species'],
                         (state['n'][i] * state['h'][i] for i in range(19)), strict=True)),
                     'added_O2_mol': oxygen, 'added_N2_mol': nitrogen,
                     'equilibrium_enthalpy_difference_J_NOT_heat_alone': difference_h,
                     'incoming_O2_enthalpy_J': incoming_o, 'incoming_N2_enthalpy_J': incoming_n,
                     'incoming_total_enthalpy_J': incoming_o + incoming_n,
                     'conditional_isobaric_Q_minus_Q0_J': difference_q,
                     'conditional_isobaric_Q_minus_Q0_MJ_per_kg_reported_sample': difference_q / 10**6,
                     'formal_difference_species_coefficients_mol': dict(zip(state['species'], nu, strict=True)),
                     'target_element_zero_mol': dict(zip(ELEMENTS, target_zero, strict=True)),
                     'actual_returned_element_residual_mol': dict(zip(ELEMENTS, state['residual'], strict=True)),
                     'reference_shift_leak_coefficients_mol_equals_residual_difference':
                         dict(zip(ELEMENTS, gauge_coefficients, strict=True))})
    return {'scope': 'conditional same-feed isobaric heat differences, not absolute process heat',
            'evidence': evidence, 'temperature_K': 800, 'pressure_Pa': 100000,
            'selected_inlet_temperature_K': 800, 'nominal_reported_sample_basis_kg': F(1),
            'incoming_h_source': str(CASES[0][1] / 'RESULT.json') + '/initial/standard_h_j_mol',
            'incoming_O2_h_J_mol': incoming_h[5], 'incoming_N2_h_J_mol': incoming_h[6],
            'shared_source_provider_policy_and_h_vectors_checked': True,
            'exact_Fraction_H_sums_match_all_saved_diagnostics': True,
            'source_basis_and_exclusions': base_input['derivation']['source_basis'] | {
                'excluded_and_unidentified': base_input['derivation']['excluded_and_unidentified']},
            'conditions': ['same unknown initial feed state and amount', 'isobaric, only pV work',
                           'no KE/PE contribution', 'identical outside-subsystem initial/final state changes',
                           'preheated ideal O2/N2 at 800 K; upstream preheating outside boundary'],
            'reference_invariance': 'exact conserved pools cancel arbitrary constant elemental enthalpy shifts; saved inventories retain the explicit residual-difference coefficients',
            'material_and_thermochemical_fit_uncertainty': None,
            'H_feed_HHV_C_U_were_set_to_zero': False,
            'new_EOS_equilibrium_calls': 0, 'cases': rows}


if __name__ == '__main__':
    result = calculate()
    with (WORK / 'RELATIVE_HEAT_ARITHMETIC.json').open('x', encoding='utf-8') as stream:
        json.dump(encode(result), stream, indent=2, allow_nan=False)
        stream.write('\n')
    print('PASS: three saved H sums and heat differences; exact lambda0 zero; 0 new EOS/equilibrium calls.')
