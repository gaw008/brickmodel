"""Independent exact saved-value arithmetic; no source-module import or EOS."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

W=Path('/private/tmp/sludge-tp-equilibrium-v1');D=W/'relative-heat-design';E=('C','H','O','N','S')
def hook(d):
 if set(d) in ({'numerator','denominator'},{'numerator','denominator','approximate_display'}) and all(type(d[k]) is int for k in ('numerator','denominator')):
  return F(d['numerator'],d['denominator'])
 return d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def sha(p):return sha256(p.read_bytes()).hexdigest()
def wire(v):
 if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
 if isinstance(v,dict):return {k:wire(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [wire(x) for x in v]
 return v
saved=read(D/'RELATIVE_HEAT_ARITHMETIC.json');checks=[];rows=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)})
check('nine_saved_input_hashes_bytes',len(saved['evidence'])==9 and all(sha(Path(p))==v['sha256'] and Path(p).stat().st_size==v['bytes'] for p,v in saved['evidence'].items()))
paths=[W/'cedrone-execution/native01',W/'finite-oxygen-execution/native01/point01',W/'finite-oxygen-execution/native01/point02'];results=[read(p/'RESULT.json') for p in paths];base=results[0];b=base['request']['element_mol'];species=[s['name'] for s in base['final']['loaded_definition']['species']];atoms=[[F(s['composition'].get(e,0)) for e in E] for s in base['final']['loaded_definition']['species']];h=[F(v) for v in base['initial']['standard_h_j_mol']];oi=species.index('O2');ni=species.index('N2');demand=b[0]+b[1]/4+b[4]-b[2]/2;n0=[1000*F(v) for v in base['final']['amounts_kmol']];H0=sum((x*y for x,y in zip(n0,h)),F());r0=[sum((n0[i]*atoms[i][j] for i in range(19)),F())-b[j] for j in range(5)];shift=[F(v*10**6) for v in (1,-3,7,-11,13)]
check('full_common_source_policy_19_thermochemistry_and_800K_1bar',len(species)==19 and all(r['status']=='completed' and r['actual_source_properties_checked'] and all(v is True for v in r['diagnostics']['checks'].values()) and r['provider_identity']==base['provider_identity'] and r['provenance']==base['provenance'] and r['policy']==base['policy'] and all(p['loaded_definition']==base['final']['loaded_definition'] and p['temperature_k']==800 and p['pressure_pa']==100000 and [F(v) for v in p['standard_h_j_mol']]==h for p in [r['initial'],r['final']]) for r in results))
check('800K_two_inlet_species_h_reference',saved['incoming_O2_h_J_mol']==h[oi] and saved['incoming_N2_h_J_mol']==h[ni] and saved['selected_inlet_temperature_K']==saved['temperature_K']==800 and saved['pressure_Pa']==100000 and saved['nominal_reported_sample_basis_kg']==1)
for lam,result,row in zip((F(),F(1,4),F(1)),results,saved['cases'],strict=True):
 n=[1000*F(v) for v in result['final']['amounts_kmol']];H=sum((x*y for x,y in zip(n,h)),F());O=lam*demand;N=F(79,21)*O;add=[F()]*19;add[oi]=O;add[ni]=N;nu=[x-y-z for x,y,z in zip(n,n0,add)];target=[b[j]+sum((add[i]*atoms[i][j] for i in range(19)),F()) for j in range(5)];res=[sum((n[i]*atoms[i][j] for i in range(19)),F())-target[j] for j in range(5)];coeff=[sum((nu[i]*atoms[i][j] for i in range(19)),F()) for j in range(5)];q=H-H0-O*h[oi]-N*h[ni]
 check(f'{lam}_19_H_terms_diagnostics_and_saved_H',row['lambda']==lam and row['saved_equilibrium_enthalpy_J']==H==result['diagnostics']['mixture_enthalpy_j'] and row['recomputed_species_H_terms_J']==dict(zip(species,[x*y for x,y in zip(n,h)])))
 check(f'{lam}_independent_additions_and_both_inlet_terms',row['added_O2_mol']==O and row['added_N2_mol']==N and result['request']['element_mol']==target and row['incoming_O2_enthalpy_J']==O*h[oi] and row['incoming_N2_enthalpy_J']==N*h[ni] and row['incoming_total_enthalpy_J']==O*h[oi]+N*h[ni])
 check(f'{lam}_signed_relative_Q_and_formal_species_difference',row['equilibrium_enthalpy_difference_J_NOT_heat_alone']==H-H0 and row['conditional_isobaric_Q_minus_Q0_J']==q==sum((x*y for x,y in zip(nu,h)),F()) and row['conditional_isobaric_Q_minus_Q0_MJ_per_kg_reported_sample']==q/10**6 and row['formal_difference_species_coefficients_mol']==dict(zip(species,nu)))
 check(f'{lam}_unprojected_actual_reference_residual',res==result['diagnostics']['element_residual_mol'] and row['actual_returned_element_residual_mol']==dict(zip(E,res)) and coeff==[x-y for x,y in zip(res,r0)] and row['reference_shift_leak_coefficients_mol_equals_residual_difference']==dict(zip(E,coeff)) and row['target_element_zero_mol']==dict.fromkeys(E,F()))
 hp=[value+sum((a*c for a,c in zip(atom,shift)),F()) for value,atom in zip(h,atoms)];shift_q=sum((x*y for x,y in zip(n,hp)),F())-sum((x*y for x,y in zip(n0,hp)),F())-O*hp[oi]-N*hp[ni];leak=sum((c*r for c,r in zip(shift,coeff)),F())
 check(f'{lam}_explicit_mixed_sign_reference_shift',shift_q-q==leak)
 if lam:
  check(f'{lam}_omitting_each_inlet_fails_reference_accounting',O*h[oi]>0 and N*h[ni]>0 and (H-H0-O*h[oi])!=q and (H-H0-N*h[ni])!=q and [coeff[j]+N*atoms[ni][j] for j in range(5)]!=coeff and [coeff[j]+O*atoms[oi][j] for j in range(5)]!=coeff)
 else:check('lambda0_exact_zero_Q_and_reference_residual',q==0 and all(x==0 for x in nu+coeff))
 rows.append({'lambda':lam,'H_J':H,'relative_Q_J':q,'inlet_O2_J':O*h[oi],'inlet_N2_J':N*h[ni],'largest_actual_reference_leak_coefficient_mol':max(map(abs,coeff)),'manufactured_shift_J_per_mol_atoms':dict(zip(E,shift)),'manufactured_reference_leak_J':leak})
check('unknown_feed_and_uncertainty_not_set_zero',saved['H_feed_HHV_C_U_were_set_to_zero'] is False and saved['material_and_thermochemical_fit_uncertainty'] is None and 'same unknown initial feed state and amount' in saved['conditions'] and 'identical outside-subsystem initial/final state changes' in saved['conditions'] and saved['new_EOS_equilibrium_calls']==0)
record={'verdict':'PASS' if all(v['passed'] for v in checks) else 'FAIL','checks':checks,'cases':rows,'files_sha256':{n:sha(D/n) for n in ['RELATIVE_HEAT_DESIGN.md','relative_heat_arithmetic.py','RELATIVE_HEAT_ARITHMETIC.json','RUN01.log']},'new_EOS_or_equilibrium_calls':0,'reference_shift_note':'manufactured arithmetic identity, no alternative physical solution'}
with (D/'review/CHECK01.json').open('x') as f:json.dump(wire(record),f,indent=2,allow_nan=False);f.write('\n')
print(record['verdict'],len(checks),'checks');print('failed',[c['name'] for c in checks if not c['passed']])
for row in rows:print({k:float(v) if isinstance(v,F) else v for k,v in row.items() if k!='manufactured_shift_J_per_mol_atoms'})
raise SystemExit(0 if record['verdict']=='PASS' else 1)
