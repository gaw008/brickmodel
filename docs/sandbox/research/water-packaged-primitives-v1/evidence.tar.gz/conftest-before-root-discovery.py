# Temporary overlay only; do not apply to repository.
from pathlib import Path
import sludge_sandbox
sludge_sandbox.__path__.insert(0,str(Path(__file__).parent/'src/sludge_sandbox'))
