# Independent packaged-primitives review

Final verdict: **APPROVE** frozen revision `63dfcb3f6e02fa40b4c4939c5e6a739c759992ddcdd0f0a2019bc2cf7ab15fc7` for package application. The MEDIUM below is resolved. All five production module hashes remain unchanged; exact diff removes only the unused `asdict` import and fixture diagnostic write, retaining every assertion. The generated diagnostic fixture was removed from the application set and preserved in `before-fixture-write-fix`. Final changed test SHA256 is `8440885db013c28407fc53432d2e64d6967a05b5052e3ec50c3c9e7179bd5d2c`. Every new FREEZE entry matches actual bytes.

Independent revised targeted test: 2 passed, 41 deselected (`review_fixed02.log`/XML). An initial direct-file invocation failed collection because that invocation did not discover the temporary parent overlay; its `review_fixed01.log`/XML are preserved. Running from the known tests directory with a test selector fixed only harness discovery. No candidate modifications were made by the reviewer. The prior complete independent 43-test run and mathematical import parity remain applicable because the only subsequent edit removes diagnostic output.

Source verdict: APPROVE the five mathematical modules. No HIGH/CRITICAL formula, threshold, source-guard or cost-semantic change found. Formal-test verdict awaits the narrowly requested test-output portability correction below.

Independent verification checked every FREEZE hash after testing, every MAPPING original/candidate SHA, and exact text substitutions for all five source files. `water_interval_eos.py` is byte-identical to reviewed SHA28bcfac0. The other four modules differ only by their package-qualified imports of this same module. In particular, Decimal contexts, directed arithmetic, Krawczyk strict inclusion and weighted norm threshold, public/native scale, source snapshots, failure records, bounds, callback accounting and budgets are unchanged. The density wrapper's pinned EOS implementation SHA remains valid because its imported module's bytes are unchanged.

Actual independent candidate test run: **43 passed in 1.17 s**, `review_tests01.log` and XML. These run synthetic callbacks and mathematical Helmholtz/independent iapws arithmetic, not new native flash or integration. `review_mapping01.json` records the independent byte/parity check. No repository or installed files were changed by the reviewer.

The six formal test files change package imports, corresponding mock target and adjacent fixture paths. All assertions are retained. Original HEOS JSON/source license and seed-state artifacts retain their original bytes. The temporary overlay merely adds candidate package modules to the test process; it must not be applied to the repository. Root's source/install regression after application remains separate from this candidate-overlay execution.

[MEDIUM] Formal test writes into source fixture directory.
File: tests/sandbox/test_water_coupled_rectangle.py:48
Issue: the wider-bracket test writes coupled-result01.json under its new ROOT, which is now a checked-in fixture directory. It causes test execution to mutate a source fixture and fails when fixtures are read-only. The actual run happened to reproduce identical bytes, so current frozen hashes still match; this does not make the write portable.
Fix: remove the unused diagnostic write and its unused generated fixture, preserving every assertion, or redirect it to a temporary test directory. Root and author were notified; do not repeat the old version's test run. Final test-only revised freeze is pending.

Packaging alone does not add a native liquid pressure consumer or expand physical/numerical qualification. The primitives retain their conditional mathematical contracts and generic callback assumptions. No global phase, native-universal error or real-material admission is implied by inclusion in the package.
