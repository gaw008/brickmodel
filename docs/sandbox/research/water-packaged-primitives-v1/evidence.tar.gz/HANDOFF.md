# Packaged interval primitives candidate

Candidate only; no repository edits, installation, native flash, or new physical admission. Independent review remains required before application.

Apply only `src/sludge_sandbox/*.py`, `tests/sandbox/test_water_*.py`, and `tests/sandbox/fixtures/water-interval-primitives-v1/*`. Do not apply either temporary conftest, logs, or preparation scripts. Formal tests use package imports and adjacent repository fixtures, with no absolute user paths. Existing test environment supplies pytest and iapws; no dependency was added.

`MAPPING.json` records original paths and SHA256 versus candidate paths and SHA256; `packaging.diff` contains all changes. Original five source hashes were asserted before copying. The interval EOS source is byte identical, so the density wrapper's pinned EOS implementation hash remains valid. Other four source changes are solely their import of that module. Public APIs, formulas, Decimal precision, weighted/default norms, strict inequalities, resource limits, source guards, and failure behavior remain unchanged.

The six test files preserve existing assertions, including the public/native molar-volume scale regression. Test changes only package imports, the mock's target module, and fixture location. Fixtures retain original bytes: the source-pinned CoolProp HEOS JSON and license, and the manufactured saved initial state/forward output used as numerical bracket seeds. Those saved outputs are not real-material qualification or validation of an entire trajectory.

Validation: tests02.xml/log, 43 passed in 1.15 s. No native EOS was invoked; tests use analytic callbacks or the mathematical Helmholtz implementation and existing independent iapws arithmetic. First attempt tests01.xml/log retained: six collection errors because pytest did not discover the parent-directory temporary overlay. The only fix was placing that overlay inside tests with the adjusted parent path. No production module or formal test was changed to resolve this harness failure.

Command (from repository root):
`PYTHONPATH=src /private/tmp/brick-water-backend-probe/venv/bin/python -m pytest /private/tmp/brick-water-pressure-interval-v1/packaged_primitives/tests -q`

This packaging does not certify global phase stability, the complete native implementation, unknown material errors, or a full U-inverse pressure enclosure. It preserves the prior local mathematical contracts. Consumer integration is a separate candidate owned by Carson.

Independent review portability correction: removed the unused diagnostic write into the fixture directory and its asdict import. All assertions preserved. Prior test/freeze/generated output retained in before-fixture-write-fix. The diagnostic output is not an input fixture and must not be applied.
