"""Independent manufactured event checks; no native water or material claims."""
from dataclasses import replace
from fractions import Fraction
import math

import pytest

from sludge_sandbox.depletion_integration import integrate_depletion
from test_depletion_spine import configured, oracle, initial, exact_event, audit, check_costs


def run_affine(b, *, method='affine_midpoint', callback=None):
    p, e = configured()
    e = replace(e, terminal_method=method, amount_absolute_mol=1e-10)
    op, counts = oracle(b)
    if callback is not None:
        op = replace(op, evaluate_callback=callback(op.evaluate_callback))
    result = integrate_depletion(initial(), op, start_s=0., end_s=.2,
        integration_policy=p, event_policy=e)
    return result, counts


@pytest.mark.parametrize('b', [0., .002])
def test_affine_event_matches_independent_root_reaction_and_energy(b):
    out, counts = run_affine(b)
    audit(out, b)
    check_costs(out)
    event = out.events[0]
    assert abs(event.time_s-exact_event(b)) < 1e-10
    assert counts['calls'] == out.evaluations
    assert event.terminal_evidence is not None
    certificate = event.terminal_evidence.clock
    assert certificate.start_s < certificate.midpoint_s < certificate.end_s
    assert certificate.end_s == event.time_s
    row = out.states[out.times_s.index(event.time_s)].amounts_mol[0]
    assert abs(row[2]-2*math.exp(-.1*event.time_s)) < 1e-10
    assert any(r.status == 'independent_approach_pass' for r in out.refinements)


def test_affine_total_work_reduces_at_same_acceptance_gates():
    affine, _ = run_affine(.002)
    euler, _ = run_affine(.002, method='euler')
    assert affine.status == euler.status == 'completed'
    assert affine.evaluations < euler.evaluations
    assert affine.phase_costs['approach']['evaluations'] < euler.phase_costs['approach']['evaluations']


def test_affine_midpoint_failure_does_not_commit_event():
    # The midpoint callback is an actual evaluation: fail there, not a cached lookup.
    def injected(original):
        def evaluate(state, t, modes):
            import inspect
            if any(f.function == 'affine_terminal' for f in inspect.stack()):
                raise ValueError('manufactured_midpoint_failure')
            return original(state, t, modes)
        return evaluate
    out, _ = run_affine(.002, callback=injected)
    assert out.status != 'completed'
    assert 'manufactured_midpoint_failure' in out.reason
    assert not out.events and not out.corrections
    assert out.operator.interfaces == ('existing_liquid',)
    assert all(s.amounts_mol[0, 0] > 0 for s in out.states)


def test_unknown_terminal_method_rejected():
    _, event = configured()
    with pytest.raises(ValueError, match='terminal_method'):
        replace(event, terminal_method='uncertified')
