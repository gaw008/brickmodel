# Shared pressure session candidate

Three new formal modules, temporary ownership only:

- `mass_wet_pressure_provider_v2.py`: structured-failure provider variant. Reuses the applied base request/policy/parameters and all five existing mathematical primitives; the copied evaluation body changes guard exception types and adds an optional caller guard, not equations or scientific thresholds.
- `mass_wet_pressure_seed.py`: formal extraction of fresh_query/propose_boxes.py's ancillary + bounded point-Newton proposal mathematics. Fixed explicit seed policy, immutable actual iteration prefixes, no pressure proof claim.
- `mass_wet_pressure_session.py`: one synchronous owner, one construction-time deadline, cumulative seed/proof budgets, immutable query history. It does not connect stage/controller itself.

Original provider source is preserved as `provider-before.py`; no applied file, old consumer freeze or fresh-query artifact was changed. Old provider class/return fields remain unchanged. The new `StructuredPressureEvidence` is explicitly schema `conditional_pressure_evidence_v2`, inheriting the original fields and adding failure kind/stage. Old codecs must not silently discard those fields.

## Stable API

```python
session = PressureSession(
    original_pair,
    branch_policy=branch_policy,
    seed_policy=LiquidSeedPolicy(),
    budget=PressureSessionBudget(
        maximum_seed_evaluations=48,
        maximum_proof_operations=16,
        maximum_wall_seconds=90.,
        maximum_boxes_per_primitive=256,
    ),
    caller_guard=outer_guard,
    remaining_caller_wall=outer_remaining_wall,
    cancel=cancel,
)
before = session.snapshot()
attempt = session.query(
    current_pair, full_two_states, actual_cell_rate, cell,
    context=immutable_encoded_role_time_policy_and_sample_context,
    caller_guard=trial_guard,
    remaining_caller_wall=trial_remaining_wall,
    cancel=trial_cancel,
)
after = session.snapshot()
```

The numerical limits above illustrate field names, not a recommendation to replace any registered budget. Root's actual case must declare its own frozen limits before execution. Snapshot has original policy/configuration bytes, original physics bytes, implementation/source hashes, monotonic construction start, cumulative elapsed, all query attempts and cumulative entered/completed counters. A trial's own history range is `len(before.attempts):len(after.attempts)`; do not charge that copied range twice.

`query` returns `PressureQueryAttempt`. A usable radius requires `status == 'proved_conditional_query'`, nonnegative Fraction radius and matching actual request. Otherwise preserve the attempt before propagating its failure. Structured `failure_kind` is one of cancelled/resource_limit/domain_exit/binding_failure/unresolved/callback_failure; classification uses exception classes only. Stage can map the first three to InterruptedError/TimeoutError/DomainExit and the remaining kinds to explicit numerical/binding refusal. Do not inspect reason substrings. Internal primitive failures that lack a structured reason remain unresolved mathematical proof failures; this wrapper does not guess a hidden cause from their prose.

## Original budget and failure semantics

The session deadline begins at **construction**, not at each query. Its elapsed wall includes intervening host evaluations and every gap between queries. Stage wall is separately constrained through each query's additional guard/remaining callback; controller can reuse the same session over all steps/rejections/refinements/independent approaches. There is no reset/begin method. The smaller caller/session remaining wall is passed downward with conservative float conversion.

Seed evaluations and whole proof operations are separate cumulative counts. The five primitives' internal evidence/counters remain retained. Bottom-level residual evaluation count is still unknown. `native_calls=0` means **the session itself makes no additional native queries**, not that the enclosing stage has no native calls.

Every seed callback increments entered before evaluation and completed immediately after the mathematical return; if matrix inversion, source or wall checking then fails, its value and completed cost remain recorded. Ancillary preparation is separately retained; it does not count as an EOS residual evaluation. Successful seeds remain untrusted proposals. A proof is executed afresh for every query; no past PASS cache exists.

Each child result is charged once before any post-child guard. Resource/source/cancel rejection cannot remove earlier query history or spent work. If a child unexpectedly escapes without any returned cost record, the session marks `cost_complete=False` and refuses further work: it does not invent a zero cost or continue with an understated budget. Normal numerical failures return their complete child evidence and leave remaining explicit budgets available. The object refuses reentrant/cross-thread use; it is not a shared global service.

Source changes are checked against construction-time policies, primitive/provider/session code bytes and original pair physics. Only explicit mode/its derived identity are excluded from the reusable physics fingerprint; each query still creates a new actual source/mode-bound request. This does not authorize a mode transition or accept an old certificate. All original inputs/context are saved as immutable bytes; no live provider is exported.

Cancellation is cooperative at the provider/seed guard boundaries. Coexistence/coupled primitive calls remain non-preemptible Python calls; completed overrun work is retained and rejected, not described as hard real-time cancellation. No sys profiler, global production monkey patch, native callback or new material/phase theorem was added.

## Pure validation

Tests import the formal modules. Temporary conftest overlays this directory; its fixtures symlink points to the existing tracked coefficient fixture and is not installed. Tests use the existing synthetic binding/parameter fixture only for orchestration. The real pinned coefficient seed equation is evaluated to obtain an **untrusted proposal**, while the pressure-proof call is deliberately failed. No test fabricates a successful physical pressure certificate.

Coverage: type-based failure category despite misleading reason text; actual seed equation completion; second entered seed failure; completed seed value retained after source change; two failed pressure queries with once-only cumulative costs; depleted seed/proof budgets preventing another query; wall including an intervening host gap; per-trial cancellation/wall stricter than session; source change; unexpected child escape marks unknown cost and stops reuse; strict budget types. Default old provider byte equality is documented by its retained source, not claimed from a fabricated successful query. A separate actual native stage run remains root-owned after review/freeze/install.

No native EOS calls, full stage/controller trajectory, repository edit or install was performed in this task.
