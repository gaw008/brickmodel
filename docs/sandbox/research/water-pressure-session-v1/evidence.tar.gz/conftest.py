from pathlib import Path
import sys
import sludge_sandbox
sludge_sandbox.__path__.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path.cwd()/'tests'/'sandbox'))
