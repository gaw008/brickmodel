"""Independent orchestration negatives, no native calls or successful proof mock."""
from test_mass_wet_pressure_session import seam,session_seam
from test_mass_wet_pressure_interval import control_flow_only
from sludge_sandbox import mass_wet_pressure_session as sessions


def test_changed_original_budget_is_rejected_before_work(session_seam):
    session,pair,request,_,_=session_seam
    original=session.snapshot().original_configuration_json
    object.__setattr__(session._budget,'maximum_seed_evaluations',1000)
    out=session.query(pair,(),request.rate,0,context=b'changed-budget')
    assert out.failure_kind=='binding_failure' and out.seed is None
    assert session.snapshot().original_configuration_json==original
    assert session.snapshot().seed_attempted==0


def test_completed_seed_charged_before_post_child_cancel(session_seam,monkeypatch):
    session,pair,request,_,_=session_seam
    original=sessions.propose_liquid_boxes
    cancelled=[False]
    def complete_then_cancel(*args,**kwargs):
        out=original(*args,**kwargs)
        cancelled[0]=True
        return out
    monkeypatch.setattr(sessions,'propose_liquid_boxes',complete_then_cancel)
    out=session.query(pair,(),request.rate,0,context=b'post-child-cancel',cancel=lambda:cancelled[0])
    assert out.failure_kind=='cancelled' and out.proof is None
    assert out.seed.completed>0
    assert out.cumulative_seed_completed==out.seed.completed
    assert out.cumulative_seed_attempted==out.seed.attempted
    assert out.cost_complete


def test_reentrant_query_rejected_without_erasing_outer_cost(session_seam,monkeypatch):
    session,pair,request,_,_=session_seam
    original=sessions.propose_liquid_boxes
    seen=[]
    def recurse(*args,**kwargs):
        try: session.query(pair,(),request.rate,0,context=b'reentrant')
        except RuntimeError as exc:seen.append(str(exc))
        return original(*args,**kwargs)
    monkeypatch.setattr(sessions,'propose_liquid_boxes',recurse)
    out=session.query(pair,(),request.rate,0,context=b'outer')
    assert seen==['session_single_owner_nonreentrant']
    assert len(session.snapshot().attempts)==1
    assert out.seed.completed>0 and out.cost_complete
