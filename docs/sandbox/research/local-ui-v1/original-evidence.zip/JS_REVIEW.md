# Local UI JavaScript review

Scope: newly added, currently untracked `src/sludge_sandbox/assets/app.js`, `index.html`, `app.css`, inspected with surrounding run-service/provenance response definitions. `git diff --staged` was empty and tracked `git diff` only showed pyproject; explicit task ownership and `git status` establish the new-file scope. This is a local review, not a PR; merge readiness does not apply. No package.json, tsconfig, or ESLint configuration was found in the repository, and eslint was not on PATH. JavaScript-only source: TypeScript check skipped. `node --check src/sludge_sandbox/assets/app.js` passed. No browser or EOS execution performed. Backend is not yet frozen, so endpoint/security review is outside this report.

## HIGH — Provenance persists after switching to a newly submitted run

app.js lines 32 and 40 change `selected` after run/replay/resume but never call `clearTrace()`. Selecting an existing job does clear it (line 56). Reproduction: trace completed run A, open its source artifact, then start B or replay A. B becomes the selected result while section 04 retains A's graph, verified-source message, and artifact. Refresh never changes that section. This is a material source-to-result attribution error in a traceability-first model. Clear and invalidate provenance whenever selected job changes, and display the bound job ID and quantity with trace results.

## MEDIUM — Spatial plot colors disagree with the displayed legend

app.js lines 111–113: the time plot assigns one color per job/cell series, but spatial plot assigns one color per job. The single legend uses the time-series colors. Comparing two 2-cell runs makes spatial run B orange while orange's legend label says run A / cell 2. Add a separate spatial legend or use consistent job coloring plus another cell encoding.

## MEDIUM — Pending artifact response restores a cleared, obsolete trace

app.js line 128 checks only `id !== selected`. Click a source artifact, change quantity while its request is pending, then let it resolve: `clearTrace()` runs on quantity change, but the previous artifact reappears without a corresponding current graph. Two artifact clicks can also complete in reverse order, displaying the first click after the second. Introduce request-generation guards invalidated by selected/quantity/trace changes and capture the selected artifact request identity.

## MEDIUM — Polling removes keyboard focus from job controls

app.js lines 50–61 fully replaces the job list every polling refresh (line 136, every two seconds). A keyboard user focused on a job button or comparison checkbox loses that element as polling removes it. This makes job selection/comparison unreliable without a pointer. Reconcile existing rows by job ID or preserve and restore the focused control and active selection after refresh.

## Reviewed strengths and limitations

Dynamic user/source/error content uses textContent or text nodes, not innerHTML, eval, or executable source rendering. Fetch errors from JSON parsing propagate through action/start/poll catches. Thermal charts show saved endpoints and explicitly avoid interpolated intermediate temperature/pressure claims; conserved-state polylines are labelled discrete connections. Actual browser rendering, contrast, interactive behavior, and frozen endpoint integration remain unverified by this review. Statically observed issues above require fixes/re-review before approval.

## Final static re-review

All four reported findings are resolved in the inspected asset bytes:

- Run/replay/resume and explicit job selection clear and invalidate trace; displayed trace identifies job and quantity.
- Trace and artifact response commits check generation, selected job, and quantity; artifact requests also have separate ordering generations.
- Spatial plot has its own job-level legend using the spatial series color ordering, with corresponding HTML container and CSS.
- Refresh captures focus only inside the job list and restores the same job/control identity with preventScroll after rebuilding it. Focus elsewhere is not stolen.

`node --check` passes again. No remaining HIGH/CRITICAL finding identified in this bounded static review. Approval applies to these static assets only; browser behavior and actual server contracts still require root integration verification. No production changes or Node DOM fixture tests were authored by this reviewer.

Final SHA-256:

- app.js: `910b36d3e2846f205f57d14db6e313083504c37c99ceb11772329819348d2fbd`
- index.html: `f441556bbf5e0ef7b10504a53e64350dca06413ca275e441ea865017598a1bf3`
- app.css: `443e08e1ab1b3be3a547796cbed0ae6c52301b6123944670716635f5cb34d115`

Recommended behavior checks: begin an A trace then select B before its response; begin artifact fetch then change quantity; return two artifact responses in reverse click order; focus a job comparison checkbox then refresh and verify the replacement checkbox retains focus. These checks should exercise the script's public event handlers with delayed fake fetch responses or the actual browser, without asserting implementation generation counters.

## Post-browser visual-fix re-review

Compared source assets against `/private/tmp/brick-local-ui-v1/pre-visual-fix`. Only the declared changes are present: y-axis labels use 8 significant digits instead of 4, and the source button list has max-height 440px with automatic overflow scrolling. These address the reported approximately -197000 J baseline with approximately 10 J variation and long source list without changing numerical data or provenance behavior. No new HIGH/CRITICAL issue identified; approved within this limited static scope. Fixed 8-digit formatting is not a general guarantee that arbitrarily close ticks remain distinct; this review does not claim it is. `node --check` passes. No browser/EOS run by reviewer.

Current SHA-256 superseding the earlier app.js/app.css hashes:

- app.js: `e41a4596233c8cf3781cdfd9e093223a8ea2d02866d28f622f47d7ac183c1c63`
- app.css: `6018ef66198eb305abc218abba1596bfe51210af0228118f582cd2bec839dd9a`
- index.html unchanged: `f441556bbf5e0ef7b10504a53e64350dca06413ca275e441ea865017598a1bf3`

## Export fallback re-review

Compared app.js and index.html against `/private/tmp/brick-local-ui-v1/pre-export-fix`. Export now captures the job ID before awaiting the server and refuses to commit a response for a different current job. The filename and visible report label use that captured identity. Report JSON is rendered through textarea.value and labels through textContent; it cannot inject HTML. A readonly, labelled textarea preserves a copyable report even when the attempted Blob download produces no observable download. Copy/JSON generation is distinguished from browser download confirmation, and the report is explicitly not claimed to be a complete replay bundle. Selection invalidation clears the old panel and text. No new HIGH/CRITICAL findings; approved in bounded static scope. `node --check` passes. Browser download behavior remains root's actual verification scope.

Current SHA-256 superseding previous app.js/index.html hashes:

- app.js: `a8e3dd07d5f417f0bbbcbdbd32f28c8865d12c0b355e3acea27e4dec2555c33d`
- index.html: `ae372af41da7c3c2f3cade68d78ff74023c660d4aa74867606215f52d6f3f7e1`
- app.css unchanged: `6018ef66198eb305abc218abba1596bfe51210af0228118f582cd2bec839dd9a`

## Lossless export and regression review

Reviewed current rawText API branch, export handler, and new `tests/sandbox/ui_export_test.cjs`. Successful raw exports now use Response.text() and pass the returned JSON text directly into textarea.value and Blob. There is no JSON.parse/stringify numeric conversion in this path, so the original server JSON integer tokens are preserved, including Fraction numerator/denominator values exceeding JavaScript's safe integer range. Error responses retain the existing parsed error reporting. Captured job identity is checked after the full response text resolves, before either UI publication or Blob creation.

The two tests exercise the actual registered export handler in a minimal VM environment. The exact-text test verifies both report and Blob contents containing 9007199254740993 and confirms the parsed response path is unused. The delayed-response test changes selected job while export is pending and verifies no old report or Blob is published. These are bounded behavioral regressions, not browser download tests. VM startup's deliberately unresolved config request does not fabricate a successful browser initialization. No HIGH/CRITICAL issues found in this change or its test. Approved.

Reviewer verification: node syntax check passed; `node --test tests/sandbox/ui_export_test.cjs` passed 2/2 tests, 0 failures, reported duration 61.843084 ms. No browser or EOS executed.

Current SHA-256:

- app.js: `97d3cb7a3c17825450ecccfcb56dfb03ebad9763402cedbe3f17bcf357206d25`
- index.html unchanged: `ae372af41da7c3c2f3cade68d78ff74023c660d4aa74867606215f52d6f3f7e1`
- app.css unchanged: `6018ef66198eb305abc218abba1596bfe51210af0228118f582cd2bec839dd9a`
- ui_export_test.cjs: `4c8dde7da97830ec0a8d64f195f8cabbee554a9c3073df50b6949331ffddc3b3`
