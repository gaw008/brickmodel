"""Independent persisted-browser-run audit; no EOS or browser control."""
import json
from pathlib import Path
import traceback
from sludge_sandbox.run_service import read_run
from audit_ledgers import audit
root=Path(__file__).parent
record={'status':'started','jobs':{}}
try:
    results={};resumed=[]
    for directory in sorted((root/'browser-storage/jobs').iterdir()):
        if not directory.is_dir():continue
        job=json.loads((directory/'job.json').read_bytes())
        assert job['status'] in ('completed','cancelled','timed_out')
        assert job['child_reaped'] and job['returncode'] is not None
        item={k:job.get(k) for k in ('operation','status','returncode','child_reaped','elapsed_wall_seconds','hard_killed')}
        record['jobs'][directory.name]=item
        result,manifest=read_run(directory/'run')
        results[directory.name]=(result,manifest)
        steps=result.get('integration',{}).get('steps',[])
        item['accepted_steps']=len(steps)
        if steps:
            path=root/(directory.name+'-ledger-input.json')
            path.write_text(json.dumps({'run':result['integration'],'initial':result['integration']['states'][0]},indent=2))
            item['ledger_audit']=audit(path,{})
        if job['operation']=='resume':
            assert job['status']=='completed' and len(steps)==4
            assert result['resume_ledger_audit']['status']=='passed'
            parent=json.loads((directory/'run/parent/result.json').read_bytes())
            count=len(parent['integration']['steps'])
            assert count>0 and steps[:count]==parent['integration']['steps']
            assert result['integration']['states'][:count+1]==parent['integration']['states']
            assert result['policy']==parent['policy']
            assert result['suffix_policy']['maximum_steps']==result['policy']['maximum_steps']-count
            resumed.append(directory.name)
    first=next(v for k,v in results.items() if k.startswith('57b07404'))
    replay=next(v for k,v in results.items() if k.startswith('db4bf733'))
    for field in ('states','steps','times_s'):assert first[0]['integration'][field]==replay[0]['integration'][field]
    for field in ('initial_snapshot','final_snapshot'):assert first[0][field]==replay[0][field]
    export=json.loads((root/'browser-export-summary.json').read_bytes())
    assert export['integration']==first[0]['integration'] and export['manifest']==first[1]
    assert export['case_sha256']==first[0]['case_sha256'] and export['status']=='completed'
    assert len(results)==7 and len(resumed)==1
    record.update(status='passed',exact_replay=True,browser_report_matches_saved=True,resumed_jobs=resumed)
except Exception as exc:
    record.update(status='failed',reason=str(exc),traceback=traceback.format_exc())
finally:
    (root/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('jobs','traceback')}))
raise SystemExit(0 if record['status']=='passed' else 1)
