"""Check actual imported installed modules against source; no EOS evaluation."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys

root = Path('/Users/wanggaoying/Desktop/brickmodel-github/src/sludge_sandbox')
records = []
for source in sorted(root.glob('*.py')):
    name = 'sludge_sandbox' + ('.'+source.stem if source.stem != '__init__' else '')
    module = importlib.import_module(name)
    actual = Path(module.__file__).resolve()
    assert 'site-packages' in actual.parts, actual
    assert actual.read_bytes() == source.read_bytes(), name
    records.append({'module': name, 'path': str(actual), 'sha256': hashlib.sha256(actual.read_bytes()).hexdigest()})
out = {'cwd': os.getcwd(), 'PYTHONPATH': os.environ.get('PYTHONPATH'), 'python': sys.version, 'modules': records}
Path(sys.argv[1]).write_text(json.dumps(out, indent=2)+'\n')
print(f'{len(records)} actual installed modules match source')
