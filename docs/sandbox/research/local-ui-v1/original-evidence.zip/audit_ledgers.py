"""Independent saved two-cell ledgers, exact arithmetic only; no model imports."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import sys
import traceback


def rational(value):
    if isinstance(value, dict):
        return F(value['numerator'], value['denominator'])
    return F(value)


def audit(path, progress):
    data = json.loads(path.read_text())
    run = data['run']
    initial = data['initial']
    states, steps, times = run['states'], run['steps'], run['times_s']
    assert states[0] == initial
    assert len(states) == len(times) == len(steps)+1
    assert len(initial['amounts_mol']) == 2
    initial_n = [[F(x) for x in row] for row in initial['amounts_mol']]
    initial_u = [F(x) for x in initial['internal_energy_j']]
    nledger = [[F() for _ in range(5)] for _ in range(2)]
    uledger = [F(), F()]
    work_total = F()
    rows = []
    progress['verified_prefixes'] = rows
    max_n = max_u = max_water = max_c = max_carrier = F()
    component_residual = [F(), F()]
    internal_water = internal_heat = False
    for index, (state, step) in enumerate(zip(states[1:], steps, strict=True), 1):
        progress['checking_prefix_index'] = index
        assert step['start_s'] == times[index-1] and step['end_s'] == times[index]
        assert step['end_s'] > step['start_s']
        assert state['energy_model_identity'] == initial['energy_model_identity']
        fn = step['face_species_mol']
        fu = step['face_energy_j']
        rn = step['reaction_species_mol']
        w = step['cell_work_j']
        assert len(fn) == len(fu) == 3
        assert all(x == 0 for row in (fn[0], fn[2]) for x in row)
        assert fu[0] == fu[2] == 0
        internal_water |= fn[1][2] != 0
        internal_heat |= fu[1] != 0
        components = step['cell_work_components_j']
        assert set(components) == {'elastic_deformation','interface_deformation','dissipation','bulk_pressure','body'}
        assert all(v == 0 for v in components['body'])
        local_n_errors, local_u_errors = [], []
        for cell in range(2):
            n = state['amounts_mol'][cell]
            assert all(math.isfinite(v) and v >= 0 for v in n)
            assert n[3] > 0  # This registered experiment is entirely wet.
            for species in range(5):
                nledger[cell][species] += F(fn[cell][species])-F(fn[cell+1][species])+F(rn[cell][species])
                error = F(n[species])-initial_n[cell][species]-nledger[cell][species]
                assert abs(error) <= F(1e-12)
                max_n = max(max_n, abs(error))
                local_n_errors.append(float(error))
            uledger[cell] += F(fu[cell])-F(fu[cell+1])+F(w[cell])
            error = F(state['internal_energy_j'][cell])-initial_u[cell]-uledger[cell]
            assert abs(error) <= F(1e-7)
            max_u = max(max_u, abs(error))
            local_u_errors.append(float(error))
            parts = sum((F(v[cell]) for v in components.values()), F())
            residual = rational(step['component_sum_residual_j'][cell])
            assert parts+residual == F(w[cell])
            component_residual[cell] += abs(residual)
            carbon = F(n[0])+F(n[1])-initial_n[cell][0]-initial_n[cell][1]
            assert abs(carbon) <= F(1e-10)
            max_c = max(max_c, abs(carbon))
            expected_a = float(initial_n[cell][0])*math.exp(-.1*(times[index]-times[0]))
            assert abs(n[0]-expected_a) <= 1e-9
        water = sum((F(row[2])+F(row[3]) for row in state['amounts_mol']), F())
        water -= sum((row[2]+row[3] for row in initial_n), F())
        carrier = sum((F(row[4]) for row in state['amounts_mol']), F())-sum((row[4] for row in initial_n), F())
        assert abs(water) <= F(1e-12) and abs(carrier) <= F(1e-12)
        max_water = max(max_water, abs(water)); max_carrier = max(max_carrier, abs(carrier))
        work_total += sum(map(F, w), F())
        global_energy = sum(map(F, state['internal_energy_j']), F())-sum(initial_u, F())-work_total
        assert abs(global_energy) <= F(2e-7)
        for species in range(5):
            # Opposite uses of one stored internal face cancel exactly.
            assert sum((F(fn[i][species])-F(fn[i+1][species]) for i in range(2)), F()) == 0
        rows.append({'time_s': times[index], 'local_species_errors_mol': local_n_errors,
            'local_energy_errors_j': local_u_errors, 'global_energy_error_j': float(global_energy),
            'global_water_error_mol': float(water), 'global_carrier_error_mol': float(carrier)})
    if 'cumulative_amounts_mol' in run:
        assert [v for row in nledger for v in row] == list(map(rational, run['cumulative_amounts_mol']))
    if 'cumulative_energy_j' in run:
        assert uledger == list(map(rational, run['cumulative_energy_j']))
    if run.get('cumulative_absolute_component_residual_j') is not None:
        assert component_residual == list(map(rational, run['cumulative_absolute_component_residual_j']))
    return {'input': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'solver_status': run['status'], 'accepted_steps': len(steps),
        'trajectory_completed': run['status'] == 'completed',
        'all_saved_prefixes_pass': True, 'internal_water_flux_seen': internal_water,
        'internal_energy_flux_seen': internal_heat,
        'max_local_species_error_mol': float(max_n), 'max_local_energy_error_j': float(max_u),
        'max_global_water_error_mol': float(max_water), 'max_cell_carbon_error_mol': float(max_c),
        'max_global_carrier_error_mol': float(max_carrier), 'prefixes': rows,
        'qualification': 'saved ledger arithmetic; no independent temperature or constitutive oracle'}


if __name__ == '__main__':
    path = Path(sys.argv[1])
    result = {'status': 'started', 'input': str(path)}
    progress = {}
    try:
        result['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        result.update(audit(path, progress), status='prefix_audit_passed')
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc),
            traceback=traceback.format_exc(), partial=progress)
    finally:
        Path(sys.argv[2]).write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('prefixes','partial','traceback')}, indent=2))
    raise SystemExit(0 if result['status'] == 'prefix_audit_passed' else 1)
