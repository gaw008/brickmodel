# Loopback application Python/security review

Disposition: approve the inspected candidate for HTTP and native validation. No concrete CRITICAL or HIGH correctness/security finding identified. No tests, EOS calls or production edits performed by this reviewer.

## Reviewed bytes

- `src/sludge_sandbox/local_app.py`: `2a6f6d969971d96cc997ebe8de549a33715eccd0c746bb7ae9a564aaaa27595d`
- `src/sludge_sandbox/cli.py`: `72e9443616a4ff13029120c0c9b1bf02de22b4862e0dd0dd1976dd6345645f61`
- `pyproject.toml`: `db87e37b879c0d0b169edebedb0a52e753f1fe7b36403997d61f9af282f68ac8`

Reviewed actual diff and complete local_app.py. AST parsing passed for local_app.py and cli.py. Ruff, mypy and black were unavailable on PATH; no static-tool pass is claimed. HTTP tests were still root-owned work at review time and are not claimed validated here.

## Request boundary

The public factory binds only 127.0.0.1. Exact single Host validation rejects alternate/rebound hosts; present Origin headers must match the loopback origin exactly. APIs require exactly one constant-time-checked random token header. Static HTML delivers the token only under the same Host/Origin boundary, with no-store, no-referrer, frame-ancestors none and a self-only script policy. The token is not part of the URL and request logging is suppressed. Browser source/header behavior still requires actual HTTP tests and frontend review.

POST bodies require one Content-Length, no Transfer-Encoding, JSON content type, a one-MiB bound and complete reads. Duplicate JSON keys, nonfinite numbers and nonobject roots are rejected. Sockets have a ten-second timeout. Resource scope is a local research server, not a general adversarial multiuser HTTP service; thread-per-connection is not a global connection/memory quota.

Startup directories are trusted operator configuration. Browser clients supply a validated case or a canonical UUID, not filesystem roots. Job paths reject symlinked job directories. Source browsing first verifies the run manifest, then admits only listed normalized relative paths, rejects escaping/symlink targets, caps the read and verifies its actual SHA after reading. Artifacts are returned as text inside JSON, not served as executable HTML. Manifest integrity does not certify scientific applicability.

## Ownership, cancellation and shutdown

RLock serializes launch admission and closing. Only one owned supervisor thread may be active; the underlying supervisor also enforces its documented parent-directory flock scope. HTTP status separates saved job observations from actual owned-thread liveness. It does not infer a live native process from a stored PID or record. Cancellation sets the owned event and/or writes a job-ID-bound request; it never signals a stored PID.

Non-daemon worker threads delegate child termination/reaping to the reviewed supervisor. Shutdown first marks admission closed, requests cancellation under the lock, releases that lock, and joins workers. It explicitly fails to confirm shutdown if a worker remains alive, rather than reporting successful cleanup. This retains the supervisor's existing OS scheduling and parent-death limitations; it is not a new orphan watchdog.

## CLI and scope

The ui command forwards explicit case/water/evidence/storage configuration and bounded factory port settings; it provides no external bind address. Asset package-data entries include only the declared HTML/CSS/JS assets. Startup returns the loopback URL, not the token. The initial UI configuration explicitly labels manufactured inputs, prescribed motion and unsupported raw-sludge/full-cycle/strength/production uses.

Validation still required from root: actual HTTP Host/Origin/token and body rejection, artifact traversal/hash failures, launch contention and cancellation/close behavior, installed asset availability, frontend rendering/security review, and bounded native interaction. This source review alone establishes none of those executed outcomes and does not establish full Goal completion.

## Final HTTP tests and browser-result verifier review

Read-only review; no HTTP tests, browser actions, verifier execution or EOS calls performed here. AST parsing passed.

- `tests/sandbox/test_local_app.py`: `8e9d2de1d6adb86bd4c118584562f784a2ea6b39c29f4b2d67e7d378f8760aff`
- Experiment `verify.py`: `6fe14ce57de4514d379aae720b4e313a2645de65cb6185963120316f3d80bc80`

The HTTP tests use actual loopback requests for pages/configuration, invalid Host/Origin/token, malformed/nonfinite/duplicate JSON, content-type and size rejection, material exclusion, resource caps, UUID/path checks, manifest export and tampering. Worker dispatch/cancellation/closing tests deliberately use a cooperative fake supervisor; they establish manager-thread behavior, not native child termination. That distinction is explicit and is supplemented by the separate reviewed supervisor tests and native evidence. No blocking test-design finding identified.

The final verifier reads `browser-export-lossless.json` as raw downloaded response bytes and parses them with Python's JSON decoder, which preserves integer numerators/denominators. It compares the entire exported result and manifest with the manifest-verified saved result, rather than checking only a selected quantity or relying on browser JSON.parse/JSON.stringify to preserve large integers. This is complete decoded-JSON value equality, not a claim that the export is byte-for-byte identical to the separately formatted source files. The earlier export failure evidence remains under `pre-lossless-export`; the raw-response export correction is not treated as if the original browser conversion had been lossless.

Replay comparison covers all saved states, steps, times and both initial/final snapshots. Nonempty trajectories undergo the unchanged independent ledger audit. The resume checks preserve parent states and steps, original policy and the remaining maximum-step count, with the production resume audit required to report passed. The script does not separately recompute remaining rejection/wall budgets; those claims require the checkpoint implementation/tests and recorded policies. The general seven-job loop permits the three terminal status kinds rather than enforcing each scenario's exact count, so the standalone verifier must not be overstated as a complete preregistration scenario checker.

The inspected saved verification.json reports passed, exact replay and full export equality. Its seven recorded jobs are: three ordinary completed/replay trajectories of two steps each, one immediate cancellation with zero steps, one timeout with zero steps, one fine cancellation with one step, and one completed resume with four steps. These are recorded observations; this review did not rerun them. The preserved earlier failure directory and lossless export file are present.

Final disposition: approve the reviewed HTTP tests and verifier within the stated scope. No new blocking Python finding. Scientific status remains manufactured verification, not raw-sludge/full-cycle material admission or full Goal completion.

## Narrow verifier closeout
Final verify.py SHA256: `785d49fe7bbd20dc76540bfb5d6fee758d814ec3b66a7bcf2df9064742572e26`; AST parsing passed.
Verified explicit registered job-prefix operation/status/step-count expectations and completed/zero-exit equivalence.
Verified remaining rejection allowance and exact-Fraction conservative remaining/cumulative wall-time checks.
Prior verifier is preserved as verify-before-budget-closeout.py; these additions resolve the preceding coverage qualifications.
Approved within manufactured verification scope; no tests, verifier rerun or native/EOS execution by this reviewer.
