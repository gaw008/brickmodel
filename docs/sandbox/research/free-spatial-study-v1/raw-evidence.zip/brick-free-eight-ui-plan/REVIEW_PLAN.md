# Eight-cell free UI: implementation guidance

Read-only inspection completed. No candidate code authored because this agent's developer role permits review findings only. Root/worker should implement and request independent review before application.

Current behavior and concrete issue:
- assets/index.html grid select contains only 2 and 4.
- app.js fillControls assigns String(caseData.grid.cells) directly. In a real HTML select, assigning 8 without an option clears the selection. controlsToCase then converts the empty value with Number('') to 0 and mutates the case.
- JSON apply validates through /validate before assigning caseData, which is desirable and must remain.
- Backend currently recognizes exact model IDs manufactured_reacting_wet_prescribed_slab_v1 and manufactured_reacting_wet_free_slab_v1 before model-dependent field validation. Current grid gate is still (2, 4) for both models; eight-cell UI depends on coordinated backend support.

Minimal proposed implementation:
1. In fillControls, construct grid choices from the exact validated model ID: free gets [2,4,8], prescribed gets [2,4]. Populate choices before assigning the current numeric cell value. No substring/prefix test for free models.
2. Explicitly reject unknown model IDs and unsupported/missing cell values before changing active case or controls. Do not use fallback model IDs, default cells, Number('') coercion, or reset a free eight-cell case to four implicitly.
3. Keep authoritative /validate before JSON apply acceptance. Validate model/grid locally before committing caseData as a defensive check; an unknown/rejected candidate must leave previous active case and controls intact.
4. controlsToCase should validate selected cells against current model before mutating caseData. Other controls and payload fields must preserve existing behavior. Legacy model remains two/four only.
5. Keep the initial HTML two/four choices or otherwise ensure the eight option cannot be selected before validated free configuration loads. Add brief user-facing text that eight cells require the free model if useful, without claiming material validation.

Required regression evidence against actual app.js:
- Use a select mock implementing real value semantics: setting a value absent from options yields empty string. Plain objects with arbitrary .value cannot detect this bug.
- Startup/fillControls for a free eight-cell case yields selected value '8'; subsequent controlsToCase and submitted/validated JSON retain numeric 8 and the exact free model ID.
- Applying free eight-cell JSON invokes /validate on the unmodified candidate; successful apply populates/selects 8; rejected validation leaves active case and options unchanged.
- Applying prescribed two/four JSON after free eight-cell removes/disables eight appropriately and retains explicitly requested cells. Prescribed eight and unknown model IDs are refused without normalization.
- Selecting free 2/4/8 retains the same remaining physical case data; no hidden change to parent_cells or model ID.
- Empty/invalid select values are refused before mutation/API submission.
- Re-run mechanical plot, trace-handler, and lossless export regressions on the integrated candidate.

No source edits, installs, native activity, or browser activity performed.
