from pathlib import Path
from fractions import Fraction as F
import json
b=Path(__file__).parent
q=lambda z:F(z['numerator'],z['denominator'])
results={}
for name,cells in [('two-fine',2),('eight-fine',8)]:
 r=json.loads((b/name/'result.json').read_text());run=r['integration'];s0=run['states'][0];p=r['policy']
 N=[[F()]*5 for _ in range(cells)];E=[F()]*cells;M=[F()]*(cells+1);Q=[F()]*(cells+1);A=[F()]*(cells+1)
 maxima=dict(N=F(),E=F(),work=F(),mechanical=F(),roundoff=F());cr=ce=F()
 assert len(run['times_s'])==len(run['states'])==len(run['steps'])+1
 for k,(s,l) in enumerate(zip(run['states'][1:],run['steps'])):
  assert l['start_s']==run['times_s'][k] and l['end_s']==run['times_s'][k+1] and l['end_s']>l['start_s']
  assert s['energy_model_identity']==s0['energy_model_identity'] and len(s['mechanical_stretches'])==cells+1 and min(s['mechanical_stretches'])>0
  assert set(l['cell_work_components_j'])=={'external_traction','mechanical_constraint','body'}
  for i in range(cells):
   for j in range(5):
    N[i][j]+=F(l['face_species_mol'][i][j])-F(l['face_species_mol'][i+1][j])+F(l['reaction_species_mol'][i][j]);maxima['N']=max(maxima['N'],abs(F(s['amounts_mol'][i][j])-F(s0['amounts_mol'][i][j])-N[i][j]))
   E[i]+=F(l['face_energy_j'][i])-F(l['face_energy_j'][i+1])+F(l['cell_work_j'][i]);maxima['E']=max(maxima['E'],abs(F(s['internal_energy_j'][i])-F(s0['internal_energy_j'][i])-E[i]))
  for i in range(cells+1):
   M[i]+=F(l['stretch_increment'][i]);z=q(l['stretch_quadrature_roundoff'][i]);Q[i]+=z;A[i]+=abs(z);change=F(s['mechanical_stretches'][i])-F(s0['mechanical_stretches'][i]);maxima['mechanical']=max(maxima['mechanical'],abs(change-M[i]),abs(change-M[i]+Q[i]));maxima['roundoff']=max(maxima['roundoff'],A[i])
  cs=l['cell_work_components_j']['mechanical_constraint'];zs=l['component_quadrature_roundoff_j']['mechanical_constraint'];cr+=abs(sum(map(F,cs),F()));ce+=abs(sum((F(v)-q(z) for v,z in zip(cs,zs)),F()))
  n=list(map(F,s['mechanical_stretches']));de=sum((F(v)-F(z) for v,z in zip(s['internal_energy_j'],s0['internal_energy_j'])),F());v0=F(.0002)/cells;maxima['work']=max(maxima['work'],abs(de+101325*v0*(sum(n[:-1],F())*n[-1]**2-cells)))
 assert maxima['N']<F(p['amount_absolute_tolerance_mol']) and maxima['E']<F(p['energy_absolute_tolerance_j'])
 assert maxima['work']<cells*F(p['energy_absolute_tolerance_j']) and max(maxima['mechanical'],maxima['roundoff'])<F(p['stretch_absolute_tolerance'])
 assert max(cr,ce)<cells*F(p['energy_absolute_tolerance_j'])
 results[name]={'maxima':{k:float(v) for k,v in maxima.items()},'constraint_represented_abs':float(cr),'constraint_exact_abs':float(ce),'times_s':run['times_s'],'policy':p,'rejections':run['rejected_trials']}
(b/'fine-prefix-metrics.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
