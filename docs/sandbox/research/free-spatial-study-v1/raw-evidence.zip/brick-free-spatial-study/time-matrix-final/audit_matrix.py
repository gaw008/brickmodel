"""Run only after all six runs are confirmed terminal; reads sealed files only."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
BASE=Path('/private/tmp/brick-free-spatial-study')
PATHS={
 (2,0):Path('/private/tmp/brick-free-app-native/attempt01'),
 (4,0):BASE/'native-four/attempt01',
 (4,1):BASE/'matrix-next/four-fine',
 (8,0):BASE/'matrix-next/eight-coarse',
 (2,1):BASE/'time-matrix-final/two-fine',
 (8,1):BASE/'time-matrix-final/eight-fine',
}

def read(path):return json.loads(path.read_text())
def restrict(result,cells):
 s=result['integration']['states'][-1];snap=result['final_snapshot'];factor=cells//2
 vals={'N':[],'E':[],'n':[],'T':[],'T_bound':[]}
 for parent in range(2):
  ids=range(parent*factor,(parent+1)*factor)
  vals['N'].extend(sum((F(s['amounts_mol'][i][j]) for i in ids),F()) for j in range(5))
  vals['E'].append(sum((F(s['internal_energy_j'][i]) for i in ids),F()))
  vals['n'].append(sum((F(s['mechanical_stretches'][i]) for i in ids),F())/factor)
  vals['T'].append(sum((F(snap['temperature_k'][i]) for i in ids),F())/factor)
  vals['T_bound'].append(sum((F(snap['inverse_temperature_error_k'][i]) for i in ids),F())/factor)
 vals['t']=[F(s['mechanical_stretches'][-1])]
 return vals

def distance(a,b,key):return max(abs(x-y) for x,y in zip(a[key],b[key],strict=True))

def main():
 runs={};cases={};manifests={};restricted={}
 for key,path in PATHS.items():
  r=read(path/'result.json');m=read(path/'manifest.json');case=read(path/'case.json')
  assert r['status']=='completed' and r['runtime_before']==r['runtime_after'],key
  for name,digest in m['files'].items():assert hashlib.sha256((path/name).read_bytes()).hexdigest()==digest,(key,name)
  assert case['grid']['cells']==key[0] and case['refinement']==key[1]
  assert r['integration']['times_s'][0]==.5 and r['integration']['times_s'][-1]==.5000152587890625
  runs[key]=r;cases[key]=case;manifests[key]=m;restricted[key]=restrict(r,key[0])
 module_differences={}
 baseline=runs[(2,0)]['runtime_before']['modules']
 for key,r in runs.items():
  now=r['runtime_before']['modules'];module_differences[str(key)]=[name for name in sorted(set(now)|set(baseline)) if now.get(name)!=baseline.get(name)]
 # Report, do not silently infer every changed module is non-scientific.
 unexpected={k:[x for x in names if x not in ('verification_case.py',)] for k,names in module_differences.items()}
 assert not any(unexpected.values()),unexpected
 physical={}
 for key,case in cases.items():
  physical[key]={k:v for k,v in case.items() if k not in ('case_id','grid','refinement','numerics')}
 assert all(v==physical[(2,0)] for v in physical.values()),'physical_payload_mismatch'
 temporal={}
 for cells in (2,4,8):
  a,b=restricted[cells,0],restricted[cells,1]
  temporal[cells]={key:distance(a,b,key) for key in ('N','E','n','t','T')}
  temporal[cells]['T_paired_point_bound']=max(x+y for x,y in zip(a['T_bound'],b['T_bound']))
 spatial={}
 for left,right in ((2,4),(4,8)):
  a,b=restricted[left,1],restricted[right,1];row={}
  for quantity in ('N','E','n','t','T'):
   observed=distance(a,b,quantity)
   uncertainty=temporal[left][quantity]+temporal[right][quantity]
   if quantity=='T':uncertainty+=max(x+y for x,y in zip(a['T_bound'],b['T_bound']))
   # Only T has a directly saved propagated point bound. E/N/stretches lack
   # independently certified propagated trajectory uncertainty: no order claim.
   row[quantity]={'difference':float(observed),'temporal_plus_available_point_bound':float(uncertainty),
    'exceeds_10x_available_bound':observed>10*uncertainty,
    'complete_uncertainty_certificate':False}
  spatial[f'{left}-{right}']=row
 centers={}
 for key,r in runs.items():
  face=key[0]//2;steps=r['integration']['steps']
  centers[str(key)]={'H2O_mol':float(sum((F(s['face_species_mol'][face][2]) for s in steps),F())),
   'energy_j':float(sum((F(s['face_energy_j'][face]) for s in steps),F()))}
 report={'module_differences':module_differences,'physical_payloads_identical_excluding_explicit_grid_numerics':True,
  'temporal':{str(k):{q:float(v) for q,v in row.items()} for k,row in temporal.items()},'refined_spatial':spatial,
  'center_face_integrals':centers,'apparent_order':'not reported; unresolved spatial layer and incomplete trajectory uncertainty',
  'runs':{str(k):{'steps':len(r['integration']['steps']),'evaluations':r['integration']['evaluations'],'service_seconds':r['elapsed_seconds'],
   'case_sha256':r['case_sha256'],'result_sha256':manifests[k]['files']['result.json']} for k,r in runs.items()}}
 target=BASE/'time-matrix-final';(target/'matrix-audit-metrics.json').write_text(json.dumps(report,indent=2)+'\n')
 (target/'MATRIX_AUDIT.md').write_text('# Six-run comparison\n\nSee matrix-audit-metrics.json. All six completed sealed results verified. Comparison uses exact extensive parent-bin restrictions and width-weighted normal stretches; common tangent is global. Temperature uses explicitly reference-volume-weighted parent averages with summed weighted inverse bounds. All source byte differences are reported; verification_case changes must retain their independent gate-only review evidence. No same-runtime replay claim. The10x flag uses only available bounds and cannot manufacture a complete trajectory error certificate. No spatial order is asserted. Full wet/fired/cooling physics, source-qualified sludge and experimental validation remain outstanding. No EOS executed by this audit.\n')
 print(json.dumps(report,indent=2))

if __name__=='__main__':main()
