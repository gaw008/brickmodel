"""Focused passive review probes; all observations come from frozen native bytes."""
from dataclasses import replace
from fractions import Fraction as F
from pathlib import Path
import hashlib
import importlib.util
import json
import math

import pytest

from sludge_sandbox.depletion_integration import NestedApproachPolicy
from sludge_sandbox.exact_record import canonical, pack, unpack, _policy
from sludge_sandbox.source_endpoint_comparison import _copy_policy, measure_source_endpoint_pair
from sludge_sandbox.source_net_panel import SavedSourceSample
from test_depletion_integration import policies
from test_pressure_comparison import policy as pressure_policy

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
NATIVE_SHA = '7c0907af104450ffc42cf142e3e3aebefaf21c597eb6806f09b7bdbe6d6d3505'


@pytest.fixture
def pair(monkeypatch):
    spec = importlib.util.spec_from_file_location('independent_saved_decoder', ROOT / 'docs/sandbox/research/source-net-panel-v1/replay_native.py')
    decoder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(decoder)
    for owner, method in ((decoder.ExactSourceColumn, 'evaluate'),
                          (decoder.SourceWetStorage, 'invert'),
                          (decoder.SourceWetStorage, 'evaluate'),
                          (decoder.RigidStorage, 'evaluate_at_temperature'),
                          (decoder.WaterProperties, 'state_tp'),
                          (decoder.HEOSWaterProperties, 'state_tp'),
                          (decoder.WaterChemicalPotential, 'equilibrium_at_liquid_tp')):
        monkeypatch.setattr(owner, method, decoder.reject_physics)
    raw = (ROOT / 'docs/sandbox/research/source-prefix-trial-v1/native-result.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    trial = json.loads(raw)['trial']
    captures = [trial['captures'][i]['fields'] for i in (2, -1)]
    samples = tuple(SavedSourceSample(decoder.decode(c['state']), decoder.decode(c['evaluation']), c['role']) for c in captures)
    inputs = {k: decoder.decode(trial[k]) for k in ('operator_identity', 'energy_identity', 'fixed_dry_mass_kg')}
    return samples, inputs


def test_complete_nested_policy_reuses_existing_codec():
    original = replace(policies()[1], nested_approach=NestedApproachPolicy(maximum_step_s=.01), pressure_comparison=pressure_policy())
    copied = _policy(unpack(pack(original)))
    assert canonical(pack(copied)) == canonical(pack(original))
    for name in ('roundoff_policy', 'nested_approach', 'pressure_comparison'):
        assert getattr(copied, name) is not getattr(original, name)
    assert copied.pressure_comparison.cell_boxes[0] is not original.pressure_comparison.cell_boxes[0]


def test_policy_copy_detaches_pressure_box_and_retains_all_fields():
    original = replace(policies()[1], nested_approach=NestedApproachPolicy(maximum_step_s=.01), pressure_comparison=pressure_policy())
    before = canonical(pack(original))
    copied = _copy_policy(original)
    object.__setattr__(original.pressure_comparison.cell_boxes[0], 'reference_volume_m3', F(999))
    object.__setattr__(original.nested_approach, 'maximum_step_s', .02)
    assert canonical(pack(copied)) == before


@pytest.mark.parametrize('target,field,value', [
    ('roundoff_policy', 'molar_mass_kg_mol', 0.),
    ('roundoff_policy', 'correction_fraction_evaporated', 1e-7),
    ('nested_approach', 'reuse_ordinary_spine', 1),
    ('pressure_comparison', 'schema', 'other'),
    ('box', 'solid_error_m3_mol', (F(-1),)),
    ('box', 'reference_error_m3', 0.),
])
def test_invalid_nested_policy_rejected(target, field, value):
    original = replace(policies()[1], nested_approach=NestedApproachPolicy(maximum_step_s=.01), pressure_comparison=pressure_policy())
    owner = original.pressure_comparison.cell_boxes[0] if target == 'box' else getattr(original, target)
    object.__setattr__(owner, field, value)
    with pytest.raises(ValueError):
        _copy_policy(original)


def test_actual_saved_pair_has_no_new_physics_and_independent_exact_bounds(pair):
    samples, inputs = pair
    out = measure_source_endpoint_pair(*samples, **inputs)
    assert len(out.amount_differences_mol) == len(out.inverse_inputs) == 3
    for row, t, p in zip(out.inverse_inputs, out.temperature_bounds_k, out.reported_pressure_bounds_pa):
        assert t == abs(row[0] - row[4]) + row[1] + row[5]
        assert p == abs(row[2] - row[6]) + row[3] + row[7]
    assert out.comparison_time_offset_s == F()
    out.check()


def test_exact_upper_bound_does_not_round_inward(pair):
    samples, inputs = pair
    changed = []
    for error in (1., math.ulp(0.)):
        original = samples[0]
        cells = tuple(replace(cell, inverse=replace(cell.inverse, temperature_error_bound_k=error))
                      for cell in original.evaluation.source_evaluation.cells)
        raw = replace(original.evaluation.source_evaluation, cells=cells)
        changed.append(replace(original, evaluation=replace(original.evaluation, source_evaluation=raw)))
    out = measure_source_endpoint_pair(*changed, **inputs)
    assert out.maxima[2] == F(1) + F(math.ulp(0.))
    assert out.maxima[2] > F(1) and float(out.maxima[2]) == 1.
    out.check()


def test_declared_fixed_masses_reject_equal_fraction_replacements(pair):
    samples, inputs = pair
    inputs['fixed_dry_mass_kg'] = tuple(F(x) for x in inputs['fixed_dry_mass_kg'])
    with pytest.raises(ValueError):
        measure_source_endpoint_pair(*samples, **inputs)


def test_saved_sample_post_measurement_mutation_rejected(pair):
    samples, inputs = pair
    out = measure_source_endpoint_pair(*samples, **inputs)
    object.__setattr__(samples[0].evaluation.source_evaluation.cells[0].inverse,
                       'temperature_error_bound_k', 1.)
    with pytest.raises(ValueError):
        out.check()


@pytest.mark.parametrize('field,value', [('maxima', (F(),) * 4), ('comparison_time_offset_s', 0.), ('qualification', 'event_ready')])
def test_result_exact_types_and_scope_cannot_be_relabelled(pair, field, value):
    samples, inputs = pair
    out = measure_source_endpoint_pair(*samples, **inputs)
    with pytest.raises(ValueError):
        replace(out, **{field: value}).check()
