"""Bounded source-endpoint review probes; manufactured source hosts, no HEOS."""
from dataclasses import replace
from fractions import Fraction as F
import pytest

from test_source_endpoint_comparison import actual_trials
from test_depletion_integration import policies
from test_pressure_comparison import policy as pressure_policy
from sludge_sandbox.depletion_integration import NestedApproachPolicy
from sludge_sandbox.exact_record import pack
from sludge_sandbox.source_endpoint_comparison import _copy_policy, compare_source_trial_endpoints, measure_source_endpoint_pair


def complex_policy():
    return replace(policies()[1],nested_approach=NestedApproachPolicy(maximum_step_s=.0001,reuse_ordinary_spine=True),
        terminal_method='affine_midpoint',ordered_event_policy='ordered_affine_packet_v1',
        pressure_comparison=pressure_policy())


def test_full_existing_policy_codec_preserves_nested_packet_and_pressure_fields():
    original=complex_policy()
    copied=_copy_policy(original)
    assert pack(copied)==pack(original)
    assert copied is not original and copied.roundoff_policy is not original.roundoff_policy
    assert copied.nested_approach is not original.nested_approach
    assert copied.pressure_comparison is not original.pressure_comparison
    assert copied.pressure_comparison.cell_boxes[0] is not original.pressure_comparison.cell_boxes[0]
    assert copied.ordered_event_policy=='ordered_affine_packet_v1'
    assert copied.nested_approach.reuse_ordinary_spine is True


def test_nested_pressure_box_does_not_bypass_original_validation():
    original=complex_policy()
    object.__setattr__(original.pressure_comparison.cell_boxes[0],'reference_error_m3',F(-1))
    with pytest.raises(ValueError):
        _copy_policy(original)


def test_unearned_event_and_material_claims_fail_rebuild(actual_trials):
    comparison=compare_source_trial_endpoints(actual_trials[0],event_policy=complex_policy())
    for altered in (replace(comparison,event_time_gate='within_tolerance'),
                    replace(comparison,material_qualified=True),
                    replace(comparison,status='source_certified_full_inverse_pressure_enclosure')):
        with pytest.raises(ValueError):
            altered.check()


def test_saved_endpoint_measurements_are_symmetric_and_exact(actual_trials):
    comparison=compare_source_trial_endpoints(actual_trials[1],event_policy=None)
    a=comparison.differences
    b=measure_source_endpoint_pair(*reversed(a.samples),operator_identity=a.operator_identity,
        energy_identity=a.energy_identity,fixed_dry_mass_kg=a.fixed_dry_mass_kg)
    for name in ('amount_differences_mol','energy_differences_j','temperature_bounds_k','reported_pressure_bounds_pa','maxima'):
        assert getattr(a,name)==getattr(b,name)
    assert all(type(v) is F for row in b.amount_differences_mol for v in row)
    assert all(type(v) is F for v in b.maxima)
    assert a.comparison_time_offset_s==b.comparison_time_offset_s==F()
    b.check()


def test_conditional_pressure_identity_for_positive_negative_and_zero_expansion():
    # Pure manufactured differentiable volume: v=a+b*T-c*P. This is algebra,
    # not a liquid EOS or a whole-domain source certification.
    cases=0
    for nl in (F(),F(1,5),F(2)):
        for vt in (F(-1,20),F(),F(1,20)):
            for vp in (F(),F(-1,50),F(-1,5)):
                ng,R,t,p=F(3),F(5),F(4),F(7)
                vg=ng*R*t/p
                D=vg-nl*p*vp
                up=-t*vt-p*vp
                direct=(nl*p*vt+ng*R)/D
                transformed=p/t*(1-nl*up/D)
                assert direct==transformed and D>=vg>0
                declared_B=abs(up)+1
                local=p/t*(1+nl*declared_B/vg)
                Tmin,Pmax=F(3),F(8)
                global_bound=Pmax/Tmin*(1+nl*declared_B*Pmax/(ng*R*Tmin))
                assert abs(direct)<=local<=global_bound
                cases+=1
    assert cases==27
