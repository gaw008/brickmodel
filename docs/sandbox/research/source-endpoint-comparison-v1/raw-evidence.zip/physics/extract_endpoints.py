"""Passive exact endpoint differences and conditional pressure propagation."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
P=Path('/private/tmp/brick-source-prefix-trial-v1/root/native-result.json');OUT=Path(__file__).parent
assert hashlib.sha256(P.read_bytes()).hexdigest()=='7c0907af104450ffc42cf142e3e3aebefaf21c597eb6806f09b7bdbe6d6d3505'
def dec(x):
 if isinstance(x,list):return [dec(y) for y in x]
 if isinstance(x,dict):
  if set(x)=={'numerator','denominator'}:return F(x['numerator'],x['denominator'])
  if set(x)=={'type','fields'}:return dec(x['fields'])
  if 'dtype' in x and 'values' in x:return dec(x['values'])
  return {k:dec(y) for k,y in x.items()}
 return x
def enc(x):
 if isinstance(x,F):return {'numerator':x.numerator,'denominator':x.denominator}
 if isinstance(x,list):return [enc(y) for y in x]
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 return x
r=dec(json.loads(P.read_text()));trial=r['trial'];a=trial['captures'][2];b=trial['captures'][-1]
assert a['time']==b['time']==trial['end'] and a['role']=='prefix_terminal' and b['role']=='reference'
assert trial['reference']['status']=='completed' and b['state']==trial['reference']['states'][-1]
rows=[]
for i in range(3):
 endpoints=[]
 for c in (a,b):
  inverse=c['evaluation']['source_evaluation']['cells'][i]['inverse'];p=inverse['point'];mech=p['fluid']['mechanical'];env=p['fluid']['envelope'];T=F(mech['temperature_k']);P0=F(mech['pressure_pa']);eT=F(inverse['temperature_error_bound_k']);eP=F(p['pressure_error_pa']);nl=F(c['state']['amounts_mol'][i][0]);ng=sum(map(F,c['state']['amounts_mol'][i][1:]),F());R=F(mech['gas_constant_j_mol_k']);B=F(env['liquid_abs_du_dp_bound_j_mol_pa']);Tlo,Thi=map(F,env['temperature_range_k']);Plo,Phi=map(F,env['pressure_range_pa'])
  assert Tlo <=T-eT<=T+eT<=Thi
  def bound(tmin,pmax):return pmax/tmin*(1+nl*B*pmax/(ng*R*tmin))
  L=bound(Tlo,Phi);radius=eP+L*eT;assert Plo<P0-radius<P0+radius<Phi
  # Bootstrap: whole-domain conditional bound first encloses the path; then
  # its enclosing pressure box and the actual T error interval yield tighter L.
  L2=bound(T-eT,P0+radius);radius2=eP+L2*eT;assert radius2<=radius
  endpoints.append({'T':T,'T_error':eT,'P_reported':P0,'P_reported_error':eP,'P_fluid_only_error':F(p['fluid']['pressure_error_bound_pa']),'P_volume_extra':F(p['extra_pressure_error_pa']),'Nl':nl,'Ng':ng,'R':R,'B_uP':B,'envelope_method':env['method'],'envelope_sources':env['source_ids'],'global_conditional_abs_dP_dT':L,'global_conditional_radius':radius,'bootstrapped_conditional_abs_dP_dT':L2,'bootstrapped_conditional_radius':radius2})
 x,y=endpoints
 row={'cell':i,'absolute_N_differences':[abs(F(v)-F(w)) for v,w in zip(a['state']['amounts_mol'][i],b['state']['amounts_mol'][i])],'absolute_U_difference':abs(F(a['state']['internal_energy_j'][i])-F(b['state']['internal_energy_j'][i])),'absolute_T_difference':abs(x['T']-y['T']),'T_difference_plus_errors':abs(x['T']-y['T'])+x['T_error']+y['T_error'],'absolute_reported_P_difference':abs(x['P_reported']-y['P_reported']),'reported_P_difference_plus_errors':abs(x['P_reported']-y['P_reported'])+x['P_reported_error']+y['P_reported_error'],'conditional_full_P_difference_upper':abs(x['P_reported']-y['P_reported'])+x['bootstrapped_conditional_radius']+y['bootstrapped_conditional_radius'],'endpoints':endpoints}
 rows.append(row)
result={'status':'extracted_no_event_tolerance_decision','input_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'time':a['time'],'rows':rows,'pressure_propagation_qualification':'conditional_on_declared_whole_domain_uP_envelope_and_stable_smooth_liquid_branch_not_independently_certified_EOS','event_policy':None}
(OUT/'ENDPOINTS.json').write_text(json.dumps(enc(result),indent=2)+'\n')
print(json.dumps([{k:([float(v) for v in value] if isinstance(value,list) else float(value) if isinstance(value,F) else value) for k,value in row.items() if k!='endpoints'} for row in rows],indent=2))
