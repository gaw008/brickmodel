"""Independent passive review tests; no providers, workers or integration."""
from dataclasses import replace
import json
from pathlib import Path

import pytest

from sludge_sandbox import source_terminal_record as terminal
from sludge_sandbox import source_execution_service as service

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
RAW_TERMINAL = ROOT / 'docs/sandbox/research/source-resume-v1/native01/continuous/trajectory/events/000060.json'


def test_overlimit_committed_history_rejected_before_expanding_digest(monkeypatch):
    wire = json.loads(RAW_TERMINAL.read_bytes())['payload']
    nodes = wire['nodes']
    saved_node = next(node for node in nodes.values() if node['type'] ==
                     'sludge_sandbox.exact_integration_checkpoint.ExactIntegrationCheckpoint')
    original = nodes[saved_node['fields']['observations']['ref']]['values']
    original.extend([original[0]] * (terminal.MAX_OBSERVATIONS + 1 - len(original)))
    # Full JSON roundtrip and actual graph admission, not fabricated Python types.
    raw = json.dumps(wire).encode()
    graph = terminal._Graph(json.loads(raw))
    assert len(raw) < 1024 * 1024 and graph.visits < terminal.MAX_VALUES
    execution = graph.root.values['execution']
    committed = execution.values['committed_checkpoint']
    assert len(committed.values['observations']) == terminal.MAX_OBSERVATIONS + 1
    # Do not execute the unbounded digest on this adversarial record.
    numerical = terminal._materialize(execution.values['result'])
    policy = terminal._materialize(committed.values['problem']).policy
    def forbid_expanded_digest(value):
        raise AssertionError('overlimit_saved_history_reached_unbounded_digest')
    monkeypatch.setattr(terminal, '_digest', forbid_expanded_digest)
    with pytest.raises(ValueError, match='limit|observations|history'):
        terminal._numerical(execution, numerical.states[0], numerical.times_s[0], numerical.times_s[-1], policy)


@pytest.mark.parametrize('raw', [b'{"x":1e999}', b'{"x":NaN}', b'{"x":1,"x":2}', b'[' * 200 + b'0' + b']' * 200])
def test_service_decoder_rejects_nonfinite_duplicates_depth(raw):
    with pytest.raises(ValueError):
        service._decode(raw)


def test_same_distinguishes_boolean_float_zero_and_array_bits():
    import numpy as np
    assert not terminal._same(True, 1)
    assert not terminal._same(0., -0.)
    assert not terminal._same(np.array([0.]), np.array([-0.]))


def test_public_inspection_malformed_inputs_return_unverified(tmp_path):
    target = tmp_path.resolve()
    (target / 'INPUT_BINDING.json').write_text('{"schema":"bad"}')
    report = service.inspect_source_execution(target)
    assert report['record_valid'] is False
    assert report['status'] == 'unverified_result'
    assert report['restore_available'] is False
    assert report['new_eos_calls'] == 0


def test_compact_doubling_wire_refused_before_any_materialization(monkeypatch):
    nodes = {'0': {'type': 'builtins.tuple', 'values': ['leaf']}}
    for i in range(1, 31):
        nodes[str(i)] = {'type': 'builtins.tuple', 'values': [{'ref': str(i-1)}] * 2}
    nodes['31'] = {'type': 'sludge_sandbox.exact_integration_checkpoint.ExactCheckpointRun',
                   'fields': {'result': {'ref': '30'}, 'checkpoint': None,
                              'observations': (), 'committed_checkpoint': None, 'failure': None},
                   'uninitialized_fields': []}
    # The graph only permits tagged containers; None suffices for a field that
    # must not reach materialization because the preceding branch is too large.
    nodes['31']['fields']['observations'] = None
    wire = dict(schema='source_run_raw_projection_v1', root={'ref': '31'}, nodes=nodes,
                numeric_validation_performed=False, resume_authorized=False)
    raw = json.dumps(wire).encode()
    graph = terminal._Graph(json.loads(raw))
    assert len(raw) < 10000 and graph.visits < 100
    def forbidden(value):
        pytest.fail('compact_DAG_reached_constructor_before_expansion_limit')
    monkeypatch.setattr(terminal, '_materialize', forbidden)
    with pytest.raises(ValueError, match='expansion_size_limit'):
        terminal._numerical(graph.root, None, None, None, None)


def test_repeated_array_edges_charge_complete_expanded_cost():
    import numpy as np
    values = np.zeros(1024, dtype=np.float64)
    single = terminal._expansion_limit((values,))
    double = terminal._expansion_limit((values, values))
    assert double == 2 * single - 128
    with pytest.raises(ValueError, match='expansion_size_limit'):
        terminal._expansion_limit((values,) * 3000)


def test_expansion_preflight_accepts_exact_clock_and_original_numeric_body():
    from fractions import Fraction
    from sludge_sandbox.exact_event_clock import ExactEventTime
    assert terminal._expansion_limit(ExactEventTime(Fraction(1, 3))) > 128
    graph = terminal._Graph(json.loads(RAW_TERMINAL.read_bytes())['payload'])
    cost = terminal._expansion_limit(graph.root.values['execution'].values)
    assert 0 < cost <= terminal.MAX_EXPANDED_BYTES


def test_callback_evaluation_dag_refused_before_reify(monkeypatch):
    events = RAW_TERMINAL.parent
    event = next(json.loads(path.read_bytes()) for path in sorted(events.glob('*.json'))
                 if json.loads(path.read_bytes())['event'] == 'rhs_returned')
    wire = event['payload']
    nodes = wire['nodes']
    evaluation = next(node for node in nodes.values() if node['type'] ==
                      'sludge_sandbox.exact_source_column.SourceExactEvaluation')
    states = nodes[evaluation['fields']['source_states']['ref']]['values']
    states.extend([states[0]] * 50000)
    raw = json.dumps(wire).encode()
    graph = terminal._Graph(json.loads(raw))
    candidate = graph.root['evaluation']
    assert len(raw) < 2 * 1024 * 1024 and graph.visits < terminal.MAX_VALUES
    with pytest.raises(ValueError, match='expansion_size_limit'):
        terminal._expansion_limit(candidate)
    def forbidden(*args, **kwargs):
        pytest.fail('callback_DAG_reached_reify_before_expansion_limit')
    monkeypatch.setattr(terminal, 'reify', forbidden)
    with pytest.raises(ValueError, match='expansion_size_limit'):
        terminal._materialize(candidate)
