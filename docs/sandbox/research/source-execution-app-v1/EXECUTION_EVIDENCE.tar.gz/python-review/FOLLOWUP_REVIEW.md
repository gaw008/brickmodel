# Independent follow-up: cover every materialization boundary

The first `_expansion_limit(body)` fix, after exact-clock support was restored, closes the original overlong committed-history digest path. EXPANSION_PROBES01 records 10 passing independent tests, including compact doubling graphs rejected before any materialization, repeated arrays charged for every reference, exact clocks retained, and actual original numeric body accepted.

The same issue remains at `_audit_events` callback evaluation materialization when `_materialize` is called directly without the numeric-body preflight. CALLBACK_RED01.log/xml records a second actual safe wire-level test (1 failed, 10 passed): an original rhs_returned SourceExactEvaluation.source_states tuple retains its original nodes and adds 50000 references to one saved WetMixedState. The full JSON is below 2 MiB and the graph remains under the existing visit limit. The new expansion estimator correctly rejects it, but `_materialize(candidate)` still reaches the intercepted reify call without that check.

Fix: apply expansion preflight at every outermost `_materialize` call (`memo is None`), retaining the shared memo for recursive materialization. This is the same HIGH resource-boundary defect, not a request for general refactoring or a new codec. No large expansion, EOS operation or physical integration was performed.
