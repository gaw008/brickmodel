# Independent Python review — current block

Reviewed source_execution_service.py, source_terminal_record.py, job_supervisor.py and cli.py against 4a8504d, plus the unexecuted native_driver.py and NATIVE_PLAN.md. INPUT_HASHES.json records exact starting content. No production edits, providers, worker launch, native integration, Git mutation or installation performed.

[HIGH] Bound saved history before canonical digest expansion
File: src/sludge_sandbox/source_terminal_record.py:406
Issue: _numerical materializes the committed checkpoint, then calls _digest(committed) before comparing that checkpoint history and observations with the validated terminal result. _digest uses the existing recursive _plain representation and json.dumps, which expand shared graph references. The raw graph limits count distinct array nodes and graph traversal but do not bound the expanded digest. A small record can therefore induce excessive time and memory before it is ultimately rejected for mismatched history.
Fix: Before materialization/digest, check the raw committed history lengths and correspondence to the already validated result, and bound repeated-reference expansion work/bytes. Keep the original checkpoint digest bytes and numerical/material gates unchanged.

Evidence: WIRE_ADMITTED_RED.log/xml is an actual failing sentinel test with a full JSON roundtrip and actual _Graph admission. It extends the original committed observations tuple to 4097 entries by repeating an existing observation; the terminal execution's original observation tuple stays unchanged. The admitted graph is 373424 bytes, below existing limits. The test safely intercepts _digest and demonstrates it is called before rejection. No large expansion is actually allocated. Six other independent decoder/equality/error-path tests pass.

INDEPENDENT_RED.log/xml is the initial equivalent decoded-object reproduction. WIRE_RED and WIRE_FINAL_RED are preserved test-construction failures (an unreachable replacement tuple and an overly small reviewer size assumption), not additional product defects. WIRE_ADMITTED_RED is the valid final wire-level defect evidence.

No other concrete blocker found in source execution service, fixed isolated worker invocation, CLI dispatch, or frozen native journey plan. Saved process facts remain labelled persisted and not live proof; private asset admission is not replaced by software seam tests; controller arithmetic replay and material/full-cycle qualification remain explicitly false. Native journey is still unexecuted.

ruff, mypy, black and pylint are unavailable in the existing runtime. STATIC_CHECKS.json records successful AST parsing; it is not a claim of lint/type-check completion.

Disposition: BLOCK for the exact initial terminal SHA until the bounded digest issue is fixed and independently rechecked.
