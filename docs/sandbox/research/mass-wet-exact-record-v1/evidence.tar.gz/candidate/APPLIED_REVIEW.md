# Application identity and actual capture runner review

Application identity APPROVE: src/sludge_sandbox/mass_wet_exact_record.py SHA8b59ac0b5c1aadf4a71883b511ea69f29eb1add73d44ceef419310bc980e0c75 and tests/sandbox/test_mass_wet_exact_record.py SHA7c53a7a1f9afaca2dbe03db0bff7463cdcad41bac1f050263d790cd2de362a1c equal the final reviewed candidate hashes. No new numerical or scope adaptation identified. No tests or installation repeated.

Runner review pending corrections (actual_record_study/run.py initial snapshot):

- Actual test fixture chain includes test_mass_wet_storage.py, which defines the analytic liquid implementation but is omitted from runtime hashes. Include it.
- Module checking currently enumerates repo *.py and checks each installed file, without exact installed membership comparison. Check installed-vs-repo membership before claiming a complete95-module runtime.
- Preserve canonical(pack(result)) as explicitly raw numerical projection before encode_mixed_run, whose internal read validation can fail before returning record bytes. Current codec failure would retain only controller-status and lose complete diagnostic path evidence.
- Include actual fixture data before/after hashes: data/sandbox/water assets, water-element-convention-v1/facts.json and mass-storage-bridge-v1/gas_molar_mass_facts.json. Actual source validators at construction do not substitute for checking unchanged files after the experiment.

Original binding is correctly captured and written before integration; case embeds original states/request and fixture identity; result explicitly retains partial audit unknowns and no-resume boundary. Installed analytical-fixture trajectory remains manufactured, not native water evidence. No execution, EOS, repository edits or install performed by reviewer. Parent notified of concrete runner corrections before actual run.

## Runner revision readback

Confirmed added analytic fixture hash, exact installed module membership at entry, all actual water/facts hashes, and full diagnostic plus unvalidated packed result saved before codec. A final narrow request remains: compare installed-module and water-asset membership again at exit, so newly introduced files cannot escape existing-key rehash checks. No execution performed.

## Final runner disposition

APPROVE runner b17220efbc94b375ced5bcc575e6a4c1ebee3576e09b5a12470c1bda41d62c28. Final readback confirms module_names and recursive water_names are captured before execution and both exact sets are compared in finally along with every file hash. EXECUTION_FREEZE script SHA matches actual bytes. All previously reported runner corrections are closed. Source/test application remains exact8b59ac0b/7c53a7a1. This approval covers the single installed manufactured analytical-fixture capture and explicit partial-audit/no-resume scope only. The ongoing parent process was not polled, interrupted or rerun by this reviewer; no result claim is made here.
