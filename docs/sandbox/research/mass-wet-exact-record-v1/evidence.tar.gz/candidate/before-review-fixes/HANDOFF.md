# Mixed controller record candidate

This is a new mixed kg-solid / mol-fluid data schema, not a relabelled molar-solid codec. It preserves all dataclass fields of the actual controller result and nested numerical evidence. A fixed class registry has no dynamic imports or arbitrary object construction. WetPair is deliberately reduced to its recorded constructor identity and modes; its original source content is separately captured before the run. Live providers, caches and callbacks are not exported.

`float_hex`, reduced rational pairs and ExactEventTime records preserve numeric values without JavaScript-number conversion. Reading yields immutable numeric Nodes; export returns the exact original canonical JSON bytes as text. This is not a solver-state restore API and has no resume admission.

## Minimal call sequence

```python
from sludge_sandbox.mass_wet_exact_record import (
    capture_binding, encode_mixed_run, read_mixed_run,
    audit_mixed_record, export_mixed_record,
)
from sludge_sandbox.mass_wet_exact_controller import integrate_mixed_exact

# pair, initial, exact start/end and ORIGINAL policies are already constructed.
# args has start, end, stage_policy, roundoff_policy,
# original_liquid_fraction_limit, controller_policy, constant_liquid_fixture.
# runtime_before is the actual complete runtime manifest; case_sha256 is the
# hash of retained original case bytes. Never substitute a successful-run label.
expected_binding = capture_binding(
    pair, initial, case_sha256=case_sha256,
    runtime_identity=runtime_before, **args,
)
# Save expected_binding separately and pin its SHA BEFORE the solver call.
result = integrate_mixed_exact(pair, initial, **args)
raw = encode_mixed_run(result, original_binding=expected_binding)
# Save raw BEFORE audit/assertions, including a failed or cancelled result.
record = read_mixed_run(raw, expected_binding=expected_binding)
audit = audit_mixed_record(record, expected_binding=expected_binding)
assert export_mixed_record(record).encode('utf-8') == raw
# audit.status is intentionally 'partial_audit'; resume_allowed is False.
```

`capture_binding` performs only existing source/state guards; it makes no EOS calls. `runtime_identity` is a nonempty externally supplied mapping: callers must retain actual module/source hashes and independently verify before/after stability. The external original binding must come from that retained capture, not be recreated from the untrusted run file. When running this candidate before installation, record its exact source SHA separately as part of that external runtime manifest; do not claim a previous runtime automatically covers a new verifier. The pure tests explicitly label their synthetic runtime metadata.

## Offline checks actually implemented

Fresh canonical-byte parsing on every audit, including manually forged frozen wrappers. Exact field sets, supported tags/classes, type-sensitive numeric decoding, complete original request and external binding equality. Policies are reconstructed through their existing pure validation constructors.

Every recorded refinement path, including uncommitted failed paths: exact increasing times, original initial/end binding, two-cell kg/Nl/Ng/U shape, full signed component key set, represented/exact integral/roundoff identities, original per-unit local and original-prefix cumulative budgets, cumulative absolute quadrature and U-component residual budgets. Every retained projection is recomputed with the existing pure `project_mixed_depletion`, rebuilding original-cell cumulative totals from preceding projections once. Context initial/time/policy/source/fraction, frame/ledger/projected-state association, and old-to-new mode/operator lineage are checked. Empty correction histories must have empty totals. Final accepted history/operator/totals/frames equal the selected main path; failed runs publish no speculative path or correction.

Refinement roles/levels and original terminal controls, explicit coarse anchor, the recorded six nonnegative exact differences versus original gates, two successive pass roles followed by an independent approach, halved controls and distinct recorded pre-first grids. Whole cumulative counter sums and original resource limits; observation journal completion/cost association. This checks saved cost consistency, not an independent native EOS call journal.

## Explicit unknowns / limits

The returned status is always `partial_audit`, never full verification or resume authorization. Unknown checks are retained in the returned report:

- independent physical-provider and external source authentication;
- complete recomputation of event/common six numerical differences from actual inverse/provider evidence;
- full all-candidate root-order and whole-panel proof replay;
- native physical validation;
- resume admission.

A saved PASS string alone is not considered proof of these unknown checks. Supplied source declarations and numerical sample values are not authenticated merely because their bytes are canonical. Projection replay uses the existing reviewed pure mathematical helper; it is not a second independent derivation of its equations.

The model remains the existing autonomous manufactured constant-liquid pressure contract. No implicit generic wet/HEOS pressure admission, no scientific gate changes, no new mode-transition permission, no whole physical wet-to-fired/material claim, no service or legacy codec changes. Only the single atomic-packet controller's present layout is supported.

## Validation and files

Production candidate: `mass_wet_exact_record.py`; portable test: `test_mass_wet_exact_record.py` importing `sludge_sandbox.mass_wet_exact_record`. Temporary-only `conftest.py` adds the candidate package path and existing test fixture path; it must not be installed. Tests use the already-applied controller with native water disabled by the existing analytic fixture. Short actual resource, stage and post-terminal domain failures exercise the real stored numerical structure; the complete 57-second controller experiment was not repeated.

Run from repository root:

```
PYTHONPATH=src /private/tmp/brick-water-backend-probe/venv/bin/python -m pytest -q /private/tmp/brick-mass-wet-integration-v1/exact_controller_record/test_mass_wet_exact_record.py
```

Original tests01–05 failures are preserved (missing explicit nested data classes and Literal decoder handling). Tests06–09 are subsequent results, not overwritten failures. Static ruff/black/mypy executables and modules were unavailable in the current test environment. No repository edits, installation or native EOS run was performed.
