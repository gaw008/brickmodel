from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_mass_wet_exact_record import capture
from sludge_sandbox.mass_wet_exact_record import *
from sludge_sandbox.mass_wet_writeback import MixedWritebackTotals


def test_retained_actual_attempts_cannot_have_zero_charged_cost(monkeypatch):
    result,binding=capture(monkeypatch,3)
    assert result.refinements[0].path.attempts
    zero=tuple((k,0) for k,v in result.costs)
    fake=replace(result,costs=zero,refinements=tuple(replace(ref,costs=zero) for ref in result.refinements))
    with pytest.raises(MixedRecordError):
        audit_mixed_record(read_mixed_run(encode_mixed_run(fake,original_binding=binding)),expected_binding=binding)


def test_failed_global_totals_keep_original_time_fraction_policy(monkeypatch):
    result,binding=capture(monkeypatch)
    altered=replace(result.roundoff_totals.context,original_liquid_fraction_limit=F('1e-9'))
    fake=replace(result,roundoff_totals=MixedWritebackTotals.empty(altered))
    with pytest.raises(MixedRecordError):
        audit_mixed_record(read_mixed_run(encode_mixed_run(fake,original_binding=binding)),expected_binding=binding)


def test_ordinary_path_storage_identity_cannot_change(monkeypatch):
    result,binding=capture(monkeypatch,10)
    ref=result.refinements[0];path=ref.path
    assert len(path.states)>1
    states=list(path.states);row=list(states[-1]);row[0]=replace(row[0],energy_model_identity='f'*64);states[-1]=tuple(row)
    fake=replace(result,refinements=(replace(ref,path=replace(path,states=tuple(states))),*result.refinements[1:]))
    with pytest.raises(MixedRecordError):audit_mixed_record(read_mixed_run(encode_mixed_run(fake,original_binding=binding)),expected_binding=binding)
