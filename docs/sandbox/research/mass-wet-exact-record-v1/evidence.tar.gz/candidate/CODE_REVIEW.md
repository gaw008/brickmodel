# Independent mixed record review — changes required

Reviewed source8652a68d98a05c93665681354caa7fd419f1c95c5992a5824fb4688dcfe48231, test60d6ce42532474334e1879421f4ad12f6e0b37905e85dc8c4c035de237ef5d82, HANDOFF and actual nested types. Original13 tests independently pass. No native EOS, installation, repository edits or complete57s controller execution. All attacks use short actual controller failure paths.

[HIGH] Failed global correction context is not fully bound
File: mass_wet_exact_record.py, audit_mixed_record failed branch
Issue: changing global roundoff_totals.context.original_liquid_fraction_limit from original1e-8 to1e-9 and rebuilding empty totals is accepted by encode/read/audit. The branch only binds original_states/operator_identity. Time, original policy, source labels and fraction must also retain original request values, including zero-correction failures. Runnable review_attack_test.py and review-red.xml/log preserve actual DID NOT RAISE.
Fix: validate full global original context and its current operator lineage before checking empty or accumulated totals.

[HIGH] Ordinary path state can change storage identity
File: mass_wet_exact_record.py, audit_path state loop
Issue: a real short path with an ordinary accepted step still passes audit after changing one endpoint energy_model_identity to another valid64hex digest. Numerical conservation does not establish correct caloric/reference interpretation. Existing modes do not change the per-cell storage model.
Fix: bind every cell's path-state energy_model_identity to the corresponding original cell identity. Actual review-model-red.xml/log retain the failed negative control.

Scope review: explicit unknown_checks correctly leaves full numerical comparison recomputation, all-root replay and physical provider authenticity unproved. These two findings are within the codec's claimed original-context/storage consistency, not requests for those deferred proofs. Whole cost-zero attack was correctly rejected and is not a finding. Canonical reparsing, immutable decoded numeric nodes and explicit kg/mol separation otherwise agree with documented scope; no legacy/resume admission is introduced.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 2 | warn |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: WARNING — resolve both HIGH findings before adopting this audit candidate. Author notified; final revision pending.

# Final revision review

APPROVE source8b59ac0b5c1aadf4a71883b511ea69f29eb1add73d44ceef419310bc980e0c75 / test7c53a7a1f9afaca2dbe03db0bff7463cdcad41bac1f050263d790cd2de362a1c for its documented partial offline audit. Both HIGH findings closed. Original report and failed evidence above remain historical.

Read exact diff from retained8652 bytes. validate_context binds all seven fields (original states/time, full policy, source labels, molar mass, original fraction, operator identity). It is invoked for failed global totals, successful global totals, each projection before mode change, and each path's final context after the actual recorded lineage. Every cell of every retained path state now matches its corresponding original energy_model_identity. No tolerance, physical assumption or unknown-check qualification changed.

Independently reran original expanded18 tests plus all3 reviewer controls against the final source:21 passed, review-final.log/XML. This includes previously failing original-fraction and ordinary-state identity attacks. No full57s controller, native EOS, installation, or repository edit.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — partial consistency audit only; original explicit unknown checks and no-resume boundary remain required.
