"""Continue from saved raw record, never restart the completed controller."""
from pathlib import Path
from dataclasses import asdict
import json,hashlib,time
from sludge_sandbox.mass_wet_exact_record import read_mixed_run,audit_mixed_record,export_mixed_record,canonical,pack
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    begun=time.monotonic();out=ROOT/'replay01';out.mkdir(exist_ok=False)
    runtime=json.loads((ROOT/'runtime-before.json').read_text())
    assert all(sha(Path(p))==h for p,h in runtime.items())
    installed={str(Path(p).parent) for p in runtime if 'site-packages/sludge_sandbox/' in p}
    assert len(installed)==1
    assert {str(p) for p in Path(next(iter(installed))).glob('*.py')}=={p for p in runtime if 'site-packages/sludge_sandbox/' in p}
    water=Path('/Users/wanggaoying/Desktop/brickmodel-github/data/sandbox/water')
    assert {str(p) for p in water.rglob('*') if p.is_file()}=={p for p in runtime if p.startswith(str(water)+'/')}
    paths=[ROOT/'record.json',ROOT/'original-binding.json',ROOT/'runtime-before.json',ROOT/'result.json',Path(__file__)]
    frozen={str(p):sha(p) for p in paths};(out/'freeze.json').write_text(json.dumps(frozen,indent=2))
    report={'status':'started','scope':'saved numeric record partial consistency; no solver or EOS call'}
    try:
        raw=(ROOT/'record.json').read_bytes();binding=(ROOT/'original-binding.json').read_bytes()
        record=read_mixed_run(raw,expected_binding=binding)
        audit=audit_mixed_record(record,expected_binding=binding)
        (out/'audit.json').write_bytes(canonical(pack(asdict(audit))))
        exported=export_mixed_record(record).encode();(out/'exported.json').write_bytes(exported)
        assert exported==raw and audit.status=='partial_audit' and not audit.resume_allowed and audit.accepted_steps==18
        report.update(status='passed_saved_partial_audit',audit_status=audit.status,accepted_steps=audit.accepted_steps,unknown_checks=list(audit.unknown_checks),resume_allowed=audit.resume_allowed,record_bytes=len(raw),record_sha256=hashlib.sha256(raw).hexdigest(),export_identical=True)
    except Exception as exc:report.update(status='failed',exception=type(exc).__name__,reason=str(exc))
    report['runtime_unchanged']=all(sha(Path(p))==h for p,h in runtime.items()) and {str(p) for p in Path(next(iter(installed))).glob('*.py')}=={p for p in runtime if 'site-packages/sludge_sandbox/' in p} and {str(p) for p in water.rglob('*') if p.is_file()}=={p for p in runtime if p.startswith(str(water)+'/')}
    report['saved_inputs_unchanged']=all(sha(p)==h for p,h in ((Path(n),h) for n,h in frozen.items()))
    if not report['runtime_unchanged'] or not report['saved_inputs_unchanged']:report['status']='failed'
    report['elapsed_seconds']=time.monotonic()-begun
    (out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
    if report['status']!='passed_saved_partial_audit':raise SystemExit(1)
if __name__=='__main__':main()
