"""One actual manufactured two-event controller trajectory, installed record API."""
from pathlib import Path
import importlib,hashlib,json,sys,time,os
from fractions import Fraction as F
from dataclasses import asdict
import pytest
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')
sys.path.insert(0,str(REPO/'tests/sandbox'))
from test_mass_wet_exact_controller import setup
from test_mass_wet_exact_stage import fixture,policy
from sludge_sandbox.mass_wet_exact_controller import integrate_mixed_exact
from sludge_sandbox.mass_wet_exact_record import capture_binding,encode_mixed_run,read_mixed_run,audit_mixed_record,export_mixed_record,canonical,pack
from sludge_sandbox.exact_event_clock import ExactEventTime as T

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    with (ROOT/name).open('xb') as f:f.write(data)
def main():
    begun=time.monotonic();runtime={}
    installed_dir=Path(importlib.import_module('sludge_sandbox').__file__).resolve().parent
    module_names={p.name for p in installed_dir.glob('*.py')}
    water_names={str(p) for p in (REPO/'data/sandbox/water').rglob('*') if p.is_file()}
    assert module_names=={p.name for p in (REPO/'src/sludge_sandbox').glob('*.py')}
    for p in sorted((REPO/'src/sludge_sandbox').glob('*.py')):
        name='sludge_sandbox' if p.stem=='__init__' else 'sludge_sandbox.'+p.stem
        actual=Path(importlib.import_module(name).__file__).resolve()
        assert 'site-packages' in actual.parts and sha(actual)==sha(p)
        runtime[str(actual)]=sha(actual)
    for name in ('test_mass_wet_exact_controller.py','test_mass_wet_exact_stage.py','test_mass_wet_transport.py','test_mass_wet_storage.py','test_mass_storage_bridge.py'):
        p=REPO/'tests/sandbox'/name;runtime[str(p)]=sha(p)
    for p in sorted((REPO/'data/sandbox/water').rglob('*')):
        if p.is_file():runtime[str(p)]=sha(p)
    for name in ('water-element-convention-v1/facts.json','mass-storage-bridge-v1/gas_molar_mass_facts.json'):
        p=REPO/'data/sandbox/research'/name;runtime[str(p)]=sha(p)
    runtime[str(Path(__file__))]=sha(Path(__file__))
    write('runtime-before.json',json.dumps(runtime,indent=2).encode())
    result=None;report={'status':'started','scope':'actual manufactured analytic-liquid two-event controller; partial record consistency only; no native or resume'}
    monkey=pytest.MonkeyPatch()
    try:
        pair,initial,rp,cp=setup(monkey)
        args=dict(start=T(F()),end=T(F(1,2000)),stage_policy=policy(),roundoff_policy=rp,original_liquid_fraction_limit=F('1e-8'),controller_policy=cp,constant_liquid_fixture=fixture(pair))
        case=canonical(pack({'definition':'existing frozen manufactured analytic-liquid controller fixture','original_states':initial,'request':{k:v for k,v in args.items() if k!='constant_liquid_fixture'},'fixture_source_sha256':runtime[str(REPO/'tests/sandbox/test_mass_wet_exact_controller.py')]}))
        write('case.json',case)
        binding=capture_binding(pair,initial,case_sha256=hashlib.sha256(case).hexdigest(),runtime_identity=runtime,**args)
        write('original-binding.json',binding)
        result=integrate_mixed_exact(pair,initial,**args)
        report.update(controller_status=result.status,controller_reason=result.reason,accepted_steps=len(result.steps),events=sum(len(x) for x in result.packets),controller_costs=dict(result.costs),controller_elapsed_seconds=result.elapsed_seconds)
        write('controller-status.json',json.dumps(report,indent=2).encode())
        write('controller-diagnostic.txt',repr(result).encode())  # Diagnostic only, saved before codec; not replay input.
        write('packed-result.json',canonical(pack(result)))  # Unvalidated projection, preserved before record checks.
        raw=encode_mixed_run(result,original_binding=binding);write('record.json',raw)
        record=read_mixed_run(raw,expected_binding=binding)
        audit=audit_mixed_record(record,expected_binding=binding)
        write('audit.json',canonical(pack(audit)))
        exported=export_mixed_record(record).encode();write('exported.json',exported)
        assert exported==raw
        assert result.status=='completed' and len(result.steps)==18 and sum(len(x) for x in result.packets)==2
        assert audit.status=='partial_audit' and not audit.resume_allowed and audit.accepted_steps==18
        report.update(status='completed_record_study',record_bytes=len(raw),record_sha256=hashlib.sha256(raw).hexdigest(),audit_status=audit.status,unknown_checks=list(audit.unknown_checks))
    except Exception as exc:report.update(status='failed',exception=type(exc).__name__,reason=str(exc))
    finally:
        monkey.undo()
        after={p:sha(Path(p)) for p in runtime};write('runtime-after.json',json.dumps(after,indent=2).encode())
        report['runtime_unchanged']=after==runtime and module_names=={p.name for p in installed_dir.glob('*.py')} and water_names=={str(p) for p in (REPO/'data/sandbox/water').rglob('*') if p.is_file()}
        if not report['runtime_unchanged']:report['status']='failed'
        report['elapsed_seconds']=time.monotonic()-begun
        write('result.json',json.dumps(report,indent=2).encode())
    print(report)
    if report['status']!='completed_record_study':raise SystemExit(1)
if __name__=='__main__':main()
