# Saved-record continuation of failed wrapper

Original capture remains FAILED: result.json records controller completed18steps/2events/396evaluations in29.812729791010497s, but reporting raised unsupported_record_type:MixedReplayAudit; total42.2420968330116s. Original code places this failing report serialization after audit_mixed_record returned, so this is the research wrapper's output-type mismatch, not a production codec rejection. The actual source/runtime stayed unchanged.

Independent stdlib-only availability check (review-record-availability.json): record40763391bytes, SHA52bef9f423a93ffa4917966ab9fd67fa14f51ba49670392ce050d1174d1797a8 is canonical JSON; its binding exactly equals retained original-binding.json; its entire result equals packed-result.json; before/after manifests match and contain95 installed modules. Record has18steps/19states/one packet. No production audit/controller/EOS executed by reviewer.

replay_saved.py reads the original raw record and separately retained external binding, runs only read/audit/export, and uses canonical(pack(asdict(audit))) to serialize the ordinary report dataclass as a mapping. This conversion preserves every report field and does not alter record bytes or audit gates. A new-only replay01 directory and input/script hashes retain original failure evidence. Exact export equality and partial_audit/resume_allowed=false remain required. It is not solver continuation or resume.

The wrapper fix is approved in substance. Final narrow integrity request sent to parent: duplicate entry module/water membership verification at exit, alongside existing-key hash checks, before claiming unchanged full runtime. Pending readback of that tail only; no need for another trajectory or production-code change.

Final source readback: APPROVE replay_saved.py SHAbd39f428b094e233bbdfa1ab1bee5dcc84e22e9bbd5f95160f2085e42759d7ef. Exit now compares installed-module and recursive water-asset membership plus all hashes, closing the final request. Actual replay result not yet assessed in this code-review section.

# Final saved replay result review

APPROVE bounded saved-record result evidence. Parent replay finished successfully; saved result elapsed9.590763583983062s. Independently inspected audit/report and compared export bytes with original record:40763391bytes, identical SHA52bef9f423a93ffa4917966ab9fd67fa14f51ba49670392ce050d1174d1797a8. Parsed audit reports18 accepted steps,4 refinements,80 checked path steps and8 projection replays, explicitly partial_audit and resume_allowed=false. All five unknown checks remain present and equal between audit and report; no result elevates them to verified.

Independently rehashed original95 installed modules, all recorded fixture/data/runner files, exact installed-module and water-directory memberships, original before/after manifests, and all replay freeze inputs. All match. See replay01/independent-result-review.json. This verification used stdlib JSON/bytes/hashes only, not production audit rerun, solver, EOS or install.

Original controller capture wrapper result.json remains FAILED with unsupported_record_type:MixedReplayAudit; that failure is neither deleted nor relabelled. Separate replay01 proves the saved numeric record can be partially audited and exported losslessly after fixing only the report serialization wrapper. Neither result grants physical-provider authentication, complete six-gate/root-proof recomputation, native validation or resume admission.
