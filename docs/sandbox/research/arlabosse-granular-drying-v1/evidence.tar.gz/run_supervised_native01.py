"""Execute the one registered contact-drying experiment after source freeze."""
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
SCRATCH = Path('/private/tmp/arlabosse-granular-drying-v1')
PYTHON = Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python')
INSTALLED = PYTHON.parent.parent/'lib/python3.12/site-packages/sludge_sandbox'
SUPERVISOR = ROOT/'docs/sandbox/research/research-process-supervisor/supervisor.py'
spec = importlib.util.spec_from_file_location('granular_research_supervisor', SUPERVISOR)
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)
inputs = {Path(__file__).resolve(), SCRATCH/'native_driver.py', SCRATCH/'NATIVE_PLAN.md',
          SCRATCH/'install/SOURCE_FREEZE.json', SUPERVISOR}
source = ROOT/'data/sandbox/research/arlabosse-granular-drying-v1/source.json'
inputs.add(source)
definition = json.loads(source.read_bytes())
inputs.update(ROOT/a['path'] for a in definition['assets'])
wet = ROOT/definition['thermal_upstream']['path']
inputs.add(wet)
definition = json.loads(wet.read_bytes())
inputs.update(ROOT/a['path'] for a in definition['assets'])
for upstream in definition['upstream']:
    path = ROOT/upstream['path']
    inputs.add(path)
    inputs.update(ROOT/a['path'] for a in json.loads(path.read_bytes())['assets'])
for name in ('IAPWS95-2018.pdf', 'iapws-1.5.5-py3-none-any.whl', 'iapws-1.5.5-iapws95.py',
             'iapws-1.5.5-LICENSE', 'source_facts.json'):
    inputs.add(ROOT/'data/sandbox/water'/name)
for directory in (ROOT/'src/sludge_sandbox', INSTALLED, INSTALLED.parent/'iapws'):
    inputs.update(p for p in directory.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and p.suffix != '.pyc')
result = supervisor.run_attempt(SCRATCH/'supervised-native01',
    ['/usr/bin/env', '-u', 'PYTHONPATH', str(PYTHON), '-I', str(SCRATCH/'native_driver.py')],
    cwd='/private/tmp', input_paths=sorted(inputs), timeout_s=80., cleanup_grace_s=5.)
print(json.dumps({k: v for k, v in result.items() if not k.startswith('inputs_')}, indent=2))
sys.exit(0 if result['status'] == 'complete' and result['returncode'] == 0 else 1)
