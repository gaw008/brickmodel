# Granular contact-drying native01: preregistered conditional experiment

No actual EOS/thermal trajectory has run for this new model. The source law is
Eq3, F=34.38W+4.58 kg water/(m2 h), retaining b. A and dry mass are explicit
virtual designs, not inferred original experimental loading. Applying the rate
at this controlled temperature/gas condition has unknown model error.

Freeze the reviewed package, noneditable-install it, and compare every source
and installed package file. Use installed Python -I outside the repository,
with PYTHONPATH removed. Preserve all failed attempts and original thresholds.

Exactly one physical evaluation: md=.1 kg dry, A=.02 m2 nominal heated area,
Tcontrol=363.15 K (90 Celsius), external pv=1000 Pa, total/liquid P=100000 Pa,
Wi=.32 to Wf=.15, 12 equal moisture reporting intervals. The analytic t(W)
predicts the path's model clock. Output sampling is not an ODE integrator/time
step or proof of time convergence. No arbitrary temperature-rate factor.

Run API wall limit 30 s; entire driver limit 60 s checked between finite work;
external original-process-group supervisor 80 s and 5 s cleanup. One attempt,
no automatic retry. Save raw result before asserting completion/numerical gates.

Independent references and thresholds, fixed before observation:

- Original rational Arlabosse95 facts SHA543d55918db7df6d0cc0f695c5dceadbdebda82b83f4fdde206266bcd12f2f16.
  Integrate the original six q95 nodes with Fraction, retaining independent
  intervals, not the model's heat method. Evaluate a separate existing water
  provider at 90 and95 Celsius using the same declared water reference, to
  obtain hl,hv and deltaL. These two reference property calls are additional
  actual water evaluations, not independent validation of the water EOS.
- Clock from 60-digit Decimal ln and original a/b: absolute error <=1e-9 s.
  Flux from Decimal source equation and explicit area/3600: <=1e-14 kg/s.
- At every observed W, heat Q=md*(integral[W,Wi]q95+deltaL*(Wi-W)), outgoing
  enthalpy=md*(Wi-W)*hv90, waterout=md*(Wi-W). Heat/enthalpy <=1e-5 J, water
  <=1e-12 kg. Required power=flow*(q95(W)+deltaL), <=1e-7 W.
- Recompute each reported H from original dry Cp integral from95 to90 Celsius,
  W*hl90 and Hex=integral[.8,W](L95-q95) with original Fraction nodes; total
  target/recovered H difference from that independent reference <=1e-5 J.
- Compare actual inverse T to control90 Celsius: <=1e-6 K. All local and
  whole-prefix target/recovered energy balances <=1e-5 J and water balances
  <=1e-12 kg, including initial and final rows. These are numerical gates,
  not statistical/material error tolerances.
- Times strictly increase; W strictly decreases, exact requested endpoints;
  all13 observations present. Actual terminal must be completed, no pending
  trial. Positive model q/flow/power. Source and all thermal rows retain false
  qualification and unknown errors. Boundary pv below saved model equilibrium
  pressure throughout. Driver records no prediction of wall/gas response.
- Negative arithmetic controls, no second EOS run: omitting b must differ
  from the retained-b terminal clock by >1e-9 s; adding latent heat a second
  time must violate the same1e-5 J energy threshold.

Source/installed package, source metadata/assets and scientific runtime records
must remain unchanged; saved before/after fingerprints checked. An independent
read-only review may recompute saved arithmetic, without rerunning this path.
Public experimental hold-out validation and a complete brick cycle remain unmet.
