# Final independent granular-drying Python review

**APPROVE** for production SHA256 `f1ec79c0b606ebcc58029f24162ac25eb75825b4944aca86c693716b3d274b7a`. No unresolved CRITICAL or HIGH finding remains in the scoped review. FINAL_IDENTITY.json records the final source, tests, source definition, thermal dependency and independent tests.

Scope: new arlabosse_granular_drying.py and its tests relative to baseline 641377f, with the registered source definition and existing thermal interface checked. No production edits, installation, Git mutation, real EOS construction, physical trajectory or literature-image rereading was performed.

## Closed numeric-boundary finding

The original source SHA 54d130c76b0bf45b73c86790c8bf102afb646adb7bca22c72c27f6d3e16f8429 accepted positive subnormal mass/area but could return completed while the mass trajectory became drier and the reported water flow rounded to zero. UNDERFLOW01.log/xml preserves the actual manufactured reproduction: 1 failed/8 passed. It does not claim that a real EOS run was performed.

The final implementation rejects nonrepresentable strictly positive initial/final water inventory, step removal, step heat, water flow and required power. Clock and flow scaling use exact Fraction operations on represented input values before final binary64 conversion, avoiding avoidable intermediate overflow. Failed computations retain the existing accepted prefix and pending observation; power overflow is recorded as a null field plus the original invalid scalar string, so JSON remains valid.

The root also added the explicitly recorded numerical acceptance policy for isothermal temperature, energy and water residuals. Independent negative controls alter T only, H while keeping T unchanged, and water removal while keeping heat balanced; all three gates independently refuse the bad candidate and preserve its full pending row. The final elapsed-time observation cannot leave an over-budget result completed.

## Mathematical and source conclusions

The integrated law includes b: t=3600 md/(A a) ln[(a Wi+b)/(a W+b)]. Its log1p form remains accurate for adjacent binary64 moisture inputs. F is kg water/(m2 h); A F/3600 is kg water/s and multiplication by q is W. The correction relative to the source's intercept-omitting equation is explicitly identified as a derived correction, not an author erratum.

The run updates H from cumulative source-model heat and signed outgoing vapor enthalpy, then uses the actual thermal inverse. It does not overwrite the recovered temperature. Increasing t and decreasing W are checked, and reporting intervals are labelled output sampling rather than an ODE step-convergence tolerance. The numerical acceptance policy is separate from unquantified source-protocol transfer and experimental error.

The low external vapor-pressure condition is checked against the driest endpoint under the admitted wet model's monotone activity assumption. It is correctly described as necessary for the declared evaporation direction, not proof that the empirical rate applies at the chosen temperature/gas conditions. This remains prescribed-temperature granular contact-drying preprocessing, with calculated heat requirement; it does not predict brick-internal transport, unrestricted temperature response, industrial fuel demand or validated drying time.

Source and thermal definitions are reread; mutation of returned definitions/results does not affect later runs. A failure on the last source recheck keeps the complete computed prefix but marks the run failed. Cooperative cancellation and deadlines retain observed prefixes. Only the documented known-error family is converted to a result; no broad promise of catching every arbitrary callback exception is inferred.

## Actual tests and evidence

FINAL_TESTS02.log/xml: **41 passed in 0.11 seconds** (XML .105), zero failures/errors/skips: 26 repository tests plus 15 independent tests. All five reviewed inputs are unchanged before/after this run. AST parsing and git diff --check passed. ruff/mypy/black/pylint were unavailable in the runtime; no lint/type-check pass is claimed.

Independent checks include three 90-digit Decimal clock oracles (including adjacent float W), the analytic rate derivative and 3600 conversion, immediate cancellation before construction, nonboolean cancellation after a prefix, final source-change refusal, returned-data isolation, separate subnormal flow/mass controls, the three independent numeric gates, JSON-safe power overflow and final-clock deadline refusal.

STATIC_CHECKS.json also verifies registered private source-asset bytes and the thermal model JSON hash without evaluating EOS. This is source-byte identity checking, not new experimental or literature validation.

Evidence naming: UNDERFLOW01 is the actual original RED. MASS_UNDERFLOW01, CONTROL_GATE01/02 and the earlier FINAL_TESTS contain actual intermediate GREEN results and remain preserved; they must not be presented as additional failures or as final-hash verification. FINAL_TESTS02 with FINAL_IDENTITY is the final approval evidence.
