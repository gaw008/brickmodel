"""Independent manufactured algebra/control-boundary checks; no EOS."""
from decimal import Decimal, localcontext
import json
import math

import pytest

from test_arlabosse_granular_drying import setup, run, Thermal
from sludge_sandbox import arlabosse_granular_drying as model


@pytest.mark.parametrize('wi,wf,md,area',[(.32,.15,.123,.034),(.29,.21,3.5,.1),(.25,math.nextafter(.25,0),.1,.02)])
def test_clock_with_intercept_against_high_precision_binary_input_oracle(setup,wi,wf,md,area):
    law=model.ArlabosseGranularFlux('manufactured-root')
    actual=law.elapsed_seconds(wi,wf,dry_mass_kg=md,contact_area_m2=area)
    with localcontext() as ctx:
        ctx.prec=90
        a,b=Decimal.from_float(float('34.38')),Decimal.from_float(float('4.58'))
        x,y=Decimal.from_float(wi),Decimal.from_float(wf)
        expected=(Decimal(3600)*Decimal.from_float(md)/(Decimal.from_float(area)*a)*((a*x+b)/(a*y+b)).ln())
    assert actual > 0
    assert actual == pytest.approx(float(expected),rel=8e-16)
    assert law.elapsed_seconds(wi,wi,dry_mass_kg=md,contact_area_m2=area) == 0


def test_rate_is_derivative_of_analytic_path_with_correct_hour_conversion(setup):
    law=model.ArlabosseGranularFlux('manufactured-root')
    md,area,w0=.1,.02,.32
    t=law.elapsed_seconds(w0,.23,dry_mass_kg=md,contact_area_m2=area)
    a,b=34.38,4.58
    def exact_w(time):
        return (w0+b/a)*math.exp(-a*area*time/(3600*md))-b/a
    dt=1e-3
    derivative=(exact_w(t+dt)-exact_w(t-dt))/(2*dt)
    expected=-area*law.flux_kg_water_m2_h(.23)/(3600*md)
    assert derivative == pytest.approx(expected,rel=3e-10)
    assert abs(derivative-expected*3600)>1e-3


def test_immediate_cancel_has_no_source_or_thermal_calls(setup,monkeypatch):
    def forbidden(*args,**kwargs):
        pytest.fail('construction_before_cancel')
    monkeypatch.setattr(model,'_load_source',forbidden)
    monkeypatch.setattr(model,'ArlabosseWetThermodynamics',forbidden)
    result=run(setup,cancel=lambda:True)
    assert result['status']=='cancelled'
    assert result['observations']==[] and result['pending_observation'] is None
    assert result['elapsed_seconds']>=0


def test_nonboolean_cancel_return_keeps_successful_prefix(setup):
    checks=iter([False,False,False,'yes'])
    result=run(setup,cancel=lambda:next(checks))
    assert result['status']=='failed'
    assert result['reason']=='cancel_must_return_bool'
    assert len(result['observations'])==2
    assert result['pending_observation'] is None


def test_final_source_recheck_does_not_mark_stale_run_completed(setup,monkeypatch):
    actual=model.ArlabosseGranularFlux.definition
    calls=0
    # constructor, recorded definition, two law reads for each of 9 rows,
    # then the final recheck; all computations are manufactured.
    def changing(self):
        nonlocal calls
        calls+=1
        if calls==21:
            raise model.GranularDryingError('source_changed_after_last_observation')
        return actual(self)
    monkeypatch.setattr(model.ArlabosseGranularFlux,'definition',changing)
    result=run(setup)
    assert result['status']=='failed'
    assert result['reason']=='source_changed_after_last_observation'
    assert len(result['observations'])==9
    assert result['observations'][-1]['moisture_kg_water_kg_dry']==.15
    assert result['material_qualified'] is False


def test_definition_and_returned_rows_are_not_shared_across_runs(setup):
    first=run(setup,intervals=1)
    first['source']['parameters']['a']['value']='FAKE'
    first['observations'][0]['inverse']['state']['temperature_k']=-1
    second=run(setup,intervals=1)
    assert second['source']['parameters']['a']['value']=='34.38'
    assert second['observations'][0]['inverse']['state']['temperature_k']>300
    assert second['experimental_uncertainty'] is None
    assert 'not_an_ODE' in second['numerical_scope']
    json.dumps(second,allow_nan=False)


def test_subnormal_area_cannot_publish_a_positive_drying_path_with_zero_water_rate(setup):
    # A report labelled completed must not silently round its positive flow to
    # zero while the analytic law still advances to a drier endpoint.
    result=run(setup,dry_mass_kg=1e-323,contact_area_m2=1e-323,intervals=1)
    if result['status']=='completed':
        assert all(row['water_out_kg_s']>0 for row in result['observations'])


def test_positive_moisture_step_cannot_publish_zero_removed_water(setup):
    # Area is ordinary here: a flow-only guard cannot close dry-mass underflow.
    result=run(setup,dry_mass_kg=1e-323,contact_area_m2=.02,intervals=1)
    if result['status']=='completed':
        assert all(row['step_water_out_kg']>0 for row in result['observations'][1:])


def test_control_temperature_failure_preserves_full_rejected_observation(setup,monkeypatch):
    from test_arlabosse_granular_drying import Point
    original=Thermal.inverse_enthalpy
    calls=0
    def biased(self,target_j,*,dry_mass_kg,moisture,**kwargs):
        nonlocal calls
        calls+=1
        returned=original(self,target_j,dry_mass_kg=dry_mass_kg,moisture=moisture,**kwargs)
        if calls==2:
            bad=Point(returned.state.temperature_k+.01,moisture)
            returned.state=bad
            returned.residual_j=dry_mass_kg*bad.specific_enthalpy_j_kg_dry-target_j
            returned.to_record=lambda:{'state':bad.to_record()}
        return returned
    monkeypatch.setattr(Thermal,'inverse_enthalpy',biased)
    result=run(setup)
    assert result['status']=='failed'
    assert len(result['observations'])==1
    pending=result['pending_observation']
    assert pending['index']==1
    assert pending['recovered_temperature_difference_k'] == pytest.approx(.01,abs=1e-12)
    assert pending['inverse']['state']['temperature_k'] == pytest.approx(setup['temperature_k']+.01)
    assert pending['step_heat_j']>0 and pending['step_water_out_kg']>0
    assert abs(pending['open_energy_residual_j'])>1e-5
    assert result['full_firing_cycle'] is False


def test_energy_gate_rejects_bias_even_with_exact_control_temperature(setup,monkeypatch):
    original=Thermal.inverse_enthalpy
    calls=0
    def biased(self,target_j,*,dry_mass_kg,moisture,**kwargs):
        nonlocal calls
        calls+=1
        returned=original(self,target_j,dry_mass_kg=dry_mass_kg,moisture=moisture,**kwargs)
        if calls==2:
            returned.state.specific_enthalpy_j_kg_dry += .01
        return returned
    monkeypatch.setattr(Thermal,'inverse_enthalpy',biased)
    result=run(setup)
    assert result['status']=='failed'
    assert result['reason']=='numerical_gate_energy_balance'
    pending=result['pending_observation']
    assert abs(pending['recovered_temperature_difference_k'])<1e-6
    assert abs(pending['open_energy_residual_j'])>1e-5
    assert len(result['observations'])==1


def test_water_gate_is_independent_of_thermal_balance(setup,monkeypatch):
    original=Thermal.isothermal_drying_heat
    def biased(self,*args,**kwargs):
        result=original(self,*args,**kwargs)
        result.removed_water_kg += 1e-5
        return result
    monkeypatch.setattr(Thermal,'isothermal_drying_heat',biased)
    result=run(setup)
    assert result['status']=='failed'
    assert result['reason']=='numerical_gate_water_balance'
    pending=result['pending_observation']
    assert abs(pending['open_energy_residual_j'])<1e-5
    assert abs(pending['water_balance_residual_kg'])>1e-12
    assert len(result['observations'])==1


def test_power_overflow_preserves_invalid_scalar_without_invalid_json(setup):
    result=run(setup,contact_area_m2=1e308,intervals=1)
    assert result['status']=='failed'
    pending=result['pending_observation']
    assert pending['water_out_kg_s']>0 and math.isfinite(pending['water_out_kg_s'])
    assert pending['required_net_heat_w'] is None
    assert pending['invalid_computed_values']['required_net_heat_w']=='inf'
    assert 'inverse' in pending and result['observations']==[]
    json.dumps(result,allow_nan=False)


def test_final_elapsed_observation_cannot_publish_over_budget_completed(setup,monkeypatch):
    values=iter([0.,0.,0.,0.,0.,0.,11.])
    monkeypatch.setattr(model.time,'monotonic',lambda:next(values))
    result=run(setup,intervals=1)
    assert result['status']=='time_budget_exceeded'
    assert len(result['observations'])==2
    assert result['pending_observation'] is None
    assert result['elapsed_seconds']==11.
