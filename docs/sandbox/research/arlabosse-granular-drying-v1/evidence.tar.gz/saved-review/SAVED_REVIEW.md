# Granular native01 saved-result audit

**PASS — 588 independent audit assertions, zero failures.** The final audit took 0.049742 s and used only saved JSON/CSV, original rational source data and filesystem hashes. No scientific package was imported, no EOS evaluated, no drying path replayed and no package installed.

Final evidence: [SAVED_REVIEW02.json](SAVED_REVIEW02.json), [audit_saved02.py](audit_saved02.py), [AUDIT02.log](AUDIT02.log). The final JSON is authoritative; the separately retained first-audit FAIL is explained below.

## Actual saved outcome

The original run completed all **13 observations** with no pending candidate and passed all **369 original assertions**. Run/driver/outer durations were **5.063229208055 / 5.119489999954 / 10.250868208997 s**, within the original 30/60/80 s limits and 5 s cleanup grace. The saved supervisor records return code 0, leader reaped and no signal errors; its containment claim remains the original process group only.

The conditional model clock is **246.155847610960 s** for W=.32→.15, with **0.017 kg** water removed and **43006.742625222105 J** required net heat. Signed outgoing vapor enthalpy is **-226127.079654531670 J** under the shared reference; its negative sign was retained in every ledger. This is a prescribed 90 °C, 0.1 kg dry-mass, 0.02 m² nominal-area, 1000 Pa external-vapor scenario, not a measured drying time or industrial energy-consumption estimate.

## Independent recomputation

The audit recomputes t(W) using 60-digit Decimal ln and the original a/b coefficients, flow with Decimal source arithmetic, and heat/reference H with exact Fraction trapezoids over the original six q95 nodes. The two saved 90/95 °C water references supply the shared hl/hv/latent difference; no fresh water evaluation was performed. Original dry Cp and the integrated excess enthalpy reconstruct H independently at every observation.

All local and cumulative heat, signed-vapor and water increments were checked, including initial and final rows. The audit binds recovered H to the actual saved inverse state, verifies its input target/mass, bracket/iterations/residual, compares actual inverse temperature with the control, and reproduces the serialized binary64 residual expressions in their original order. Exact arithmetic over saved values is an arithmetic check, not a claim of zero physical uncertainty.

| Quantity | Maximum absolute independent residual | Original limit |
|---|---:|---:|
| Clock | 3.84679724366e-14 s | 1e-9 s |
| Flow | 1.79409226672e-20 kg/s | 1e-14 kg/s |
| Cumulative heat against original q reference | 8.0413174163e-12 J | 1e-5 J |
| Signed vapor enthalpy | 4.74974513054e-11 J | 1e-5 J |
| Required net power | 6.0993575166e-14 W | 1e-7 W |
| Target H against independent reference | 1.46793760466e-10 J | 1e-5 J |
| Recovered H against independent reference | 1.68498422948e-08 J | 1e-5 J |
| Actual inverse temperature | 6.26641849522e-11 K | 1e-6 K |
| Local/whole-prefix energy balance | 3.00947249343e-08 J | 1e-5 J |
| Local/whole-prefix water balance | 3.8820841929e-18 kg | 1e-12 kg |

Final whole-path energy residual is **-1.45519152284e-08 J**. Arithmetic negative controls also pass their required rejection checks: omitting b changes terminal time by **150.538237047425 s**; adding latent heat again produces **-38976.582026479853 J** energy residual. Neither control reruns the EOS/path.

## Identity and scientific limits

All **385 declared input files** match their before/after/current byte hashes and sizes. All **171 source and installed package files** match the original freeze. Reviewed production/driver/protocol hashes are unchanged. Before/after runtime records are identical; **164 modules + 4 catalogs** match installed bytes. All **24 rate/wet/upstream asset entries**, water assets and original q facts match their pinned definitions. The two earlier failed install logs and successful third install log remain preserved and unchanged.

The saved rate source and full thermal definition match the original metadata. Original q observations at W=.1/.5/.6 remain unknown; no interpolated value was relabeled as an observation. Source-temperature/gas correspondence, rate-condition transfer error and experimental uncertainty remain unknown. Material/training/full-cycle qualifications remain false, and no internal spatial model is claimed. The evaporation direction/domain/positive q-flow-power checks pass under the declared model; they do not validate transfer of the empirical rate to these conditions.

All original native, supervisor and installation files were unchanged by this audit. The water reference numbers were audited as saved constituents and source identities, not independently checked against another EOS or measured experiment.

## Saved plot and CSV

The **13 CSV rows / 130 numerical fields** equal the original saved RUN values. PLOT_RECORD binds the exact original RUN and plot-script hashes; the script imports no model/EOS. Its fixed title, 90 °C/mass/area/vapor conditions and rounded 246.16 s / 17 g / 43.01 kJ summary match this run. The axes contain all saved points, and the labels explicitly say calculated conditional points, not measurements or brick-internal transport, with unknown transfer error. PNG/SVG/PDF hashes are retained in the final audit JSON.

This was a CSV/value and static fixed-case plot review; I did not rerender the plot or independently inspect its typography. Matplotlib version 3.11.2 is recorded by the separate plotting environment. The physical environment's frozen source/runtime identity remained unchanged.

## Preserved first-audit failure

The first review script assumed the preceding phase's flat freeze mapping. This phase correctly stores `{base_commit, files}` with package-relative paths, so that audit stopped after 21 assertions with a schema-handling error. This was an audit-script failure, not a native calculation or threshold failure. Its original [SAVED_REVIEW.json](SAVED_REVIEW.json), [AUDIT.log](AUDIT.log) and [audit_saved.py](audit_saved.py) remain untouched. [AUDIT01_DIAGNOSIS.json](AUDIT01_DIAGNOSIS.json) and [AUDIT02.diff](AUDIT02.diff) record the correction and the requested additional CSV/static-plot checks. No production, original numerical gate or physical evidence was modified.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — saved native01 passes its original arithmetic, identity and reporting gates within the explicitly conditional scientific scope.
