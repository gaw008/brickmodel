"""Independent saved-value audit. Stdlib only; no model import or physical replay."""
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path
import hashlib
import csv
import ast
import json
import math
import sys
import time
from datetime import datetime, timezone

BASE=Path('/private/tmp/arlabosse-granular-drying-v1')
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
INSTALLED=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
OUT=BASE/'saved-review'
CHECKS=[]
METRICS={}
START=time.monotonic()


def read(path):
    def reject(value):raise ValueError('nonfinite_json:'+value)
    return json.loads(Path(path).read_bytes(),parse_constant=reject)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(name,condition,detail=None):
    CHECKS.append({'name':name,'passed':bool(condition),**({'detail':detail} if detail is not None else {})})


def equal(name,left,right):check(name,left==right)


def close(name,left,right,tolerance):
    error=F(left)-F(right)
    check(name,abs(error)<=F(str(tolerance)),{'residual':float(error),'limit':tolerance})
    return float(error)


def rational(value):return F(int(value['numerator']),int(value['denominator']))


def q_value(nodes,x):
    for (a,y),(b,z) in zip(nodes,nodes[1:]):
        if a<=x<=b:return ((b-x)*y+(x-a)*z)/(b-a)
    raise ValueError('original_q_interpolant_domain')


def q_integral(nodes,a,b):
    if b<a:return -q_integral(nodes,b,a)
    cuts=[a]+[x for x,_ in nodes if a<x<b]+[b]
    return sum(((y-x)*(q_value(nodes,x)+q_value(nodes,y))/2 for x,y in zip(cuts,cuts[1:])),F())


def finite(value):
    if isinstance(value,float):return math.isfinite(value)
    if isinstance(value,dict):return all(finite(v) for v in value.values())
    if isinstance(value,list):return all(finite(v) for v in value)
    return True


def audit():
    protected=sorted(p for name in ('native01','supervised-native01','install') for p in (BASE/name).iterdir() if p.is_file())
    before_hashes={str(p):sha(p) for p in protected}
    run=read(BASE/'native01/RUN.json')
    acceptance=read(BASE/'native01/ACCEPTANCE.json')
    runtime=read(BASE/'native01/RUNTIME_BEFORE.json')
    meta=read(BASE/'supervised-native01/metadata.json')
    status=read(BASE/'supervised-native01/status.json')
    freeze_record=read(BASE/'install/SOURCE_FREEZE.json')
    equal('freeze_base_commit',freeze_record['base_commit'],'641377f')
    freeze=freeze_record['files']
    expected_inputs={'dry_mass_kg':.1,'contact_area_m2':.02,'temperature_k':363.15,'ambient_vapor_pressure_pa':1000.,'initial_moisture':.32,'final_moisture':.15,'intervals':12,'wall_seconds':30.}
    equal('saved_inputs_match_preregistration',read(BASE/'native01/INPUTS.json'),expected_inputs)
    equal('run_inputs_bound_to_saved_inputs',run['inputs'],expected_inputs)
    equal('actual_terminal_completed',(run['status'],run['reason'],run['pending_observation']),('completed','requested_moisture_endpoint_reached',None))
    equal('acceptance_passed',acceptance['status'],'passed')
    equal('original_recorded_check_count',len(acceptance['checks']),369)
    check('all_original_checks_pass_and_names_unique',all(c['passed'] is True for c in acceptance['checks']) and len({c['name'] for c in acceptance['checks']})==369)
    equal('outer_complete_exit_zero',(status['status'],status['returncode']),('complete',0))
    check('saved_leader_reaped_no_signal_errors',status['cleanup']['leader_reaped'] is True and status['cleanup']['signal_errors']==[])
    equal('cleanup_scope',status['cleanup']['scope'],'original_process_group_only; escaped_sessions_not_contained')
    check('all_original_wall_limits',0<run['elapsed_seconds']<30 and run['elapsed_seconds']<=acceptance['elapsed_seconds']<60 and acceptance['elapsed_seconds']<=status['elapsed_s']<80)
    equal('outer_registered_budget',(meta['timeout_s'],meta['cleanup_grace_s']),(80.,5.))
    equal('fixed_installed_isolated_command',meta['command'],['/usr/bin/env','-u','PYTHONPATH','/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python','-I',str(BASE/'native_driver.py')])
    equal('outside_repo_working_directory',meta['cwd'],'/private/tmp')
    equal('runtime_before_after',runtime,read(BASE/'native01/RUNTIME_AFTER.json'))
    equal('runtime_versions',runtime['versions'],{'sludge-vme':'0.1.0','numpy':'2.5.2','scipy':'1.18.1','iapws':'1.5.5','CoolProp':'8.0.0'})
    equal('audit_interpreter_matches_saved_python',runtime['python'],'.'.join(map(str,sys.version_info[:3])))
    equal('input_sets_before_after',set(meta['inputs_before']),set(status['inputs_after']))
    inputs=meta['inputs_before'];mismatches=[]
    for name,item in inputs.items():
        p=Path(name)
        if not p.is_file() or p.stat().st_size!=item['bytes'] or sha(p)!=item['sha256'] or status['inputs_after'][name]!=item['sha256']:mismatches.append(name)
    check('all_native_input_hashes_before_after_current',not mismatches,{'count':len(inputs),'mismatches':mismatches})
    equal('saved_input_unchanged_flag',status['inputs_unchanged'],True)
    equal('frozen_file_count',len(freeze),171)
    mismatches=[]
    for rel,digest in freeze.items():
        source=ROOT/'src/sludge_sandbox'/rel;installed=INSTALLED/rel
        if not sha(source)==sha(installed)==inputs[str(source)]['sha256']==inputs[str(installed)]['sha256']==digest:mismatches.append(rel)
    check('all_source_installed_freeze_files_match',not mismatches,{'count':len(freeze),'mismatches':mismatches})
    install=read(BASE/'install/INSTALL_IDENTITY_BEFORE_TESTS.json')
    equal('installation_rows_bound_to_freeze',{r['path']:r['frozen_sha256'] for r in install['rows']},freeze)
    check('installation_rows_source_and_installed_equal',all(r['frozen_sha256']==r['source_sha256']==r['installed_sha256'] for r in install['rows']))
    check('runtime_module_and_catalog_bytes_match',all(sha(INSTALLED/p)==d for p,d in runtime['modules'].items()) and all(sha(INSTALLED/'catalogs'/p)==d for p,d in runtime['catalogs'].items()))
    reviewed=read(BASE/'code-review/FINAL_REVIEW.json')
    for p,item in reviewed['files'].items():
        equal('reviewed_candidate:'+p,sha(p),item['sha256'])
    for name,digest in {'NATIVE_PLAN.md':'07840ba038da67b8bb0138dacdbed082223234d83a2bd92129816e5a95cc9c33','native_driver.py':'69f22c56a473e5a16eb3e154df075e53d6212b7b45483ea17842bd47a56b12d6','run_supervised_native01.py':'146e2d49a5740728c262d50778806ee1b1a802ae379dfde84efe3ebe515ba6be'}.items():
        equal('reviewed_native_protocol_input:'+name,sha(BASE/name),digest)
        equal('protocol_in_before_manifest:'+name,inputs[str(BASE/name)]['sha256'],digest)
    source_path=ROOT/'data/sandbox/research/arlabosse-granular-drying-v1/source.json'
    source=read(source_path)
    equal('saved_full_rate_source',run['source'],source)
    equal('original_rate_coefficients',(source['parameters']['a']['value'],source['parameters']['b']['value']),('34.38','4.58'))
    wet_path=ROOT/source['thermal_upstream']['path'];wet=read(wet_path);definition=run['thermodynamic_definition']
    equal('saved_full_wet_metadata',{k:definition[k] for k in wet},wet)
    equal('saved_wet_model_sha',definition['model_sha256'],sha(wet_path))
    assets=source['assets']+[source['thermal_upstream']]+wet['assets']+wet['upstream']
    assets += [a for s in wet['upstream'] for a in read(ROOT/s['path'])['assets']]
    check('every_rate_wet_upstream_asset_identity',all((ROOT/a['path']).resolve().is_relative_to(ROOT) and sha(ROOT/a['path'])==a['sha256']==inputs[str(ROOT/a['path'])]['sha256'] for a in assets),{'entries':len(assets)})
    check('water_source_assets_match',all(sha(ROOT/'data/sandbox/water'/p)==d for p,d in definition['water']['source_asset_sha256'].items()))
    facts_path=ROOT/'data/sandbox/research/arlabosse95/facts.json'
    equal('original_q_facts_sha',sha(facts_path),'543d55918db7df6d0cc0f695c5dceadbdebda82b83f4fdde206266bcd12f2f16')
    facts=read(facts_path)
    heat_rows={F(r['requested_moisture_kg_water_per_kg_dry_matter']):r for r in facts['observations'] if r['figure']==2}
    nodes=sorted((w,rational(r['value'])) for w,r in heat_rows.items() if r['value'] is not None)
    equal('six_original_heat_nodes',len(nodes),6)
    equal('original_unknown_heat_points',{w for w,r in heat_rows.items() if r['value'] is None},{F('.1'),F('.5'),F('.6')})
    point_records={rational(p['moisture_kg_water_per_kg_dry_matter']):p for p in definition['source_point_records']}
    check('saved_supported_original_heat_values',all((point_records[w]['total_desorption_heat']['value'] is None if row['value'] is None else rational(point_records[w]['total_desorption_heat']['value'])==rational(row['value'])) for w,row in heat_rows.items() if w in point_records))
    equal('original_runtime_numerical_policy',run['numerical_policy'],{'temperature_tolerance_k':1e-6,'energy_tolerance_j':1e-5,'water_tolerance_kg':1e-12,'inverse_temperature_tolerance_k':1e-10,'inverse_maximum_iterations':80,'classification':'numerical_policy','scope':'absolute_arithmetic_acceptance_not_experimental_uncertainty'})
    for label,record in [('run',run),('source',source),('wet_definition',definition)]:
        check('qualification_false:'+label,all(record[k] is False for k in ('material_qualified','training_eligible','full_firing_cycle')))
    check('borrowed_conditions_and_error_unknown',all(run[k] is None and source[k] is None for k in ('source_protocol_temperature_and_gas_match','rate_condition_transfer_model_error','experimental_uncertainty')))
    equal('no_spatial_model',run['spatial_model'],False)
    equal('acceptance_science_scope',acceptance['scientific_scope'],'conditional_model_arithmetic_not_public_holdout_validation')
    check('all_saved_numbers_finite',finite(run) and finite(acceptance))
    oracles=read(BASE/'native01/ORACLE_WATER.json')
    equal('two_registered_water_temperatures',[r['temperature_k'] for r in oracles],[363.15,368.15])
    check('water_oracles_share_registered_reference',all(r['liquid_pressure_pa']==100000. and r['molar_mass_kg_mol']==definition['water']['molar_mass_kg_mol'] and r['source_ids']==definition['water']['source_ids'] for r in oracles))
    hl,hv=F(oracles[0]['liquid_h_j_kg']),F(oracles[0]['vapor_h_j_kg'])
    latent95=F(oracles[1]['vapor_h_j_kg'])-F(oracles[1]['liquid_h_j_kg'])
    deltaL=hv-hl-latent95
    cp=read(ROOT/'data/sandbox/research/arlabosse2005/source.json')['caloric_relation']
    equal('original_dry_cp_coefficients',(cp['intercept'],cp['slope_per_degC']),(1434,3.29))
    dryh=F(cp['intercept'])*(F(90)-95)+F(str(cp['slope_per_degC']))*(90**2-95**2)/2
    md,wi,wf=F('.1'),F('.32'),F('.15')
    def enthalpy(w):return md*(dryh+w*hl+latent95*(w-F('.8'))-q_integral(nodes,F('.8'),w))
    close('independent_initial_total_H',run['initial_total_enthalpy_j'],enthalpy(wi),1e-5)
    equal('initial_H_bound_to_saved_initial_state',run['initial_total_enthalpy_j'],.1*run['initial']['specific_enthalpy_j_kg_dry'])
    rows=run['observations'];equal('thirteen_indexed_observations',[r['index'] for r in rows],list(range(13)))
    equal('acceptance_observation_count',acceptance['actual_observations'],13)
    previous_w=wi;previous_time=-1.;previous_H=F(run['initial_total_enthalpy_j']);previous_recovered=previous_H
    previous_q=previous_v=previous_water=F();stepqs=[];stepvs=[];stepms=[]
    details=[]
    for i,row in enumerate(rows):
        label=str(i);w=F(str(row['moisture_kg_water_kg_dry']));state=row['inverse']['state'];inverse=row['inverse']
        wanted=.32 if i==0 else .15 if i==12 else .32+(.15-.32)*(i/12)
        equal('requested_sampling_coordinate:'+label,row['moisture_kg_water_kg_dry'],wanted)
        check('strict_time_and_moisture_order:'+label,row['time_s']>previous_time and (i==0 or w<previous_w))
        with localcontext() as context:
            context.prec=60
            a,b=Decimal(source['parameters']['a']['value']),Decimal(source['parameters']['b']['value'])
            wd=Decimal(w.numerator)/Decimal(w.denominator)
            time_ref=Decimal(3600)*Decimal('.1')/(Decimal('.02')*a)*((a*Decimal('.32')+b)/(a*wd+b)).ln()
            flow_ref=Decimal('.02')*(a*wd+b)/Decimal(3600)
        time_error=close('independent_Decimal_clock:'+label,row['time_s'],F(time_ref),1e-9)
        flow_error=close('independent_Decimal_flow:'+label,row['water_out_kg_s'],F(flow_ref),1e-14)
        q=md*(q_integral(nodes,w,wi)+deltaL*(wi-w));v=md*(wi-w)*hv;m=md*(wi-w)
        heat_error=close('independent_cumulative_heat:'+label,row['cumulative_net_heat_j'],q,1e-5)
        vapor_error=close('independent_signed_vapor_H:'+label,row['cumulative_vapor_enthalpy_j'],v,1e-5)
        water_error=close('independent_cumulative_water:'+label,row['cumulative_water_out_kg'],m,1e-12)
        power_error=close('independent_required_power:'+label,row['required_net_heat_w'],F(flow_ref)*(q_value(nodes,w)+deltaL),1e-7)
        target_error=close('independent_target_H:'+label,row['target_total_enthalpy_j'],enthalpy(w),1e-5)
        recovered_error=close('independent_recovered_H:'+label,row['recovered_total_enthalpy_j'],enthalpy(w),1e-5)
        sq,sv,sm=F(row['step_heat_j']),F(row['step_vapor_enthalpy_j']),F(row['step_water_out_kg'])
        close('independent_local_heat:'+label,sq,md*(q_integral(nodes,w,previous_w)+deltaL*(previous_w-w)),1e-5)
        close('independent_local_signed_vapor_H:'+label,sv,md*(previous_w-w)*hv,1e-5)
        close('independent_local_water:'+label,sm,md*(previous_w-w),1e-12)
        target,recovered=F(row['target_total_enthalpy_j']),F(row['recovered_total_enthalpy_j'])
        actual_q,actual_v,actual_water=F(row['cumulative_net_heat_j']),F(row['cumulative_vapor_enthalpy_j']),F(row['cumulative_water_out_kg'])
        balances={
            'target_local':close('target_local_energy:'+label,target-previous_H-sq+sv,0,1e-5),
            'recovered_local':close('recovered_local_energy:'+label,recovered-previous_recovered-sq+sv,0,1e-5),
            'target_whole_prefix':close('target_whole_prefix_energy:'+label,target-F(run['initial_total_enthalpy_j'])-actual_q+actual_v,0,1e-5),
            'recovered_whole_prefix':close('recovered_whole_prefix_energy:'+label,recovered-F(run['initial_total_enthalpy_j'])-actual_q+actual_v,0,1e-5),
            'water_local':close('water_local_inventory:'+label,md*w-md*previous_w+sm,0,1e-12),
            'water_whole_prefix':close('water_whole_prefix_inventory:'+label,md*w-md*wi+actual_water,0,1e-12)}
        close('cumulative_heat_matches_step:'+label,actual_q-previous_q-sq,0,1e-5)
        close('cumulative_vapor_matches_step:'+label,actual_v-previous_v-sv,0,1e-5)
        close('cumulative_water_matches_step:'+label,actual_water-previous_water-sm,0,1e-12)
        equal('inverse_target_and_dry_mass:'+label,(inverse['target_enthalpy_j'],inverse['dry_mass_kg']),(row['target_total_enthalpy_j'],.1))
        equal('recovered_H_is_actual_inverse_state_H:'+label,row['recovered_total_enthalpy_j'],.1*state['specific_enthalpy_j_kg_dry'])
        equal('inverse_original_policy:'+label,(inverse['temperature_tolerance_k'],inverse['maximum_iterations']),(1e-10,80))
        lo,hi=inverse['temperature_bracket_k']
        check('actual_inverse_bracket_convergence:'+label,0<=inverse['iterations']<=80 and 308.15<=lo<=state['temperature_k']<=hi<=368.15 and hi-lo==inverse['bracket_width_k'] and hi-lo<=1e-10 and abs(inverse['residual_j'])<=inverse['residual_tolerance_j'])
        equal('recorded_inverse_residual:'+label,inverse['residual_j'],math.fsum((row['recovered_total_enthalpy_j'],-row['target_total_enthalpy_j'])))
        temperature_error=close('actual_inverse_T_to_control:'+label,state['temperature_k'],F('363.15'),1e-6)
        equal('saved_temperature_error:'+label,row['recovered_temperature_difference_k'],state['temperature_k']-363.15)
        equal('actual_state_moisture:'+label,state['moisture_kg_water_per_kg_dry'],row['moisture_kg_water_kg_dry'])
        check('physical_direction_domain_positive_q_flow_power:'+label,308.15<=state['temperature_k']<=368.15 and .15<=float(w)<=.32 and 0<state['activity']<=1 and 1000.<state['model_equilibrium_vapor_pressure_pa'] and state['liquid_mechanical_pressure_pa']==100000. and state['total_desorption_heat_j_kg_water']>0 and row['water_out_kg_s']>0 and row['required_net_heat_w']>0)
        check('state_qualification_and_unknown_errors:'+label,all(state[k] is False for k in ('material_qualified','training_eligible','full_firing_cycle')) and all(state[k] is None for k in ('interpolation_model_error','temperature_extension_model_error','water_reference_model_error','experimental_uncertainty')))
        equal('state_model_source_identity:'+label,(state['model_id'],state['model_sha256'],state['source_ids']),(definition['model_id'],definition['model_sha256'],definition['source_ids']))
        stepqs.append(row['step_heat_j']);stepvs.append(row['step_vapor_enthalpy_j']);stepms.append(row['step_water_out_kg'])
        equal('saved_binary64_prefix_sums:'+label,(row['cumulative_net_heat_j'],row['cumulative_vapor_enthalpy_j'],row['cumulative_water_out_kg']),(math.fsum(stepqs),math.fsum(stepvs),math.fsum(stepms)))
        equal('saved_target_update:'+label,row['target_total_enthalpy_j'],math.fsum((run['initial_total_enthalpy_j'],row['cumulative_net_heat_j'],-row['cumulative_vapor_enthalpy_j'])))
        equal('saved_recovered_local_residual:'+label,row['step_energy_residual_j'],math.fsum((row['recovered_total_enthalpy_j'],-float(previous_recovered),-row['step_heat_j'],row['step_vapor_enthalpy_j'])))
        equal('saved_target_local_residual:'+label,row['target_step_energy_residual_j'],math.fsum((row['target_total_enthalpy_j'],-float(previous_H),-row['step_heat_j'],row['step_vapor_enthalpy_j'])))
        equal('saved_whole_prefix_residual:'+label,row['open_energy_residual_j'],math.fsum((row['recovered_total_enthalpy_j'],-run['initial_total_enthalpy_j'],-row['cumulative_net_heat_j'],row['cumulative_vapor_enthalpy_j'])))
        equal('saved_water_residual:'+label,row['water_balance_residual_kg'],math.fsum((.1*row['moisture_kg_water_kg_dry'],row['cumulative_water_out_kg'],-.1*.32)))
        details.append({'index':i,'moisture':str(w),'time_s':row['time_s'],'clock_error_s':time_error,'flow_error_kg_s':flow_error,'heat_reference_error_j':heat_error,'signed_vapor_reference_error_j':vapor_error,'water_reference_error_kg':water_error,'power_error_w':power_error,'target_H_reference_error_j':target_error,'recovered_H_reference_error_j':recovered_error,'temperature_error_k':temperature_error,'inverse_iterations':inverse['iterations'],'endpoint_roundoff_allowance_j':inverse['endpoint_roundoff_allowance_j'],'balances':balances})
        previous_w,previous_time=w,row['time_s'];previous_H,previous_recovered=target,recovered
        previous_q,previous_v,previous_water=actual_q,actual_v,actual_water
    negative=read(BASE/'native01/NEGATIVE_CONTROLS.json')
    with localcontext() as context:
        context.prec=60
        no_b=Decimal(3600)*Decimal('.1')/(Decimal('.02')*Decimal('34.38'))*(Decimal('.32')/Decimal('.15')).ln()
    close('no_b_arithmetic_clock',negative['omitted_b_time_s'],F(no_b),1e-9)
    check('no_b_control_fails_original_clock_threshold',abs(F(no_b)-F(rows[-1]['time_s']))>F('1e-9'))
    duplicate_Q=F(rows[-1]['cumulative_net_heat_j'])+md*(wi-wf)*(hv-hl)
    duplicate_error=F(rows[-1]['recovered_total_enthalpy_j'])-F(run['initial_total_enthalpy_j'])-duplicate_Q+F(rows[-1]['cumulative_vapor_enthalpy_j'])
    close('double_latent_arithmetic_residual',negative['double_latent_energy_residual_j'],duplicate_error,1e-5)
    check('double_latent_control_fails_original_energy_threshold',abs(duplicate_error)>F('1e-5'))
    check('no_native_failure_record',not (BASE/'native01/FAILURE.json').exists())
    equal('stderr_empty',(BASE/'supervised-native01/stderr.log').read_bytes(),b'')
    output=read(BASE/'supervised-native01/stdout.log')
    equal('saved_stdout_summary_matches_actual_final_state',(output['status'],output['actual_observations'],output['predicted_time_s'],output['water_out_kg'],output['net_heat_j'],output['run_elapsed_s']),('passed',13,rows[-1]['time_s'],rows[-1]['cumulative_water_out_kg'],rows[-1]['cumulative_net_heat_j'],run['elapsed_seconds']))
    check('original_failed_install_logs_retained',all((BASE/'install'/p).is_file() for p in ('INSTALL.log','INSTALL02.log','INSTALL03.log')))
    equal('all_native_supervisor_install_files_unchanged_during_audit',{str(p):sha(p) for p in protected},before_hashes)
    plot_source=BASE/'plot_saved.py'
    plot_record=read(BASE/'PLOT_RECORD.json')
    plot_directory=ROOT/'docs/sandbox/research/arlabosse-granular-drying-v1'
    csv_path=plot_directory/'CALCULATED_POINTS.csv'
    fields=['time_s','moisture_kg_water_kg_dry','water_out_kg_s','required_net_heat_w','cumulative_water_out_kg','cumulative_net_heat_j','cumulative_vapor_enthalpy_j','target_total_enthalpy_j','recovered_total_enthalpy_j','recovered_temperature_difference_k']
    with csv_path.open(newline='') as f:
        reader=csv.DictReader(f);header=reader.fieldnames;csv_rows=list(reader)
    equal('plot_CSV_columns',header,fields)
    equal('plot_CSV_row_count',len(csv_rows),13)
    check('all_130_CSV_values_match_saved_RUN',all(float(saved[k])==row[k] for saved,row in zip(csv_rows,rows) for k in fields))
    equal('plot_record_original_RUN_SHA',plot_record['source_run_sha256'],sha(BASE/'native01/RUN.json'))
    equal('plot_record_script_SHA',plot_record['script_sha256'],sha(plot_source))
    equal('plot_record_classification',plot_record['classification'],'plot_of_conditional_simulation_not_observations')
    equal('plot_record_count_and_no_new_EOS',(plot_record['actual_points'],plot_record['new_eos_calls']),(13,0))
    text=plot_source.read_text();tree=ast.parse(text)
    imports=[n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]+[a.name for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names]
    check('plot_script_has_no_model_or_EOS_import',not any(x and x.split('.')[0] in {'sludge_sandbox','iapws','CoolProp'} for x in imports))
    literals=[n.value for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,str)]
    expected_summary=f"{rows[-1]['time_s']:.2f} s model time  |  {rows[-1]['cumulative_water_out_kg']*1000:g} g water removed  |  {rows[-1]['cumulative_net_heat_j']/1000:.2f} kJ net heat"
    check('fixed_plot_summary_matches_this_actual_run',expected_summary in literals)
    check('fixed_plot_labels_match_inputs_and_preserve_conditions',all(part in text for part in ['Conditional contact drying','Model time (seconds)','Prescribed 90 C; 0.1 kg dry solid; 0.02 m2 nominal heated area; vapor pressure 1000 Pa.','13 calculated points joined by lines. Not measurements or brick-internal transport.','Transfer of the published rate to these conditions has unknown model error.']))
    check('fixed_plot_axis_limits_contain_every_saved_point',all(-3<=r['time_s']<=250 and 0<=r['moisture_kg_water_kg_dry']<=.36 and 0<=r['required_net_heat_w']<=250 for r in rows))
    check('three_plot_artifacts_exist',all((plot_directory/('CONDITIONAL_DRYING.'+ext)).is_file() for ext in ['png','svg','pdf']))
    METRICS['plot']={'matched_CSV_rows':13,'matched_CSV_values':130,'record':plot_record,'artifact_hashes':{str(p):sha(p) for p in [csv_path]+[plot_directory/('CONDITIONAL_DRYING.'+ext) for ext in ['png','svg','pdf']]},'scope':'Saved CSV value equality and static fixed-case script labels/limits only; no chart rerender or EOS.'}
    check('no_scientific_package_imports',not any(k.split('.')[0] in {'sludge_sandbox','iapws','CoolProp','numpy','scipy'} for k in sys.modules))
    def maximum(key):return max(abs(r[key]) for r in details)
    METRICS.update(run_elapsed_seconds=run['elapsed_seconds'],driver_elapsed_seconds=acceptance['elapsed_seconds'],outer_elapsed_seconds=status['elapsed_s'],observations=len(rows),original_native_assertions=len(acceptance['checks']),declared_inputs=len(inputs),source_installed_files=len(freeze),source_asset_entries=len(assets),runtime_modules=len(runtime['modules']),runtime_catalogs=len(runtime['catalogs']),predicted_conditional_time_s=rows[-1]['time_s'],water_removed_kg=rows[-1]['cumulative_water_out_kg'],net_heat_j=rows[-1]['cumulative_net_heat_j'],signed_outgoing_vapor_H_j=rows[-1]['cumulative_vapor_enthalpy_j'],max_clock_error_s=maximum('clock_error_s'),max_flow_error_kg_s=maximum('flow_error_kg_s'),max_heat_reference_error_j=maximum('heat_reference_error_j'),max_vapor_reference_error_j=maximum('signed_vapor_reference_error_j'),max_water_reference_error_kg=maximum('water_reference_error_kg'),max_power_error_w=maximum('power_error_w'),max_target_H_reference_error_j=maximum('target_H_reference_error_j'),max_recovered_H_reference_error_j=maximum('recovered_H_reference_error_j'),max_temperature_error_k=maximum('temperature_error_k'),max_exact_energy_balance_j=max(abs(v) for r in details for k,v in r['balances'].items() if not k.startswith('water')),max_exact_water_balance_kg=max(abs(v) for r in details for k,v in r['balances'].items() if k.startswith('water')),whole_final_energy_residual_j=details[-1]['balances']['recovered_whole_prefix'],negative_control_no_b_difference_s=float(F(no_b)-F(rows[-1]['time_s'])),negative_control_double_latent_residual_j=float(duplicate_error),rows=details,protected_file_hashes=before_hashes)


try:audit()
except BaseException as exc:check('audit_completed_without_exception',False,{'type':type(exc).__name__,'reason':str(exc)})
result={'status':'PASS' if all(c['passed'] for c in CHECKS) else 'FAIL','checks':len(CHECKS),'failures':[c for c in CHECKS if not c['passed']],'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-START,'metrics':METRICS,'assertions':CHECKS,'scope':'Saved-value and byte-identity audit only. Independent Fraction and 60-digit Decimal arithmetic, no scientific package import, EOS, installation or physical replay.','limitations':['The two saved water reference values are reused; this is not independent validation of their EOS.','Reported t(W) remains conditional on the borrowed empirical rate at unverified temperature/gas conditions.','Exact arithmetic over saved floats is not a claim of zero physical or model error.','Material, training, full-cycle eligibility remain false; no internal brick transport or free-temperature prediction.','Saved cleanup concerns the original process group; escaped sessions are not certified contained.']}
with (OUT/'SAVED_REVIEW02.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False)
summary={k:result[k] for k in ('status','checks','failures','elapsed_seconds')}
summary['metrics']={k:v for k,v in METRICS.items() if k not in ('rows','protected_file_hashes')}
print(json.dumps(summary,indent=2))
raise SystemExit(0 if result['status']=='PASS' else 1)
