"""One installed, conditional contact-drying path and primary-data oracles."""
from decimal import Decimal, localcontext
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import time

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
SCRATCH = Path('/private/tmp/arlabosse-granular-drying-v1')
INPUTS = dict(dry_mass_kg=.1, contact_area_m2=.02, temperature_k=363.15,
              ambient_vapor_pressure_pa=1000., initial_moisture=.32,
              final_moisture=.15, intervals=12, wall_seconds=30.)


def q_integral(nodes, start, end):
    a, b = F(str(start)), F(str(end))
    if b < a:
        return -q_integral(nodes, end, start)
    assert nodes[0][0] <= a <= b <= nodes[-1][0]
    value = F(0)
    for (x, y), (xx, yy) in zip(nodes, nodes[1:]):
        low, high = max(x, a), min(xx, b)
        if low < high:
            value += y*(high-low)+(yy-y)/(xx-x)*((high-x)**2-(low-x)**2)/2
    return value


def q_point(nodes, w):
    w = F(str(w))
    for (x, y), (xx, yy) in zip(nodes, nodes[1:]):
        if x <= w <= xx:
            return y+(yy-y)*(w-x)/(xx-x)
    raise ValueError('oracle_outside_source_domain')


def main():
    from sludge_sandbox.arlabosse_granular_drying import run_isothermal_drying
    from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
    from sludge_sandbox.run_service import runtime_identity

    out = SCRATCH/'native01'
    out.mkdir(exist_ok=False)
    start = time.monotonic()
    checks, oracles = [], []
    def save(name, value):
        with (out/name).open('x') as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write('\n')
    def require(ok, name, **detail):
        checks.append(dict(name=name, passed=bool(ok), **detail))
        if time.monotonic()-start >= 60.:
            raise RuntimeError('driver_deadline_60_seconds')
        if not ok:
            raise AssertionError(name)
    def close(actual, expected, limit, name):
        residual = float(F(actual)-F(expected))
        require(abs(residual) <= limit, name, actual=actual, expected=expected,
                residual=residual, limit=limit)

    try:
        before = runtime_identity()
        save('RUNTIME_BEFORE.json', before)
        save('INPUTS.json', INPUTS)
        run = run_isothermal_drying(ROOT, ROOT/'data/sandbox/water', **INPUTS)
        save('RUN.json', run)
        require(run['status'] == 'completed', 'actual_completed', status=run['status'], reason=run['reason'])
        require(len(run['observations']) == 13 and run['pending_observation'] is None, 'all_observations')
        require(run['elapsed_seconds'] < 30., 'original_run_budget')
        require(run['numerical_policy']['temperature_tolerance_k'] == 1e-6 and
                run['numerical_policy']['energy_tolerance_j'] == 1e-5 and
                run['numerical_policy']['water_tolerance_kg'] == 1e-12, 'original_runtime_gates')
        for key in ('material_qualified', 'training_eligible', 'full_firing_cycle', 'spatial_model'):
            require(run[key] is False, 'run_qualification_'+key)
        require(run['rate_condition_transfer_model_error'] is None, 'transfer_error_unknown')
        raw = (ROOT/'data/sandbox/research/arlabosse95/facts.json').read_bytes()
        require(hashlib.sha256(raw).hexdigest() ==
                '543d55918db7df6d0cc0f695c5dceadbdebda82b83f4fdde206266bcd12f2f16', 'original_q_facts')
        heat = []
        for row in json.loads(raw)['observations']:
            if row['figure'] == 2 and row['value'] is not None:
                val = row['value']
                heat.append((F(row['requested_moisture_kg_water_per_kg_dry_matter']),
                             F(int(val['numerator']), int(val['denominator']))))
        require(len(heat) == 6, 'six_original_q_nodes')
        water = WaterChemicalPotential(ROOT/'data/sandbox/water')
        molar_mass = water.reference.molar_mass_kg_mol
        values = {}
        for t in (363.15, 368.15):
            state = water.equilibrium_at_liquid_tp(t, 100000.)
            item = dict(temperature_k=t, liquid_pressure_pa=100000.,
                        liquid_h_j_kg=state.liquid.enthalpy_j_mol/molar_mass,
                        vapor_h_j_kg=state.vapor.enthalpy_j_mol/molar_mass,
                        molar_mass_kg_mol=molar_mass, source_ids=list(state.source_ids))
            oracles.append(item)
            values[t] = item
            require(True, f'oracle_water_returned_within_driver_budget_{t}')
        save('ORACLE_WATER.json', oracles)
        hl, hv = map(F, (values[363.15]['liquid_h_j_kg'], values[363.15]['vapor_h_j_kg']))
        latent95 = F(values[368.15]['vapor_h_j_kg'])-F(values[368.15]['liquid_h_j_kg'])
        delta_latent = hv-hl-latent95
        dry_h = 1434*(F(90)-95)+F('3.29')*(90**2-95**2)/2
        md, wi = F('.1'), F('.32')
        previous_w, previous_t = math.inf, -1.
        previous_target = previous_recovered = F(run['initial_total_enthalpy_j'])
        previous_q = previous_vapor = F(0)
        previous_water, previous_inventory = F(0), md*wi
        for row in run['observations']:
            i, w = row['index'], F(str(row['moisture_kg_water_kg_dry']))
            point = row['inverse']['state']
            require(float(w) < previous_w and row['time_s'] > previous_t, f'monotonic_{i}')
            with localcontext() as ctx:
                ctx.prec = 60
                wd = Decimal(w.numerator)/Decimal(w.denominator)
                a, b = Decimal('34.38'), Decimal('4.58')
                seconds = Decimal(3600)*Decimal('.1')/(Decimal('.02')*a)*(
                    (a*Decimal('.32')+b)/(a*wd+b)).ln()
                flow = Decimal('.02')*(a*wd+b)/Decimal(3600)
            close(row['time_s'], float(seconds), 1e-9, f'clock_{i}')
            close(row['water_out_kg_s'], float(flow), 1e-14, f'flow_{i}')
            q = md*(q_integral(heat, w, wi)+delta_latent*(wi-w))
            hout, mout = md*(wi-w)*hv, md*(wi-w)
            close(row['cumulative_net_heat_j'], float(q), 1e-5, f'heat_{i}')
            close(row['cumulative_vapor_enthalpy_j'], float(hout), 1e-5, f'vapor_h_{i}')
            close(row['cumulative_water_out_kg'], float(mout), 1e-12, f'waterout_{i}')
            power = F(float(flow))*(q_point(heat, w)+delta_latent)
            close(row['required_net_heat_w'], float(power), 1e-7, f'power_{i}')
            hexcess = latent95*(w-F('.8'))-q_integral(heat, '.8', w)
            h_expected = md*(dry_h+w*hl+hexcess)
            close(row['target_total_enthalpy_j'], float(h_expected), 1e-5, f'target_H_{i}')
            close(row['recovered_total_enthalpy_j'], float(h_expected), 1e-5, f'recovered_H_{i}')
            close(point['temperature_k'], 363.15, 1e-6, f'actual_inverse_T_{i}')
            target, recovered = F(row['target_total_enthalpy_j']), F(row['recovered_total_enthalpy_j'])
            qs, vs = F(row['cumulative_net_heat_j']), F(row['cumulative_vapor_enthalpy_j'])
            for key, value in (
                ('target_step', target-previous_target-F(row['step_heat_j'])+F(row['step_vapor_enthalpy_j'])),
                ('recovered_step', recovered-previous_recovered-F(row['step_heat_j'])+F(row['step_vapor_enthalpy_j'])),
                ('whole_prefix', recovered-F(run['initial_total_enthalpy_j'])-qs+vs),
                ('heat_steps', qs-previous_q-F(row['step_heat_j'])),
                ('vapor_steps', vs-previous_vapor-F(row['step_vapor_enthalpy_j']))):
                close(float(value), 0., 1e-5, f'{key}_{i}')
            close(float(md*w+F(row['cumulative_water_out_kg'])-md*wi), 0., 1e-12, f'mass_balance_{i}')
            current_water = F(row['cumulative_water_out_kg'])
            step_water = F(row['step_water_out_kg'])
            close(float(current_water-previous_water-step_water), 0., 1e-12, f'water_steps_{i}')
            close(float(md*w-previous_inventory+step_water), 0., 1e-12, f'local_water_inventory_{i}')
            for key in ('material_qualified', 'training_eligible', 'full_firing_cycle'):
                require(point[key] is False, f'point_{key}_{i}')
            for key in ('interpolation_model_error', 'temperature_extension_model_error',
                        'water_reference_model_error', 'experimental_uncertainty'):
                require(point[key] is None, f'unknown_{key}_{i}')
            require(1000. < point['model_equilibrium_vapor_pressure_pa'], f'vapor_boundary_{i}')
            require(row['water_out_kg_s'] > 0 and row['required_net_heat_w'] > 0, f'positive_flow_heat_{i}')
            previous_w, previous_t = float(w), row['time_s']
            previous_target, previous_recovered = target, recovered
            previous_q, previous_vapor = qs, vs
            previous_water, previous_inventory = current_water, md*w
        rows = run['observations']
        require(rows[0]['moisture_kg_water_kg_dry'] == .32 and
                rows[-1]['moisture_kg_water_kg_dry'] == .15, 'requested_endpoints')
        no_b_seconds = 3600.*.1/(.02*34.38)*math.log(.32/.15)
        duplicate_heat = rows[-1]['cumulative_net_heat_j']+float(md*(wi-F('.15'))*(hv-hl))
        duplicate_residual = (F(rows[-1]['recovered_total_enthalpy_j'])-
                              F(run['initial_total_enthalpy_j'])-F(duplicate_heat)+previous_vapor)
        negative = dict(omitted_b_time_s=no_b_seconds,
                        omitted_b_time_difference_s=no_b_seconds-rows[-1]['time_s'],
                        double_latent_energy_residual_j=float(duplicate_residual))
        save('NEGATIVE_CONTROLS.json', negative)
        require(abs(negative['omitted_b_time_difference_s']) > 1e-9, 'intercept_negative_control')
        require(abs(negative['double_latent_energy_residual_j']) > 1e-5, 'latent_negative_control')
        after = runtime_identity()
        save('RUNTIME_AFTER.json', after)
        require(before == after, 'runtime_unchanged')
        elapsed = time.monotonic()-start
        require(elapsed < 60., 'final_driver_budget', elapsed_seconds=elapsed)
        save('ACCEPTANCE.json', dict(status='passed', checks=checks,
            elapsed_seconds=elapsed, actual_observations=13,
            material_qualified=False, full_firing_cycle=False,
            scientific_scope='conditional_model_arithmetic_not_public_holdout_validation'))
        print(json.dumps(dict(status='passed', actual_observations=13,
            predicted_time_s=rows[-1]['time_s'], water_out_kg=rows[-1]['cumulative_water_out_kg'],
            net_heat_j=rows[-1]['cumulative_net_heat_j'], run_elapsed_s=run['elapsed_seconds'])))
    except BaseException as exc:
        save('FAILURE.json', dict(type=type(exc).__name__, reason=str(exc), checks=checks,
                                 oracle_water=oracles, elapsed_seconds=time.monotonic()-start))
        raise


if __name__ == '__main__':
    main()
