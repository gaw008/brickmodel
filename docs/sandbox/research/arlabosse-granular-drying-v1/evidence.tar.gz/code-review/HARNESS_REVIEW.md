# Granular contact-drying native01: bounded static harness review

**APPROVE within static pre-execution scope.** Reviewed the original plan, driver and existing-supervisor wrapper. No EOS, physical path, installation or additional tests were run by this review. Both Python files compile without execution. Neither native01 nor supervised-native01 existed at this snapshot.

## Parameters, references and gates

The actual call matches the preregistered design: dry mass 0.1 kg, nominal heated area 0.02 m², controlled material temperature 363.15 K, external vapor pressure 1000 Pa, shared liquid/total pressure 100000 Pa, W=.32→.15 and 12 reporting intervals/13 observations. The limits remain 30 s for the run API, 60 s for the driver and 80 s outer supervision with 5 s cleanup grace.

The driver saves INPUTS and raw RUN before requiring completion, the full observation count, no pending candidate or numerical success. On failure, it retains the original RUN, evaluated oracle records and accumulated assertion details. Output/attempt directories and individual JSON files use exclusive creation, preventing silent replacement of a prior attempt.

The independent heat reference loads the original six rational q95 nodes under the fixed original facts SHA and integrates them with Fraction instead of calling the model's heat method. A separate existing water provider supplies the two registered 90/95 °C reference states with the same pressure/molar-mass convention; their raw h values and source IDs are saved. The resulting delta latent term, original dry-Cp polynomial and reference excess-enthalpy integral reconstruct total H at each observed W. These are independent arithmetic/reference organizations using shared physical constituents, not an independent EOS or experimental validation.

The clock uses 60-digit Decimal ln with the original a=34.38 and b=4.58. Per-row checks independently cover clock, flow, cumulative heat, signed outgoing vapor enthalpy, water removal, required power, target/recovered H and actual inverse temperature. Energy increments and whole prefixes use Fraction over saved values. The registered clock/flow/power/T/energy/water thresholds remain unchanged. Source and point qualification/error restrictions, evaporation direction, positive flow/power, monotonic W/time and requested endpoints are checked. No-b and double-latent controls are pure arithmetic; their computed values are saved before assertion and require no additional path.

## Corrections verified

The initial driver checked local heat and vapor increments but omitted the analogous saved step-water relation. The final driver now checks both `cumulative_water_i - cumulative_water_previous - step_water_i` and `md*W_i - previous_inventory + step_water_i` at the original 1e-12 kg threshold, including the initial row.

Each separate oracle-water return now crosses a driver-deadline check. The final elapsed scalar is captured, checked under the unchanged 60 s gate and then saved as that same scalar. These changes do not alter physical inputs, numerical limits or resource budgets. No unresolved actionable finding remains in the assigned static scope.

## Supervision and identity

The wrapper uses the fixed installed interpreter with `-I`, unsets PYTHONPATH and runs outside the repository. Its before/after input set includes the wrapper/driver/plan/supervisor and freeze record, granular source definition plus every declared rate asset, wet metadata plus its assets/upstream source assets, fixed water-source files, all source/installed package files and installed iapws files excluding caches. The existing supervisor records return code, elapsed time and original-process-group cleanup, and rejects an otherwise successful run if a declared input changes. Installation/freeze correspondence remains the separate pre-launch gate carried out by the parent.

The API/driver deadlines are checked at finite operation boundaries; only the outer supervisor can terminate a blocked process. Existing containment is limited to the original process group and makes no escaped-session claim. A future `passed` result would verify this conditional model's arithmetic under its original thresholds; it would not establish source-condition transfer, held-out drying-time validity, internal brick transport or a full firing cycle. Material/training/full-cycle qualifications must remain false.

## Exact reviewed snapshot

| File | Bytes | SHA-256 |
|---|---:|---|
| `NATIVE_PLAN.md` | 3558 | `07840ba038da67b8bb0138dacdbed082223234d83a2bd92129816e5a95cc9c33` |
| `native_driver.py` | 10877 | `69f22c56a473e5a16eb3e154df075e53d6212b7b45483ea17842bd47a56b12d6` |
| `run_supervised_native01.py` | 2236 | `146e2d49a5740728c262d50778806ee1b1a802ae379dfde84efe3ebe515ba6be` |

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — static harness review only; actual supervised acceptance remains to be performed.
