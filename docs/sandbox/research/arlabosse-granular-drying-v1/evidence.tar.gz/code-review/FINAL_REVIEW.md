# Granular contact drying: independent finite code review

**APPROVE for the reviewed candidate.** Baseline `641377f`. Final validation: **41 passed in 0.12 s**, comprising 26 author tests and 15 independent review tests; no failures/errors/skips. Evidence: [FINAL_TESTS.log](FINAL_TESTS.log), [FINAL_TESTS.xml](FINAL_TESTS.xml), [FINAL_REVIEW.json](FINAL_REVIEW.json).

The review covers the new granular drying module, its tests and pinned source definition. I modified no production, installed no package, and ran no water EOS or physical drying trajectory. Numerical/process probes use manufactured thermal objects. Source-admission probes use copied, byte-identical pinned assets inside disposable review directories; mutations affect only those copies.

## Reported findings resolved

- **HIGH — terminal budget/cancel state.** Final source revalidation originally happened after the last stop check; it could consume the deadline or receive cancellation and still return `completed`. The final elapsed-time snapshot could also contradict completion. The candidate checks again after final revalidation and prevents completion when its final recorded elapsed time meets/exceeds the budget. Independent final-revalidation deadline/cancel and terminal-timestamp cases pass while retaining the accepted observations.
- **HIGH — finite records could hide loss of isothermal control.** Finite subnormal mass arithmetic could return completion despite a control-temperature error. The interim `b15e970…` probe with dry mass `1e-320` produced a **−0.026348050783553845 K** endpoint error while all recorded open-energy residuals were zero. The candidate now records explicit numerical acceptance policy, preserves each candidate in `pending_observation`, and checks temperature, local/cumulative energy and water balance before appending an accepted observation. Positive inventory, step removal/heat, flow and power guards reject unresolved scales. Separate independent probes verify that excessive temperature, energy and water residuals each reject completion and retain the failed candidate.
- **MEDIUM — avoidable intermediate overflow.** Public elapsed-time evaluation originally multiplied `3600*mass` before dividing by area, rejecting `mass=area=1e308` even though the resulting time is finite. Exact rational final scaling now avoids that intermediate overflow while retaining a finite-output gate. An independent 80-digit Decimal reference passes.

Original actual RED evidence remains unchanged: [INDEPENDENT_RED.log](INDEPENDENT_RED.log), [INDEPENDENT_RED.xml](INDEPENDENT_RED.xml), [RED_SNAPSHOT_SHA256.txt](RED_SNAPSHOT_SHA256.txt): **4 failed, 1 passed**. The concrete interim quantization result and its source hash remain in [TINY_MASS_INTERIM_SUMMARY.json](TINY_MASS_INTERIM_SUMMARY.json) and [TINY_MASS_INTERIM_RESULT.json](TINY_MASS_INTERIM_RESULT.json).

`TINY_MASS_RED_RESULT.json` was collected after the author had already added an interim underflow guard; despite its initially chosen filename, that file is a controlled **failed** result with no observations, not the original erroneous completion. Its accompanying console-only attempt to take the maximum over the empty prefix failed after writing the JSON. It is retained and is not counted as RED completion evidence. The later `1e-320` interim probe above demonstrates the remaining control-temperature defect without that ambiguity.

## Source, model and record boundaries

The source definition SHA matches the production constant, and all **8 direct assets/thermal-upstream entries** match their declared hashes. Real-byte tests confirm that changed rate assets, changed thermal metadata and changed source-definition bytes are rechecked after construction; an asset symlink resolving outside the admitted root is rejected.

I read the pinned article's coefficient paragraph and independently viewed original equation 3, equation 4, and the image containing equations 5/6. Equation 3 contains `aW+b`, the coefficient paragraph gives a=34.38 and b=4.58, and the printed equation 6 omits b. The metadata transparently labels the b-retaining conservation solution as a derived correction, not an author erratum. The source rate domain and narrower thermal joint domain remain distinct.

The common wet model supplies the same-reference heat increments and signed outgoing vapor enthalpy; the new code updates total H and actually inverts it instead of overwriting the resulting temperature. Negative signed vapor enthalpy remains valid. Output sampling selects report locations along the analytic moisture trajectory and is not represented as an ODE convergence test. Numerical tolerance settings are explicit, finite and recorded separately from physical uncertainty.

Known source/numerical failures retain accepted prefixes and available pending coordinates/energy/inverse data. Rejected heat calculations retain the attempted coordinate. Unrepresentable power is recorded as null plus a diagnostic string, preserving strict JSON serialization. The final domain/qualification metadata keeps rate-condition transfer, source-temperature/gas correspondence and experimental uncertainty unknown, with material/training/full-cycle flags false.

This synchronous function checks deadline/cancellation at operation/report boundaries; it does not preempt an EOS operation blocked inside a call. Actual execution therefore remains a separate supervised-run gate. The model is conditional contact drying under imposed material temperature and external vapor pressure, not internal brick transport, free-temperature prediction, validated drying time, industrial fuel consumption, or a full firing cycle.

## Exact accepted snapshot

| File | SHA-256 |
|---|---|
| `src/sludge_sandbox/arlabosse_granular_drying.py` | `f1ec79c0b606ebcc58029f24162ac25eb75825b4944aca86c693716b3d274b7a` |
| `tests/sandbox/test_arlabosse_granular_drying.py` | `5aa56dac4c4b3f05928598dac5ef28751a6f3205009512bda1cb78f933dc4be8` |
| `data/sandbox/research/arlabosse-granular-drying-v1/source.json` | `7c29b68de800ba52c7dac2565d5d4edf8ddaf259da8aa6a6c5aef66f430b3c9e` |

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — no unresolved actionable finding in this finite source/code review; actual physical execution and validation remain separate gates.
