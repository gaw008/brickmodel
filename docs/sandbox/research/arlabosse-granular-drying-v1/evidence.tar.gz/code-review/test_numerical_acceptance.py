"""Independent manufactured violations distinguish acceptance gates from reports."""
from types import SimpleNamespace
from test_independent_granular import args, model, run, Thermal


def test_returned_inverse_with_small_temperature_but_excess_energy_residual_is_pending(args,monkeypatch):
    original=Thermal.inverse_enthalpy
    def coarse(self,*a,**kw):
        inverse=original(self,*a,**kw)
        state=self.evaluate(inverse.state.temperature_k+1e-7,kw['moisture'])
        return SimpleNamespace(state=state,to_record=lambda:{'state':state.to_record()})
    monkeypatch.setattr(Thermal,'inverse_enthalpy',coarse)
    result=run(args)
    assert result['status']=='failed'
    assert result['reason']=='numerical_gate_energy_balance'
    assert result['observations']==[]
    candidate=result['pending_observation']
    assert abs(candidate['recovered_temperature_difference_k'])<result['numerical_policy']['temperature_tolerance_k']
    assert abs(candidate['open_energy_residual_j'])>result['numerical_policy']['energy_tolerance_j']


def test_inconsistent_water_out_is_rejected_while_thermal_balance_passes(args,monkeypatch):
    original=Thermal.isothermal_drying_heat
    def inconsistent(self,*a,**kw):
        heat=original(self,*a,**kw)
        heat.removed_water_kg*=1.1
        return heat
    monkeypatch.setattr(Thermal,'isothermal_drying_heat',inconsistent)
    result=run(args)
    assert result['status']=='failed'
    assert result['reason']=='numerical_gate_water_balance'
    assert len(result['observations'])==1
    candidate=result['pending_observation']
    assert abs(candidate['water_balance_residual_kg'])>result['numerical_policy']['water_tolerance_kg']
    assert abs(candidate['open_energy_residual_j'])<=result['numerical_policy']['energy_tolerance_j']
