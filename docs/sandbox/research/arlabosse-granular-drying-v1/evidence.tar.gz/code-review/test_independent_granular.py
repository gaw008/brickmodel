"""Independent manufactured thermal/process probes; no EOS construction."""
from decimal import Decimal, localcontext
import math
from types import SimpleNamespace
import pytest
from sludge_sandbox import arlabosse_granular_drying as model


class Thermal:
    def __init__(self, *args):
        self.definition_calls = 0
    def definition(self):
        self.definition_calls += 1
        return {'classification': 'independent_manufactured_fixture'}
    def evaluate(self, temperature, moisture):
        h=1200.125*(temperature-300)-1000000.125*moisture+12345.67*moisture**2
        values=dict(temperature_k=temperature,specific_enthalpy_j_kg_dry=h,
                    total_desorption_heat_j_kg_water=200000.123-24691.34*moisture,
                    model_equilibrium_vapor_pressure_pa=10000*moisture)
        return SimpleNamespace(**values,to_record=lambda:values.copy())
    def isothermal_drying_heat(self,t,wi,wf,dry_mass_kg):
        removed=dry_mass_kg*(wi-wf)
        return SimpleNamespace(heat_j=dry_mass_kg*(200000.123*(wi-wf)-12345.67*(wi**2-wf**2)),
            vapor_carried_enthalpy_j=removed*(-800000.002),removed_water_kg=removed)
    def inverse_enthalpy(self,target_j,*,dry_mass_kg,moisture,**kwargs):
        t=300+(target_j/dry_mass_kg+1000000.125*moisture-12345.67*moisture**2)/1200.125
        state=self.evaluate(t,moisture)
        residual=dry_mass_kg*state.specific_enthalpy_j_kg_dry-target_j
        return SimpleNamespace(state=state,residual_j=residual,
            to_record=lambda:{'state':state.to_record(),'residual_j':residual})


@pytest.fixture
def args(monkeypatch):
    monkeypatch.setattr(model,'_load_source',lambda root:{'parameters':{'a':{'value':'34.38'},'b':{'value':'4.58'}}})
    monkeypatch.setattr(model,'ArlabosseWetThermodynamics',Thermal)
    return dict(dry_mass_kg=.1,contact_area_m2=.02,temperature_k=358.15,
        ambient_vapor_pressure_pa=500.,initial_moisture=.32,final_moisture=.15,
        intervals=4,wall_seconds=10.)


def run(args,**changes):
    return model.run_isothermal_drying('manufactured','manufactured',**(args|changes))


def test_independent_normal_control_sanity(args):
    result=run(args)
    assert result['status']=='completed'
    assert all(abs(r['recovered_temperature_difference_k'])<1e-10 for r in result['observations'])


def test_final_source_revalidation_cannot_return_completed_after_deadline(args,monkeypatch):
    clock={'t':0.}
    monkeypatch.setattr(model.time,'monotonic',lambda:clock['t'])
    old=Thermal.definition
    def definition(self):
        value=old(self)
        if self.definition_calls==2:clock['t']=11.
        return value
    monkeypatch.setattr(Thermal,'definition',definition)
    result=run(args)
    assert result['status']=='time_budget_exceeded',result
    assert len(result['observations'])==5
    assert result['elapsed_seconds']==11.


def test_final_source_revalidation_cannot_lose_cancel(args,monkeypatch):
    flag={'cancel':False}
    old=Thermal.definition
    def definition(self):
        value=old(self)
        if self.definition_calls==2:flag['cancel']=True
        return value
    monkeypatch.setattr(Thermal,'definition',definition)
    result=run(args,cancel=lambda:flag['cancel'])
    assert result['status']=='cancelled',result
    assert len(result['observations'])==5


def test_finite_public_mass_area_ratio_avoids_intermediate_overflow(args):
    law=model.ArlabosseGranularFlux('manufactured')
    with localcontext() as ctx:
        ctx.prec=80
        a,b=Decimal('34.38'),Decimal('4.58')
        expected=Decimal(3600)/a*((a*Decimal('.32')+b)/(a*Decimal('.15')+b)).ln()
    actual=law.elapsed_seconds(.32,.15,dry_mass_kg=1e308,contact_area_m2=1e308)
    assert math.isfinite(actual) and actual==pytest.approx(float(expected),abs=1e-12)


def test_tiny_mass_quantization_cannot_complete_off_control_temperature(args):
    result=run(args,dry_mass_kg=math.ulp(0.))
    assert result['status']!='completed' or all(abs(r['recovered_temperature_difference_k'])<=1e-10
        for r in result['observations']),result
