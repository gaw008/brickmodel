"""Additional concrete boundary regressions for the reported completion defects."""
import inspect
from test_independent_granular import args, model, run, Thermal


def test_positive_representable_water_mass_still_requires_isothermal_acceptance(args):
    result=run(args,dry_mass_kg=1e-320)
    assert result['status']!='completed' or all(abs(r['recovered_temperature_difference_k'])<=1e-10
        for r in result['observations']),result


def test_final_elapsed_snapshot_classifies_deadline(args,monkeypatch):
    direct_calls=0
    def now():
        nonlocal direct_calls
        if inspect.currentframe().f_back.f_code.co_name=='run_isothermal_drying':
            direct_calls+=1
            return 0. if direct_calls==1 else 11.
        return 0.
    monkeypatch.setattr(model.time,'monotonic',now)
    result=run(args)
    assert result['elapsed_seconds']==11.
    assert result['status']=='time_budget_exceeded',result


def test_heat_failure_keeps_attempted_coordinate_and_accepted_prefix(args,monkeypatch):
    def fail(*args,**kwargs):
        raise ValueError('manufactured_heat_failure')
    monkeypatch.setattr(Thermal,'isothermal_drying_heat',fail)
    result=run(args)
    assert result['status']=='failed'
    assert len(result['observations'])==1
    pending=result['pending_observation']
    assert pending is not None
    assert pending['index']==1 and pending['time_s']>0
    assert pending['moisture_kg_water_kg_dry']<args['initial_moisture']
