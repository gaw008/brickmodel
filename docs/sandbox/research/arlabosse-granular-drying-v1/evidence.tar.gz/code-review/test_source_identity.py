"""Real pinned source bytes in disposable review roots; no thermal construction."""
import hashlib
import json
from pathlib import Path
import pytest
from sludge_sandbox import arlabosse_granular_drying as model

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')

@pytest.fixture
def source_root(tmp_path):
    source_path=ROOT/model.SOURCE_PATH
    source=json.loads(source_path.read_bytes())
    targets=[{'path':model.SOURCE_PATH}]+source['assets']+[source['thermal_upstream']]
    for item in targets:
        target=tmp_path/item['path']
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((ROOT/item['path']).read_bytes())
    return tmp_path,source


def test_real_pinned_source_and_assets_admit_without_thermal(source_root):
    root,source=source_root
    law=model.ArlabosseGranularFlux(root)
    assert law.definition()==source
    assert hashlib.sha256((root/model.SOURCE_PATH).read_bytes()).hexdigest()==model.SOURCE_SHA256


@pytest.mark.parametrize('target_kind',['rate_asset','thermal_upstream','source_definition'])
def test_mutation_after_construction_is_rechecked(source_root,target_kind):
    root,source=source_root
    law=model.ArlabosseGranularFlux(root)
    relative={'rate_asset':source['assets'][0]['path'],
              'thermal_upstream':source['thermal_upstream']['path'],
              'source_definition':model.SOURCE_PATH}[target_kind]
    target=root/relative
    target.write_bytes(target.read_bytes()+b' ')
    with pytest.raises(model.GranularDryingError,match='changed'):
        law._coefficients()


def test_asset_symlink_outside_admitted_root_is_rejected(source_root,tmp_path):
    root,source=source_root
    p=root/source['assets'][0]['path']
    outside=tmp_path.parent/(tmp_path.name+'-outside-asset.gif')
    outside.write_bytes(p.read_bytes())
    p.unlink()
    p.symlink_to(outside)
    with pytest.raises(model.GranularDryingError,match='outside_repository'):
        model.ArlabosseGranularFlux(root)
