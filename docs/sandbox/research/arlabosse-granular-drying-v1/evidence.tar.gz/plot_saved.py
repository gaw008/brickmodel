"""Plot only the saved, accepted run. No model/EOS imports or recomputation."""
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
SCRATCH = Path('/private/tmp/arlabosse-granular-drying-v1')
DEST = ROOT/'docs/sandbox/research/arlabosse-granular-drying-v1'
raw = (SCRATCH/'native01/RUN.json').read_bytes()
run = json.loads(raw)
assert run['status'] == 'completed' and run['material_qualified'] is False
rows = run['observations']
assert len(rows) == 13
t = [r['time_s'] for r in rows]
w = [r['moisture_kg_water_kg_dry'] for r in rows]
power = [r['required_net_heat_w'] for r in rows]
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'svg.fonttype': 'path'})
fig, axs = plt.subplots(1, 2, figsize=(11, 5.3))
fig.patch.set_facecolor('#faf9f6')
for ax in axs:
    ax.set_facecolor('#faf9f6')
    ax.grid(axis='y', color='#dcdedb', linewidth=.7)
    ax.set_axisbelow(True)
    ax.set_xlim(-3, 250)
    ax.set_xlabel('Model time (seconds)', labelpad=10)
    ax.tick_params(colors='#33434b')
axs[0].plot(t, w, marker='o', markersize=4, color='#176986', linewidth=2)
axs[0].set_ylim(0, .36)
axs[0].set_ylabel('Moisture W (kg water / kg dry solid)')
axs[1].plot(t, power, marker='o', markersize=4, color='#b9562d', linewidth=2)
axs[1].set_ylim(0, 250)
axs[1].set_ylabel('Required net heat rate (W)')
fig.suptitle('Conditional contact drying', x=.08, y=.98, ha='left',
             fontsize=21, fontweight='bold', color='#203842')
fig.text(.08, .88, '246.16 s model time  |  17 g water removed  |  43.01 kJ net heat',
         color='#33434b', fontsize=12)
fig.text(.08, .065,
         'Prescribed 90 C; 0.1 kg dry solid; 0.02 m2 nominal heated area; vapor pressure 1000 Pa.\n'
         '13 calculated points joined by lines. Not measurements or brick-internal transport.\n'
         'Transfer of the published rate to these conditions has unknown model error.',
         fontsize=9, color='#46565e', linespacing=1.5)
fig.subplots_adjust(left=.08, right=.97, bottom=.28, top=.78, wspace=.30)
for suffix in ('png', 'svg', 'pdf'):
    path = DEST/('CONDITIONAL_DRYING.'+suffix)
    if path.exists():
        raise FileExistsError(path)
    fig.savefig(path, dpi=160, facecolor=fig.get_facecolor())
plt.close(fig)
fields = ['time_s','moisture_kg_water_kg_dry','water_out_kg_s','required_net_heat_w',
          'cumulative_water_out_kg','cumulative_net_heat_j',
          'cumulative_vapor_enthalpy_j','target_total_enthalpy_j',
          'recovered_total_enthalpy_j','recovered_temperature_difference_k']
with (DEST/'CALCULATED_POINTS.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    writer.writerows({k: r[k] for k in fields} for r in rows)
assert (SCRATCH/'native01/RUN.json').read_bytes() == raw
record = {'source_run_sha256': hashlib.sha256(raw).hexdigest(),
          'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'matplotlib_version': importlib.metadata.version('matplotlib'),
          'actual_points': 13, 'new_eos_calls': 0,
          'classification': 'plot_of_conditional_simulation_not_observations'}
with (SCRATCH/'PLOT_RECORD.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
