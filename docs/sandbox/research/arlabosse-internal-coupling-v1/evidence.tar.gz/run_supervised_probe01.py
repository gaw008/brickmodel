"""Single frozen-source probe under the existing process-group supervisor."""
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK = Path('/private/tmp/arlabosse-internal-coupling-v1')
PYTHON = Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python')
INSTALLED = PYTHON.parent.parent/'lib/python3.12/site-packages/sludge_sandbox'
SUPERVISOR = ROOT/'docs/sandbox/research/research-process-supervisor/supervisor.py'
spec = importlib.util.spec_from_file_location('sorption_probe_supervisor', SUPERVISOR)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
inputs = {Path(__file__).resolve(), WORK/'native_case.py', WORK/'probe_driver.py',
          WORK/'PROBE_PLAN.md', WORK/'install/SOURCE_FREEZE.json', SUPERVISOR}
wet = ROOT/'data/sandbox/research/arlabosse-wet-thermo-v1/model.json'
inputs.add(wet)
definition = json.loads(wet.read_bytes())
inputs.update(ROOT/a['path'] for a in definition['assets'])
for item in definition['upstream']:
    path=ROOT/item['path']; inputs.add(path)
    inputs.update(ROOT/a['path'] for a in json.loads(path.read_bytes())['assets'])
for name in ('IAPWS95-2018.pdf','iapws-1.5.5-py3-none-any.whl','iapws-1.5.5-iapws95.py',
             'iapws-1.5.5-LICENSE','source_facts.json'):
    inputs.add(ROOT/'data/sandbox/water'/name)
for name in ('data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json',
             'data/sandbox/research/water-element-convention-v1/facts.json',
             'data/sandbox/research/water-element-convention-v1/source-excerpt.txt',
             'data/sandbox/thermochemistry/nist_gases_v1.json'):
    inputs.add(ROOT/name)
facts=json.loads((ROOT/'data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json').read_bytes())
inputs.update(ROOT/row['cache_path'] for row in facts)
for directory in (ROOT/'src/sludge_sandbox', INSTALLED, INSTALLED.parent/'iapws'):
    inputs.update(p for p in directory.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and p.suffix!='.pyc')
result=module.run_attempt(WORK/'supervised-probe01',
    ['/usr/bin/env','-u','PYTHONPATH',str(PYTHON),'-I',str(WORK/'probe_driver.py')],
    cwd='/private/tmp',input_paths=sorted(inputs),timeout_s=110.,cleanup_grace_s=5.)
print(json.dumps({k:v for k,v in result.items() if not k.startswith('inputs_')},indent=2))
sys.exit(0 if result['status']=='complete' and result['returncode']==0 else 1)
