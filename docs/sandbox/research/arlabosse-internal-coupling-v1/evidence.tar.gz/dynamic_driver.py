"""Unique predeclared source-sorption integration; no reference EOS rerun."""
import importlib.util
import json
from fractions import Fraction as F
from pathlib import Path
import time
import traceback

from sludge_sandbox.source_wet_column import integrate_source_column

WORK = Path('/private/tmp/arlabosse-internal-coupling-v1')
spec = importlib.util.spec_from_file_location('dynamic_case', WORK/'native_case.py')
case = importlib.util.module_from_spec(spec)
spec.loader.exec_module(case)
OUT = WORK/'dynamic01'
OUT.mkdir(exist_ok=False)
start = time.monotonic()

def save(name, value):
    (OUT/name).write_text(json.dumps(case.serialize(value), indent=2, allow_nan=False)+'\n')

try:
    column, initial, points = case.make_case(lambda p: save('CONSTRUCTION_PREFIX.json', p))
    save('INITIAL.json', {'states': initial, 'points': points, 'provenance': column.provenance()})
    run = integrate_source_column(column, initial, duration_s=.05, steps=2,
        maximum_wall_seconds=60., energy_roundoff_budget_j=1e-8,
        inventory_roundoff_budget_mol=1e-12)
    save('RUN.json', run)
    checks = []
    def check(label, condition):
        checks.append({'id': label, 'passed': bool(condition)})
    check('completed', run.status=='completed' and run.reason is None)
    check('counts', len(run.states)==3 and len(run.ledgers)==2 and len(run.observations)==2
          and run.evaluations_attempted==run.evaluations_completed==6)
    check('clock', run.times_s==(F(), F(.05)/2, F(.05)))
    check('identity', run.model_identity==column.model_identity)
    check('false_material', run.material_qualified is False)
    check('roundoff_energy_budget', run.energy_roundoff_used_j<=F(1e-8))
    check('roundoff_inventory_budget', run.inventory_roundoff_used_mol<=F(1e-12))
    cumulative_u = F()
    cumulative_w = F()
    cumulative_inert = [F(), F()]
    total_u = lambda states: sum((F(s.internal_energy_j) for s in states), F())
    total_w = lambda states: sum((F(s.liquid_water_mol)+F(s.gas_amounts_mol[2]) for s in states), F())
    total_g = lambda states,k: sum((F(s.gas_amounts_mol[k]) for s in states), F())
    for n, (old,new,ledger,observation) in enumerate(zip(run.states,run.states[1:],run.ledgers,run.observations)):
        prefix=f'step{n}'
        check(prefix+'_clock',ledger.duration_s==run.times_s[n+1]-run.times_s[n])
        check(prefix+'_closed',all(face.energy_j==0 and all(x==0 for x in face.gas_mol)
              for face in (ledger.faces[0],ledger.faces[-1])))
        check(prefix+'_active_heat',ledger.faces[1].conduction_j!=0)
        check(prefix+'_active_gas',any(v!=0 for v in ledger.faces[1].gas_mol))
        check(prefix+'_active_enthalpy',any(v!=0 for v in (
            *ledger.faces[1].diffusive_enthalpy_j, *ledger.faces[1].advective_enthalpy_j)))
        check(prefix+'_active_phase',all(v!=0 for v in ledger.phase_water_mol))
        for face in ledger.faces:
            check(prefix+f'_face{face.face_id}_energy',face.energy_j==face.conduction_j+
                  sum(face.diffusive_enthalpy_j,F())+sum(face.advective_enthalpy_j,F())+
                  face.energy_decomposition_roundoff_j)
        for i,(a,b,cell,policy) in enumerate(zip(old,new,observation.cells,column.inverse_policies)):
            label=prefix+f'_cell{i}'
            left,right=ledger.faces[i:i+2]
            check(label+'_U_ledger',F(b.internal_energy_j)-F(a.internal_energy_j)==
                  left.energy_j-right.energy_j+ledger.roundoff.energy_j[i])
            check(label+'_Nc_ledger',F(b.liquid_water_mol)-F(a.liquid_water_mol)==
                  -ledger.phase_water_mol[i]+ledger.roundoff.liquid_mol[i])
            for k in range(3):
                check(label+f'_gas{k}_ledger',F(b.gas_amounts_mol[k])-F(a.gas_amounts_mol[k])==
                    left.gas_mol[k]-right.gas_mol[k]+(ledger.phase_water_mol[i] if k==2 else F())+
                    ledger.roundoff.gas_mol[i][k])
            inv=cell.inverse; p=inv.point; eq=cell.phase.equilibrium
            residual=F(p.total_internal_energy_j)-F(b.internal_energy_j)
            check(label+'_actual_target',inv.target_energy_j==b.internal_energy_j and inv.energy_residual_j==residual)
            check(label+'_inverse_U',abs(residual)+F(p.energy_error_j)<=F(policy.energy_tolerance_j))
            check(label+'_inverse_T',inv.temperature_error_bound_k<=policy.temperature_tolerance_k)
            check(label+'_T_domain',325<=p.temperature_k<=338)
            check(label+'_W_domain',.15<=p.moisture_kg_water_per_kg_dry<=.8)
            check(label+'_P_domain',90000<=p.pressure_pa-p.pressure_error_pa and p.pressure_pa+p.pressure_error_pa<=110000)
            check(label+'_actual_liquid_P',eq.pure_equilibrium.liquid.state.pressure_pa==p.pressure_pa)
            check(label+'_aw',eq.equilibrium_partial_pressure_pa==float(F(p.activity)*F(eq.pure_equilibrium.equilibrium_partial_pressure_pa)))
            check(label+'_mu',abs(eq.chemical_potential_residual_j_mol)<=1e-7)
            check(label+'_entropy',cell.phase.entropy_production_w_k is not None and cell.phase.entropy_production_w_k>0)
            check(label+'_positive',b.liquid_water_mol>0 and all(v>=0 for v in b.gas_amounts_mol))
            check(label+'_false_flags',p.material_qualified is False and p.training_eligible is False)
        error_u=sum(ledger.roundoff.energy_j,F())
        error_w=sum(ledger.roundoff.liquid_mol,F())+sum((r[2] for r in ledger.roundoff.gas_mol),F())
        check(prefix+'_global_U',total_u(new)-total_u(old)==error_u)
        check(prefix+'_global_W',total_w(new)-total_w(old)==error_w)
        cumulative_u+=error_u; cumulative_w+=error_w
        check(prefix+'_prefix_U',total_u(new)-total_u(initial)==cumulative_u)
        check(prefix+'_prefix_W',total_w(new)-total_w(initial)==cumulative_w)
        for k in range(2):
            error_g=sum((r[k] for r in ledger.roundoff.gas_mol),F())
            cumulative_inert[k]+=error_g
            check(prefix+f'_gas{k}_global',total_g(new,k)-total_g(old,k)==error_g)
            check(prefix+f'_gas{k}_prefix',total_g(new,k)-total_g(initial,k)==cumulative_inert[k])
    if run.observations:
        for i,(first,last,state) in enumerate(zip(points,run.observations[-1].cells,run.states[-1])):
            p=last.inverse.point
            check(f'cell{i}_resolved_delta_T',abs(p.temperature_k-first.temperature_k)>
                  last.inverse.temperature_error_bound_k+1e-6)
            check(f'cell{i}_changed_Nc',state.liquid_water_mol!=initial[i].liquid_water_mol)
            check(f'cell{i}_changed_P',p.pressure_pa!=first.pressure_pa)
    finished=time.monotonic()
    check('integrator_wall',run.elapsed_seconds<60.)
    check('whole_driver_wall',finished-start<80.)
    report={'passed':all(c['passed'] for c in checks),'checks':checks,
        'integrator_seconds':run.elapsed_seconds,'driver_seconds':finished-start,
        'model_duration_seconds':float(run.times_s[-1]), 'evaluations':run.evaluations_completed,
        'final_temperature_k':[c.inverse.point.temperature_k for c in run.observations[-1].cells] if run.observations else [],
        'final_pressure_pa':[c.inverse.point.pressure_pa for c in run.observations[-1].cells] if run.observations else [],
        'material_qualified':False, 'spatial_temporal_convergence_demonstrated':False}
    save('ACCEPTANCE.json',report)
    print(json.dumps(report))
    assert report['passed'], 'dynamic_acceptance_failed'
except BaseException as exc:
    save('FAILURE.json',{'type':type(exc).__name__,'message':str(exc),
         'elapsed_seconds':time.monotonic()-start,'traceback':traceback.format_exc()})
    raise
