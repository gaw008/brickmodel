"""Archive an explicit evidence whitelist; never include private source bodies."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

WORK = Path('/private/tmp/arlabosse-internal-coupling-v1')
DEST = Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/arlabosse-internal-coupling-v1')
ROOT_NAMES = (
    'ARCHITECTURE_REVIEW.md', 'THERMODYNAMIC_REFERENCE.json', 'COLUMN_RED.log',
    'COLUMN_TESTS01.log', 'COLUMN_TESTS01.xml', 'COLUMN_TESTS02.log', 'COLUMN_TESTS02.xml',
    'COLUMN_TESTS03.log', 'COLUMN_TESTS03.xml', 'PROBE_PLAN.md', 'DYNAMIC_PLAN.md',
    'native_case.py', 'probe_driver.py', 'dynamic_driver.py',
    'run_supervised_probe01.py', 'run_supervised_dynamic01.py', 'DERIVED_SUMMARY.json',
    'publish_evidence.py',
)
DIRECTORIES = ('implementation', 'code-review', 'install', 'source-review',
               'probe01', 'supervised-probe01', 'dynamic01', 'supervised-dynamic01',
               'saved-review', 'transport-next')
ALLOWED_SUFFIXES = {'.py', '.md', '.json', '.log', '.xml', '.csv'}
paths = [WORK/name for name in ROOT_NAMES]
for directory in DIRECTORIES:
    parent=WORK/directory
    if not parent.is_dir():
        raise ValueError('missing_evidence_directory: '+directory)
    # Only immediate regular audit/record files. No recursion into original
    # PDFs/XML/assets, test source fixtures, caches, or environment directories.
    paths.extend(p for p in parent.iterdir() if p.is_file() and not p.is_symlink()
                 and p.suffix in ALLOWED_SUFFIXES)
paths=sorted(set(paths))
if any(not p.is_file() or p.is_symlink() for p in paths):
    raise ValueError('nonregular_evidence')
archive=DEST/'evidence.tar.gz'
if archive.exists():
    raise FileExistsError('do_not_overwrite_existing_evidence_archive')
members=[]
with tarfile.open(archive, 'w:gz') as handle:
    for path in paths:
        data=path.read_bytes(); name=str(path.relative_to(WORK))
        entry=tarfile.TarInfo(name); entry.size=len(data); entry.mode=0o644
        handle.addfile(entry, io.BytesIO(data))
        members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive, 'r:gz') as handle:
    names=handle.getnames()
    if names!=[m['path'] for m in members]:
        raise ValueError('archive_member_mismatch')
    for member in members:
        data=handle.extractfile(member['path']).read()
        if len(data)!=member['bytes'] or hashlib.sha256(data).hexdigest()!=member['sha256']:
            raise ValueError('archive_content_mismatch: '+member['path'])
manifest={'schema':'evidence_archive_v1','base_commit':'2541b32',
    'archive':archive.name,'archive_bytes':archive.stat().st_size,
    'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'member_count':len(members),'uncompressed_bytes':sum(m['bytes'] for m in members),
    'members':members,'all_members_reopened_and_verified':True,
    'excluded':'Private original source bodies, nested fixtures/assets, caches and environments.',
    'software_status':'limited_source_sorption_column_coupling_verified',
    'scientific_status':'conditional_numerical_check; material_and_external_prediction_unvalidated',
    'deployment_status':'offline_research_only', 'goal_complete':False}
(DEST/'EVIDENCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'},indent=2))
