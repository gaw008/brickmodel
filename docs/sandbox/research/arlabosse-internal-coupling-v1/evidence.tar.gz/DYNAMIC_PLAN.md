# Unique internal sorption dynamic01

Registered after successful probe01, before dynamic execution. Source/installed
code remains the reviewed 173-file freeze; no physics or policies changed.
Probe build 0.441828 s, one operator 3.428046 s. Six midpoint-host evaluations
for two accepted steps nominally cost 20.57 s. Register a 60 s integrator limit,
80 s whole driver limit, 100 s outer supervisor plus 5 s cleanup; no retries.

Use native_case.py unchanged: two 0.01 kg dry cells, initial 330/333 K,
condensed water 0.2/0.225 mol, explicit manufactured geometry/transport, source
wet thermodynamics and the identical actual Python water provider. Integrate
0.05 represented seconds with two midpoint steps (0.025 s nominal each).
This small wet-domain segment tests active coupling; it is not a drying cycle
or a time/space convergence study. Limits are numerical policies, not measured
material uncertainties.

Save construction prefix, INITIAL, returned RUN before assertions, and either
ACCEPTANCE or FAILURE. A failed or incomplete run stays failed. Require exactly
two accepted steps, six attempted/completed evaluations, three stored states,
two accepted observations; original energy inverse tolerance 1e-5 J,
temperature bound 1e-6 K, accumulated roundoff budgets 1e-8 J / 1e-12 mol.

For every accepted step and cell independently reconstruct exact Fraction
inventory/energy differences from shared signed face integrals, phase transfer,
and recorded binary64 projection residuals. Also reconstruct closed global
water, each inert gas, and U, including every accepted prefix, with residual
exactly zero after the explicitly recorded roundoff. Predictor contributions
are excluded from accepted balances. Reconstruct the sum of face heat and
species enthalpy plus recorded decomposition residual. Check target U against
actual returned decoded U, full original inverse budgets, positive inventories,
T/W/P domains, actual liquid pressure query, scaled activity equilibrium,
positive phase entropy and false material/training qualifications.

Require nonzero phase transfer and internal heat/enthalpy exchange, changed
water and pressure, and decoded temperature change larger than the final
inverse bound plus 1e-6 K (conservative allowance for initial direct numerical
decode). This demonstrates resolved nonstationarity, not physical accuracy.
Initial and final total-U errors or roundoff do not certify truncation error.
The separate independent reviewer will re-read saved numeric fields without
running new EOS or repeating this path.
