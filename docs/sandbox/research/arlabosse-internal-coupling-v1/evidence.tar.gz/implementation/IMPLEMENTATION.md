# Rigid sorption storage implementation

Owned files only:

- `src/sludge_sandbox/arlabosse_rigid_sorption.py` — SHA256 `abcfe0d3fab764deddf21d0716a3b11dbdd15090b91cd86ac77363af169613d6`
- `tests/sandbox/test_arlabosse_rigid_sorption.py` — SHA256 `67fb1c9578f4a97ded162d2036ab3f23593ee983dd9f45a4336577330ea74feb`

`ArlabosseSorptionStorage(base, wet, pressure_domain_pa)` accepts exactly the two existing production storage/model classes. Its `ArlabosseSorptionPoint` is a `SourceWetPoint` subclass. The inverse result remains `SourceWetInverse` with the new point subclass.

The extension is `F_ex=md*(hex(W)-T*sex(W))`, with zero excess volume and `U_ex=md*hex(W)`. W uses liquid water only. Integrals use Fraction arithmetic on the existing represented binary64 m/q nodes and exact inventory-derived W. The base fluid and solid sensible terms remain intact. Fixed-inventory capacity and mechanical pressure are inherited. The final total-U projection error is added to the unchanged base numerical error. Activity and chemical potential are nominal readouts from `wet._excess`; they have no certified new error envelope.

The bisection operates on full U, avoiding target-minus-Hex projection entirely. It retains the base InversePolicy endpoint, residual, capacity, sign-resolution, and iteration gates. The entire initial temperature bracket must fit the declared pressure domain, including the existing pressure error interval. This conservative requirement can reject a locally valid point if its bracket endpoint is outside the exploration domain; narrow the explicitly supplied base temperature domain if appropriate, without changing tolerances.

The new identity binds base identity, wet definition, actual m/q nodes, latent reference, water constants, backend identity and pressure/temperature domains. Public operations check pinned sources. Only identical liquid-water backend type/implementation, reference and source-asset identity are supported. No HEOS/Python bridge is inferred. A prior base state is rejected by wrapper identity validation; conversion is private after validation.

The wet definition and missing source readings remain fresh provenance data. The fixed dry-energy reference offset is recorded independently; the wet full H is never substituted for base U. Pressure/temperature extension errors, interpolation model error and experimental uncertainty remain `None`; material qualification and training eligibility remain false.

## Verification evidence

- `RED01.log/xml`: actual missing-module RED before implementation, on the new energy/entropy/derivative contract test.
- `GREEN01.log/xml`: 31 manufactured tests passed in 0.17 s.
- `GREEN02.log/xml`: 33 passed, 1 failed. The new large-reference-energy negative control accidentally chose exactly representable 6400 J excess, so its expectation of large projection error was incorrect. No production change was made for this failure.
- `GREEN03.log/xml`: after choosing nonintegral moisture for that negative control, all 34 tests passed in 0.18 s.
- Both files parsed with Python AST. Ruff, mypy, black and pylint are unavailable in the selected installed test runtime; no dependencies were installed.

The tests use actual public classes with explicit manufactured internal seams. They do not execute a water EOS, a native trajectory, or physical validation. The root agent owns independent review and integration/native admission. Other agents' files were neither edited nor reverted. No commit or installation was performed here.
