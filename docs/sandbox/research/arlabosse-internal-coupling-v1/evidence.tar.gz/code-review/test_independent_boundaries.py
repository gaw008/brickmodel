"""Bounded independent seam probes; no water construction or EOS calls."""
from dataclasses import replace
from types import SimpleNamespace
import pytest

from test_arlabosse_rigid_sorption import fixture, state
from sludge_sandbox.source_wet_column import SourceWetColumn, ArlabosseSorptionColumn
from sludge_sandbox.exact_source_column import ExactSourceColumn


def sorption_column_shell(fixture, monkeypatch):
    # The target is adapter admission only. The reviewed storage fixture keeps
    # real public class identities and replaces thermophysical leaves.
    column = object.__new__(ArlabosseSorptionColumn)
    object.__setattr__(column, 'storages', (fixture.storage,))
    object.__setattr__(column, '_identity', 'manufactured_sorption_column')
    monkeypatch.setattr(SourceWetColumn, 'binding', lambda self: 'manufactured_sorption_column')
    monkeypatch.setattr(SourceWetColumn, 'provenance', lambda self: {
        'schema': 'manufactured_sorption_column', 'sorption': True})
    return column


def test_legacy_exact_adapter_refuses_unregistered_sorption(fixture, monkeypatch):
    column = sorption_column_shell(fixture, monkeypatch)
    with pytest.raises(ValueError, match='actual_fixed_source_column_required'):
        ExactSourceColumn(column)


def test_legacy_exact_provenance_does_not_claim_base_only_energy(fixture, monkeypatch):
    column = sorption_column_shell(fixture, monkeypatch)
    try:
        adapter = ExactSourceColumn(column)
    except ValueError:
        return
    assert 'sorption' in adapter.provenance()['total_energy_meaning']


def phase_shell(fixture, monkeypatch, point):
    import math
    from sludge_sandbox import arlabosse_sorption_phase as phase_module
    from sludge_sandbox.mass_wet_transport import WetPhaseEvaluation
    from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
    chemical = object.__new__(WaterChemicalPotential)
    water = fixture.base.water
    object.__setattr__(chemical, 'water', water)
    object.__setattr__(chemical, 'vapor', SimpleNamespace(_water=water,
        gas_constant_j_mol_k=8.31446261815324, source_ids=('manufactured:water',)))
    pure = SimpleNamespace(equilibrium_partial_pressure_pa=50000.,
        phase_enthalpy_difference_j_mol=45000.,
        liquid=SimpleNamespace(chemical_potential_j_mol=0.),
        source_ids=('manufactured:water',))
    monkeypatch.setattr(phase_module, 'evaluate_wet_phase', lambda *a: WetPhaseEvaluation(
        0., 1000., pure, None, None))
    # This is an analytic ideal-vapor chemical leaf, not a water provider call.
    monkeypatch.setattr(WaterChemicalPotential, 'ideal_vapor', lambda self, t, p:
        SimpleNamespace(chemical_potential_j_mol=self.gas_constant_j_mol_k*t*math.log(p/50000.)))
    return lambda: phase_module.evaluate_sorption_phase(fixture.storage, chemical, point,
        .001, 1e-9, 'existing_liquid')


def test_public_phase_rechecks_conditional_pressure_domain(fixture, monkeypatch):
    point = fixture.storage.evaluate(state(fixture), 340.)
    fluid = SimpleNamespace(mechanical=SimpleNamespace(temperature_k=340.,
        pressure_pa=120000., gas_volume_m3=.0009))
    point = replace(point, fluid=fluid)
    call = phase_shell(fixture, monkeypatch, point)
    with pytest.raises(ValueError, match='pressure|domain'):
        call()


def test_public_phase_rechecks_conditional_temperature_domain(fixture, monkeypatch):
    point = fixture.storage.evaluate(state(fixture), 340.)
    fluid = SimpleNamespace(mechanical=SimpleNamespace(temperature_k=370.,
        pressure_pa=100000., gas_volume_m3=.0009))
    point = replace(point, fluid=fluid)
    # Preserve chemical consistency after changing temperature, isolating the
    # public declared domain gate instead of relying on the residual check.
    import math
    point = replace(point, activity=math.exp(point.excess_chemical_potential_j_mol/
                                             (8.31446261815324*370.)))
    call = phase_shell(fixture, monkeypatch, point)
    with pytest.raises(ValueError, match='temperature|domain'):
        call()


def test_discarded_pure_water_rate_cannot_overflow_finite_sorption_rate(fixture, monkeypatch):
    import math
    from sludge_sandbox import arlabosse_sorption_phase as phase_module
    from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
    from sludge_sandbox.mass_wet_transport import represented
    from fractions import Fraction as F
    point = fixture.storage.evaluate(state(fixture), 340.)
    pure_pressure = 50000.
    actual_pressure = represented(F(pure_pressure)*F(point.activity))
    water_vapor_mol = 1e-3
    volume = water_vapor_mol*8.31446261815324*340./actual_pressure
    fluid = SimpleNamespace(mechanical=SimpleNamespace(temperature_k=340.,
        pressure_pa=100000., liquid_pressure_pa=100000., gas_volume_m3=volume,
        liquid_inventory_mol=2., gas_inventory_mol={'O2': .01, 'N2': .02, 'H2O': water_vapor_mol}))
    point = replace(point, fluid=fluid)
    water = fixture.base.water
    chemical = object.__new__(WaterChemicalPotential)
    object.__setattr__(chemical, 'water', water)
    object.__setattr__(chemical, 'vapor', SimpleNamespace(_water=water,
        gas_constant_j_mol_k=8.31446261815324, source_ids=('manufactured:water',)))
    pure = SimpleNamespace(equilibrium_partial_pressure_pa=pure_pressure,
        phase_enthalpy_difference_j_mol=45000.,
        liquid=SimpleNamespace(chemical_potential_j_mol=0.), source_ids=('manufactured:water',))
    monkeypatch.setattr(WaterChemicalPotential, 'equilibrium_at_liquid_tp', lambda *a: pure)
    monkeypatch.setattr(WaterChemicalPotential, 'ideal_vapor', lambda self, t, p:
        SimpleNamespace(chemical_potential_j_mol=self.gas_constant_j_mol_k*t*math.log(p/pure_pressure)))
    # Only chemical leaves are manufactured; the real pure-phase arithmetic is
    # executed. Its discarded drive is large; the sorption drive is at most a
    # representable projection residual and yields a finite final rate.
    expected_pv = represented(F(water_vapor_mol)*F(chemical.gas_constant_j_mol_k)*F(340.)/F(volume))
    expected_rate = represented(F(1e305)*(F(actual_pressure)-F(expected_pv)))
    assert math.isfinite(expected_rate)
    result = phase_module.evaluate_sorption_phase(fixture.storage, chemical, point,
        water_vapor_mol, 1e305, 'existing_liquid')
    assert result.phase_water_mol_s == expected_rate


@pytest.mark.parametrize('field,value', [
    ('moisture_kg_water_per_kg_dry', .7),
    ('activity', .1),
    ('excess_chemical_potential_j_mol', 0.),
    ('excess_partial_water_enthalpy_j_mol', 0.),
])
def test_public_phase_rejects_replaced_source_fields(fixture, monkeypatch, field, value):
    point = fixture.storage.evaluate(state(fixture), 340.)
    fluid = SimpleNamespace(mechanical=SimpleNamespace(temperature_k=340.,
        pressure_pa=100000., liquid_pressure_pa=100000., liquid_inventory_mol=2.,
        gas_volume_m3=.0009))
    point = replace(point, fluid=fluid, **{field: value})
    call = phase_shell(fixture, monkeypatch, point)
    with pytest.raises(ValueError, match='moisture|excess'):
        call()


def test_legacy_source_column_rejects_wrapper_before_other_fields(fixture):
    column = object.__new__(SourceWetColumn)
    object.__setattr__(column, 'storages', (fixture.storage,))
    with pytest.raises(ValueError, match='explicit_sorption_column_type_required'):
        column.binding()


def test_legacy_programmed_column_rejects_new_subclass_before_other_fields(fixture, monkeypatch):
    from sludge_sandbox.programmed_source_wet_column import ProgrammedSourceWetColumn
    column = sorption_column_shell(fixture, monkeypatch)
    program = object.__new__(ProgrammedSourceWetColumn)
    object.__setattr__(program, 'base', column)
    with pytest.raises(ValueError, match='actual_source_column_required'):
        program.binding()
