"""Independent passive numeric audit; standard library only, no application imports."""
from pathlib import Path
from fractions import Fraction as F
from bisect import bisect_right
import csv
import hashlib
import json
import math
import time
import traceback

W = Path('/private/tmp/arlabosse-internal-coupling-v1')
R = Path('/Users/wanggaoying/Desktop/brickmodel-github')
OUT = W/'saved-review'
START = time.monotonic()
CHECKS = []
METRICS = {}
INPUT_HASHES = {}
HASH_CACHE = {}

def sha(path):
    path = Path(path)
    if str(path) not in HASH_CACHE:
        HASH_CACHE[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return HASH_CACHE[str(path)]

def load(path):
    path = Path(path)
    INPUT_HASHES[str(path)] = sha(path)
    return json.loads(path.read_text())

def f(value):
    if type(value) is dict and set(value) == {'numerator', 'denominator'}:
        return F(int(value['numerator']), int(value['denominator']))
    if type(value) in (int, float):
        return F(value)
    raise TypeError('unexpected numeric shape '+repr(value)[:100])

def check(label, condition):
    CHECKS.append({'id':label, 'passed':bool(condition)})

def maximum(label, value):
    METRICS[label] = max(METRICS.get(label, 0.), abs(float(value)))

def sumf(values):
    return sum((f(v) for v in values), F())

def mech(point):
    return point['fluid']['mechanical']

def interp_exact(curve, x):
    for (a, ya), (b, yb) in zip(curve, curve[1:]):
        if a <= x <= b:
            return ya+(yb-ya)*(x-a)/(b-a)
    raise ValueError('independent interpolation outside source range')

def integral(curve, a, b):
    if a == b: return F()
    if b < a: return -integral(curve,b,a)
    edges = [a]+[x for x,y in curve if a<x<b]+[b]
    return sum(((interp_exact(curve,x)+interp_exact(curve,y))*(y-x)/2
                for x,y in zip(edges,edges[1:])),F())

def nominal_interp(curve,x):
    xs=[float(a) for a,b in curve]; ys=[float(b) for a,b in curve]
    if x in xs: return ys[xs.index(x)]
    i=min(bisect_right(xs,x)-1,len(xs)-2)
    return math.fsum((ys[i],(x-xs[i])*((ys[i+1]-ys[i])/(xs[i+1]-xs[i]))))

try:
    probe_a=load(W/'probe01/ACCEPTANCE.json')
    probe_i=load(W/'probe01/INITIAL.json')
    probe_e=load(W/'probe01/EVALUATION.json')
    dynamic_a=load(W/'dynamic01/ACCEPTANCE.json')
    initial=load(W/'dynamic01/INITIAL.json')
    run=load(W/'dynamic01/RUN.json')
    for name, report, count in (('probe',probe_a,34),('dynamic',dynamic_a,117)):
        check(name+'_acceptance',report['passed'] is True)
        check(name+'_original_check_count',len(report['checks'])==count)
        check(name+'_original_checks',all(c['passed'] is True for c in report['checks']))
        check(name+'_no_failure_file',not (W/(name+'01')/'FAILURE.json').exists())
        prefix=load(W/(name+'01')/'CONSTRUCTION_PREFIX.json')
        source=probe_i if name=='probe' else initial
        check(name+'_construction_prefix',prefix['states']==source['states'] and prefix['points']==source['points'])
    check('probe_has_no_dynamic_claim',probe_a['dynamic_path_executed'] is False)
    check('probe_driver_budget',0<=probe_a['build_seconds']<90 and 0<=probe_a['operator_seconds']<90 and probe_a['total_seconds']<90)
    check('probe_dynamic_initial_states_same',probe_i['states']==initial['states'])
    check('dynamic_status_and_counts',run['status']=='completed' and run['reason'] is None and
          len(run['states'])==3 and len(run['observations'])==2 and len(run['ledgers'])==2 and
          run['evaluations_attempted']==run['evaluations_completed']==6)
    check('dynamic_clock',tuple(map(f,run['times_s']))==(F(),F(.05)/2,F(.05)))
    check('dynamic_initial_preserved',run['states'][0]==initial['states'])
    check('dynamic_identity',run['model_identity']==initial['provenance']['model_identity'])
    check('dynamic_resources',run['elapsed_seconds']==dynamic_a['integrator_seconds'] and
          0<=run['elapsed_seconds']<60 and 0<=dynamic_a['driver_seconds']<80)
    check('dynamic_original_budgets',run['energy_roundoff_budget_j']==1e-8 and run['inventory_roundoff_budget_mol']==1e-12)
    check('dynamic_used_budgets',0<=f(run['energy_roundoff_used_j'])<=F(1e-8) and
          0<=f(run['inventory_roundoff_used_mol'])<=F(1e-12))
    check('dynamic_no_qualification',run['material_qualified'] is False and
          dynamic_a['material_qualified'] is False and dynamic_a['spatial_temporal_convergence_demonstrated'] is False)
    METRICS.update(probe_build_seconds=probe_a['build_seconds'],probe_operator_seconds=probe_a['operator_seconds'],
                   probe_driver_seconds=probe_a['total_seconds'],dynamic_integrator_seconds=run['elapsed_seconds'],
                   dynamic_driver_seconds=dynamic_a['driver_seconds'])

    for name,limit in (('probe',110.),('dynamic',100.)):
        metadata=load(W/('supervised-'+name+'01')/'metadata.json')
        status=load(W/('supervised-'+name+'01')/'status.json')
        check(name+'_supervised_terminal',status['status']=='complete' and status['returncode']==0 and
              status['cleanup']['leader_reaped'] is True and status['cleanup']['signal_errors']==[])
        check(name+'_supervised_budget',metadata['timeout_s']==limit and metadata['cleanup_grace_s']==5. and
              status['elapsed_s']<limit+5.)
        check(name+'_fixed_command',metadata['command']==['/usr/bin/env','-u','PYTHONPATH',
              '/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python','-I',str(W/(name+'_driver.py'))])
        check(name+'_input_keys',set(metadata['inputs_before'])==set(status['inputs_after']) and len(metadata['inputs_before'])==389)
        for path,before in metadata['inputs_before'].items():
            check(name+'_input:'+path,before['sha256']==status['inputs_after'][path]==sha(path))
        check(name+'_input_flag',status['inputs_unchanged'] is True)
        METRICS[name+'_supervisor_seconds']=status['elapsed_s']
    freeze=load(W/'install/SOURCE_FREEZE.json')
    installed=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
    check('freeze_count',len(freeze['files'])==173 and freeze['base_commit']=='2541b32')
    for name,digest in freeze['files'].items():
        check('source_installed:'+name,sha(R/'src/sludge_sandbox'/name)==digest==sha(installed/name))
    check('install_test_identity_unchanged',load(W/'install/INSTALL_IDENTITY_BEFORE_TESTS.json')==load(W/'install/INSTALL_IDENTITY_AFTER_TESTS.json'))

    provenance=initial['provenance']['cells'][0]
    definition=provenance['wet_definition']; water=definition['water']
    MW=water['molar_mass_kg_mol']; RR=water['gas_constant_j_mol_k']; RS=water['gas_constant_j_kg_water_k']
    T0=368.15; W0=F(.8)
    records=definition['source_point_records']
    qcurve=[]; mcurve=[]
    for record in records:
        x=F(float(f(record['moisture_kg_water_per_kg_dry_matter'])))
        aw=float(f(record['activity']['value']))
        mcurve.append((x,F(RS*T0*math.log(aw))))
        q=record['total_desorption_heat']['value']
        if q is not None: qcurve.append((x,F(float(f(q)))))
    check('original_node_counts',len(mcurve)==8 and len(qcurve)==6)
    check('original_missing_q_preserved',all(p['total_desorption_heat']['value'] is None
          for p in records if float(f(p['moisture_kg_water_per_kg_dry_matter'])) in (.5,.6)))
    check('water_M_R_basis',MW==water['reference']['molar_mass_kg_mol'] and RS==RR/MW and water['backend']=='python')
    old=Path('/private/tmp/arlabosse-wet-thermo-v1')
    anchor_report=load(old/'native01/ACCEPTANCE.json')
    anchor=anchor_report['oracle_water'][0]
    check('old_anchor_state',anchor['temperature_k']==T0 and anchor['liquid_pressure_pa']==100000. and
          anchor['molar_mass_kg_mol']==MW and anchor['source_ids']==water['source_ids'])
    L95=math.fsum((anchor['vapor_enthalpy_j_kg_water'],-anchor['liquid_enthalpy_j_kg_water']))
    METRICS['prior_saved_same_backend_L95_j_kg_water']=L95
    oldmeta=load(old/'supervised-native01/metadata.json')
    oldstatus=load(old/'supervised-native01/status.json')
    check('old_anchor_supervised_status',oldstatus['status']=='complete' and oldstatus['returncode']==0 and
          oldstatus['inputs_unchanged'] is True and oldstatus['cleanup']['leader_reaped'] is True)
    anchor_files=0
    for path,before in oldmeta['inputs_before'].items():
        if '/iapws/' in path or '/data/sandbox/water/' in path or Path(path).name in (
            'arlabosse_wet_thermo.py','water_properties.py','water_chemical_potential.py','ideal_water_vapor.py'):
            check('old_anchor_source:'+path,before['sha256']==oldstatus['inputs_after'][path]==sha(path))
            anchor_files+=1
    check('old_anchor_sources_present',anchor_files>=20)
    METRICS['old_anchor_relevant_source_files']=anchor_files
    for p in initial['provenance']['cells']:
        check('matching_wet_definition',p['wet_definition']==definition)
        check('conditional_provenance',p['material_qualified'] is False and p['training_eligible'] is False and
              all(p[k] is None for k in ('pressure_extension_model_error','temperature_extension_model_error',
                                       'interpolation_model_error','experimental_uncertainty')))

    def point_check(label,p,state,inverse=None,phase=None):
        m=mech(p); t=m['temperature_k']; pressure=m['pressure_pa']; md=F(state['solid_mass_kg'][0])
        moisture=f(state['liquid_water_mol'])*F(MW)/md
        check(label+'_inventory_binding',m['liquid_inventory_mol']==state['liquid_water_mol'] and
              tuple(m['gas_inventory_mol'][k] for k in ('O2','N2','H2O'))==tuple(state['gas_amounts_mol']) and
              p['model_identity']==state['energy_model_identity'])
        check(label+'_domains',325<=t<=338 and F(.15)<=moisture<=F(.8) and
              F(90000)<=F(pressure)-F(p['pressure_error_pa']) and F(pressure)+F(p['pressure_error_pa'])<=F(110000))
        check(label+'_W',p['moisture_kg_water_per_kg_dry']==float(moisture))
        hex_=F(L95)*(moisture-W0)-integral(qcurve,W0,moisture)
        sex=(hex_-integral(mcurve,W0,moisture))/F(T0)
        check(label+'_excess_U',f(p['excess_internal_energy_j'])==md*hex_)
        check(label+'_excess_S',f(p['excess_entropy_j_k'])==md*sex)
        check(label+'_excess_F',f(p['excess_helmholtz_energy_j'])==md*(hex_-F(t)*sex))
        source_dry_a=F('1434')-F('3.29')*F('273.15'); dryref=F('313.15')
        dry_u=md*(source_dry_a*(F(t)-dryref)+F('3.29')*(F(t)**2-dryref**2)/2)
        check(label+'_dry_U',f(p['solid_internal_energy_j'])==dry_u)
        combined=F(p['fluid']['internal_energy_j'])+dry_u+md*hex_
        err=abs(F(p['total_internal_energy_j'])-combined)
        check(label+'_full_U',err<=F(p['energy_error_j']))
        maximum('max_combined_U_projection_j',err)
        b_exact=F(L95)-interp_exact(qcurve,moisture)
        check(label+'_partial_excess_h',p['excess_partial_water_enthalpy_j_mol']==float(F(MW)*b_exact))
        x=float(moisture); ratio=t/T0
        b_float=L95-nominal_interp(qcurve,x)
        mu=math.fsum((ratio*nominal_interp(mcurve,x),(1-ratio)*b_float))
        mu_mol=float(F(mu)*F(MW)); aw=math.exp(mu/(RS*t))
        check(label+'_mu_ex',p['excess_chemical_potential_j_mol']==mu_mol)
        check(label+'_activity',p['activity']==aw)
        check(label+'_false_flags',p['material_qualified'] is False and p['training_eligible'] is False and
              p['excess_volume_m3']==0 and p['pressure_extension_model_error'] is None)
        if inverse is not None:
            residual=F(p['total_internal_energy_j'])-F(state['internal_energy_j'])
            check(label+'_inverse_target',inverse['target_energy_j']==state['internal_energy_j'] and f(inverse['energy_residual_j'])==residual)
            bound=abs(residual)+F(p['energy_error_j'])
            check(label+'_inverse_budget',bound<=F(1e-5) and 0<=inverse['temperature_error_bound_k']<=1e-6)
            check(label+'_inverse_bound_formula',F(inverse['temperature_error_bound_k'])>=bound/F(p['minimum_heat_capacity_j_k']))
            maximum('max_inverse_energy_plus_error_j',bound)
            maximum('max_inverse_temperature_bound_k',inverse['temperature_error_bound_k'])
            prefix='dynamic_' if label.startswith('step') else 'probe_'
            maximum(prefix+'max_inverse_energy_plus_error_j',bound)
            maximum(prefix+'max_inverse_temperature_bound_k',inverse['temperature_error_bound_k'])
        if phase is not None:
            eq=phase['equilibrium']; pure=eq['pure_equilibrium']; liquid=pure['liquid']
            peq=float(F(pure['equilibrium_partial_pressure_pa'])*F(aw))
            pv=float(F(state['gas_amounts_mol'][2])*F(RR)*F(t)/F(m['gas_volume_m3']))
            rate=float(F(1e-10)*(F(peq)-F(pv)))
            check(label+'_peq',eq['equilibrium_partial_pressure_pa']==peq and eq['activity']==aw)
            check(label+'_pv',phase['water_partial_pressure_pa']==pv)
            check(label+'_rate',phase['phase_water_mol_s']==rate)
            check(label+'_current_query',liquid['state']['pressure_pa']==m['liquid_pressure_pa']==pressure and liquid['state']['temperature_k']==t)
            check(label+'_water_reference',liquid['state']['reference']==water['reference'] and liquid['state']['implementation'] is None)
            latent=float(F(pure['vapor']['enthalpy_j_mol'])-F(liquid['enthalpy_j_mol']))
            check(label+'_pure_latent',pure['phase_enthalpy_difference_j_mol']==latent)
            q=float(F(latent)-F(p['excess_partial_water_enthalpy_j_mol']))
            check(label+'_desorption_h',eq['phase_enthalpy_difference_j_mol']==q and
                  eq['excess_partial_water_enthalpy_j_mol']==p['excess_partial_water_enthalpy_j_mol'] and q>0)
            if pv>0:
                logarithm=math.log1p((peq-pv)/pv) if abs(peq-pv)<.5*pv else math.log(peq)-math.log(pv)
                drive=float(F(RR)*F(t)*F(logarithm))
                entropy=float(F(rate)*F(drive)/F(t))
                check(label+'_chemical_drive',phase['chemical_driving_force_j_mol']==drive)
                check(label+'_entropy',phase['entropy_production_w_k']==entropy and entropy>0)
            check(label+'_equilibrium_residual',abs(eq['chemical_potential_residual_j_mol'])<=1e-7)
            liquid_mu=math.fsum((liquid['enthalpy_j_mol'],-t*liquid['entropy_j_mol_k']))
            pure_vapor_mu=math.fsum((pure['vapor']['enthalpy_j_mol'],-t*pure['vapor']['entropy_j_mol_k']))
            check(label+'_saved_potential_relations',liquid['chemical_potential_j_mol']==liquid_mu and
                  pure['vapor']['chemical_potential_j_mol']==pure_vapor_mu)
            corrected_vapor_mu=math.fsum((pure_vapor_mu,RR*t*(math.log(peq)-math.log(pure['equilibrium_partial_pressure_pa']))))
            independent_residual=math.fsum((liquid_mu,p['excess_chemical_potential_j_mol'],-corrected_vapor_mu))
            check(label+'_independent_phase_mu',abs(independent_residual)<=1e-7)
            maximum('max_independent_phase_mu_residual_j_mol',independent_residual)
            check(label+'_phase_flags',eq['material_qualified'] is False and eq['training_eligible'] is False and eq['pressure_extension_model_error'] is None)

    for i,(state,p) in enumerate(zip(initial['states'],initial['points'])):
        point_check('initial'+str(i),p,state)
        check('initial_energy'+str(i),state['internal_energy_j']==p['total_internal_energy_j'])
    for i,(state,cell) in enumerate(zip(probe_i['states'],probe_e['cells'])):
        point_check('probe'+str(i),cell['inverse']['point'],state,cell['inverse'],cell['phase'])
        check('probe_T'+str(i),abs(mech(cell['inverse']['point'])['temperature_k']-mech(probe_i['points'][i])['temperature_k'])<=cell['inverse']['temperature_error_bound_k'])
    check('probe_faces',len(probe_e['cells'])==2 and len(probe_e['faces'])==3 and probe_e['material_qualified'] is False)
    totals=lambda states:(sumf(s['internal_energy_j'] for s in states),
        sum((f(s['liquid_water_mol'])+f(s['gas_amounts_mol'][2]) for s in states),F()),
        *[sumf(s['gas_amounts_mol'][k] for s in states) for k in range(2)])
    original_total=totals(initial['states']); cumulative=[F() for _ in range(4)]
    for n,(old,new,ledger,observation) in enumerate(zip(run['states'],run['states'][1:],run['ledgers'],run['observations'])):
        label='step'+str(n); rnd=ledger['roundoff']; faces=ledger['faces']
        check(label+'_clock',f(ledger['duration_s'])==f(run['times_s'][n+1])-f(run['times_s'][n]))
        check(label+'_face_layout',len(faces)==3 and [x['face_id'] for x in faces]==[0,1,2])
        check(label+'_closed',all(f(face['energy_j'])==0 and all(f(v)==0 for v in face['gas_mol']) for face in (faces[0],faces[-1])))
        check(label+'_active_heat',f(faces[1]['conduction_j'])!=0)
        check(label+'_active_enthalpy',any(f(v)!=0 for v in faces[1]['diffusive_enthalpy_j']+faces[1]['advective_enthalpy_j']))
        check(label+'_active_gas_phase',any(f(v)!=0 for v in faces[1]['gas_mol']) and all(f(v)!=0 for v in ledger['phase_water_mol']))
        for face in faces:
            error=f(face['energy_j'])-f(face['conduction_j'])-sumf(face['diffusive_enthalpy_j'])-sumf(face['advective_enthalpy_j'])-f(face['energy_decomposition_roundoff_j'])
            check(label+'_face_energy'+str(face['face_id']),error==0)
        for i,(a,b,cell) in enumerate(zip(old,new,observation['cells'])):
            prefix=label+'_cell'+str(i); left,right=faces[i:i+2]
            ue=f(b['internal_energy_j'])-f(a['internal_energy_j'])-f(left['energy_j'])+f(right['energy_j'])-f(rnd['energy_j'][i])
            ne=f(b['liquid_water_mol'])-f(a['liquid_water_mol'])+f(ledger['phase_water_mol'][i])-f(rnd['liquid_mol'][i])
            check(prefix+'_U',ue==0);check(prefix+'_Nc',ne==0)
            maximum('max_exact_local_U_defect_j',ue);maximum('max_exact_local_Nc_defect_mol',ne)
            for k in range(3):
                ge=f(b['gas_amounts_mol'][k])-f(a['gas_amounts_mol'][k])-f(left['gas_mol'][k])+f(right['gas_mol'][k])-f(rnd['gas_mol'][i][k])
                if k==2: ge-=f(ledger['phase_water_mol'][i])
                check(prefix+'_gas'+str(k),ge==0)
                maximum('max_exact_local_gas_defect_mol',ge)
            check(prefix+'_positive',b['liquid_water_mol']>0 and all(x>=0 for x in b['gas_amounts_mol']))
            check(prefix+'_fixed_dry_mass',a['solid_mass_kg']==b['solid_mass_kg']==initial['states'][i]['solid_mass_kg'])
            point_check(prefix,cell['inverse']['point'],b,cell['inverse'],cell['phase'])
        costs=[sumf(rnd['energy_j']),sumf(rnd['liquid_mol'])+sumf(row[2] for row in rnd['gas_mol']),
               *[sumf(row[k] for row in rnd['gas_mol']) for k in range(2)]]
        before,after=totals(old),totals(new)
        for k,kind in enumerate(('U','water','O2','N2')):
            cumulative[k]+=costs[k]
            defect=after[k]-before[k]-costs[k]
            prefix_defect=after[k]-original_total[k]-cumulative[k]
            check(label+'_global_'+kind,defect==0);check(label+'_prefix_'+kind,prefix_defect==0)
            maximum('max_exact_global_'+kind+'_defect',defect);maximum('max_exact_prefix_'+kind+'_defect',prefix_defect)
    last=run['observations'][-1]['cells']; changes_T=[];changes_P=[];changes_Nc=[]
    for i,(p,cell,st) in enumerate(zip(initial['points'],last,run['states'][-1])):
        final=cell['inverse']['point']; dt=mech(final)['temperature_k']-mech(p)['temperature_k']; dp=mech(final)['pressure_pa']-mech(p)['pressure_pa']
        dn=st['liquid_water_mol']-initial['states'][i]['liquid_water_mol']
        check('final_resolved_T'+str(i),abs(dt)>cell['inverse']['temperature_error_bound_k']+1e-6)
        check('final_changed_P_Nc'+str(i),dp!=0 and dn!=0)
        check('final_acceptance_values'+str(i),dynamic_a['final_temperature_k'][i]==mech(final)['temperature_k'] and dynamic_a['final_pressure_pa'][i]==mech(final)['pressure_pa'])
        changes_T.append(dt);changes_P.append(dp);changes_Nc.append(dn)
    METRICS.update(temperature_changes_k=changes_T,pressure_changes_pa=changes_P,condensed_water_changes_mol=changes_Nc,
                   energy_roundoff_used_j=float(f(run['energy_roundoff_used_j'])),
                   inventory_roundoff_used_mol=float(f(run['inventory_roundoff_used_mol'])))
    derived=load(W/'DERIVED_SUMMARY.json')
    expected={'probe_checks':34,'dynamic_checks':117,'max_inverse_energy_with_error_j':METRICS['dynamic_max_inverse_energy_plus_error_j'],
        'max_inverse_temperature_bound_k':METRICS['dynamic_max_inverse_temperature_bound_k'],
        'energy_roundoff_used_j':METRICS['energy_roundoff_used_j'],'inventory_roundoff_used_mol':METRICS['inventory_roundoff_used_mol'],
        'condensed_water_changes_mol':changes_Nc,'temperature_changes_k':changes_T,'pressure_changes_pa':changes_P}
    for key,value in expected.items(): check('derived_summary_'+key,derived[key]==value)
    csv_path=R/'docs/sandbox/research/arlabosse-internal-coupling-v1/TRACE.csv'
    INPUT_HASHES[str(csv_path)]=sha(csv_path)
    rows=list(csv.DictReader(csv_path.open()))
    check('CSV_six_rows',len(rows)==6)
    for j,row in enumerate(rows):
        step,cell=divmod(j,2); st=run['states'][step][cell]
        p=initial['points'][cell] if step==0 else run['observations'][step-1]['cells'][cell]['inverse']['point']
        expected_row={'time_s':float(f(run['times_s'][step])),'cell':cell,
         'temperature_k':mech(p)['temperature_k'],'pressure_pa':mech(p)['pressure_pa'],
         'moisture_kg_water_per_kg_dry':p['moisture_kg_water_per_kg_dry'],
         'condensed_water_mol':st['liquid_water_mol'],'vapor_water_mol':st['gas_amounts_mol'][2],
         'total_internal_energy_j':st['internal_energy_j'],'activity':p['activity']}
        for key,value in expected_row.items(): check('CSV_'+str(j)+'_'+key,float(row[key])==value)
    for path,digest in INPUT_HASHES.items():
        check('audit_did_not_change:'+path,hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest)
    status='PASS' if all(c['passed'] for c in CHECKS) else 'FAIL'
    failure=None
except BaseException as exc:
    status='FAIL';failure={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
report={'status':status,'check_count':len(CHECKS),'passed_count':sum(c['passed'] for c in CHECKS),
        'failed_checks':[c for c in CHECKS if not c['passed']], 'failure':failure,
        'elapsed_seconds':time.monotonic()-START,'metrics':METRICS,'input_sha256':INPUT_HASHES,
        'check_records':CHECKS,'no_EOS_or_application_import':True,
        'anchor_scope':'Existing prior-stage saved Python-water 95C reference; source/runtime byte correspondence checked; no new independent EOS validation.',
        'scientific_scope':'Two-step conditional source-sorption coupling only; manufactured geometry/transport, unknown pressure/temperature/model transfer errors, no liquid Darcy, no material/training qualification or space/time convergence.'}
(OUT/'SAVED_REVIEW02.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('check_records','input_sha256')},indent=2))
raise SystemExit(0 if status=='PASS' else 1)
