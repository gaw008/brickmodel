"""One predeclared actual constructor/operator probe, preserving failures."""
import json
from fractions import Fraction as F
from pathlib import Path
import time
import traceback
import importlib.util
spec = importlib.util.spec_from_file_location('sorption_native_case',
    '/private/tmp/arlabosse-internal-coupling-v1/native_case.py')
case = importlib.util.module_from_spec(spec)
spec.loader.exec_module(case)
make_case, serialize = case.make_case, case.serialize

OUT = Path('/private/tmp/arlabosse-internal-coupling-v1/probe01')
OUT.mkdir(exist_ok=False)
start = time.monotonic()

def save(name, value):
    (OUT/name).write_text(json.dumps(serialize(value), indent=2, allow_nan=False)+'\n')

try:
    column, initial, points = make_case(lambda prefix: save('CONSTRUCTION_PREFIX.json', prefix))
    built = time.monotonic()
    save('INITIAL.json', {'states': initial, 'points': points, 'build_seconds': built-start})
    assert built-start < 90., 'probe_build_wall_target_exceeded'
    operator_start = time.monotonic()
    result = column.evaluate(initial)
    returned = time.monotonic()
    save('EVALUATION.json', result)
    checks = []
    def check(label, condition):
        checks.append({'id': label, 'passed': bool(condition)})
    check('two_cells_three_faces', len(result.cells)==2 and len(result.faces)==3)
    check('closed_end_faces', all(f.energy_w==0 and all(x==0 for x in f.gas_mol_s) for f in (result.faces[0],result.faces[-1])))
    check('nonzero_internal_heat', result.faces[1].conduction_w != 0)
    check('nonzero_local_phase', all(c.phase.phase_water_mol_s != 0 for c in result.cells))
    check('no_material_admission', result.material_qualified is False)
    for i, (cell, state, original, policy) in enumerate(zip(result.cells,initial,points,column.inverse_policies)):
        inv=cell.inverse; p=inv.point
        check(f'T{i}', abs(p.temperature_k-original.temperature_k)<=inv.temperature_error_bound_k)
        original_residual = F(p.total_internal_energy_j)-F(state.internal_energy_j)
        check(f'target{i}', inv.target_energy_j==state.internal_energy_j)
        check(f'residual{i}', inv.energy_residual_j==original_residual)
        check(f'U{i}', abs(original_residual)+F(p.energy_error_j)<=F(policy.energy_tolerance_j))
        eq=cell.phase.equilibrium; pure=eq.pure_equilibrium
        check(f'peq_activity{i}', eq.equilibrium_partial_pressure_pa==float(F(p.activity)*F(pure.equilibrium_partial_pressure_pa)))
        check(f'actual_liquid_query_pressure{i}', pure.liquid.state.pressure_pa==p.fluid.mechanical.liquid_pressure_pa==p.pressure_pa)
        check(f'water_reference{i}', pure.liquid.state.reference==column.chemical.reference==column.storages[i].water.reference)
        check(f'water_mass{i}', pure.liquid.state.molar_mass_kg_mol==column.chemical.reference.molar_mass_kg_mol==column.storages[i].wet._mass)
        check(f'water_backend{i}', pure.liquid.state.implementation==column.chemical.water.implementation==column.storages[i].water.implementation)
        check(f'T_policy{i}', inv.temperature_error_bound_k<=policy.temperature_tolerance_k)
        check(f'P_domain{i}', 90000<=p.pressure_pa-p.pressure_error_pa and p.pressure_pa+p.pressure_error_pa<=110000)
        check(f'phase_mu{i}', abs(cell.phase.equilibrium.chemical_potential_residual_j_mol)<=1e-7)
        check(f'water_identity{i}', p.fluid.mechanical.liquid_inventory_mol==state.liquid_water_mol)
        check(f'false_flags{i}', p.material_qualified is False and p.training_eligible is False)
    finished = time.monotonic()
    check('whole_driver_wall', finished-start<90.)
    report={'passed':all(c['passed'] for c in checks),'checks':checks,'build_seconds':built-start,
        'operator_seconds':returned-operator_start,'total_seconds':finished-start,
        'material_qualified':False,'dynamic_path_executed':False}
    save('ACCEPTANCE.json',report)
    print(json.dumps(report))
    assert report['passed'], 'probe_acceptance_failed'
except BaseException as exc:
    save('FAILURE.json',{'type':type(exc).__name__,'message':str(exc),'elapsed_seconds':time.monotonic()-start,
        'traceback':traceback.format_exc()})
    raise
