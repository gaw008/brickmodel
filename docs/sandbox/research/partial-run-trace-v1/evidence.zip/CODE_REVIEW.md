# Independent partial-run trace review

APPROVE scoped candidate. Read candidate.patch, surrounding trace_run implementation and test_trace.py. No repository edits, EOS, native process interaction or test reruns.

Reviewed run_service.py SHA256 9eb31b2392c5cf761b4224632071fee0f36875e5e17c6a968785f5a8fff794e1 and test_trace.py SHA256 d94290f052933b68ecf4b9a71fcf4571eed0c5c21c02536833d8ba0b7cecbf4d.

Unknown quantities are still refused before read_run. Prescribed-model quantity restrictions and unsupported-model rejection also execute before the new missing-final branch. When no final snapshot dictionary exists, the trace reports value=None, result_pointer=None and explicit final_snapshot_unavailable metadata with the original run reason. It neither reads initial_snapshot nor substitutes the accepted-prefix state as a final result. For complete runs with a final snapshot dictionary, the previous quantity selection and pointers remain unchanged; absent individual keys still raise quantity_unavailable.

Missing-value handling does not return early. It still requires the sealed run to pass read_run, resolves required equation artifacts, includes original case parameters and frozen artifact hashes, and calls query_graph with manifest artifacts when provenance exists. The original case-hash binding check remains after graph lookup. Thus lack of a final value does not bypass graph/source checks or turn an unknown quantity into an apparently valid trace.

Tests use synthetic sealed artifacts but actual read_run/query_graph. They compare complete traces exactly against the original implementation for all supported quantities, cover cancelled and failed runs with deliberately different initial values and an accepted prefix, require explicit unavailable values and retained graph/equation/parameter output, and verify every artifact byte is unchanged. Unknown-quantity refusal is separately checked. Read XML directly: retained RED has 14 failures among 22 tests; GREEN has 22 tests, zero failures/errors/skips, 0.215 seconds.

No blocking issue found. These tests establish trace behavior/source-graph plumbing, not validity of the synthetic material or numerical model. Candidate application and verification remain root-owned while native replay is active.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE scoped partial-run trace candidate.

## Final repository application review

APPROVE applied source and permanent tests. Current run_service.py SHA256 9eb31b2392c5cf761b4224632071fee0f36875e5e17c6a968785f5a8fff794e1 exactly matches the reviewed candidate. Current test_partial_run_trace.py SHA256 524f6e069f69457d36e541d82d9af8176779ec077aac7d1a5e7f482faa60c4ba imports the normal production module and replaces the temporary old-module comparison with explicit expected values and pointers for all seven supported quantities. It additionally requires no availability annotation for complete results, completed status and retained source graph/equations. Missing-final and unknown-quantity tests remain intact with byte-preservation checks.

Current git diff contains this trace patch and the separately approved resume preflight changes; no unreviewed trace behavior was introduced during application. Read repo-red.xml: 22 tests, 14 failures, 0 errors; repo-green.xml: 32 tests, zero failures/errors/skips, 0.326 seconds, including the resume preflight suite. No EOS or test rerun performed by reviewer. Native replay completion was reported by root and is not independently re-audited in this narrow application review.
