import json,time
from test_solid_fluid_heat import ingredients
from test_programmed_solid_fluid_heat import wrapped,program
from sludge_sandbox.deforming_solid_storage import _digest,_canonical
from dataclasses import fields,is_dataclass
from collections.abc import Mapping
import numpy as np,hashlib
def snapshot(x):
 if isinstance(x,np.ndarray):return ['ndarray',str(x.dtype),list(x.shape),snapshot(x.tolist())]
 if is_dataclass(x):return [type(x).__module__,type(x).__qualname__,[[f.name,snapshot(getattr(x,f.name))] for f in fields(x)]]
 if isinstance(x,Mapping):return {k:snapshot(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [snapshot(v) for v in x]
 return _canonical(x)
def digest(x):return hashlib.sha256(json.dumps(snapshot(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
start=time.monotonic();rows={}
for name,options in [('film',{}),('radiation',dict(emissivity=.8,program=program(radiation_temperature_k=(400.,)*4)))]:
 op=wrapped(ingredients.__wrapped__(),**options)
 state=op.base_model.state_from_temperatures([[2.,0.,0.,.01]],[300.])
 out=op.evaluate(state,.05)
 rows[name]={'identity':op.operator_identity,'point_digest':digest(out),'point':snapshot(out),'surface':_canonical(op._surface(300.,op.program.at(.05)))}
print(json.dumps({'elapsed_s':time.monotonic()-start,'rows':rows},indent=2))
