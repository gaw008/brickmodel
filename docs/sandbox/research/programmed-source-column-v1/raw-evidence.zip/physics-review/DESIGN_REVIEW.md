# ProgrammedSourceWetColumn design/physics review

Read-only review of existing ProgrammedSolidFluidHeat._surface and ExactProgramView. No EOS or trajectory execution and no repository edits. The proposed wrapper is physically consistent as a conditional prescribed-environment model if the following contracts are retained. It advances the open boundary requirement without admitting missing raw-material transport or volume evidence.

## Signs and energy accounting

Orient all faces toward increasing cell index. Face 0 remains closed. Right face N is positive body-to-reservoir. Let Jk be each signed outward gas molar flux and Qc be positive heat conducted from solid surface into the last cell. Then:

- boundary Eout = sum(diffusive_Jk*h_k(Tface)) + sum(advective_Jk*h_k(Tdonor)) - Qc;
- last-cell dU/dt includes -Eout;
- global body energy change = -integrated right-face Eout + accepted signed projection corrections;
- each body gas quantity includes -integrated right-face Jk; total water includes liquid and vapor so local phase transfer cancels.

Compute the right face once and use that one value in both local update and external ledger. Gas advection carries enthalpy, including flow work, so no additional pressure-work boundary source is added to a fixed control volume. Liquid/vapor energy differences remain in storage; no added latent-heat source. Surface conduction already equals convection plus radiation within its residual. Add only Qc to the body, never Qc plus convective and radiative terms. Preserve the signed surface residual separately.

## Geometry and temperature roles

For a fixed slab the surface-to-last-cell distance is width_last/2. Thermal resistance is width_last/(2*k_last*A). The gas-only WetFace may use two quarter widths so its total distance is the same half-cell distance; both artificial gas-face conductivities must be zero to suppress its conduction path. The independent thermal surface solver supplies all boundary conduction.

Equal quarter widths imply the existing face interpolation selects Tface=(Tcell+Treservoir)/2 for diffusive enthalpy. This is an explicit numerical interface convention. It is not the solid surface root Ts and does not resolve the external boundary layer. Do not label the interpolated gas face temperature as the physical solid surface temperature. Darcy donor temperature must switch with direction, including unequal reservoir/cell T; zero advective rate must not require a nonexistent donor temperature.

For k>0, h>0, emissivity=0 the independent linear Robin answer is Ts=(g*Tcell+h*Tgas)/(g+h), Qc=A*g*h*(Tgas-Tcell)/(g+h), g=2*k/width. For example A=.01 m2, width=.25 m, k=.5 W/(m K), h=10 W/(m2 K), Tcell=320 K and Tgas=340 K give Ts=2340/7 K and Qc=4/7 W. Qc>0 and the heat-only outward boundary face energy must be -4/7 W. This is an exact analytic surface test, not a constant-C temporal solution for source material.

Radiation introduces sigma*epsilon*A*(Trad^4-Ts^4). For nonnegative coefficients and temperatures, surface residual Qc-Qconv-Qrad is nondecreasing in Ts; bracketing by min/max of Tcell,Tgas,Trad is valid. Zero k and nonzero external heat transfer has zero conducted body heat even if the exterior surface equilibrates between gas and radiation. All coefficients zero is explicitly underdetermined/insulated. Surface residual tolerance is a boundary algebraic solve tolerance, not a time-integration bound or experimental uncertainty.

## Source applicability and identity

Require exact ProgrammedSourceWetColumn wrapper type, SourceWetColumn base, ExactProgramView whose underlying program is BoundaryProgram (not ScalarProgram), full gas species/R/molar identity, and reviewed source caloric providers. Bind the program contents, exact translation, surface coefficients/policy, Stefan-Boltzmann source, gas face geometry/coefficients and energy interpolation convention. Runtime mutations must fail before evaluating new rates. The base must remain explicitly closed so replacing its right endpoint cannot double-add an existing reservoir.

At every actual query, reservoir gas T must be within all selected gas enthalpy provider domains, including water vapor's low-temperature bridge. Face and donor enthalpy queries must satisfy the same ranges. Cell inverse temperature must remain within the source dry-caloric and fluid domains. Radiation temperature or a surface root is not a dry-material caloric evaluation and need not artificially be restricted to the dry Cp range; a hot radiation environment may be selected, but heating a cell beyond its valid source range must terminate with the accepted prefix. No out-of-range gas caloric extrapolation is allowed to make a high-temperature furnace programme appear supported.

The reservoir is infinite and prescribed. Its inventory is not tracked as a finite cell; only signed exchanged mass/energy is accumulated. Programme temperature/pressure/composition are virtual_design_choice. Manufactured geometry, phase/transport/film coefficients do not acquire source-material qualification because programme interpolation, radiation law or water EOS have citations. material_qualified remains false.

## Exact time and integration

Use the existing shared midpoint integrator, with explicit wrapper dispatch; do not broadly permit arbitrary duck-typed operators. Initial time, first/midpoint/endpoint rate query times and all subdivision endpoints must use ExactEventTime/Fraction arithmetic. Merge requested nominal step endpoints with exact programme knots before advancing; no step may straddle an interior slope-change knot. Evaluate actual time at all three stages; neither endpoint-only boundary sampling nor a frozen initial boundary is midpoint integration.

Knot subdivision changes the actual accepted step count. Report nominal requested steps separately from actual ledger count/subdivision, with exact cumulative times and durations. If an endpoint is rejected or budget expires, keep only the last fully admitted state/time/ledger prefix, including prior accepted subdivisions. Exact schedule clocks do not themselves grant the old exact depletion-event/localization/resume APIs. Large translated absolute times must not be converted to one float before determining knot membership or midpoint locations.

## Minimum independent verification after implementation

1. Linear Robin formula above, both heating and cooling, no radiation; independently check Ts, Qc, sign and signed residual. Include zero-k and adiabatic cases without requiring an arbitrary surface temperature to be physically unique.
2. Turn phase/diffusion/Darcy off and test that body U gain equals the negative right-face outward heat integral plus signed projection corrections; no duplicate convective/radiative contribution.
3. Nonzero reservoir pressure/composition gradients in both directions with different Tcell/Treservoir. Independently call the underlying gas transport primitive, then recompute species enthalpy at face/donor T and form Eout. Check every species and global energy/water external ledger. This checks assembly, not independent validity of the constitutive primitive.
4. At least one internal programme knot strictly inside a nominal timestep, with differing slopes on either side. Require an exact accepted endpoint at the knot and stage queries at the exact substep midpoints. Use a large rational schedule translation to expose float clock collapse. Compare translated and untranslated relative schedules within identical arithmetic/primitive evaluations.
5. Keep N>=3 so middle-cell internal exchange and last-cell internal-plus-external exchange are both active. Recheck each cell and global external balances with exact saved face and projection data. Predictor corrections remain outside accepted physical balance.
6. A small artificial-liquid independent RHS/DOP853 reference can check time-varying boundary convergence after code freezes. Do not treat a constant-capacity heat exponential as an exact source Cp(T) solution. Run only a bounded manufactured case; no new native EOS work in this design review.

Potential implementation errors to reject: right-face sign inversion; duplicated gas conduction or heat source; using reservoir enthalpy for outgoing advection; subtracting gas enthalpy a second time in a surface residual that already represents only conduction/convection/radiation; extrapolating water gas enthalpy to kiln temperatures; silently skipping time knots; replacing current surface half-width with a full cell distance; or claiming exact-event/material admission from the wrapper.
