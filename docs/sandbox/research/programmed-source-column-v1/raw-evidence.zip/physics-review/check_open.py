"""Bounded independent open RHS; no production aggregate used as oracle."""
from pathlib import Path
from fractions import Fraction as F
from dataclasses import replace
import json,math,hashlib,time,signal,traceback
import numpy as np
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
from pytest import MonkeyPatch
from test_programmed_source_wet_column import setup
from sludge_sandbox.exact_boundary_program import ExactProgramView
from sludge_sandbox.gas_transport import ideal_gas_state,ideal_gas_reservoir,face_exchange
from sludge_sandbox.source_wet_column import integrate_source_column
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github');OUT=Path('/private/tmp/brick-source-boundary-physics-v1')
paths=['src/sludge_sandbox/programmed_source_wet_column.py','src/sludge_sandbox/source_wet_column.py','src/sludge_sandbox/surface_balance.py','src/sludge_sandbox/mass_wet_transport.py']
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
frozen=hashes();start=time.monotonic();result={'hashes_before':frozen,'runs':[]};patch=MonkeyPatch()
def timeout(*args):raise TimeoutError('55_second_cap')
signal.signal(signal.SIGALRM,timeout);signal.alarm(55)
try:
 model,initial=setup(patch,knots=(0.,.0625,.125))
 tg=(330.,340.,335.);tr=(340.,345.,338.);press=(1.4e6,1.6e6,1.3e6);xs=((.25,.6875,.0625),(.3125,.625,.0625),(.1875,.71875,.09375))
 program=replace(model.program.program,gas_temperature_k=tg,radiation_temperature_k=tr,total_pressure_pa=press,mole_fractions=xs)
 model=replace(model,program=ExactProgramView(program),emissivity=.5)
 ids=model.gas_ids;curves=[model.storages[0].fluid_template.gas_phases[k]._curve for k in ids]
 R=model.base.chemical.gas_constant_j_mol_k;m=.2;a=1434-3.29*273.15;t0=313.15
 masses={k:model.storages[0].fluid_template.gas_phases[k].molar_mass_kg_mol for k in ids}
 def pack(states):
  s=states[0];return np.array([s.liquid_water_mol,*s.gas_amounts_mol,s.internal_energy_j])
 def energy(t,nl,ng):return nl*(75*t-300000)+math.fsum(n*c.internal_energy_j_mol(t) for n,c in zip(ng,curves))+m*(a*(t-t0)+1.645*(t*t-t0*t0))
 def rhs(t,y):
  nl=y[0];ng=y[1:4];T=brentq(lambda T:energy(T,nl,ng)-y[4],310,350,xtol=1e-11,rtol=1e-14)
  vg=.001-nl*1.8e-5;p=sum(ng)*R*T/vg
  eq=model.base.chemical.equilibrium_at_liquid_tp(T,p);phase=1e-9*(eq.equilibrium_partial_pressure_pa-ng[2]*R*T/vg)
  j=0 if t<=.0625 else 1;w=(t-j*.0625)/.0625
  lerp=lambda values:(1-w)*values[j]+w*values[j+1]
  gasT=lerp(tg);radT=lerp(tr);pressure=lerp(press)
  fractions={k:lerp(tuple(row[i] for row in xs)) for i,k in enumerate(ids)}
  cell=ideal_gas_state(dict(zip(ids,ng)),temperature_k=T,gas_volume_m3=vg,molar_masses_kg_mol=masses,gas_constant_j_mol_k=R)
  reservoir=ideal_gas_reservoir(pressure_pa=pressure,temperature_k=gasT,mole_fractions=fractions,molar_masses_kg_mol=masses,gas_constant_j_mol_k=R)
  ex=face_exchange(cell,reservoir,area_m2=.01,distance_m=.125,face_left_weight=.5,effective_diffusivities_m2_s=dict(zip(ids,(1e-5,2e-5,1.5e-5))),permeability_m2=1e-13,relative_permeability=1.,viscosity_pa_s=1.8e-5)
  def residual(ts):return .04*(ts-T)-.1*(gasT-ts)-.5*5.670374419e-8*.01*(radT**4-ts**4)
  ts=brentq(residual,min(T,gasT,radT),max(T,gasT,radT),xtol=1e-11,rtol=1e-14)
  q=.04*(ts-T);terms=[-q]
  for k,c in zip(ids,curves):
   terms.append(ex.diffusive_mol_s[k]*c.enthalpy_j_mol(ex.face_temperature_k))
   if ex.advective_mol_s[k]:terms.append(ex.advective_mol_s[k]*c.enthalpy_j_mol(ex.advective_donor_temperature_k))
  return np.array([-phase,*[-ex.net_mol_s[k]+(phase if k=='H2O' else 0) for k in ids],-math.fsum(terms)])
 y0=pack(initial);yref=y0.copy();nfev=0;probe=time.monotonic();rhs(0,y0);result['probe_seconds']=time.monotonic()-probe
 for lo,hi in ((0.,.0625),(.0625,.125)):
  sol=solve_ivp(rhs,(lo,hi),yref,method='DOP853',rtol=2e-12,atol=[1e-13]*4+[1e-8],max_step=(hi-lo)/2)
  assert sol.success;yref=sol.y[:,-1];nfev+=sol.nfev
 result['dop853_nfev']=nfev;result['reference_final']=yref.tolist()
 for steps in (2,4,8):
  run=integrate_source_column(model,initial,duration_s=.125,steps=steps,maximum_wall_seconds=12.)
  row={'steps':steps,'status':run.status,'reason':run.reason,'seconds':run.elapsed_seconds};result['runs'].append(row)
  assert run.status=='completed',run.reason
  err=pack(run.states[-1])-yref;row.update(energy_error_j=abs(float(err[4])),inventory_error_mol=float(max(abs(err[:4]))))
  assert F(1,16) in run.times_s
  for old,new,l in zip(run.states,run.states[1:],run.ledgers):
   aa,bb=old[0],new[0];face=l.faces[-1];r=l.roundoff
   assert F(bb.internal_energy_j)-F(aa.internal_energy_j)==-face.energy_j+r.energy_j[0]
   for k in (0,1):assert F(bb.gas_amounts_mol[k])-F(aa.gas_amounts_mol[k])==-face.gas_mol[k]+r.gas_mol[0][k]
   assert F(bb.liquid_water_mol)+F(bb.gas_amounts_mol[2])-F(aa.liquid_water_mol)-F(aa.gas_amounts_mol[2])==-face.gas_mol[2]+r.liquid_mol[0]+r.gas_mol[0][2]
   b=l.boundary_integral
   assert b.conductive_into_cell_j==-face.conduction_j
   assert b.exact_surface_balance_defect_j==b.conductive_into_cell_j-b.convective_in_j-b.radiative_in_j
   assert abs(b.reported_surface_residual_j)<=b.surface_balance_limit_j
  row['exact_open_ledger_checks']='passed'
 for key in ('energy_error_j','inventory_error_mol'):
  ratios=[result['runs'][i][key]/result['runs'][i+1][key] for i in (0,1)];result[key+'_ratios']=ratios
  assert all(3<r<5 for r in ratios),(key,ratios)
 result['passed']=True
except Exception as exc:
 result.update(passed=False,error=repr(exc),traceback=traceback.format_exc())
finally:
 signal.alarm(0);patch.undo();result['elapsed_seconds']=time.monotonic()-start;result['hashes_after']=hashes();result['reviewed_files_unchanged']=frozen==result['hashes_after'];result['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();(OUT/'OPEN_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
assert result['passed'] and result['reviewed_files_unchanged']
