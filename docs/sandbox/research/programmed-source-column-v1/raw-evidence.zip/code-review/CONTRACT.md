# Boundary review preparation (not approval)

Baseline old HEAD snapshots saved before author changes. Open right face is positive outward: positive gas enthalpy out removes cell U; surface heat into cell must enter outward face as its negative. The gas-only boundary face must contribute only gas enthalpy, no duplicate direct cell/reservoir conduction in addition to half-cell surface film. Internal faces and left closed boundary remain shared.

Boundary time must preserve Fraction step coordinates and program knots; midpoint full update starts from previously accepted state. A step must never cross a declared program knot. Program evaluation at exact nodes must use the corresponding boundary convention. Cancellation, failed end-state validation and resource exits retain only complete accepted prefix. Surface root extraction must preserve default slab/spherical/current-moving transport selection and previous arithmetic. No native EOS execution or new-code approval at preparation stage.
