from dataclasses import replace
from fractions import Fraction as F
import math
import pytest
from test_programmed_source_wet_column import setup
from sludge_sandbox.programmed_source_wet_column import ProgrammedSourceWetColumn
from sludge_sandbox.source_wet_column import integrate_source_column,SourceWetColumn
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.exact_boundary_program import ExactProgramView

def test_cooling_sign_and_no_second_heat(monkeypatch):
    m,s=setup(monkeypatch,thermal_only=True)
    p=replace(m.program.program,gas_temperature_k=(320.,)*2,radiation_temperature_k=(320.,)*2)
    m=replace(m,program=ExactProgramView(p));o=m.evaluate(s,ExactEventTime(F()))
    t=o.gas_states[0].temperature_k
    exact=(320-t)/(m.base.cell_widths_m[0]/(2*m.outer_conductivity_w_m_k*m.base.face_area_m2)+1/(m.convection_w_m2_k*m.base.face_area_m2))
    assert math.isclose(o.surface.conductive_into_cell_w,exact,abs_tol=1e-10)
    assert o.faces[-1].energy_w>0 and o.faces[-1].shared_evaluation.conduction_w==0

def test_zero_conductivity_keeps_open_gas_enthalpy(monkeypatch):
    m,s=setup(monkeypatch,pressure=2e6);m=replace(m,outer_conductivity_w_m_k=0.)
    o=m.evaluate(s,ExactEventTime(F()))
    assert o.surface.conductive_into_cell_w==0 and any(o.faces[-1].gas_mol_s)
    assert o.faces[-1].energy_w==math.fsum((*o.faces[-1].diffusive_enthalpy_w,*o.faces[-1].advective_enthalpy_w))

def test_exact_start_inside_program_knot_equal_nominal(monkeypatch):
    origin=F(10**18)
    m,s=setup(monkeypatch,thermal_only=True,knots=(0.,1/256,1/128,1/64),translation=origin)
    r=integrate_source_column(m,s,duration_s=1/128,steps=2,start_time=ExactEventTime(origin+F(1,256)))
    assert r.status=='completed',r.reason
    assert r.times_s==(origin+F(1,256),origin+F(1,128),origin+F(3,256))
    assert len(r.ledgers)==2 and all(l.duration_s==F(1,256) for l in r.ledgers)

def test_cancel_before_final_observation_discards_candidate(monkeypatch):
    m,s=setup(monkeypatch,thermal_only=True);calls=0
    def stop():
        nonlocal calls
        calls+=1
        return calls==3
    r=integrate_source_column(m,s,duration_s=1/256,steps=1,cancel=stop)
    assert r.status=='cancelled' and r.states==(s,) and not r.ledgers and r.evaluations_completed==2

def test_program_source_drift_pre_base_query(monkeypatch):
    m,s=setup(monkeypatch)
    def forbidden(*a,**k):pytest.fail('drift reached base')
    monkeypatch.setattr(SourceWetColumn,'evaluate',forbidden)
    object.__setattr__(m,'coefficient_source_ids',('manufactured:drift',))
    with pytest.raises(ValueError,match='content_changed'):m.evaluate(s,ExactEventTime(F()))
