"""Reviewer-owned no-EOS tests of the actual candidate transaction AST."""
import ast
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
from threading import RLock
from types import SimpleNamespace
import warnings

ROOT = Path(__file__).parent
tree = ast.parse((ROOT / 'sludge_sandbox/_heos_kernel.py').read_text())
cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'HEOSCandidate')
method = next(x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == '_transaction')
module = ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[]))

class SourceError(ValueError):
    pass

class NumericalError(ValueError):
    pass

scope = dict(contextmanager=contextmanager, hashlib=hashlib, json=json,
             warnings=warnings, WaterSourceError=SourceError, WaterNumericalError=NumericalError)
exec(compile(module, 'candidate_transaction_ast', 'exec'), scope)
transaction = scope['_transaction']

class FakeCP:
    def __init__(self):
        self.raw = '{"a":1}'
        self.config = '{}'
        self.reads = 0

    def get_config_as_json_string(self):
        return self.config

    def get_fluid_param_string(self, fluid, field):
        assert (fluid, field) == ('Water', 'JSON')
        self.reads += 1
        return self.raw

def instance():
    cp = FakeCP()
    return SimpleNamespace(_cp=cp, _config='{}', _lock=RLock(),
                           _fluid_digest=hashlib.sha256(cp.raw.encode()).hexdigest())

results = []
for case in ('stable', 'pre_content', 'post_content', 'pre_whitespace',
             'post_whitespace', 'pre_config', 'post_config', 'warning', 'nested'):
    obj = instance()
    entered = False
    expected = None
    if case.startswith('pre_'):
        if case == 'pre_config':
            obj._cp.config = '{"x":1}'
        else:
            obj._cp.raw = '{"a":2}' if case == 'pre_content' else '{ "a": 1 }'
        expected = SourceError
    elif case.startswith('post_'):
        expected = SourceError
    elif case == 'warning':
        expected = NumericalError
    try:
        with transaction(obj):
            entered = True
            if case == 'post_content': obj._cp.raw = '{"a":2}'
            if case == 'post_whitespace': obj._cp.raw = '{ "a": 1 }'
            if case == 'post_config': obj._cp.config = '{"x":1}'
            if case == 'warning': warnings.warn('review_injected', RuntimeWarning)
            if case == 'nested':
                with transaction(obj): pass
    except (SourceError, NumericalError) as exc:
        assert expected is not None and type(exc) is expected
        if case.startswith('pre_'): assert not entered
        results.append(dict(case=case, rejection=str(exc), passed=True))
    else:
        assert expected is None
        assert obj._cp.reads == (4 if case == 'nested' else 2)
        results.append(dict(case=case, raw_reads=obj._cp.reads, passed=True))
assert json.loads('{"a":1}') == json.loads('{ "a": 1 }')
(ROOT / 'review-fault-results.json').write_text(json.dumps(dict(
    scope='actual_transaction_AST_with_stub_CP_no_EOS',
    kernel_sha256=hashlib.sha256((ROOT / 'sludge_sandbox/_heos_kernel.py').read_bytes()).hexdigest(),
    cases=results), indent=2) + '\n')
print('9 no-EOS transaction checks passed')
