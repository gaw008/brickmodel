from pathlib import Path
import sys,json
repo=Path('/Users/wanggaoying/Desktop/brickmodel-github');case=Path('/private/tmp/brick-heos-stage8-installed')
sys.path.insert(0,str(repo/'docs/sandbox/research/research-process-supervisor'))
from supervisor import run_attempt
script,attempt=sys.argv[1:]
inputs=list((repo/'src/sludge_sandbox').glob('*.py'))+list((repo/'tests/sandbox').glob('*.py'))+list((repo/'data/sandbox/water').rglob('*'))+list(case.glob('*.py'))+[case/'PLAN.json',case/'expected.json',case/'previous-result.json',repo/'docs/sandbox/research/research-process-supervisor/supervisor.py']
result=run_attempt(case/attempt,['/usr/bin/env',f'PYTHONPATH={repo}/tests/sandbox','PYTHONDONTWRITEBYTECODE=1','/private/tmp/brick-water-backend-probe/venv/bin/python',str(case/script)],cwd='/private/tmp',input_paths=[p for p in inputs if p.is_file()],timeout_s=30)
print(json.dumps({k:result[k] for k in ('status','returncode','elapsed_s','cleanup')},indent=2))
