import importlib.util,sys
from pathlib import Path
for name,path in [('exact_terminal_executor',Path('/private/tmp/brick-exact-terminal-executor-v1/exact_terminal_executor.py')),('exact_depletion_integration',Path(__file__).with_name('exact_depletion_integration.py'))]:
    spec=importlib.util.spec_from_file_location('sludge_sandbox.'+name,path);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
