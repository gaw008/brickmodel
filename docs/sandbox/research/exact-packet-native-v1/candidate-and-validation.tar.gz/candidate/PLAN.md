# Next implementation: complete exact-time ordered packet core

Implement ONE new exact_depletion_integration.py driver over the installed exact ordinary integrator, explicit ExactFreeWaterTransfer and Carson's single-terminal executor. Do not create another isolated mathematical primitive. First target is the original four-cell physical case from original initial state to original common/end horizon, with the original two-pass and independent-approach acceptance gates. This is a concrete core milestone; service/checkpoint serialization remains explicitly refused until its exact schema is audited.

## Public entry and records

`integrate_exact_depletion(initial, operator: ExactFreeWaterTransfer, *, start: ExactEventTime, end: ExactEventTime, integration_policy: IntegrationPolicy, event_policy: DepletionPolicy, cancel=None) -> ExactDepletionResult`.

Require direct autonomous free-slab transfer, affine_midpoint and explicit ordered strategy/nested controls. Preserve original physical model/energy identity and pressure comparison policy. A new versioned exact-time strategy identity is required; no cast to legacy DepletionResult. Result contains original full accepted times/states/ExactStepLedgers, explicit event frames and corrections, original policies, final actual exact view/modes, cumulative totals, full refinement attempts and phase costs, actual resource counters and structured status/reason. Internal mutable Path holds speculative states/steps/frames/current view/totals; freezing output does not make uncommitted data accepted.

Carson executor returns an ExactTerminalAttempt, retaining actual observations, predictor, root order, panel, correction, candidate totals/view and costs even on failure. Driver must append successful terminal panel exactly once at its exact endpoint and use its actual endpoint observation. Do not rerun the endpoint merely to translate types. A failed attempt remains diagnostics, never an accepted terminal panel.

## Port actual existing control flow, not scientific meaning

1. Mirror depletion_integration.py:480–595: one outer monotonic wall clock, global component schema and energy/source binding, guarded observations, bounded ordinary runs. Native observations retain full actual WPT output needed by paired pressure comparison; compact detached T/P/error/rate data may coexist. All observation counts come from actual calls. Ordinary `integrate_exact` returns an accepted local prefix on failure; only that prefix may be appended. Guard actual operator identity before/after calls and before commit.
2. Candidate tau=N/(-net liquid rate) is a rational scheduling estimate only. It does not certify ordering. Exact ordinary endpoint = min(current+cap,current+safe*tau,target). Start root from the actual accepted state. Retain current safeguards against positive-stage failures and approaching another event during an ordinary RK stage.
3. Mirror proposal/continue_packet:915–967 and 836–867. Ordinary approach advances until the terminal window, then execute the actual terminal, switch ONLY its certified selected cell through its returned view, and continue mixed RHS to one exact common endpoint. Repeat terminal execution for another impending event. A stage forecast at/before ordinary finish triggers a structured replan through the ordinary integrator's failure boundary, retaining only its accepted prefix and charging its interrupted trial. Never change modes at an unaccepted stage. A replan with no localizable next root must fail as before, not loop indefinitely.
4. Common endpoint is shared exactly across compared paths. Compute the original min(end/knot,current+max(common_horizon,2*terminal_window)) using Fraction policy durations. Any horizon reduction resets previous/coarse comparisons, successes and independent-approach reuse; old candidate paths are discarded but their costs remain charged.
5. Outer refinement follows existing 1125–1277: coarse path first; halve terminal approach window; compare successive paths; require TWO CONSECUTIVE passes. Then run the independently finer approach with BOTH ordinary cap and safe inventory fraction halved, not merely a nominal inactive cap. Require actual distinct ordinary endpoint grids. Independent branch failure is a structured rejection with once-only costs; no opportunistic fallback to an earlier path. Each frame must carry real corresponding previous/coarse/common metadata; packet-wide maxima must be labeled, and raw per-frame arrays preserved.
6. Before accepting a packet, its event cell sequence and final modes must match across paths. Match each corresponding event frame, not only the first. Continue every path through actual mixed RHS to common endpoint, including any additional events encountered there.

## Comparisons: retain original six gates exactly

Existing single_comparison:968–1037 and comparison:1039–1054 provide the contract:
- Event time: exact `abs(tA-tB) + widthA + widthB <= Fraction(original time_absolute_s)`. Width is each selected lower-to-upper rational root enclosure; no float event-time conversion. Diagnostic display may round outward but cannot be used as the criterion.
- N and E: maximum across every full event state and common state, original absolute thresholds.
- T: original nominal maximum difference plus both original maximum inverse-temperature errors, event/common maximum. No new thermal uncertainty cancellation.
- P: original point-error family unless the original explicit shared-constant policy is present. Reuse `compare_pressure_pair` on actual underlying `view.operator`/state/inverses; this routine need not receive time. Keep both original independent P bound and selected pair certificate, actual endpoint samples and before/after endpoint call accounting. The helper strict WPT admission is satisfied by explicit unwrapping, not weakening isinstance checks or inventing fake hosts. Preserve reported-temperature qualification.
- Mechanical: original maximum full-vector event/common difference <= original stretch tolerance.

No time tolerance is a minimum physical event spacing. No sampling-dependent source error or numerical gate is widened. These are the same empirical full-path refinement checks, not a new rigorous true-RHS validated ODE requirement.

## Global resources and exact ordinary duration boundary

All numerical durations begin as exact Fractions of the original policy floats. Exact integration's future nominal-duration downward quantization is explicit. The old normal adapter uses `min/max(float, finish-t)` and `float(maxstep)`; replace that with a deliberate downward nominal policy cap while actual exact end clips the interval. Refuse a clipped interval below original minimum; do not discard it or reset the clock origin. If safe exact cap is below minimum, fail openly.

One original wall deadline covers every ordinary trial, midpoint/terminal/endpoint evaluation, source guard and comparison, including discarded paths. Pass remaining wall allowance downward into callees and outer cancellation/deadline guard into every call path. Executor must not restart the original wall allowance on each terminal. Debit ordinary attempted/rejected counts from its actual result and terminal predictor/terminal counters from executor costs exactly once, including failed attempts. Retain legacy panel-budget semantics explicitly and also expose attempted RK trials; do not conflate 6 RHS calls with 6 panels. No `max(1, remaining)` or epsilon-wall shortcut may dispatch after budget exhaustion.

The first coherent driver may disable ordinary-spine reuse under an explicitly recorded no-reuse exact strategy, without changing numerical cap/safe/refinement controls. If original reuse is claimed, port immutable spine binding and actual cache counts fully. Never silently label missing reuse as exercised. Reuse never caches terminal, dry, correction or comparison calls.

## Atomic commit and record boundary

Port commit:1056–1113 against ORIGINAL global initial state. Accumulate every signed shared face/source/E/work ledger once, apply each event's paired liquid/vapor correction once, and audit represented N/E/component and mechanical represented/exact quadrature budgets. All correction totals are cumulative original totals, not reset at packet/terminal boundaries. Validate all prospective prefixes before mutating global accepted state/operator/modes/events. Failure or cancellation retains the previous globally committed prefix, and separately preserves the entire uncommitted packet diagnostics/costs.

Legacy event_record float-time whitelist, legacy DepletionEvent clocks, ordinary checkpoint types and run_service event branch cannot consume these records. Explicit new schema must encode semantic time numerator/denominator, exact root brackets, complete initial/mid/endpoint observations, original/full cumulative ledger and mode lineage before service replay/resume is admitted. First actual four-cell core run can use a research-only full capture with original failure preservation; it must not masquerade as a resumable legacy result.

## Required tests then one bounded actual run

Use a strict source-bound fake exact host for pure driver tests (or a separately explicit manufactured adapter), never pretend it is a native WaterTransferEvaluation by incomplete fields. Cover: two close events that require mixed-RHS reevaluation; initial tangent tie that separates; true same-root unsupported; accelerating later event inside an RK stage; two-pass and independent-grid failure; cancellation before/after speculative first event; source mutation at final acceptance; full initial cumulative N/E/mechanical/correction budgets; predictor/interrupted/rejected/comparison costs; and all-frame comparison metadata. Reuse original analytic identities and thresholds.

Once this complete driver passes review and installed-source checks, root authorizes ONE original four-cell initial-to-end core run under its unchanged 800 s integration / 840 s outer budget. Save full success/failure before assertions. No forecast of success from the already accepted cell-2/3 endpoint: that endpoint was only one uncommitted reconstructed branch, not two refined complete paths.

This plan was prepared by reading actual sources and current executor draft only. No production edits, EOS, installation or tests were run.
