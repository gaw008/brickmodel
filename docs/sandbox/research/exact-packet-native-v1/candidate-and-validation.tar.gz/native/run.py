"""Original four-cell experiment with exact packet core; research-only capture."""
from pathlib import Path
from dataclasses import fields,is_dataclass,replace
from collections.abc import Mapping
import json,hashlib,time,traceback
from sludge_sandbox.verification_case import read_case,build_case,encode
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.exact_depletion_integration import integrate_exact_depletion
from sludge_sandbox.water_phase_transfer import WaterTransferEvaluation
from sludge_sandbox.deforming_solid_storage import _canonical
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent
out=root/'attempt01';out.mkdir(exist_ok=False)
prior=Path('/private/tmp/brick-four-cell-ordered-failure-evidence-v1/attempt01')
def save(name,v):(out/name).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def capture(v):
    if type(v) is ExactFreeWaterTransfer:
        return {'schema':'research_exact_operator_reference_v1','identity':encode(v._identity),'modes':list(v.operator.interfaces)}
    if type(v) is WaterTransferEvaluation:
        # Snapshot exactly the numerical observation vectors used by the core,
        # phase diagnostics and Rates. Do not duplicate live current_host trees.
        b=v.base_evaluation
        return {'schema':'research_depletion_observation_v1','rates':encode(v.rates),
          'temperatures_k':[x.mechanical.temperature_k for x in b.storage_states],
          'temperature_errors_k':[x.temperature_error_bound_k for x in b.storage_inverses],
          'pressures_pa':[x.mechanical.pressure_pa for x in b.storage_states],
          'pressure_errors_pa':[x.pressure_error_bound_pa for x in b.storage_states],
          'cell_transfers':encode(v.cell_transfers),'interface_modes':list(v.interface_modes),
          'source_ids':list(v.source_ids),'coefficient_set_id':v.coefficient_set_id,
          'coefficient_version':v.coefficient_version,'coefficient_classification':v.coefficient_classification,
          'dry_policy':v.dry_policy,'qualification':v.qualification}
    if is_dataclass(v):return {f.name:capture(getattr(v,f.name)) for f in fields(v)}
    if isinstance(v,Mapping):return {str(k):capture(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [capture(x) for x in v]
    return encode(v)
started=time.monotonic();before=runtime_identity();save('runtime-before.json',before)
casebytes=(prior/'case.json').read_bytes();(out/'case.json').write_bytes(casebytes)
report={'capture_status':'started','qualification':'Exact ordered packet research core, actual water EOS with manufactured solid; not audited legacy record/resume or material validation.'}
try:
    built=build_case(read_case(out/'case.json'),Path('/private/tmp/brick-free-native-events-v1/attempt01/water'))
    assert encode(built.initial)==json.loads((prior/'initial.json').read_text())
    assert encode(built.policy)==json.loads((prior/'original-integration-policy.json').read_text())
    assert encode(built.depletion_policy)==json.loads((prior/'original-depletion-policy.json').read_text())
    policy=replace(built.depletion_policy,ordered_event_policy='ordered_affine_packet_v1')
    assert encode(policy)==json.loads((prior/'actual-depletion-policy.json').read_text())
    assert built.start_s==.5 and built.end_s==.50032
    assert built.policy.maximum_steps==512 and built.policy.maximum_wall_seconds==800.
    op=ExactFreeWaterTransfer(built.operator);identity=op.operator_identity
    save('initial.json',encode(built.initial));save('initialization.json',built.initialization)
    save('original-operator-inputs.json',_canonical(built.operator))
    save('operator-identity.json',encode(identity));save('integration-policy.json',encode(built.policy));save('event-policy.json',encode(policy))
    start=ExactEventTime.from_float(built.start_s);end=ExactEventTime.from_float(built.end_s)
    save('times.json',{'start':start.to_record(),'end':end.to_record()})
    core_started=time.monotonic()
    result=integrate_exact_depletion(built.initial,op,start=start,end=end,integration_policy=built.policy,event_policy=policy)
    report['core_elapsed_s']=time.monotonic()-core_started
    save('core-result.json',capture(result))
    assert identity==op.operator_identity
    assert encode(built.initial)==json.loads((prior/'initial.json').read_text())
    report.update(capture_status='captured',core_status=result.status,core_reason=result.reason,
        accepted_steps=len(result.steps),packets=len(result.packets),events=sum(len(x) for x in result.packets),
        terminal_attempts=len(result.terminal_attempts),final_time=result.times_s[-1].to_record(),costs=encode(result.costs))
except BaseException:
    report.update(capture_status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-after.json',after);assert before==after
        assert casebytes==(prior/'case.json').read_bytes()==(out/'case.json').read_bytes()
    except BaseException:report.update(capture_status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_s=time.monotonic()-started,modules=len(before['modules']),case_sha256=hashlib.sha256(casebytes).hexdigest(),runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    save('report.json',report)
assert report['capture_status']=='captured',report
