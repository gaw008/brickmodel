"""Saved comparison audit only. Main is run after native termination; no EOS/build_case.
Uses the existing pure pressure record auditor; full prefix ledgers are audited separately.
"""
from pathlib import Path
from fractions import Fraction as F
from dataclasses import fields
import copy,hashlib,json,math
from sludge_sandbox.integration import ConservedState
from sludge_sandbox.pressure_comparison import restore_pressure_comparison_policy,audit_pressure_comparison
from sludge_sandbox.water_implementation import WaterImplementation
P=Path(__file__).parent

def load(path):return json.loads(path.read_text())
def q(v):return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)
def t(v):return q(v['seconds'])
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def cf(v):return dict(v[2])
def plain(v):
    if not isinstance(v,list):return v
    if len(v)==2 and v[0]=='float':return float.fromhex(v[1])
    if len(v)==3 and v[0]=='fraction':return F(v[1],v[2])
    if len(v)==2 and v[0]=='mapping':return {k:plain(x) for k,x in v[1]}
    if len(v)==4 and v[0]=='source_gated_water':return {'reference':plain(v[1]),'assets':plain(v[2]),'limits':plain(v[3])}
    if len(v)==3 and isinstance(v[0],str) and v[0].startswith('sludge_sandbox.') and isinstance(v[2],list):return {k:plain(x) for k,x in v[2]}
    return [plain(x) for x in v]
def canon(v):
    if isinstance(v,float):return ['float',v.hex()]
    if isinstance(v,list):return [canon(x) for x in v]
    if isinstance(v,dict):return ['mapping',[[k,canon(x)] for k,x in sorted(v.items())]]
    return v

def state(v):
    return ConservedState(v['amounts_mol'],v['internal_energy_j'],tuple(v['energy_model_identity']),mechanical_stretches=v['mechanical_stretches'])
def diffs(a,b):
    assert len(a)==len(b)
    return [diffs(x,y) if isinstance(x,list) else abs(x-y) for x,y in zip(a,b)]
def flat(v):
    for x in v:
        if isinstance(x,list):yield from flat(x)
        else:yield x
def maximum(a,b):return max(flat(diffs(a,b)))
def observation(v,n):
    assert v['schema']=='research_depletion_observation_v1'
    for key in ('temperatures_k','temperature_errors_k','pressures_pa','pressure_errors_pa'):
        assert len(v[key])==n and all(type(x) in (int,float) and math.isfinite(x) for x in v[key])
    assert all(x>=0 for key in ('temperature_errors_k','pressure_errors_pa') for x in v[key])
def time_error(frame):
    a=frame['terminal'];i=a['root_order']['selected_cell'];e=next(x['evidence'] for x in a['root_order']['candidates'] if x['cell_index']==i)
    assert e['lower']==a['observations'][-1]['time']
    s=e['samples'];h=t(e['lower'])-t(s['start']);hm=t(s['midpoint'])-t(s['start'])
    r=sum(map(q,s['liquid_rates_start_mol_s']),F());acc=(sum(map(q,s['liquid_rates_mid_mol_s']),F())-r)/hm
    val=q(s['start_inventory_mol'])+r*h+acc*h*h/2
    assert val>=0
    return F() if val==0 else t(e['upper'])-t(e['lower'])

def main():
    D=P/'attempt01';r=load(D/'core-result.json');report=load(D/'report.json');ep=load(D/'event-policy.json');ip=load(D/'integration-policy.json')
    assert report['capture_status']=='captured' and report['core_status']==r['status']
    assert load(D/'runtime-before.json')==load(D/'runtime-after.json')
    prior=Path('/private/tmp/brick-four-cell-ordered-failure-evidence-v1/attempt01')
    assert (D/'case.json').read_bytes()==(prior/'case.json').read_bytes()
    assert report['case_sha256']==hashlib.sha256((D/'case.json').read_bytes()).hexdigest()
    assert load(D/'initial.json')==load(prior/'initial.json')
    assert ip==load(prior/'original-integration-policy.json') and ep==load(prior/'actual-depletion-policy.json')
    assert r['initial_policy']==ip and r['event_policy']==ep and r['states'][0]==load(D/'initial.json')
    initialcanonical=load(D/'original-operator-inputs.json');originalidentity=load(D/'operator-identity.json');n=len(r['states'][0]['amounts_mol'])
    assert originalidentity[1]==sha(initialcanonical)
    original=plain(initialcanonical);host=original['base_model'];points=host['point_storages'];hostcanonical=cf(initialcanonical)['base_model'];pointcanonical=cf(hostcanonical)['point_storages']
    pc=ep.get('pressure_comparison');pressure_policy=restore_pressure_comparison_policy(pc) if pc else None
    pure_certificates=0;recorded_endpoint_calls=0
    def op_binding(v):
        assert v['schema']=='research_exact_operator_reference_v1' and len(v['modes'])==n
        c=copy.deepcopy(initialcanonical)
        for row in c[2]:
            if row[0]=='interface_modes':row[1]=v['modes']
        identity=v['identity'];assert identity[0]==originalidentity[0] and identity[2]==originalidentity[2]
        assert identity[1]==sha(c)
        return identity[1]
    def path_checks(path):
        assert len(path['times'])==len(path['states'])==len(path['steps'])+1
        op_binding(path['operator'])
        first_event=t(path['frames'][0]['terminal']['observations'][-1]['time']) if path['frames'] else None
        expected=[when for when in path['times'][1:] if first_event is None or t(when)<first_event]
        assert path['approach_grid']==expected
        for f in path['frames']:
            attempt=f['terminal'];assert attempt['status']=='speculative_completed'
            assert attempt['observations'][0]['state']==attempt['initial_state']
            assert attempt['observations'][1]['state']==attempt['predictor_panel']['raw_state']
            assert attempt['observations'][-1]['state']==attempt['corrected_state']
            before=attempt['original_operator'];after=attempt['candidate_operator'];op_binding(before);op_binding(after)
            modes=before['modes'].copy();modes[attempt['root_order']['selected_cell']]='depleted_no_nucleation';assert after['modes']==modes
            assert attempt['observations'][-1]['evaluation']['interface_modes']==modes
            idx=path['times'].index(attempt['observations'][-1]['time'])
            assert path['states'][idx]==attempt['corrected_state'] and path['steps'][idx-1]==attempt['terminal_panel']['ledger']
    def binding_static(binding,view):
        assert binding['operator_sha256']==op_binding(view) and binding['base_sha256']==sha(hostcanonical) and binding['interfaces']==view['modes']
        assert binding['layout']==host['base_model']['inventory_layout']
        assert binding['water_reference']==original['chemical']['water']['reference']
        implementation=binding['water_implementation']
        implcanon=['sludge_sandbox.water_implementation','WaterImplementation',[[f.name,canon(implementation[f.name])] for f in fields(WaterImplementation)]] if implementation is not None else None
        chemical_slot=next(x for x in originalidentity[2] if x[0]==['chemical','water'])
        assert sha(implcanon)==chemical_slot[3]
        assert binding['boxes']==pc['cell_boxes']
        for i,p in enumerate(points):
            assert binding['boxes'][i]['point_identity_sha256']==sha(pointcanonical[i])
            fluid=p['template']['fluid_template'];domain=binding['domains'][i];ref=binding['reference'][i]
            assert q(domain['liquid_v_error'])==F(fluid['envelope']['liquid_v_error_m3_mol'])
            assert list(map(q,domain['pressure']))==list(map(F,fluid['mechanical']['pressure_bracket_pa']))
            assert list(map(q,domain['temperature']))==list(map(F,fluid['envelope']['temperature_range_k']))
            assert q(domain['gas_constant'])==F(original['chemical']['vapor']['gas_constant_j_mol_k'])  # Bound fixed-R bridge; closure uses the same constant
            reference=p['skeleton']['reference_model']['reference']
            assert ref['cells']==n==reference['cells'] and q(ref['area'])==F(reference['reference_area_m2']) and q(ref['half_thickness'])==F(reference['half_thickness_m'])
            assert q(ref['additional_bulk_error'])==F(p['error_bounds']['additional_bulk_volume_error_m3'])
    def paired(record,sa,oa,va,sb,ob,vb):
        nonlocal pure_certificates,recorded_endpoint_calls
        assert record['states']==[sa,sb]
        binding_static(record['bindings_a'],va);binding_static(record['bindings_b'],vb)
        for i,cell in enumerate(record['cells']):
            for key,vec in [('reported_pressures_pa','pressures_pa'),('reported_temperatures_k','temperatures_k'),('original_pressure_errors_pa','pressure_errors_pa'),('original_temperature_errors_k','temperature_errors_k')]:
                assert list(map(q,cell[key]))==[F(oa[vec][i]),F(ob[vec][i])]
        bound=audit_pressure_comparison(record,policy=pressure_policy,state_a=state(sa),state_b=state(sb),bindings_a=record['bindings_a'],bindings_b=record['bindings_b'])
        pure_certificates+=len(record['cells']);recorded_endpoint_calls+=record['endpoint_evaluations'];return bound
    gates=[F(ep['time_absolute_s']),ep['amount_absolute_mol'],ep['energy_absolute_j'],ep['temperature_absolute_k'],ep['pressure_absolute_pa'],ip['stretch_absolute_tolerance']]
    def comparison(ref,a,b):
        assert a['times'][0]==b['times'][0] and a['states'][0]==b['states'][0]
        common=ref['common_time'];assert a['times'][-1]==b['times'][-1]==common
        assert [f['terminal']['root_order']['selected_cell'] for f in a['frames']]==[f['terminal']['root_order']['selected_cell'] for f in b['frames']]
        assert a['operator']['modes']==b['operator']['modes'] and len(ref['comparison'])==len(a['frames'])>0
        maxima=[F(),0.,0.,0.,0.,0.]
        for row,fa,fb in zip(ref['comparison'],a['frames'],b['frames']):
            ea,eb=fa['terminal']['observations'][-1],fb['terminal']['observations'][-1]
            assert row['event_a']==ea and row['event_b']==eb
            ca,cb=row['common_a'],row['common_b'];sa,sb=a['states'][-1],b['states'][-1]
            assert row['common_state_a']==sa and row['common_state_b']==sb
            va,vb=ea['evaluation'],eb['evaluation']
            for ob in (va,vb,ca,cb):observation(ob,n)
            assert ca['interface_modes']==a['operator']['modes'] and cb['interface_modes']==b['operator']['modes']
            for prefix,x,y in [('event',ea['state'],eb['state']),('common',sa,sb)]:
                for short,key in [('amount','amounts_mol'),('energy','internal_energy_j'),('stretch','mechanical_stretches')]:assert row[prefix+'_'+short+'_differences']==diffs(x[key],y[key])
            dt=abs(t(ea['time'])-t(eb['time']))+time_error(fa)+time_error(fb)
            thermal=lambda x,y:maximum(x['temperatures_k'],y['temperatures_k'])+max(x['temperature_errors_k'])+max(y['temperature_errors_k'])
            pressure=lambda x,y:maximum(x['pressures_pa'],y['pressures_pa'])+max(x['pressure_errors_pa'])+max(y['pressure_errors_pa'])
            temp=max(thermal(va,vb),thermal(ca,cb));independent=max(pressure(va,vb),pressure(ca,cb));assert row['independent_pressure_bound_pa']==independent
            if pc:
                assert len(row['paired'])==2
                event_p=paired(row['paired'][0],ea['state'],va,fa['terminal']['candidate_operator'],eb['state'],vb,fb['terminal']['candidate_operator'])
                common_p=paired(row['paired'][1],sa,ca,a['operator'],sb,cb,b['operator']);selected=max(event_p,common_p)
            else:assert not row['paired'];selected=independent
            values=[dt,max(maximum(ea['state']['amounts_mol'],eb['state']['amounts_mol']),maximum(sa['amounts_mol'],sb['amounts_mol'])),max(maximum(ea['state']['internal_energy_j'],eb['state']['internal_energy_j']),maximum(sa['internal_energy_j'],sb['internal_energy_j'])),temp,selected,max(maximum(ea['state']['mechanical_stretches'],eb['state']['mechanical_stretches']),maximum(sa['mechanical_stretches'],sb['mechanical_stretches']))]
            assert q(row['differences'][0])==values[0] and row['differences'][1:]==values[1:]
            maxima=[max(x,y) for x,y in zip(maxima,values)]
        passed=all(math.isfinite(v) and v<=g for v,g in zip(maxima,gates))
        assert ref['status']==('comparison_pass' if passed else 'comparison_fail')
        return maxima
    refs=r['refinements'];groups=[];group=[];results={}
    for index,ref in enumerate(refs):
        if ref['role']=='terminal' and ref['status']=='coarse_reference':
            if group:groups.append(group)
            group=[]
        group.append((index,ref))
        if ref['path'] is not None:path_checks(ref['path'])
        if ref['comparison']:
            previous=refs[index-1]
            assert previous['role']=='terminal' and previous['path'] is not None
            if ref['role']=='independent':
                assert q(ref['approach_cap_s'])*2==q(previous['approach_cap_s']) and q(ref['safe_fraction'])*2==q(previous['safe_fraction'])
                assert ref['terminal_cap_s']==previous['terminal_cap_s'] and ref['level']==previous['level']
                assert ref['path']['approach_grid']!=previous['path']['approach_grid']
            else:
                assert ref['level']==previous['level']+1 and q(ref['terminal_cap_s'])*2==q(previous['terminal_cap_s'])
                assert ref['approach_cap_s']==previous['approach_cap_s'] and ref['safe_fraction']==previous['safe_fraction']
            results[index]=comparison(ref,previous['path'],ref['path'])
    if group:groups.append(group)
    committed=0
    for packet in r['packets']:
        matches=[g for g in groups if len(g)>=4 and g[-1][1]['role']=='independent' and g[-1][1]['status']=='comparison_pass' and [x['terminal'] for x in g[-2][1]['path']['frames']]==[x['terminal'] for x in packet]]
        assert len(matches)==1;g=matches[0];fine_i,fine=g[-1];chosen_i,chosen=g[-2];prev_i,previous=g[-3];coarse=g[0][1]
        assert chosen['status']==previous['status']=='comparison_pass' and chosen['role']==previous['role']=='terminal'
        maximum_values=[max(a,b) for a,b in zip(results[chosen_i],results[fine_i])]
        for j,f in enumerate(packet):
            assert f['coarse_time']==coarse['path']['frames'][j]['terminal']['observations'][-1]['time']
            assert f['previous_time']==previous['path']['frames'][j]['terminal']['observations'][-1]['time'] and f['common_time']==chosen['common_time']
            assert q(f['packet_maximum_differences'][0])==maximum_values[0] and f['packet_maximum_differences'][1:]==maximum_values[1:]
            endpoint=f['terminal']['observations'][-1]['time'];idx=r['times_s'].index(endpoint)
            assert r['states'][idx]==f['terminal']['corrected_state'] and r['steps'][idx-1]==f['terminal']['terminal_panel']['ledger']
        committed+=1
    assert recorded_endpoint_calls<=r['costs']['endpoint_completed']<=r['costs']['endpoint_attempts']
    if r['status']=='completed':assert recorded_endpoint_calls==r['costs']['endpoint_completed']==r['costs']['endpoint_attempts']
    summary={'audit_status':'passed','core_status':r['status'],'completed_acceptance':r['status']=='completed','committed_packets_checked':committed,'comparison_records_checked':len(results),'pure_pressure_certificates_checked':pure_certificates,'saved_pressure_endpoint_calls':recorded_endpoint_calls,'scope':'comparison/frame/source-domain audit; no EOS, full prefix accounting separate','source_limit':'Certificate source-label hashes are checked by existing auditor internally; static physical domain, boxes, reference, backend, operator/base hashes are independently bound to initial canonical inputs. Omitted live thermal inverse trees are not reconstructed.','core_sha256':hashlib.sha256((D/'core-result.json').read_bytes()).hexdigest()}
    (P/'comparison-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
if __name__=='__main__':main()
