from dataclasses import replace
import pytest
from test_mass_transport_bridge import setup
from sludge_sandbox.mass_transport_bridge import MixedPair,integrate_pair

def test_asymmetric_geometry_reversal(monkeypatch):
 p,s=setup(monkeypatch)
 p=replace(p,face=replace(p.face,half_widths_m=(.03,.09)))
 a=p.evaluate(s)
 q=replace(p,cells=p.cells[::-1],face=replace(p.face,half_widths_m=p.face.half_widths_m[::-1],conductivities_w_m_k=p.face.conductivities_w_m_k[::-1]))
 b=q.evaluate(s[::-1])
 assert a.face_energy_w==pytest.approx(-b.face_energy_w,rel=1e-12)
 for k in a.exchange.net_mol_s:assert a.exchange.net_mol_s[k]==pytest.approx(-b.exchange.net_mol_s[k],rel=1e-12)

def test_failure_after_accepted_prefix(monkeypatch):
 p,s=setup(monkeypatch);reference=integrate_pair(p,s,duration_s=.005,steps=1)
 assert reference.status=='completed'
 original=MixedPair.evaluate;count=[0]
 def fail(self,states):
  count[0]+=1
  if count[0]==5:raise ValueError('deliberate_second_midpoint_failure')
  return original(self,states)
 monkeypatch.setattr(MixedPair,'evaluate',fail)
 r=integrate_pair(p,s,duration_s=.01,steps=2)
 assert r.status=='failed' and r.reason=='deliberate_second_midpoint_failure'
 assert r.states==reference.states and r.times_s==reference.times_s
 assert r.ledgers==reference.ledgers and r.observations==reference.observations
