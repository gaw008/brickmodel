"""Instrumented dispatch tests, not physical/EOS validation."""
from fractions import Fraction
from types import SimpleNamespace
import pytest
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.free_solid_slab import FreeSolidSlab
from sludge_sandbox.water_phase_transfer import WaterPhaseTransfer
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.integration import IntegrationError


def test_free_shared_body_and_original_time_validation(monkeypatch):
    host=object.__new__(FreeSolidSlab); calls=[]; state=object(); result=object()
    monkeypatch.setattr(FreeSolidSlab,'_check_state',lambda self,s:calls.append(('check',s)))
    monkeypatch.setattr(FreeSolidSlab,'_evaluate_current_state',lambda self,s:(calls.append(('body',s)) or result))
    assert host.evaluate(state,.5) is result
    assert host.evaluate_autonomous(state) is result
    assert calls==[('check',state),('body',state)]*2
    with pytest.raises(ValueError):host.evaluate(state,float('nan'))
    assert calls[-1]==('check',state)


def test_transfer_precheck_precedes_evaluation_and_shared_assembly(monkeypatch):
    host=object.__new__(FreeSolidSlab); op=object.__new__(WaterPhaseTransfer)
    object.__setattr__(op,'base_model',host); calls=[]; state=object(); base=object(); result=object()
    monkeypatch.setattr(WaterPhaseTransfer,'_check_interface_state',lambda self,s:calls.append('precheck'))
    monkeypatch.setattr(FreeSolidSlab,'evaluate_autonomous',lambda self,s:(calls.append('autonomous') or base))
    monkeypatch.setattr(FreeSolidSlab,'evaluate',lambda self,s,t:(calls.append(('legacy',t)) or base))
    monkeypatch.setattr(WaterPhaseTransfer,'_assemble_transfer',lambda self,s,b:(calls.append(('assembly',b)) or result))
    assert op.evaluate(state,.5) is result
    assert op.evaluate_autonomous(state) is result
    assert calls==['precheck',('legacy',.5),('assembly',base),'precheck','autonomous',('assembly',base)]
    def reject(self,s):raise IntegrationError('interface_rejected')
    monkeypatch.setattr(WaterPhaseTransfer,'_check_interface_state',reject)
    with pytest.raises(IntegrationError):op.evaluate_autonomous(state)
    assert len(calls)==6


def test_exact_view_no_float_projection_strict_admission_and_source_checks(monkeypatch):
    host=object.__new__(FreeSolidSlab); op=object.__new__(WaterPhaseTransfer)
    object.__setattr__(op,'base_model',host); checks=[]; calls=[]
    actual_autonomous=WaterPhaseTransfer.evaluate_autonomous
    binding=['original']
    monkeypatch.setattr(ExactFreeWaterTransfer,'_binding',lambda self:(checks.append('bind') or tuple(binding)))
    result=SimpleNamespace(rates=object())
    monkeypatch.setattr(WaterPhaseTransfer,'evaluate_autonomous',lambda self,s:(calls.append(s) or result))
    view=ExactFreeWaterTransfer(op); state=object()
    assert view(state,ExactEventTime(Fraction(10**400))) is result.rates
    assert calls==[state] and len(checks)==3
    for bad in (.5,True,Fraction(1)):
        with pytest.raises(IntegrationError):view(state,bad)
    assert len(calls)==1
    binding[0]='changed'
    with pytest.raises(IntegrationError):view(state,ExactEventTime(Fraction(1)))
    assert len(calls)==1
    with pytest.raises(IntegrationError):ExactFreeWaterTransfer(SimpleNamespace(base_model=host))
    object.__setattr__(op,'base_model',SimpleNamespace())
    with pytest.raises(IntegrationError):actual_autonomous(op,state)
