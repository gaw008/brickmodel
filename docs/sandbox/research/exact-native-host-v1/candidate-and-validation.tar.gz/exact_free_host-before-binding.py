"""Explicit exact-time adapter for the reviewed autonomous free-slab transfer."""
from dataclasses import dataclass, field
from .exact_event_clock import ExactEventTime
from .free_solid_slab import FreeSolidSlab
from .water_phase_transfer import WaterPhaseTransfer, WaterTransferEvaluation
from .integration import ConservedState, IntegrationError, Rates
from .deforming_solid_storage import _digest, DeformingStorageError

SCHEMA = 'exact_autonomous_free_slab_transfer_v1'


@dataclass(frozen=True)
class ExactFreeWaterTransfer:
    operator: WaterPhaseTransfer
    _identity: tuple = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if type(self.operator) is not WaterPhaseTransfer or type(self.operator.base_model) is not FreeSolidSlab:
            raise IntegrationError('explicit_direct_free_slab_transfer_required')
        object.__setattr__(self, '_identity', self._binding())

    def _binding(self) -> tuple:
        try:
            self.operator.chemical._check_identity()
            implementation = self.operator.chemical.water.implementation
            return (SCHEMA, _digest(self.operator),
                    None if implementation is None else implementation.sha256)
        except (ValueError, TypeError, AttributeError, OverflowError) as exc:
            raise IntegrationError('exact_autonomous_source_binding_invalid') from exc

    @property
    def operator_identity(self) -> tuple:
        if self._binding() != self._identity:
            raise IntegrationError('exact_autonomous_source_binding_changed')
        return self._identity

    @property
    def energy_model_identity(self) -> tuple:
        self.operator_identity
        return self.operator.base_model.energy_model_identity

    def evaluate(self, state: ConservedState, time: ExactEventTime) -> WaterTransferEvaluation:
        if type(time) is not ExactEventTime:
            raise IntegrationError('exact_event_time_required')
        self.operator_identity
        result = self.operator.evaluate_autonomous(state)
        self.operator_identity
        return result

    def __call__(self, state: ConservedState, time: ExactEventTime) -> Rates:
        return self.evaluate(state, time).rates

    def breakpoints(self, start: ExactEventTime, end: ExactEventTime) -> tuple:
        if type(start) is not ExactEventTime or type(end) is not ExactEventTime or end <= start:
            raise IntegrationError('ordered_exact_time_interval_required')
        self.operator_identity
        return ()

    def with_depleted_cells(self, state: ConservedState, cell_indices: tuple[int, ...]) -> 'ExactFreeWaterTransfer':
        self.operator_identity
        return ExactFreeWaterTransfer(self.operator.with_depleted_cells(state, cell_indices))
