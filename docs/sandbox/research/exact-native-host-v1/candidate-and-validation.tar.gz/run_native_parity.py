"""Two actual direct-host evaluations; no event integration or material admission."""
from pathlib import Path
from fractions import Fraction
from dataclasses import is_dataclass,fields
from collections.abc import Mapping
from sludge_sandbox.water_properties import is_water_provider
from sludge_sandbox.deforming_solid_storage import _canonical
import hashlib,json,time,traceback
from sludge_sandbox.verification_case import read_case,build_case,encode
from sludge_sandbox.run_service import runtime_identity
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer

root=Path(__file__).parent
out=root/'native-attempt02'
out.mkdir(exist_ok=False)
prior=Path('/private/tmp/brick-four-cell-ordered-failure-evidence-v1/attempt01')
case_bytes=(prior/'case.json').read_bytes()
water=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')
def save(name,value):
    (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def capture(value):
    # Preserve all numerical dataclass fields. Source providers have explicit
    # scientific descriptors, never repr/native cache serialization.
    if is_water_provider(value):
        return {'provider_type':[type(value).__module__,type(value).__qualname__],
          'source':_canonical(value),'implementation':_canonical(value.implementation)}
    if is_dataclass(value):
        return {f.name:capture(getattr(value,f.name)) for f in fields(value)}
    if isinstance(value,Mapping):
        return {str(k):capture(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):
        return [capture(v) for v in value]
    return encode(value)
before=runtime_identity();save('runtime-before.json',before)
(out/'case.json').write_bytes(case_bytes)
started=time.monotonic()
report={'status':'started','qualification':'Actual water direct-host point parity only; manufactured solid. No event, full trajectory or material validation.'}
try:
    built=build_case(read_case(out/'case.json'),water)
    initial=encode(built.initial)
    assert initial==json.loads((prior/'initial.json').read_text())
    save('initial.json',initial)
    adapter=ExactFreeWaterTransfer(built.operator)
    identity=adapter.operator_identity
    legacy=built.operator.evaluate(built.initial,built.start_s)
    assert identity==adapter.operator_identity
    save('legacy.json',capture(legacy))
    t=ExactEventTime(Fraction(10**12)+Fraction(1,10**10))
    assert t.display().seconds_binary64==1e12
    exact=adapter.evaluate(built.initial,t)
    save('exact.json',capture(exact))
    assert capture(legacy)==capture(exact)
    assert identity==adapter.operator_identity
    assert initial==encode(built.initial)
    report.update(status='passed',operator_identity=encode(identity),exact_time=t.to_record())
except BaseException:
    report.update(status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-after.json',after)
        assert before==after
        assert case_bytes==(prior/'case.json').read_bytes()==(out/'case.json').read_bytes()
    except BaseException:
        report.update(status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_seconds=time.monotonic()-started,runtime_module_count=len(before['modules']),
      case_sha256=hashlib.sha256(case_bytes).hexdigest(),
      runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    save('report.json',report)
assert report['status']=='passed',report
