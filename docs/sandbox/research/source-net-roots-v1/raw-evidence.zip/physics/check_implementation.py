"""Compare production pure roots with independently factorized Fraction truths."""
from pathlib import Path
from fractions import Fraction as F
from dataclasses import replace
import json,hashlib,time
from sludge_sandbox.mass_wet_exact_stage import InventoryPolynomial as P
from sludge_sandbox.source_net_roots import isolate_first_root,refine_first_root,same_first_root,order_inventory_roots,QuadraticRoot,QuadraticNoRoot
from sludge_sandbox.rational_polynomial import refine_descending_bracket,polynomial_gcd
OUT=Path(__file__).parent;ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github');paths=['src/sludge_sandbox/source_net_roots.py','src/sludge_sandbox/rational_polynomial.py']
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
start=time.monotonic();before=hashes();checks={}
def check(k,v):checks[k]=bool(v);assert v,k
def reject(k,func):
 try:func()
 except ValueError:checks[k]=True
 else:raise AssertionError(k)
cases=json.loads((OUT/'EXACT_CASES.json').read_text());roots=[]
for i,row in enumerate(cases):
 p=P('liquid',i,0,*[F(row[x]) for x in ('n','r','q')]);H=F(row['h']);r=isolate_first_root(p,H)
 if row['first_root'] is None:
  check(f'{i}_excluded',type(r) is QuadraticNoRoot and r.minimum==F(row['minimum']) and r.minimum_time==F(row['minimum_time']));r.check()
  reject(f'{i}_forged_min',lambda:replace(r,minimum=r.minimum+1))
 else:
  expected=F(row['first_root']);check(f'{i}_first_branch',type(r) is QuadraticRoot and r.branch_lower<=expected<=r.branch_upper)
  if row['tangent']:check(f'{i}_tangent_priority',r.root_kind=='exact_tangent' and r.lower==r.upper==expected)
  for j in range(8):
   check(f'{i}_enclosure{j}',r.lower<=expected<=r.upper);r=refine_first_root(r)
  r.check();roots.append(r)
  reject(f'{i}_forged_branch',lambda:replace(r,branch_upper=r.branch_upper+1))
  reject(f'{i}_forged_enclosure',lambda:replace(r,lower=r.lower-F(1,7)))
  reject(f'{i}_bool_refinements',lambda:replace(r,refinements=True))
# Known common later root, opposite to first-root equality.
a=P('liquid',0,0,F(3,16),F(-1),F(1));b=P('liquid',1,0,F(3,8),F(-5,4),F(1))
check('common_later_not_first',not same_first_root(isolate_first_root(a,F(1)),isolate_first_root(b,F(1))))
o=order_inventory_roots((a,b),F(1));check('common_later_correct_order',o.status=='ordered' and o.earliest_labels==( ('liquid',0,0),));o.check()
# A tied pair may share a later earliest group while another gas is earlier.
p1=P('liquid',1,0,F(1),F(-2),F());p2=P('liquid',2,0,F(2),F(-4),F());gas=P('gas',0,1,F(1),F(-4),F())
o=order_inventory_roots((p1,p2,gas),F(1));check('gas_before_later_tie',o.status=='ordered' and o.earliest_labels==( ('gas',0,1),));o.check()
o=order_inventory_roots((p1,p2),F(1));check('earliest_tie',o.status=='tied' and set(o.earliest_labels)=={('liquid',1,0),('liquid',2,0)});o.check()
for p in (P('gas',0,1,F(),F(),F()),P('gas',0,1,F(),F(-1),F()),P('gas',0,1,F(),F(1),F(-1))):
 o=order_inventory_roots((p,p1),F(1));check('zero_'+str(p.linear),o.status=='unsupported_zero_initial' and not o.complete and o.zero_initial_labels==( ('gas',0,1),));o.check()
 reject('zero_isolate_'+str(p.linear),lambda:isolate_first_root(p,F(1)))
x=P('gas',0,1,F(1),F(),F(-2));y=P('gas',1,1,F(1)+F(1,2**80),F(),F(-2))
o=order_inventory_roots((x,y),F(1),maximum_refinements=1);check('unresolved_honest',o.status=='unresolved' and not o.complete and o.earliest_labels==());o.check()
for field,value in [('complete',True),('status','ordered'),('earliest_labels',(('gas',0,1),)),('qualification','physical_event')]:
 forged=replace(o,**{field:value});reject('forged_order_'+field,forged.check)
reject('float_coeff',lambda:isolate_first_root(replace(p1,linear=-2.),F(1)))
reject('zero_H',lambda:isolate_first_root(p1,F()))
reject('energy_not_competitor',lambda:isolate_first_root(replace(p1,family='energy'),F(1)))
check('legacy_mid_zero_keep_lower',refine_descending_bracket((F(1),F(-2)),F(),F(1))==(F(1,2),F(1)))
check('legacy_upper_zero_keep_endpoint',refine_descending_bracket((F(1),F(-1)),F(),F(1))==(F(1,2),F(1)))
gcd=polynomial_gcd((F(3,16),F(-1),F(1)),(F(3,8),F(-5,4),F(1)))
check('gcd_later_root',len(gcd)==2 and -gcd[0]/gcd[1]==F(3,4))
check('unchanged_during_audit',before==hashes())
result={'passed':True,'case_count':len(cases),'checks_passed':len(checks),'checks':checks,'hashes':before,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'elapsed_s':time.monotonic()-start,'scope':'Production pure root code compared to independent exact factored roots/minima. No EOS or physical event/writeback/material admission.'};(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
