# Independent arithmetic audit scope

117 factorized exact rational polynomial/domain cases are frozen before source implementation comparison. Expected first roots are known from factors; minima are checked directly at endpoints and any interior convex vertex. The oracle does not use tested root isolation/minimum/GCD code to generate those expectations.

Once source files exist, verify new records/enclosures against the independently known first root, no-root minimum evidence and tangent precedence; all branch enclosures must contain the earliest positive root, not a common later root. Add independent direct examples for earliest-group competition, exact ties, a convex shared-later-root pair, zero-initial completeness and forged evidence verification. Preserve every failure before fixes and re-review only changed code.

Legacy shared helper extraction must preserve arithmetic operation order, p(mid)>=0 lower update, original evidence-construction positions, exception behavior and refinement counts; the new pure layer must not alter evaporation budgets. No EOS/native/trajectory/event-writeback admission. Production code/tests are read-only to this reviewer.
