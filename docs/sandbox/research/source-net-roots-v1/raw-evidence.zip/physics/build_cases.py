"""Independent exact-factor truth cases; no sandbox production imports."""
from fractions import Fraction as F
from pathlib import Path
import json
OUT=Path(__file__).parent
cases=[]
def put(name,n,r,q,h,roots):
 roots=sorted(set(t for t in roots if 0<t<=h))
 times=[F(),h]
 if q>0 and 0<-r/(2*q)<h:times.append(-r/(2*q))
 p=lambda t:n+r*t+q*t*t
 assert n>0 and h>0 and all(p(t)==0 for t in roots)
 mn,at=min((p(t),t) for t in times)
 assert (mn<=0)==bool(roots)
 cases.append(dict(name=name,n=str(n),r=str(r),q=str(q),h=str(h),first_root=str(roots[0]) if roots else None,tangent=bool(roots and q>0 and r*r==4*q*n),minimum=str(mn),minimum_time=str(at)))
for a in (F(1,4),F(1,2),F(1),F(3,2)):
 for b in (a,a+F(1,4),a+F(1),a+F(2)):
  for tag,h in [('before',a/2),('first',a),('between',(a+b)/2),('second',b),('after',b+1)]:
   put(f'convex_{a}_{b}_{tag}',a*b,-a-b,F(1),h,[a,b])
for a in (F(1,4),F(1),F(2)):
 for b in (F(-1,4),F(-1),F(-3)):
  for tag,h in [('before',a/2),('endpoint',a),('after',a+1)]:
   put(f'concave_{a}_{b}_{tag}',-a*b,a+b,F(-1),h,[a])
for a in (F(1,3),F(1,2),F(3)):
 for h in (a/2,a,2*a):put(f'linear_{a}_{h}',F(1),-1/a,F(),h,[a])
put('strict_positive',F(1),F(-1),F(1),F(2),[])
(OUT/'EXACT_CASES.json').write_text(json.dumps(cases,indent=2)+'\n');print(f'{len(cases)} independent factored polynomial/domain cases checked with exact Fraction substitution and minima.')
