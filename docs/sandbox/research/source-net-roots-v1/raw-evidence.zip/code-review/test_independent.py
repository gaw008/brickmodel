from fractions import Fraction as F
from itertools import product
from dataclasses import replace
import pytest
from sludge_sandbox.mass_wet_exact_stage import InventoryPolynomial as P
from sludge_sandbox.source_net_roots import isolate_first_root,QuadraticNoRoot,refine_first_root,order_inventory_roots

def test_factored_rational_quadratic_first_root_grid():
 roots=[F(n,4) for n in range(-6,9) if n]
 for a,b,h in product(roots,roots,(F(1,2),F(1),F(2))):
  q=F(1) if a*b>0 else F(-1)
  p=P('liquid',0,0,q*a*b,-q*(a+b),q)
  wanted=min((x for x in (a,b) if 0<x<=h),default=None)
  out=isolate_first_root(p,h)
  if wanted is None:assert type(out) is QuadraticNoRoot
  else:
   for _ in range(3):out=refine_first_root(out)
   assert out.lower<=wanted<=out.upper
   assert out.branch_lower<=wanted<=out.branch_upper

def test_opposite_curvature_same_first_root_and_later_tie():
 # positive starts, common first .5; one concave with earlier negative root.
 a=P('liquid',0,0,F(1),F(-5,2),F(1))
 b=P('gas',0,1,F(1,2),F(-1,2),F(-1))
 c=P('gas',0,2,F(3,8),F(-5,4),F(1))
 result=order_inventory_roots((a,b,c),F(2))
 assert result.status=='tied' and len(result.earliest_labels)==3
 result.check()

def test_zero_only_never_complete_and_forged_qualification():
 zero=P('gas',0,1,F(),F(),F())
 r=order_inventory_roots((zero,),F(1))
 assert not r.complete and not r.roots and not r.exclusions
 with pytest.raises(ValueError):replace(r,qualification='physical_event_accepted').check()
