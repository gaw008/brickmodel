"""Independent Python boundary probes; no EOS or source dynamics calls."""
from dataclasses import replace
from fractions import Fraction as F
import pytest

from sludge_sandbox.mass_wet_exact_stage import InventoryPolynomial as P
from sludge_sandbox.source_net_roots import (
    SourceNetRootError, isolate_first_root, order_inventory_roots,
    order_source_panel_roots, refine_first_root, same_first_root,
)


def p(n=1, r=-3, q=1, cell=0):
    return P('liquid', cell, 0, F(n), F(r), F(q))


@pytest.mark.parametrize('field,value', [
    ('duration', 1), ('root_kind', 'exact_crossing'),
    ('branch_lower', False), ('branch_upper', 1.),
    ('lower', F(1, 4)), ('upper', F(1, 4)), ('refinements', True),
])
def test_mutated_root_revalidated_before_refinement_and_gcd(field, value):
    good = isolate_first_root(p(), F(1))
    bad = replace(good)
    object.__setattr__(bad, field, value)
    with pytest.raises(SourceNetRootError):
        refine_first_root(bad)
    with pytest.raises(SourceNetRootError):
        same_first_root(good, bad)


@pytest.mark.parametrize('field,value', [
    ('family', 'energy'), ('cell', True), ('index', False),
    ('initial', 1.), ('linear', -3), ('quadratic', True),
])
def test_mutated_nested_polynomial_does_not_pass_record_check(field, value):
    root = isolate_first_root(p(), F(1))
    object.__setattr__(root.polynomial, field, value)
    with pytest.raises(SourceNetRootError):
        root.check()


@pytest.mark.parametrize('field,value', [
    ('qualification', 'physical_event_permission'), ('status', 'no_roots'),
    ('complete', 1), ('refinement_level', False), ('earliest_labels', ()),
    ('roots', ()), ('exclusions', (object(),)), ('polynomials', []),
    ('maximum_refinements', True), ('zero_initial_labels', (('gas', 0, 1),)),
])
def test_mutated_root_order_is_not_a_valid_evidence_record(field, value):
    out = order_inventory_roots((p(),), F(1))
    object.__setattr__(out, field, value)
    with pytest.raises(SourceNetRootError):
        out.check()


def test_shared_later_root_is_not_first_even_with_large_domains():
    # Both quadratics share the later root at 3/4, never the first root.
    left = isolate_first_root(p(F(3, 16), -1, 1), F(100))
    right = isolate_first_root(p(F(3, 8), F(-5, 4), 1, cell=1), F(100))
    for _ in range(9):
        assert not same_first_root(left, right)
        left, right = refine_first_root(left), refine_first_root(right)


def test_same_first_root_works_with_different_domains_and_refinement_counts():
    left = isolate_first_root(p(), F(1))
    right = isolate_first_root(p(2, -6, 2, cell=1), F(2))
    for _ in range(11):
        assert same_first_root(left, right)
        left = refine_first_root(left)


@pytest.mark.parametrize('field,value', [
    ('qualification', 'event_or_writeback_permission'),
    ('operator_identity', ()), ('sample_bindings', ()),
])
def test_source_order_snapshot_identity_rejects_mutations(field, value):
    from test_source_net_panel import panel, sample
    saved = panel(sample(F(), liquid=.25), sample(F(1, 2), liquid=.25, role='interior'))
    out = order_source_panel_roots(saved)
    object.__setattr__(out, field, value)
    with pytest.raises(SourceNetRootError):
        out.check()


def test_source_order_rechecks_mutated_numpy_rate_arrays():
    from test_source_net_panel import panel, sample
    saved = panel(sample(F(), liquid=.25), sample(F(1, 2), liquid=.25, role='interior'))
    out = order_source_panel_roots(saved)
    array = saved.first.evaluation.rates.face_species_mol_s
    array.setflags(write=True)
    array[1, 0] += 1.
    with pytest.raises(ValueError):
        out.check()
