"""Bounded actual manufactured-source probe; no native EOS and no synthetic captures."""
from dataclasses import fields
from fractions import Fraction as F
from pathlib import Path
import hashlib,importlib.util,json,sys,time
repo=Path('/Users/wanggaoying/Desktop/brickmodel-github')
sys.path[:0]=[str(repo/'src'),str(repo/'tests/sandbox')]
import pytest
from test_source_approach import actual as fixture
from sludge_sandbox._heos_kernel import HEOSCandidate
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.integration import IntegrationError
from sludge_sandbox.exact_integration import _duration_control
from sludge_sandbox.source_approach import propose_source_approach,evaluate_source_approach
from sludge_sandbox.source_prefix_trial import evaluate_source_prefix_trial
from sludge_sandbox.source_net_panel import SavedSourceSample
from sludge_sandbox.source_endpoint_comparison import measure_source_endpoint_pair,_policy_binding
from sludge_sandbox.source_inverse_pressure import enclose_source_inverse_pressure
from sludge_sandbox.source_net_prefix import _same

location=repo/'docs/sandbox/research/exact-source-column-v1/run_native.py'
assert hashlib.sha256(location.read_bytes()).hexdigest()=='b0b873960bdc8bc9f2299fc3d0d008fd5fa5a9d3f7a972eb0f080ec3a2d39ab5'
spec=importlib.util.spec_from_file_location('frozen_passive_serializer',location)
serializer=importlib.util.module_from_spec(spec);spec.loader.exec_module(serializer)
encode=serializer.serialize
folder=Path('/private/tmp/brick-source-root-comparison-v1/code-review')
output=folder/'actual-common01.json'
begin=time.monotonic();phase='fixture_probe_and_seed';calls=[]
result={'status':'started','scope':'actual_source_adapter_existing_manufactured_liquid_fixture_not_native_or_material_evidence','soft_seconds':30,'total_source_callback_cap':48,'native_eos_calls':0,'captures':calls}
def save():
    result['wall_seconds']=time.monotonic()-begin
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
def guard():
    if time.monotonic()-begin>=30:raise IntegrationError('probe_30s_soft_limit')
def record(value,omit=()):
    return {f.name:encode(getattr(value,f.name)) for f in fields(value) if f.name not in omit}
def trial_record(value):return record(value,('adapter',))
def forbid_native(*args,**kwargs):raise AssertionError('probe_native_constructor_forbidden')
actual=ExactSourceColumn.evaluate

def observed(self,state,when):
    guard()
    if len(calls)>=48:raise IntegrationError('probe_48_source_callback_limit')
    item={'ordinal':len(calls)+1,'phase':phase,'state':encode(state),'time':encode(when)}
    calls.append(item)
    try:
        evaluation=actual(self,state,when)
        item['evaluation']=encode(evaluation)
        guard()
        return evaluation
    except Exception as exc:
        item.update(exception_type=type(exc).__name__,exception=str(exc))
        raise

def perform(adapter,state,start,end,policy,role):
    global phase
    guard();phase=role
    trial=evaluate_source_prefix_trial(adapter,state,start=start,end=end,integration_policy=policy,maximum_callbacks=16,cancel=lambda:time.monotonic()-begin>=30)
    result[role]=trial_record(trial);save();guard();trial.check()
    return trial

with pytest.MonkeyPatch.context() as mp:
    mp.setattr(HEOSCandidate,'__init__',forbid_native)
    mp.setattr(ExactSourceColumn,'evaluate',observed)
    generator=fixture.__wrapped__()
    try:
        seed,event=next(generator)
        guard();assert len(calls)==3
        calls[0]['phase']='initial_phase_probe'
        for c in calls[1:]:c['phase']='coarse_seed'
        result.update(coarse_seed=trial_record(seed),integration_policy=encode(seed.policy),event_policy=encode(event),event_policy_binding=_policy_binding(event))
        proposal=propose_source_approach(seed,event_policy=event)
        result['coarse_proposal']=record(proposal,('original_trial',));phase='approach'
        approach=evaluate_source_approach(proposal,maximum_callbacks=16,cancel=lambda:time.monotonic()-begin>=30)
        assert approach.status=='validated_positive_numerical_approach',approach.reason
        result['approach_trial']=trial_record(approach.trial);save();guard()
        source=seed.adapter;at=approach.trial.reference.times_s[-1];state=approach.trial.reference.states[-1]
        assert _same(state,approach.trial.captures[-1].state)
        shifted=perform(source,state,at,seed.end,seed.policy,'shifted_seed')
        assert shifted.reason=='source_prefix_negative_inventory_minimum' and shifted.prefix is None
        assert len(shifted.captures)==2 and all(c.binding is not None and c.failure is None for c in shifted.captures)
        refined=propose_source_approach(shifted,event_policy=event)
        assert refined.status=='positive_numerical_proposal'
        result['shifted_proposal']=record(refined,('original_trial',));save()
        assert proposal.roots.order.earliest_labels==refined.roots.order.earliest_labels==( ('liquid',0,0), )
        left=seed.start.shifted(proposal.choice.selected_root.lower)
        right=at.shifted(refined.choice.selected_root.lower)
        room=min(left,right).elapsed_since(at)
        assert room>0
        desired=F(event.safe_inventory_fraction)*room
        duration=_duration_control(desired)
        common=at.shifted(duration)
        assert F(seed.policy.minimum_step_s)<=duration<=F(seed.policy.maximum_step_s)
        assert F(seed.policy.minimum_step_s)<=common.elapsed_since(seed.start)<=F(seed.policy.maximum_step_s)
        assert at<common<min(left,right) and common<=seed.end
        assert not source.breakpoints(seed.start,common) and not source.breakpoints(at,common)
        result['common_controls']={'coarse_root_lower_absolute':encode(left),'fine_root_lower_absolute':encode(right),'shifted_start':encode(at),'room_s':encode(room),'desired_fine_duration_s':encode(desired),'fine_duration_s':encode(duration),'common_end':encode(common)}
        coarse=perform(source,seed.initial,seed.start,common,seed.policy,'coarse_common')
        fine=perform(source,state,at,common,seed.policy,'fine_common')
        assert coarse.status==fine.status=='validated_positive_numerical_trial'
        ends=tuple(t.captures[-1] for t in (coarse,fine))
        assert all(c.time==common for c in ends)
        samples=tuple(SavedSourceSample(c.state,c.evaluation,c.role) for c in ends)
        comparison=measure_source_endpoint_pair(*samples,operator_identity=seed.operator_identity,energy_identity=seed.energy_identity,fixed_dry_mass_kg=seed.fixed_dry_mass_kg)
        comparison.check()
        bounds=tuple(enclose_source_inverse_pressure(source.column.storages[0],c.evaluation.source_states[0],c.evaluation.source_evaluation.cells[0].inverse) for c in ends)
        assert all(b.continuation.status=='conditional_pressure_enclosure' for b in bounds)
        pb=abs(F(bounds[0].inverse.point.pressure_pa)-F(bounds[1].inverse.point.pressure_pa))+sum((b.continuation.radius_pa for b in bounds),F())
        limits=tuple(map(F,(event.amount_absolute_mol,event.energy_absolute_j,event.temperature_absolute_k,event.pressure_absolute_pa)))
        gates=tuple(x<=limit for x,limit in zip(comparison.maxima,limits))
        result.update(endpoint_differences=encode(comparison),pressure_endpoints=[record(b,('storage',)) for b in bounds],conditional_pressure_bound=encode(pb),conditional_pressure_gate=pb<=limits[3],gates=list(gates),event_admitted=False,material_qualified=False)
        # Read-only aggregate of the actual accepted fine-reference ledgers,
        # never an execution/controller or a substituted prefix ledger.
        joined=(approach.trial.reference,fine.reference);origin=seed.initial
        ntotal=[F() for _ in origin.amounts_mol.flat];utotal=[F() for _ in origin.internal_energy_j]
        residuals=[];previous_time=seed.start;previous_state=origin
        for run in joined:
            assert run.times_s[0]==previous_time and _same(run.states[0],previous_state)
            for idx,ledger in enumerate(run.steps):
                assert ledger.start_s==previous_time
                n=origin.amounts_mol.shape[0]
                for i in range(n):
                    for j in range(4):ntotal[i*4+j]+=F(float(ledger.face_species_mol[i,j]))-F(float(ledger.face_species_mol[i+1,j]))+F(float(ledger.reaction_species_mol[i,j]))
                    utotal[i]+=F(float(ledger.face_energy_j[i]))-F(float(ledger.face_energy_j[i+1]))+F(float(ledger.cell_work_j[i]))
                after=run.states[idx+1]
                nr=tuple(F(float(x))-F(float(a))-v for x,a,v in zip(after.amounts_mol.flat,origin.amounts_mol.flat,ntotal))
                ur=tuple(F(float(x))-F(float(a))-v for x,a,v in zip(after.internal_energy_j,origin.internal_energy_j,utotal))
                assert all(abs(x)<=F(seed.policy.amount_absolute_tolerance_mol) for x in nr)
                assert all(abs(x)<=F(seed.policy.energy_absolute_tolerance_j) for x in ur)
                residuals.append({'end':encode(ledger.end_s),'N_residuals':encode(nr),'U_residuals':encode(ur)})
                previous_time=ledger.end_s;previous_state=after
        result['fine_joined_reference_residuals']=residuals
        assert previous_time==common and _same(previous_state,fine.reference.states[-1])
        guard();result.update(status='completed',total_source_callbacks=len(calls),callback_phases={name:sum(c['phase']==name for c in calls) for name in sorted({c['phase'] for c in calls})})
        result['display']={'H_s':float(seed.end.elapsed_since(seed.start)),'shifted_start_s':float(at.elapsed_since(seed.start)),'common_end_s':float(common.elapsed_since(seed.start)),'fine_duration_s':float(duration),'coarse_root_lower_s':float(left.elapsed_since(seed.start)),'fine_root_lower_s':float(right.elapsed_since(seed.start)),'N_U_T_P_maxima':list(map(float,comparison.maxima)),'conditional_pressure_bound_pa':float(pb),'coarse_terminal_liquid':float(ends[0].state.amounts_mol[0,0]),'fine_terminal_liquid':float(ends[1].state.amounts_mol[0,0]),'coarse_D':coarse.discrepancy,'fine_D':fine.discrepancy,'fine_joined_accepted_steps':len(residuals)}
        save();print(json.dumps({k:result[k] for k in ('status','wall_seconds','total_source_callbacks','callback_phases','display','gates','conditional_pressure_gate')},indent=2))
    except Exception as exc:
        result.update(status='failed',exception_type=type(exc).__name__,exception=str(exc));save();raise
    finally:generator.close()
