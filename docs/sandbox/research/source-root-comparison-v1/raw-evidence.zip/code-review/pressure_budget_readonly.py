"""Standard-library decomposition of two completed immutable saved comparisons."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,time
folder=Path('/private/tmp/brick-source-root-comparison-v1/code-review')
inputs=[(Path('/private/tmp/brick-source-approach-v1/root/native-result.json'),'6f6c32330f9bd3159186705345fbe35bce0729e592f006611c9707082f068ca2','approach'),(folder.parent/'root/native-result.json','6aa52124fec977dfb39c65cac64538c87918fc8ed3cff82d3b3a5d5cd0474ae8','common')]
def f(x):return F(x['numerator'],x['denominator']) if isinstance(x,dict) else F(x)
def enc(x):
 if isinstance(x,F):return {'numerator':x.numerator,'denominator':x.denominator,'display':float(x)}
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [enc(v) for v in x]
 return x
start=time.monotonic();rows=[]
for path,sha,role in inputs:
 data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==sha
 d=json.loads(data);assert d['status']=='completed'
 pairs=d['pressure']['endpoint_bounds'] if role=='approach' else d['common_pressure_pairs']
 for i,pair in enumerate(pairs):
  points=[b['inverse']['fields']['point']['fields'] for b in pair]
  fluids=[p['fluid']['fields'] for p in points]
  mechanics=[p['mechanical']['fields'] for p in fluids]
  cont=[b['continuation']['fields'] for b in pair]
  inverses=[b['inverse']['fields'] for b in pair]
  nominal=abs(f(mechanics[0]['pressure_pa'])-f(mechanics[1]['pressure_pa']))
  fluid=sum((f(p['pressure_error_bound_pa']) for p in fluids),F())
  extra=sum((f(p['extra_pressure_error_pa']) for p in points),F())
  at_report=sum((f(p['pressure_error_pa']) for p in points),F())
  temp=sum((f(c['slope_pa_k'])*f(v['temperature_error_bound_k']) for c,v in zip(cont,inverses)),F())
  conditional=nominal+sum((f(c['radius_pa']) for c in cont),F())
  assert conditional==nominal+at_report+temp
  rows.append(dict(role=role,input_path=str(path),sha256=sha,cell=i,nominal_pressure_difference=nominal,
       reported_pressure_bound=nominal+at_report,conditional_pressure_bound=conditional,
       fluid_pressure_radii_sum=fluid,additional_available_volume_radii_sum=extra,
       outward_aggregate_rounding=at_report-fluid-extra,inverse_temperature_contribution=temp,
       pressure_gate=F(1,10000),inverse_temperature_errors=[f(v['temperature_error_bound_k']) for v in inverses],
       local_pressure_slopes=[f(c['slope_pa_k']) for c in cont],
       volume_errors=[f(p['available_volume_error_m3']) for p in points],
       available_volumes=[f(p['available_pore_volume_m3']) for p in points],
       temperature_budget_after_nominal_reported=F(1,10000)-nominal-at_report,
       volume_fraction_of_bound=extra/conditional,temperature_fraction_of_bound=temp/conditional))
result=dict(scope='read_only_saved_scalar_decomposition_no_models_or_EOS',rows=rows,elapsed_seconds=time.monotonic()-start)
(folder/'pressure-budget-readonly.json').write_text(json.dumps(enc(result),indent=2)+'\n')
for row in rows:
 print(json.dumps({k:(float(v) if isinstance(v,F) else v) for k,v in row.items() if k in ('role','nominal_pressure_difference','reported_pressure_bound','conditional_pressure_bound','fluid_pressure_radii_sum','additional_available_volume_radii_sum','inverse_temperature_contribution','temperature_budget_after_nominal_reported','volume_fraction_of_bound','temperature_fraction_of_bound')}))
