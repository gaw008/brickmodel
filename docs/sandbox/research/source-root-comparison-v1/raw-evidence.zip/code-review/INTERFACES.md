# Actual source root comparison: minimal reuse review

Baseline `b7466e3`, initially clean. Production was read-only. No native EOS, new manufactured trajectory or tests were run for this interface investigation. `INTERFACE_INPUTS.json` pins the files read. The existing fixtures below are suitable candidates, not a claim that the new refinement sequence has already passed.

## Existing comparison boundaries

`exact_depletion_integration.py:252` defines `compare` as an inner closure of the mechanical ordered-packet driver. It depends on ExactFreeWaterTransfer, mechanical stretches, terminal frames, packet event order, nested policies and fresh mechanical observations. Its input guard explicitly excludes an ExactSourceColumn. Reuse its principles—same event labels/modes, actual same-time observations, separate time/N/U/T/P tests—not its controller or mechanical record types.

`SourcePrefixTrial.check()` already passively verifies successful reference integration by replaying retained rates and DomainExit recovery, with no EOS. Successful `SourceApproachResult.check()` also binds the seed, new interval, policy, actual callback count, endpoint comparison and conditional pressure. The saved reference endpoint is the actual accepted numeric path endpoint. Its prefix endpoint is a separate numerical construction and must not silently replace it when the declared refined path starts from the reference.

`measure_source_endpoint_pair` already accepts two actual SavedSourceSample records from separate evaluations and requires exact equal time plus source/energy/fixed-mass consistency. It computes exact N/U differences and reported-T/P differences plus original inverse errors. In contrast, `compare_source_trial_endpoints` and SourceEndpointComparison are expressly one-trial prefix-versus-reference records; fabricating one around cross-path samples would violate their check contract.

Likewise, `enclose_source_inverse_pressure(storage,state,inverse)` is directly reusable for each cross-path endpoint. `propagate_source_trial_pressure` is bound to SourceEndpointComparison and selects that trial's captures itself. Extract a small shared exact gate/paired-pressure aggregation helper if desired; do not invent a trial or duplicate the physical pressure-continuation derivation to fit the old wrapper.

## Smallest useful new structures

1. A source root-refinement record retaining the original seed, the successful SourceApproachResult, one fresh fine seed, both SourcePanelRootOrders, the original full event-policy binding, absolute first-root intervals, matching labels and a numerical time-difference bound. Its checker revalidates all three original records and reconstructs derived data without new physics.
2. A cross-path common-endpoint record retaining actual coarse and fine successful continuation trials, their reference endpoint captures, the shared exact endpoint, original policies, SourceEndpointDifferences, per-endpoint SourceInversePressure records and separate gate results. Its checker binds the refined path's start to the accepted approach reference endpoint and measures the actual cross-path samples rather than the within-trial pair.
3. A bounded executor making only the necessary original `evaluate_source_prefix_trial` calls, with declared per-call/total resources and retained partial results. Reuse the existing chained assessment-error pattern so a later comparison or pressure failure does not discard expensive completed trials. A caller-declared common endpoint avoids introducing another adaptive depletion controller.

## Actual evaluation sequence and binding

- Require a checked successful approach and bind `approach.proposal.original_trial` to the requested coarse seed. Retain the original coarse full-prefix failure and its real first/midpoint samples.
- Set fine initial state exactly to `approach.trial.reference.states[-1]` and fine start to `approach.trial.reference.times_s[-1]`. Require its final reference capture to carry the same state/time. Keep the same actual adapter, source/energy/fixed-dry identities and original IntegrationPolicy.
- Call `evaluate_source_prefix_trial` once from that fine start/state to the original coarse seed end. If the full fine prefix again becomes negative, the two successful initial/Euler-midpoint captures still construct the fine root panel through the existing proposal/panel/root functions. Missing samples, cancellation, callback limits and other actual failures remain explicit; no fabricated endpoint fills the gap.
- Convert root brackets from local elapsed times to absolute ExactEventTime values using each panel's own start. A root lower value is not an absolute timestamp. Require the same unique liquid-first label and supported descending-root classification. Ties, gas-first, tangent, zero-initial, no-root and ordering uncertainty stay restricted. Preserve both panels' original budgets and distinguish any further bisection of their fixed polynomials from independent sampling.
- The two root intervals bound the roots of two independently sampled numerical panels only. A bound on their possible time difference can be derived from the exact interval endpoints; overlap alone does not certify equal times. Passing an original time tolerance does not yet certify the physical event time.
- For state comparison choose an exact common positive endpoint strictly after the fine start and before both relevant first-root lower bounds, also within the declared coarse horizon/program interval and original min/max step constraints. Actually run a coarse trial from the original coarse initial state and a fine trial from the accepted approach reference state to that endpoint. Either may be reused only if that exact successful trial already exists and is fully bound. Otherwise both endpoints require actual evaluation.
- Compare the two final reference captures as SavedSourceSample(state,evaluation,original_role). Do not relabel an earlier observation with the common time or reuse the old coarse Euler midpoint as the fine midpoint. A failed full-prefix root seed supplies root samples, not the missing common-endpoint state.

## Composite-path accounting

The refined common path consists of the accepted approach reference segment followed by the accepted fine continuation reference segment. Verify exact shared time and byte/type-exact shared state, source/energy identity and policies at the join. Each SourcePrefixTrial already verifies its own complete reference trace.

If the result claims the composite path obeys the original global numerical budgets, also accumulate represented accepted ExactStepLedger inventory/energy exchanges across the join and check the signed residual at every accepted endpoint against the original N/U absolute tolerances. Each separate integrate_exact call restarts its cumulative ledger; two locally passing runs do not by themselves prove the concatenated residual fits one global allowance. Do not sum each trial's wall allowance, accepted-step limit or callback count and call that a single original-controller allowance; report separate and total experiment costs explicitly.

`audit_source_prefixes` cannot directly audit this selected reference path: it is bound to SourcePrefix raw states and prefix ledgers. The mechanical exact record/resource/continuation admission APIs are likewise not source-host APIs. A small read-only accepted-reference ledger aggregation is sufficient for this stage; do not claim general record restoration, dry continuation or event admission.

## Reusable fixtures and exact-time cases

- `test_source_approach.actual` is the minimal existing actual manufactured source fixture: N1, liquid 1e-6, gases (.125,.25,1e-12), U initialized at 325 K, actual initial phase measurement, exact H=1.5*N/phase. It already supplies a two-capture negative coarse seed and complete event policy. Use the normal successful `evaluate_source_approach`, then its accepted reference endpoint for the new fine seed. The new fine-seed outcome must be measured; it has not been run by this reviewer.
- For large origins use an actual closed-column evaluation sequence starting at `T(F(2**80)+F(1,3))`, as the existing prefix-trial translation test does. Build all observations through the adapter at those exact times. Do not edit the times of saved records. Root interval translation and common-endpoint comparison must use Fraction/ExactEventTime throughout; only permitted nominal durations use the existing downward binary64 controller.
- `test_programmed_source_wet_column.setup(..., knots=(0.,.005,.015625), translation=origin)` and `test_exact_source_column.test_program_time_and_breakpoints_are_exact` provide actual source program boundaries. An interior knot is returned as `T(origin+F(.005))`; the same knot exactly at an interval endpoint is permitted. A cross-knot seed is refused before source evaluation. A supported coarse panel has no interior knot, so its contained fine/common intervals do not acquire a new knot. A common endpoint extending outside that panel must not silently bypass the program check.
- The existing open programmed fixture has different gas/heat boundary behavior; it is suitable for time/knot guards, but its root label must not be assumed to match the closed tiny-liquid case. `thermal_only=True` disables phase transfer in the fixture, so it cannot be presented as the same liquid-depletion case without an explicit legitimate model configuration.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE the reuse direction and minimal interface boundaries. This is not final approval of the new implementation or a claim of executed fine/common trajectories.
