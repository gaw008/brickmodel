"""Bounded independent new-path failure retention and passive runner review."""
from dataclasses import replace
from fractions import Fraction as F
from pathlib import Path
import ast, hashlib, importlib.util, signal
import pytest
from test_source_approach import actual as existing_fixture
from test_depletion_integration import policies
from sludge_sandbox._heos_kernel import HEOSCandidate
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.integration import IntegrationPolicy
from sludge_sandbox.depletion_roundoff import DepletionRoundoffPolicy
from sludge_sandbox.depletion_integration import DepletionPolicy
from sludge_sandbox.source_approach import propose_source_approach, evaluate_source_approach
from sludge_sandbox.source_root_comparison import (
    evaluate_source_root_refinement, positive_source_common_end,
    evaluate_source_common_endpoint, SourceRootStudyError,
)
from sludge_sandbox.integration import DomainExit
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
RUNNER=Path('/private/tmp/brick-source-root-comparison-v1/root/run_native.py')

def imported(path):
    spec=importlib.util.spec_from_file_location('review_'+path.parent.name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def test_current_runner_imports_hashes_complete_policy_and_limits_are_passive(monkeypatch):
    monkeypatch.setattr(HEOSCandidate,'__init__',lambda *a,**kw:pytest.fail('import invoked native constructor'))
    module=imported(RUNNER)
    compile(RUNNER.read_text(),str(RUNNER),'exec')
    for name,expected in module.HELPERS.items():
        path=ROOT/'docs/sandbox/research'/name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
        imported(path)
    calls={n.func.id:n for n in ast.walk(ast.parse(RUNNER.read_text()))
           if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
           and n.func.id in ('IntegrationPolicy','DepletionRoundoffPolicy','DepletionPolicy')}
    env=dict(F=F,horizon=F(1,1024),IntegrationPolicy=IntegrationPolicy,
             DepletionRoundoffPolicy=DepletionRoundoffPolicy,DepletionPolicy=DepletionPolicy)
    for name in ('IntegrationPolicy','DepletionRoundoffPolicy','DepletionPolicy'):
        value=eval(compile(ast.Expression(calls[name]),str(RUNNER),'eval'),env)
        env[{'IntegrationPolicy':'policy','DepletionRoundoffPolicy':'rounding','DepletionPolicy':'event'}[name]]=value
    assert env['rounding']==policies()[1].roundoff_policy
    assert env['event']==replace(policies()[1],maximum_refinements=32)
    assert env['policy']==IntegrationPolicy(1/1024,1/1024,2**-30,1e-8,1e-7,1e-3,1.,1e5,4,4,180.)
    assert (module.CALLBACK_CAP,module.TOTAL_CALLBACK_CAP,module.OUTER_SECONDS)==(16,81,210.)

@pytest.fixture(scope='module')
def refinement():
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(HEOSCandidate,'__init__',lambda *a,**k:pytest.fail('manufactured review invoked native'))
        gen=existing_fixture.__wrapped__()
        try:
            seed,event=next(gen)
            approach=evaluate_source_approach(propose_source_approach(seed,event_policy=event),maximum_callbacks=16)
            yield evaluate_source_root_refinement(approach,maximum_callbacks=16)
        finally:gen.close()

@pytest.mark.parametrize('kind',[DomainExit,RuntimeError])
def test_second_common_trial_failure_preserves_completed_first_and_attempt(refinement,monkeypatch,kind):
    original=ExactSourceColumn.evaluate;calls=[]
    def observed(self,state,at):
        calls.append((state,at))
        if len(calls)==12:raise kind('independent_second_path_failure')
        return original(self,state,at)
    monkeypatch.setattr(ExactSourceColumn,'evaluate',observed)
    with pytest.raises(SourceRootStudyError) as caught:
        evaluate_source_common_endpoint(refinement,end=positive_source_common_end(refinement),
                                        maximum_callbacks_per_trial=16)
    err=caught.value
    assert err.stage=='shifted_common_trial' and len(err.records)==3
    coarse,shifted=err.records[1:]
    assert coarse.status=='validated_positive_numerical_trial' and len(coarse.captures)==11
    assert len(shifted.captures)==1 and len(calls)==12
    assert shifted.captures[0].failure_kind==('DomainExit' if kind is DomainExit else 'UnexpectedException')
    assert shifted.status==('domain_exit' if kind is DomainExit else 'numerical_failure')
    assert 'independent_second_path_failure' in shifted.reason
    before=len(calls);coarse.check();shifted.check();assert len(calls)==before
