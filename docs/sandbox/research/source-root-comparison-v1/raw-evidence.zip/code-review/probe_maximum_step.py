"""Independent bounded manufactured regression for multi-step common trials."""
from dataclasses import fields, replace
from fractions import Fraction as F
import hashlib, importlib.util, json, time
from pathlib import Path
import pytest
from test_source_approach import actual as fixture
from sludge_sandbox._heos_kernel import HEOSCandidate
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_approach import propose_source_approach, evaluate_source_approach
from sludge_sandbox.source_prefix_trial import evaluate_source_prefix_trial
from sludge_sandbox.source_root_comparison import (
    evaluate_source_root_refinement, positive_source_common_end,
    evaluate_source_common_endpoint, SourceRootStudyError,
)

folder=Path('/private/tmp/brick-source-root-comparison-v1/code-review')
repo=Path('/Users/wanggaoying/Desktop/brickmodel-github')
serializer_path=repo/'docs/sandbox/research/exact-source-column-v1/run_native.py'
assert hashlib.sha256(serializer_path.read_bytes()).hexdigest()=='b0b873960bdc8bc9f2299fc3d0d008fd5fa5a9d3f7a972eb0f080ec3a2d39ab5'
spec=importlib.util.spec_from_file_location('passive_encode',serializer_path)
serializer=importlib.util.module_from_spec(spec);spec.loader.exec_module(serializer)
encode=serializer.serialize
started=time.monotonic();calls=[];phase='fixture';out={'scope':'manufactured_actual_source_no_native','native_calls':0,'cap':48,'soft_seconds':30}
def record(value,omit=()):return {f.name:encode(getattr(value,f.name)) for f in fields(value) if f.name not in omit}
def save():
    out.update(wall_seconds=time.monotonic()-started,calls=calls,total_callbacks=len(calls))
    (folder/'maximum-step.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
def forbidden(*a,**k):raise AssertionError('native_constructor_forbidden')
def cancel():return time.monotonic()-started>=30
original=ExactSourceColumn.evaluate
def observed(self,state,when):
    if cancel():raise AssertionError('30s_soft_limit')
    if len(calls)>=48:raise AssertionError('48_callback_limit')
    calls.append({'ordinal':len(calls)+1,'phase':phase,'time':encode(when)})
    return original(self,state,when)
with pytest.MonkeyPatch.context() as mp:
    mp.setattr(HEOSCandidate,'__init__',forbidden)
    mp.setattr(ExactSourceColumn,'evaluate',observed)
    gen=fixture.__wrapped__()
    try:
        original_seed,event=next(gen)
        maximum=float(original_seed.end.elapsed_since(original_seed.start)/16)
        policy=replace(original_seed.policy,initial_step_s=maximum,maximum_step_s=maximum)
        # Only the legitimate new run's step controls change; all scientific tolerances are identical.
        out.update(original_policy=encode(original_seed.policy),policy=encode(policy),event_policy=encode(event))
        phase='new_seed'
        seed=evaluate_source_prefix_trial(original_seed.adapter,original_seed.initial,start=original_seed.start,
            end=original_seed.end,integration_policy=policy,maximum_callbacks=32,cancel=cancel)
        out['seed']=record(seed,('adapter',));save()
        assert seed.reason=='source_prefix_negative_inventory_minimum' and len(seed.captures)==2
        phase='approach'
        approach=evaluate_source_approach(propose_source_approach(seed,event_policy=event),maximum_callbacks=32,cancel=cancel)
        out['approach_trial']=record(approach.trial,('adapter',));save()
        assert approach.status=='validated_positive_numerical_approach'
        assert approach.trial.end.elapsed_since(seed.start)==F(maximum)
        phase='shifted_seed'
        refinement=evaluate_source_root_refinement(approach,maximum_callbacks=32,cancel=cancel)
        out['shifted_trial']=record(refinement.shifted_trial,('adapter',));save()
        assert refinement.clock is not None
        end=positive_source_common_end(refinement)
        assert end.elapsed_since(seed.start)>F(maximum)
        assert end.elapsed_since(approach.trial.end)<=F(maximum)
        out['requested_common_end']=encode(end)
        phase='common'
        common=evaluate_source_common_endpoint(refinement,end=end,maximum_callbacks_per_trial=32,cancel=cancel)
        for name,trial in [('coarse',common.coarse_trial),('shifted',common.shifted_trial)]:
            out[name]=record(trial,('adapter',))
            durations=[step.end_s.elapsed_since(step.start_s) for step in trial.reference.steps]
            assert all(F(policy.minimum_step_s)<=h<=F(maximum) for h in durations)
            assert trial.discrepancy<=1 and trial.status=='validated_positive_numerical_trial'
            out[name+'_reference_durations']=encode(durations)
        assert len(common.coarse_trial.reference.steps)==2
        assert not common.event_admitted and not common.material_qualified
        before=len(calls);timer=time.monotonic();common.check()
        out['passive_check_seconds']=time.monotonic()-timer
        assert len(calls)==before
        out.update(status='completed',gates=encode(common.gates),conditional_pressure_gate=common.conditional_pressure_gate,
                   maximum_step_s=maximum,common_span_s=float(end.elapsed_since(seed.start)),
                   new_evaluations=common.new_evaluations)
        save()
        print(json.dumps({k:out[k] for k in ('status','wall_seconds','total_callbacks','maximum_step_s','common_span_s','new_evaluations','passive_check_seconds','gates')},indent=2))
    except Exception as exc:
        if isinstance(exc,SourceRootStudyError):
            out.update(error_stage=exc.stage,error_trials=[record(v,('adapter',)) for v in exc.records if hasattr(v,'captures')])
        out.update(status='failed',exception_type=type(exc).__name__,exception=str(exc));save();raise
    finally:gen.close()
