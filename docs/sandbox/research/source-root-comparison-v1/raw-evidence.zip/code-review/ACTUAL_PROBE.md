# Actual manufactured-source refinement/common endpoint probe

One execution completed in **7.455988792 s**, within the declared 30 s soft limit. The guarded adapter recorded **38 actual source callbacks**, below the total cap of 48. No native HEOS constructor or EOS was executed. The existing explicitly manufactured liquid fixture supplied the water response; these results are not real-material evidence.

Full artifact: `actual-common01.json`, 3,140,068 bytes, SHA-256 `8d3f2b06b5ecfeddf492b7eeeeec0966c005dc93e131467cb4ac3176cff0ef85`. Script/log: `probe_actual_common.py`, `actual-common01.log`. The compact `ACTUAL_PROBE_SUMMARY.json` retains the full policies, exact common-endpoint controls and cumulative reference residuals. All previously pinned interface files remained unchanged after the run.

| Phase | Source callbacks | Actual outcome |
|---|---:|---|
| Initial phase observation | 1 | Positive manufactured-source phase |
| Coarse seed | 2 | Negative full-prefix minimum, prefix=None; valid initial/midpoint retained |
| Existing positive approach | 11 | Completed actual prefix/reference trial |
| Shifted seed to original H | 2 | Negative full-prefix minimum, prefix=None; valid new initial/midpoint retained |
| Coarse path to common endpoint | 11 | Completed actual prefix/reference trial |
| Fine continuation to common endpoint | 11 | Completed actual prefix/reference trial |

The first three callbacks are made by the unmodified `test_source_approach.actual.__wrapped__()` fixture. The shifted initial state is exactly the successful approach's accepted reference endpoint, bound to its final actual capture. No saved state, time, adapter or evaluation was fabricated or relabeled as a new physical evaluation. The source callback count is not an exhaustive count of all internal property arithmetic or fixture initialization operations.

Both root proposals select the same first liquid label `('liquid',0,0)`. Their independently evaluated first/midpoint pairs differ. The coarse H is 18.755119098214227 s; shifted start is 2.344389887276778 s. Refined positive lower bounds on the common original clock are 9.377559549107113 s and 10.549754492745501 s.

The preregistered probe rule gives the common endpoint as shifted start plus downward_binary64(1/4 times the remaining distance to the smaller absolute root lower bound). The actual common endpoint is **4.102682302734362 s**, with fine duration **1.7582924154575836 s**. Both path durations pass the original min/max constraints, the common endpoint is strictly below both lower bounds, and neither interval crosses a program knot.

The coarse and fine common endpoint samples are the final **reference** captures of two fresh successful SourcePrefixTrials. Their liquid amounts are 6.736890118778901e-7 and 6.736877847139503e-7 mol. Each call retained the same original IntegrationPolicy: initial/max step=float(H), min step=2^-30, rtol=1e-8, N atol=1e-7, U atol=1e-3, scales=1 and 1e5, accepted/rejected limits=4, wall limit=15 s. Each new trial retained a 16-callback cap. The complete original DepletionPolicy, including safe fraction=0.25, refinements=32 and all nested/default controls, is saved unchanged.

`measure_source_endpoint_pair` and two `enclose_source_inverse_pressure` calls yield:

| Quantity | Bound/difference | Original gate |
|---|---:|---|
| N | 1.2271639398957607e-12 mol | true |
| U | 0 J | true |
| T | 5.276919853385867e-10 K | true |
| Reported-temperature P | 0.0005741868907938694 Pa | false |
| Conditional full-temperature P | 0.0005758321954782356 Pa | false |

The last two exceed the unchanged 0.0001 Pa pressure tolerance. No tolerance was modified to achieve a passing outcome. The two within-trial direct discrepancies are 4.57747881380606e-5 and 3.5832417766158757e-6; those are separate from the cross-path event-policy gates.

Read-only aggregation joins the two accepted fine-reference segments (approach followed by fine continuation) at their exact shared time/state and accumulates original represented N/U ledger exchanges from the original initial state. Both accepted endpoints satisfy the original cumulative signed N/U residual limits. Actual per-endpoint Fraction residuals are retained; prefix ledgers were not substituted for accepted reference ledgers. This verifies this two-segment example, not a general continuation or resource-admission implementation.

No runtime failure or parameter search occurred. Root-time comparison, event admission, dry transitions and real-material validation remain unclaimed. This probe demonstrates that the proposed real evaluation/refinement/common-endpoint sequence is feasible using existing APIs, with both pressure gates honestly retained as false.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE the reuse sequence demonstrated by this bounded fixture. New production implementation remains subject to code review.
