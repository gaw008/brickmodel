"""Bounded independent tests; ledger records below are manufactured helper inputs."""
from dataclasses import replace
from fractions import Fraction as F
from types import SimpleNamespace as NS

import numpy as np
import pytest

from test_source_approach import choice
from test_source_net_roots import poly
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.integration import ConservedState, IntegrationError
from sludge_sandbox.source_root_comparison import (
    _joined_reference_residuals, compare_source_root_clocks,
)


def manufactured_chain(*, amount_delta=0., energy_delta=0., origin=F()):
    """No actual source trial is constructed or claimed by this pure arithmetic fixture."""
    policy = NS(amount_absolute_tolerance_mol=1.5, energy_absolute_tolerance_j=1.5)
    states = tuple(ConservedState(np.array([[8. + i*amount_delta]]), np.array([8. + i*energy_delta]))
                   for i in range(3))
    def segment(index):
        start, end = T(origin+index), T(origin+index+1)
        ledger = NS(face_species_mol=np.zeros((2, 1)), face_energy_j=np.zeros(2),
                    reaction_species_mol=np.zeros((1, 1)), cell_work_j=np.zeros(1), end_s=end)
        return NS(initial=states[index], start=start, end=end, policy=policy,
                  status='validated_positive_numerical_trial',
                  reference=NS(states=(states[index], states[index+1]), steps=(ledger,)))
    return segment(0), segment(1)


@pytest.mark.parametrize('field,reason', [('amount_delta', 'joined_source_cumulative_amount_roundoff'),
                                         ('energy_delta', 'joined_source_cumulative_energy_roundoff')])
def test_joined_residual_budget_cannot_restart_between_segments(field, reason):
    trials = manufactured_chain(**{field: 1.})
    for one in trials:
        _joined_reference_residuals((one,))  # each local residual 1 is below 1.5
    with pytest.raises(IntegrationError, match=reason):
        _joined_reference_residuals(trials)  # original-origin residual 2 exceeds 1.5


@pytest.mark.parametrize('origin', [F(10**400), -F(10**400)])
def test_joined_helper_keeps_exact_large_origin(origin):
    rows = _joined_reference_residuals(manufactured_chain(amount_delta=.5, energy_delta=.5, origin=origin))
    assert rows[-1][0] == T(origin+2)
    assert rows[-1][1] == rows[-1][2] == (F(1),)


@pytest.mark.parametrize('seconds', [1, True])
def test_clock_rejects_mutated_nonfraction_exact_time(seconds):
    c = choice((poly(1,-1),))
    invalid = T(F(1))
    object.__setattr__(invalid, 'seconds', seconds)
    with pytest.raises(ValueError):
        compare_source_root_clocks((c,c),(invalid,T(F(1))),time_absolute_s=F(1,100))


from test_source_root_comparison import actual, approach, refinement
import sludge_sandbox.source_root_comparison as module
from sludge_sandbox.source_root_comparison import (
    SourceRootStudyError, positive_source_common_end, evaluate_source_common_endpoint,
    evaluate_source_root_refinement,
)


def test_second_path_cancellation_preserves_both_actual_trial_records(refinement, monkeypatch):
    end = positive_source_common_end(refinement)
    original = module.evaluate_source_prefix_trial
    paths = []
    def observed(*args, **kwargs):
        paths.append((args[1], kwargs['start'], kwargs['end']))
        return original(*args, **kwargs)
    monkeypatch.setattr(module, 'evaluate_source_prefix_trial', observed)
    with pytest.raises(SourceRootStudyError) as caught:
        evaluate_source_common_endpoint(refinement, end=end, maximum_callbacks_per_trial=16,
                                        cancel=lambda: len(paths) == 2)
    error = caught.value
    assert error.stage == 'shifted_common_trial'
    assert len(paths) == 2 and len(error.records) == 3
    completed, cancelled = error.records[1:]
    assert completed.status == 'validated_positive_numerical_trial'
    assert completed.reference.status == 'completed' and len(completed.captures) > 0
    assert cancelled.status == 'cancelled' and len(cancelled.captures) == 0
    assert cancelled.start == refinement.approach.trial.end
    assert completed.end == cancelled.end == end
    assert error.exception_type == 'IntegrationError' and isinstance(error.__cause__, IntegrationError)
    completed.check()
    cancelled.check()


def test_shifted_root_assessment_failure_keeps_real_shifted_attempt(approach, monkeypatch):
    def fail(*args, **kwargs):
        raise RuntimeError('independent_shifted_assessment_failure')
    monkeypatch.setattr(module, 'compare_source_root_trials', fail)
    with pytest.raises(SourceRootStudyError) as caught:
        evaluate_source_root_refinement(approach, maximum_callbacks=16)
    error = caught.value
    assert error.stage == 'shifted_root_assessment' and len(error.records) == 2
    saved_approach, trial = error.records
    assert saved_approach.trial is approach.trial
    assert trial.start == approach.trial.end
    assert trial.reason == 'source_prefix_negative_inventory_minimum' and len(trial.captures) == 2
    assert error.exception_type == 'RuntimeError'
    assert error.exception_message == 'independent_shifted_assessment_failure'
    assert isinstance(error.__cause__, RuntimeError)
    trial.check()
