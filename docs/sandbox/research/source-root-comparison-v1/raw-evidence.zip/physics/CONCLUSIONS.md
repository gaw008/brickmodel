# Shifted actual-panel comparison: valid scope and concrete construction

Read-only review of source_approach.py, SourcePrefixTrial and old exact_depletion_integration.compare. No EOS, new source evaluation or production edit.

A validated positive approach's **reference** endpoint can be a legitimate new initial state for a fresh SourcePrefixTrial ending at the old exact attempted H. This creates an independently evaluated shifted panel along a partitioned numerical path. It is not a standard2:1 coarse/fine refinement, not a Richardson estimator and not a physically accepted event trajectory. Do not multiply root-time discrepancy by1/3 or label the shifted panel a second half-step unless it actually is one.

Required chain: original common state/operator/time -> completed approach reference over[0,a] -> its actual last evaluated packed state and exact timea -> fresh trial[a,H]. Preserve fixed dry mass, full source/energy/operator identities, declared interface modes and original scientific/integration/event policies. Use reference.states[-1], not the affine prefix endpoint, and retain which path was selected. The initial derivative at the new state must be freshly evaluated as part of the new trial; do not reuse an old observation at the same time with another state. Source program knots must be handled through existing exact interval guards, without changing furnace forcing.

A fresh trial may fail negative full-prefix minimum yet supply valid actual first/Euler-midpoint observations. Those support a numerical root panel just as the original failed seed did. If its Euler midpoint is nonpositive or its callback fails, there is no second actual panel: return missing_actual_shifted_midpoint, with partial evidence. Do not force root comparison using a fabricated state or an unevaluated extrapolated derivative.

## Why H/2 can fail and a smaller actual partition can help

For a manufactured constant phase loss N(t)=N0-k*t, tau=N0/k. A fresh Euler midpoint from an exactly evolved positive starting state at timea to H is positive iff

    a < 2*tau-H.

Original seed midpoint can be positive whenH<2*tau, even though H>tau and the full prefix crosses zero. Using a=H/2 requiresH<4*tau/3. Thus H=1.5*tau has a valid original midpoint but an invalid second-half midpoint (3H/4=1.125*tau). A smaller validated approach a=tau/4 gives new midpoint0.875*tau, positive, while the shifted full panel still crosses the root. The previous actual approach used a aroundH/8, which likewise makes this construction plausible, not guaranteed for nonlinear source rates.

Counterexample: H=1.9*tau and a=tau/4 are individually consistent with an original positive seed midpoint and a positive approach, but shifted midpoint1.075*tau is negative. Therefore even the original safe_inventory_fraction<.5 does not guarantee a valid continuation-to-H midpoint. There must be an explicit refusal; choosing smallera is a separately bounded proposal, not an automatic resource retry or a new controller.

## Exact root comparison

Each panel separately orders all4N fluid inventories, with positive initial amounts and complete bound source evidence. Require exactly one identical earliest liquid descending-crossing label; gas-first, ties, tangent, zero-initial, no-root and unresolved cases retain distinct statuses. Also reject comparison if the shifted starta lies at/after the original first-root interval's lower bound: the positive initial path does not by itself prove the coarse surrogate had no earlier zero. Keep earliest event order across the actual approach segment; all-positive numerical prefix/reference checks provide conditional numerical path evidence, not continuous true-RHS root proof.

Convert each local bracket to absolute exact times: [La,Ua]=startA+[loA,hiA], [Lb,Ub]=startB+[loB,hiB]. A conservative upper bound on distance between their surrogate roots is

    delta_upper = max(abs(La-Ub), abs(Ua-Lb)).

This includes both bracket widths without adding clock origins as floats. Equivalently use center distance plus both half-widths. An exact point root has zero width. The interval-distance lower bound max(0,La-Ub,Lb-Ua) may be reported separately, but overlapping intervals do not prove the time gate passes. Compare delta_upper to the original time_absolute_s; an upper bound above tolerance means uncertified/rejected comparison, not proof that true physical event times differ beyond tolerance.

Each panel's existing ordering/lower-positive refinements retain their original caller-limited counts and256 per-root hard ceiling. Further comparison narrowing must consume explicitly allocated remaining rounds, never reset either root's depth. Record initial/final brackets, per-panel depth and additional comparison rounds. If using one shared outer comparison budget, state whether a round refines one or both records and charge it consistently. Exact point roots need no bisection. No root-order implementation or adaptive integrator is copied.

## Common endpoint and pressure constraints

Raw states at differently located root estimates are not same-time N/U/T/P comparisons. For this stage, compare both numerical paths at a separately declared common positive time strictly before both earliest lower bounds, with actually completed positive evolution and actual observations there. If the desired common time would require crossing a dry event, it is unavailable until the source dry-mode/writeback machinery is independently justified. In particular, H lies beyond the candidate zero and cannot be an accepted wet common endpoint merely because it was the attempted panel horizon.

The shifted-root comparison can first report only surrogate root-order/time consistency, leaving event-state/common-time checks unresolved. Existing reported-T pressure bounds and conditional inverse-temperature propagation remain distinct; the latter is still based on declared numerical envelopes and stable-branch hypotheses. Matching roots and passing a conditional pressure gate do not grant source-certified event accuracy, paired drainage correction or material qualification.

## Two bounded manufactured cases

1. Actual manufactured-water N1 source fixture matching the recent positive-approach test: tiny positive liquid/vapor, no reaction, closed boundaries. Preserve the existing failed seed and completed approach; perform just one fresh[a,H] trial with original tolerances and explicit remaining callbacks/wall budget. Expect either two valid observations with a liquid root, or an honest midpoint/domain refusal. Independently rebuild both polynomials from actual rates and compare absolute brackets. This case is phase transfer only, not transport drainage.

2. Pure retained-rate constant-loss construction with exact N0=k=1, H=3/2 and a=1/4 proves the geometric distinction above; H=19/10,a=1/4 is the mandatory refusal counterexample. Expand to4N records with a deliberately earlier gas crossing or a tangent to prove label/competitor guards. These manufactured records verify comparison arithmetic and refusal logic; they must not be relabeled actual source-EOS observations.

These cases need no new controller and do not require a successful wet endpoint after depletion. Full source wet-to-dry continuation still needs its own conserved correction, mode law and independently supported event-state/pressure bounds.
