"""Supplement original registered scalar budgets and retain exact prefix residuals."""
import runpy,json,hashlib,time
from pathlib import Path
from fractions import Fraction
P=Path(__file__).parent
m=runpy.run_path(str(P/'audit_saved.py')); t=time.monotonic()
f=Path('/private/tmp/brick-source-root-comparison-v1/root/native-result.json');raw=f.read_bytes();r=m['dec'](json.loads(raw));n=0
def ck(v):
 global n
 n+=1
 assert v
ck(hashlib.sha256(raw).hexdigest()=='6aa52124fec977dfb39c65cac64538c87918fc8ed3cff82d3b3a5d5cd0474ae8')
for k,v in dict(minimum_step_s=2**-30,relative_tolerance=1e-8,amount_absolute_tolerance_mol=1e-7,energy_absolute_tolerance_j=1e-3,amount_scale_mol=1.,energy_scale_j=1e5,maximum_steps=4,maximum_rejections=4,maximum_wall_seconds=180.).items():ck(r['integration_policy'][k]==v)
for k,v in dict(time_absolute_s=1e-8,amount_absolute_mol=1e-11,energy_absolute_j=1e-7,temperature_absolute_k=1e-5,pressure_absolute_pa=1e-4,maximum_refinements=32,safe_inventory_fraction=.25).items():ck(r['event_policy'][k]==v)
for key in ('seed','trial','shifted_seed','coarse_common_trial','shifted_common_trial'):
 ck(r[key]['policy']==r['integration_policy']);ck(len(r[key]['captures'])<=16)
ck(r['outer_seconds']==210. and r['per_trial_callback_cap']==16 and r['total_callback_cap']==81)
ck(len(r['captures'])<=81 and r['wall_seconds']<210.)
for k in ('backend_constructors_started','backend_constructors_completed','constructor_reference_anchor_checks'):ck(r[k]==4)
ck(r['initial_energy_evaluations_attempted']==1)
def enc(v):
 if isinstance(v,Fraction):return {'numerator':v.numerator,'denominator':v.denominator}
 raise TypeError(type(v).__name__)
s={'status':'passed','checks':n,'elapsed_s':time.monotonic()-t,'input_sha256':hashlib.sha256(raw).hexdigest(),'trial_capture_counts':{k:len(r[k]['captures']) for k in ('seed','trial','shifted_seed','coarse_common_trial','shifted_common_trial')},'cumulative_residuals_exact':r['common_comparison']['cumulative_residuals'],'constructor_anchor_scope':'four explicitly recorded provider construction anchors; no claim to count every internal native operation','source_evaluations':len(r['captures'])}
(P/'SAVED_POLICY_RESULT.json').write_text(json.dumps(s,default=enc,indent=2)+'\n');print(json.dumps(s,default=enc,indent=2))
