"""Independent clocks/budget algebra and synthetic joined-ledger controls; no EOS."""
from fractions import Fraction as F
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace as NS
import hashlib,time,json,signal
import numpy as np
from sludge_sandbox.mass_wet_exact_stage import InventoryPolynomial
from sludge_sandbox.source_net_roots import order_inventory_roots
from sludge_sandbox.source_approach import choose_positive_approach
from sludge_sandbox.source_root_comparison import compare_source_root_clocks,_joined_reference_residuals
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.integration import ConservedState,IntegrationPolicy
from sludge_sandbox.exact_integration import ExactStepLedger
OUT=Path(__file__).parent;SRC=Path('src/sludge_sandbox/source_root_comparison.py');sha=lambda:hashlib.sha256(SRC.read_bytes()).hexdigest();initialsha=sha();n=0
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('independent20s')));signal.alarm(20)
def ck(v,label):
 global n
 n+=1
 if not v:raise AssertionError(label)
def p(c,r,q=0,j=0):return InventoryPolynomial('liquid' if j==0 else 'gas',0,j,F(c),F(r),F(q))
def choice(poly,budget):
 order=order_inventory_roots((poly,p(1,0,j=1),p(1,0,j=2),p(1,0,j=3)),F(2),maximum_refinements=budget)
 return choose_positive_approach(order,safe_fraction=F(1,4),minimum_step_s=F(1,2**30),maximum_step_s=F(2),horizon_s=F(2))
def independent(choice,tol):
 root=choice.selected_root;lo,hi=root.lower,root.upper;used=0;remaining=choice.order.maximum_refinements-choice.order.refinement_level-choice.additional_refinement_rounds
 while hi-lo>tol/4 and used<remaining:
  mid=(lo+hi)/2;q=root.polynomial;v=q.initial+q.linear*mid+q.quadratic*mid*mid
  if v==0:lo=hi=mid
  elif v>0:lo=mid
  else:hi=mid
  used+=1
 return lo,hi,used
start=time.monotonic();origin=F(2**100)+F(1,3)
a,b=choice(p(1,-1),32),choice(p(F(3,4),-1),32)
out=compare_source_root_clocks((a,b),(T(origin),T(origin+F(1,4))),time_absolute_s=F(1,1000));ck(out.gate and out.distance_upper_s==0 and out.additional_rounds==(0,0),'identical absolute point roots');out.check()
far=compare_source_root_clocks((a,b),(T(origin),T(origin+F(1,4)+F(1,500))),time_absolute_s=F(1,1000));ck(not far.gate and far.distance_upper_s==F(1,500),'no erroneous divide3')
for budget in (2,3,8,32):
 a=choice(p(1,-3,1),budget);tol=F(1,2**20)
 out=compare_source_root_clocks((a,a),(T(origin),T(origin+F(1,100))),time_absolute_s=tol)
 lo,hi,used=independent(a,tol)
 ck(out.additional_rounds==(used,used),'remaining round counts')
 ck(out.refined_roots[0].lower==lo and out.refined_roots[0].upper==hi,'independent bracket')
 A,B=origin+lo,origin+hi;C,D=origin+F(1,100)+lo,origin+F(1,100)+hi
 lower=max(F(),A-D,C-B);upper=max(abs(A-D),abs(B-C))
 ck(out.distance_lower_s==lower and out.distance_upper_s==upper and out.gate==(upper<=tol),'exact interval separation')
 ck(a.order.refinement_level+a.additional_refinement_rounds+used<=budget,'no reset from prior root work');out.check()
 if budget<8:ck(hi-lo>tol/4 and not out.gate,'exhaustion retains wide false gate')
 for bad in (replace(out,gate=True),replace(out,additional_rounds=(0,0)),replace(out,distance_upper_s=F())):
  try:bad.check()
  except ValueError:ck(True,'forged comparison rejected')
  else:
   # rounds0 can be the actual value when budget fully consumed; do not label unchanged record forged.
   ck(bad==out,'unchanged record only')
# Test joined arithmetic in isolation; these are synthetic trusted-input records,
# not actual SourcePrefixTrial instances or source physics evidence.
policy=IntegrationPolicy(1.,1.,.1,1e-8,1.,3*2.**-49,1.,1.,4,4,5.)
state=ConservedState(np.ones((1,4)),np.array([100.]),('synthetic',))
def trial(at,policy,energy_delta=0.,amount_delta=0.):
 ledger=ExactStepLedger(T(F(at)),T(F(at+1)),np.zeros((2,4)),np.array([energy_delta,0.]),np.array([[amount_delta,0.,0.,-amount_delta]]),np.zeros(1))
 return NS(status='validated_positive_numerical_trial',initial=state,start=T(F(at)),end=T(F(at+1)),policy=policy,reference=NS(states=(state,state),steps=(ledger,)))
for kind in ('energy','amount'):
 pol=policy if kind=='energy' else replace(policy,amount_absolute_tolerance_mol=3*2.**-55,energy_absolute_tolerance_j=1.)
 kw={'energy_delta':2.**-48} if kind=='energy' else {'amount_delta':2.**-54}
 t1,t2=trial(0,pol,**kw),trial(1,pol,**kw)
 ck(len(_joined_reference_residuals((t1,)))==1 and len(_joined_reference_residuals((t2,)))==1,'each isolated residual passes')
 try:_joined_reference_residuals((t1,t2))
 except ValueError as e:ck(str(e)==('joined_source_cumulative_energy_roundoff' if kind=='energy' else 'joined_source_cumulative_amount_roundoff'),'joined original budget rejects reset')
 else:raise AssertionError('joined reset budget accepted')
ck(initialsha==sha(),'unchanged source during check');result={'status':'passed','checks':n,'elapsed_s':time.monotonic()-start,'source_sha256':initialsha,'scope':'Exact absolute clocks, remaining bisection budget and isolated synthetic joined-ledger arithmetic; no EOS or actual physical path run'}
OUT.joinpath('CLOCK_BALANCE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));signal.alarm(0)
