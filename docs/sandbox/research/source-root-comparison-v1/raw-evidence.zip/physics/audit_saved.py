"""Terminal saved root/common-path audit: stdlib only, no EOS/model imports."""
from fractions import Fraction as F
from pathlib import Path
import json,hashlib,math,sys,time
OUT=Path(__file__).parent;checks=0
def ck(x,label):
 global checks
 checks+=1
 if not x:raise AssertionError(label)
def dec(x):
 if isinstance(x,list):return [dec(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'numerator','denominator'}:return F(x['numerator'],x['denominator'])
  if set(x)=={'type','fields'}:return dec(x['fields'])
  if 'dtype' in x and 'values' in x:return dec(x['values'])
  return {k:dec(v) for k,v in x.items()}
 return x
def value(p,t):return p['initial']+p['linear']*t+p['quadratic']*t*t
def minimum(p,h):
 ts=[F(),h]
 if p['quadratic']>0 and 0<-p['linear']/(2*p['quadratic'])<h:ts.append(-p['linear']/(2*p['quadratic']))
 return min((value(p,t),t) for t in ts)
def refine(root,remaining,tol):
 lo,hi=root['lower'],root['upper'];used=0
 while hi-lo>tol/4 and used<remaining:
  mid=(lo+hi)/2;v=value(root['polynomial'],mid)
  if v==0:lo=hi=mid
  elif v>0:lo=mid
  else:hi=mid
  used+=1
 return lo,hi,used
def interval(e):return [e['lower']['seconds'],e['upper']['seconds']]
def same_capture(actual,stored):
 ck(actual['packed_input']==stored['state'] and actual['time']==stored['time'],'actual capture inputs')
 if stored['evaluation'] is not None:ck(actual.get('evaluation')==stored['evaluation'],'actual capture output')
def joined(trials):
 origin=trials[0]['initial'];policy=trials[0]['policy'];nc=len(origin['amounts_mol']);nv=len(origin['amounts_mol'][0]);sn=[[F()]*nv for _ in range(nc)];su=[F()]*nc;previous=origin;at=trials[0]['start'];rows=[]
 for trial in trials:
  ref=trial['reference'];ck(trial['status']=='validated_positive_numerical_trial' and trial['initial']==previous and trial['start']==at and trial['policy']==policy,'reference chain actual connection')
  ck(ref['status']=='completed' and ref['states'][0]==previous and ref['times_s'][0]==at and ref['times_s'][-1]==trial['end'] and len(ref['states'])==len(ref['steps'])+1,'reference complete interval')
  for state,ledger,when in zip(ref['states'][1:],ref['steps'],ref['times_s'][1:]):
   nr=[];ur=[]
   for i in range(nc):
    for j in range(nv):
     sn[i][j]+=F(ledger['face_species_mol'][i][j])-F(ledger['face_species_mol'][i+1][j])+F(ledger['reaction_species_mol'][i][j]);res=F(state['amounts_mol'][i][j])-F(origin['amounts_mol'][i][j])-sn[i][j];nr.append(res);ck(abs(res)<=F(policy['amount_absolute_tolerance_mol']),'original cumulative amount budget each prefix')
    su[i]+=F(ledger['face_energy_j'][i])-F(ledger['face_energy_j'][i+1])+F(ledger['cell_work_j'][i]);res=F(state['internal_energy_j'][i])-F(origin['internal_energy_j'][i])-su[i];ur.append(res);ck(abs(res)<=F(policy['energy_absolute_tolerance_j']),'original cumulative U budget each prefix')
   ck(when==ledger['end_s'],'ledger endpoint');rows.append([when,nr,ur])
  previous=ref['states'][-1];at=trial['end']
 return rows

def run(path,expected):
 start=time.monotonic();sha=hashlib.sha256(path.read_bytes()).hexdigest();ck(sha==expected,'native SHA');r=dec(json.loads(path.read_text()));summary={'input_sha256':sha,'original_status':r['status']}
 if r['status']!='completed':
  summary.update(status='original_failure_preserved',available_fields=sorted(r),actual_captures=len(r.get('captures',[])),exception=r.get('exception'),checks=checks);return summary
 names=('seed','trial','shifted_seed','coarse_common_trial','shifted_common_trial');trials=[r[k] for k in names];caps=r['captures'];stored=[c for t in trials for c in t['captures']]
 ck(len(caps)==1+len(stored),'all actual callbacks including separate rate probe')
 for actual,c in zip(caps[1:],stored):same_capture(actual,c)
 origin=r['initial'];op=trials[0]['operator_identity'];energy=trials[0]['energy_identity']
 for c in stored:
  ck(c['state']['energy_model_identity']==energy,'state energy identity')
  if c['evaluation'] is not None:
   ck(c['evaluation']['operator_identity']==op and c['evaluation']['time']==c['time'],'source actual time identity')
   ck(c['evaluation']['material_qualified'] is False,'source remains unqualified')
 seed,approach,shifted,coarse,fine=trials
 ck(seed['initial']==origin and seed['prefix'] is None and seed['status']=='numerical_failure','original failed seed retained')
 ck(shifted['initial']==approach['reference']['states'][-1] and shifted['start']==approach['end'] and shifted['end']==seed['end'],'shifted path starts at actual reference endpoint')
 clock=r['root_refinement']['clock'];tol=clock['time_absolute_s'];ck(tol==F(r['event_policy']['time_absolute_s']),'unchanged clock tolerance')
 ck(clock['choices']==[r['proposal']['choice'],r['shifted_proposal']['choice']] and clock['starts']==[seed['start'],shifted['start']],'clock binds two original proposals')
 actual_intervals=[]
 for c,at,savedroot,additional,savedinterval in zip(clock['choices'],clock['starts'],clock['refined_roots'],clock['additional_rounds'],clock['intervals']):
  order=c['order'];ck(order['complete'] and order['status']=='ordered' and order['earliest_labels']==[['liquid',0,0]] and len(order['polynomials'])==4,'all N1 four competitors same first liquid')
  remaining=order['maximum_refinements']-order['refinement_level']-c['additional_refinement_rounds'];lo,hi,used=refine(c['selected_root'],remaining,tol)
  ck((savedroot['lower'],savedroot['upper'],additional)==(lo,hi,used),'independent remaining bisection')
  ck(used+order['refinement_level']+c['additional_refinement_rounds']<=order['maximum_refinements']<=256,'shared cap no reset')
  absolute=[at['seconds']+lo,at['seconds']+hi];ck(interval(savedinterval)==absolute,'absolute root interval');actual_intervals.append(absolute)
 A,B=actual_intervals;lo=max(F(),A[0]-B[1],B[0]-A[1]);hi=max(abs(A[0]-B[1]),abs(A[1]-B[0]));ck(clock['distance_lower_s']==lo and clock['distance_upper_s']==hi and clock['gate']==(hi<=tol),'conservative root time gate no Richardson')
 common=r['common_comparison'];end=r['requested_common_end'];ck(coarse['end']==fine['end']==common['common_end']==end,'same actual common endpoint')
 ck(coarse['initial']==origin and coarse['start']==seed['start'] and fine['initial']==approach['reference']['states'][-1] and fine['start']==approach['end'],'coarse vs partitioned complete connection')
 lower=min(A[0],B[0]);startfine=shifted['start']['seconds'];fraction=F(r['event_policy']['safe_inventory_fraction']);desired=min(fraction*(lower-startfine),F(seed['policy']['maximum_step_s']),shifted['end']['seconds']-startfine);d=float(desired)
 if F(d)>desired:d=math.nextafter(d,-math.inf)
 ck(end['seconds']==startfine+F(d) and startfine<end['seconds']<lower and F(d)>=F(seed['policy']['minimum_step_s']),'common target exact/downward/original caps')
 for c,at in zip(clock['choices'],clock['starts']):
  h=end['seconds']-at['seconds'];ck(all(minimum(p,h)[0]>0 for p in c['order']['polynomials']),'all inventories positive to common end')
 rows=[joined((coarse,)),joined((approach,fine))];ck(common['cumulative_residuals']==rows,'all retained original-origin cumulative rows')
 for t in (coarse,fine):
  ck(t['captures'][-1]['state']==t['reference']['states'][-1] and t['captures'][-1]['time']==end,'actual common reference endpoint')
 ca,cb=coarse['captures'][-1],fine['captures'][-1];dif=common['differences'];ck(dif['samples'][0]['state']==ca['state'] and dif['samples'][1]['state']==cb['state'],'common sampled states')
 maxima=[F(),F(),F(),F()];conditional=[]
 for i in range(len(origin['amounts_mol'])):
  nd=[abs(F(a)-F(b)) for a,b in zip(ca['state']['amounts_mol'][i],cb['state']['amounts_mol'][i])];ud=abs(F(ca['state']['internal_energy_j'][i])-F(cb['state']['internal_energy_j'][i]));points=[];radii=[]
  for c,bound in zip((ca,cb),r['common_pressure_pairs'][i]):
   inv=c['evaluation']['source_evaluation']['cells'][i]['inverse'];p=inv['point'];m=p['fluid']['mechanical'];T,eT,P,eP=map(F,(m['temperature_k'],inv['temperature_error_bound_k'],m['pressure_pa'],p['pressure_error_pa']));points.append((T,eT,P,eP));co=bound['continuation'];nl=F(c['state']['amounts_mol'][i][0]);ng=sum(map(F,c['state']['amounts_mol'][i][1:]),F());R=F(m['gas_constant_j_mol_k']);B=F(p['fluid']['envelope']['liquid_abs_du_dp_bound_j_mol_pa'])
   ck(co['inputs']==[nl,ng,R,B,T,eT,P,eP],'common conditional original inputs')
   if co['status']=='conditional_pressure_enclosure':
    tmin=co['temperature_domain_k'][0];pmax=co['pressure_domain_pa'][1];L=pmax/tmin*(1+nl*B*pmax/(ng*R*tmin));g=eP+L*eT;L2=(P+g)/(T-eT)*(1+nl*B*(P+g)/(ng*R*(T-eT)));radius=eP+L2*eT;ck(co['global_radius_pa']==g and co['radius_pa']==radius,'independent conditional radius');radii.append(radius)
   else:radii.append(None)
  a,b=points;tb=abs(a[0]-b[0])+a[1]+b[1];pb=abs(a[2]-b[2])+a[3]+b[3];ck(dif['amount_differences_mol'][i]==nd and dif['energy_differences_j'][i]==ud and dif['temperature_bounds_k'][i]==tb and dif['reported_pressure_bounds_pa'][i]==pb,'independent common differences')
  maxima=[max(x,y) for x,y in zip(maxima,(max(nd),ud,tb,pb))];conditional.append(abs(a[2]-b[2])+sum(radii,F()) if all(x is not None for x in radii) else None)
 limits=[r['event_policy'][k] for k in ('amount_absolute_mol','energy_absolute_j','temperature_absolute_k','pressure_absolute_pa')];gates=[x<=F(y) for x,y in zip(maxima,limits)];ck(common['gates']==gates and dif['maxima']==maxima,'original four endpoint gates')
 ck(common['conditional_pressure_bounds_pa']==conditional,'conditional pair bound');gate=max(conditional)<=F(limits[-1]) if all(x is not None for x in conditional) else None;ck(common['conditional_pressure_gate']==gate,'original conditional P gate')
 ck(r['event_admitted'] is r['material_qualified'] is common['event_admitted'] is common['material_qualified'] is False,'no event/material admission')
 summary.update(status='passed',checks=checks,elapsed_s=time.monotonic()-start,actual_callbacks=len(caps),absolute_intervals=[[str(x) for x in row] for row in actual_intervals],root_time_upper_s=float(hi),root_time_gate=clock['gate'],common_end_s=float(end['seconds']),common_maxima=[float(x) for x in maxima],common_gates=gates,conditional_pressure_bounds=[None if x is None else float(x) for x in conditional],conditional_pressure_gate=gate,cumulative_prefixes=[len(x) for x in rows],scope='Saved partitioned-surrogate and positive-common-reference evidence; no EOS or event-time/state accuracy claim');return summary
if __name__=='__main__':
 result=run(Path(sys.argv[1]),sys.argv[2]);OUT.joinpath('SAVED_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
