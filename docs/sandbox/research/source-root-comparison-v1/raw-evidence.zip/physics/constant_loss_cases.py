"""Exact arithmetic examples only; not actual source observations."""
from fractions import Fraction as F
from pathlib import Path
import json
rows=[]
for H,a,expect in ((F(3,2),F(1,4),True),(F(19,10),F(1,4),False),(F(3,2),F(3,4),False)):
 original_mid=1-H/2;approach=1-a;shifted_mid=approach-(H-a)/2
 assert original_mid>0 and approach>0 and (shifted_mid>0)==expect
 rows.append({'H':str(H),'a':str(a),'original_mid_inventory':str(original_mid),'approach_inventory':str(approach),'shifted_mid_inventory':str(shifted_mid),'new_actual_midpoint_can_be_positive_under_constant_loss':expect})
# Same exact root at absolute1 despite distinct local starts.
assert F(1,4)+F(3,4)==1
result={'status':'passed','cases':rows,'scope':'Constant-loss arithmetic illustrating possible and impossible shifted midpoint; no EOS.'}
Path(__file__).with_name('CASES.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
