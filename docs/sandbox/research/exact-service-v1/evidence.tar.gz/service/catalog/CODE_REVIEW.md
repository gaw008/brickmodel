# Independent exact-event catalog review

Reviewed catalog SHA256 `e630bb963c72fa391c39e7990aca5b569ec3cbcd249985a00d23e64c78f354ee`, construction/check scripts, NOTES, all revised numerical entries and inherited source classifications against the current legacy event catalog and actual exact implementations. No source edits, model construction or EOS.

Independent execution of the existing production pure build_graph/query_graph checks against the retained fixture passed **27 equations / 7 quantity roots**. `independent-graph-review.json` retains the result. All 18 inherited physical/initialization entries equal their old objects, including sources, classifications, domains and omissions. All referenced implementation files in the fixture match actual current source bytes. All AST symbols and JSON pointers resolve, and every result root reaches the exact semantic clock branch. No obsolete single-event depletion/clock/record anchor remains; the ordinary Rates derivative anchor remains legitimate.

Rational equality/display distinction, equal-half SSPRK2 error control, ordered strictly separated numerical first roots, whole-panel positivity, local signed writeback/gross denominator, full event/common comparison, original-level-zero controls and both independent approach controls match the inspected code. Fresh admission invokes the four actual auditors and restore against original inputs and strict execution runtime. It preserves authoritative recorded telemetry rather than claiming independent reconstruction of every discarded RHS call or historical wall. The graph correctly labels these as numerical policy and explicitly does not qualify a material, physical nonlinear root, convergence study or furnace cycle. Paired-pressure assumptions remain an explicit manufactured shared-constant family, with independent pressure errors retained.

The seven quantity roots retain sensible output/storage/geometry/free-force branches. accepted-output-reconstruction anchors the actual existing exact host evaluate and total-energy inverse, not a fictional future service helper. The graph fixture is a locator fixture only; its availability is not a new case-parser/native acceptance result. Bibliographic source availability is not independent applicability validation.

[MEDIUM] Clarify codec versus restored ledger identity.
File: catalog equation `depletion-record-audit`, expression.
“Canonical typed records retain ... shared ledger aliases” overstates what the strict codec does. It retains complete ledger values; `restore_exact_projection` reconstructs shared committed-ledger object identity. Recommend explicitly distinguishing these two operations and adding the restore symbol to this node's anchors. The existing continuation node already anchors restore, and this wording issue does not alter execution or scientific gates. Reported to root before finalization.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 1 | info |
| LOW | 0 | pass |

Verdict: APPROVE with the bounded codec/restore wording correction recommended. No material qualification or service execution approval is implied by this graph review.

Final wording correction reviewed at catalog SHA `04da3c784a8b6bc7fcbb1a047c592c507c55503dc991c97db56214f17caecf46`: the record node now says complete ledger values are saved and object aliases are separately reconstructed by restore_exact_projection; the actual restore symbol is explicitly anchored. This resolves the sole medium finding without changing physical entries or scientific gates. Final disposition APPROVE, no open findings in this bounded graph review.
