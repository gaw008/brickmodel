# Dedicated exact-event catalog handoff

Frozen catalog SHA e630bb963c72fa391c39e7990aca5b569ec3cbcd249985a00d23e64c78f354ee.
Catalog ID free-wet-exact-event-slab-equations-v1; model manufactured_reacting_wet_free_slab_v1; case schema sludge_sandbox_free_exact_event_case_v1. Validation fixture declares sandbox_exact_depletion_policy_v1 with ordered_affine_packet_v1. This fixture exercises graph binding only, not the separate case parser under development.

27 equations,7 original quantity roots.18 original physical/initialization equations and their source declarations/classifications are byte-value identical to the existing event catalog. Four numerical/output entries are replaced; five explicit rational-clock/root-order/panel/comparison/admission entries are added. All quantity roots reach the exact-clock and new accepted-time branch; no old depletion_integration/affine_depletion_clock/event_record navigation anchors remain. Ordinary Rates.derivatives retains its legitimate integration.py anchor.

The current actual exact_free_host.evaluate anchors final reconstruction rather than an unimplemented future service snapshot symbol. Service author may add a verified exact snapshot wrapper anchor only when its code is frozen and AST-resolved. No anchor to proposed service code is manufactured.

Pure check command: PYTHONPATH=src /private/tmp/brick-water-backend-probe/venv/bin/python /private/tmp/brick-exact-service-v1/catalog/check_graph.py. Actual check01.log: passed27 equations/7 roots. build_graph and query_graph use current production provenance code, actual source ASTs and actual JSON pointers. All declared source assets were present in the local fixture; this proves file/locator availability, not new scientific applicability. No model construction or EOS invocation. Source assets were copied only into this private temporary fixture, not proposed for public distribution.

Output edges remain: temperature/pressure→accepted-output-reconstruction; amounts/stretch→accepted-time-update; energy→accepted-time-update+total-storage; geometry→accepted-output-reconstruction+current-geometry; free→accepted-output-reconstruction+free-traction-closure+mechanical-power. Numerical admission definitions are prerequisite algorithm declarations in the DAG, not a claim that a saved hash or any single partial auditor grants continuation. Actual continuation invokes all four gates against original inputs and same runtime.

Coincident/unresolved roots, nonlinear physical root error and whole-material/firing-cycle validity remain explicitly outside the graph certificate. Original independent pressure error remains distinct from conditional manufactured shared-constant-box paired pressure evidence.
