"""Pure source/JSON/AST graph checks; no model construction or EOS."""
from pathlib import Path
import json,hashlib,shutil
from sludge_sandbox.run_provenance import build_graph,query_graph,evidence_paths
ROOT=Path(__file__).parent
REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')
cat=json.loads((ROOT/'free-wet-exact-event-slab-equations-v1.json').read_text())
base=json.loads((REPO/'src/sludge_sandbox/catalogs/free-wet-event-slab-equations-v1.json').read_text())
work=ROOT/'graph-fixture';work.mkdir(exist_ok=False)
case=json.loads(Path('/private/tmp/brick-exact-record-native-v1/attempt01/case.json').read_text())
case['schema']='sludge_sandbox_free_exact_event_case_v1'
case['numerics']['depletion']['schema']='sandbox_exact_depletion_policy_v1'
case['numerics']['depletion']['ordered_event_policy']='ordered_affine_packet_v1'
(work/'case.json').write_text(json.dumps(case,indent=2)+'\n')
(work/'implementation').mkdir()
for f in (REPO/'src/sludge_sandbox').glob('*.py'):shutil.copyfile(f,work/'implementation'/f.name)
(work/'water').mkdir()
for f in Path('/private/tmp/brick-free-native-events-v1/attempt01/water').iterdir():
 if f.is_file():shutil.copyfile(f,work/'water'/f.name)
for name in evidence_paths(cat):
 source=REPO/'data/sandbox'/name
 if source.is_file():
  target=work/'evidence'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
(work/'equation_catalog.json').write_text(json.dumps(cat,indent=2)+'\n')
# Physical equations and their original source IDs/classifications remain exact.
changed={'accepted-time-update','accepted-output-reconstruction','depletion-writeback','depletion-record-audit'}
new={e['id']:e for e in cat['equations']}
for e in base['equations']:
 if e['id'] not in changed:assert new[e['id']]==e
assert cat['result_roots']==base['result_roots']
graph=build_graph(work,cat)
artifacts={str(f.relative_to(work)):hashlib.sha256(f.read_bytes()).hexdigest() for f in work.rglob('*') if f.is_file()}
queries={q:query_graph(graph,q,artifacts=artifacts) for q in cat['result_roots']}
assert all('equation:exact-clock' in {n['id'] for n in g['nodes']} for g in queries.values())
legacy={'depletion_integration.py','affine_depletion_clock.py','event_record.py'}
assert not any(Path(a['path']).name in legacy for e in cat['equations'] for a in e['implemented_at'])
(ROOT/'graph.json').write_text(json.dumps(graph,indent=2)+'\n')
report={'status':'passed','equations':len(cat['equations']),'roots':list(queries),'preserved_physical_equations':len(base['equations'])-len(changed),'source_availability':{n['id']:n['availability'] for n in graph['nodes'] if n['node_type']=='source'},'catalog_sha256':hashlib.sha256((ROOT/'free-wet-exact-event-slab-equations-v1.json').read_bytes()).hexdigest(),'scope':'Pure declared graph, AST anchors and JSON pointers; not case-builder/native/material validation.'}
(ROOT/'graph-check-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'],report['equations'],len(queries),report['catalog_sha256'])
