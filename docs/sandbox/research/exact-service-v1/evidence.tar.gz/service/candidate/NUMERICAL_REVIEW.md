# Exact service numerical/lifecycle review

Disposition: APPROVE for the declared exact manufactured service route. No new numerical or lifecycle blocker found in the frozen implementation. This is source review, not an actual native service lifecycle validation.

Reviewed FREEZE.json: all eight artifact hashes independently matched; all six Python files parsed. Main adapter exact_run_service.py is 643511f3bedf95cc5fe4cd01b9949ad8bda454b10ac66b23abff4d86b9d4eeca; run_service.py is 7ccb68a9d66e7de13465fc41f5acde51b5c354d497677c79468f0890924562b2; portable tests are 7967706ea1d42b33414d20410175e6b3202bebdec8de989461f86ee78f84e641. Git Python diff was empty at review time. Ruff, mypy, pylint and black are unavailable in the selected environment. No tests or EOS calls were repeated by this reviewer.

## Original inputs and continuation

The shared service copies the exact parent bytes, verifies result/manifest hashes and the complete copied implementation/water/evidence membership, and binds the current runtime and selected catalog. checked_parent additionally validates the canonical record against the rebuilt actual original operator, exact original start/end, initial state and both complete policies. This comparison occurs before a new integration callback. The canonical bytes/hash, not the presentation, form ExactContinuationRequest.

The core receives the ORIGINAL initial state, original full interval and original full policies on resume. The existing reviewed continuation admission supplies four fresh audits and cumulative costs/ledger state. The service never merges the returned full history a second time: it stores that complete result directly and exposes the original-prefix boundary separately. It does not subtract a wall budget and then let core subtract it again. Repeated-resume tests check prefix preservation and monotone cumulative elapsed time; the numerical accounting proof remains the actual core audits, not those simple assertions.

Replay validates the saved original binding but passes no continuation request, so it performs a new full run from the freshly reconstructed original initial state. Neither replay nor resume treats float display clocks as solver authority.

## Exact clocks and evidence

Canonical record bytes retain the typed rational clocks and full numerical evidence. The plot presentation has elapsed float times only, plus separately labelled absolute numerator/denominator strings, without sorting or deduplication. The final snapshot evaluates the actual final-mode ExactFreeWaterTransfer at the actual ExactEventTime; it does not convert that callback query to a float. Its serialization helper consumes that already evaluated result rather than repeating thermal inversion.

export_run rechecks the canonical artifact hash and transports its UTF-8 JSON as an opaque string. The local export route shares this implementation and does not impose the preview-size cap. Thus the canonical JSON integers are not coerced by a JSON client into numeric fields of the enclosing export. This is a result/manifest/record export, explicitly not a standalone source/replay bundle.

## Audits, failure and cancellation

The raw core projection and canonical bytes are saved before the four output audits. Each real audit receives the original state/interval/policies/case/runtime appropriate to its existing API; resource audit consumes the canonical original policy. Each returned record SHA must match. Reports are serialized using the general verification encoder, avoiding the strict codec's unsupported-report-class problem.

A later audit or snapshot exception becomes a failed service result while retaining raw canonical output and the underlying core status/reason; already written audit reports are retained. Cancellation with an accepted prefix is canonically represented and audited. Preparation failures may have no canonical record and cannot acquire an accepted integration presentation. Resume requires both a cancelled service/core prefix and, in checked_parent, the actual canonical cancel_requested reason and a nonterminal accepted ledger.

read_run performs canonical-to-presentation/policy/state/report-file association checks; it deliberately does not claim that a caller-resealed audit report is a new live numerical authorization. Fresh core admission, not read_run metadata, authorizes continuation. A completed service result requires all four associated reports and a completed canonical core.

## Policy and limits

The new case/policy schemas require explicit exact ordering, the existing affine method and a non-reused nested approach. Legacy schema defaults remain separate. An explicit pressure_comparison:null invokes the original independent comparison gate; a missing key is rejected. The catalog correctly makes paired certificates conditional, and no tolerance, material coefficient or physical envelope is changed by this service adapter.

The portable service tests instrument the physical host, snapshot extraction and portions of proof bindings. They substantiate service control flow, byte retention, repeated resume, tamper rejection and exact query dispatch; they do not establish an actual wet EOS service run or a real browser lifecycle. Native run/cancel/resume/replay, real final snapshot serialization and browser handling of coincident display times remain prospective validation. This review does not claim full spatial convergence, a real sludge material package, or full-cycle firing validation.
