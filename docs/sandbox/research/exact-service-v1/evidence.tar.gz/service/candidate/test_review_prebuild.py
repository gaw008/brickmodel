from test_exact_run_service import app
import sludge_sandbox.run_service as service

def test_review_prebuild_cancel_does_not_publish_parent_as_current(app,tmp_path):
    case,water,_,_=app;flag=[False]
    parent=service.run_case(case,water,tmp_path/'parent',cancel=lambda:flag[0],_exact_on_commit=lambda info:flag.__setitem__(0,True))
    assert parent['status']=='cancelled' and parent['integration']['steps']
    result=service.resume_run(tmp_path/'parent',tmp_path/'child',cancel=lambda:True)
    assert result['status']=='cancelled' and result['reason']=='cancelled_before_build'
    assert result.get('integration') is None
    service.read_run(tmp_path/'child')
