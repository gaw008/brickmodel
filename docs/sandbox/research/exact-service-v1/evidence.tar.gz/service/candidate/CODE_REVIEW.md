# Independent exact service code review

Initial frozen snapshot reviewed: run_service 7ccb68a9, exact_run_service 643511f3, verification_case 8081d357, run_provenance 56d7f444, local_app 92268be1; full hashes are in the original FREEZE.json. Read complete new helper/tests, all five source diffs, relevant old run/manifest/trace/codec/continuation paths, sample and catalog. No production edits, installation or EOS. Final approval pending the prebuild failure fix below.

[HIGH] Prebuild cancellation/failure of exact resume publishes the parent's presentation as the child's current integration.
The generic _resume preparation copies parent['integration'] before run_exact_event gets an opportunity to reset it. Cancellation before build therefore returns a child with old accepted history but no child canonical record; read_run's strict association also rejects that child. The same issue applies to earlier build/source-copy failures. Independent `test_review_prebuild.py` produced **1 failed, 17 deselected in 1.00 s**, retained in `review-prebuild-red.log`. Keep exact child integration=None from initial preparation until its own core record exists, while retaining the complete parent files separately. Legacy resume behavior should remain unchanged. Reported to root and author; no workaround/native run performed.

## Verified contracts and bounds

The case route is explicitly separate from legacy ordinary/event schemas. Exact policy requires ordered packet mode, nested controls with no spine reuse, and an explicit pressure_comparison key (null is an intentional independent-bound choice). The sample differs from the old source only in schema/case ID, exact policy schema, ordered declaration and reuse_ordinary_spine=false; physical numbers, original budgets and six gates are unchanged.

Parent canonical/result/manifest bytes are captured with hashes; source-copy membership, full runtime, selected catalog, original state/time and policies bind before the core continuation. Fresh core admission reruns all four audits and restores actual modes/ledger aliases. Presentation elapsed floats are never resume inputs; the returned history is already cumulative and not merged again. Runtime compatibility is strict same-version execution, not the historical read-only verifier allowance.

Canonical and full projected core evidence persist before post-audits and final diagnostic reconstruction. Successful earlier audit files survive a later failure, and core status is kept separate from service failure. read_run associates strict record/presentation with type-preserving pack equality, original/final conserved states, policy containers, projected core, audit files and SHA links. This is structural/content consistency, not authentication or fresh numerical approval; actual resume still performs the four audits. Saved final T/P diagnostic values are not independently recomputed by read_run.

Final snapshot queries the actual final mode operator at ExactEventTime and reuses the existing diagnostic serializer after that evaluation, avoiding another inverse or display-time projection. The initial snapshot uses the original case's binary64 initial-time input. No future/nonexistent implementation symbol is invented. Missing final diagnostics retain the established unavailable trace semantics, rather than treating accepted-prefix values as completed output.

Verified export wraps the complete canonical JSON as an opaque text field; it is not parsed into JavaScript numbers and is not subject to the source-preview cap. It explicitly does not bundle all replay inputs. Local JobManager delegates export to that service path; old export result/manifest shape remains. UI display-collision labeling and native/browser lifecycle tests remain separate outstanding evidence, not proved by these pure service tests.

The corrected catalog's 04da3c78 record node explicitly distinguishes saved ledger values from restore-created object aliases. The earlier medium wording finding is resolved; physical source classifications and material limitations remain unchanged.

Tests are instrumented service/core tests with no water EOS: builder and final diagnostic/geometry qualification are stubbed, while core/strict codec/four audit paths run. The independent-pressure fixture does not establish the actual paired-water branch. Parent-reported broad 70-pass runs were inspected as evidence but do not replace the independent negative control above.

## Final pre-build fix review

Reviewed final run_service.py SHA256 4ae72fef273dea32392a90e6a3b0ca7db94529af3b1573333f6f41df55ce1d08 and portable test SHA256 f02f3e84d58124d231c0bc164fdd711d72e3070f86eefbb46444df5156b575ca. The sole source delta leaves exact child integration absent until a child canonical record is produced; legacy history initialization is unchanged. Parent evidence remains copied and bound separately. This closes the reported HIGH: early cancellation or build failure no longer presents inherited parent integration as a child result without canonical evidence.

Independent final pure run of the complete exact service test file plus the retained reviewer pre-build cancellation attack: 20 passed in 36.18s (review-final-tests.log). The original actual failing attack remains in review-prebuild-red.log; author before-prebuild-fix and prebuild-red evidence also remain. These are instrumented no-EOS service tests, not native service validation. Previously reviewed source, catalog, strict canonical association and audit boundaries remain unchanged.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE for the explicit exact service candidate. Actual native lifecycle validation remains a separate execution gate.
