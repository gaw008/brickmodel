# Exact shared-service candidate — frozen for independent review

The explicit exact service route is implemented in temporary candidates only. No repository changes, installation, native EOS, or real trajectory runs were performed. `FREEZE.json` lists all final hashes.

## Application files

- `run_service.py`, `exact_run_service.py`, `verification_case.py`, `run_provenance.py`, `local_app.py` → same filenames under `src/sludge_sandbox/`.
- `test_exact_run_service.py` → `tests/sandbox/test_exact_run_service.py` (formal imports, repository root from file parents; no temporary imports).
- `reacting-wet-free-exact-events-v1.json` → `data/sandbox/cases/reacting-wet-free-exact-events-v1.json`.
- Independently authored `../catalog/free-wet-exact-event-slab-equations-v1.json` → `src/sludge_sandbox/catalogs/`.

Old modules are retained as baseline copies and four focused patches accompany modified modules. New sample differs from the original paired endpoint-root case only in case ID/schema, explicit exact policy schema, ordered-event declaration, and explicitly disabling ordinary-spine reuse. Physical settings, all six gates and original budgets are unchanged. New identity must be rebuilt; this is not relabeling historical native records.

## Contract

New case schema: `sludge_sandbox_free_exact_event_case_v1`; policy `sandbox_exact_depletion_policy_v1`. `ordered_event_policy='ordered_affine_packet_v1'`, nonempty nested approach and `reuse_ordinary_spine=false` are explicit. `pressure_comparison` is a required key: either the existing actual shared-constant declaration or explicit `null`, selecting the core's existing independent pressure bound. It never silently falls back between policies. The sample retains its paired declaration; pure service fixtures explicitly choose independent bounds.

`run_case`, `resume_run`, `replay_run`, `read_run`, `trace_run` are the same shared service entry points used by existing CLI/supervisor/UI. Defaults remain on their original paths. An immutable `ExactParent` carries canonical parent bytes and externally verified result/manifest/record hashes. All copied source memberships, runtime before/after, case, scalar policies and freshly rebuilt original state are checked; core continuation then repeats all four full admission audits. No saved providers, display clocks, partial reports or arbitrary commands are execution inputs. Core returns one complete cumulative history; no suffix merge occurs.

Exact runs save `exact-core-projection.json` and authoritative `exact-run-record.json` before postchecks/diagnostics. Earlier successful audit reports survive later audit failure. `core_status/core_reason` remain distinct from service diagnostic failures. Final snapshots evaluate the actual final mode operator at the actual `ExactEventTime`, then use the shared existing diagnostic serialization without another inverse or float-time query.

`integration` is deliberately labeled `exact_core_presentation_v1`: elapsed display floats plus exact absolute rational strings, plain conserved states, step-boundary summaries and cumulative counts. It is never resume authority. `read_run` reparses canonical bytes and strictly binds presentation types/values, policies, initial/final conserved states, raw projection, core status and saved audit files; removing the kind marker cannot bypass this association. This is local integrity and structural association, not artifact authentication or a replacement for live four-audit admission.

`trace_run` retains existing quantities and adds actual exact numerical/physical anchors, canonical record SHA, canonical conserved-value pointer, and the dedicated equation graph. Missing final snapshot remains unavailable; it does not substitute accepted-prefix values as final output. Shared constant and independent pressure branches are labeled separately in the catalog.

`export_run` and `JobManager.export` return a verified canonical JSON **text string**, preserving large rational integers without JS Number conversion. This export bypasses the independent source-preview byte cap. It includes result+manifest, not every referenced input/source artifact, and explicitly says it is not a standalone replay directory. Old exports keep their existing result+manifest shape.

Private `_exact_on_commit` on run/resume enables deterministic cooperative cancellation after a real global commit for bounded native tests. It forwards the core's immutable numeric notification and does not change numerical gates.

## Actual validation

Final command (temporary coherent package overlay only):

```
/private/tmp/brick-water-backend-probe/venv/bin/python /private/tmp/brick-exact-service-v1/candidate/run_tests.py -q /private/tmp/brick-exact-service-v1/candidate/test_exact_run_service.py tests/sandbox/test_event_run_service.py tests/sandbox/test_run_service.py tests/sandbox/test_partial_run_trace.py
```

`tests07-portable.log`: **70 passed in 37.78 s**. Tests cover explicit schema/old schema, full canonical run/replay/trace, repeated resume with exact parent records and original history/costs, live initial mismatch with zero solver callbacks, resealed display/type/kind/policy/initial-state attacks, canonical removal, failed post-audit/snapshot retention, null-vs-missing policy, actual exact snapshot query dispatch, and verified local-manager export unaffected by preview cap.

The service fixture uses real core/codec/all four audits and actual source-bound typed numerical shells. Builder, native RHS and geometry/observation diagnostic seams are explicitly instrumented; it is not a water EOS oracle or proof of a real material. The fixture's independent pressure comparison is explicit and does not claim paired endpoint certificates.

`tests01.log` retains initial wrong policy-decoder and missing explicit spine declaration failures. `tests03/04` retained a legacy trace test conflict also independently reproduced on original source (`baseline-diagnostic-test.log`); root updated only that old test to the established no-final-snapshot→unavailable contract. Final production trace behavior was not weakened. `tests05.log` retained 22 sandbox localhost-bind permission errors from broad preexisting HTTP tests; 22 relevant tests passed. Final tests exercise the actual local manager export directly without launching a network server.

## Remaining real validation

No native exact **service** lifecycle or browser HTTP lifecycle has been run on these new module/catalog identities. Root should rebuild a fresh same-version parent and conduct bounded service cancellation/resume/replay, never use historical older-runtime execution compatibility. Existing generic UI receives display values and lossless export, but browser tests for near-time display collisions, explicit elapsed-axis labeling and inspectable exact-clock metadata remain outstanding. No UI styling or new material admission is claimed. Current charts must not deduplicate colliding displayed clocks or feed them back into physics.

## Prebuild exact resume correction
Reviewer HIGH reproduced in both prebuild cancellation and build exception: original code copied parent integration presentation without a child canonical record. Original source, portable tests and FREEZE retained in before-prebuild-fix/. New portable tests produced prebuild-red.log: 2 failed, 17 deselected. Exact-only assignment now keeps integration=None until canonical child output exists; historical parent raw record/result retained. Legacy assignment unchanged. Regression prebuild-green.log: 76 passed in 37.72s (exact service, legacy run_service, checkpoint, partial trace). No EOS/install. Updated hashes in FREEZE.json.
