from pathlib import Path
import shutil
import sys
HERE=Path(__file__).parent
ROOT=Path.cwd()
package=HERE/'overlay'/'sludge_sandbox';package.mkdir(parents=True,exist_ok=True)
for source in (ROOT/'src/sludge_sandbox').glob('*.py'):shutil.copyfile(source,package/source.name)
shutil.copytree(ROOT/'src/sludge_sandbox/catalogs',package/'catalogs',dirs_exist_ok=True)
for name in ('run_service.py','verification_case.py','run_provenance.py','exact_run_service.py','local_app.py'):shutil.copyfile(HERE/name,package/name)
shutil.copyfile(HERE.parent/'catalog/free-wet-exact-event-slab-equations-v1.json',package/'catalogs/free-wet-exact-event-slab-equations-v1.json')
sys.path.insert(0,str(package.parent));sys.path.insert(1,str(ROOT/'tests/sandbox'))
import sludge_sandbox.run_service
import pytest
args=sys.argv[1:]
portable=HERE/'test_exact_run_service.py'
if str(portable) in args:
    workspace=HERE/'test_workspace'
    target=workspace/'tests/sandbox/test_exact_run_service.py';target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(portable,target)
    fixture='reacting-wet-free-paired-events-endpoint-root-v1.json'
    data=workspace/'data/sandbox/cases';data.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/'data/sandbox/cases'/fixture,data/fixture)
    args=[str(target) if x==str(portable) else x for x in args]
raise SystemExit(pytest.main(args))
