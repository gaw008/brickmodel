"""Isolated subprocess-only candidate wiring; permanent test has normal imports."""
import importlib.util,sys
from pathlib import Path
import sludge_sandbox
import pytest
p=Path(__file__).parent
name='sludge_sandbox.depletion_integration'
spec=importlib.util.spec_from_file_location(name,p/'depletion_integration.py')
m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
sludge_sandbox.depletion_integration=m
raise SystemExit(pytest.main([str(p/'test_depletion_failure_evidence.py'),'-q']))
