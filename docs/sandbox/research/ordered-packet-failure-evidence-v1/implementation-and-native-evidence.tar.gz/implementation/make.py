from pathlib import Path
p=Path('/private/tmp/brick-ordered-packet-failure-evidence-v1')
s=(p/'before.py').read_text()
old='''            raw,record,path.totals=depletion_writeback(raw,cell_index=cell,liquid_index=li,vapor_index=vi,
                panel_liquid_start_mol=float(state.amounts_mol[cell,li]),
                panel_liquid_terms_mol=(float(fn[cell,li]),-float(fn[cell+1,li]),float(rn[cell,li])),
                positive_evaporated_mol=evap,policy=ep.roundoff_policy,totals=path.totals,clock_evidence=clock)'''
new='''            try:
                raw,record,path.totals=depletion_writeback(raw,cell_index=cell,liquid_index=li,vapor_index=vi,
                    panel_liquid_start_mol=float(state.amounts_mol[cell,li]),
                    panel_liquid_terms_mol=(float(fn[cell,li]),-float(fn[cell+1,li]),float(rn[cell,li])),
                    positive_evaporated_mol=evap,policy=ep.roundoff_policy,totals=path.totals,clock_evidence=clock)
            except DepletionRoundoffError as exc:
                if ordered:
                    # Data already evaluated on this speculative branch; no provider
                    # or validation callback is invoked to manufacture diagnostics.
                    try:
                        exc.ordered_failure_evidence=_snapshot_failure_diagnostic({
                        'schema':'ordered_affine_writeback_failure_v1',
                        'qualification':'uncommitted_numerical_terminal_diagnostic',
                        'reason':str(exc),'cell_index':cell,'liquid_index':li,'vapor_index':vi,
                        'initial_state':state,'raw_state':raw,'clock':clock,
                        'midpoint_state':predictor,'initial_observation':obs,'midpoint_observation':middle,
                        'signed_liquid_terms_mol':(float(fn[cell,li]),-float(fn[cell+1,li]),float(rn[cell,li])),
                        'integrated_fields':dict(zip(('face_species_mol','face_energy_j','reaction_species_mol','cell_work_j'),fields)),
                        'exact_positive_evaporated_mol':gross,'positive_evaporated_mol':evap,
                        'stretch_increment':stretch_increment,'stretch_quadrature_roundoff':stretch_rounding,
                        'roundoff_policy':ep.roundoff_policy,'totals_before':path.totals,
                        'root_order':path.pending_order,'previous_uncommitted_frames':tuple(path.packet_frames),
                        'process_local_source_binding':binding})
                    except (DepletionIntegrationError,TypeError,ValueError,OverflowError,RecursionError) as capture_error:
                        exc.ordered_failure_evidence=MappingProxyType({
                            'schema':'ordered_affine_writeback_failure_v1','available':False,
                            'reason':str(exc),'capture_error':type(capture_error).__name__+': '+str(capture_error)})
                raise'''
assert old in s;s=s.replace(old,new)
needle="                                phase_costs=frozen_costs(before_cost),approach_role='terminal_refinement' if nested else 'legacy',"
s=s.replace(needle,"                                comparison_details=({'writeback_failure':exc.ordered_failure_evidence} if hasattr(exc,'ordered_failure_evidence') else {}),\n"+needle,1)
needle='                                                time.monotonic()-independent_start,phase_costs=frozen_costs(independent_cost),'
s=s.replace(needle,needle+"\n                                                comparison_details=({'writeback_failure':exc.ordered_failure_evidence} if hasattr(exc,'ordered_failure_evidence') else {}),")
s=s.replace('from dataclasses import dataclass,replace,field,fields','from dataclasses import dataclass,replace,field,fields,is_dataclass')
helper="""def _snapshot_failure_diagnostic(value):
    \"\"\"Detach already computed data without importing runtime builders.\"\"\"
    if isinstance(value,Fraction):
        return MappingProxyType({'numerator':value.numerator,'denominator':value.denominator})
    if is_dataclass(value) and not isinstance(value,type):
        return MappingProxyType({item.name:_snapshot_failure_diagnostic(getattr(value,item.name))
                                 for item in fields(value)})
    if isinstance(value,Mapping):
        return MappingProxyType({key:_snapshot_failure_diagnostic(item) for key,item in value.items()})
    if isinstance(value,np.ndarray):return _snapshot_failure_diagnostic(value.tolist())
    if isinstance(value,np.generic):return _snapshot_failure_diagnostic(value.item())
    if isinstance(value,(list,tuple)):return tuple(_snapshot_failure_diagnostic(item) for item in value)
    if value is None or type(value) in (str,int,float,bool):return value
    raise DepletionIntegrationError('unsupported_failure_diagnostic_type')


"""
s=s.replace('def _quadratic_inventory_minimum(',helper+'def _quadratic_inventory_minimum(')
(p/'depletion_integration.py').write_text(s)
