# Frozen failure diagnostic candidate

Core SHA256 a2cdd548419c1f1129dbfa33c10051c230daed0313f39d3c574c1a44dc0dbb31.
Permanent test SHA256 03e626e78ba8699ffa5e5a796cd18f39fe0e8deb69c0b04e9a79d0ab0d3dd10e.

No repository files were changed. Candidate patch is against before.py, the original ordered core. Only ordered affine writeback exceptions add comparison_details.writeback_failure to the existing failure refinement. No result schema or default field changes. The snapshot copies computed values to immutable containers using a local data-only converter, with no case-builder import or new provider call. An explicitly unavailable diagnostic preserves the original physical refusal if capture encounters a supported serialization error.

Actual tests:
- red.log: original source fails missing failure detail; default test passes.
- first.log: initial two-test candidate passes; subsequently root identified successful-path exc-scope bug absent from those tests.
- green01.log: extended tests catch unsupported NumPy scalar snapshot, masking original reason; fixed by np.generic scalar conversion and explicit capture-failure preservation.
- green03.log: four archived old/new tests pass, including full successful nonwall output and actual callback sequence parity.
- portable-green.log: four permanent production-import tests pass against isolated candidate wiring, 0.27 seconds. check_portable.py is evidence tooling only; do not copy it into the permanent suite.

The failure is produced by real manufactured integrator execution, without mocked writeback exceptions. Tests independently reconstruct signed liquid quadrature, complete raw N/E/stretch, constant positive evaporation integral and downward rounding, clock downward-root placement, original relative budget failure, retained global prefix, earlier uncommitted frame, and nested immutability. Successful packet and default-refusal controls exercise unchanged paths. A diagnostic-only TypeError injection verifies that capture cannot relabel the underlying refusal.

No native EOS or installed production test was executed by this author. Independent reviews requested from both existing reviewers; this document is not a claim of their approval. Root owns application and installed verification.
