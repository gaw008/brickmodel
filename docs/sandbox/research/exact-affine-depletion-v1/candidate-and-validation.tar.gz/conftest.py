"""Temporary loader only."""
import importlib.util,sys
from pathlib import Path
name='sludge_sandbox.exact_affine_depletion'
spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name('exact_affine_depletion.py'))
m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
