from pathlib import Path
p=Path('/private/tmp/brick-exact-affine-depletion-v1')
s=Path('/Users/wanggaoying/Desktop/brickmodel-github/src/sludge_sandbox/depletion_roundoff.py').read_text()
(p/'baseline-roundoff.py').write_text(s)
record=s[s.index('@dataclass(frozen=True)\nclass DepletionWritebackRecord:'):s.index('def _check_budgets(')]
record=record.replace('DepletionWritebackRecord','ExactDepletionWritebackRecord').replace('DepletionClockEvidence | AffineDepletionClockEvidence | None','ExactAffineEvidence | None').replace("'event_only_accounting_not_event_time_or_full_trajectory_verification'","'exact_clock_event_only_accounting_not_coupled_trajectory_verification'")
f=s[s.index('def depletion_writeback('):].replace('def depletion_writeback(', 'def exact_depletion_writeback(').replace('DepletionWritebackRecord(', 'ExactDepletionWritebackRecord(')
f=f.replace("    if liquid==0:\n        raise DepletionRoundoffError('no_positive_liquid_remainder')",'')
a=f.index('    clock_residual=Fraction(0)');b=f.index('    if delta>local+clock_residual:',a)
f=f[:a]+'''    if type(clock_evidence) is not ExactAffineEvidence:
        raise DepletionRoundoffError('explicit_exact_clock_evidence_required')
    clock_residual=clock_evidence.inventory_residual(start,terms)
    if clock_evidence.policy != policy or positive_evaporated_mol != clock_evidence.positive_evaporated_mol:
        raise DepletionRoundoffError('exact_clock_policy_or_evaporation_mismatch')
'''+f[b:]
f=f.replace('    vapor=float(state.amounts_mol[cell_index,vapor_index])','''    if liquid == 0:
        return state,None,totals
    vapor=float(state.amounts_mol[cell_index,vapor_index])''')
(p/'writeback-part.txt').write_text(record+f)
