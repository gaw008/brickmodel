# Exact-time SSPRK2 candidate

Frozen core: c225da066745682080a06b9af06ee80ca25f13e7dd128e52fba0c0665b726f0c
Frozen permanent tests: fc6e7ccf160906b9368694242759bc39d77b0b1b43f93988e420245b960fbaa5

Actual command: `PYTHONPATH=src /private/tmp/brick-water-backend-probe/venv/bin/python -m pytest /private/tmp/brick-exact-integration-v1/test_exact_integration.py -q`
Final: 16 passed in 4.73s (tests06.log). No repository edits, native EOS, installation, or commit by this author.

## Concrete interface

`integrate_exact(initial, operator, *, start_s: ExactEventTime, end_s: ExactEventTime, policy: IntegrationPolicy, breakpoints_s: tuple[ExactEventTime,...]=(), cancel=None)` returns an independent ExactIntegrationResult. Every callback receives ExactEventTime. Internal endpoints, midpoint construction, interval differences, SSP weights, and exact quadrature reference values use Fraction. No callback time is converted to binary64. Existing ConservedState/Rates schema, explicit error scales, inventory positivity, mechanical positivity, component schema, representation budgets, and operator validation are retained.

ExactStepLedger is a distinct class, not a subclass of StepLedger; its start_s/end_s are strictly ordered ExactEventTime objects. All physical integrated arrays remain binary64 with the original component and mechanical exact-roundoff ledgers. Result states and endpoints contain only accepted fine-path updates. Costs include operator evaluations, rejected trials, and explicit attempted_trials, including cancelled partial trials. No legacy event codec, service, or checkpoint/resume admission is provided by this module.

## Explicit numerical controller decisions

The next NOMINAL duration is selected by downward binary64 projection and immediately adopted as a Fraction. This controls denominator growth from repeated floating error-control factors. It does not project semantic absolute times or actual quadrature intervals; clipped steps and exact half-stages remain rational. This is an explicit controller difference, not a claim of byte-identical legacy numerical trajectories.

The original minimum_step_s is enforced on actual accepted candidate intervals, including clipped tails. If a proposed landing would leave a positive sub-minimum tail, the remaining span is planned as two equal admissible intervals, provided each is within the original min/max constraints. Otherwise the run refuses. Nothing skips the remaining time or lowers the minimum. Example 0→3 with maximum_step_s=float(.3) completes in eleven legal steps rather than dropping the exact leftover. A whole horizon shorter than the minimum explicitly fails.

SSPRK2 still accepts two half steps and uses the discarded full step for error estimation, validates each Euler stage and the accepted combination in the actual operator, and stages all N/E/component/mechanical cumulative checks before commit. Cancel/resource/domain/rejection behavior preserves the accepted prefix. As in the existing solver, arbitrary unexpected user callback exceptions propagate; declared DomainExit and IntegrationError have structured outcomes. Wall limits are cooperative between callbacks and do not interrupt a blocking native function.

## Actual verification and preserved failures

- tests01: seven failures from an invalid test component name; fixed to an admitted mechanical_constraint component.
- tests02: eight passes; tests03: thirteen passes.
- tests04: fourteen passes and a genuine 30-second wall-limit failure in nonlinear positivity work due to growing rational control denominators. before-controller-fix.py preserves that source. No gate was loosened.
- tests05: fifteen passes; the first nonmultiple-endpoint fixture also consumed its inventory and correctly hit rejection limits. Replaced only that intended constant-forcing fixture's consuming source with zero source; its physical forcing and original error policy are explicit in the final test.
- tests06: all sixteen pass after both fixes.

Independent tests cover exact actual callback-stage sequence, autonomous origin 0 versus 10^12 with coincident float displays, per-prefix Fraction N/E/stretch/component closure, analytic translated piecewise heat forcing with exact knot clipping, nonlinear amount and mechanical-only error rejection, positivity without clipping, operator rejection of an accepted trial, initial/later domain failures, cancellation after a prefix, wall/step/rejection limits, schema change, absent mechanical state, and strict time inputs. Analytic solutions use exponentials or integrated piecewise linear forcing, not this solver as an oracle.

## Handoff and limits

Copy only exact_integration.py and test_exact_integration.py after independent review. conftest.py is temp-only loading infrastructure. baseline-integration.py and its SHA preserve the existing algorithm used to prepare this version. build_candidate.py records INITIAL generation only; final manual controller fixes are in the frozen source and before-controller-fix.py, not regenerated by that historical script.

This bounded implementation intentionally parallels the existing solver to permit a clear numerical diff; common extraction can follow only after behavior is independently reviewed. It is the required time/ledger substrate, not completion of exact-clock ordered events. Remaining work includes exact affine event clock/root evidence, complete typed packet comparisons/atomic transition, clock-aware actual host queries, source/record schemas, and audited resume. No material admission, wet native success, or full firing trajectory is claimed.
