from pathlib import Path
import hashlib
root=Path('/Users/wanggaoying/Desktop/brickmodel-github')
source=(root/'src/sludge_sandbox/integration.py').read_text()
base=Path(__file__).parent
(base/'baseline-integration.py').write_text(source)
(base/'baseline-sha256.txt').write_text(hashlib.sha256(source.encode()).hexdigest()+'\n')
ledger=source[source.index('class StepLedger:'):source.index('@dataclass(frozen=True)\nclass IntegrationPolicy:')]
ledger=ledger.replace('class StepLedger:', 'class ExactStepLedger:').replace('start_s: float','start_s: ExactEventTime').replace('end_s: float','end_s: ExactEventTime')
ledger=ledger.replace('    def __post_init__(self):','''    def __post_init__(self):
        if type(self.start_s) is not ExactEventTime or type(self.end_s) is not ExactEventTime or self.end_s <= self.start_s:
            raise IntegrationError("ordered_exact_ledger_times_required")''')
result=source[source.index('@dataclass(frozen=True)\nclass IntegrationResult:'):source.index('class _Reject(Exception):')]
result=result.replace('class IntegrationResult:','class ExactIntegrationResult:').replace('tuple[float, ...]','tuple[ExactEventTime, ...]').replace('tuple[StepLedger, ...]','tuple[ExactStepLedger, ...]')
result=result.replace('    cumulative_absolute_component_residual_j:', '    attempted_trials: int\n    cumulative_absolute_component_residual_j:')
s=source[source.index('def integrate('):]
s=s.replace('def integrate(', 'def integrate_exact(').replace('Callable[[ConservedState, float], Rates]','Callable[[ConservedState, ExactEventTime], Rates]').replace('start_s: float, end_s: float','start_s: ExactEventTime, end_s: ExactEventTime').replace('tuple[float, ...]','tuple[ExactEventTime, ...]').replace(') -> IntegrationResult:',') -> ExactIntegrationResult:')
a=s.index('    """');b=s.index('    if not isinstance(initial',a)
s=s[:a]+'''    """Two-half SSPRK2 with exact semantic stage times and original error gates.

    Explicit opt-in: callbacks receive ExactEventTime, never display floats.
    Policy durations retain their exact binary64 meaning. Clipped remaining
    intervals below minimum_step_s are refused, including breakpoint remainders.
    No legacy checkpoint/codec or depletion-packet admission is provided.
    """
'''+s[b:]
s=s.replace('    start, end = _scalar(start_s, "start"), _scalar(end_s, "end")','''    if type(start_s) is not ExactEventTime or type(end_s) is not ExactEventTime:
        raise IntegrationError("exact_time_endpoints_required")
    start, end = start_s.seconds, end_s.seconds''')
s=s.replace('    knots = [_scalar(t, "breakpoint") for t in breakpoints_s]','''    if any(type(t) is not ExactEventTime for t in breakpoints_s):
        raise IntegrationError("exact_breakpoints_required")
    knots = [t.seconds for t in breakpoints_s]''')
s=s.replace('    evaluations, rejected, knot_index = 0, 0, 0','    evaluations, rejected, knot_index, attempted = 0, 0, 0, 0')
s=s.replace('return IntegrationResult(status, reason, tuple(times), tuple(states), tuple(ledgers),','return ExactIntegrationResult(status, reason, tuple(ExactEventTime(t) for t in times), tuple(states), tuple(ledgers),')
s=s.replace('evaluations, rejected, time.monotonic()-begin,','evaluations, rejected, time.monotonic()-begin, attempted,')
s=s.replace('''        if at+desired >= endpoint:
            return math.nextafter(endpoint, at)-at
        return desired''','''        return min(desired, (endpoint-at)/2)''')
s=s.replace('rates = operator(state, at)','rates = operator(state, ExactEventTime(at))')
s=s.replace('step*dn','_scaled(step,dn)').replace('step*du','_scaled(step,du)').replace('step*rates.mechanical_rates_per_s','_scaled(step,rates.mechanical_rates_per_s)')
s=s.replace('(step/2)*getattr(first, name)','_scaled(step/2,getattr(first, name))').replace('(step/2)*getattr(second, name)','_scaled(step/2,getattr(second, name))')
s=s.replace('(step/2)*first.mechanical_rates_per_s','_scaled(step/2,first.mechanical_rates_per_s)').replace('(step/2)*second.mechanical_rates_per_s','_scaled(step/2,second.mechanical_rates_per_s)')
s=s.replace('(step/2)*a, (step/2)*b','_scaled(step/2,a), _scaled(step/2,b)')
s=s.replace('    h = policy.initial_step_s','    h = Fraction(policy.initial_step_s)')
a=s.index('        # Accumulate nominal binary-float durations');b=s.index('        try:\n            midpoint',a)
s=s[:a]+'''        next_time = min(at+h,target)
        proposed_clock = next_time
        step = next_time-at
        if step < Fraction(policy.minimum_step_s) or step <= 0:
            return finish("domain_exit" if last_domain else "numerical_failure",
                          last_domain or "minimum_time_step")
        attempted += 1
'''+s[b:]
s=s.replace('''            # Rounded absolute times need not divide into exactly equal halves.
            # Every stage uses its actual endpoint difference, including weights.''','''            # These semantic subintervals are exactly equal, independent of origin.''')
s=s.replace('step*max(0.2, 0.9*error**(-1/3))','step*Fraction(max(0.2, 0.9*error**(-1/3)))')
s=s.replace('ledger = StepLedger(at, next_time,','ledger = ExactStepLedger(ExactEventTime(at), ExactEventTime(next_time),')
s=s.replace('max(policy.minimum_step_s, min(policy.maximum_step_s, step*(2 if error == 0 else min(2, max(0.2, 0.9*error**(-1/3))))))','max(Fraction(policy.minimum_step_s), min(Fraction(policy.maximum_step_s), step*Fraction(2 if error == 0 else min(2, max(0.2, 0.9*error**(-1/3))))))')
header='''"""Exact-time SSPRK2 candidate: explicit separate types, no legacy time casts."""
from dataclasses import dataclass, field
from collections.abc import Mapping
from fractions import Fraction
from types import MappingProxyType
from typing import Callable
import math
import time
import numpy as np
from numpy.typing import NDArray
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.integration import (ConservedState, Rates, IntegrationPolicy, IntegrationError,
    DomainExit, _Reject, _Stop, _array, _components, _scalar, _updated, _sum_arrays, _check_update)


def _scaled(duration: Fraction, values: NDArray[np.float64]) -> NDArray[np.float64]:
    """Round each exact rational duration times represented rate once."""
    try:
        out = np.array([float(duration*Fraction(float(v))) for v in values.flat]).reshape(values.shape)
    except (OverflowError,ValueError) as exc:
        raise _Reject('unrepresentable_exact_duration_product') from exc
    if not np.all(np.isfinite(out)):
        raise _Reject('unrepresentable_exact_duration_product')
    return out


@dataclass(frozen=True)
'''
(base/'exact_integration.py').write_text(header+ledger+result+s)
