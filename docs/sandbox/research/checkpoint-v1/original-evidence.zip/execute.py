import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).parent
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
PYTHON = '/private/tmp/brick-water-backend-probe/venv/bin/python'
mode = sys.argv[1]
if len(sys.argv) == 2:
    started = time.monotonic()
    record = {'mode': mode, 'external_timeout_s': 150}
    try:
        args = [PYTHON, __file__, mode, '--child']
        if mode == 'final':
            args = [PYTHON, '-m', 'sludge_sandbox', 'resume', str(HERE/'middle'), '--output', str(HERE/'final')]
        result = subprocess.run(args, cwd='/private/tmp', env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                                capture_output=True, text=True, timeout=150)
        record.update(command=args, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    except subprocess.TimeoutExpired as exc:
        record.update(returncode=None, timeout=True, stdout=str(exc.stdout), stderr=str(exc.stderr))
    record['elapsed_seconds'] = time.monotonic()-started
    (HERE/(mode+'-process.json')).write_text(json.dumps(record, indent=2))
    print(json.dumps(record))
    raise SystemExit(0 if record.get('returncode') == 0 else 1)

from sludge_sandbox.run_service import run_case, resume_run
count = 0
def cancel():
    global count
    count += 1
    return count >= 20

if mode == 'parent':
    payload = json.loads((ROOT/'data/sandbox/cases/reacting-wet-slab-v1.json').read_bytes())
    payload['refinement'] = 1
    (HERE/'case.json').write_text(json.dumps(payload, indent=2)+'\n')
    result = run_case(HERE/'case.json', ROOT/'data/sandbox/water', HERE/mode,
                      evidence_directory=ROOT/'data/sandbox', cancel=cancel)
elif mode == 'middle':
    result = resume_run(HERE/'parent', HERE/mode, cancel=cancel)
elif mode == 'reference':
    result = run_case(HERE/'case.json', ROOT/'data/sandbox/water', HERE/mode,
                      evidence_directory=ROOT/'data/sandbox')
else:
    raise ValueError(mode)
steps = len(result.get('integration', {}).get('steps', []))
print(json.dumps({'status': result['status'], 'reason': result.get('reason'), 'steps': steps, 'cancel_calls': count}))
assert result['status'] == ('completed' if mode == 'reference' else 'cancelled'), result.get('reason')
assert steps == {'parent': 1, 'middle': 2, 'reference': 4}[mode], steps
