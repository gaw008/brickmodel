"""Independent saved-artifact and original ledger checks; no EOS evaluation."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import traceback
from sludge_sandbox.run_service import read_run, trace_run
from audit_ledgers import audit

here = Path(__file__).parent
record = {'status': 'started', 'runs': {}}
try:
    runs = {}
    for name in ('parent', 'middle', 'final', 'reference'):
        result, manifest = read_run(here/name)
        runs[name] = result
        assert len(result['integration']['steps']) == {'parent': 1, 'middle': 2, 'final': 4, 'reference': 4}[name]
        assert result['status'] == ('cancelled' if name in ('parent', 'middle') else 'completed')
        path = here/(name+'-ledger-input.json')
        path.write_text(json.dumps({'run': result['integration'], 'initial': result['integration']['states'][0]}, indent=2))
        checked = audit(path, {})
        checked['original_result_sha256'] = manifest['files']['result.json']
        record['runs'][name] = checked
    for child, parent in (('middle', 'parent'), ('final', 'middle')):
        c, p = runs[child], runs[parent]
        raw = (here/parent/'result.json').read_bytes()
        assert (here/child/'parent/result.json').read_bytes() == raw
        assert c['resume_of']['result_sha256'] == hashlib.sha256(raw).hexdigest()
        assert c['case_sha256'] == p['case_sha256']
        assert c['policy'] == p['policy']
        assert c['initial_snapshot'] == p['initial_snapshot']
        n = len(p['integration']['steps'])
        assert c['integration']['steps'][:n] == p['integration']['steps']
        assert c['integration']['states'][:n+1] == p['integration']['states']
        assert c['suffix_policy']['maximum_steps'] == c['policy']['maximum_steps']-n
        assert c['suffix_policy']['maximum_rejections'] == c['policy']['maximum_rejections']-p['integration']['rejected_trials']
        assert Fraction(c['suffix_policy']['maximum_wall_seconds']) <= Fraction(c['policy']['maximum_wall_seconds'])-Fraction(p['integration']['elapsed_seconds'])
        suffix = json.loads((here/child/'resume_suffix.json').read_bytes())
        assert Fraction(c['integration']['elapsed_seconds']) >= Fraction(p['integration']['elapsed_seconds'])+Fraction(suffix['elapsed_seconds'])
        assert c['resume_ledger_audit']['status'] == 'passed'
    final, reference = runs['final'], runs['reference']
    assert final['integration']['times_s'] == reference['integration']['times_s']
    differences = []
    for left, right in zip(final['integration']['states'], reference['integration']['states'], strict=True):
        dn = max(abs(a-b) for ra, rb in zip(left['amounts_mol'], right['amounts_mol']) for a,b in zip(ra,rb))
        de = max(abs(a-b) for a,b in zip(left['internal_energy_j'], right['internal_energy_j']))
        assert dn <= 1e-12 and de <= 1e-8
        differences.append({'amount_mol': dn, 'energy_j': de})
    record['comparison'] = {
        'state_differences': differences,
        'states_exactly_equal': final['integration']['states'] == reference['integration']['states'],
        'ledgers_exactly_equal': final['integration']['steps'] == reference['integration']['steps'],
        'temperature_difference_k': [a-b for a,b in zip(final['final_snapshot']['temperature_k'],reference['final_snapshot']['temperature_k'])],
        'pressure_difference_pa': [a-b for a,b in zip(final['final_snapshot']['pressure_pa'],reference['final_snapshot']['pressure_pa'])],
        'cumulative_integration_seconds': final['integration']['elapsed_seconds']}
    (here/'temperature-trace.json').write_text(json.dumps(trace_run(here/'final', 'temperature_k'), indent=2))
    record['status'] = 'passed'
except Exception as exc:
    record.update(status='failed', reason=str(exc), error_type=type(exc).__name__, traceback=traceback.format_exc())
finally:
    (here/'verification.json').write_text(json.dumps(record, indent=2))
print(json.dumps({k:v for k,v in record.items() if k not in ('runs','traceback')}))
raise SystemExit(0 if record['status'] == 'passed' else 1)
