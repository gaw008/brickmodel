"""Independent saved endpoint scalar breakdown; no model imports."""
from fractions import Fraction as F
from pathlib import Path
import runpy,json,hashlib,time
P=Path(__file__).parent;m=runpy.run_path(str(P/'audit_manufactured.py'));t0=time.monotonic();p=Path('/private/tmp/brick-source-dry-transition-v1/root/native-result.json');raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='0a242ef8c239226b68ee085abe51641e1b95165c464f7edb175454555543fa49';r=m['dec'](json.loads(raw));t=r['transition'];rows=[]
for idx,k in enumerate((0,-1)):
 points=[c['captures'][k]['evaluation']['source_evaluation']['cells'][0]['inverse']['point'] for c in t['candidates']];ps=[F(p['fluid']['mechanical']['pressure_pa']) for p in points];dp=abs(ps[0]-ps[1]);fluid=sum((F(p['fluid']['pressure_error_bound_pa']) for p in points),F());volume=sum((F(p['extra_pressure_error_pa']) for p in points),F());reported=dp+sum((F(p['pressure_error_pa']) for p in points),F());conditional=t['conditional_pressure_bounds_pa'][idx];assert reported==dp+fluid+volume
 rows.append({'kind':'event' if idx==0 else 'common','actual_times':[c['captures'][k]['time']['seconds'] for c in t['candidates']],'nominal_pressure_difference_pa':dp,'fluid_pressure_bound_sum_pa':fluid,'available_volume_extra_sum_pa':volume,'reported_pressure_bound_pa':reported,'conditional_pressure_bound_pa':conditional,'conditional_increment_over_reported_pa':conditional-reported,'original_pressure_tolerance_pa':F(r['event_policy']['pressure_absolute_pa']),'volume_fraction_reported':volume/reported,'endpoint_differences':t['endpoint_differences'][idx][3]})
paths=[]
for i,c in enumerate(t['candidates']):
 bal=t['balance_paths'][i];paths.append({'event_time':c['terminal']['clock']['lower']['seconds'],'end_time':c['end']['seconds'],'dry_duration':c['end']['seconds']-c['terminal']['clock']['lower']['seconds'],'dry_capture_count':len(c['captures']),'dry_water_mol':sum(map(F,c['captures'][0]['state']['amounts_mol'][0][::3]),F()),'reused_rounds':c['terminal']['reused_clock_rounds'],'additional_rounds':c['terminal']['additional_clock_rounds'],'final_balance':bal[-1]})
def enc(x):
 if isinstance(x,F):return {'numerator':x.numerator,'denominator':x.denominator,'decimal':float(x)}
 raise TypeError(type(x).__name__)
out={'input_sha256':hashlib.sha256(raw).hexdigest(),'elapsed_s':time.monotonic()-t0,'rows':rows,'paths':paths};(P/'NATIVE_PRESSURE_BREAKDOWN.json').write_text(json.dumps(out,default=enc,indent=2)+'\n');print(json.dumps(out,default=enc,indent=2))
