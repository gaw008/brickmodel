# 首版实际源码只读审查

已读 source_terminal.py / source_dry_transition.py；尚未读取未终态 manufactured-result.json。已准备 audit_manufactured.py，仅 py_compile，未执行结果审核或 EOS。

符合合同：完整实际 seed.check/初中样本、原域内正初库存、禁化学、禁液体transport配置、每面液流0、全区间正蒸发、真正phase gross、原water molar mass绑定、全部4库存竞争、strict unique liquid root；完整 source prefix 与旧三项积分逐项相等；原 ExactAffineEvidence/writeback 预算不变；写回U不变、energy identity不变，dry operator改变；实际 dry integrate_exact 与程序节点；dry事件和末态真实capture压力绑定；全链普通+terminal+writeback+dry从原始初态累积，rho显式保留。

需明确：terminal 自 seed 重建 order，没接已有 refinement 的 choice/clock 追加深度。若两者确为相同 canonical [0,H] dyadic 链，逻辑共用深度应为 max 而非机械相加，重复算术本身不是科学预算超标；但目前缺已耗链绑定与复用记录。最小解决是接入已检查同域同系数已有 bracket/depth，从其层次继续，或显式证明已有/新证据是同一链且共同总深度不超原cap。已通知root，不声称当前制造例已实际越界。

_audit_path 的水残差 = nr_liquid+nr_vapor+storage 正确：nr已扣除了实际writeback增量，因此加回rho表示物理外流/相变账本的真实水剩余。不能再把这个rho当漏项消掉。H/O/N元素与流体质量记录由当前残差线性组合得到；普通累计N/U以IntegrationPolicy判定，事件rho另经原DepletionRoundoffTotals单项/累计元素/质量预算判定。当前函数没有把全链所有普通积分残差再施加event-only element/mass门槛，报告必须区分这两套原政策，不能声称所有普通元素余额都过了事件专属门槛。

普通积分段 full 字段取已有 represented step ledger（源积分器并未提供每个Heun算术步骤的无限精度积分真值）；terminal full字段才额外使用精确affine积分。该full含义不能宣传为全轨迹连续方程真误差界。后续保存审核将独立保留此范围。
