"""Offline Fraction ledger auditor; execute only after terminal/hash notification."""
from fractions import Fraction as F
import json,hashlib,sys,time
from pathlib import Path
checks=0

def ck(v,label):
 global checks
 checks+=1
 if not v:raise AssertionError(label)
def dec(v):
 if isinstance(v,list):return [dec(x) for x in v]
 if isinstance(v,dict):
  if set(v)=={'numerator','denominator'}:return F(v['numerator'],v['denominator'])
  if set(v)=={'type','fields'}:return dec(v['fields'])
  if 'dtype'in v and 'values'in v:return dec(v['values'])
  return {k:dec(x) for k,x in v.items()}
 return v

def audit(t):
 cases=[]
 for path,c in enumerate(t['candidates']):
  ordinary=[] if path==0 else [t['refinement']['approach']['trial']]
  z=c['terminal'];prefix=z['prefix'];clock=z['clock'];samples=clock['samples'];start=samples['start']['seconds'];H=samples['upper']['seconds']-start;hm=samples['midpoint']['seconds']-start
  h=clock['lower']['seconds']-start;depth=clock['iterations'];width=H/2**depth;lo=F();hi=H
  n=F(samples['start_inventory_mol']);rates=samples['liquid_rates_start_mol_s'];acc=[(F(b)-F(a))/hm for a,b in zip(rates,samples['liquid_rates_mid_mol_s'])]
  val=lambda x:n+sum((F(a)*x+b*x*x/2 for a,b in zip(rates,acc)),F())
  for _ in range(depth):
   m=(lo+hi)/2
   if val(m)>=0:lo=m
   else:hi=m
  ck((h,clock['upper']['seconds']-start)==(lo,hi),'canonical legacy dyadic clock')
  ck(hi-lo==width and depth<=z['event_policy']['maximum_refinements'],'original clock bound')
  E=F(samples['evaporation_start_mol_s']);aE=(F(samples['evaporation_mid_mol_s'])-E)/hm
  ck(min(E,E+aE*H)>0,'full interval positive evaporation')
  ck(all(F(x)==0 for x in rates[:2]+samples['liquid_rates_mid_mol_s'][:2]),'zero individual liquid faces')
  terms=[float(F(a)*h+b*h*h/2) for a,b in zip(rates,acc)]
  ck(float(n+sum(map(F,terms),F()))==prefix['raw_state']['amounts_mol'][0][0],'legacy/source raw liquid projection')
  before=prefix['raw_state'];after=z['corrected_state'];delta=[F(a)-F(b) for a,b in zip(after['amounts_mol'][0],before['amounts_mol'][0])];rho=sum(delta,F())
  ck(after['amounts_mol'][0][0]==0 and delta[1:3]==[F(),F()] and after['internal_energy_j']==before['internal_energy_j'],'phase only writeback and unchanged U')
  ck(rho==z['totals']['signed_storage_roundoff_mol'],'actual storage rho')
  d=F(before['amounts_mol'][0][0]);rp=z['event_policy']['roundoff_policy'];gross=E*h+aE*h*h/2;rounded=float(gross)
  import math
  if F(rounded)>gross:rounded=math.nextafter(rounded,-math.inf)
  ck(d<=F(rp['correction_absolute_mol']) and d<=F(rounded)*F(rp['correction_fraction_evaporated']),'original correction budgets')
  for pre in ('','cumulative_'):
   ck(abs(rho)<=F(rp[pre+'storage_absolute_mol']) and 2*abs(rho)<=F(rp[pre+'element_absolute_mol']) and abs(rho)*F(rp['molar_mass_kg_mol'])<=F(rp[pre+'mass_absolute_kg']),'original storage element mass budgets')
  origin=(ordinary[0] if ordinary else c['seed'])['initial'];sn=[F()]*4;su=F();fn=[F()]*4;fu=F();correction=[F()]*4;storage=F();rows=[];policy=c['seed']['policy'];masses=c['captures'][0]['evaluation']['source_evaluation']['gas_states'][0]['molar_masses_kg_mol']
  def record(state,at,phase):
   nr=[F(x)-F(y)-a-b for x,y,a,b in zip(state['amounts_mol'][0],origin['amounts_mol'][0],sn,correction)];full=[F(x)-F(y)-a-b for x,y,a,b in zip(state['amounts_mol'][0],origin['amounts_mol'][0],fn,correction)]
   u=F(state['internal_energy_j'][0])-F(origin['internal_energy_j'][0])-su;uf=F(state['internal_energy_j'][0])-F(origin['internal_energy_j'][0])-fu;w=nr[0]+nr[3]+storage
   row=dict(time=at,phase=phase,inventory_residual_mol=nr,energy_residual_j=u,full_inventory_residual_mol=full,full_energy_residual_j=uf,water_balance_residual_mol=w,event_water_storage_roundoff_mol=storage,fluid_element_residuals_mol=[['H',2*w],['O',w+2*nr[1]],['N',2*nr[2]]],fluid_mass_residual_kg=F(masses['H2O'])*w+F(masses['O2'])*nr[1]+F(masses['N2'])*nr[2])
   ck(all(abs(v)<=F(policy['amount_absolute_tolerance_mol']) for v in nr+full) and max(abs(u),abs(uf))<=F(policy['energy_absolute_tolerance_j']),'original full path prefix budgets');rows.append(row)
  def step(state,l,phase,exact=None):
   nonlocal su,fu
   dn=[F(l['face_species_mol'][0][j])-F(l['face_species_mol'][1][j])+F(l['reaction_species_mol'][0][j]) for j in range(4)];du=F(l['face_energy_j'][0])-F(l['face_energy_j'][1])+F(l['cell_work_j'][0]);en,eu=(dn,du) if exact is None else exact
   for j in range(4):sn[j]+=dn[j];fn[j]+=en[j]
   su+=du;fu+=eu;record(state,l['end_s'],phase)
  for trial in ordinary:
   for state,l in zip(trial['reference']['states'][1:],trial['reference']['steps']):step(state,l,'wet_reference')
  pieces={name:values for name,values,_ in prefix['integrals']};f=pieces['face_species_mol_s'];r=pieces['reaction_species_mol_s'];u=pieces['face_energy_w'];work=pieces['cell_power_w']
  step(before,prefix['ledger'],'wet_terminal',([f[j]-f[j+4]+r[j] for j in range(4)],u[0]-u[1]+work[0]));correction=delta;storage=rho;record(after,prefix['ledger']['end_s'],'writeback')
  for state,l in zip(c['reference']['states'][1:],c['reference']['steps']):step(state,l,'dry_reference')
  ck(rows==t['balance_paths'][path],'all independent saved balance rows')
  ck(c['reference']['states'][0]==after and c['reference']['times_s'][0]==clock['lower'] and c['reference']['times_s'][-1]==c['end'] and len(c['reference']['steps'])>0,'actual dry time advance')
  cases.append({'prefix_count':len(rows),'dry_steps':len(c['reference']['steps']),'rho':str(rho),'depth':depth})
 return cases
if __name__=='__main__':
 p=Path(sys.argv[1]);raw=p.read_bytes();ck(hashlib.sha256(raw).hexdigest()==sys.argv[2],'terminal input hash');r=dec(json.loads(raw));start=time.monotonic()
 t=r.get('transition',r);out=audit(t);print(json.dumps({'checks':checks,'elapsed_s':time.monotonic()-start,'paths':out,'input_sha256':hashlib.sha256(raw).hexdigest()},indent=2))
