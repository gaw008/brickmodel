"""Terminal saved manufactured cases; no EOS or production imports."""
import runpy,json,hashlib,time,sys
from pathlib import Path
from fractions import Fraction as F
P=Path(__file__).parent;m=runpy.run_path(str(P/'audit_manufactured.py'));ck=m['ck'];start=time.monotonic()
f=Path(sys.argv[1]);raw=f.read_bytes();sha=hashlib.sha256(raw).hexdigest();ck(sha==sys.argv[2],'terminal input hash');r=m['dec'](json.loads(raw))
if r['status']!='completed':
 result={'input_sha256':sha,'original_status':r['status'],'actual_callbacks':len(r.get('captures',[])),'returned_candidates':len(r.get('returned_candidates',[])),'scope':'original terminal failure preserved; no forced success or event conclusion'}
 (P/'NATIVE_AUDIT_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(0)
t=r['transition'];r['cases']={'native':t}
ck(r['returned_candidates']==t['candidates'],'all returned candidates retained exactly')
ck(t['refinement']==r['refinement'] and r['refinement']['approach']==r['approach'],'top level refinement identities')
trials=[r['seed'],r['approach']['trial'],r['refinement']['shifted_trial'],*t['candidates']]
stored=[c for trial in trials for c in trial['captures']]
ck(len(r['captures'])==1+len(stored),'actual callbacks no expected-count forcing')
for actual,c in zip(r['captures'][1:],stored):
 ck(actual['packed_input']==c['state'] and actual['time']==c['time'],'outer actual callback inputs')
 if c['evaluation'] is not None:ck(actual['evaluation']==c['evaluation'],'outer actual callback outputs')
 ck(actual['energy_identity']==r['seed']['energy_identity'],'fixed source energy identity')
ck(r['expected_callbacks_not_measurement']==32,'planning estimate remains declared estimate')
ck(r['backend_constructors_started']==r['backend_constructors_completed']==r['constructor_reference_anchor_checks']==4 and r['initial_energy_evaluations_attempted']==1,'explicit constructor anchor and initial energy count')
ck(r['initial_energy_point']['available_volume_error_m3']==1e-12,'original volume error retained')
for key,value in dict(time_absolute_s=1e-8,amount_absolute_mol=1e-11,energy_absolute_j=1e-7,temperature_absolute_k=1e-5,pressure_absolute_pa=1e-4,maximum_refinements=32).items():ck(r['event_policy'][key]==value,'original event gate '+key)
ck(r['material_qualified'] is False and r['numerical_event_accepted']==t['numerical_event_accepted'],'top level conditional outcome only')
out={}
for name,t in r['cases'].items():
 paths=m['audit'](t);ep=t['candidates'][0]['event_policy'];lims=[F(ep[k]) for k in ('amount_absolute_mol','energy_absolute_j','temperature_absolute_k','pressure_absolute_pa')];bounds=[];allg=[]
 for i,c in enumerate(t['candidates']):
  z=c['terminal'];prior=z['prior_clock'];ix=z['root_index'];choice=prior['choices'][ix];spent=choice['order']['refinement_level']+choice['additional_refinement_rounds']+prior['additional_rounds'][ix]
  ck(prior==t['refinement']['clock'] and ix==i,'prior actual comparison binding')
  ck(z['reused_clock_rounds']==spent and z['clock']['iterations']==spent+z['additional_clock_rounds']<=ep['maximum_refinements'],'shared prior plus additional depth')
  ck(choice['order']['polynomials']==z['root_order']['order']['polynomials'] and len(choice['order']['polynomials'])==4,'all four original polynomials')
  radii=[]
  for capture,b in zip((c['captures'][0],c['captures'][-1]),c['pressure_endpoints']):
   inv=capture['evaluation']['source_evaluation']['cells'][0]['inverse'];p=inv['point'];me=p['fluid']['mechanical'];co=b['continuation'];ng=sum(map(F,capture['state']['amounts_mol'][0][1:]),F());R=F(me['gas_constant_j_mol_k']);T=F(me['temperature_k']);et=F(inv['temperature_error_bound_k']);V=F(p['available_pore_volume_m3']);ev=F(p['available_volume_error_m3']);pressure=F(me['pressure_pa']);er=F(p['pressure_error_pa'])
   ck(capture['state']['amounts_mol'][0][0]==0 and b['inverse']==inv,'actual dry endpoint binding')
   ck(co['inputs']==[ng,R,T,et,V,ev,pressure,er],'eight raw pressure inputs')
   tb=[T-et,T+et];vb=[V-ev,V+ev];analytic=[ng*R*tb[0]/vb[1],ng*R*tb[1]/vb[0]];slope=ng*R/vb[0];rad=er+slope*et;interval=[min(analytic[0],pressure-rad),max(analytic[1],pressure+rad)];radius=max(pressure-interval[0],interval[1]-pressure)
   ck(co['temperature_interval_k']==tb and co['volume_interval_m3']==vb and co['analytic_interval_pa']==analytic,'complete analytic T V box')
   ck(co['slope_pa_k']==slope and co['candidate_interval_pa']==interval==co['interval_pa'] and co['radius_pa']==radius,'retained pressure plus T radius and corner hull')
   ck(co['temperature_domain_k'][0]<=tb[0]<=tb[1]<=co['temperature_domain_k'][1] and 0<vb[0] and co['pressure_domain_pa'][0]<=interval[0]<=interval[1]<=co['pressure_domain_pa'][1],'full box domain fences')
   ck(co['source_certified'] is b['source_certified'] is b['event_admitted'] is b['material_qualified'] is False,'no pressure material certification');radii.append(radius)
  bounds.append(radii)
  if name=='programmed':
   ck({'seconds':F(.0002)} in c['reference']['times_s'],'exact program knot accepted')
   A,B=c['captures'][0],c['captures'][-1]
   ck(A['state']['internal_energy_j']!=B['state']['internal_energy_j'],'actual nonzero dry heat')
   ta=A['evaluation']['source_evaluation']['cells'][0]['inverse']['point']['fluid']['mechanical']['temperature_k'];tb=B['evaluation']['source_evaluation']['cells'][0]['inverse']['point']['fluid']['mechanical']['temperature_k'];ck(ta!=tb,'actual dry temperature change')
 for rowidx,k in enumerate((0,-1)):
  a,b=[c['captures'][k] for c in t['candidates']];pa,pb=[v['evaluation']['source_evaluation']['cells'][0]['inverse'] for v in (a,b)];ma,mb=[v['point']['fluid']['mechanical'] for v in (pa,pb)]
  vals=[max(abs(F(x)-F(y)) for x,y in zip(a['state']['amounts_mol'][0],b['state']['amounts_mol'][0])),abs(F(a['state']['internal_energy_j'][0])-F(b['state']['internal_energy_j'][0])),abs(F(ma['temperature_k'])-F(mb['temperature_k']))+F(pa['temperature_error_bound_k'])+F(pb['temperature_error_bound_k']),abs(F(ma['pressure_pa'])-F(mb['pressure_pa']))+F(pa['point']['pressure_error_pa'])+F(pb['point']['pressure_error_pa'])]
  gates=[v<=lim for v,lim in zip(vals,lims)];bound=abs(F(ma['pressure_pa'])-F(mb['pressure_pa']))+bounds[0][rowidx]+bounds[1][rowidx]
  ck(t['endpoint_differences'][rowidx][1:]==[a['time'],b['time'],vals] and t['endpoint_gates'][rowidx]==gates,'actual event common four gates')
  ck(t['conditional_pressure_bounds_pa'][rowidx]==bound and t['conditional_pressure_gates'][rowidx]==(bound<=lims[3]),'conditional gate');allg.append(all(gates) and bound<=lims[3])
 ca,cb=[c['terminal']['clock'] for c in t['candidates']];distance=max(abs(ca['lower']['seconds']-cb['upper']['seconds']),abs(ca['upper']['seconds']-cb['lower']['seconds']));clockgate=distance<=F(ep['time_absolute_s'])
 ck(distance==t['clock_distance_upper_s'] and clockgate==t['clock_gate'],'absolute root time gate');ck(t['numerical_event_accepted']==(clockgate and all(allg)) and t['material_qualified'] is False,'conditional numerical only acceptance')
 out[name]={'paths':paths,'clock_upper_s':float(distance),'endpoint_gates':t['endpoint_gates'],'pressure_bounds_pa':[float(x) for x in t['conditional_pressure_bounds_pa']],'status':t['status']}
result={'checks':ck.__globals__['checks'],'elapsed_s':time.monotonic()-start,'input_sha256':sha,'cases':out,'actual_callbacks':len(r['captures']),'expected_callbacks_not_measurement':r['expected_callbacks_not_measurement'],'scope':'saved terminal native returned objects; no new EOS, source simulation or tests executed'}
(P/'NATIVE_AUDIT_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
