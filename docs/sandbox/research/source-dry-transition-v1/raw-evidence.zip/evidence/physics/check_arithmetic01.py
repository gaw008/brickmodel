"""Independent Fraction manufactured arithmetic, no production imports or EOS."""
from fractions import Fraction as F
from pathlib import Path
import math,json,time,hashlib
start=time.monotonic();checks=0

def ck(x):
 global checks
 checks+=1
 assert x

def p(n,e,a,h):return n-e*h-a*h*h/2

def bisect(n,e,a,H,k):
 lo,hi=F(),H
 for _ in range(k):
  mid=(lo+hi)/2
  if p(n,e,a,mid)>=0:lo=mid
  else:hi=mid
 return lo,hi

# Independent three signed integrals versus shared phase projection and once-rounded raw state.
for n,e,em,H in ((1.,1.,1.,F(3,2)),(1.,1.,1.25,F(3,2)),(1.,1.,.875,F(3,2))):
 hm=H/2;a=(F(em)-F(e))/hm
 ck(min(F(e),F(e)+a*H)>0 and p(F(n),F(e),a,H)<=0)
 for k in (4,8,16,32,48,56):
  lo,hi=bisect(F(n),F(e),a,H,k);I=F(e)*lo+a*lo*lo/2
  triple=(float(F()),float(-F()),float(-I));source=(-float(I),float(I))
  ck(sum(map(F,triple),F())==F(source[0]));ck(F(source[0])+F(source[1])==0)
  ck(float(F(n)+sum(map(F,triple),F()))==float(F(n)+F(source[0])))
  ck(hi-lo==H/2**k and p(F(n),F(e),a,lo)>=0 and p(F(n),F(e),a,hi)<=0)
  ck(lo/(H/2**k)==(lo/(H/2**k)).numerator)
  # Restart from original and split refinements must give same bracket.
  split=k//2;x,y=bisect(F(n),F(e),a,H,split)
  for _ in range(k-split):
   m=(x+y)/2
   if p(F(n),F(e),a,m)>=0:x=m
   else:y=m
  ck((x,y)==(lo,hi))

# Exact point source roots still need a nonzero legacy bin, including upper endpoint.
for tau,H in ((F(1),F(3,2)),(F(3,4),F(3,2)),(F(3,2),F(3,2))):
 for k in (2,8,32):
  w=H/2**k;lo=(tau//w)*w
  if lo==H:lo-=w
  ck(lo>0 and hi!=lo and lo<=tau<=lo+w and lo+w<=H)
  ck((lo,lo+w)==bisect(tau,F(1),F(),H,k))

# Positive sample evaporation alone does not imply extrapolated monotonic evaporation.
e0,em,hm,H=F(1),F(1,4),F(1,2),F(1)
ck(e0>0 and em>0 and e0+(em-e0)*H/hm<0)
# Zero net liquid from two equal nonzero faces does not prove absence of transport.
ck(F(1)-F(1)==0 and (F(1),F(1))!=(F(),F()))
# A liquid drain with condensation cannot use net removal as gross evaporation.
Jleft,Jright,E=F(),F(2),F(-1)
ck(Jleft-Jright-E<0 and E<0)

# Explicit sub-ulp writeback: vapor storage loses d, although ideal paired transfer conserves water.
d=F(1,2**54);v=1.;after=float(F(v)+d);rho=F(after)-F(v)-d
ck(rho==-d);ck(-d+(F(after)-F(v))==rho);ck(-d+d==0)
ck(2*rho==-F(1,2**53));ck(abs(rho)>F(1,2**55))
# Accumulating two locally-small residuals must not reset the original global budget.
r=F(3,2**56);limit=F(1,2**54)
ck(abs(r)<=limit and abs(2*r)>limit)
result={'status':'passed','checks':checks,'elapsed_s':time.monotonic()-start,'scope':'manufactured arithmetic only; no production calls, EOS, or event admission','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('ARITHMETIC_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
