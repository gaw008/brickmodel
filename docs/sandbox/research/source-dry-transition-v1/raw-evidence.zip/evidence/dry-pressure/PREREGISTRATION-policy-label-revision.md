# Pre-registration label correction

Independent review identified that the initial registration mislabeled the three positional IntegrationPolicy tolerances. The actual unchanged code uses relative_tolerance=1e-8, amount_absolute_tolerance_mol=1e-7, and energy_absolute_tolerance_j=1e-3. Only the document labels were corrected; no source code, parameter value, scientific threshold, native run or installation changed. The initial text is retained in PREREGISTRATION-before-policy-label-fix.md.

Before SHA-256: 8e19f14c67b2eecb77da16ce0395eae0ac5c0aa6be799d9fd9596a5f91724b25

After SHA-256: 68d1e4b1cf41b96d262574fff57e6d7e659eea6d4619b9820edd0e130d815551

Unchanged runner SHA-256: a7916d30ee0eb0abf5852a76c5b92eec3a70acd1b0e130cd05a1dc556f2d6e71

```diff
--- before/PREREGISTRATION.md
+++ after/PREREGISTRATION.md
@@ -39,8 +39,8 @@
 
 One actual positive finite initial evaporation probe E determines exact
 `H=(3/2)*Nl/E`. Initial/max reference step is the binary64 value of that actual
-H; minimum step 2^-30 s, amount tolerance 1e-8 mol, energy tolerance 1e-7 J,
-relative tolerance 1e-3, amount scale 1 mol, energy scale 1e5 J, maximum four
+H; minimum step 2^-30 s, relative tolerance 1e-8, amount tolerance 1e-7 mol,
+energy tolerance 1e-3 J, amount scale 1 mol, energy scale 1e5 J, maximum four
 accepted steps and four rejects, and 180 s per-trial/path wall policy are retained.
 These controls are saved in full, including the actual derived H.
 
```
