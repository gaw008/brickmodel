"""Capture complete manufactured wet pressure records before/after shared extraction."""
from dataclasses import fields, replace
from pathlib import Path
import hashlib,json,sys
import pytest
from test_source_wet_storage import setup
from sludge_sandbox.phase_storage import InversePolicy
from sludge_sandbox.source_inverse_pressure import enclose_source_inverse_pressure
from sludge_sandbox.deforming_solid_storage import _canonical
records=[]
for temperature,error in ((330.,0.),(331.,0.),(330.,1e-12)):
    with pytest.MonkeyPatch.context() as patch:
        storage,state,_=setup(patch)
        storage=replace(storage,volume=replace(storage.volume,error_m3=error))
        state=storage.state(state.liquid_water_mol,state.gas_amounts_mol,0.)
        state=replace(state,internal_energy_j=storage.evaluate(state,temperature).total_internal_energy_j)
        inverse=storage.invert(state,InversePolicy(1e-6,1e-6,100))
        bound=enclose_source_inverse_pressure(storage,state,inverse)
        bound.check()
        record={f.name:getattr(bound,f.name) for f in fields(bound) if f.name!='storage'}
        records.append(_canonical(record))
encoded=json.dumps(records,sort_keys=True,indent=2).encode()+b'\n'
Path(sys.argv[1]).write_bytes(encoded)
print(json.dumps({'records':len(records),'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest()}))
