"""Actual manufactured source observations; strip wall-derived fields only."""
from dataclasses import fields, is_dataclass
from collections.abc import Mapping
from fractions import Fraction
from pathlib import Path
import json
import sys
import numpy as np
import pytest
from test_source_prefix_trial import fixture, run
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.integration import DomainExit

def encode(x):
    if isinstance(x, Fraction):
        return [x.numerator,x.denominator]
    if isinstance(x,np.ndarray):
        return {'dtype':str(x.dtype),'shape':x.shape,'values':x.tolist()}
    if is_dataclass(x):
        return {f.name:encode(getattr(x,f.name)) for f in fields(x)
                if f.name not in ('adapter','elapsed_seconds','maximum_wall_seconds')}
    if isinstance(x,Mapping):
        return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):
        if x and all(type(v) is tuple and len(v)==2 and type(v[0]) is str for v in x):
            return [encode(v) for v in x if v[0]!='maximum_wall_seconds']
        return [encode(v) for v in x]
    return x

outputs=[]
for recovery in (False,True):
    with pytest.MonkeyPatch.context() as patch:
        adapter,initial=fixture(patch)
        actual=ExactSourceColumn.evaluate
        count=[0]
        def observe(self,state,when):
            count[0]+=1
            if recovery and count[0]==6:
                raise DomainExit('saved-recoverable-source-domain-exit')
            return actual(self,state,when)
        patch.setattr(ExactSourceColumn,'evaluate',observe)
        if recovery:
            from dataclasses import replace
            from test_source_prefix_trial import POLICY
            from sludge_sandbox.source_prefix_trial import evaluate_source_prefix_trial
            from sludge_sandbox.exact_event_clock import ExactEventTime as T
            out=evaluate_source_prefix_trial(adapter,initial,start=T(Fraction()),end=T(Fraction(1,16384)),
                integration_policy=replace(POLICY,minimum_step_s=1/32768),maximum_callbacks=32)
        else:
            out=run(adapter,initial)
        out.check()
        outputs.append({'recovery':recovery,'actual_callbacks':count[0],'result':encode(out)})
Path(sys.argv[1]).write_text(json.dumps(outputs,sort_keys=True,allow_nan=False)+'\n')
print([(x['result']['status'],x['actual_callbacks']) for x in outputs])
