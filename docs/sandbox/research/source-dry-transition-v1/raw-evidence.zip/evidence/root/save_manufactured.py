"""Save actual returned test trajectories without running additional physics."""
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from fractions import Fraction
from pathlib import Path
import json
import numpy as np

OUTPUT = Path('/private/tmp/brick-source-dry-transition-v1/root/manufactured-result.json')
results = {}

def encode(value):
    if isinstance(value, Fraction):
        return {'numerator': value.numerator, 'denominator': value.denominator}
    if isinstance(value, np.ndarray):
        return {'dtype': str(value.dtype), 'shape': list(value.shape), 'values': encode(value.tolist())}
    if isinstance(value, np.generic):
        return encode(value.item())
    if is_dataclass(value):
        return {'type': type(value).__module__+'.'+type(value).__qualname__,
                'fields': {f.name: encode(getattr(value,f.name)) for f in fields(value)
                           if f.name not in ('adapter','dry_adapter','storage')}}
    if isinstance(value, Mapping):
        return {k: encode(v) for k,v in value.items()}
    if isinstance(value, (tuple,list)):
        return [encode(v) for v in value]
    if value is None or type(value) in (str,int,float,bool):
        return value
    raise TypeError(type(value).__name__)

def pytest_collection_modifyitems(items):
    import test_source_dry_transition as module
    actual = module.evaluate_source_dry_transition
    def observed(refinement, **kwargs):
        out = actual(refinement, **kwargs)
        column = refinement.approach.proposal.original_trial.adapter.column
        name = 'programmed' if hasattr(column,'base') else 'closed'
        if name not in results:
            results[name] = encode(out)
        return out
    module.evaluate_source_dry_transition = observed

def pytest_sessionfinish(session, exitstatus):
    document = {'classification':'manufactured_test_fixture', 'native_eos_used':False,
                'pytest_exitstatus':int(exitstatus),'cases':results,
                'omitted_live_fields':['adapter','dry_adapter','storage']}
    pending = OUTPUT.with_suffix('.pending')
    pending.write_text(json.dumps(document,indent=2,allow_nan=False)+'\n')
    pending.replace(OUTPUT)
