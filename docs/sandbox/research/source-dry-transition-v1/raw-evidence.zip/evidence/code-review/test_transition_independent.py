"""Independent bounded source-transition record regression probes."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_source_dry_transition import actual as actual_fixture
from sludge_sandbox._heos_kernel import HEOSCandidate
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.integration import DomainExit
from sludge_sandbox.source_dry_transition import execute_source_dry_candidate

@pytest.fixture(scope='module')
def actual():
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(HEOSCandidate,'__init__',lambda *a,**k:pytest.fail('native forbidden'))
        gen=actual_fixture.__wrapped__()
        try:yield next(gen)
        finally:gen.close()

@pytest.fixture(scope='module')
def complete(actual):
    refinement,end=actual
    value=execute_source_dry_candidate(refinement.approach.proposal.original_trial,
        event_policy=refinement.approach.proposal.event_policy,end=end,maximum_callbacks=24)
    assert value.status=='executed_dry_candidate',value.reason
    return value

def test_saved_execution_policy_wall_cannot_be_rewritten(complete,monkeypatch):
    monkeypatch.setattr(ExactSourceColumn,'evaluate',lambda *a,**k:pytest.fail('saved check called source'))
    assert complete.dry_policy.maximum_wall_seconds < complete.seed.policy.maximum_wall_seconds
    revised=replace(complete.dry_policy,maximum_wall_seconds=complete.seed.policy.maximum_wall_seconds)
    with pytest.raises(ValueError):replace(complete,dry_policy=revised).check()

def test_failed_capture_exact_clock_cannot_be_mutated_to_float(actual,monkeypatch):
    refinement,end=actual
    def fail(*a,**k):raise DomainExit('independent failed first dry call')
    monkeypatch.setattr(ExactSourceColumn,'evaluate',fail)
    out=execute_source_dry_candidate(refinement.approach.proposal.original_trial,
        event_policy=refinement.approach.proposal.event_policy,end=end,maximum_callbacks=8)
    assert out.captures[0].evaluation is None and out.captures[0].failure_kind=='DomainExit'
    out.check()
    # Failed input binding retains the same time object: a field mutation must not evade validation.
    capture=out.captures[0]
    object.__setattr__(capture.time,'seconds',float((out.terminal.clock.lower.seconds+end.seconds)/2))
    assert type(capture.time.seconds) is float
    with pytest.raises(ValueError):out.check()


def test_failed_capture_exact_fraction_clock_is_independently_frozen(actual,monkeypatch):
    refinement,end=actual
    def fail(*a,**k):raise DomainExit('independent exact failed dry call')
    monkeypatch.setattr(ExactSourceColumn,'evaluate',fail)
    out=execute_source_dry_candidate(refinement.approach.proposal.original_trial,
        event_policy=refinement.approach.proposal.event_policy,end=end,maximum_callbacks=8)
    assert out.captures[0].evaluation is None and out.captures[0].failure_kind=='DomainExit'
    out.check()
    capture=out.captures[0]
    assert capture.time is not capture.input_binding[2]
    original=capture.time.seconds
    revised=(out.terminal.clock.lower.seconds+end.seconds)/2
    assert revised!=original and type(revised) is F
    object.__setattr__(capture.time,'seconds',revised)
    with pytest.raises(ValueError,match='trial_attempt_input_failure_binding'):out.check()


def test_prior_clock_binds_actual_seed_and_keeps_shared_depth(actual,monkeypatch):
    from sludge_sandbox.source_terminal import build_source_terminal
    refinement,end=actual
    event=refinement.approach.proposal.event_policy
    monkeypatch.setattr(ExactSourceColumn,'evaluate',lambda *a,**k:pytest.fail('clock check called source'))
    for index,seed in enumerate((refinement.approach.proposal.original_trial,refinement.shifted_trial)):
        terminal=build_source_terminal(seed,event_policy=event,prior_clock=refinement.clock,root_index=index)
        terminal.check()
        assert terminal.reused_clock_rounds>=refinement.clock.refined_roots[index].refinements
        assert terminal.clock.iterations==terminal.reused_clock_rounds+terminal.additional_clock_rounds
        assert terminal.clock.iterations<=terminal.root_order.order.maximum_refinements<=event.maximum_refinements
        assert terminal.clock.lower>=refinement.clock.intervals[index].lower
        assert terminal.clock.upper<=refinement.clock.intervals[index].upper
        with pytest.raises(ValueError):
            build_source_terminal(seed,event_policy=event,prior_clock=refinement.clock,root_index=1-index)
        with pytest.raises(ValueError):replace(terminal,reused_clock_rounds=terminal.reused_clock_rounds+1).check()
