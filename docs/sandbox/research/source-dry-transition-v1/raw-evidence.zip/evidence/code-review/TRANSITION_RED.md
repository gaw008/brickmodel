# Independent transition record review — initial RED evidence

Scope: source_terminal.py, source_dry_transition.py, shared source_prefix_trial.py extraction, and the new actual manufactured transition tests. Production was read-only. The two independent tests completed in 2.90 s, with native HEOS construction forbidden. Original output is retained in transition-independent01.xml/log; input hashes are in TRANSITION_REVIEW_INITIAL.json. Root is independently correcting prior-clock provenance, which is not duplicated below.

[MEDIUM] The recorded applied dry integration wall policy can change undetected

File: src/sludge_sandbox/source_dry_transition.py:65
Issue: SourceDryCandidate.check() accepts replacing the applied remaining maximum_wall_seconds with the original full seed wall budget. The actual successful candidate was constructed by execute_source_dry_candidate, then only its dry_policy field was replaced. The check remained passive and passed. The bounds check limits the replacement to the original total wall budget but does not freeze which remaining policy the integrator actually received. The original trial implementation already preserves a separate reference_policy_binding for this reason.
Fix: Record and verify the complete applied dry_policy binding, including its actual remaining wall value. Preserve None for runs that did not start integration.

[MEDIUM] A failed source attempt aliases its supposedly bound exact timestamp

File: src/sludge_sandbox/source_dry_transition.py:58; src/sludge_sandbox/source_prefix_trial.py::_check_source_captures/_attempt_input
Issue: After an actual first dry callback raises DomainExit, its retained evaluation is None. Mutating capture.time.seconds in place to an interior float still passes candidate.check(). The tuple input binding retains the same ExactEventTime object, so it changes together with the capture. No evaluation digest protects this failed callback, and there is no Fraction check on each captured timestamp. Merely requiring Fraction would still leave another Fraction value aliased rather than frozen.
Fix: Bind the exact scalar clock independently for each retained dry callback and validate its Fraction type. Verify the initial attempt against the actual corrected state and terminal clock. Keep the unchanged legacy capture schema and old extraction golden records where practical.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 2 | info |
| LOW | 0 | pass |

Verdict: WARNING — two concrete saved-evidence integrity defects remain pending narrow fixes. Neither probe claims a physical tolerance bypass or invokes native EOS.
