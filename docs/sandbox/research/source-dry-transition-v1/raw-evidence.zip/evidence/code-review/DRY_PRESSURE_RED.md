# Dry pressure review: confirmed provenance binding defect

[HIGH] SourceDryPressure accepts rewritten fluid source labels

File: src/sludge_sandbox/source_dry_pressure.py:134

The new dry-specific binding reconstructs mechanical source IDs, but does not reconstruct ClosedStorageState.source_ids from the actual storage providers. The shared validator only checks that fluid.source_ids is a tuple of strings and point.source_ids is the union of storage IDs and those supplied fluid IDs. Thus it checks internal consistency of potentially rewritten labels, not their actual provider binding.

Two actual cheap counterexamples start from the existing manufactured source dry inverse, change fluid.source_ids to either an empty tuple or ('fabricated:certified-fluid-eos',), and update only point.source_ids to the corresponding union. Neither changes numerical inputs, identities, policies or uncertainty. enclose_source_dry_pressure returns a successful conditional enclosure for both. This permits deletion or fabrication in a newly validated pressure object's retained fluid provenance. It does not flip material/event flags or change pressure arithmetic, but violates the explicit source-trace contract for the accepted saved record.

Fix narrowly in the new dry branch: rebuild the original RigidStorage source sequence, beginning with mechanical.source_ids + template.envelope.source_ids, then extending with phase.metadata.source_ids for every nonzero gas in the actual fixed gas-species order, and deduplicate preserving first occurrence. Require exact tuple equality. The original RigidWaterGas builds its inventory mapping in mechanical.gas_species_ids order, here storage.gas_ids; do not infer the original order from a potentially rearranged saved mapping. Preserve old wet behavior and all numerical bounds.

Evidence: test_dry_pressure_independent.py, dry-independent01.xml/log: 2 failed / 3 passed in 0.47 s. The three independent tests check rational interior/corner containment and preservation of the original reported radius. No native EOS, installation or production edits were used.

Reviewed input SHA-256:

- source_dry_pressure.py: 208137535d2bf3e08fc5f1911c1b6be3b8c3779283e8cb60890c1e3a9984d04b
- source_inverse_pressure.py: 27b90389a8b6ad6055cbe5cb4310122059ea605990ec84c41bd64f4022f949b1
- test_source_dry_pressure.py: 7d8d7cd167f72a4ccf456f87caddc88d73dc3db46a7e161b69e55edb473c592b

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 1 | warn |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: WARNING — resolve the provenance binding before final approval. This report preserves the actual pre-fix RED and is not a claim about later revised bytes.
