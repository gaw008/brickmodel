"""Execute only the runner's actual save/timeout/except AST, never run().

This validates persistence/control flow with explicit synthetic diagnostic data.
It performs no model construction, no source callback and no physical validation.
"""
import ast
from contextlib import redirect_stdout
from dataclasses import dataclass
from fractions import Fraction as F
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import time
import numpy as np
from sludge_sandbox.source_dry_transition import SourceDryTransitionError

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
OUT=Path('/private/tmp/brick-source-dry-transition-v1/code-review')
PATH=ROOT/'docs/sandbox/research/source-dry-transition-v1/run_native.py'
SPEC=importlib.util.spec_from_file_location('reviewed_dry_runner',PATH)
runner=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(runner)
helper_path=ROOT/'docs/sandbox/research/exact-source-column-v1/run_native.py'
hs=importlib.util.spec_from_file_location('reviewed_fixed_encoder',helper_path)
helper=importlib.util.module_from_spec(hs);hs.loader.exec_module(helper)
module=ast.parse(PATH.read_text())
run=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='run')
body=[n for n in run.body if isinstance(n,ast.FunctionDef) and n.name in ('save','timeout')]
try_node=next(n for n in run.body if isinstance(n,ast.Try))
handler=ast.FunctionDef(name='failure_handler',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg='exc')],kwonlyargs=[],kw_defaults=[],defaults=[]),body=try_node.handlers[0].body,decorator_list=[])
code=compile(ast.fix_missing_locations(ast.Module(body=[*body,handler],type_ignores=[])),str(PATH)+':failure_block','exec')

@dataclass(frozen=True)
class DiagnosticProbe:
    value: F
    array: np.ndarray
    storage: object

reports=[]
for case in ('postprocessing','outer_timeout','ordinary_timeout'):
    output=OUT/('runner-'+case+'.json')
    result={'status':'started','returned_candidates':[{'synthetic_saved_diagnostic':True}], 'captures':[{'ordinal':1,'synthetic_attempt':True}]}
    env={'result':result,'output':output,'started':time.monotonic(),'time':time,'json':json,
         'encode':lambda x:runner.saved_record(x,helper.serialize)}
    exec(code,env)
    if case=='postprocessing':
        cause=RuntimeError('postprocess diagnostic')
        probe=DiagnosticProbe(F(1,3),np.array([1.,np.nan]),object())
        exc=SourceDryTransitionError('source_event_comparison',{'exact_time':F(7,11)},(probe,),cause)
        exc.__cause__=cause
    elif case=='outer_timeout':
        try:env['timeout']()
        except TimeoutError as error:exc=error
    else:exc=TimeoutError('ordinary callback timeout diagnostic')
    with redirect_stdout(io.StringIO()):assert env['failure_handler'](exc)==1
    saved=json.loads(output.read_text())
    assert saved['status']==('resource_limit' if case=='outer_timeout' else 'failed')
    assert saved['returned_candidates']==result['returned_candidates'] and saved['captures']==result['captures']
    assert len(saved['exception_chain'])==(2 if case=='postprocessing' else 1)
    assert not output.with_suffix(output.suffix+'.pending').exists()
    if case=='postprocessing':
        fields=saved['exception_chain'][0]['candidates'][0]['fields']
        assert fields['value']=={'numerator':1,'denominator':3} and 'storage' not in fields
        assert fields['array']['dtype']=='float64' and fields['array']['shape']==[2]
        assert fields['array']['values'][1]=={'type':'nonfinite_binary64','value':'nan'}
        assert saved['exception_chain'][1]['exception']=='postprocess diagnostic'
    elif case=='outer_timeout':
        assert saved['outer_timeout_requested'] is True and saved['exception_type']=='TimeoutError'
    else:assert 'outer_timeout_requested' not in saved and saved['exception_type']=='TimeoutError'
    reports.append({'case':case,'status':saved['status'],'bytes':output.stat().st_size})
report={'runner_sha256':hashlib.sha256(PATH.read_bytes()).hexdigest(),'control_cases':reports,'native_eos_calls':0,'source_callbacks':0,'scope':'actual runner failure AST only; synthetic diagnostics, no physical validation'}
(OUT/'runner-failure-paths-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
