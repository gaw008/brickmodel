"""Bounded independent dry pressure checks; no native EOS."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_source_dry_pressure import dry as dry_fixture
from sludge_sandbox._heos_kernel import HEOSCandidate
from sludge_sandbox.source_dry_pressure import enclose_source_dry_pressure,propagate_declared_dry_pressure

@pytest.fixture(scope='module')
def actual():
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(HEOSCandidate,'__init__',lambda *a,**k:pytest.fail('native EOS forbidden'))
        gen=dry_fixture.__wrapped__()
        try:yield next(gen)
        finally:gen.close()

@pytest.mark.parametrize('ng,te,ve,ep',[(F(1,3),F(1,7),F(1,11),F(1,2)),(F(2),F(),F(3,4),F()),(F(10**-1),F(1),F(),F(5))])
def test_independent_exact_corner_and_retained_radius_containment(ng,te,ve,ep):
    r,t,v=F(8),F(325),F(1);p=ng*r*t/v
    out=propagate_declared_dry_pressure(ng,r,t,te,v,ve,p,ep,
        temperature_domain_k=(F(310),F(350)),pressure_domain_pa=(F(1),F(10**6)))
    assert out.status=='conditional_dry_pressure_enclosure'
    for ti in (t-te,t-te/3,t,t+te/3,t+te):
        for vi in (v-ve,v-ve/3,v,v+ve/3,v+ve):
            exact=ng*r*ti/vi
            assert out.interval_pa[0]<=exact<=out.interval_pa[1]
    assert out.interval_pa[0]<=p-ep and out.interval_pa[1]>=p+ep
    assert out.radius_pa>=ep+ng*r*te/(v-ve)
    out.check()

@pytest.mark.parametrize('replacement',[(),('fabricated:certified-fluid-eos',)])
def test_rewritten_fluid_source_metadata_rejected(actual,replacement):
    storage,state,inverse=actual
    fluid=replace(inverse.point.fluid,source_ids=replacement)
    point=replace(inverse.point,fluid=fluid,
                  source_ids=tuple(sorted(set(storage.source_ids+replacement))))
    altered=replace(inverse,point=point)
    with pytest.raises(ValueError):enclose_source_dry_pressure(storage,state,altered)
