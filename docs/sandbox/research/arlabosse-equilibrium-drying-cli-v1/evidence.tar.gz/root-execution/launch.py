"""One supervised run of the reviewed public CLI, using the existing supervisor."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
BASE=Path('/private/tmp/arlabosse-equilibrium-transport-v1')
WORK=Path(__file__).resolve().parent
ENTRY=ROOT/'examples/sandbox/run_equilibrium_drying.py'
PYTHON=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python')
assert hashlib.sha256(ENTRY.read_bytes()).hexdigest()=='c1e567f6f1fd74d488d0e64c66b650d494711c3ed786f4f3aae7d79c430b1df8'
metadata=json.loads((BASE/'supervised-native01/metadata.json').read_text())
inputs=[]
for name,record in metadata['inputs_before'].items():
    path=Path(name)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=record['sha256']:
        raise ValueError('original_input_changed:'+name)
    inputs.append(path)
inputs.extend((ENTRY,WORK/'PLAN.md',Path(__file__).resolve()))
if (WORK/'native01').exists() or (WORK/'native01').is_symlink() or (WORK/'supervised-native01').exists() or (WORK/'supervised-native01').is_symlink():
    raise FileExistsError('refuse_repeat_public_cli_attempt')
(WORK/'native01').mkdir()
spec=importlib.util.spec_from_file_location('public_cli_supervisor',ROOT/'docs/sandbox/research/research-process-supervisor/supervisor.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result=module.run_attempt(WORK/'supervised-native01',
    ['/usr/bin/env','-u','PYTHONPATH',str(PYTHON),'-I',str(ENTRY),
     '--source-root',str(ROOT),'--output',str(WORK/'native01/result.json'),'--steps','1'],
    cwd='/private/tmp',input_paths=inputs,timeout_s=165.,cleanup_grace_s=5.)
print(json.dumps({k:v for k,v in result.items() if not k.startswith('inputs_')},ensure_ascii=False,indent=2))
raise SystemExit(0 if result['status']=='complete' and result['returncode']==0 and result['inputs_unchanged'] is True else 1)
