[MEDIUM] Expired driver budget starts source construction

File: examples/sandbox/run_equilibrium_drying.py, main after load_runtime. The provider/import stage returns at 151 seconds in the independent manufactured probe, but make_case is called before any guard. That call can begin new actual water/source work after the 150-second allowance. Store any necessary returned policy metadata, then guard before make_case. INDEPENDENT02 is the actual 1-failure/1-pass run (0.03 seconds); INDEPENDENT01 only reports a system interpreter without pytest and is not a behavioral RED. No EOS was executed.
