"""Bounded manufactured CLI probes; no model imports or EOS calls."""
from dataclasses import dataclass
from fractions import Fraction as F
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace


FILE = Path('/Users/wanggaoying/Desktop/brickmodel-github/examples/sandbox/run_equilibrium_drying.py')
spec = importlib.util.spec_from_file_location('review_equilibrium_cli', FILE)
cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cli)


def arguments(tmp_path, steps=4):
    return ['--source-root', str(tmp_path), '--output', str(tmp_path/'result.json'), '--steps', str(steps)]


def test_runtime_return_past_budget_stops_before_source_construction(tmp_path, monkeypatch):
    clock = [0.]
    calls = []
    monkeypatch.setattr(cli, 'time', SimpleNamespace(monotonic=lambda: clock[0]))
    def load():
        clock[0] = 151.
        return None, None, SimpleNamespace(definition=lambda: {'manufactured': True})
    def construction(*args):
        calls.append('source_construction')
        raise ValueError('manufactured_forbidden_late_construction')
    monkeypatch.setattr(cli, 'load_runtime', load)
    monkeypatch.setattr(cli, 'make_case', construction)
    assert cli.main(arguments(tmp_path)) == 1
    record = json.loads((tmp_path/'result.json').read_text())
    assert calls == []
    assert record['status'] == 'resource_limit'
    assert record['reason'] == 'driver_wall_budget'


@dataclass
class Point:
    temperature_k: float = 330.
    pressure_pa: float = 100000.


@dataclass
class Inverse:
    point: Point


@dataclass
class Cell:
    fixed_composition_inverse: Inverse


@dataclass
class State:
    liquid_water_mol: float = .01
    gas_amounts_mol: tuple = (.001, .002, .0001)
    internal_energy_j: float = -10.


@dataclass
class Face:
    energy_j: F


@dataclass
class Ledger:
    boundary_water_mol: F
    boundary_heat_j: F
    boundary_enthalpy_j: F
    boundary_energy_decomposition_j: F
    faces: tuple
    cells: tuple


@dataclass
class Initialization:
    status: str = 'completed'
    reason: None = None


@dataclass
class Run:
    ledgers: tuple
    states: tuple
    times_s: tuple
    status: str = 'completed'
    reason: None = None
    energy_roundoff_used_j: F = F()
    inventory_roundoff_used_mol: F = F()


def test_successful_four_steps_serialize_all_cumulative_ledgers(tmp_path, monkeypatch):
    cells = (Cell(Inverse(Point())), Cell(Inverse(Point(333., 101000.))))
    ledgers = tuple(Ledger(F(i,100),F(2*i),F(-3*i),F(i,1000),
        (Face(F(-5*i)),),cells) for i in (1,2,3,4))
    states = ((State(),State()),)*5
    run = Run(ledgers,states,tuple(F(i,4) for i in range(5)))
    policy = SimpleNamespace(definition=lambda: {'manufactured': True})
    monkeypatch.setattr(cli,'make_case',lambda root,progress: ('manufactured_column',states[0],(Point(),Point())))
    monkeypatch.setattr(cli,'load_runtime',lambda: (lambda *a,**kw:Initialization(),lambda *a,**kw:run,policy))
    assert cli.main(arguments(tmp_path)) == 0
    record = json.loads((tmp_path/'result.json').read_text())
    def fraction(name):
        value=record['observables'][name]
        return F(value['numerator'],value['denominator'])
    assert fraction('boundary_water_mol') == F(1,10)
    assert fraction('boundary_heat_j') == 20
    assert fraction('boundary_enthalpy_j') == -30
    assert fraction('boundary_energy_decomposition_j') == F(1,100)
    assert fraction('signed_outward_energy_j') == -50
    assert len(record['run']['ledgers']) == 4
    assert record['material_qualified'] is False and record['training_eligible'] is False
