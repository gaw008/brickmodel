"""One passive complete-graph comparison; never imports application or EOS code."""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import math
import traceback

BASE=Path('/private/tmp/arlabosse-equilibrium-transport-v1')
WORK=BASE/'cli/root-execution'
OUT=BASE/'cli/saved-review'
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
PKG=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')

def read(path):
    def bad(value):raise ValueError('nonfinite_json:'+value)
    return json.loads(path.read_text(),parse_constant=bad)

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def frac(value):
    if isinstance(value,dict):return F(value['numerator'],value['denominator'])
    return F(value)

def encode(value):
    if isinstance(value,F):return {'numerator':value.numerator,'denominator':value.denominator}
    raise TypeError(type(value).__name__)

def pointer(key):return str(key).replace('~','~0').replace('/','~1')

def graph_compare(old,new,prefix):
    """Compare every field/type/value, preserving float binary64 including signed zero."""
    stack=[(old,new,prefix)];diff=[];counts={'containers':0,'scalars':0,'numeric_scalars':0}
    while stack:
        left,right,path=stack.pop()
        if type(left) is not type(right):
            diff.append({'path':path,'kind':'type','old_type':type(left).__name__,'new_type':type(right).__name__})
        elif isinstance(left,dict):
            counts['containers']+=1
            for key in left.keys()|right.keys():
                if key not in left or key not in right:
                    diff.append({'path':path+'/'+pointer(key),'kind':'missing_key','old_present':key in left,'new_present':key in right})
                else:stack.append((left[key],right[key],path+'/'+pointer(key)))
        elif isinstance(left,list):
            counts['containers']+=1
            if len(left)!=len(right):diff.append({'path':path,'kind':'length','old':len(left),'new':len(right)})
            for i,(a,b) in enumerate(zip(left,right)):stack.append((a,b,path+'/'+str(i)))
        else:
            counts['scalars']+=1
            if type(left) in (int,float):counts['numeric_scalars']+=1
            same=(left.hex()==right.hex() if type(left) is float else left==right)
            if not same:diff.append({'path':path,'kind':'value','old':left,'new':right})
    return {'counts':counts,'differences':sorted(diff,key=lambda x:x['path'])}

result={'status':'FAIL','checks':{},'complete_graphs':{},'metadata_differences':[]}
checks=result['checks']
try:
    cli=read(WORK/'native01/result.json')
    initial=read(BASE/'native01/INITIAL.json');initialized=read(BASE/'native01/INITIALIZATION.json')
    run=read(BASE/'native01/RUN_1.json');inputs=read(BASE/'native01/INPUTS.json')
    accepted=read(BASE/'native01/ACCEPTANCE.json');old_obs=read(BASE/'native01/OBSERVABLES.json')
    pairs={'initial_states':(initial['states'],cli['initial_states']),
        'initial_points':(initial['points'],cli['initial_points']),
        'model_provenance':(initial['provenance'],cli['model_provenance']),
        'construction_prefix':({'states':initial['states'],'points':initial['points']},cli['construction_prefix']),
        'last_completed_construction_point':(initial['points'][-1],cli['last_completed_construction_point']),
        'initialization':(initialized,cli['initialization']),
        'run':(run,cli['run']),
        'flash_policy':(inputs['flash_policy'],cli['flash_policy'])}
    all_diff=[]
    for name,(old,new) in pairs.items():
        result['complete_graphs'][name]=graph_compare(old,new,'/'+name)
        all_diff.extend(result['complete_graphs'][name]['differences'])
    allowed={'/initialization/elapsed_seconds','/run/elapsed_seconds','/run/initialization/elapsed_seconds'}
    checks['complete_graph_only_explicit_execution_times_differ']=all(d['kind']=='value' and d['path'] in allowed for d in all_diff)
    result['graph_differences']=all_diff
    checks['physical_time_exact']=cli['run']['times_s']==run['times_s']==[{'numerator':0,'denominator':1},{'numerator':1,'denominator':1}]
    checks['returned_initialization_and_raw_continuity']=(cli['run']['initialization']==cli['initialization']
        and cli['run']['states'][0]==cli['initialization']['states']
        and cli['initialization']['raw_states']==cli['initial_states'])
    checks['old_acceptance_connected']=accepted['passed'] is True and all(v is True for v in accepted['checks'].values())
    checks['prior_independent_acceptance_connected']=read(BASE/'saved-review/SAVED_REVIEW01.json')['status']=='PASS'
    checks['terminal_and_qualification']=(cli['status']=='completed' and cli['stage']=='complete'
        and cli['material_qualified'] is False and cli['training_eligible'] is False
        and cli['full_equilibrium_temperature_error_bound_k'] is None
        and cli['qualification']=='one_second_exploratory_research_not_material_or_full_firing_validation'
        and cli['pending_initial_inventory'] is None and cli['pending_temperature_k'] is None
        and all(x['status']=='completed' and x['failed_trial'] is None and x['material_qualified'] is False
                and x['training_eligible'] is False for x in (cli['initialization'],cli['run'])))
    checks['unknowns_retained']=cli['unknown_errors']==['equilibrium composition/log error','source material transfer','low-moisture extension','instantaneous equilibrium timescale']
    checks['budget_and_input_policy']=(cli['inputs']['steps']==inputs['steps']==1 and cli['inputs']['duration_s']==inputs['duration_s']==1.
        and cli['budgets']['initialization_s']==40 and cli['budgets']['integration_s']==100 and cli['budgets']['driver_s']==150
        and cli['budgets']['energy_roundoff_j']==1e-8 and cli['budgets']['inventory_roundoff_mol']==1e-12
        and cli['source_root']==str(ROOT))
    result['metadata_differences']=[
        {'cli_path':'/budgets/initialization_s','native_path':'INPUTS.json/initialization_seconds','old':inputs['initialization_seconds'],'new':cli['budgets']['initialization_s']},
        {'cli_path':'/budgets/integration_s','native_path':'INPUTS.json/integration_seconds','old':inputs['integration_seconds'],'new':cli['budgets']['integration_s']},
        {'cli_path':'/budgets/driver_s','native_path':'INPUTS.json/driver_seconds','old':inputs['driver_seconds'],'new':cli['budgets']['driver_s']},
        {'cli_path':'/elapsed_seconds','native_path':'ACCEPTANCE.json/driver_seconds','old':accepted['driver_seconds'],'new':cli['elapsed_seconds'],
         'scope':'CLI recorded before final write; native through checks/input comparison; execution time only'}]
    rows=cli['run']['ledgers'];states=cli['run']['states']
    sums={key:sum((frac(row[key]) for row in rows),F()) for key in
        ('boundary_water_mol','boundary_heat_j','boundary_enthalpy_j','boundary_energy_decomposition_j')}
    sums['signed_outward_energy_j']=sum((frac(row['faces'][-1]['energy_j']) for row in rows),F())
    final=[]
    for state,cell in zip(states[-1],rows[-1]['cells']):
        p=cell['fixed_composition_inverse']['point']['fluid']['mechanical']
        final.append({'temperature_k':p['temperature_k'],'pressure_pa':p['pressure_pa'],
            'condensed_water_mol':state['liquid_water_mol'],'vapor_water_mol':state['gas_amounts_mol'][2],'internal_energy_j':state['internal_energy_j']})
    checks['all_step_cumulative_observables']=all(frac(cli['observables'][key])==v for key,v in sums.items()) and cli['observables']['final_cells']==final
    water=lambda row:sum((F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]) for s in row),F())
    energy=lambda row:sum((F(s['internal_energy_j']) for s in row),F())
    dn=sum((sum((frac(x) for x in l['roundoff']['liquid_mol']),F())+sum((frac(g[2]) for g in l['roundoff']['gas_mol']),F()) for l in rows),F())
    du=sum((sum((frac(x) for x in l['roundoff']['energy_j']),F()) for l in rows),F())
    checks['independent_cumulative_water_U']=(water(states[-1])-water(states[0])==-sums['boundary_water_mol']+dn
        and energy(states[-1])-energy(states[0])==-sums['signed_outward_energy_j']+du)
    checks['independent_Q_H_decomposition']=-sums['signed_outward_energy_j']==sums['boundary_heat_j']-sums['boundary_enthalpy_j']-sums['boundary_energy_decomposition_j']
    checks['old_outward_water_observation']=sums['boundary_water_mol']==frac(old_obs['outward_water_mol'])
    meta=read(WORK/'supervised-native01/metadata.json');status=read(WORK/'supervised-native01/status.json')
    old_meta=read(BASE/'supervised-native01/metadata.json')
    before=meta['inputs_before'];normalized={p:v['sha256'] for p,v in before.items()}
    expected=set(old_meta['inputs_before'])|{str(ROOT/'examples/sandbox/run_equilibrium_drying.py'),str(WORK/'PLAN.md'),str(WORK/'launch.py')}
    checks['complete_2795_input_set']=set(before)==expected and len(before)==2795
    checks['all_input_before_after_current']=(normalized==status['inputs_after'] and status['inputs_unchanged'] is True
        and all(sha(Path(p))==v['sha256'] and Path(p).stat().st_size==v['bytes'] for p,v in before.items()))
    checks['original_input_hashes_preserved']=all(before[p]==v for p,v in old_meta['inputs_before'].items())
    checks['reviewed_script_and_plan_identity']=(sha(ROOT/'examples/sandbox/run_equilibrium_drying.py')=='c1e567f6f1fd74d488d0e64c66b650d494711c3ed786f4f3aae7d79c430b1df8'
        and sha(WORK/'PLAN.md')=='1df694da097944c11af1723b8c080c3bf148382dca630b2fc2c0052c1890940a'
        and sha(WORK/'launch.py')=='be6612996ebfb6757de51ed88e52bc42b316393851bf3200f66399e60fcb3aec')
    checks['process_reaped_and_budgets']=(status['status']=='complete' and status['returncode']==0
        and status['cleanup']['leader_reaped'] is True and status['cleanup']['signal_errors']==[]
        and status['elapsed_s']<=170 and meta['timeout_s']==165 and meta['cleanup_grace_s']==5
        and cli['elapsed_seconds']<=150 and cli['initialization']['elapsed_seconds']<=40 and cli['run']['elapsed_seconds']<=100)
    freeze=read(BASE/'install/IDENTITY01.json')
    checks['source_and_installed_freeze']=len(freeze['members'])==186 and freeze['python_modules']==179 and all(
        sha(ROOT/'src/sludge_sandbox'/p)==v==sha(PKG/p) for p,v in freeze['members'].items())
    pins=read(BASE/'time-refinement/BASELINE.json')['sha256']
    checks['prior_native_artifact_pins']=all(sha(Path(p))==v for p,v in pins.items())
    result['metrics']={'observables':sums,'final_cells':final,'input_count':len(before),
        'seconds':{'initialization':cli['initialization']['elapsed_seconds'],'integration':cli['run']['elapsed_seconds'],
            'CLI_recorded':cli['elapsed_seconds'],'supervisor':status['elapsed_s']},
        'graph_scalar_count':sum(x['counts']['scalars'] for x in result['complete_graphs'].values()),
        'graph_numeric_scalar_count':sum(x['counts']['numeric_scalars'] for x in result['complete_graphs'].values())}
except Exception:
    checks['audit_exception']=False;result['exception']=traceback.format_exc()
result['failed']=[k for k,v in checks.items() if v is not True]
result['status']='FAIL' if result['failed'] else 'PASS'
result['script_sha256']=sha(Path(__file__))
result['input_artifact_sha256']={str(p):sha(p) for p in (WORK/'native01/result.json',WORK/'supervised-native01/metadata.json',WORK/'supervised-native01/status.json',BASE/'native01/INITIAL.json',BASE/'native01/INITIALIZATION.json',BASE/'native01/RUN_1.json')}
with (OUT/'COMPARISON01.json').open('x') as f:json.dump(result,f,default=encode,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failed':result['failed'],
    'graph_differences':result.get('graph_differences'),'metrics':result.get('metrics'),
    'exception':result.get('exception')},default=encode,ensure_ascii=False))
raise SystemExit(bool(result['failed']))
