"""New Chinese CLI only: manufactured callbacks / static comparison, no EOS."""
import importlib.util
import json
from pathlib import Path
import sys
from dataclasses import dataclass

import pytest

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
EXAMPLE = ROOT/'examples/sandbox/run_equilibrium_drying.py'
spec = importlib.util.spec_from_file_location('equilibrium_drying_example', EXAMPLE)
example = importlib.util.module_from_spec(spec)
spec.loader.exec_module(example)


@dataclass
class FailedResult:
    status: str = 'numerical_failure'
    reason: str = 'manufactured_specific_failure'
    failed_trial: object = None


def args(tmp_path, steps=1):
    return ['--source-root', str(tmp_path), '--output', str(tmp_path/'result.json'), '--steps', str(steps)]


def install_runtime(monkeypatch, initialize, integrate):
    class Policy:
        def definition(self):
            return {'manufactured': True}
    monkeypatch.setattr(example, 'load_runtime', lambda: (initialize, integrate, Policy()))


def test_construction_failure_keeps_input_and_completed_prefix(tmp_path, monkeypatch):
    def make_case(root, progress):
        assert json.loads((tmp_path/'result.json').read_text())['status'] == 'prepared'
        progress({'construction_prefix': {'states': ('manufactured_state',), 'points': ('manufactured_point',)}})
        raise ValueError('manufactured_missing_source')
    monkeypatch.setattr(example, 'make_case', make_case)
    install_runtime(monkeypatch, None, None)
    assert example.main(args(tmp_path)) == 1
    record = json.loads((tmp_path/'result.json').read_text())
    assert record['reason'] == 'manufactured_missing_source'
    assert record['inputs']['initial_cells'][0][1] == [.0000714, .0002686, .000001]
    assert record['construction_prefix']['points'] == ['manufactured_point']
    assert record['material_qualified'] is False


def test_failed_initialization_keeps_raw_trial_and_does_not_integrate(tmp_path, monkeypatch):
    failure = FailedResult(failed_trial={'last_completed_provider_result': {'actual': 7}, 'trials': [1, 2]})
    monkeypatch.setattr(example, 'make_case', lambda root, progress: ('column', ('state',), ('point',)))
    def initialize(*a, **kw):
        assert kw['maximum_wall_seconds'] == 40.
        return failure
    def forbidden(*a, **kw):
        pytest.fail('integration called after failed initialization')
    install_runtime(monkeypatch, initialize, forbidden)
    assert example.main(args(tmp_path)) == 1
    record = json.loads((tmp_path/'result.json').read_text())
    assert record['initialization']['failed_trial']['last_completed_provider_result'] == {'actual': 7}
    assert record['initialization']['reason'] == failure.reason
    assert record['run'] is None


def test_save_serialization_error_preserves_prior_bytes(tmp_path):
    path = tmp_path/'save.json'
    with path.open('x+') as stream:
        example.save(stream, {'prior': 1})
        before = path.read_bytes()
        with pytest.raises(ValueError):
            example.save(stream, {'bad': float('nan')})
        assert path.read_bytes() == before


def test_existing_output_and_invalid_steps_do_not_load_runtime(tmp_path, monkeypatch):
    monkeypatch.setattr(example, 'load_runtime', lambda: pytest.fail('runtime must not load'))
    output = tmp_path/'result.json'; output.write_text('preserve')
    with pytest.raises(SystemExit):
        example.main(args(tmp_path))
    assert output.read_text() == 'preserve'
    output.unlink()
    with pytest.raises(SystemExit):
        example.main(args(tmp_path, 3))
    assert not output.exists()


@pytest.mark.parametrize('steps', [2, 4])
def test_failed_run_preserves_accepted_prefix_and_original_budgets(tmp_path, monkeypatch, steps):
    initialized = FailedResult(status='completed', reason=None)
    failure = FailedResult(failed_trial={'accepted_prefix': [0, .25], 'last_completed_provider_result': {'actual': 8}})
    monkeypatch.setattr(example, 'make_case', lambda root, progress: ('column', ('state',), ('point',)))
    def integrate(column, previous, **kw):
        assert previous is initialized
        assert kw['duration_s'] == 1. and kw['steps'] == steps
        assert kw['maximum_wall_seconds'] == 100.
        assert kw['energy_roundoff_budget_j'] == 1e-8
        assert kw['inventory_roundoff_budget_mol'] == 1e-12
        return failure
    install_runtime(monkeypatch, lambda *a, **kw: initialized, integrate)
    assert example.main(args(tmp_path, steps)) == 1
    record = json.loads((tmp_path/'result.json').read_text())
    assert record['run']['failed_trial']['accepted_prefix'] == [0, .25]
    assert record['run']['failed_trial']['last_completed_provider_result'] == {'actual': 8}


def test_timeout_after_initialize_keeps_returned_result(tmp_path, monkeypatch):
    from types import SimpleNamespace
    clock = [0.]
    monkeypatch.setattr(example, 'time', SimpleNamespace(monotonic=lambda: clock[0]))
    monkeypatch.setattr(example, 'make_case', lambda root, progress: ('column', ('state',), ('point',)))
    def initialize(*a, **kw):
        clock[0] = 151.
        return FailedResult(status='completed', reason=None, failed_trial={'actual_return': 'preserved'})
    install_runtime(monkeypatch, initialize, lambda *a, **kw: pytest.fail('must stop after late initialization'))
    assert example.main(args(tmp_path)) == 1
    record = json.loads((tmp_path/'result.json').read_text())
    assert record['status'] == 'resource_limit'
    assert record['initialization']['failed_trial']['actual_return'] == 'preserved'
    assert record['run'] is None


def test_static_same_source_construction_binary64_inventory_and_policy():
    import ast
    base = Path('/private/tmp/arlabosse-equilibrium-transport-v1')
    original = ast.parse((base/'native_case.py').read_text())
    new = ast.parse(EXAMPLE.read_text())
    old_case = next(n for n in original.body if isinstance(n, ast.FunctionDef) and n.name == 'make_case')
    new_case = next(n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == 'make_case')

    class RootName(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Name(id='ROOT', ctx=node.ctx), node) if node.id == 'root' else node

    def construction(function):
        body = function.body
        start = next(i for i, n in enumerate(body) if isinstance(n, ast.Assign)
                     and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'wet')
        stop = next(i for i, n in enumerate(body) if isinstance(n, ast.Assign)
                    and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'column'
                    and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name)
                    and n.value.func.id == 'replace')
        return ast.dump(RootName().visit(ast.Module(body=body[start:stop+1], type_ignores=[])), include_attributes=False)

    assert construction(old_case) == construction(new_case)
    old_cells = ast.literal_eval(next(n.iter for n in old_case.body if isinstance(n, ast.For)))
    new_cells = ast.literal_eval(next(n.value for n in new.body if isinstance(n, ast.Assign)
                                     and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'INITIAL_CELLS'))
    assert repr(old_cells) == repr(new_cells)
    for old, current in zip(old_cells, new_cells):
        assert [v.hex() for v in old[1]] == [v.hex() for v in current[1]]
    old_opened = next(n for n in old_case.body if isinstance(n, ast.Assign)
                      and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'opened')
    new_opened = next(n for n in new_case.body if isinstance(n, ast.Assign)
                      and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'opened')
    assert ast.dump(old_opened) == ast.dump(new_opened)
    native_driver = ast.parse((base/'native_driver.py').read_text())
    old_policy = next(n for n in native_driver.body if isinstance(n, ast.Assign)
                      and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'policy')
    runtime = next(n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == 'load_runtime')
    new_policy = next(n for n in runtime.body if isinstance(n, ast.Assign))
    assert ast.dump(old_policy) == ast.dump(new_policy)
    assert '/private/tmp' not in EXAMPLE.read_text() and '/Users/' not in EXAMPLE.read_text()


def test_isolated_help_needs_no_installed_physics_or_output(tmp_path):
    import subprocess
    result = subprocess.run([sys.executable, '-I', str(EXAMPLE), '--help'],
                            capture_output=True, text=True, timeout=5)
    assert result.returncode == 0
    assert '--source-root' in result.stdout and '{1,2,4}' in result.stdout
    assert not (tmp_path/'result.json').exists()
