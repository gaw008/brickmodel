# 两格 1 s 排湿 CLI 示例交接

新正式文件仅 `examples/sandbox/run_equilibrium_drying.py`，254 行。其他核心模块、旧原生轨迹和 1/2/4 比较记录未改。此时示例尚未运行实际 EOS；唯一实际 CLI smoke 由 ROOT 在独审冻结后执行。

调用（从项目目录，使用已安装 sludge-vme 的 Python）：

```sh
python -I examples/sandbox/run_equilibrium_drying.py --source-root "$PWD" --output /tmp/equilibrium-drying-new.json --steps 1
```

`--source-root` 和 `--output` 必需；根目录需含原 data/sandbox 与忽略的原件缓存，输出父目录须存在且目标不许已存在。脚本没有本机硬编码路径，不导入任何旧 scratch 脚本。`--steps` 仅 1/2/4，默认 1，固定总物理 1 s；没有恢复、长时、全周期或认证入口。

实际构造直接保留原 native_case：相同来源热力学/储能、k/D、压力域和流体数值包络、几何、固定组成 inverse T1e−8 K、相变系数显式0以禁用旧动力学、选择性蒸汽口与333K热浴。两格原始 O2/N2/Nv 分量 `(0.0000714,0.0002686,0.000001)` / `(0.0000672,0.0002528,0.000001)` 保留原 binary64 常量，不重新拆总量。flash 参数保持原 U/μ/peq/组成/迭代/域门；预算采用新已登记初始化40 s、积分100 s、driver150 s。内部时钟不能中断正在运行的 EOS，示例自身不提供外部进程组监督。

输出先写虚拟工况与资格说明，再记录完整 model_provenance；各原初库存/温度在能量调用前保存，已完成原初点/构造前缀在返回后先保存再检查时钟。实际初始化和完整 run 也先存返回对象，再查超时/失败。原 core 的完整 trial、最后已返回物性、接受前缀、所有逐格账本、实际费用和来源均随返回对象保存。累计外水/Q/H/分解残差及带符号 Eout 从全部动态账本求和；零时刻初始化单独保留。物理通量与全平衡误差未量化，固定组成温度界不冒充整体平衡温度证书。材料和训练资格持续 false。

退出码 0 仅表示这个 1 s 研究请求完成并保存；运行失败/超时返回1，参数/创建输出/结果保存失败返回2。独占创建拒绝覆盖（包括已有符号链接）；完整 JSON 在内存序列化后才写，序列化失败保留上一快照，但后续 I/O 失败可能使输出不完整，终端提示明确这一限制。记录 elapsed 是第一次最终写入前的值；该写入后再查150 s，若越时保留 run 并改 resource_limit，末次状态保存与 stdout 不是底层 EOS 的中断保证。

真实作者检查：`AUTHOR_RED01.log` 保留实现前缺文件的 collection RED；`AUTHOR_GREEN02.log` 9 项通过0.08 s。范围为制造构造失败/已完成前缀、初始化失败原trial、steps2/4积分失败保留接受前缀和原资源门、provider正常返回后才越时的保存、序列化失败保留旧字节、拒绝覆盖/非法步数、隔离 `-I --help`、静态原工况比较。静态比较对源构造块/边界/Flash policy做 AST 相等检查，并对原初气量逐项 float.hex 相等；没有调用物性。AST 解析通过；ruff/mypy/pylint/black 不可用，未安装。SHA01.txt 固定候选代码和作者测试；独立代码审查另行进行。

独审唯一 MEDIUM 已有限修复：load_runtime 返回后先保存 policy definition 和 runtime_loaded 阶段，再 guard，越过150 s不进入 make_case。review/INDEPENDENT02.log/xml 保留真实1失败/1通过；作者只运行受影响的 test_runtime_return_past_budget_stops_before_source_construction，RUNTIME_GUARD_GREEN01.log 为1通过，未重跑原9项或实际EOS。
