"""Prospective same-runtime continuation experiment. Requires a frozen manifest."""
from pathlib import Path
from dataclasses import replace, fields
import argparse
import hashlib
import json
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
PRIOR = Path('/private/tmp/brick-exact-record-native-v1/attempt01')
WATER = Path('/private/tmp/brick-free-native-events-v1/attempt01/water')
CASE_SHA = '9d930a6c6d60cf328e5abe2e61dc6a5f9f0cf06d9453827b84d0f0b56e5746f4'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def audit_output(report):
    from sludge_sandbox.verification_case import encode
    return {f.name: encode(getattr(report, f.name)) for f in fields(report)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('cancel', 'resume'), required=True)
    args = parser.parse_args()
    manifest_path = ROOT / 'freeze.json'
    manifest = json.loads(manifest_path.read_text())
    require(manifest.get('status') == 'FROZEN', 'runtime_manifest_unfilled')
    out = ROOT / args.phase
    out.mkdir(exist_ok=False)

    def save(name, value):
        (out / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

    began = time.monotonic()
    report = {'status': 'started', 'phase': args.phase, 'new_trajectory': True}
    paths = [Path(p) for p in manifest['inputs']]
    paths.append(manifest_path)
    required_paths = [ROOT / 'run.py', ROOT / 'supervise.py', ROOT / 'PLAN.md']
    required_paths += [PRIOR / n for n in ('case.json', 'initial.json', 'integration-policy.json', 'event-policy.json')]
    required_paths += [p for p in WATER.rglob('*') if p.is_file()]
    require(all(str(p) in manifest['inputs'] for p in required_paths), 'incomplete_frozen_inputs')
    if args.phase == 'resume':
        paths += [ROOT / 'resume-input.json'] + list((ROOT / 'cancel').glob('*.json'))
    before = None
    inputs = {}
    calls = []
    commits = []
    try:
        inputs = {str(p): sha(p) for p in paths}
        save('inputs-before.json', inputs)
        require(all(inputs[p] == h for p, h in manifest['inputs'].items()), 'frozen_input_changed')
        require(sha(PRIOR / 'case.json') == CASE_SHA, 'original_case_changed')
        import sludge_sandbox
        from sludge_sandbox.verification_case import read_case, build_case, encode
        from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
        from sludge_sandbox.exact_event_clock import ExactEventTime as T
        from sludge_sandbox.exact_depletion_integration import integrate_exact_depletion
        from sludge_sandbox.exact_continuation_admission import ExactContinuationRequest
        from sludge_sandbox.exact_record import encode_exact_run, read_exact_run, pack, canonical
        from sludge_sandbox.exact_projection_restore import restore_exact_projection
        from sludge_sandbox.exact_record_audit import audit_exact_run
        from sludge_sandbox.exact_terminal_proof_audit import audit_committed_terminal_proofs
        from sludge_sandbox.exact_record_comparison_audit import audit_exact_comparisons
        from sludge_sandbox.exact_resource_audit import audit_exact_resources
        from sludge_sandbox.run_service import runtime_identity
        require(str(Path(sludge_sandbox.__file__).resolve()).startswith('/private/tmp/brick-water-backend-probe/venv/'), 'installed_import_required')
        before = runtime_identity()
        save('runtime-before.json', before)
        require(before == manifest['runtime'], 'new_runtime_not_frozen_version')
        tick = time.monotonic()
        built = build_case(read_case(PRIOR / 'case.json'), WATER)
        report['build_elapsed_s'] = time.monotonic() - tick
        policy = replace(built.depletion_policy, ordered_event_policy='ordered_affine_packet_v1')
        for name, value in (('initial.json', built.initial), ('integration-policy.json', built.policy), ('event-policy.json', policy)):
            save(name, encode(value))
            require(encode(value) == json.loads((PRIOR / name).read_text()), 'original_' + name + '_changed')
        op = ExactFreeWaterTransfer(built.operator)
        start, end = T.from_float(built.start_s), T.from_float(built.end_s)
        parent = None
        request = None
        if args.phase == 'resume':
            parent_path = ROOT / 'cancel' / 'exact-run-record.json'
            parent_raw = parent_path.read_bytes()
            parent_sha = hashlib.sha256(parent_raw).hexdigest()
            authorization = json.loads((ROOT / 'resume-input.json').read_text())
            require(authorization['parent_sha256'] == parent_sha, 'frozen_parent_hash_mismatch')
            require(authorization['freeze_sha256'] == sha(manifest_path), 'parent_runtime_manifest_mismatch')
            require(json.loads((ROOT / 'cancel' / 'report.json').read_text())['status'] == 'passed', 'parent_phase_not_passed')
            require(json.loads((ROOT / 'cancel' / 'runtime-before.json').read_text()) == before, 'parent_runtime_mismatch')
            parent = read_exact_run(parent_raw)
            request = ExactContinuationRequest(parent_raw, parent_sha, CASE_SHA, before)
            save('parent-link.json', {'parent_sha256': parent_sha, 'freeze_sha256': sha(manifest_path)})
        armed = [False]

        def committed(info):
            commits.append(pack(info))
            if args.phase == 'cancel' and info[0] >= 1:
                armed[0] = True

        tick = time.monotonic()
        try:
            result = integrate_exact_depletion(built.initial, op, start=start, end=end,
                integration_policy=built.policy, event_policy=policy,
                continuation=request, cancel=lambda: armed[0], on_commit=committed)
        finally:
            report['integrate_call_elapsed_s'] = time.monotonic() - tick
            save('commits.json', commits)
        save('calls.json', {'telemetry_origin': 'core_cumulative_counters',
            'independent_EOS_journal': False, 'costs': dict(result.costs)})
        save('result.json', pack(result))
        raw = encode_exact_run(result, original_operator=op, start=start, end=end,
            case_sha256=CASE_SHA, runtime_identity=before)
        (out / 'exact-run-record.json').write_bytes(raw)
        checked = read_exact_run(raw)
        common = dict(original_initial=built.initial, start=start, end=end,
            integration_policy=built.policy, event_policy=policy, case_sha256=CASE_SHA, runtime_identity=before)
        tick = time.monotonic()
        audits = {}
        for name, invoke in (
            ('prefix', lambda: audit_exact_run(checked, op, **common)),
            ('terminal', lambda: audit_committed_terminal_proofs(raw, original_operator=op, **common)),
            ('comparison', lambda: audit_exact_comparisons(checked, op, **common)),
            ('resource', lambda: audit_exact_resources(checked, original_policy=built.policy))):
            audits[name] = audit_output(invoke())
            save('audit-' + name + '.json', audits[name])
        restored = restore_exact_projection(raw, original_operator=op, case_sha256=CASE_SHA, runtime_identity=before)
        reencoded = encode_exact_run(restored.result, original_operator=op, start=start, end=end,
            case_sha256=CASE_SHA, runtime_identity=before)
        (out / 'reencoded-record.json').write_bytes(reencoded)
        report['audit_restore_elapsed_s'] = time.monotonic() - tick
        report.update(record_sha256=hashlib.sha256(raw).hexdigest(), accepted_steps=len(result.steps),
            packets=len(result.packets), core_status=result.status, core_reason=result.reason,
            cumulative_elapsed_s=result.elapsed_seconds, costs=dict(result.costs), byte_identical=raw == reencoded)
        save('checks-before-assertions.json', report)
        require(raw == reencoded, 'record_reencode_mismatch')
        if args.phase == 'cancel':
            require(result.status == 'cancelled' and result.steps and start < result.times_s[-1] < end, 'no_accepted_cancelled_interior_prefix')
            require(not result.packets and result.operator.operator.interfaces == op.operator.interfaces, 'early_ordinary_target_not_met')
        else:
            require(result.status == 'completed' and result.times_s[-1] == end, 'original_endpoint_not_completed')
            require(sum(len(packet) for packet in result.packets) == 2, 'original_two_events_required')
            restored_parent = restore_exact_projection(parent_raw, original_operator=op, case_sha256=CASE_SHA, runtime_identity=before).result
            for field in ('times_s', 'states', 'steps', 'packets', 'refinements', 'terminal_attempts'):
                old = getattr(restored_parent, field)
                require(canonical(pack(getattr(result, field)[:len(old)])) == canonical(pack(old)), 'parent_history_changed:' + field)
            require(all(result.costs[k] >= v for k, v in restored_parent.costs.items()), 'cost_reset')
            require(result.elapsed_seconds >= restored_parent.elapsed_seconds, 'wall_reset')
        report['status'] = 'passed'
    except BaseException:
        report.update(status='failed', traceback=traceback.format_exc())
    finally:
        try:
            if before is not None:
                after = runtime_identity()
                save('runtime-after.json', after)
                require(after == before, 'runtime_changed')
            after_inputs = {str(p): sha(p) for p in paths}
            save('inputs-after.json', after_inputs)
            require(after_inputs == inputs, 'inputs_changed')
        except BaseException:
            report.update(status='failed', integrity_error=traceback.format_exc())
        report['runner_elapsed_s'] = time.monotonic() - began
        save('report.json', report)
    require(report['status'] == 'passed', 'phase_failed_see_report')


if __name__ == '__main__':
    main()
