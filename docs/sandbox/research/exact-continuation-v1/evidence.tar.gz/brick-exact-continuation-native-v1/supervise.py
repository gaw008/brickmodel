"""Prospective bounded phase supervisor; never fills its own approval manifest."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--phase', choices=('cancel', 'resume'), required=True)
phase = parser.parse_args().phase
manifest = json.loads((root / 'freeze.json').read_text())
if manifest.get('status') != 'FROZEN':
    raise ValueError('runtime_manifest_unfilled')
source = Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/research-process-supervisor/supervisor.py')
if hashlib.sha256(source.read_bytes()).hexdigest() != '939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1':
    raise ValueError('supervisor_identity_changed')
spec = importlib.util.spec_from_file_location('research_supervisor', source)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
inputs = [Path(p) for p in manifest['inputs']] + [root / 'freeze.json', source]
if phase == 'resume':
    inputs += [root / 'resume-input.json'] + list((root / 'cancel').glob('*.json'))
result = module.run_attempt(root / ('supervised-' + phase),
    ['/private/tmp/brick-water-backend-probe/venv/bin/python', str(root / 'run.py'), '--phase', phase],
    cwd='/private/tmp', input_paths=inputs, timeout_s=90 if phase == 'cancel' else 180,
    cleanup_grace_s=.1)
print(json.dumps(result, indent=2))
if result['returncode'] != 0:
    raise SystemExit(1)
