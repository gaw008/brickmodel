from dataclasses import fields
from fractions import Fraction as F
import json
import pytest
import run
from sludge_sandbox.exact_record_audit import PartialExactAudit
from sludge_sandbox.exact_resource_audit import ResourceAudit
from sludge_sandbox.exact_record_comparison_audit import ExactComparisonAudit
from sludge_sandbox.exact_terminal_proof_audit import TerminalProofReport

@pytest.mark.parametrize('report',[
    PartialExactAudit('a'*64,1,0,{'N':F(1,3)}),
    ExactComparisonAudit('a'*64,0,0,0,0),
    ResourceAudit('a'*64,1,511,100,F(799),0,{},F(1)),
    TerminalProofReport('a'*64,0,0,0,()),
])
def test_report_encoding_preserves_all_fields(report):
    actual=run.audit_output(report)
    assert set(actual)=={f.name for f in fields(report)}
    assert actual['record_sha256']=='a'*64
    json.dumps(actual,allow_nan=False)
