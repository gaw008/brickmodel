"""Independent data-only saved lifecycle checks, no solver imports."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
R=Path(__file__).parent
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=lambda v:F(v['numerator'],v['denominator'])
p=R/'resume';parent=R/'cancel';historical=Path('/private/tmp/brick-exact-record-native-v1/attempt01')
a=load(p/'report.json');status=load(R/'supervised-resume/status.json');freeze=load(R/'freeze.json')
assert a['status']=='passed' and status['returncode']==0 and status['cleanup']['leader_reaped'] and status['inputs_unchanged']
assert load(p/'inputs-before.json')==load(p/'inputs-after.json')
assert all(sha(Path(k))==v for k,v in load(p/'inputs-before.json').items())
assert load(p/'runtime-before.json')==load(p/'runtime-after.json')==load(parent/'runtime-before.json')==freeze['runtime']
assert len(freeze['runtime']['modules'])==84
link=load(p/'parent-link.json');assert link['parent_sha256']==sha(parent/'exact-run-record.json') and link['freeze_sha256']==sha(R/'freeze.json')
assert (p/'exact-run-record.json').read_bytes()==(p/'reencoded-record.json').read_bytes()
assert a['record_sha256']==sha(p/'exact-run-record.json')
new=load(p/'exact-run-record.json');old=load(historical/'exact-run-record.json');par=load(parent/'exact-run-record.json')
n=new['result']['fields'];o=old['result']['fields'];q=par['result']['fields']
assert new['start']==old['start']==par['start'] and new['end']==old['end']==par['end']
for k in ('times_s','states','steps','packets','refinements','terminal_attempts'):
    prior=q[k]['sequence'];assert n[k]['sequence'][:len(prior)]==prior
assert n['times_s']['sequence'][-1]==new['end']
assert len(n['steps']['sequence'])==30 and len(n['packets']['sequence'])==2
assert n['status']=='completed'
for name in ('initial.json','integration-policy.json','event-policy.json'):assert load(p/name)==load(parent/name)==load(historical/name)
audits={k:load(p/('audit-'+k+'.json')) for k in ('prefix','terminal','comparison','resource')}
assert all(v['record_sha256']==a['record_sha256'] for v in audits.values())
z=audits['resource'];assert z['charged_panels']==79 and z['remaining_panels']==433
assert f(z['remaining_wall_seconds'])+f(z['cumulative_elapsed_seconds'])==800
assert z['cumulative_counters']==a['costs']
assert all(v>=load(parent/'report.json')['costs'][k] for k,v in a['costs'].items())
assert F(a['cumulative_elapsed_s'])>=F(load(parent/'report.json')['cumulative_elapsed_s'])
# Compare every raw result field, preserving all differences. Only named
# dataclass elapsed_seconds fields may be omitted in the secondary comparison.
def differences(a,b,path='$'):
    if type(a) is not type(b):return [{'path':path,'old':a,'new':b}]
    if isinstance(a,dict):
        out=[]
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b:out.append({'path':path+'.'+k,'old':a.get(k),'new':b.get(k)})
            else:out+=differences(a[k],b[k],path+'.'+k)
        return out
    if isinstance(a,list):
        if len(a)!=len(b):return [{'path':path+'.length','old':len(a),'new':len(b)}]
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+f'[{i}]')]
    return [] if a==b else [{'path':path,'old':a,'new':b}]
d= differences(o,n)
wall=[x for x in d if x['path'].endswith('.fields.elapsed_seconds.float_hex') or x['path']=='$.elapsed_seconds.float_hex']
nonwall=[x for x in d if x not in wall]
summary={'status':'passed','resume_record_sha256':a['record_sha256'],'historical_record_sha256':sha(historical/'exact-run-record.json'),
'parent_link':link,'runtime_module_count':84,'supervision_elapsed_s':status['elapsed_s'],'cumulative_elapsed_s':a['cumulative_elapsed_s'],
'prefix_preserved':True,'accepted_steps':30,'packets':2,'charged_panels':79,'all_audits':audits,
'historical_exact_grid_equal':o['times_s']==n['times_s'],'historical_states_equal':o['states']==n['states'],'historical_ledgers_equal':o['steps']==n['steps'],
'raw_result_difference_count':len(d),'explicit_elapsed_difference_count':len(wall),'nonwall_result_differences':nonwall,
'raw_result_differences':d,'qualification':'Different-runtime numerical comparison only; not old-record execution compatibility. No EOS or rerun.'}
(R/'saved-verification.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print({k:v for k,v in summary.items() if k not in ('all_audits','raw_result_differences','nonwall_result_differences')})
print('nonwall',len(nonwall))
