from pathlib import Path
import hashlib,json,shutil
import sludge_sandbox
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent;repo=Path('/Users/wanggaoying/Desktop/brickmodel-github');prior=Path('/private/tmp/brick-exact-record-native-v1/attempt01');core=Path('/private/tmp/brick-exact-continuation-v1/core');water=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'run.py')=='d494f343b593ebb6a4fd4ed085cbfc39ff7aa85a330761807ab0303212e6cdbe'
assert sha(root/'supervise.py')=='bf2ac2dbc70d73fe12a7dabb90a0d2f59b4886e40f190b8c803243b6d7af11fb'
runtime=runtime_identity();assert len(runtime['modules'])==84
assert runtime['modules']['exact_depletion_integration.py']=='5c06f392fa8415a8b6d57e9605e04074052cc9a2e04225a5df9ec35b8a2028a2'
assert runtime['modules']['exact_continuation_admission.py']=='a3819fba56f7bdf8009be1f8c7a06449f7e6c2750e663c2063ecbf56103c7432'
assert '25 passed in 15.11s' in (core/'root-installed-tests.log').read_text()
assert '65 passed in 47.41s' in (core/'root-source-tests.log').read_text()
package=Path(sludge_sandbox.__file__).parent
paths=[root/n for n in ('run.py','supervise.py','PLAN.md','RUNNER_REVIEW.md','freeze_manifest.py')]
paths += [prior/n for n in ('case.json','initial.json','integration-policy.json','event-policy.json')]
paths += [core/n for n in ('CODE_REVIEW.md','NUMERICAL_REVIEW.md','HANDOFF.md','root-installed-tests.log','root-installed-tests.xml','root-source-tests.log','root-source-tests.xml','installed-identity.json')]
paths += [p for p in water.rglob('*') if p.is_file()]
for name,h in runtime['modules'].items():
 for folder in (package,repo/'src/sludge_sandbox'):
  assert sha(folder/name)==h;paths.append(folder/name)
paths.append(repo/'docs/sandbox/research/research-process-supervisor/supervisor.py')
manifest={'status':'FROZEN','runtime':runtime,'inputs':{str(p):sha(p) for p in paths},'scope':'same_new_execution_runtime_cancel_then_resume_no_old_record_execution_compatibility','outer_seconds':{'cancel':90,'resume':180},'original_wall_seconds':800}
assert json.loads((root/'freeze.json').read_text())['status']!='FROZEN'
shutil.copyfile(root/'freeze.json',root/'freeze-unfilled.json')
(root/'freeze.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'modules':len(runtime['modules']),'frozen_inputs':len(manifest['inputs']),'freeze_sha256':sha(root/'freeze.json')}))
