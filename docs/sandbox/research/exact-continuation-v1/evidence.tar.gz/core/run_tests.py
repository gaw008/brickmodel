from pathlib import Path
import runpy
import sys
runpy.run_path(str(Path(__file__).with_name('conftest.py')))
import pytest
raise SystemExit(pytest.main(sys.argv[1:]))
