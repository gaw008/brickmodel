import importlib.util
import sys
from pathlib import Path
import sludge_sandbox
HERE=Path(__file__).parent
for name in ('exact_depletion_integration','exact_continuation_admission'):
    full='sludge_sandbox.'+name
    existing=sys.modules.get(full)
    if existing is not None and Path(existing.__file__).resolve()==(HERE/(name+'.py')).resolve():continue
    spec=importlib.util.spec_from_file_location(full,HERE/(name+'.py'))
    module=importlib.util.module_from_spec(spec);sys.modules[full]=module
    setattr(sludge_sandbox,name,module)
    spec.loader.exec_module(module)
