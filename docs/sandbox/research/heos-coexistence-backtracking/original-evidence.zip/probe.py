from pathlib import Path
import sys,json,math,hashlib,traceback
from dataclasses import asdict
from sludge_sandbox._heos_kernel import HEOSCandidate
import sludge_sandbox._heos_kernel as module
from sludge_sandbox.water_properties import load_water_properties
root=Path('/Users/wanggaoying/Desktop/brickmodel-github');here=Path(__file__).resolve().parent
mode=sys.argv[1]
manifest=root/'data/sandbox/water/heos-8.0.0-approved-manifest.json' if mode=='baseline' else here/'expected.json'
w=HEOSCandidate(manifest,root/'data/sandbox/water');reference=load_water_properties(root/'data/sandbox/water')
t=299.9996124454831
rows=[]
for temperature in [t,math.nextafter(t,-math.inf),math.nextafter(t,math.inf),t-1e-6,t+1e-6,t-1e-4,t+1e-4,t-.01,t+.01,293.,300.,500.]:
    row={'temperature_k':temperature}
    try:
        pair=w.saturation_pair(temperature);old=reference.saturation_pair(temperature)
        row['snapshots']=[asdict(x) for x in pair]
        row['reference']=[asdict(old.liquid),asdict(old.vapor)]
        for a,b in zip(pair,(old.liquid,old.vapor)):
            assert abs(a.density-b.density_kg_m3)<=2e-8*b.density_kg_m3
            assert max(abs(a.h-b.native_enthalpy_j_kg),abs(a.u-b.native_internal_energy_j_kg),temperature*abs(a.s-b.native_entropy_j_kg_k))<=.002
            assert max(abs(a.cp-b.cp_j_kg_k),abs(a.cv-b.cv_j_kg_k))<=1e-5
        row['status']='passed'
    except Exception as exc:row.update(status='failed',error=repr(exc),traceback=traceback.format_exc())
    row['coexistence']=w.last_coexistence;rows.append(row)
result={'mode':mode,'kernel_path':module.__file__,'kernel_sha256':hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),'manifest':str(manifest),'rows':rows}
(here/(mode+'-probe-result.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'mode':mode,'passed':sum(x['status']=='passed' for x in rows),'failed':[{k:x[k] for k in ('temperature_k','error')} for x in rows if x['status']=='failed']}))
raise SystemExit(0 if all(x['status']=='passed' for x in rows) else 1)
