from pathlib import Path
import sys,json
root=Path('/Users/wanggaoying/Desktop/brickmodel-github');here=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'docs/sandbox/research/research-process-supervisor'))
from supervisor import run_attempt
mode=sys.argv[1]
env=['/usr/bin/env','PYTHONDONTWRITEBYTECODE=1']
if mode!='baseline':env+=['PYTHONPATH='+str(here/'candidate')]
inputs=list((root/'src/sludge_sandbox').glob('*.py'))+list((root/'data/sandbox/water').rglob('*'))+list((here/'candidate').rglob('*.py'))+list(here.glob('*.py'))+[here/'PLAN.json']
if (here/'expected.json').exists():inputs.append(here/'expected.json')
inputs+=list(Path('/private/tmp/brick-water-backend-probe/venv/lib/python3.12/site-packages/sludge_sandbox').glob('*.py'))
v=run_attempt(here/(mode+'-attempt01'),env+['/private/tmp/brick-water-backend-probe/venv/bin/python',str(here/(mode+'.py'))],cwd='/private/tmp',input_paths=[x for x in inputs if x.is_file()],timeout_s=30)
print(json.dumps({k:v[k] for k in ('status','returncode','elapsed_s')},indent=2))
