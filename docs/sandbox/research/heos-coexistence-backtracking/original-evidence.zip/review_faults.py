"""Reviewer-owned no-EOS tests of the actual candidate transaction AST."""
import ast
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
from threading import RLock
from types import SimpleNamespace
import warnings

ROOT = Path(__file__).parent
tree = ast.parse((ROOT / 'candidate/sludge_sandbox/_heos_kernel.py').read_text())
cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'HEOSCandidate')
method = next(x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == '_transaction')
module = ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[]))

class SourceError(ValueError):
    pass

class NumericalError(ValueError):
    pass

scope = dict(contextmanager=contextmanager, hashlib=hashlib, json=json,
             warnings=warnings, WaterSourceError=SourceError, WaterNumericalError=NumericalError)
exec(compile(module, 'candidate_transaction_ast', 'exec'), scope)
transaction = scope['_transaction']

class FakeCP:
    def __init__(self):
        self.raw = '{"a":1}'
        self.config = '{}'
        self.reads = 0

    def get_config_as_json_string(self):
        return self.config

    def get_fluid_param_string(self, fluid, field):
        assert (fluid, field) == ('Water', 'JSON')
        self.reads += 1
        return self.raw

def instance():
    cp = FakeCP()
    return SimpleNamespace(_cp=cp, _config='{}', _lock=RLock(),
                           _fluid_digest=hashlib.sha256(cp.raw.encode()).hexdigest())

results = []
for case in ('stable', 'pre_content', 'post_content', 'pre_whitespace',
             'post_whitespace', 'pre_config', 'post_config', 'warning', 'nested'):
    obj = instance()
    entered = False
    expected = None
    if case.startswith('pre_'):
        if case == 'pre_config':
            obj._cp.config = '{"x":1}'
        else:
            obj._cp.raw = '{"a":2}' if case == 'pre_content' else '{ "a": 1 }'
        expected = SourceError
    elif case.startswith('post_'):
        expected = SourceError
    elif case == 'warning':
        expected = NumericalError
    try:
        with transaction(obj):
            entered = True
            if case == 'post_content': obj._cp.raw = '{"a":2}'
            if case == 'post_whitespace': obj._cp.raw = '{ "a": 1 }'
            if case == 'post_config': obj._cp.config = '{"x":1}'
            if case == 'warning': warnings.warn('review_injected', RuntimeWarning)
            if case == 'nested':
                with transaction(obj): pass
    except (SourceError, NumericalError) as exc:
        assert expected is not None and type(exc) is expected
        if case.startswith('pre_'): assert not entered
        results.append(dict(case=case, rejection=str(exc), passed=True))
    else:
        assert expected is None
        assert obj._cp.reads == (4 if case == 'nested' else 2)
        results.append(dict(case=case, raw_reads=obj._cp.reads, passed=True))
assert json.loads('{"a":1}') == json.loads('{ "a": 1 }')
(ROOT / 'review-fault-results.json').write_text(json.dumps(dict(
    scope='actual_transaction_AST_with_stub_CP_no_EOS',
    kernel_sha256=hashlib.sha256((ROOT / 'candidate/sludge_sandbox/_heos_kernel.py').read_bytes()).hexdigest(),
    cases=results), indent=2) + '\n')
print('9 no-EOS transaction checks passed')

# Actual public-method routing, with native work replaced only by stubs.
import math
import types
methods = {x.name:x for x in cls.body if isinstance(x, ast.FunctionDef)}
scope.update(math=math, WaterDomainError=SourceError,
             require=lambda condition, reason: condition or (_ for _ in ()).throw(NumericalError(reason)))
for name in ('_temperature', 'saturation_pair', 'state_tp'):
    node = methods[name]
    node.decorator_list = []
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])),
                 'candidate_public_AST', 'exec'), scope)

routes = []
for public in ('saturation_pair', 'state_tp'):
    for fault in ('none', 'fluid', 'config', 'warning'):
        obj = instance()
        obj._transaction = types.MethodType(transaction, obj)
        obj._temperature = scope['_temperature']
        obj._r = 461.51805
        obj._tp_iterations = []
        obj._cp.iphase_liquid = 1
        obj._cp.iphase_supercritical_liquid = 2
        obj._cp.iphase_gas = 3
        obj._cp.PT_INPUTS = 4
        obj._cp.DmassT_INPUTS = 5
        obj._flash = SimpleNamespace(update=lambda *a:None, phase=lambda:1,
            rhomass=lambda:1000., specify_phase=lambda *a:None, unspecify_phase=lambda:None,
            dalphar_dDelta=lambda:0., d2alphar_dDelta2=lambda:0.,
            p=lambda:100., hmass=lambda:2., umass=lambda:1.)
        obj._snapshot = lambda *a:SimpleNamespace(density=1000.)
        def saturation(t):
            assert obj._lock._is_owned()
            if fault == 'fluid': obj._cp.raw = '{ "a":1}'
            if fault == 'config': obj._cp.config = '{"x":1}'
            if fault == 'warning': warnings.warn('public_route_warning', RuntimeWarning)
            return SimpleNamespace(pressure=10.,density=900.), SimpleNamespace(density=1.)
        obj._saturation_pair_locked = saturation
        try:
            if public == 'saturation_pair': scope[public](obj,300.)
            else: scope[public](obj,300.,100.,phase='liquid')
        except (SourceError,NumericalError) as exc:
            assert fault != 'none'
            assert type(exc) is (NumericalError if fault=='warning' else SourceError)
        else:
            assert fault == 'none'
            assert obj._cp.reads == 2
        routes.append(dict(public=public,fault=fault,passed=True))
data=json.loads((ROOT/'review-fault-results.json').read_text())
data['public_routes']=routes
(ROOT/'review-fault-results.json').write_text(json.dumps(data,indent=2)+'\n')
print('8 actual-public-route no-EOS checks passed')
