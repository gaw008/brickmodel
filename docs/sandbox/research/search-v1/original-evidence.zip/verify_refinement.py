from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
from sludge_sandbox.run_service import read_run
from sludge_sandbox.job_supervisor import read_job
from audit_ledgers import audit

out = Path('/private/tmp/brick-search-v1')
search_report = json.loads((out/'verified.json').read_text())
best = search_report['best']
coarse_record = next(r for r in search_report['records'] if r['generation'] == best['generation'] and r['id'] == best['candidate_id'])
coarse_dir = Path(coarse_record['run_directory'])
fine_dir = out/'refined-job/run'
job = read_job(fine_dir.parent)
assert job['status'] == 'completed' and job['returncode'] == 0 and job['child_reaped']
coarse, coarse_manifest = read_run(coarse_dir)
fine, fine_manifest = read_run(fine_dir)
assert fine['status'] == 'completed' and len(fine['integration']['steps']) == 4
original_case = json.loads((coarse_dir/'case.json').read_text())
refined_case = json.loads((fine_dir/'case.json').read_text())
assert original_case['refinement'] == 0 and refined_case['refinement'] == 1
refined_case['refinement'] = 0
assert original_case == refined_case
coarse_span = coarse_record['span_k']
temperatures = fine['final_snapshot']['temperature_k']
fine_span = max(temperatures)-min(temperatures)
difference = abs(F(fine_span)-F(coarse_span))
assert difference <= F(1e-5)
ledger = out/'refined-ledger-input.json'
ledger.write_text(json.dumps({'run': fine['integration'], 'initial': fine['integration']['states'][0]}))
checked = audit(ledger, {})
assert checked['all_saved_prefixes_pass'] and checked['accepted_steps'] == 4
(out/'refined-ledger-audit.json').write_text(json.dumps(checked, indent=2))
others = [r['span_k'] for r in search_report['records'] if r['generation'] == best['generation'] and r['id'] != best['candidate_id']]
report = {'status': 'passed', 'coarse_span_k': coarse_span, 'fine_span_k': fine_span,
          'absolute_difference_k': float(difference), 'preregistered_limit_k': 1e-5,
          'coarse_next_candidate_gap_k': min(others)-coarse_span,
          'accepted_steps': 4, 'child_reaped': True, 'returncode': 0,
          'coarse_result_sha256': coarse_manifest['files']['result.json'],
          'fine_result_sha256': fine_manifest['files']['result.json'],
          'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'scope': 'Separate selected-case temporal refinement only; no spatial convergence, experimental uncertainty or material validation claim.'}
(out/'refinement-verification.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
