from pathlib import Path
import json
import subprocess
import time

root = Path('/Users/wanggaoying/Desktop/brickmodel-github')
out = Path('/private/tmp/brick-search-v1')
directory = out/'native-search'
cli = '/private/tmp/brick-water-backend-probe/venv/bin/sludge-sandbox'
commands = [
    ['search-prepare', str(root/'data/sandbox/search/initial-temperature-search-v1.json'),
     '--water-data', str(root/'data/sandbox/water'), '--evidence-data', str(root/'data/sandbox'),
     '--output', str(directory)],
    ['search-run', str(directory)],
    ['search-status', str(directory)],
]
for index, command in enumerate(commands):
    began = time.monotonic()
    completed = subprocess.run([cli, *command], capture_output=True, text=True, timeout=300)
    (out/f'command-{index}.stdout').write_text(completed.stdout)
    (out/f'command-{index}.stderr').write_text(completed.stderr)
    (out/f'command-{index}.json').write_text(json.dumps({
        'argv': [cli, *command], 'returncode': completed.returncode,
        'elapsed_seconds': time.monotonic()-began}))
    assert completed.returncode == 0, completed.stdout+completed.stderr
    print('command completed', index, flush=True)
