from pathlib import Path
import hashlib,json,zipfile
root=Path('/private/tmp/brick-search-v1')
out=Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/search-v1')
out.mkdir(parents=True,exist_ok=True)
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
manifest={'schema':'sandbox_evidence_archive_v1','files':{p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
with zipfile.ZipFile(out/'original-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(out/'original-evidence.zip') as z:
    assert set(z.namelist())==set(manifest['files'])
    for name,expected in manifest['files'].items():
        raw=z.read(name)
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256']
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Verified archive members',len(files))
