from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
from sludge_sandbox.search import read_search
from sludge_sandbox.experiments import read_experiment
from sludge_sandbox.run_service import read_run
from sludge_sandbox.job_supervisor import read_job
from audit_ledgers import audit

out = Path('/private/tmp/brick-search-v1')
directory = out/'native-search'
state = read_search(directory)
assert state == json.loads((out/'command-2.stdout').read_text())
assert state['status'] == 'completed' and len(state['generations']) == 2
assert state['attempts_used'] == 5
assert 0 < state['charged_wall_seconds'] <= 220
previous = None
records = []
experiment_wall = F()
for generation in state['generations']:
    index = generation['index']
    experiment_dir = directory/generation['experiment_artifact']
    experiment = read_experiment(experiment_dir)
    expected_count = (2, 3)[index]
    assert experiment['status'] == 'completed'
    assert len(experiment['attempts']) == len(experiment['candidates']) == expected_count
    experiment_wall += F(experiment['charged_wall_seconds'])
    if previous is not None:
        assert generation['parent_result_sha256'] == previous['result_sha256']
        assert generation['parent_values'] == previous['factor_values']
    metrics = {}
    for attempt in experiment['attempts']:
        jobdir = experiment_dir/attempt['job_artifact']
        job = read_job(jobdir)
        assert job['child_reaped'] and job['returncode'] == 0 and job['status'] == 'completed'
        result, manifest = read_run(jobdir/'run')
        assert result['status'] == 'completed' and len(result['integration']['steps']) == 2
        assert manifest['files']['result.json'] == attempt['result_sha256']
        snapshot = result['final_snapshot']
        span = max(snapshot['temperature_k'])-min(snapshot['temperature_k'])
        pressure = max(snapshot['pressure_pa'])
        row = next(row for row in generation['selection']['assessments']
                   if row['result_sha256'] == attempt['result_sha256'])
        assert row['objective_value'] == span and pressure <= 60000
        metrics[row['id']] = span
        n = len(records)
        ledger = out/f'ledger-input-{n}.json'
        ledger.write_text(json.dumps({'run': result['integration'], 'initial': result['integration']['states'][0]}))
        checked = audit(ledger, {})
        assert checked['accepted_steps'] == 2 and checked['all_saved_prefixes_pass']
        (out/f'ledger-audit-{n}.json').write_text(json.dumps(checked, indent=2))
        records.append({'generation': index, 'id': row['id'], 'span_k': span,
                        'pressure_pa': pressure, 'run_directory': str(jobdir/'run')})
    selected = generation['selection']['selected']
    assert F(metrics['parent'])-F(min(metrics.values())) > F(1e-8), 'observed gap must exceed declared retention threshold'
    assert selected['objective_value'] == min(metrics.values())
    previous = selected
assert len(records) == 5 and previous == state['best']
assert F(state['charged_wall_seconds']) >= sum((F(i['elapsed_seconds']) for i in state['invocations']), F()) >= experiment_wall
best_record = next(r for r in records if r['generation'] == state['best']['generation'] and r['id'] == state['best']['candidate_id'])
case = json.loads((Path(best_record['run_directory'])/'case.json').read_text())
case['refinement'] = 1
(out/'selected-refined-case.json').write_text(json.dumps(case, indent=2))
report = {'status': 'passed', 'generations': 2, 'native_attempts': len(records),
          'charged_wall_seconds': state['charged_wall_seconds'], 'cli_python_equal': True,
          'best': state['best'], 'records': records,
          'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'scope': 'Manufactured numerical search; no real material or full firing validation.'}
(out/'verified.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
