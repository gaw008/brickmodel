from pathlib import Path
import json
import subprocess
import sys
out = Path('/private/tmp/brick-search-v1')
result = subprocess.run([sys.executable, str(out/'refine.py')], timeout=60,
                        capture_output=True, text=True)
(out/'refined.stdout').write_text(result.stdout)
(out/'refined.stderr').write_text(result.stderr)
(out/'refined-command.json').write_text(json.dumps({'returncode': result.returncode, 'external_timeout_seconds': 60}))
assert result.returncode == 0, result.stdout+result.stderr
print('refined child completed')
