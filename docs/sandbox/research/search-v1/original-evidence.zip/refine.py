from pathlib import Path
import json
from sludge_sandbox.job_supervisor import supervise, SupervisionPolicy

out = Path('/private/tmp/brick-search-v1')
root = Path('/Users/wanggaoying/Desktop/brickmodel-github')
result = supervise('run', out/'selected-refined-case.json', out/'refined-job',
    SupervisionPolicy(40, 5), water_directory=root/'data/sandbox/water',
    evidence_directory=root/'data/sandbox')
(out/'refined-supervision.json').write_text(json.dumps(result, indent=2))
assert result['status'] == 'completed' and result['child_reaped'] and result['returncode'] == 0
print(json.dumps(result))
