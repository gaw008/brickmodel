# Parent-requested metadata follow-up

Production SHA-256 during this separate run: `b58d0a617116d5200b69f2bb778576421c029d6455a87a1ed04406609ecfd495`. The preserved source is `identity-fixed-source_inverse_pressure.py`; the original liquid-pressure/R identity fixes had already made the independent 17-test batch pass.

Actual `metadata-red.xml`/`metadata-red.log`: **5 failures**, no errors/skips. All are DID NOT RAISE failures when changing a single SourceWetPoint field on an otherwise actual source inverse:

- source_ids = ()
- qualification = source_certified_material_pressure
- fit_error = 0.0
- solid_volume_m3 = 1.0
- total_enthalpy_j = 1.0

These changes do not alter the propagated pressure arithmetic or the outer result's false source_certified/event_admitted flags. They do contradict the supplied record's claimed actual SourceWetPoint provenance and its explicitly unknown material/energy fields, so silently retaining them would weaken source traceability and allow stronger unsupported metadata inside the accepted graph.

Minimal correction: reproduce the original evaluate-time point-source union `tuple(sorted(set(storage.source_ids + fluid.source_ids)))`, preserving additional actual runtime fluid source IDs; enforce the current fixed SourceWetPoint qualification and None-valued total enthalpy, solid volume and fit error. No new EOS or broader material certification is needed. The parent accepted these fixes. Further review expansion stopped; the only pending execution is the final existing 22 probes against the repaired frozen bytes.
