# Initial reuse and adverse-check preparation

Baseline e0a7f4a. Read-only preparation; no EOS, provider construction, production change or test execution.

Existing arithmetic worth reusing:

- `rigid_storage._directed`, `_sum_upper`, `_product_upper` implement the actual directed operations used by the wet pressure-error estimate. Preserve the order: exact positive gas-compliance expression → downward binary64 slope bound; outward liquid-volume error product and volume-residual/resolution sum → outward division. Replacing the sequence with one final rounding may change original bounds.
- `mass_wet_storage.evaluate_wet_fluid` contains the global and local volume-error propagation and both original domain fences. It is not itself passive: it first calls fluid evaluation. There is no existing separate pure helper for its short final arithmetic block. A minimal extraction of only that block can allow reuse while preserving existing order and zero-volume-error behavior.
- `mass_storage_bridge.upper` and `mass_wet_storage.lower` provide existing directed conversion. Exact new continuation bounds can remain Fractions throughout, using directed conversion only if binary64 output is explicitly required.
- `SourceWetStorage.check/_check` bind actual storage and state to caloric/volume/fluid/source/water conventions. `source_net_prefix._same` provides exact typed dataclass/array comparisons. The previous endpoint comparison already binds the complete original DepletionPolicy and all original reported N/U/T/P gates.

Potential underreporting checks (risks to test once implementation exists, not established findings):

1. Saved `fluid.pressure_error_bound_pa` alone is insufficient: rederive original eps_p from the same saved mechanical residual/resolution, liquid amount, original envelope and exact gas total. Then rederive global/extra/local source pressure errors and domain fences.
2. If saved original residuals are audited, verify their association with the same N/R/T/V and recorded liquid volume. Simultaneously shrinking input residual/resolution and resulting eP must not silently pass a claimed original-formula audit. RigidWaterGas.finish contains their original binary64 arithmetic; exact arithmetic should not retroactively replace its represented result.
3. Bind source state solid/liquid/all gas inventories/U, inverse target/residual, point model identity, fluid envelope, mechanical source assets/R/domain/policy and source qualification. A matching model_identity string alone is insufficient.
4. Do not permit a saved eT smaller than the original inverse expression `upper((abs(residual)+point.energy_error_j)/point.minimum_heat_capacity_j_k)`. Preserve the actual caloric/temperature-domain lower-capacity relation if the interface claims to revalidate it.
5. New pressure propagation must retain global-domain proof before bootstrap, full temperature interval in all declared domains, stable branch/global response assumptions and separate conditional status. It must preserve original reported endpoint gates and grant no event/material permission.

Native reconstruction boundary: the parent's prospective make_case reconstruction invokes HEOS candidate construction and its DmassT reference-anchor validation. That work cannot be described as zero EOS. The saved endpoint calculation can remain passive after the explicitly recorded backend/anchor setup. No native reconstruction is part of this review preparation.
