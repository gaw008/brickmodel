# First independent run

Actual run: 17 tests; 4 failures, 13 passes; pytest log reports 0.56 s. Preserved `first.log`, `first.xml`, `first-state.json` and four production source snapshots. Source inverse-pressure SHA-256: `7cc846444bdb4314c0aafa324030cc112afb07d8f3fa964022f13f5c05bf1745`.

The fixture uses the existing explicitly manufactured constant-liquid seam. Native water solving is forbidden by that fixture. After generating one actual SourceWetStorage inverse, six source/storage/water evaluation methods are patched to fail. These probes do not reconstruct a native HEOS case or invoke new native properties.

[HIGH] Contradictory liquid pressure accepted as an actual planar wet source point

File: src/sludge_sandbox/source_inverse_pressure.py, enclose_source_inverse_pressure model/state binding.
Issue: changing only `inverse.point.fluid.mechanical.liquid_pressure_pa` to None, 1.0 or Fraction(1) is accepted, and the function still returns a conditional_pressure_enclosure. Positive liquid inventory and the supported planar/no-capillary assumption require a finite binary64 liquid pressure equal to the recorded gas pressure. The admitted record can currently contradict that fundamental closure identity.
Fix: require the recorded liquid pressure to be exact float, finite, positive and equal to the recorded pressure for this positive-liquid source entry. No new EOS is needed.
Evidence: three actual DID NOT RAISE failures in first.xml; all other fields are taken from the genuine manufactured-source inverse.

[MEDIUM] Equal Fraction substitutes for original binary64 gas constant

File: src/sludge_sandbox/source_inverse_pressure.py, source_pressure_model_binding.
Issue: replacing only mechanical.gas_constant_j_mol_k with an exactly equal Fraction passes equality and the actual-source entry. This changes the record's original represented type while strict typed binding is used for neighboring fields.
Fix: use the existing _same comparison against the actual template constant, and/or include the constant in strict binary64 validation.
Evidence: one actual DID NOT RAISE failure in first.xml.

The 13 passing tests cover a normal source endpoint with nonzero volume uncertainty; five individual original closure-diagnostic mutations; three single-ULP pressure-error reductions; original temperature/capacity/source-U checks; altered source assets; incorrect result/continuation qualifications and exact result types; and the extracted closure_diagnostics' original binary64 sequence. A parameterized test count is not a claim of independent EOS certification.
