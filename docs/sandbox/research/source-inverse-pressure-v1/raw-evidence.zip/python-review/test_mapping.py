"""Narrow regression for decoded dict versus actual immutable asset mapping."""
from dataclasses import replace
from types import MappingProxyType

import pytest

from test_independent import endpoint, with_mechanical
from sludge_sandbox.source_inverse_pressure import enclose_source_inverse_pressure
from sludge_sandbox.source_net_prefix import _same


@pytest.mark.parametrize('container', [dict, MappingProxyType])
def test_equal_asset_mapping_containers_are_accepted(endpoint, container):
    storage, state, inverse = endpoint
    original = storage.water.source_asset_sha256
    assert type(original) is MappingProxyType
    saved = container(dict(original))
    changed = with_mechanical(inverse, source_asset_sha256=saved)
    expected = enclose_source_inverse_pressure(storage, state, inverse)
    result = enclose_source_inverse_pressure(storage, state, changed)
    assert result.continuation == expected.continuation
    assert result.initial_bounds_pa == expected.initial_bounds_pa
    result.check()
    # The fix must be local; other typed-record comparisons stay strict.
    assert _same({}, MappingProxyType({})) is False


@pytest.mark.parametrize('change', ['missing', 'extra', 'changed', 'wrong_value_type', 'pairs'])
def test_asset_mapping_content_changes_are_rejected(endpoint, change):
    storage, state, inverse = endpoint
    data = dict(storage.water.source_asset_sha256)
    key = next(iter(data))
    if change == 'missing':
        del data[key]
    elif change == 'extra':
        data['foreign_asset'] = '0' * 64
    elif change == 'changed':
        data[key] = '0' * 64
    elif change == 'wrong_value_type':
        data[key] = data[key].encode()
    elif change == 'pairs':
        data = list(data.items())
    wrong = with_mechanical(inverse, source_asset_sha256=data)
    with pytest.raises(ValueError):
        enclose_source_inverse_pressure(storage, state, wrong)
