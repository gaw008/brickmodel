"""Independent input/identity probes with an explicit manufactured liquid seam."""
from dataclasses import replace
from fractions import Fraction as F
import math

import pytest

from test_source_wet_storage import setup
from sludge_sandbox.phase_storage import InversePolicy
from sludge_sandbox.source_wet_storage import SourceWetStorage
from sludge_sandbox.rigid_storage import RigidStorage
from sludge_sandbox.rigid_water_gas import RigidWaterGas, closure_diagnostics
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.source_inverse_pressure import enclose_source_inverse_pressure


@pytest.fixture(scope='module')
def endpoint():
    with pytest.MonkeyPatch.context() as patch:
        storage, state, calls = setup(patch)
        storage = replace(storage, volume=replace(storage.volume, error_m3=1e-12))
        state = storage.state(state.liquid_water_mol, state.gas_amounts_mol, 0.)
        point = storage.evaluate(state, 330.)
        state = replace(state, internal_energy_j=point.total_internal_energy_j)
        inverse = storage.invert(state, InversePolicy(1e-6, 1e-6, 100))
        count = len(calls)
        def forbidden(*args, **kwargs):
            raise AssertionError('review must not evaluate fluid or source physics')
        for owner, method in ((SourceWetStorage, 'evaluate'), (SourceWetStorage, 'invert'),
                              (RigidStorage, 'evaluate_at_temperature'),
                              (RigidWaterGas, 'evaluate_at_temperature'),
                              (WaterProperties, 'state_tp'), (WaterProperties, 'state_tp_response')):
            patch.setattr(owner, method, forbidden)
        yield storage, state, inverse
        assert len(calls) == count


def with_mechanical(inverse, **changes):
    fluid = inverse.point.fluid
    return replace(inverse, point=replace(inverse.point,
                   fluid=replace(fluid, mechanical=replace(fluid.mechanical, **changes))))


def test_actual_manufactured_endpoint_and_no_repeat_properties(endpoint):
    result = enclose_source_inverse_pressure(*endpoint)
    assert result.continuation.status == 'conditional_pressure_enclosure'
    assert result.continuation.radius_pa > F(endpoint[2].point.pressure_error_pa)
    assert result.initial_bounds_pa[2] > 0
    assert result.source_certified is result.event_admitted is False
    result.check()


@pytest.mark.parametrize('value', [None, 1., F(1)])
def test_wrong_recorded_liquid_pressure_rejected(endpoint, value):
    storage, state, inverse = endpoint
    wrong = with_mechanical(inverse, liquid_pressure_pa=value)
    with pytest.raises(ValueError):
        enclose_source_inverse_pressure(storage, state, wrong)


def test_equal_nonbinary64_R_rejected(endpoint):
    storage, state, inverse = endpoint
    wrong = with_mechanical(inverse, gas_constant_j_mol_k=F(inverse.point.fluid.mechanical.gas_constant_j_mol_k))
    with pytest.raises(ValueError):
        enclose_source_inverse_pressure(storage, state, wrong)


@pytest.mark.parametrize('field', ('gas_volume_m3', 'pressure_residual_pa', 'volume_residual_m3',
                                  'volume_resolution_m3', 'pressure_resolution_pa'))
def test_mechanical_diagnostic_change_rejected(endpoint, field):
    storage, state, inverse = endpoint
    original = getattr(inverse.point.fluid.mechanical, field)
    wrong = with_mechanical(inverse, **{field: math.nextafter(original, math.inf)})
    with pytest.raises(ValueError):
        enclose_source_inverse_pressure(storage, state, wrong)


@pytest.mark.parametrize('field', ('global_pressure_error_pa', 'extra_pressure_error_pa', 'pressure_error_pa'))
def test_single_ulp_pressure_underreport_rejected(endpoint, field):
    storage, state, inverse = endpoint
    value = math.nextafter(getattr(inverse.point, field), -math.inf)
    wrong = replace(inverse, point=replace(inverse.point, **{field: value}))
    with pytest.raises(ValueError):
        enclose_source_inverse_pressure(storage, state, wrong)


def test_original_T_lower_bound_and_cmin_rechecked(endpoint):
    storage, state, inverse = endpoint
    for wrong in (replace(inverse, temperature_error_bound_k=0.),
                  replace(inverse, point=replace(inverse.point,
                          minimum_heat_capacity_j_k=inverse.point.minimum_heat_capacity_j_k * 2)),
                  replace(inverse, point=replace(inverse.point,
                          solid_internal_energy_j=inverse.point.solid_internal_energy_j + 1))):
        with pytest.raises(ValueError):
            enclose_source_inverse_pressure(storage, state, wrong)


def test_native_asset_identity_rejected(endpoint):
    storage, state, inverse = endpoint
    original = dict(inverse.point.fluid.mechanical.source_asset_sha256)
    original[next(iter(original))] = '0' * 64
    with pytest.raises(ValueError):
        enclose_source_inverse_pressure(storage, state,
                                        with_mechanical(inverse, source_asset_sha256=original))


def test_source_result_flags_and_continuation_type_binding(endpoint):
    result = enclose_source_inverse_pressure(*endpoint)
    for wrong in (replace(result, source_certified=True), replace(result, event_admitted=True),
                  replace(result, initial_bounds_pa=tuple(float(x) for x in result.initial_bounds_pa)),
                  replace(result, continuation=replace(result.continuation, assumptions=())),
                  replace(result, continuation=replace(result.continuation, source_certified=True))):
        with pytest.raises(ValueError):
            wrong.check()


def test_shared_closure_diagnostics_preserve_original_binary64_sequence(endpoint):
    storage, state, inverse = endpoint
    mechanical = inverse.point.fluid.mechanical
    volume, vl, p, t = storage.volume.value_m3, mechanical.liquid_volume_m3, mechanical.pressure_pa, mechanical.temperature_k
    ng, r = math.fsum(state.gas_amounts_mol), mechanical.gas_constant_j_mol_k
    nrt = ng * r * t
    resolution = math.fsum((math.ulp(ng)*r*t, math.ulp(ng*r)*t, math.ulp(nrt)))
    vg = math.fsum((volume, -vl))
    ideal = nrt / vg
    rp = math.fsum((p, -ideal))
    rv = math.fsum((vl, nrt/p, -volume))
    vr = math.fsum((math.ulp(volume), math.ulp(vl), math.ulp(vg), math.ulp(nrt/p), resolution/p))
    pr = math.fsum((math.ulp(p), math.ulp(ideal), abs(ideal)*vr/vg))
    assert closure_diagnostics(volume, vl, p, nrt, resolution) == (vg, ideal, rp, rv, vr, pr)
