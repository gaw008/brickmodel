"""Parent-requested focused checks of unsupported source-point metadata changes."""
from dataclasses import replace

import pytest

from test_independent import endpoint
from sludge_sandbox.source_inverse_pressure import enclose_source_inverse_pressure


@pytest.mark.parametrize('field,value', [
    ('source_ids', ()),
    ('qualification', 'source_certified_material_pressure'),
    ('fit_error', 0.),
    ('solid_volume_m3', 1.),
    ('total_enthalpy_j', 1.),
])
def test_source_point_provenance_and_unknown_fields_not_upgraded(endpoint, field, value):
    storage, state, inverse = endpoint
    wrong = replace(inverse, point=replace(inverse.point, **{field: value}))
    with pytest.raises(ValueError):
        enclose_source_inverse_pressure(storage, state, wrong)
