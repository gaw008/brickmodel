"""Independent Decimal quadratic roots versus implemented conditional fences."""
from dataclasses import replace
from fractions import Fraction as F
from decimal import localcontext
from pathlib import Path
import hashlib,json,signal,time
from analytic_oracle import setup,positive_pressure,decimal
from sludge_sandbox.source_inverse_pressure import propagate_declared_pressure
OUT=Path(__file__).parent;SOURCE=Path('src/sludge_sandbox/source_inverse_pressure.py');sha=lambda:hashlib.sha256(SOURCE.read_bytes()).hexdigest();before=sha();count=0
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('independent10s')));signal.alarm(10)
def ck(ok,label):
 global count
 count+=1
 if not ok:raise AssertionError(label)
def call(s,**kwargs):
 return propagate_declared_pressure(s['nl'],s['ng'],s['R'],s['B'],s['T0'],s['et'],s['p0'],s['reported_error'],temperature_domain_k=(s['tlo'],s['thi']),pressure_domain_pa=(s['plo'],s['phi']),**kwargs)
begin=time.monotonic();records=[];roots=0
for sign in (1,-1,0):
 s=setup();s['a']*=sign
 s['B']=max(abs(-s['a']*T+s['b']*P) for T in (s['tlo'],s['thi']) for P in (s['plo'],s['phi']))
 s['p0']=F(float(positive_pressure(s['T0'],s['V'],s['v0'],s['a'],s['b'],s['nl'],s['ng'],s['R'])))
 residual=abs(s['nl']*(s['v0']+s['a']*s['T0']-s['b']*s['p0'])+s['ng']*s['R']*s['T0']/s['p0']-s['V'])
 slope=s['ng']*s['R']*s['T0']/s['phi']**2;nominal=(residual+s['nl']*s['vv'])/slope;globalE=nominal+s['ev']/slope
 s['reported_error']=nominal+s['ev']/(s['ng']*s['R']*s['T0']/(s['p0']+globalE)**2)
 out=call(s);out.check();ck(out.status=='conditional_pressure_enclosure' and out.source_certified is False,'conditional status')
 ck(out.radius_pa<=out.global_radius_pa and s['reported_error']>0 and s['et']>0,'nonzero error/bootstrap')
 ck(min(s['v0']+s['a']*T-s['b']*P for T in (s['tlo'],s['thi']) for P in (s['plo'],s['phi']))>0,'whole-box positive liquid volume')
 # Whole-box uP max is attained at a corner; all affine coefficients exact.
 ck(s['B']==max(abs(-s['a']*T+s['b']*P) for T in (s['tlo'],s['thi']) for P in (s['plo'],s['phi'])),'independent analytic uP maximum')
 with localcontext() as ctx:
  ctx.prec=100
  for j in range(41):
   T=s['T0']-s['et']+2*s['et']*F(j,40)
   for volume_sign in (-1,1):
    for response_sign in (-1,1):
     P=positive_pressure(T,s['V']+volume_sign*s['ev'],s['v0']+response_sign*s['vv'],s['a'],s['b'],s['nl'],s['ng'],s['R']);roots+=1
     ck(decimal(out.global_interval_pa[0])<=P<=decimal(out.global_interval_pa[1]),'quadratic root global enclosure')
     ck(decimal(out.interval_pa[0])<=P<=decimal(out.interval_pa[1]),'quadratic root bootstrap enclosure')
     if j==20:ck(decimal(s['p0']-s['reported_error'])<=P<=decimal(s['p0']+s['reported_error']),'initial perturbed-root existence fence')
 records.append({'thermal_expansion_sign':sign,'global_radius':str(out.global_radius_pa),'radius':str(out.radius_pa),'radius_float':float(out.radius_pa),'global_slope_float':float(out.global_slope_pa_k),'slope_float':float(out.slope_pa_k)})
 # Exact negative controls, no chosen tolerance margins.
 ck(call(dict(s,et=s['T0']-s['tlo']+1)).reason=='temperature_interval_outside_declared_domain','T domain rejection')
 ck(call(dict(s,reported_error=s['p0']-s['plo'])).reason=='temperature_continuation_pressure_domain_exit','initial fence plus temperature domain rejection')
 # Tangency of global lower fence to pressure domain must refuse nonzero eT.
 contact=s['p0']-out.global_radius_pa
 contactcase=call(dict(s,plo=contact));ck(contactcase.reason=='temperature_continuation_pressure_domain_exit','exact boundary contact rejected')
 for updates in ({'ng':F()},{'B':F(-1)},{'reported_error':F(-1)}):
  try:call(dict(s,**updates))
  except ValueError:ck(True,'invalid physical scalar refused')
  else:raise AssertionError('invalid physical scalar accepted')
 try:replace(out,radius_pa=F()).check()
 except ValueError:ck(True,'forged bootstrap refused')
 else:raise AssertionError('forged bootstrap accepted')
ck(before==sha(),'source stable during audit')
result={'status':'passed','checks':count,'quadratic_reference_roots':roots,'expansion_cases':3,'elapsed_s':time.monotonic()-begin,'source_sha256':before,'records':records,'scope':'Pure conditional continuation helper, independent affine stable-liquid Decimal quadratic roots; no EOS or source-host wrapper execution; no source certification'}
(OUT/'ANALYTIC_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));signal.alarm(0)
