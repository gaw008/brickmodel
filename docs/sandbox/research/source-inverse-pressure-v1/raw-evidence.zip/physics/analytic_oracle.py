"""Manufactured stable affine-liquid oracle, independent positive quadratic root.
No tested pressure helper imports. Preparation module; main execution waits.
"""
from decimal import Decimal,localcontext
from fractions import Fraction as F

def decimal(x):
    return Decimal(x.numerator)/Decimal(x.denominator)

def positive_pressure(T,V,v0,a,b,nl,ng,R):
    # Stable quadratic formula avoids subtractive cancellation when c>0.
    with localcontext() as ctx:
        ctx.prec=100
        A=decimal(nl*b);c=decimal(V-nl*(v0+a*T));rhs=decimal(ng*R*T)
        return 2*rhs/((c*c+4*A*rhs).sqrt()+c)

def setup():
    v0=F(1,100000);a=F(1,100000000);b=F(1,10**14)
    nl=F(1,4);ng=F(3,8);R=F(8);V=F(1,1000)
    T0=F(330);et=F(1,1000);ev=F(1,10**12);vv=F(1,10**16)
    tlo,thi=F(310),F(350);plo,phi=F(10**5),F(10**7)
    B=max(abs(-a*T+b*P) for T in (tlo,thi) for P in (plo,phi))
    assert min(v0+a*T-b*P for T in (tlo,thi) for P in (plo,phi))>0
    p0=F(float(positive_pressure(T0,V,v0,a,b,nl,ng,R)))
    residual=abs(nl*(v0+a*T0-b*p0)+ng*R*T0/p0-V)
    slope=ng*R*T0/phi**2
    nominal_error=(residual+nl*vv)/slope
    initial_global=nominal_error+ev/slope
    certified_upper=p0+initial_global
    reported_error=nominal_error+ev/(ng*R*T0/certified_upper**2)
    return dict(v0=v0,a=a,b=b,nl=nl,ng=ng,R=R,V=V,T0=T0,et=et,ev=ev,vv=vv,tlo=tlo,thi=thi,plo=plo,phi=phi,B=B,p0=p0,residual=residual,nominal_error=nominal_error,initial_global=initial_global,reported_error=reported_error)
