"""Independent stdlib-only saved conditional pressure audit, no EOS/imports."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,time
ROOT=Path('/private/tmp/brick-source-inverse-pressure-v1/root');OUT=Path(__file__).parent
paths=[ROOT/'saved-repaired-installed.json',ROOT/'saved-installed.json',Path('/private/tmp/brick-source-prefix-trial-v1/root/native-result.json'),Path('/private/tmp/brick-source-endpoint-comparison-v1/physics/ENDPOINTS.json'),ROOT/'analytic-scope-correspondence.json']
def decode(x):
 if isinstance(x,list):return [decode(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'numerator','denominator'}:return F(x['numerator'],x['denominator'])
  if set(x)=={'type','fields'}:return decode(x['fields'])
  if 'dtype' in x and 'values' in x:return decode(x['values'])
  return {k:decode(v) for k,v in x.items()}
 return x
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
count=0
def ck(x,label):
 global count
 count+=1
 if not x:raise AssertionError(label)
begin=time.monotonic();saved,failed,native,old,ast=[decode(json.loads(p.read_text())) for p in paths]
ck(sha(paths[2])=='7c0907af104450ffc42cf142e3e3aebefaf21c597eb6806f09b7bdbe6d6d3505','frozen native hash')
ck(sha(paths[3])=='711d7716bf247b693c4c92b6d0a65150e5abffc94a2b3f1d112d8f3c57d0f7ab','prior independent extract hash')
ck(saved['status']=='conditional_saved_inverse_pressure_completed' and failed['status']=='failed','actual terminal outcomes')
ck(saved['input_sha256']==failed['input_sha256']==sha(paths[2]),'same native original')
ck(saved['event_policy'] is None and saved['conditional_gate'] is None and saved['event_admitted'] is saved['material_qualified'] is saved['source_certified'] is False,'no undeclared policy/qualification')
ck(ast['status']=='identical_pure_function_AST' and ast['original_module_sha256']=='7cc846444bdb4314c0aafa324030cc112afb07d8f3fa964022f13f5c05bf1745','prior analytical correspondence')
source=Path('/Users/wanggaoying/Desktop/brickmodel-github/src/sludge_sandbox/source_inverse_pressure.py');ck(sha(source)==ast['final_module_sha256']=='5695976e4f655bca189c7eadd87e62a321c048349d1ddcbf79a74b12f2d52e36','current final source hash')
for r in (saved,failed):
 ck(r['backend_constructors_started']==r['backend_constructors_completed']==r['constructor_reference_anchor_checks']==2 and r['new_endpoint_evaluations_attempted']==0,'each real run constructor anchors/zero endpoints')
ck(saved['constructor_reference_anchor_checks']+failed['constructor_reference_anchor_checks']==4,'cumulative four anchors')
trial=native['trial'];captures=(trial['captures'][2],trial['captures'][-1]);bounds=[]
ck(len(saved['cells'])==3,'three cells')
for i,cell in enumerate(saved['cells']):
 ck(cell['cell']==i and len(cell['endpoint_bounds'])==2,'cell pair layout');radii=[];pressures=[]
 for j,(e,c) in enumerate(zip(cell['endpoint_bounds'],captures)):
  inv=c['evaluation']['source_evaluation']['cells'][i]['inverse'];point=inv['point'];mech=point['fluid']['mechanical'];env=point['fluid']['envelope'];row=c['state']['amounts_mol'][i]
  inputs=[F(row[0]),sum(map(F,row[1:]),F()),F(mech['gas_constant_j_mol_k']),F(env['liquid_abs_du_dp_bound_j_mol_pa']),F(mech['temperature_k']),F(inv['temperature_error_bound_k']),F(mech['pressure_pa']),F(point['pressure_error_pa'])]
  p=e['continuation'];ck(p['inputs']==inputs,'actual N/R/B/T/eT/P/eP');ck(e['storage_identity']==point['model_identity']==c['evaluation']['source_states'][i]['energy_model_identity'],'source storage identity')
  ck(p['temperature_domain_k']==list(map(F,env['temperature_range_k'])) and p['pressure_domain_pa']==list(map(F,mech['pressure_bracket_pa'])),'actual declared effective domains')
  nl,ng,R,B,T,eT,P,eP=inputs;tmin,tmax=p['temperature_domain_k'];pmin,pmax=p['pressure_domain_pa'];tb=[T-eT,T+eT]
  L=pmax/tmin*(1+nl*B*pmax/(ng*R*tmin));glob=eP+L*eT;gb=[P-glob,P+glob];L2=gb[1]/tb[0]*(1+nl*B*gb[1]/(ng*R*tb[0]));rad=eP+L2*eT;pb=[P-rad,P+rad]
  ck(p['temperature_interval_k']==tb and tmin<=tb[0]<=tb[1]<=tmax,'T interval')
  ck(p['global_slope_pa_k']==L and p['global_radius_pa']==glob and p['global_interval_pa']==gb,'global proof arithmetic')
  ck(pmin<gb[0]<=gb[1]<pmax,'strict global mechanical domain')
  ck(p['slope_pa_k']==L2 and p['radius_pa']==rad and p['interval_pa']==pb and gb[0]<=pb[0]<=pb[1]<=gb[1],'bootstrap proof arithmetic')
  prior=old['rows'][i]['endpoints'][j];ck(rad==prior['bootstrapped_conditional_radius'] and glob==prior['global_conditional_radius'],'previous independent derivation')
  ck(p['status']=='conditional_pressure_enclosure' and p['reason'] is None and p['source_certified'] is False and e['source_certified'] is e['event_admitted'] is False,'endpoint conditional qualification')
  ck(p['assumptions']==['smooth_stable_planar_liquid_branch_on_entire_declared_box','declared_domain_wide_liquid_volume_and_uP_error_bounds','saved_closure_residual_and_representation_error_contract','declared_caloric_error_and_saved_energy_roundoff_contract'],'explicit hypotheses')
  initial=e['initial_bounds_pa'];ck(len(initial)==4 and initial[0]<=F(point['fluid']['pressure_error_bound_pa']) and initial[1]<=F(point['global_pressure_error_pa']) and initial[2]<=F(point['extra_pressure_error_pa']) and initial[3]<=eP,'recorded initial bounds conservative')
  radii.append(rad);pressures.append(P)
 pair=abs(pressures[0]-pressures[1])+sum(radii,F());ck(pair==cell['conditional_bound_pa']==old['rows'][i]['conditional_full_P_difference_upper'],'exact pair bound independent match');ck(cell['conditional_bound_pa_display']==float(pair),'display');bounds.append(float(pair))
result={'status':'passed','checks':count,'elapsed_s':time.monotonic()-begin,'endpoint_count':6,'cell_bounds_pa_display':bounds,'original_failed_status':failed['status'],'original_failed_reason':failed['reason'],'saved_success_status':saved['status'],'constructor_anchor_checks_total':4,'new_endpoint_evaluations_total':0,'scope':'Saved arithmetic/provenance counts only; no assertion of every internal native backend operation; no new EOS; no event policy/source certification','input_hashes':{str(p):sha(p) for p in paths},'source_sha256':sha(source)}
(OUT/'SAVED_AUDIT_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
