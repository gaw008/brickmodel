"""Compare helpers with their exact pre-extraction HEAD statements; no EOS."""
import ast
from copy import deepcopy
from fractions import Fraction as F
import hashlib
from pathlib import Path
import struct
import subprocess
from types import SimpleNamespace as NS
import pytest

import sludge_sandbox.rigid_water_gas as closure
import sludge_sandbox.rigid_storage as storage
import sludge_sandbox.mass_wet_storage as wet

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
OUT=Path('/private/tmp/brick-source-inverse-pressure-v1/code-review')


def original(name):
    raw=subprocess.run(['git','show','HEAD:src/sludge_sandbox/'+name+'.py'],cwd=ROOT,
        check=True,capture_output=True).stdout
    (OUT/(name+'.HEAD.py')).write_bytes(raw)
    return ast.parse(raw)


def extracted(args,body,module):
    function=ast.parse('def previous('+args+'):\n pass\n').body[0]
    function.body=deepcopy(body)
    compiled=ast.fix_missing_locations(ast.Module(body=[function],type_ignores=[]))
    namespace=dict(vars(module));exec(compile(compiled,'<HEAD original arithmetic>','exec'),namespace)
    return namespace['previous']


def expression(text):
    return ast.parse(text).body


def setup_module():
    global old_closure,old_liquid,old_volume
    tree=original('rigid_water_gas')
    finish=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='finish')
    assert len(finish.body)>=6 and all(isinstance(n,ast.Assign) for n in finish.body[:6])
    old_closure=extracted('volume,vl,p,nrt,nrt_resolution',
        finish.body[:6]+expression('return vg,ideal_p,residual_p,residual_v,vr,pr'),closure)
    tree=original('rigid_storage')
    branch=next(n for n in ast.walk(tree) if isinstance(n,ast.If)
        and any(isinstance(q,ast.Name) and q.id=='eps_f' for q in ast.walk(ast.Module(body=n.body,type_ignores=[]))))
    assert any(isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='bmin' for t in n.targets) for n in branch.body)
    old_liquid=extracted('state,self,r,nl,t',expression('p_hi=self.envelope.pressure_range_pa[1]')+
        branch.body+expression('return eps_p'),storage)
    tree=original('mass_wet_storage')
    function=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='evaluate_wet_fluid')
    start=next(i for i,n in enumerate(function.body) if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='p' for t in n.targets))
    old_volume=extracted('fluid,out,gas_amounts,t,available_error_m3',
        function.body[start:-1]+expression('return global_error,extra,pressure_error'),wet)


def captured(fn,*args):
    try:
        value=fn(*args)
        def exact(v):
            if type(v) is float:return ('binary64',struct.pack('!d',v).hex())
            if type(v) is F:return ('Fraction',v.numerator,v.denominator)
            if type(v) is tuple:return tuple(map(exact,v))
            raise AssertionError(type(v))
        return ('returned',exact(value))
    except Exception as exc:
        return ('raised',type(exc).__module__,type(exc).__name__,str(exc))


@pytest.mark.parametrize('args',[
    (.001,.0005,1e6,500.,1e-10),
    (.001,0.,1e6,1000.,1e-10),
    (1.,float.fromhex('0x1.fffffffffffffp-1'),9e9,1e-6,1e-20),
    (.5,.6,1e6,500.,1e-10),
    (1e-300,0.,1e6,1e308,1e-10),
])
def test_closure_original_bitwise_and_failure_results(args):
    assert captured(closure.closure_diagnostics,*args)==captured(old_closure,*args)


@pytest.mark.parametrize('gas,nl,residual,resolution,verror',[
    ((.125,.25,.00390625),.25,1e-18,1e-17,1e-16),
    ((.125,.25,.00390625),.25,0.,0.,0.),
    ((1e-320,0.,0.),.25,1e-18,1e-17,1e-16),
    ((.125,.25,.00390625),1e308,1e-18,1e-17,1e308),
])
def test_liquid_pressure_original_directed_rounding_and_failures(gas,nl,residual,resolution,verror):
    point=NS(gas_inventory_mol=dict(zip(('O2','N2','H2O'),gas)),temperature_k=331.25,
        liquid_inventory_mol=nl,volume_residual_m3=residual,volume_resolution_m3=resolution)
    env=NS(pressure_range_pa=(1e5,1e7),liquid_v_error_m3_mol=verror)
    assert captured(storage.liquid_pressure_error_bound,point,env,8.31446261815324)==captured(
        old_liquid,point,NS(envelope=env),8.31446261815324,nl,point.temperature_k)


@pytest.mark.parametrize('p,error,gas,volume_error',[
    (1e6,1e-4,(.125,.25,.00390625),F(1,10**12)),
    (1e6,1e-4,(.125,.25,.00390625),F()),
    (1e5,1e-4,(.125,.25,.00390625),F()),
    (1e6,1e-4,(.125,.25,.00390625),F(1)),
    (1e6,1e-4,(0.,0.,0.),F(1,10**12)),
])
def test_volume_global_then_local_rounding_and_failures(p,error,gas,volume_error):
    fluid=NS(mechanical=NS(gas_constant_j_mol_k=8.31446261815324,pressure_bracket_pa=(1e5,1e7)),
        envelope=NS(pressure_range_pa=(1e5,1e7)))
    point=NS(mechanical=NS(pressure_pa=p),pressure_error_bound_pa=error)
    args=(fluid,point,gas,331.25,volume_error)
    assert captured(wet.wet_fluid_pressure_bounds,*args)==captured(old_volume,*args)
