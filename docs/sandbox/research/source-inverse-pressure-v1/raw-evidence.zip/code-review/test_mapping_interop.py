"""Saved/live mapping container interoperability, with no native EOS calls."""
from dataclasses import replace
from types import MappingProxyType
import pytest
from test_source_wet_storage import setup
from sludge_sandbox.phase_storage import InversePolicy
from sludge_sandbox.source_inverse_pressure import enclose_source_inverse_pressure


@pytest.fixture(scope='module')
def endpoint():
    with pytest.MonkeyPatch.context() as monkeypatch:
        storage,state,_=setup(monkeypatch)
        point=storage.evaluate(state,330.)
        state=replace(state,internal_energy_j=point.total_internal_energy_j)
        inverse=storage.invert(state,InversePolicy(1e-6,1e-6,100))
        yield storage,state,inverse


def with_assets(inverse,assets):
    return replace(inverse,point=replace(inverse.point,fluid=replace(inverse.point.fluid,
        mechanical=replace(inverse.point.fluid.mechanical,source_asset_sha256=assets))))


@pytest.mark.parametrize('container',[dict,MappingProxyType])
def test_equivalent_saved_mapping_wrappers_preserve_bound(endpoint,container):
    storage,state,inverse=endpoint
    original=enclose_source_inverse_pressure(storage,state,inverse)
    altered=with_assets(inverse,container(dict(inverse.point.fluid.mechanical.source_asset_sha256)))
    result=enclose_source_inverse_pressure(storage,state,altered)
    assert result.continuation==original.continuation
    assert result.initial_bounds_pa==original.initial_bounds_pa
    result.check()


@pytest.mark.parametrize('change',['value','missing','extra','value_type','key_type','not_mapping'])
def test_mapping_normalization_does_not_weaken_exact_source_contents(endpoint,change):
    storage,state,inverse=endpoint
    assets=dict(inverse.point.fluid.mechanical.source_asset_sha256)
    key=next(iter(assets))
    class StringAlias(str):
        pass
    if change=='value':assets[key]='0'*64
    elif change=='missing':assets.pop(key)
    elif change=='extra':assets['unexpected-asset']='f'*64
    elif change=='value_type':assets[key]=StringAlias(assets[key])
    elif change=='key_type':assets[StringAlias(key)]=assets.pop(key)
    else:assets=list(assets.items())
    with pytest.raises(ValueError,match='model_binding'):
        enclose_source_inverse_pressure(storage,state,with_assets(inverse,assets))
