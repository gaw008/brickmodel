"""Independent saved-data arithmetic and identity audit; standard library only."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
H=Path(__file__).parent;A=H/'attempt01'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def frac(v):return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)
def pack(v):return {'numerator':v.numerator,'denominator':v.denominator}
def files(p):
 out={}
 for f in p.rglob('*'):
  assert not f.is_symlink()
  if f.is_file():out[f.relative_to(p).as_posix()]=sha(f)
 return out
freeze=read(H/'freeze.json');report=read(A/'report.json');runtime=read(A/'runtime-before.json');c=read(H/'inputs/case.json')
assert sha(H/'freeze.json')==report['freeze_sha256']=='2e4fdadc8367dbb7e490379896248761dbac9742f16c0de5166ac35b31f74674'
assert runtime==read(A/'runtime-after.json')==freeze['runtime'] and len(runtime['modules'])==89
assert files(H/'inputs')==read(A/'inputs-before.json')==read(A/'inputs-after.json')==freeze['files']
for n,d in freeze['scripts'].items():assert sha(H/n)==d
assert {p.name:sha(p) for p in (H/'inputs/implementation').glob('*.py')}==runtime['modules']
assert read(A/'attempted-point.json')==c
old=read(H.parent/'brick-mass-wet-native-v1/inputs/case.json');expected=dict(old,pressure_domain_pa=[1e4,1e7]);assert c==expected
st=read(A/'storage-inputs.json');water=read(A/'water-provider.json');vapor=read(A/'vapor-provider.json');pt=read(A/'forward.json');inv=read(A/'inverse.json');state=read(A/'inverse-input.json');proto=read(A/'initial-prototype.json')
assert vapor['_water']==water==st['fluid_template']['mechanical']['water']
assert st['fluid_template']['gas_phases']['H2O']['caloric']==vapor
assert st['water_element_convention']['facts_json'].encode()==(H/'inputs/water-element-convention/facts.json').read_bytes()
assert st['water_element_convention']['facts_sha256']==sha(H/'inputs/water-element-convention/facts.json')
assert state==dict(proto,internal_energy_j=pt['total_internal_energy_j'])
assert state['solid_mass_kg']==c['solid_mass_kg'] and state['liquid_water_mol']==c['liquid_water_mol'] and state['gas_amounts_mol']==c['gas_amounts_mol']
assert proto['internal_energy_j']==0 and proto['energy_model_identity']==st['_identity']==pt['model_identity']==inv['point']['model_identity']==report['model_identity']
assert st['temperature_domain_k']==c['temperature_domain_k'] and st['fluid_template']['mechanical']['pressure_bracket_pa']==c['pressure_domain_pa']
assert st['fluid_template']['mechanical']['policy']==dict(c['pressure_policy'],strategy=None)
for k in ('liquid_u_error_j_mol','liquid_v_error_m3_mol','liquid_abs_du_dp_bound_j_mol_pa'):assert st['fluid_template']['envelope'][k]==c['envelope'][k]
for k in ('gas_u_error_j_mol','gas_cv_lower_j_mol_k'):assert set(st['fluid_template']['envelope'][k].values())=={c['envelope'][k]}
liquid=read(A/'oracle-liquid.json');ideal=read(A/'oracle-ideal-water.json');metrics=read(A/'comparison-before-gates.json');samples=read(A/'brent-liquid-samples.json')
assert liquid['reference']==ideal['reference']==vapor['reference'] and liquid['implementation']==ideal['implementation']
ref=liquid['reference'];M=F(ref['molar_mass_kg_mol']);R=F(vapor['gas_constant_j_mol_k']);T=F(c['temperature_k']);nl=F(c['liquid_water_mol']);ng=sum(map(F,c['gas_amounts_mol']),F());vs=sum((F(m)*F(v) for m,v in zip(c['solid_mass_kg'],c['solid_volume_m3_kg'])),F());available=F(c['bulk_volume_m3'])-vs
assert len(samples)==metrics['brent_calls']==14
residuals=[]
for row in samples:
 w=row['liquid'];p=F(row['pressure_pa'])
 assert row['status']=='completed' and w['temperature_k']==float(T) and w['pressure_pa']==float(p) and w['phase']=='liquid'
 assert w['reference']==ref and w['implementation']==liquid['implementation']
 assert c['pressure_domain_pa'][0]<=p<=c['pressure_domain_pa'][1]
 res=nl*M/F(w['density_kg_m3'])+ng*R*T/p-available
 assert res==frac(row['residual_m3']);residuals.append(res)
assert samples[0]['pressure_pa']==c['pressure_domain_pa'][0] and samples[1]['pressure_pa']==c['pressure_domain_pa'][1] and residuals[0]>0>residuals[1]
p=F(liquid['pressure_pa']);assert float(p)==metrics['oracle_pressure_pa'] and any(row['liquid']==liquid for row in samples)
assert liquid['temperature_k']==ideal['temperature_k']==float(T)
# Reconstruct public molar values from raw native per-kg data and common offset.
# Preserve the public binary64 multiplication/addition before exact inventory sums.
u_l=F(liquid['native_internal_energy_j_kg']*ref['molar_mass_kg_mol']+ref['energy_offset_j_mol'])
h_v=F(ideal['native_enthalpy_j_kg']*ref['molar_mass_kg_mol']+ref['energy_offset_j_mol'])
solid=F(c['solid_mass_kg'][0])*(F(c['solid_cp_j_kg_k'][0])*(T-F(c['reference_temperature_k']))-F(c['reference_pressure_pa'])*F(c['solid_volume_m3_kg'][0]))
assert c['solid_mass_kg'][1]==0
u=solid+nl*u_l+sum((F(n)*(F(cp)-R)*T for n,cp in zip(c['gas_amounts_mol'][:2],c['dry_gas_cp_j_mol_k'])),F())+F(c['gas_amounts_mol'][2])*(h_v-R*T)
v=ng*R*T/p
computed={'oracle_total_u_j':u,'oracle_gas_volume_m3':v,'energy_difference_j':abs(F(pt['total_internal_energy_j'])-u),
 'pressure_difference_pa':abs(F(pt['fluid']['mechanical']['pressure_pa'])-p),'gas_volume_difference_m3':abs(F(pt['fluid']['mechanical']['gas_volume_m3'])-v),
 'enthalpy_identity_residual_j':abs(F(pt['total_enthalpy_j'])-F(pt['total_internal_energy_j'])-F(pt['fluid']['mechanical']['pressure_pa'])*F(c['bulk_volume_m3'])),
 'inverse_energy_residual_plus_bound_j':abs(F(inv['point']['total_internal_energy_j'])-F(state['internal_energy_j']))+F(inv['point']['energy_error_j'])}
for k,value in computed.items():assert value==frac(metrics[k])==frac(report['metrics'][k])
e=F(c['inverse_policy']['energy_tolerance_j']);dt=abs(F(inv['point']['fluid']['mechanical']['temperature_k'])-T)
assert inv['target_energy_j']==state['internal_energy_j'] and inv['iterations']<=c['inverse_policy']['maximum_iterations']
assert computed['energy_difference_j']<=e and computed['enthalpy_identity_residual_j']<=e and computed['inverse_energy_residual_plus_bound_j']<=e
assert computed['pressure_difference_pa']<=F(pt['pressure_error_pa'])
assert computed['gas_volume_difference_m3']<=F(c['pressure_policy']['volume_tolerance_m3'])
assert dt==F(metrics['inverse_temperature_difference_k']) and dt<=F(c['inverse_policy']['temperature_tolerance_k']) and F(inv['temperature_error_bound_k'])<=F(c['inverse_policy']['temperature_tolerance_k'])
assert inv['final_temperature_bracket_k'][0]<=float(T)<=inv['final_temperature_bracket_k'][1]
s=read(H/'supervised-attempt01/status.json');assert s['status']=='complete' and s['returncode']==0 and s['cleanup']['leader_reaped'] and s['inputs_unchanged']
output={'status':'passed_saved_data_audit','recorded_input_hashes':{n:sha(A/n) for n in ('forward.json','inverse.json','oracle-liquid.json','oracle-ideal-water.json','brent-liquid-samples.json','storage-inputs.json')},'freeze_sha256':sha(H/'freeze.json'),'runtime_modules':89,'brent_samples_recomputed':len(samples),'metrics_exact':{k:pack(v) for k,v in computed.items()},'metrics_float':{k:float(v) for k,v in computed.items()},'forward_pressure_pa':pt['fluid']['mechanical']['pressure_pa'],'oracle_pressure_pa':float(p),'inverse_temperature_error_k':float(dt),'runner_elapsed_s':report['elapsed_s'],'supervisor_elapsed_s':s['elapsed_s'],'scope':'Independent saved arithmetic/association and original gate checks; no EOS recomputation, no trajectory/material or envelope-certification claim.'}
(H/'independent-result-audit.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
