# Independent actual wet point result review

APPROVE the bounded v2 saved result after independent standard-library arithmetic checks. audit_saved.py reads only saved JSON and source bytes; it imports no model and performs no EOS or integration. Its output is independent-result-audit.json, with exact Fraction metrics and raw input hashes, and independent-audit.log. Initial audit assumed the serialized PressurePolicy omitted the optional field; actual full dataclass capture retains strategy:null. The original failed script/log are preserved as *before-policy-normalization*. The final comparison requires precisely the unchanged case fields plus strategy=None; no numeric gate was changed.

Verified freeze 2e4fdadc8367dbb7e490379896248761dbac9742f16c0de5166ac35b31f74674, complete copied input membership/hashes, all 89 implementation module bytes against recorded runtime, runtime before/after, script hashes, original attempted point and the single v1→v2 case change (pressure lower bound 1000→10000 Pa). Source water provider descriptions are identical in the vapor bridge and storage liquid provider; saved oracle liquid/ideal-water and all 14 Brent liquid samples share reference and implementation. Original state arrays, model identities and forward-to-inverse target energy are bound. Convention facts and declared numerical envelope magnitudes remain unchanged.

Independently reconstructed every saved Brent sample residual from density, actual provider molar mass, exact represented amounts/RT and kg-solid available volume. Initial bracket endpoints have opposite residual signs; selected oracle pressure corresponds to a saved liquid sample. Reconstructed molar liquid U and ideal-water H from raw native per-kg values plus the common offset, preserving the public binary64 conversion before Fraction inventory sums. Recomputed solid A's reference/p_ref*v term and explicit O2/N2 Cv terms; no candidate storage, inverse or pressure function was called.

All original comparison gates pass:

| Check | Independently recomputed value | Original bound |
|---|---:|---:|
| Total-U difference | 2.3475723828158155e-11 J | 1e-5 J |
| Pressure difference | 1.4191027730703354e-6 Pa | returned 1.3923056048137315e-4 Pa |
| Gas-volume difference | 1.330492587155527e-19 m3 | 1e-12 m3 |
| H-U-pV residual | 1.4301650782147056e-9 J | 1e-5 J |
| Inverse residual plus energy error | 5.963078514729823e-6 J | 1e-5 J |
| Recovered temperature difference | 2.980232238769531e-7 K | 1e-4 K |

The returned inverse temperature error bound also passes 1e-4 K, and its saved bracket contains the original 300 K. Forward pressure is 1010702.1444709471 Pa; 1010702.144469528 Pa is the independent Brent pressure, not the same binary64 value. This distinction is retained in the audit JSON.

Actual supervisor status complete, returncode 0, leader_reaped true, inputs_unchanged true. Authoritative supervisor elapsed is 4.3019047919951845 s; runner elapsed is 4.08027583398507 s, which includes preparation of providers, forward/inverse, saved-data output and oracle work inside the child, not a separately measured solver-only timing. Original process-group containment limits remain.

This establishes one actual liquid-water point under the declared manufactured-solid and numerical-envelope contract. The audit does not independently recompute EOS values, certify the envelope over its domain, demonstrate phase-transfer evolution or qualify a real sludge material. V1 remains the preserved domain-failed experiment; its result has not been rewritten or included as a pass.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE the bounded actual v2 point evidence and original saved-data gates.
