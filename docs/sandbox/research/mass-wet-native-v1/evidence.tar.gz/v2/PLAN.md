# First actual wet mass-storage check

Prerequisite: final frozen source and independent approval, source/installed pure tests, installed implementation identity. No EOS execution before that gate. Do not replace actual water with test closures.

One isolated process under the existing research supervisor, outer wall90s and cleanup0.1s. One forward/inverse point T300 K; bulk0.001 m3, A0.01/B0 kg, liquid0.02 mol, gas O2/N2/H2O=(0.2,0.2,0.001) mol. Manufactured solid coefficients/chemical reference are the existing mass-storage fixture, with water coefficient zero and actual source vapor anchor. Temperature295..310 K; pressure1e4..1e7 Pa. Actual HEOS liquid and IdealWaterVapor must share type/implementation/reference/assets. Use the already approved source tree /private/tmp/brick-free-native-events-v1/attempt01/water.

Copy original rigid-storage numerical envelope values (liquid U1e-8 J/mol, v1e-16 m3/mol, |du/dp|1e-4 J/mol/Pa; gas U1e-9 and Cv lower20). These are declared manufactured numerical bounds, not an EOS or material accuracy certificate. Existing inverse tolerances1e-5 J and1e-4 K, max100; never loosen after result. Independent Brent pressure closure from actual liquid density plus ideal gas volume; independent total-U sum, H-U=pV and actual gas volume compared. Full report must preserve original failure and attempted point even if no inverse succeeds. No adaptive, phase-transfer evolution, depletion or full-model claim from this point test.

Freeze all runner/source/case/facts/water asset bytes before execution and recheck after; report actual process return/reap/time. No repeats unless a diagnosed code/runner change has its own preserved failed attempt and approval. Exclude external full-source assets from distributable archives, retain source identity.

Revision: v1 attempt01 rejected unstable liquid at1000Pa. Only lower pressure bracket narrows to10000Pa, retaining original upper bound, actual inputs, all tolerances and wall budget. v1 remains unchanged. See CASE_CHANGE.json and independent failure review.
