"""One explicitly launched wet point attempt; never prepares, retries or installs."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
SOURCE=Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/research-process-supervisor/supervisor.py')
EXPECTED='939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1'
PYTHON='/private/tmp/brick-water-backend-probe/venv/bin/python'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--freeze-sha256',required=True);p.add_argument('--attempt',required=True);a=p.parse_args()
    if not a.attempt or Path(a.attempt).name!=a.attempt or a.attempt in ('.','..'):raise ValueError('simple_new_attempt_name')
    if sha(SOURCE)!=EXPECTED:raise ValueError('reviewed_supervisor_changed')
    if sha(HERE/'freeze.json')!=a.freeze_sha256:raise ValueError('authoritative_freeze_changed')
    frozen=json.loads((HERE/'freeze.json').read_bytes())
    if frozen.get('status')!='FROZEN' or frozen['timeout_s']!=90. or frozen['cleanup_grace_s']!=.1:raise ValueError('original_supervision_policy_required')
    for n,d in frozen['scripts'].items():
        if sha(HERE/n)!=d:raise ValueError('reviewed_runner_changed')
    spec=importlib.util.spec_from_file_location('reviewed_wet_point_supervisor',SOURCE);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    inputs=[SOURCE,HERE/'freeze.json']+[HERE/n for n in frozen['scripts']]+[HERE/'inputs'/n for n in frozen['files']]
    result=m.run_attempt(HERE/('supervised-'+a.attempt),[PYTHON,str(HERE/'run.py'),'run','--freeze-sha256',a.freeze_sha256,'--attempt',a.attempt],cwd='/private/tmp',input_paths=inputs,timeout_s=90.,cleanup_grace_s=.1)
    print(json.dumps(result,indent=2))
    if result['returncode']!=0:raise SystemExit(1)
