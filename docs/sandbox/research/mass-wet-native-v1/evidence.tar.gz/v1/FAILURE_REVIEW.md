# Independent failed point and proposed domain revision review

Actual attempt01 is FAILED, not a passed storage test. Saved report records RigidClosureDomainError wrapping WaterDomainError unstable_requested_phase. The first forward evaluation reached rigid_water_gas's lower pressure-bracket trial; the native HEOS guard rejects liquid at p below saturation. This is a correct domain refusal caused by the registered dry-style 1000 Pa lower bound, not evidence that wet storage energy or inverse tolerances were exceeded.

Independently checked saved freeze ade7f9f0c79f65af0724c4cbf35b8c336a376672ff4b75d4b1ca69a9cc54b97c, all copied input membership/hashes, 89-module runtime before/after and attempted-point equality to frozen case. Original state prototype and full storage/source input are preserved. No forward.json or inverse.json exists: the prototype U=0 is only the forward construction placeholder, not an evaluated physical initial energy or a successfully recovered temperature. Do not report an inverse attempt or passed energy gate. Runner elapsed was 1.0111640830000397 s; authoritative supervisor elapsed was 1.205164374987362 s, status failed, returncode 1, leader_reaped true. Existing process-group containment qualification remains.

The proposed NEW v2 pressure domain [10000,10000000] Pa is an appropriate restriction for the unchanged 295–310 K point test. Production test_rigid_storage.py:30–33 already pairs a 10000 Pa lower bound with this temperature interval. Current _heos_kernel.py:289–294 explicitly refuses unstable requested phases rather than admitting a metastable branch. Supporting primary data: NIST's Antoine fits give approximately 3533.53 Pa at 300 K and 6225.41 Pa at 310 K, comfortably below 10000 Pa. These calculations support domain selection; they do not replace native HEOS or supply a new error certificate. [NIST water phase-change data](https://webbook.nist.gov/cgi/cbook.cgi?ID=C7732185&Mask=4#Thermo-Phase).

Independent ideal-gas volume arithmetic gives NgRT/Vavailable approximately 993494.3 Pa already at 295 K; positive liquid occupation requires still higher pressure. Thus raising the lower bracket to 10000 Pa does not discard the nominal physical root for the stated inventories and volume. This is a domain restriction, not a relaxation of pressure/energy/temperature tolerances. It does change the domain declaration and corresponding source identity, which must be recorded honestly in the new freeze; do not claim v1 and v2 identities are equal.

APPROVE preparing and reviewing a separate v2 experiment with ONLY case pressure_domain_pa[0] changed from 1000 to 10000, applied consistently to mechanical closure, declared envelope and independent Brent bracket. Keep T, kg/mol inventories, solid/reference coefficients, nominal volumes, every uncertainty envelope magnitude, inverse/pressure tolerance, iteration budget and 90-second supervision unchanged. Keep v1 raw files/freeze/runner and this failure intact. No production guard bypass, EOS replacement or automatic retry is authorized by this review. No EOS or runner execution, repository edit, or v1 runner modification was performed here. Actual v2 files still need hash/diff verification before execution.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: v1 remains FAILED; APPROVE the specified narrower-domain v2 design as a separate bounded experiment, without any pass prediction.

## Concrete v2 delta verified

Read actual v2 run.py SHA256 815710741ea8ce20e958c74377ba61dfb28d783fd3441d4db8b608563253a375: the complete source diff is exactly the single CASE pressure-domain lower-bound change above. Supervise.py SHA9362a6f192b7b09f5a87999df8a428aaf2c9fe72b8811d40466915d251dde289 and test_runner.py SHA cb6780454f061cca4f3ad9610958bb399854c0176044c6209409fd323e330710 are identical to v1. Read revised PLAN and CASE_CHANGE.json: they preserve the failed original freeze reference and state the same narrow correction. APPROVE this concrete v2 runner for root's single separately frozen execution after normal identity preparation. No repeated tests or EOS were run by this reviewer.
