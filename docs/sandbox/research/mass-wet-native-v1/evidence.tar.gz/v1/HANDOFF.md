# Runner ready for independent review; not executed

Files owned here: run.py, supervise.py, test_runner.py, RUNNER_FILES.json and this handoff. Existing root PLAN.md remains unchanged. No freeze.json or inputs were created; prepare/run were not invoked, no package installation or EOS occurred. Only stdlib utility tests executed: 3 passed in 0.003s (runner-utility-tests.log), plus AST parse of all scripts.

After candidate independent approval/application and root installation, use the approved venv with PYTHONPATH unset:

```
python run.py prepare --module-sha256 <final reviewed mass_wet_storage.py SHA>
python supervise.py --attempt attempt01 --freeze-sha256 <actual freeze.json SHA>
```

The interpreter for supervision is fixed to /private/tmp/brick-water-backend-probe/venv/bin/python; root should use it for prepare too. Prepare imports the installed candidate only and compares every installed module byte against repository and runtime. It records the actual module count (expected next version 89, no invented count). No temporary candidate overlay or historical execution compatibility exists. It copies all 16 original water assets, all convention files, tracked gas facts and installed implementation files, then freezes membership, original and copied source hashes, case, runtime, scripts and existing supervisor. Verification runs before and after the sole actual point experiment. Do not distribute the copied external full-source assets.

Case values are explicit in CASE and become inputs/case.json; they match PLAN and the old dry fixture's manufacturing coefficients. Pressure policy remains the original dry fixture 1e-12 m3 / 1e-5 Pa / 100; inverse remains PLAN 1e-5 J / 1e-4 K / 100. Native HEOS and actual IdealWaterVapor use the same copied approved backend manifest. Full source-bound storage/reference and original attempted state are saved before forward evaluation; forward saved before inverse; inverse saved before comparison gates. Failures preserve reason/trace and all preceding raw data; later integrity exceptions have separate fields. A timeout may prevent final JSON and is retained by the external supervisor, never relabeled passed.

Independent Brent closure uses actual liquid density, exact represented available volume and ideal gas amount/RT; no candidate pressure solver is invoked by the oracle. Every Brent sample is written as attempted before its liquid call, then updated with full returned WaterState and Fraction residual. Independent total U is the exact represented A reference/Cp/v term (B is zero as registered), actual liquid internal energy and explicit manufactured O2/N2 Cv plus source water ideal enthalpy minus R*T. This shares the necessary water caloric source but not the candidate summation or inverse algorithms.

Gates: pressure difference within returned candidate pressure error; gas-volume difference within original pressure-policy volume tolerance; independent energy difference and H-U-p*Vbulk within original inverse energy tolerance; inverse residual plus its returned energy error within original inverse energy tolerance; inverse temperature bound and recovery within original temperature tolerance. All raw differences/bounds are available in forward.json, inverse.json and comparison-before-gates.json. These are numerical point checks under the declared conditional envelope, not certification of that envelope or real material physics.

Current final author API (candidate ea187d15...) was checked against HANDOFF: WetMixedStorage positional convention, .binding/.state/.evaluate/.invert, point.fluid, total_internal_energy_j/total_enthalpy_j/gas_volume_m3/pressure_error_pa and inverse fields. No source edits or source-review approval are implied by runner preparation.
