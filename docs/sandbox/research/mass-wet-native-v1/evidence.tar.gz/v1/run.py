"""Root-operated installed wet mass point experiment. No EOS on import/prepare."""
from pathlib import Path
from fractions import Fraction as F
from dataclasses import fields,is_dataclass,replace
from collections.abc import Mapping
import argparse,hashlib,importlib.metadata,json,math,os,shutil,sys,sysconfig,time,traceback
HERE=Path(__file__).resolve().parent
REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WATER=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')
SUPERVISOR=REPO/'docs/sandbox/research/research-process-supervisor/supervisor.py'
SUPERVISOR_SHA='939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1'
FACTS=REPO/'data/sandbox/research/water-element-convention-v1'
CASE={'schema':'manufactured_wet_mass_point_v1','temperature_k':300.,'bulk_volume_m3':.001,'solid_mass_kg':[.01,0.],
      'liquid_water_mol':.02,'gas_ids':['O2','N2','H2O'],'gas_amounts_mol':[.2,.2,.001],
      'temperature_domain_k':[295.,310.],'pressure_domain_pa':[1e3,1e7],
      'solid_cp_j_kg_k':[1000.,1200.],'solid_volume_m3_kg':[.001,.0005],'dry_gas_cp_j_mol_k':[30.,29.],
      'reference_temperature_k':300.,'reference_pressure_pa':100000.,'reaction_mass_row':[-1,2,-1,0,0],'reaction_enthalpy_j_kg':-200000,
      'inverse_policy':{'energy_tolerance_j':1e-5,'temperature_tolerance_k':1e-4,'maximum_iterations':100},
      'pressure_policy':{'volume_tolerance_m3':1e-12,'pressure_tolerance_pa':1e-5,'maximum_iterations':100},
      'envelope':{'liquid_u_error_j_mol':1e-8,'liquid_v_error_m3_mol':1e-16,'liquid_abs_du_dp_bound_j_mol_pa':1e-4,'gas_u_error_j_mol':1e-9,'gas_cv_lower_j_mol_k':20.},
      'qualification':'One actual HEOS liquid / source ideal-vapor point; manufactured solids, reaction reference and numerical envelope. No trajectory or material admission.'}
def require(ok,reason):
    if not ok:raise ValueError(reason)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def save(path,value):
    p=Path(path);raw=json.dumps(value,indent=2,allow_nan=False)+'\n';tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(raw);tmp.replace(p)
def hashes(root):
    d={}
    for p in sorted(Path(root).rglob('*')):
        require(not p.is_symlink(),'input_symlink')
        if p.is_file():d[p.relative_to(root).as_posix()]=sha(p)
    return d
def installed():
    require(not os.environ.get('PYTHONPATH'),'PYTHONPATH_forbidden')
    from sludge_sandbox.run_service import runtime_identity
    import sludge_sandbox.mass_wet_storage as wet
    package=Path(wet.__file__).resolve().parent
    require(package.is_relative_to(Path(sysconfig.get_paths()['purelib']).resolve()),'actual_installed_package_required')
    direct=importlib.metadata.distribution('sludge-vme').read_text('direct_url.json')
    require(not direct or json.loads(direct).get('dir_info',{}).get('editable') is not True,'editable_forbidden')
    runtime=runtime_identity();actual={p.name:sha(p) for p in package.glob('*.py')}
    source={p.name:sha(p) for p in (REPO/'src/sludge_sandbox').glob('*.py')}
    require(actual==source==runtime['modules'],'actual_installed_source_mismatch')
    return package,runtime,{'python':sys.executable,'package':str(package),'module_count':len(actual),'direct_url':None if direct is None else json.loads(direct)}
def prepare(expected_module_sha):
    package,runtime,environment=installed()
    require(sha(package/'mass_wet_storage.py')==expected_module_sha,'reviewed_wet_source_required')
    require(sha(SUPERVISOR)==SUPERVISOR_SHA,'reviewed_supervisor_required')
    inp=HERE/'inputs';inp.mkdir(exist_ok=False)
    save(inp/'case.json',CASE)
    for src,dest in [(WATER,inp/'water'),(FACTS,inp/'water-element-convention')]:
        original=hashes(src);dest.mkdir()
        for name in original:
            target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/name,target)
        require(hashes(dest)==original,'copy_changed')
    require(len(hashes(inp/'water'))==16,'original_sixteen_water_assets_required')
    gas=REPO/'data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json'
    shutil.copyfile(gas,inp/'gas_molar_mass_facts.json')
    (inp/'implementation').mkdir()
    for p in package.glob('*.py'):shutil.copyfile(p,inp/'implementation'/p.name)
    frozen={'status':'FROZEN','schema':'wet_mass_point_native_freeze_v1','runtime':runtime,'environment':environment,'files':hashes(inp),
            'original_water':hashes(WATER),'original_facts':hashes(FACTS),'original_gas_facts_sha256':sha(gas),'wet_module_sha256':expected_module_sha,
            'scripts':{n:sha(HERE/n) for n in ('run.py','supervise.py','PLAN.md')},'supervisor_sha256':SUPERVISOR_SHA,'timeout_s':90.,'cleanup_grace_s':.1}
    save(HERE/'freeze.json',frozen)
    return {'status':'prepared_no_EOS','freeze_sha256':sha(HERE/'freeze.json'),'environment':environment}
def verify(expected):
    require(sha(HERE/'freeze.json')==expected,'authoritative_freeze_changed');f=read(HERE/'freeze.json')
    require(f['status']=='FROZEN','freeze_unfilled');require(hashes(HERE/'inputs')==f['files'],'frozen_inputs_changed')
    require(hashes(WATER)==f['original_water'] and hashes(FACTS)==f['original_facts'],'original_source_assets_changed')
    require(sha(REPO/'data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json')==f['original_gas_facts_sha256'],'original_gas_facts_changed')
    for n,d in f['scripts'].items():require(sha(HERE/n)==d,'runner_or_plan_changed')
    require(sha(SUPERVISOR)==f['supervisor_sha256']==SUPERVISOR_SHA,'supervisor_changed')
    _,runtime,environment=installed();require(runtime==f['runtime'],'execution_runtime_changed')
    require(read(HERE/'inputs/case.json')==CASE,'registered_point_changed')
    return f,runtime,environment

def capture(value):
    # Every numerical dataclass field is retained; providers are content descriptions.
    from sludge_sandbox.water_properties import is_water_provider
    from sludge_sandbox.deforming_solid_storage import _canonical
    from sludge_sandbox.verification_case import encode
    if is_water_provider(value):return {'concrete_type':[type(value).__module__,type(value).__qualname__],'source':_canonical(value),'implementation':_canonical(value.implementation)}
    if is_dataclass(value):return {f.name:capture(getattr(value,f.name)) for f in fields(value)}
    if isinstance(value,Mapping):return {str(k):capture(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [capture(v) for v in value]
    return encode(value)

def experiment(out):
    from sludge_sandbox.water_properties import load_water_properties
    from sludge_sandbox.ideal_water_vapor import IdealWaterVapor
    from sludge_sandbox.phase_storage import IdealGasPhase,InversePolicy
    from sludge_sandbox.rigid_water_gas import RigidWaterGas,PressurePolicy
    from sludge_sandbox.rigid_storage import RigidStorage,DeclaredNumericalEnvelope
    from sludge_sandbox.thermochemistry import ShomateGas,ShomateSegment
    from sludge_sandbox.reaction_reference import Component,Reaction,Anchor,ReactionReferenceNetwork
    from sludge_sandbox.mass_storage_bridge import MassSolid
    from sludge_sandbox.mass_wet_storage import WaterElementConvention,WetMixedStorage
    from scipy.optimize import brentq
    inp=HERE/'inputs';case=read(inp/'case.json');save(out/'attempted-point.json',case)
    water_dir=inp/'water';manifest=water_dir/'heos-8.0.0-approved-manifest.json'
    water=load_water_properties(water_dir,backend='heos',backend_manifest=manifest)
    vapor=IdealWaterVapor(water_dir,backend='heos',backend_manifest=manifest)
    require(type(water) is type(vapor._water) and water.implementation==vapor._water.implementation and water.reference==vapor.reference,'actual_water_backend_binding')
    save(out/'water-provider.json',capture(water));save(out/'vapor-provider.json',capture(vapor))
    convention=WaterElementConvention.load(inp/'water-element-convention/facts.json')
    R=8.31446261815324;phases={};facts=read(inp/'gas_molar_mass_facts.json');by_id={r['species_id']:r for r in facts}
    for name,cp in zip(('O2','N2'),case['dry_gas_cp_j_mol_k']):
        row=by_id[name];curve=ShomateGas(name,(ShomateSegment((250.,600.),(cp,0.,0.,0.,0.,0.,0.,0.),0.,R,('manufactured-constant-cp',)),),'manufactured_test_fixture',('manufactured-constant-cp',))
        phases[name]=IdealGasPhase(curve,row['nominal_molar_mass_kg_mol'],0,(row['source_id'],row['cache_sha256']))
    phases['H2O']=IdealGasPhase(vapor,water.reference.molar_mass_kg_mol)
    names=tuple(case['gas_ids']);td=tuple(case['temperature_domain_k']);pd=tuple(case['pressure_domain_pa']);env=case['envelope']
    mechanical=RigidWaterGas(water,names,case['bulk_volume_m3'],pd,'planar_interface_no_capillary_pressure',PressurePolicy(**case['pressure_policy']))
    envelope=DeclaredNumericalEnvelope(td,pd,env['liquid_u_error_j_mol'],env['liquid_v_error_m3_mol'],env['liquid_abs_du_dp_bound_j_mol_pa'],{k:env['gas_u_error_j_mol'] for k in names},{k:env['gas_cv_lower_j_mol_k'] for k in names},'manufactured-explicit-error-envelope',('manufactured-envelope',))
    fluid=RigidStorage(mechanical,phases,envelope,True);els=('C','O','N','H')
    rows=(('A','solid',(1,0,0,0)),('B','solid',(F(1,2),F(1,2),0,0)),('O2','gas',(0,1,0,0)),('N2','gas',(0,0,1,0)),('H2O','gas',convention.fractions(els,water.reference.molar_mass_kg_mol)))
    components=tuple(Component(n,p,es,('manufactured-elements',) if n!='H2O' else ('ciaaw-2024-abridged-atomic-weights',convention.facts_sha256)) for n,p,es in rows)
    ref='nist_298.15K_element_standard_formation';tref=F(case['reference_temperature_k']);pref=F(case['reference_pressure_pa'])
    anchors=[Anchor('A',F(),ref,tref,pref,'solid',('manufactured-coordinate-A-zero',))]
    for n in names:anchors.append(Anchor(n,F(phases[n].evaluate(float(tref),float(pref)).enthalpy_j_mol)/F(phases[n].molar_mass_kg_mol),ref,tref,pref,'gas',('actual-bound-gas-reference',)))
    network=ReactionReferenceNetwork(els,components,(Reaction('artificial-oxidation',tuple(case['reaction_mass_row']),case['reaction_enthalpy_j_kg'],'kg_A_consumed',('manufactured-q',)),),tref,pref,'kg_of_declared_components',ref,'manufactured_test_fixture','exact-defined-nominal-parameters',('manufactured-network',),tuple(anchors))
    solids=tuple(MassSolid(n,cp,v,('manufactured-solid-'+n,)) for n,cp,v in zip(('A','B'),case['solid_cp_j_kg_k'],case['solid_volume_m3_kg']))
    storage=WetMixedStorage(fluid,solids,network.solve(),td,case['bulk_volume_m3'],convention)
    identity=storage.binding();save(out/'storage-inputs.json',capture(storage))
    initial=storage.state(tuple(case['solid_mass_kg']),case['liquid_water_mol'],tuple(case['gas_amounts_mol']),0.)
    save(out/'initial-prototype.json',capture(initial));point=storage.evaluate(initial,case['temperature_k']);save(out/'forward.json',capture(point))
    state=replace(initial,internal_energy_j=point.total_internal_energy_j);save(out/'inverse-input.json',capture(state))
    inverse=storage.invert(state,InversePolicy(**case['inverse_policy']));save(out/'inverse.json',capture(inverse))
    # Independent closure: exact represented inventories/volumes, actual liquid density,
    # no candidate storage/pressure solver calls and no prescribed pressure.
    t=case['temperature_k'];nl=F(state.liquid_water_mol);ng=sum(map(F,state.gas_amounts_mol),F());mass=F(water.reference.molar_mass_kg_mol)
    vs=sum((F(m)*F(v) for m,v in zip(state.solid_mass_kg,case['solid_volume_m3_kg'])),F());available=F(case['bulk_volume_m3'])-vs
    samples=[]
    def residual(p):
        row={'pressure_pa':p,'status':'attempted'};samples.append(row);save(out/'brent-liquid-samples.json',samples)
        liquid=water.state_tp(t,p,phase='liquid')
        v=mass/F(liquid.density_kg_m3);res=nl*v+ng*F(R)*F(t)/F(p)-available
        row.update(status='completed',liquid=capture(liquid),residual_m3=capture(res));save(out/'brent-liquid-samples.json',samples)
        return float(res)
    oracle_p=brentq(residual,*pd,xtol=math.nextafter(0.,1.),rtol=4*sys.float_info.epsilon,maxiter=100)
    liquid=water.state_tp(t,oracle_p,phase='liquid');ideal=water.ideal_vapor(t)
    save(out/'oracle-liquid.json',capture(liquid));save(out/'oracle-ideal-water.json',capture(ideal))
    gas_u=(F(30.)-F(R))*F(t)*F(.2)+(F(29.)-F(R))*F(t)*F(.2)+F(.001)*(F(ideal.enthalpy_j_mol)-F(R)*F(t))
    # B is exactly zero in this preregistered point; A anchor is exactly zero.
    require(state.solid_mass_kg[1]==0.,'registered_zero_B_required')
    solid_u=F(state.solid_mass_kg[0])*(F(case['solid_cp_j_kg_k'][0])*(F(t)-tref)-pref*F(case['solid_volume_m3_kg'][0]))
    oracle_u=solid_u+nl*F(liquid.internal_energy_j_mol)+gas_u
    oracle_vgas=ng*F(R)*F(t)/F(oracle_p)
    delta_u=abs(F(point.total_internal_energy_j)-oracle_u);delta_p=abs(F(point.pressure_pa)-F(oracle_p));delta_v=abs(F(point.gas_volume_m3)-oracle_vgas)
    hu=abs(F(point.total_enthalpy_j)-F(point.total_internal_energy_j)-F(point.pressure_pa)*F(case['bulk_volume_m3']))
    inv_res=abs(F(inverse.point.total_internal_energy_j)-F(state.internal_energy_j))+F(inverse.point.energy_error_j)
    metrics={'oracle_pressure_pa':oracle_p,'oracle_total_u_j':capture(oracle_u),'oracle_gas_volume_m3':capture(oracle_vgas),
             'energy_difference_j':capture(delta_u),'pressure_difference_pa':capture(delta_p),'gas_volume_difference_m3':capture(delta_v),'enthalpy_identity_residual_j':capture(hu),
             'inverse_energy_residual_plus_bound_j':capture(inv_res),'inverse_temperature_difference_k':abs(inverse.point.temperature_k-t),'brent_calls':len(samples)}
    save(out/'comparison-before-gates.json',metrics)
    require(storage.binding()==identity,'storage_changed')
    ep=case['inverse_policy'];pp=case['pressure_policy']
    require(delta_u<=F(ep['energy_tolerance_j']),'independent_energy_gate')
    require(delta_p<=F(point.pressure_error_pa),'independent_pressure_enclosure_gate')
    require(delta_v<=F(pp['volume_tolerance_m3']),'independent_gas_volume_gate')
    require(hu<=F(ep['energy_tolerance_j']),'total_enthalpy_identity_gate')
    require(inv_res<=F(ep['energy_tolerance_j']) and inverse.temperature_error_bound_k<=ep['temperature_tolerance_k'],'original_inverse_gates')
    require(abs(F(inverse.point.temperature_k)-F(t))<=F(ep['temperature_tolerance_k']),'inverse_recovery_gate')
    return {'status':'passed','model_identity':identity,'metrics':metrics,'qualification':case['qualification']}

def run(expected,attempt):
    require(attempt and Path(attempt).name==attempt and attempt not in ('.','..'),'simple_new_attempt_name')
    out=HERE/attempt;out.mkdir(exist_ok=False);report={'status':'started'};save(out/'report.json',report);start=time.monotonic();before=None
    try:
        _,before,env=verify(expected);save(out/'runtime-before.json',before);save(out/'environment.json',env);save(out/'inputs-before.json',hashes(HERE/'inputs'))
        report.update(experiment(out))
    except BaseException as exc:report.update(status='failed',error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
    finally:
        try:
            _,after,_=verify(expected);save(out/'runtime-after.json',after);save(out/'inputs-after.json',hashes(HERE/'inputs'));require(before is None or before==after,'runtime_changed')
            report['runtime_unchanged']=True
        except BaseException as exc:report.update(status='failed',integrity_error=str(exc),integrity_traceback=traceback.format_exc())
        report.update(elapsed_s=time.monotonic()-start,runner_sha256=sha(__file__),freeze_sha256=expected);save(out/'report.json',report)
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True)
    prep=sub.add_parser('prepare');prep.add_argument('--module-sha256',required=True)
    exe=sub.add_parser('run');exe.add_argument('--freeze-sha256',required=True);exe.add_argument('--attempt',required=True)
    a=p.parse_args()
    if a.mode=='prepare':
        try:result=prepare(a.module_sha256)
        except BaseException as exc:
            save(HERE/'preparation-failure.json',{'error':str(exc),'traceback':traceback.format_exc()});raise
    else:result=run(a.freeze_sha256,a.attempt)
    print(json.dumps(result,indent=2,allow_nan=False))
    if result['status']=='failed':raise SystemExit(1)
