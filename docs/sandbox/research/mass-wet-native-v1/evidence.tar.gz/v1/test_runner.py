"""Pure stdlib utilities only; never imports model modules or executes prepare/run."""
import importlib.util,json,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('wet_runner',Path(__file__).with_name('run.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Utilities(unittest.TestCase):
 def test_registered_case_and_gates(self):
  c=m.CASE
  self.assertEqual(c['temperature_k'],300.);self.assertEqual(c['solid_mass_kg'],[.01,0.]);self.assertEqual(c['liquid_water_mol'],.02)
  self.assertEqual(c['gas_amounts_mol'],[.2,.2,.001]);self.assertEqual(c['reaction_mass_row'][-1],0)
  self.assertEqual(c['inverse_policy'],{'energy_tolerance_j':1e-5,'temperature_tolerance_k':1e-4,'maximum_iterations':100})
 def test_finite_atomic_save(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'r.json';m.save(p,{'original':True})
   with self.assertRaises(ValueError):m.save(p,{'value':float('nan')})
   self.assertEqual(m.read(p),{'original':True})
 def test_complete_membership_and_symlink(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td);(p/'a').write_bytes(b'one');before=m.hashes(p);(p/'b').write_bytes(b'two');self.assertNotEqual(before,m.hashes(p))
   (p/'linked').symlink_to(p/'a')
   with self.assertRaises(ValueError):m.hashes(p)
if __name__=='__main__':unittest.main()
