# Independent C host review — APPROVE

Final reviewed source: f12bd9109305344aa2fa66cfe9eb8fd797271b3ab295aba8240103aa2e2b64cc; formal new tests: 2906f43eafab84fb82562c5a4b735cebb88fb62e6343719587b836c9d491432a. Actual independent execution: **15 passed in 9.98 s**, with log/XML in independent-tests01. This includes seven B regressions, four C host tests, original/default parity, and three independent probes. Final source hash was rechecked; the live repository source remains unchanged at the B hash 7b56d8f59d1c8e2e9711cefbf79a87b8a11b7eb5a5401376b26ebc040678bd6e. PYTHONDONTWRITEBYTECODE was set for tests. AST parsing passed; ruff/mypy/pylint/black remain unavailable in the designated environment.

No unresolved numerical/security HIGH or CRITICAL finding was identified. Approval is limited to this operator-mode host and its documented domains, not any depletion-event certificate.

Scope: explicit existing-liquid / depleted-no-nucleation operator modes in the two-cell mixed kg/mol host. No event localization, panel proof, roundoff writeback, or material qualification is inferred from a mode switch.

Initial read confirms default binding omits the optional mode extension to retain the old all-wet identity. Explicit modes are bound separately; mode changes return a new host and leave storage/reference and supplied inventories unchanged. Already-zero liquid is required for selected cells. Dry storage inversion sees actual zero liquid; a hypothetical liquid chemical query at the dry gas pressure only assesses whether strict no-nucleation operation leaves its domain.

Independent probes in review_extra_test.py passed: explicit/default all-wet physical-value and chemical-call parity, preservation of mode-switch inputs and rejection of an unbound state, and a second-step dry-domain failure preserving exactly the accepted first step and evaluation counts. Original-B/default parity also passed on the complete encoded nonwall run and full liquid-state/response query journal; the archived old source loads under its canonical module name so class-name provenance does not manufacture a hash difference.

Strict supersaturation and unavailable hypothetical-liquid diagnosis return domain_exit without creating liquid. Accepted dry prefixes retain exact zero liquid and phase flux, while actual reaction and face exchange continue. Wet-to-dry state construction in the tests explicitly initializes separate dry fixtures; those fixtures are not claimed to conserve the earlier wet state or to simulate an event. with_depleted_cells itself only changes host modes for already-zero inputs and does not mutate kg, gas, liquid, U, or grant a writeback tolerance.

No repository changes, installations or native EOS calls are authorized in this review. The root's independently supervised native run is unaffected.
