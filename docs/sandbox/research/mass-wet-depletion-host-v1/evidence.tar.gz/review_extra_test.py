"""Independent host-mode checks; no event localization or native EOS."""
from dataclasses import replace
import pytest
from test_mass_wet_transport import setup
from test_mass_wet_depletion_host import dry_states
from sludge_sandbox.mass_wet_transport import integrate_wet_pair
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.verification_case import encode


def test_explicit_wet_mode_has_identical_values_and_chemical_call_count(monkeypatch):
    pair, states = setup(monkeypatch)
    explicit = replace(pair, interface_modes=('existing_liquid', 'existing_liquid'))
    old = WaterChemicalPotential.equilibrium_at_liquid_tp
    calls = []
    def observed(self, temperature, pressure):
        calls.append((temperature, pressure))
        return old(self, temperature, pressure)
    monkeypatch.setattr(WaterChemicalPotential, 'equilibrium_at_liquid_tp', observed)
    before = pair.evaluate(states)
    baseline_calls = tuple(calls)
    calls.clear()
    after = explicit.evaluate(states)
    assert len(calls) == 2 and tuple(calls) == baseline_calls
    assert encode(before) == encode(after)
    assert pair._identity != explicit._identity


def test_mode_switch_retains_inputs_and_rejects_unbound_state(monkeypatch):
    pair, states = setup(monkeypatch)
    zeros = dry_states(pair, states)
    before = encode(zeros)
    first = pair.with_depleted_cells(zeros, (0,))
    second = first.with_depleted_cells(zeros, (1,))
    assert encode(zeros) == before
    assert second.storages == pair.storages
    assert first.interfaces == ('depleted_no_nucleation', 'existing_liquid')
    assert second.interfaces == ('depleted_no_nucleation',)*2
    invalid = (replace(zeros[0], energy_model_identity='f'*64), zeros[1])
    with pytest.raises(ValueError, match='wet_state_identity'):
        pair.with_depleted_cells(invalid, (0,))


def test_second_step_dry_domain_exit_keeps_accepted_prefix(monkeypatch):
    from sludge_sandbox.water_properties import WaterDomainError
    pair, states = setup(monkeypatch)
    zeros = dry_states(pair, states)
    dry = pair.with_depleted_cells(zeros, (0,1))
    original = WaterChemicalPotential.equilibrium_at_liquid_tp
    calls = [0]
    def unavailable(self, *args, **kwargs):
        calls[0] += 1
        if calls[0] == 7:
            raise WaterDomainError('independent_second_step_liquid_domain_exit')
        return original(self, *args, **kwargs)
    monkeypatch.setattr(WaterChemicalPotential, 'equilibrium_at_liquid_tp', unavailable)
    run = integrate_wet_pair(dry, zeros, duration_s=.001, steps=2)
    assert run.status == 'domain_exit'
    assert run.reason == 'dry_interface_condensation_drive_unknown: independent_second_step_liquid_domain_exit'
    assert run.evaluations_attempted == 4 and run.evaluations_completed == 3
    assert len(run.states) == 2 and len(run.ledgers) == len(run.observations) == 1
    assert all(state.liquid_water_mol == 0 for row in run.states for state in row)
    assert run.ledgers[0].phase_water_mol == (0., 0.)
