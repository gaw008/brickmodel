"""Archived exact old/new comparison harness, not a permanent /tmp dependency."""
from pathlib import Path
import importlib.util,sys
from dataclasses import fields
from test_mass_wet_transport import setup
from sludge_sandbox.mass_wet_transport import integrate_wet_pair
from sludge_sandbox.verification_case import encode


def test_default_positive_path_exact_parity(monkeypatch):
    path=Path(__file__).with_name('before.py')
    name='sludge_sandbox.mass_wet_transport'
    previous=sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    try:
        pair,states=setup(monkeypatch)
        kwargs={f.name:getattr(pair,f.name) for f in fields(module.WetPair) if f.init}
        kwargs['face']=module.WetFace(**{f.name:getattr(pair.face,f.name) for f in fields(module.WetFace) if f.init})
        old=module.WetPair(**kwargs)
        assert old._identity==pair._identity
        from sludge_sandbox.water_properties import WaterProperties
        journal=[]
        def wrapped(label,original):
            def observed(self,t,p,**kwargs):
                journal.append((label,t,p,kwargs['phase']))
                return original(self,t,p,**kwargs)
            return observed
        for label in ('state_tp','state_tp_response'):
            monkeypatch.setattr(WaterProperties,label,wrapped(label,getattr(WaterProperties,label)))
        a=module.integrate_wet_pair(old,states,duration_s=.01,steps=4)
        old_journal=tuple(journal);journal.clear()
        b=integrate_wet_pair(pair,states,duration_s=.01,steps=4)
        assert tuple(journal)==old_journal
        assert a.status==b.status=='completed'
        x,y=encode(a),encode(b)
        x.pop('elapsed_seconds');y.pop('elapsed_seconds')
        assert x==y
    finally:sys.modules[name]=previous
