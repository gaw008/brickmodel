"""Bounded six-fraction native step diagnostic; never a replacement provider."""
from __future__ import annotations
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import traceback
from typing import Any

from sludge_sandbox.water_properties import WaterDomainError, load_water_properties
from sludge_sandbox._heos_kernel import require

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
HERE = Path(__file__).resolve().parent
DATA = ROOT/'data/sandbox/water'
FRACTIONS = (1., .5, .25, .125, .0625, .03125)


def encode(value: Any) -> Any:
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float:
        return {'value': value if math.isfinite(value) else None, 'hex': value.hex(), 'repr': repr(value)}
    if isinstance(value, Mapping):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(item) for item in value]
    if is_dataclass(value):
        return {field.name: encode(getattr(value, field.name)) for field in fields(value)}
    raise TypeError('Unexpected diagnostic value: '+type(value).__name__)


def installed_identity() -> dict[str, dict[str, str]]:
    result = {}
    for name, module in tuple(sys.modules.items()):
        path = getattr(module, '__file__', None)
        if name.startswith('sludge_sandbox') and path:
            installed = Path(path).resolve()
            require('/site-packages/sludge_sandbox/' in str(installed), 'diagnostic_requires_installed_package')
            relative = str(installed).split('/site-packages/', 1)[1]
            require(installed.read_bytes() == (ROOT/'src'/relative).read_bytes(), 'diagnostic_installed_source_mismatch')
            result[name] = {'path': str(installed), 'sha256': hashlib.sha256(installed.read_bytes()).hexdigest()}
    return result


def evaluate_density(kernel: Any, temperature: float, pressure: float, density: float,
                     phase: str, saturation_liquid: Any, saturation_vapor: Any) -> dict[str, float]:
    """Native-SI diagnostic mirrors unchanged TP loop guards/formula explicitly."""
    require(math.isfinite(density) and density > 0, 'heos_tp_invalid_density')
    require(density >= saturation_liquid.density if phase == 'liquid' else density <= saturation_vapor.density,
            'heos_tp_density_branch')
    native = kernel._flash
    cp = kernel._cp
    native.update(cp.DmassT_INPUTS, density, temperature)
    delta = density/322.
    slope = density*kernel._r*temperature*(1+2*delta*native.dalphar_dDelta()+delta*delta*native.d2alphar_dDelta2())
    residual = native.p()-pressure
    require(math.isfinite(slope) and slope > 0 and math.isfinite(residual), 'heos_tp_invalid_slope')
    allowed = (cp.iphase_liquid, cp.iphase_supercritical_liquid) if phase == 'liquid' else (cp.iphase_gas,)
    require(native.phase() in allowed, 'heos_tp_seed_wrong_phase')
    row = {'rho': density, 'native_p': native.p(), 'target_p': pressure,
           'h': native.hmass(), 'u': native.umass(), 'residual_pa': residual, 'slope': slope}
    require(all(math.isfinite(value) for value in row.values()), 'diagnostic_nonfinite_native_record')
    return row


def experiment(result: dict[str, Any]) -> None:
    manifest = json.loads((HERE/'input-manifest.json').read_text())
    for name, record in manifest.items():
        require(hashlib.sha256((HERE/name).read_bytes()).hexdigest() == record['sha256'], 'diagnostic_input_changed')
    captured = json.loads((HERE/'captured-tp.json').read_text())
    prior = json.loads((HERE/'exact-point-result.json').read_text())
    require(prior['status'] == 'failed' and prior['reason'] == 'heos_tp_not_converged',
            'unchanged_exact_point_failure_required')
    arguments = captured['arguments_and_loop_locals']
    temperature = float.fromhex(arguments['t']['hex'])
    pressure = float.fromhex(arguments['p']['hex'])
    phase = arguments['phase']
    first = captured['tp_iterations'][0]
    reference = {name: float.fromhex(value['hex']) for name, value in first.items() if isinstance(value, dict)}
    result['arguments'] = encode({'temperature_k': temperature, 'pressure_pa': pressure, 'phase': phase})
    provider = load_water_properties(DATA, backend='heos', backend_manifest=DATA/'heos-8.0.0-approved-manifest.json')
    kernel = provider._kernel
    result.update(implementation=json.loads(provider.implementation.canonical_json),
        source_asset_sha256=dict(provider.source_asset_sha256), kernel_identity=kernel.identity)
    require(kernel.identity == captured['kernel_identity'] == prior['kernel_identity'], 'diagnostic_kernel_identity_changed')
    provider._guard()
    temperature = kernel._temperature(temperature)
    if isinstance(pressure, bool) or not isinstance(pressure, (int, float)) or not math.isfinite(pressure) or not 0 < pressure <= 1e8:
        raise WaterDomainError('pressure_out_of_declared_domain')
    if phase not in ('liquid', 'vapor'):
        raise WaterDomainError('phase_must_be_liquid_or_vapor')
    with kernel._transaction():
        liquid, vapor = kernel._saturation_pair_locked(temperature)
        saturation_pressure = liquid.pressure
        if abs(pressure-saturation_pressure) <= max(.01, 2e-8*saturation_pressure):
            raise WaterDomainError('saturation_ambiguous')
        if (phase == 'liquid' and pressure < saturation_pressure) or (phase == 'vapor' and pressure > saturation_pressure):
            raise WaterDomainError('unstable_requested_phase')
        result['saturation'] = encode({'liquid': liquid, 'vapor': vapor})
        native, cp = kernel._flash, kernel._cp
        native.update(cp.PT_INPUTS, pressure, temperature)
        allowed = (cp.iphase_liquid, cp.iphase_supercritical_liquid) if phase == 'liquid' else (cp.iphase_gas,)
        require(native.phase() in allowed, 'heos_tp_seed_wrong_phase')
        seed = native.rhomass()
        result['seed_density'] = encode(seed)
        require(seed == reference['rho'], 'diagnostic_seed_differs_from_captured_first_density')
        native.specify_phase(cp.iphase_liquid if phase == 'liquid' else cp.iphase_gas)
        try:
            base = evaluate_density(kernel, temperature, pressure, seed, phase, liquid, vapor)
            result['base_native'] = encode(base)
            result['captured_base_field_equalities'] = {name: value == reference[name] for name, value in base.items()}
            require(all(result['captured_base_field_equalities'].values()), 'diagnostic_base_differs_from_captured_evaluation')
            gate = min(1e-4, seed*1e-7)
            merit = abs(base['residual_pa'])/gate
            step = -base['residual_pa']/base['slope']
            require(math.isfinite(step) and abs(step) < .1, 'heos_tp_step_outside_seed_branch')
            result['base_gate_merit_step'] = encode({'gate_pa': gate, 'normalized_residual': merit, 'full_log_density_step': step})
            result['trials'] = []
            for fraction in FRACTIONS:
                trial_density = seed*math.exp(fraction*step)
                # Every candidate is measured from the same initial density,
                # not chained from previous diagnostic candidates.
                result['active_trial'] = encode({'fraction': fraction, 'density': trial_density})
                row = evaluate_density(kernel, temperature, pressure, trial_density, phase, liquid, vapor)
                trial_gate = min(1e-4, trial_density*1e-7)
                trial_merit = abs(row['residual_pa'])/trial_gate
                row.update(fraction=fraction, gate_pa=trial_gate, normalized_residual=trial_merit,
                    original_gate_pass=abs(row['residual_pa']) <= trial_gate,
                    strict_merit_decrease=trial_merit < merit)
                record = encode(row)
                result['trials'].append(record)
                if row['original_gate_pass']:
                    # An actually evaluated residual is necessary; full existing
                    # Table-3 snapshot checks are ALSO required for a passing trial.
                    snapshot = kernel._snapshot(temperature, pressure, phase)
                    require(snapshot.density >= liquid.density if phase == 'liquid' else snapshot.density <= vapor.density,
                            'heos_density_branch')
                    record['verified_native_snapshot'] = encode(snapshot)
            result['full_step_matches_captured_second_density'] = (
                result['trials'][0]['rho']['hex'] == captured['tp_iterations'][1]['rho']['hex'])
            require(result['full_step_matches_captured_second_density'], 'diagnostic_full_step_not_original_cycle')
        finally:
            native.unspecify_phase()
    provider._guard()
    result['source_config_transaction_completed'] = True
    result['gate_passing_fractions'] = [row['fraction'] for row in result['trials'] if row['original_gate_pass']]
    result['merit_decreasing_fractions'] = [row['fraction'] for row in result['trials'] if row['strict_merit_decrease']]


def main() -> int:
    output = HERE/'step-probe-result.json'
    if output.exists():
        raise SystemExit('Preserve prior probe evidence; create a new reviewed directory for another run')
    started = time.monotonic()
    result: dict[str, Any] = {'status': 'started',
        'scope': 'diagnostic trial densities only; no returned host/property solution or modified solver',
        'native_work_bound': 'constructor+one original saturation solve+one PT seed+one base density+six trial densities+at most six existing full snapshot checks'}
    success = False
    try:
        result['installed_before'] = installed_identity()
        experiment(result)
        success = bool(result['gate_passing_fractions'])
        result['status'] = 'diagnostic_gate_pass_observed' if success else 'diagnostic_no_gate_pass'
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        try:
            result['installed_after'] = installed_identity()
        except BaseException as exc:
            result.update(status='failed', post_identity_error={'type': type(exc).__name__, 'message': str(exc)})
            success = False
        result['elapsed_s'] = time.monotonic()-started
        temporary = output.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
        temporary.replace(output)
    return 0 if success else 1


if __name__ == '__main__':
    raise SystemExit(main())
