"""Load isolated numerical kernel for no-native control tests only."""
import importlib.util
from pathlib import Path
import sys
import pytest
import sludge_sandbox

name = 'sludge_sandbox._heos_kernel'
p = Path(__file__).with_name('candidate_heos_kernel.py')
spec = importlib.util.spec_from_file_location(name, p)
module = importlib.util.module_from_spec(spec)
sys.modules[name] = module
spec.loader.exec_module(module)
setattr(sludge_sandbox, '_heos_kernel', module)
raise SystemExit(pytest.main(sys.argv[1:]))
