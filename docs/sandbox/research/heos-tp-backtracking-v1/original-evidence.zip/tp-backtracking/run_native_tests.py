"""Same nine native cases under a thirty-second source-recorded supervisor."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
HERE = Path(__file__).resolve().parent
PYTHON = Path('/private/tmp/brick-water-backend-probe/venv/bin/python')
PACKAGE = PYTHON.parent.parent/'lib/python3.12/site-packages/sludge_sandbox'

parser = argparse.ArgumentParser()
parser.add_argument('version', choices=('baseline', 'candidate'))
args = parser.parse_args()
supervisor = ROOT/'docs/sandbox/research/research-process-supervisor'
sys.path.insert(0, str(supervisor))
from supervisor import run_attempt
inputs = list(PACKAGE.glob('*.py'))+list((ROOT/'src/sludge_sandbox').glob('*.py'))
inputs += list((ROOT/'data/sandbox/water').rglob('*'))+list(HERE.glob('*.py'))
inputs += [HERE/'PLAN.md', supervisor/'supervisor.py', ROOT/'tests/sandbox/test_water_properties.py']
command = ['/usr/bin/env', 'PYTHONDONTWRITEBYTECODE=1', f'PYTHONPATH={ROOT}/tests/sandbox', str(PYTHON),
           '-m', 'pytest', str(HERE/'test_heos_tp_native.py'), '-q',
           '--junitxml='+str(HERE/(args.version+'-native-tests.xml'))]
result = run_attempt(HERE/(args.version+'-native-attempt01'), command, cwd='/private/tmp',
                     input_paths=[p for p in inputs if p.is_file()], timeout_s=30)
print(json.dumps({key: result[key] for key in ('status','returncode','elapsed_s','cleanup')}, indent=2))
raise SystemExit(0 if result['status']=='complete' and result['returncode']==0 else 1)
