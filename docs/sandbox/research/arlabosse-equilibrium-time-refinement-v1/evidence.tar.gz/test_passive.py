"""Manufactured/passive saved-record checks only; no physics import or EOS."""
from copy import deepcopy
from fractions import Fraction as F
import importlib.util
from pathlib import Path
import sys

import pytest

WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(WORK))
from compare import extract, metric, read, write_exclusive


def test_manufactured_first_order_and_nonshrinking_trend():
    result = metric([1.125, 1.0625, 1.03125], [{}, {}, {}])
    assert result['nominal_order'] == 1
    assert result['descriptive_absolute_ratio'] == 2
    assert result['full_equilibrium_error_bound'] is None
    assert metric([1, 2, 4], [{}, {}, {}])['nominal_order'] == -1


@pytest.mark.parametrize('values,diagnostics,reason', [
    ([1, 1, 1], [{}, {}, {}], 'zero_adjacent_difference'),
    ([1, 2, 1], [{}, {}, {}], 'opposite_signed_differences'),
    ([1.125, 1.0625, 1.03125], [{'conditional': 1}]*3,
     'necessary_conditional_resolution_insufficient'),
])
def test_does_not_invent_order(values, diagnostics, reason):
    result = metric(values, diagnostics)
    assert result['nominal_order'] is None
    assert result['descriptive_absolute_ratio'] is None
    assert result['order_unavailable_reason'] == reason


def test_passive_saved_baseline_and_all_steps_cumulative():
    run = read(WORK.parent/'native01/RUN_1.json')
    one = extract(run)
    manufactured = deepcopy(run)
    manufactured['ledgers'] = [run['ledgers'][0]]*4
    four = extract(manufactured)
    for key, value in one['cumulative_auxiliary'].items():
        assert four['cumulative_auxiliary'][key] == 4*value
    assert four['values']['cumulative_outward_water_mol'] == 4*one['values']['cumulative_outward_water_mol']
    assert four['values']['cell_0_U_j'] == one['values']['cell_0_U_j']
    assert one['diagnostics']['cell_0_T_k']['nominal_flash_T_bracket_width_k'] > 0


def test_output_exclusive_and_strict_finite(tmp_path):
    path = tmp_path/'saved.json'
    write_exclusive(path, {'value': F(2, 3)})
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        write_exclusive(path, {'value': 9})
    assert path.read_bytes() == before
    with pytest.raises(ValueError):
        write_exclusive(tmp_path/'nonfinite.json', {'value': float('nan')})
    assert not (tmp_path/'nonfinite.json').exists()


def test_no_physics_import_in_passive_modules():
    import ast
    for name in ('compare.py', 'run_series.py'):
        tree = ast.parse((WORK/name).read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                assert not (node.module or '').startswith('sludge_sandbox')
            if isinstance(node, ast.Import):
                assert all(not alias.name.startswith('sludge_sandbox') for alias in node.names)


def test_original_saved_attempt_against_actual_new_acceptance_body():
    """Replay only the trusted algebraic check AST, not driver imports or main."""
    import ast
    import math

    class AttributeRecord(dict):
        def __getattr__(self, key):
            if key in self:
                return self[key]
            if key in ('temperature_k', 'pressure_pa') and 'fluid' in self:
                return self['fluid']['mechanical'][key]
            raise AttributeError(key)

    def records(value):
        if isinstance(value, dict):
            return AttributeRecord({k: records(v) for k, v in value.items()})
        if isinstance(value, list):
            return tuple(records(v) for v in value)
        return value

    base = WORK.parent/'native01'
    run = records(read(base/'RUN_1.json'))
    initialized = records(read(base/'INITIALIZATION.json'))
    initial = records(read(base/'INITIAL.json'))['states']
    column = AttributeRecord(gas_ids=('O2', 'N2', 'H2O'), storages=tuple(
        AttributeRecord(model_identity=cell.fixed_composition_inverse.point.model_identity)
        for cell in initialized.cells))
    tree = ast.parse((WORK/'driver.py').read_text())
    body = next(node.body for node in tree.body if isinstance(node, ast.Try))
    first = next(i for i, node in enumerate(body) if isinstance(node, ast.Assign)
                 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'checks')
    last = next(i for i, node in enumerate(body[first:], first) if isinstance(node, ast.Assign)
                and isinstance(node.targets[0], ast.Subscript)
                and isinstance(node.targets[0].slice, ast.Constant)
                and node.targets[0].slice.value == 'inputs_unchanged')
    saved = {}
    environment = {'F': F, 'math': math, 'STEPS': 1, 'run': run,
                   'initialized': initialized, 'initial': initial, 'column': column,
                   'water': lambda states: sum((F(s.liquid_water_mol)+F(s.gas_amounts_mol[2]) for s in states), F()),
                   'energy': lambda states: sum((F(s.internal_energy_j) for s in states), F()),
                   'save': lambda name, value: saved.__setitem__(name, value)}
    selected = ast.Module(body=body[first:last], type_ignores=[])
    exec(compile(selected, str(WORK/'driver.py'), 'exec'), environment)
    assert all(environment['checks'].values()), {k: v for k, v in environment['checks'].items() if not v}
    assert len(environment['checks']) >= 128
    assert saved['OBSERVABLES.json']['cumulative_outward_water_mol'] == run.ledgers[0].boundary_water_mol


def test_cli_help_invalid_and_existing_outputs_stop_before_physics(tmp_path):
    import shutil
    import subprocess
    for name in ('driver.py', 'compare.py', 'run_series.py'):
        shutil.copyfile(WORK/name, tmp_path/name)
    for args in (['-I', str(tmp_path/'run_series.py'), '--help'],
                 [str(tmp_path/'driver.py'), '--help'],
                 [str(tmp_path/'driver.py'), '--steps', '3']):
        result = subprocess.run([sys.executable, *args], capture_output=True, text=True, timeout=5)
        assert result.returncode == (0 if '--help' in args else 2)
    output = tmp_path/'native-steps2'
    output.mkdir()
    marker = output/'preserved.txt'
    marker.write_text('preserved')
    result = subprocess.run([sys.executable, str(tmp_path/'driver.py'), '--steps', '2'],
                            capture_output=True, text=True, timeout=5)
    assert result.returncode != 0 and 'FileExistsError' in result.stderr
    assert marker.read_text() == 'preserved'
    result = subprocess.run([sys.executable, str(tmp_path/'compare.py'), '--output', str(marker)],
                            capture_output=True, text=True, timeout=5)
    assert result.returncode == 2 and 'refuse_to_overwrite' in result.stderr
    (tmp_path/'SERIES_STARTED.json').write_text('{}')
    result = subprocess.run([sys.executable, str(tmp_path/'run_series.py')],
                            capture_output=True, text=True, timeout=5)
    assert result.returncode != 0 and 'refuse_repeated_series' in result.stderr
    assert not (tmp_path/'native-steps4').exists()
