"""Preregistered steps=2 or 4 attempt; original acceptance body retained.

Adapted explicitly from ../native_driver.py; no changes to physics or gates.
"""
import argparse
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import sys
import time

WORK = Path(__file__).resolve().parent
BASE = WORK.parent
parser = argparse.ArgumentParser(description='预登记 1 s 时间加密；每档完整初始化，无重试。')
parser.add_argument('--steps', required=True, type=int, choices=(2, 4))
STEPS = parser.parse_args().steps
OUT = WORK/f'native-steps{STEPS}'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(BASE))
from native_case import make_case
from sludge_sandbox.equilibrium_transport import initialize_equilibrium, integrate_equilibrium_transport
from sludge_sandbox.low_moisture_equilibrium import FlashPolicy, FlashFailure
from sludge_sandbox.phase_storage import InversePolicy

START = time.monotonic()



def encode(value):
    if isinstance(value, F):
        return {'numerator': value.numerator, 'denominator': value.denominator}
    if is_dataclass(value):
        return {f.name: encode(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, FlashFailure):
        return {'reason': value.reason, 'trials': encode(value.trials), 'counts': encode(value.counts),
                'last_completed_provider_result': encode(value.last_completed_provider_result),
                'last_completed_provider_context': encode(value.last_completed_provider_context)}
    if isinstance(value, Mapping):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float) and math.isfinite(value):
        return value
    raise TypeError('unsupported_saved_type:'+type(value).__name__)


def save(name, value):
    raw = json.dumps(encode(value), ensure_ascii=False, indent=2, allow_nan=False)+'\n'
    with (OUT/name).open('x') as f:
        f.write(raw)


def water(states):
    return sum((F(s.liquid_water_mol)+F(s.gas_amounts_mol[2]) for s in states), F())


def energy(states):
    return sum((F(s.internal_energy_j) for s in states), F())


def driver_guard():
    if time.monotonic()-START > 150.:
        raise TimeoutError('driver_wall_budget')


inputs = [Path(__file__), WORK/'PLAN.md', WORK/'BASELINE.json',
          WORK/'compare.py', WORK/'run_series.py', BASE/'native_driver.py', BASE/'native_case.py',
          BASE/'NATIVE_PLAN01.md', BASE/'COUPLING_DESIGN.md',
          BASE/'implementation/equilibrium_transport.py']
freeze = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
policy = FlashPolicy(InversePolicy(1e-5, 1e-6, 40), (325.,338.), 1., 1e-11,
                     1e-12, 1e-5, 1e-5, 4, 40, 500, 50.)
save('INPUTS.json', {'inputs': freeze, 'flash_policy': policy.definition(),
     'initialization_seconds': 40., 'integration_seconds': 100., 'driver_seconds': 150.,
     'duration_s': 1., 'steps': STEPS, 'python': sys.executable})

try:
    sys.path.insert(0, str(WORK))
    from run_series import verify_inputs
    verify_inputs()
    def progress(prefix):
        save(f'CONSTRUCTION_{len(prefix["states"]):02d}.json', prefix)
    column, initial, points = make_case(progress)
    save('INITIAL.json', {'states': initial, 'points': points, 'provenance': column.provenance()})
    driver_guard()
    initialized = initialize_equilibrium(column, initial, (policy, policy),
        maximum_wall_seconds=40., energy_roundoff_budget_j=1e-8, inventory_roundoff_budget_mol=1e-12,
        cancel=lambda: time.monotonic()-START > 150.)
    save('INITIALIZATION.json', initialized)
    driver_guard()
    if initialized.status != 'completed':
        raise ValueError('initialization_'+initialized.status+':'+str(initialized.reason))
    run = integrate_equilibrium_transport(column, initialized, duration_s=1., steps=STEPS,
        maximum_wall_seconds=100., energy_roundoff_budget_j=1e-8, inventory_roundoff_budget_mol=1e-12,
        cancel=lambda: time.monotonic()-START > 150.)
    save('RUN.json', run)
    driver_guard()
    if run.status != 'completed':
        raise ValueError('integration_'+run.status+':'+str(run.reason))
    checks = {'completed': run.status == 'completed', 'requested_steps': len(run.ledgers) == STEPS,
              'physical_clock': run.times_s[-1] == F(1),
              'clock_starts_zero': run.times_s[0] == F(),
              'complete_time_state_shape': len(run.times_s) == len(run.states) == STEPS+1,
              'complete_endpoint_observation_shape': len(run.observations) == STEPS,
              'initialization_continuity': run.states[0] == initialized.states,
              'raw_initialization_continuity': initialized.raw_states == initial,
              'complete_two_cell_shape': len(initial) == len(initialized.states) == 2 and all(len(row) == 2 for row in run.states),
              'energy_budget': run.energy_roundoff_used_j <= F(1e-8),
              'inventory_budget': run.inventory_roundoff_used_mol <= F(1e-12),
              'material_not_qualified': not run.material_qualified}
    ledgers = [initialized.ledger, *run.ledgers]
    pairs = [(initial, initialized.states), *zip(run.states, run.states[1:])]
    for k, (ledger, (old, new)) in enumerate(zip(ledgers, pairs)):
        prefix = f'ledger_{k}_'
        checks[prefix+'complete_shape'] = (len(ledger.faces) == 3 and len(ledger.flashes) == 2
            and len(ledger.fixed_composition_rates.cells) == 2 and len(ledger.cells) == 2
            and len(ledger.exact_total_water_targets) == len(ledger.exact_energy_targets) == 2
            and len(ledger.phase_water_mol) == len(ledger.roundoff.liquid_mol) == 2
            and len(ledger.roundoff.gas_mol) == len(ledger.roundoff.energy_j) == 2
            and all(len(row) == 3 for row in ledger.roundoff.gas_mol))
        dn = sum(ledger.roundoff.liquid_mol, F())+sum((r[2] for r in ledger.roundoff.gas_mol), F())
        du = sum(ledger.roundoff.energy_j, F())
        faces = ledger.faces
        net_n = faces[0].gas_mol[2]-faces[-1].gas_mol[2]
        net_u = faces[0].energy_j-faces[-1].energy_j
        checks[prefix+'global_water'] = water(new)-water(old) == net_n+dn
        checks[prefix+'global_energy'] = energy(new)-energy(old) == net_u+du
        checks[prefix+'declared_balance_residuals'] = ledger.water_balance_residual_mol == ledger.energy_balance_residual_j == 0
        checks[prefix+'separate_heat_enthalpy_balance'] = (energy(new)-energy(old) ==
            ledger.boundary_heat_j-ledger.boundary_enthalpy_j-ledger.boundary_energy_decomposition_j+du)
        face_energy_cost = sum((abs(f.energy_decomposition_roundoff_j)
            +abs(getattr(f, 'moisture_enthalpy_projection_j', F()))
            +abs(getattr(f, 'vapor_enthalpy_projection_j', F()))
            +abs(getattr(f, 'heat_projection_j', F())) for f in faces), F())
        face_water_cost = sum((abs(getattr(f, 'moisture_molar_projection_mol', F()))
            +abs(getattr(f, 'vapor_molar_projection_mol', F())) for f in faces), F())
        state_energy_cost = sum(map(abs, ledger.roundoff.energy_j), F())
        state_water_cost = sum(map(abs, ledger.roundoff.liquid_mol), F())+sum((abs(v) for row in ledger.roundoff.gas_mol for v in row), F())
        checks[prefix+'energy_cost_from_actual_components'] = ledger.step_energy_roundoff_j == state_energy_cost+face_energy_cost
        checks[prefix+'inventory_cost_from_actual_components'] = ledger.step_inventory_roundoff_mol == state_water_cost+face_water_cost
        for i, (s, t, candidate) in enumerate(zip(old, new, ledger.flashes)):
            tag = prefix+f'cell_{i}_'
            expected_nt = (F(s.liquid_water_mol)+F(s.gas_amounts_mol[2])
                +getattr(faces[i], 'moisture_mol', F())-getattr(faces[i+1], 'moisture_mol', F())
                +faces[i].gas_mol[2]-faces[i+1].gas_mol[2])
            expected_u = F(s.internal_energy_j)+faces[i].energy_j-faces[i+1].energy_j
            expected_j = (F(s.liquid_water_mol)+getattr(faces[i], 'moisture_mol', F())
                -getattr(faces[i+1], 'moisture_mol', F())-candidate.exact_liquid_mol)
            checks[tag+'targets_from_old_state_and_faces'] = ledger.exact_total_water_targets[i] == expected_nt and ledger.exact_energy_targets[i] == expected_u
            checks[tag+'same_phase_integral'] = ledger.phase_water_mol[i] == expected_j
            checks[tag+'nonnegative'] = t.liquid_water_mol >= 0 and min(t.gas_amounts_mol) >= 0
            checks[tag+'carrier'] = s.gas_amounts_mol[:2] == t.gas_amounts_mol[:2]
            checks[tag+'same_flash_state'] = t == candidate.state
            checks[tag+'exact_requested_total'] = candidate.exact_liquid_mol+candidate.exact_vapor_mol == ledger.exact_total_water_targets[i]
            checks[tag+'two_water_projections'] = (candidate.liquid_projection_error_mol == ledger.roundoff.liquid_mol[i]
                and candidate.vapor_projection_error_mol == ledger.roundoff.gas_mol[i][2])
            checks[tag+'energy_projection_once'] = ledger.target_energy_projection_j[i] == ledger.roundoff.energy_j[i]
            checks[tag+'full_U_target'] = t.internal_energy_j == float(ledger.exact_energy_targets[i])
            checks[tag+'equilibrium_certificate_unknown'] = candidate.certified_temperature_error_bound_k is None
        for i, cell in enumerate(ledger.fixed_composition_rates.cells):
            inv, p = cell.inverse, cell.inverse.point
            tag = prefix+f'cell_{i}_'
            actual_state = new[i]
            mechanical = p.fluid.mechanical
            checks[tag+'actual_inventory_binding'] = (mechanical.liquid_inventory_mol == actual_state.liquid_water_mol
                and tuple(mechanical.gas_inventory_mol[k] for k in column.gas_ids) == actual_state.gas_amounts_mol)
            checks[tag+'actual_U_residual_binding'] = (inv.target_energy_j == actual_state.internal_energy_j
                and inv.energy_residual_j == F(p.total_internal_energy_j)-F(actual_state.internal_energy_j))
            checks[tag+'full_U_allowance'] = abs(inv.energy_residual_j)+F(p.energy_error_j) <= F(1e-5)
            checks[tag+'conditional_T_certificate'] = 0 <= inv.temperature_error_bound_k <= 1e-8
            checks[tag+'conditional_T_bound_arithmetic'] = (abs(inv.energy_residual_j)+F(p.energy_error_j))/F(p.minimum_heat_capacity_j_k) <= F(inv.temperature_error_bound_k)
            checks[tag+'temperature_domain'] = 325 <= p.temperature_k <= 338
            checks[tag+'complete_pressure_domain'] = 90000 <= F(p.pressure_pa)-F(p.pressure_error_pa) <= F(p.pressure_pa)+F(p.pressure_error_pa) <= 110000
            checks[tag+'source_identity'] = p.model_identity == column.storages[i].model_identity
            verified = ledger.cells[i]
            checks[tag+'chemical_point_binding'] = verified.fixed_composition_inverse == inv and verified.phase == cell.phase
            checks[tag+'actual_mu_residual'] = (verified.actual_chemical_residual_j_mol is not None
                and abs(verified.actual_chemical_residual_j_mol) <= 1e-5)
            vapor = verified.actual_vapor
            checks[tag+'actual_vapor_point_binding'] = (vapor is not None and vapor.temperature_k == p.temperature_k
                and vapor.partial_pressure_pa == cell.phase.water_partial_pressure_pa)
            reconstructed_mu = math.fsum((cell.phase.equilibrium.pure_equilibrium.liquid.chemical_potential_j_mol,
                p.excess.mu_ex_j_mol, -vapor.chemical_potential_j_mol))
            checks[tag+'full_mu_from_saved_actual_values'] = verified.actual_chemical_residual_j_mol == reconstructed_mu
            checks[tag+'actual_peq_pv_residual'] = (verified.equilibrium_pressure_residual_pa ==
                F(cell.phase.equilibrium.equilibrium_partial_pressure_pa)-F(cell.phase.water_partial_pressure_pa)
                and abs(verified.equilibrium_pressure_residual_pa) <= F(1e-5))
            checks[tag+'no_equilibrium_certificate_upgrade'] = (verified.certified_equilibrium_temperature_bound_k is None
                and verified.equilibrium_composition_energy_error_j is None)
    checks['initial_energy_cost'] = initialized.energy_roundoff_used_j == initialized.ledger.step_energy_roundoff_j
    checks['initial_inventory_cost'] = initialized.inventory_roundoff_used_mol == initialized.ledger.step_inventory_roundoff_mol
    checks['energy_cost_inherited_once'] = run.energy_roundoff_used_j == initialized.energy_roundoff_used_j+sum((x.step_energy_roundoff_j for x in run.ledgers), F())
    checks['inventory_cost_inherited_once'] = run.inventory_roundoff_used_mol == initialized.inventory_roundoff_used_mol+sum((x.step_inventory_roundoff_mol for x in run.ledgers), F())
    cumulative_n = sum((l.boundary_water_mol for l in run.ledgers), F())
    cumulative_q = sum((l.boundary_heat_j for l in run.ledgers), F())
    cumulative_h = sum((l.boundary_enthalpy_j for l in run.ledgers), F())
    cumulative_eout = sum((l.faces[-1].energy_j for l in run.ledgers), F())
    cumulative_decomp = sum((l.boundary_energy_decomposition_j for l in run.ledgers), F())
    cumulative_du = sum((sum(l.roundoff.energy_j, F()) for l in run.ledgers), F())
    cumulative_dn = sum((sum(l.roundoff.liquid_mol, F())
        +sum((row[2] for row in l.roundoff.gas_mol), F()) for l in run.ledgers), F())
    checks['complete_time_grid'] = run.times_s == tuple(F(i, STEPS) for i in range(STEPS+1))
    checks['complete_step_durations'] = all(l.duration_s == F(1, STEPS) for l in run.ledgers)
    checks['cumulative_water_from_all_steps'] = water(run.states[-1])-water(run.states[0]) == -cumulative_n+cumulative_dn
    checks['cumulative_energy_from_all_steps'] = energy(run.states[-1])-energy(run.states[0]) == -cumulative_eout+cumulative_du
    checks['cumulative_Q_H_decomposition'] = -cumulative_eout == cumulative_q-cumulative_h-cumulative_decomp
    checks['no_training_or_full_equilibrium_qualification'] = (run.training_eligible is False
        and run.certified_equilibrium_temperature_bound_k is None)
    save('OBSERVABLES.json', {
        'steps': STEPS, 'duration_s': 1.,
        'initial_equilibrium_temperature_k': tuple(c.fixed_composition_inverse.point.temperature_k for c in initialized.cells),
        'final_temperature_k': tuple(c.fixed_composition_inverse.point.temperature_k for c in run.ledgers[-1].cells),
        'final_pressure_pa': tuple(c.fixed_composition_inverse.point.pressure_pa for c in run.ledgers[-1].cells),
        'final_condensed_mol': tuple(s.liquid_water_mol for s in run.states[-1]),
        'final_vapor_mol': tuple(s.gas_amounts_mol[2] for s in run.states[-1]),
        'final_internal_energy_j': tuple(s.internal_energy_j for s in run.states[-1]),
        'cumulative_outward_water_mol': cumulative_n,
        'cumulative_heat_into_column_j': cumulative_q,
        'cumulative_outward_vapor_enthalpy_j': cumulative_h,
        'cumulative_signed_outward_energy_j': cumulative_eout,
        'cumulative_energy_decomposition_j': cumulative_decomp,
        'internal_energy_change_j': energy(run.states[-1])-energy(run.states[0]),
        'per_step': tuple({'duration_s': l.duration_s, 'water_mol': l.boundary_water_mol,
            'heat_j': l.boundary_heat_j, 'vapor_enthalpy_j': l.boundary_enthalpy_j,
            'signed_outward_energy_j': l.faces[-1].energy_j,
            'energy_decomposition_j': l.boundary_energy_decomposition_j} for l in run.ledgers),
        'material_qualified': False, 'training_eligible': False,
        'full_equilibrium_error': 'unknown', 'diagnostic_not_extra_acceptance_gate': True})
    checks['inputs_unchanged'] = all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in freeze.items())
    finished = time.monotonic()-START
    checks['driver_wall'] = finished <= 150.
    save('ACCEPTANCE.json', {'passed': all(checks.values()), 'checks': checks,
                           'driver_seconds': finished, 'timing_scope': 'through checks and input comparison; excludes final acceptance write and stdout',
                           'new_EOS_calls_in_checks': 0})
    print(json.dumps({'passed': all(checks.values()), 'checks': len(checks), 'status': run.status,
                      'initialization_seconds': initialized.elapsed_seconds,
                      'integration_seconds': run.elapsed_seconds, 'driver_seconds': finished}))
    if not all(checks.values()):
        raise SystemExit(2)
except Exception as exc:
    save('FAILURE.json', {'error_type': type(exc).__name__, 'reason': str(exc),
                         'driver_seconds': time.monotonic()-START, 'material_qualified': False})
    print(json.dumps({'error_type': type(exc).__name__, 'reason': str(exc)}))
    raise
