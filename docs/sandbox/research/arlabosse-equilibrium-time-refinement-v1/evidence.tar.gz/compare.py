"""Passive 1/2/4 diagnostics from complete saved records; never imports physics."""
import argparse
import hashlib
from fractions import Fraction as F
import json
import math
from pathlib import Path

WORK = Path(__file__).resolve().parent
BASE = WORK.parent


def _float(text):
    value = float(text)
    if not math.isfinite(value):
        raise ValueError('nonfinite_saved_number')
    return value


def _object(value):
    # Source provenance also uses string-valued rational descriptions: keep those
    # literal metadata records; only the driver's integer wire form is arithmetic.
    if set(value) == {'numerator', 'denominator'} and all(type(v) is int for v in value.values()):
        if value['denominator'] <= 0:
            raise ValueError('invalid_saved_fraction')
        return F(value['numerator'], value['denominator'])
    return value


def read(path):
    def reject(text):
        raise ValueError('nonfinite_saved_number:'+text)
    return json.loads(path.read_text(), object_hook=_object,
                      parse_float=_float, parse_constant=reject)


def encoded(value):
    if isinstance(value, F):
        return {'numerator': value.numerator, 'denominator': value.denominator}
    if isinstance(value, dict):
        return {key: encoded(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encoded(item) for item in value]
    return value


def write_exclusive(path, value):
    raw = json.dumps(encoded(value), ensure_ascii=False, indent=2, allow_nan=False)+'\n'
    with path.open('x') as output:
        output.write(raw)


def metric(values, diagnostics):
    """Exact saved-value differences; descriptive order requires necessary gates."""
    values = tuple(F(x) for x in values)
    deltas = (values[0]-values[1], values[1]-values[2])
    floors = []
    for i in (0, 1):
        ulps = 8*sum((F(math.ulp(float(x))) for x in values[i:i+2]), F())
        floors.append(max([ulps, *(F(diagnostics[i].get(key, 0))
            +F(diagnostics[i+1].get(key, 0))
            for key in set(diagnostics[i]) | set(diagnostics[i+1]))]))
    reason = None
    if any(d == 0 for d in deltas):
        reason = 'zero_adjacent_difference'
    elif deltas[0]*deltas[1] < 0:
        reason = 'opposite_signed_differences'
    elif any(abs(d) <= floor for d, floor in zip(deltas, floors)):
        reason = 'necessary_conditional_resolution_insufficient'
    ratio = None
    order = None
    if reason is None:
        ratio = abs(deltas[0]/deltas[1])
        # Log of integer ratios avoids a nonfinite intermediate float ratio.
        order = (math.log2(ratio.numerator)-math.log2(ratio.denominator))
    return {'values_1_2_4': values, 'signed_differences_12_24': deltas,
            'necessary_resolution_floors_12_24': floors,
            'conditional_diagnostics_1_2_4': diagnostics,
            'descriptive_absolute_ratio': ratio, 'nominal_order': order,
            'order_unavailable_reason': reason,
            'differences_shrink': abs(deltas[1]) < abs(deltas[0]),
            'full_equilibrium_error_bound': None,
            'interpretation': 'necessary diagnostics only; unresolved equilibrium/log/material errors remain unknown'}


def extract(run):
    """Extract all dynamic face integrals, never the last face integral alone."""
    ledgers = run['ledgers']
    cumulative = {key: sum((F(l[key]) for l in ledgers), F()) for key in
                  ('boundary_water_mol', 'boundary_heat_j', 'boundary_enthalpy_j',
                   'boundary_energy_decomposition_j')}
    cumulative['signed_outward_energy_j'] = sum((F(l['faces'][-1]['energy_j']) for l in ledgers), F())
    values = {'cumulative_outward_water_mol': cumulative['boundary_water_mol']}
    diagnostics = {'cumulative_outward_water_mol': {'boundary_water_projection_mol': sum(
        (abs(F(l['faces'][-1]['vapor_molar_projection_mol'])) for l in ledgers), F())}}
    for i, (state, cell) in enumerate(zip(run['states'][-1], ledgers[-1]['cells'])):
        inverse = cell['fixed_composition_inverse']
        point = inverse['point']
        mechanical = point['fluid']['mechanical']
        flash = cell['nominal_flash']
        data = {'T_k': mechanical['temperature_k'], 'Nc_mol': state['liquid_water_mol'],
                'Nv_mol': state['gas_amounts_mol'][2], 'P_pa': mechanical['pressure_pa'],
                'U_j': state['internal_energy_j']}
        numerical = {
            'T_k': {'fixed_composition_T_bound_k': inverse['temperature_error_bound_k'],
                    'nominal_flash_T_bracket_width_k': F(flash['nominal_temperature_bracket_k'][1])-F(flash['nominal_temperature_bracket_k'][0])},
            'Nc_mol': {'nominal_composition_bracket_width_mol': F(flash['composition_bracket_mol'][1])-F(flash['composition_bracket_mol'][0]),
                       'inventory_projection_mol': abs(F(flash['liquid_projection_error_mol']))},
            'Nv_mol': {'nominal_composition_bracket_width_mol': F(flash['composition_bracket_mol'][1])-F(flash['composition_bracket_mol'][0]),
                       'inventory_projection_mol': abs(F(flash['vapor_projection_error_mol']))},
            'P_pa': {'conditional_pressure_error_pa': point['pressure_error_pa']},
            'U_j': {'fixed_composition_U_residual_plus_error_j': abs(F(inverse['energy_residual_j']))+F(point['energy_error_j'])}}
        for key, value in data.items():
            name = f'cell_{i}_{key}'
            values[name] = F(value)
            diagnostics[name] = numerical[key]
    return {'values': values, 'diagnostics': diagnostics, 'cumulative_auxiliary': cumulative}


def compare():
    """Require the original acceptance and equal source/model/initial state."""
    baseline = read(BASE/'supervised-native01/metadata.json')['inputs_before']
    rows = {}
    records = {}
    failures = {}
    started = {}
    try:
        started = read(WORK/'SERIES_STARTED.json')['input_sha256']
        expected_paths = set(baseline) | set(read(WORK/'BASELINE.json')['sha256'])
        expected_paths.update(str(WORK/name) for name in (
            'PLAN.md', 'BASELINE.json', 'driver.py', 'compare.py', 'run_series.py'))
        if set(started) != expected_paths:
            raise ValueError('series_input_set_changed')
        for name, expected in started.items():
            if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
                raise ValueError('series_input_changed:'+name)
    except (OSError, KeyError, ValueError, TypeError) as exc:
        failures['series_binding'] = {'error_type': type(exc).__name__, 'reason': str(exc)}
    for steps in (1, 2, 4):
        folder = BASE/'native01' if steps == 1 else WORK/f'native-steps{steps}'
        supervised = BASE/'supervised-native01' if steps == 1 else WORK/f'supervised-steps{steps}'
        try:
            acceptance = read(folder/'ACCEPTANCE.json')
            run = read(folder/('RUN_1.json' if steps == 1 else 'RUN.json'))
            init = read(folder/'INITIALIZATION.json')
            initial = read(folder/'INITIAL.json')
            inputs = read(folder/'INPUTS.json')
            metadata, status = read(supervised/'metadata.json'), read(supervised/'status.json')
            okay = (acceptance['passed'] is True and bool(acceptance['checks'])
                and all(v is True for v in acceptance['checks'].values())
                and run['status'] == init['status'] == 'completed'
                and inputs['steps'] == steps and inputs['duration_s'] == 1
                and len(run['ledgers']) == len(run['observations']) == steps
                and len(run['states']) == len(run['times_s']) == steps+1
                and run['times_s'] == [F(i, steps) for i in range(steps+1)]
                and len(initial['states']) == len(init['states']) == 2
                and all(len(row) == 2 for row in run['states'])
                and init['raw_states'] == initial['states'] and run['states'][0] == init['states']
                and status['status'] == 'complete' and status['returncode'] == 0
                and status['inputs_unchanged'] is True
                and all(metadata['inputs_before'].get(path) == value
                        and status['inputs_after'].get(path) == value['sha256']
                        for path, value in baseline.items()))
            if steps != 1:
                okay = (okay and set(metadata['inputs_before']) == set(started)
                    and set(status['inputs_after']) == set(started)
                    and all(metadata['inputs_before'][path]['sha256'] == sha
                            and status['inputs_after'][path] == sha
                            for path, sha in started.items()))
            if not okay:
                raise ValueError('original_acceptance_shape_or_frozen_source_check_failed')
            records[steps] = (initial, init, inputs, run)
            rows[steps] = extract(run)
        except (OSError, KeyError, ValueError, TypeError, IndexError) as exc:
            failures[steps] = {'error_type': type(exc).__name__, 'reason': str(exc)}
    if not failures:
        original, init1, input1, run1 = records[1]
        for steps in (2, 4):
            initial, init, inputs, run = records[steps]
            if not (initial == original and init['states'] == init1['states']
                    and init['flash_policies'] == init1['flash_policies']
                    and inputs['flash_policy'] == input1['flash_policy']
                    and run['model_identity'] == run1['model_identity']):
                failures[steps] = {'reason': 'physical_initialization_policy_or_model_not_identical'}
    result = {'steps': [1, 2, 4], 'comparison_available': not failures,
              'failures': {str(k): v for k, v in failures.items()},
              'available_records': {str(k): v for k, v in rows.items()},
              'primary_comparisons': {}, 'diagnostic_only': True,
              'time_convergence_certified': False, 'material_qualified': False,
              'training_eligible': False, 'full_equilibrium_error': 'unknown'}
    if not failures:
        for name in rows[1]['values']:
            result['primary_comparisons'][name] = metric(
                [rows[k]['values'][name] for k in (1, 2, 4)],
                [rows[k]['diagnostics'][name] for k in (1, 2, 4)])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists() or args.output.is_symlink():
        parser.error('refuse_to_overwrite_existing_output')
    result = compare()
    write_exclusive(args.output, result)
    print(json.dumps({'comparison_available': result['comparison_available'],
                      'diagnostic_only': True}))
    return 0 if result['comparison_available'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
