"""Passive saved JSON/Fraction audit only. No application or EOS imports."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,math,traceback,gc
import xml.etree.ElementTree as ET

BASE=Path('/private/tmp/arlabosse-equilibrium-transport-v1')
W=BASE/'time-refinement'
OUT=W/'saved-review'
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
PKG=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
checks={}; extra={}; metrics={}
def hook(d):
    if set(d)=={'numerator','denominator'} and all(type(v) is int for v in d.values()):
        return F(d['numerator'],d['denominator'])
    return d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def water(states):return sum((F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]) for s in states),F())
def energy(states):return sum((F(s['internal_energy_j']) for s in states),F())
def mech(p):return p['fluid']['mechanical']
def temp(p):return mech(p)['temperature_k']
def moisture(f):return f.get('moisture_mol',F())
def fee(row):
    e=sum(map(abs,row['roundoff']['energy_j']),F())
    n=sum(map(abs,row['roundoff']['liquid_mol']),F())+sum((abs(v) for g in row['roundoff']['gas_mol'] for v in g),F())
    for f in row['faces']:
        e+=sum((abs(f.get(k,F())) for k in ('energy_decomposition_roundoff_j','moisture_enthalpy_projection_j','vapor_enthalpy_projection_j','heat_projection_j')),F())
        n+=abs(f.get('moisture_molar_projection_mol',F()))+abs(f.get('vapor_molar_projection_mol',F()))
    return e,n
def enc(v):
    if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
    raise TypeError(type(v).__name__)

# The ledger arithmetic below is reused verbatim from the prior independent
# passive audit, with step counts parameterized; no application module imports.
def audit_attempt(n,a,z,r,accepted,inp,obs,meta,status,original):
    checks={};extra={};metrics={}
    checks.update(completed=r['status']=='completed',requested_steps=len(r['ledgers'])==n,
        physical_clock=r['times_s'][-1]==F(1),clock_starts_zero=r['times_s'][0]==0,
        complete_time_state_shape=len(r['times_s'])==len(r['states'])==n+1,
        complete_endpoint_observation_shape=len(r['observations'])==n,
        initialization_continuity=r['states'][0]==z['states'],raw_initialization_continuity=z['raw_states']==a['states'],
        complete_two_cell_shape=len(a['states'])==len(z['states'])==2 and all(len(x)==2 for x in r['states']),
        energy_budget=r['energy_roundoff_used_j']<=F(1e-8),inventory_budget=r['inventory_roundoff_used_mol']<=F(1e-12),
        material_not_qualified=r['material_qualified'] is False)
    rows=[z['ledger'],*r['ledgers']]; pairs=[(a['states'],z['states']),*zip(r['states'],r['states'][1:])]
    allowances=[];tbounds=[];mus=[];pres=[];local=[]
    for k,(row,(old,new)) in enumerate(zip(rows,pairs)):
        key=f'ledger_{k}_'; f=row['faces'];err=row['roundoff'];fl=row['flashes']
        dn=sum(err['liquid_mol'],F())+sum((g[2] for g in err['gas_mol']),F());du=sum(err['energy_j'],F())
        checks[key+'complete_shape']=(len(f)==3 and len(fl)==len(row['fixed_composition_rates']['cells'])==len(row['cells'])==2
            and len(row['exact_total_water_targets'])==len(row['exact_energy_targets'])==len(row['phase_water_mol'])==2
            and len(err['liquid_mol'])==len(err['gas_mol'])==len(err['energy_j'])==2 and all(len(g)==3 for g in err['gas_mol']))
        checks[key+'global_water']=water(new)-water(old)==f[0]['gas_mol'][2]-f[-1]['gas_mol'][2]+dn
        checks[key+'global_energy']=energy(new)-energy(old)==f[0]['energy_j']-f[-1]['energy_j']+du
        checks[key+'declared_balance_residuals']=row['water_balance_residual_mol']==row['energy_balance_residual_j']==0
        checks[key+'separate_heat_enthalpy_balance']=energy(new)-energy(old)==row['boundary_heat_j']-row['boundary_enthalpy_j']-row['boundary_energy_decomposition_j']+du
        fe,fn=fee(row)
        checks[key+'energy_cost_from_actual_components']=row['step_energy_roundoff_j']==fe
        checks[key+'inventory_cost_from_actual_components']=row['step_inventory_roundoff_mol']==fn
        extra[key+'boundary_fields']=row['boundary_water_mol']==f[-1]['gas_mol'][2] and row['boundary_heat_j']==-f[-1]['conduction_j'] and row['boundary_enthalpy_j']==sum(f[-1]['diffusive_enthalpy_j']+f[-1]['advective_enthalpy_j'],F()) and row['boundary_energy_decomposition_j']==f[-1]['energy_decomposition_roundoff_j']
        extra[key+'disabled_gas_and_carriers']=all(g==0 for face in f for g in face['gas_mol'][:2]) and all(face['gas_mol'][2]==0 for face in f[:-1])
        extra[key+'zero_phase_coefficients_observed']=all(c['phase']['phase_water_mol_s']==0 for c in row['fixed_composition_rates']['cells'])
        for i,(s,t,c,cell,v) in enumerate(zip(old,new,fl,row['fixed_composition_rates']['cells'],row['cells'])):
            tag=key+f'cell_{i}_'; inv=cell['inverse'];p=inv['point']; m=mech(p);phase=cell['phase'];eq=phase['equilibrium'];vap=v['actual_vapor']
            nc=F(s['liquid_water_mol'])+moisture(f[i])-moisture(f[i+1]);nv=F(s['gas_amounts_mol'][2])+f[i]['gas_mol'][2]-f[i+1]['gas_mol'][2]
            nt=nc+nv;u=F(s['internal_energy_j'])+f[i]['energy_j']-f[i+1]['energy_j'];j=nc-c['exact_liquid_mol']
            checks[tag+'targets_from_old_state_and_faces']=row['exact_total_water_targets'][i]==nt and row['exact_energy_targets'][i]==u
            checks[tag+'same_phase_integral']=row['phase_water_mol'][i]==j
            checks[tag+'nonnegative']=t['liquid_water_mol']>=0 and min(t['gas_amounts_mol'])>=0
            checks[tag+'carrier']=s['gas_amounts_mol'][:2]==t['gas_amounts_mol'][:2]
            checks[tag+'same_flash_state']=t==c['state']
            checks[tag+'exact_requested_total']=c['exact_liquid_mol']+c['exact_vapor_mol']==nt
            checks[tag+'two_water_projections']=c['liquid_projection_error_mol']==err['liquid_mol'][i] and c['vapor_projection_error_mol']==err['gas_mol'][i][2]
            checks[tag+'energy_projection_once']=row['target_energy_projection_j'][i]==err['energy_j'][i]
            checks[tag+'full_U_target']=t['internal_energy_j']==float(u)
            checks[tag+'equilibrium_certificate_unknown']=c['certified_temperature_error_bound_k'] is None
            checks[tag+'actual_inventory_binding']=m['liquid_inventory_mol']==t['liquid_water_mol'] and [m['gas_inventory_mol'][g] for g in ('O2','N2','H2O')]==t['gas_amounts_mol']
            ur=F(p['total_internal_energy_j'])-F(t['internal_energy_j']); allowance=abs(ur)+F(p['energy_error_j']);bound=F(inv['temperature_error_bound_k'])
            checks[tag+'actual_U_residual_binding']=inv['target_energy_j']==t['internal_energy_j'] and inv['energy_residual_j']==ur
            checks[tag+'full_U_allowance']=allowance<=F(1e-5)
            checks[tag+'conditional_T_certificate']=0<=bound<=F(1e-8)
            checks[tag+'conditional_T_bound_arithmetic']=allowance/F(p['minimum_heat_capacity_j_k'])<=bound
            checks[tag+'temperature_domain']=325<=temp(p)<=338
            checks[tag+'complete_pressure_domain']=90000<=F(m['pressure_pa'])-F(p['pressure_error_pa'])<=F(m['pressure_pa'])+F(p['pressure_error_pa'])<=110000
            checks[tag+'source_identity']=p['model_identity']==a['provenance']['base']['cells'][i]['model_identity']
            checks[tag+'chemical_point_binding']=v['fixed_composition_inverse']==inv and v['phase']==phase
            mu=math.fsum((eq['pure_equilibrium']['liquid']['chemical_potential_j_mol'],p['excess']['mu_ex_j_mol'],-vap['chemical_potential_j_mol']))
            dp=F(eq['equilibrium_partial_pressure_pa'])-F(phase['water_partial_pressure_pa'])
            checks[tag+'actual_mu_residual']=v['actual_chemical_residual_j_mol'] is not None and abs(v['actual_chemical_residual_j_mol'])<=1e-5
            checks[tag+'actual_vapor_point_binding']=vap['temperature_k']==temp(p) and vap['partial_pressure_pa']==phase['water_partial_pressure_pa']
            checks[tag+'full_mu_from_saved_actual_values']=mu==v['actual_chemical_residual_j_mol']
            checks[tag+'actual_peq_pv_residual']=v['equilibrium_pressure_residual_pa']==dp and abs(dp)<=F(1e-5)
            checks[tag+'no_equilibrium_certificate_upgrade']=v['certified_equilibrium_temperature_bound_k'] is None and v['equilibrium_composition_energy_error_j'] is None
            signed=(F(t['liquid_water_mol'])-(nc-j),F(t['gas_amounts_mol'][2])-(nv+j),F(t['internal_energy_j'])-u)
            extra[tag+'independent_single_projection']=(signed==(err['liquid_mol'][i],err['gas_mol'][i][2],err['energy_j'][i]) and signed[:2]==(F(t['liquid_water_mol'])-c['exact_liquid_mol'],F(t['gas_amounts_mol'][2])-c['exact_vapor_mol']))
            extra[tag+'actual_pv_activity']=phase['water_partial_pressure_pa']==float(F(t['gas_amounts_mol'][2])*F(m['gas_constant_j_mol_k'])*F(temp(p))/F(m['gas_volume_m3'])) and eq['equilibrium_partial_pressure_pa']==float(F(eq['pure_equilibrium']['equilibrium_partial_pressure_pa'])*F(p['excess']['activity']))
            base_u=float(F(p['fluid']['internal_energy_j'])+F(p['solid_internal_energy_j']))
            extra[tag+'full_U_reconstruction']=p['total_internal_energy_j']==float(F(base_u)+p['excess_internal_energy_j'])
            extra[tag+'W_and_reference']=0<=p['excess']['moisture_kg_water_per_kg_dry']<=F(.15) and vap['entropy_reference']==eq['pure_equilibrium']['liquid']['entropy_reference']
            extra[tag+'flash_policy_and_unknown']=c['policy']==z['flash_policies'][i] and c['counts']['provider_calls']<=500 and c['material_qualified'] is False and c['training_eligible'] is False and c['equilibrium_composition_energy_error_j'] is None and c['nominal_chemical_numerical_error_j_mol'] is None
            allowances.append(allowance);tbounds.append(bound);mus.append(mu);pres.append(dp)
            local.append({'ledger':k,'cell':i,'signed_projection':signed,'J_mol':j,'new_Nt_mol':F(t['liquid_water_mol'])+F(t['gas_amounts_mol'][2])})
    checks['initial_energy_cost']=z['energy_roundoff_used_j']==z['ledger']['step_energy_roundoff_j']
    checks['initial_inventory_cost']=z['inventory_roundoff_used_mol']==z['ledger']['step_inventory_roundoff_mol']
    checks['energy_cost_inherited_once']=r['energy_roundoff_used_j']==z['energy_roundoff_used_j']+sum((x['step_energy_roundoff_j'] for x in r['ledgers']),F())
    checks['inventory_cost_inherited_once']=r['inventory_roundoff_used_mol']==z['inventory_roundoff_used_mol']+sum((x['step_inventory_roundoff_mol'] for x in r['ledgers']),F())
    cumulative={key:sum((row[key] for row in r['ledgers']),F()) for key in
        ('boundary_water_mol','boundary_heat_j','boundary_enthalpy_j','boundary_energy_decomposition_j')}
    cumulative['signed_outward_energy_j']=sum((row['faces'][-1]['energy_j'] for row in r['ledgers']),F())
    dn=sum((sum(row['roundoff']['liquid_mol'],F())+sum((g[2] for g in row['roundoff']['gas_mol']),F()) for row in r['ledgers']),F())
    du=sum((sum(row['roundoff']['energy_j'],F()) for row in r['ledgers']),F())
    checks['complete_time_grid']=r['times_s']==[F(i,n) for i in range(n+1)]
    checks['complete_step_durations']=all(row['duration_s']==F(1,n) for row in r['ledgers'])
    checks['cumulative_water_from_all_steps']=water(r['states'][-1])-water(r['states'][0])==-cumulative['boundary_water_mol']+dn
    checks['cumulative_energy_from_all_steps']=energy(r['states'][-1])-energy(r['states'][0])==-cumulative['signed_outward_energy_j']+du
    checks['cumulative_Q_H_decomposition']=-cumulative['signed_outward_energy_j']==cumulative['boundary_heat_j']-cumulative['boundary_enthalpy_j']-cumulative['boundary_energy_decomposition_j']
    checks['no_training_or_full_equilibrium_qualification']=r['training_eligible'] is False and r['certified_equilibrium_temperature_bound_k'] is None
    checks['inputs_unchanged']=all(sha(Path(p))==s for p,s in inp['inputs'].items())
    checks['driver_wall']=0<=accepted['driver_seconds']<=150
    extra['exact_original_gates']=set(checks)==set(accepted['checks']) and all(v is True for v in accepted['checks'].values()) and accepted['passed'] is True
    extra['all_recomputed_gates_equal_saved']=checks==accepted['checks']
    extra['same_initial_case_policy_and_model']=(a==original['initial'] and z['states']==original['init']['states']
        and z['flash_policies']==original['init']['flash_policies'] and inp['flash_policy']==original['inputs']['flash_policy']
        and r['model_identity']==original['model_identity'])
    extra['embedded_initialization_observations']=r['initialization']==z and all(o==row['fixed_composition_rates'] for o,row in zip(r['observations'],r['ledgers']))
    extra['zero_prior_and_zero_time']=z['prior_energy_roundoff_j']==z['prior_inventory_roundoff_mol']==z['ledger']['duration_s']==0
    extra['complete_status_and_unknown']=(z['status']=='completed' and r['reason'] is None and z['reason'] is None
        and z['failed_trial'] is None and r['failed_trial'] is None and r['numerical_policy']['order']==1
        and all(x['material_qualified'] is False and x['training_eligible'] is False
                and x['certified_equilibrium_temperature_bound_k'] is None for x in (r,z)))
    extra['resources_and_reaping']=(0<=z['elapsed_seconds']<=40 and 0<=r['elapsed_seconds']<=100
        and status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] is True
        and status['cleanup']['signal_errors']==[] and status['elapsed_s']<=170
        and meta['timeout_s']==165 and meta['cleanup_grace_s']==5
        and inp['initialization_seconds']==40 and inp['integration_seconds']==100 and inp['driver_seconds']==150)
    extra['construction_prefix']=all(read(W/f'native-steps{n}'/f'CONSTRUCTION_{j:02d}.json')==
        {'states':a['states'][:j],'points':a['points'][:j]} for j in (1,2))
    prefix_n=F();prefix_e=F();prefix_dn=F();prefix_du=F();prefix_fees=[F(),F()]
    for k,(row,(old,new)) in enumerate(zip(rows,pairs)):
        prefix_n+=row['boundary_water_mol'];prefix_e+=row['faces'][-1]['energy_j']
        prefix_dn+=sum(row['roundoff']['liquid_mol'],F())+sum((g[2] for g in row['roundoff']['gas_mol']),F())
        prefix_du+=sum(row['roundoff']['energy_j'],F())
        ee,nn=fee(row);prefix_fees[0]+=ee;prefix_fees[1]+=nn
        extra[f'prefix_{k}_raw_water_U_fees']=(water(new)-water(a['states'])==-prefix_n+prefix_dn
            and energy(new)-energy(a['states'])==-prefix_e+prefix_du and prefix_fees[0]<=F(1e-8) and prefix_fees[1]<=F(1e-12))
    extra['actual_cumulative_fees']=prefix_fees==[r['energy_roundoff_used_j'],r['inventory_roundoff_used_mol']]
    for k,row in enumerate(r['ledgers']):
        h=row['duration_s'];flow=row['origin_rates'];components=[]
        prior=z['rates'] if k==0 else r['ledgers'][k-1]['fixed_composition_rates']
        extra[f'step_{k}_actual_origin_cells']=flow['cells']==prior['cells']
        for f,q in zip(row['faces'],flow['faces']):
            ok=(f['energy_j']==h*F(q['energy_w']) and f['conduction_j']==h*F(q['conduction_w'])
                and f['gas_mol']==[h*F(x) for x in q['gas_mol_s']]
                and f['diffusive_enthalpy_j']==[h*F(x) for x in q['diffusive_enthalpy_w']]
                and f['advective_enthalpy_j']==[h*F(x) for x in q['advective_enthalpy_w']])
            decomp=f['energy_j']-f['conduction_j']-sum(f['diffusive_enthalpy_j']+f['advective_enthalpy_j'],F())-f.get('moisture_enthalpy_j',F())
            ok=ok and f['energy_decomposition_roundoff_j']==decomp
            if 'moisture_mol' in f:
                ex=q['moisture_witness']['exchange']
                ok=(ok and f['moisture_mol']==h*F(ex['molar_flow_mol_s']) and f['moisture_enthalpy_j']==h*F(ex['carried_energy_w'])
                    and f['moisture_molar_projection_mol']==f['moisture_mol']-h*ex['exact_molar_flow_mol_s']
                    and f['moisture_enthalpy_projection_j']==f['moisture_enthalpy_j']-h*ex['exact_carried_energy_w'])
            if 'vapor_molar_projection_mol' in f:
                ok=(ok and f['vapor_molar_projection_mol']==f['gas_mol'][2]-h*q['exact_water_mol_s']
                    and f['vapor_enthalpy_projection_j']==f['diffusive_enthalpy_j'][2]-h*q['exact_carried_energy_w']
                    and f['heat_projection_j']==-f['conduction_j']-h*q['exact_heat_into_cell_w'])
            components.append(ok)
        extra[f'step_{k}_actual_face_integrals_projections']=all(components)
    wanted={'steps':n,'duration_s':1.,
        'initial_equilibrium_temperature_k':[temp(c['fixed_composition_inverse']['point']) for c in z['cells']],
        'final_temperature_k':[temp(c['fixed_composition_inverse']['point']) for c in r['ledgers'][-1]['cells']],
        'final_pressure_pa':[mech(c['fixed_composition_inverse']['point'])['pressure_pa'] for c in r['ledgers'][-1]['cells']],
        'final_condensed_mol':[s['liquid_water_mol'] for s in r['states'][-1]],
        'final_vapor_mol':[s['gas_amounts_mol'][2] for s in r['states'][-1]],
        'final_internal_energy_j':[s['internal_energy_j'] for s in r['states'][-1]],
        'cumulative_outward_water_mol':cumulative['boundary_water_mol'],
        'cumulative_heat_into_column_j':cumulative['boundary_heat_j'],
        'cumulative_outward_vapor_enthalpy_j':cumulative['boundary_enthalpy_j'],
        'cumulative_signed_outward_energy_j':cumulative['signed_outward_energy_j'],
        'cumulative_energy_decomposition_j':cumulative['boundary_energy_decomposition_j'],
        'internal_energy_change_j':energy(r['states'][-1])-energy(r['states'][0]),
        'per_step':[{'duration_s':l['duration_s'],'water_mol':l['boundary_water_mol'],'heat_j':l['boundary_heat_j'],
            'vapor_enthalpy_j':l['boundary_enthalpy_j'],'signed_outward_energy_j':l['faces'][-1]['energy_j'],
            'energy_decomposition_j':l['boundary_energy_decomposition_j']} for l in r['ledgers']],
        'material_qualified':False,'training_eligible':False,'full_equilibrium_error':'unknown','diagnostic_not_extra_acceptance_gate':True}
    extra['entire_observables_from_saved_run']=obs==wanted
    metrics={'seconds':{'initialization':z['elapsed_seconds'],'integration':r['elapsed_seconds'],
        'driver':accepted['driver_seconds'],'supervisor':status['elapsed_s']},
        'original_checks':len(checks),'additional_checks':len(extra),'cumulative':cumulative,
        'final_T':wanted['final_temperature_k'],'final_P':wanted['final_pressure_pa'],
        'maximum_U_allowance_j':float(max(allowances)),'maximum_conditional_T_bound_k':float(max(tbounds)),
        'actual_full_mu_j_mol':mus,'actual_peq_pv_pa':pres,'energy_fee_j':prefix_fees[0],'inventory_fee_mol':prefix_fees[1]}
    return {'checks':checks,'additional':extra,'metrics':metrics}

def extract_metrics(r):
    ledgers=r['ledgers'];data={};diagnostics={}
    sums={key:sum((F(row[key]) for row in ledgers),F()) for key in
        ('boundary_water_mol','boundary_heat_j','boundary_enthalpy_j','boundary_energy_decomposition_j')}
    sums['signed_outward_energy_j']=sum((F(row['faces'][-1]['energy_j']) for row in ledgers),F())
    data['cumulative_outward_water_mol']=sums['boundary_water_mol']
    diagnostics['cumulative_outward_water_mol']={'boundary_water_projection_mol':sum(
        (abs(F(row['faces'][-1]['vapor_molar_projection_mol'])) for row in ledgers),F())}
    for i,(s,c) in enumerate(zip(r['states'][-1],ledgers[-1]['cells'])):
        inv=c['fixed_composition_inverse'];p=inv['point'];fl=c['nominal_flash']
        vals={'T_k':temp(p),'Nc_mol':s['liquid_water_mol'],'Nv_mol':s['gas_amounts_mol'][2],
            'P_pa':mech(p)['pressure_pa'],'U_j':s['internal_energy_j']}
        cb=F(fl['composition_bracket_mol'][1])-F(fl['composition_bracket_mol'][0])
        dd={'T_k':{'fixed_composition_T_bound_k':inv['temperature_error_bound_k'],
            'nominal_flash_T_bracket_width_k':F(fl['nominal_temperature_bracket_k'][1])-F(fl['nominal_temperature_bracket_k'][0])},
            'Nc_mol':{'nominal_composition_bracket_width_mol':cb,'inventory_projection_mol':abs(F(fl['liquid_projection_error_mol']))},
            'Nv_mol':{'nominal_composition_bracket_width_mol':cb,'inventory_projection_mol':abs(F(fl['vapor_projection_error_mol']))},
            'P_pa':{'conditional_pressure_error_pa':p['pressure_error_pa']},
            'U_j':{'fixed_composition_U_residual_plus_error_j':abs(F(inv['energy_residual_j']))+F(p['energy_error_j'])}}
        for k,v in vals.items():data[f'cell_{i}_{k}']=F(v);diagnostics[f'cell_{i}_{k}']=dd[k]
    return {'values':data,'diagnostics':diagnostics,'cumulative_auxiliary':sums}

def audit_comparison(items,saved):
    gates={};reported={}
    gates['qualification_and_completeness']=(saved['comparison_available'] is True and saved['failures']=={}
        and saved['steps']==[1,2,4] and saved['diagnostic_only'] is True and saved['time_convergence_certified'] is False
        and saved['material_qualified'] is False and saved['training_eligible'] is False and saved['full_equilibrium_error']=='unknown'
        and set(saved['primary_comparisons'])==set(items[1]['values']))
    gates['all_three_saved_metric_records']=saved['available_records']=={str(n):items[n] for n in (1,2,4)}
    for key in items[1]['values']:
        values=[items[n]['values'][key] for n in (1,2,4)]
        ds=[items[n]['diagnostics'][key] for n in (1,2,4)]
        delta=[values[0]-values[1],values[1]-values[2]];floors=[]
        for i in (0,1):
            pieces=[8*sum((F(math.ulp(float(v))) for v in values[i:i+2]),F())]
            pieces.extend(F(ds[i].get(k,0))+F(ds[i+1].get(k,0)) for k in set(ds[i])|set(ds[i+1]))
            floors.append(max(pieces))
        reason=('zero_adjacent_difference' if 0 in delta else 'opposite_signed_differences' if delta[0]*delta[1]<0
            else 'necessary_conditional_resolution_insufficient' if any(abs(d)<=b for d,b in zip(delta,floors)) else None)
        ratio=abs(delta[0]/delta[1]) if reason is None else None
        p=math.log2(ratio.numerator)-math.log2(ratio.denominator) if ratio is not None else None
        expected={'values_1_2_4':values,'signed_differences_12_24':delta,'necessary_resolution_floors_12_24':floors,
            'conditional_diagnostics_1_2_4':ds,'descriptive_absolute_ratio':ratio,'nominal_order':p,'order_unavailable_reason':reason,
            'differences_shrink':abs(delta[1])<abs(delta[0]),'full_equilibrium_error_bound':None,
            'interpretation':'necessary diagnostics only; unresolved equilibrium/log/material errors remain unknown'}
        gates[key]=saved['primary_comparisons'][key]==expected
        reported[key]={'d12':delta[0],'d24':delta[1],'floors':floors,'ratio':ratio,'nominal_order':p,'reason':reason}
    return gates,reported

result={'status':'FAIL','attempts':{},'global_checks':{},'comparison_checks':{},'metrics':{}}
g=result['global_checks'];inputs_read={};failed=[]
try:
    original={'initial':read(BASE/'native01/INITIAL.json'),'init':read(BASE/'native01/INITIALIZATION.json'),
        'inputs':read(BASE/'native01/INPUTS.json')}
    oldrun=read(BASE/'native01/RUN_1.json');original['model_identity']=oldrun['model_identity']
    items={1:extract_metrics(oldrun)};del oldrun;gc.collect()
    baseline=read(W/'BASELINE.json')['sha256'];started=read(W/'SERIES_STARTED.json');series=read(W/'SERIES_RESULT.json')
    oldmeta=read(BASE/'supervised-native01/metadata.json');oldstatus=read(BASE/'supervised-native01/status.json')
    expected_paths=set(baseline)|set(oldmeta['inputs_before'])|{str(W/name) for name in ('PLAN.md','BASELINE.json','driver.py','compare.py','run_series.py')}
    table=started['input_sha256']
    g['old_baseline_artifacts_unchanged']=all(sha(Path(p))==s for p,s in baseline.items())
    g['complete_series_input_set']=set(table)==expected_paths
    g['all_current_series_input_bytes']=all(sha(Path(p))==s for p,s in table.items())
    g['old_supervisor_pinned_unchanged']=oldstatus['inputs_unchanged'] is True and {p:v['sha256'] for p,v in oldmeta['inputs_before'].items()}==oldstatus['inputs_after']
    g['series_policy']=started['steps']==[2,4] and started['attempts_at_most']==2 and started['retry'] is False and [started[k] for k in ('init_seconds','integration_seconds','driver_seconds','supervisor_seconds','cleanup_seconds')]==[40,100,150,165,5]
    g['series_terminal']=series['failure'] is None and series['comparison_available'] is True and len(series['attempts'])==2 and series['material_qualified'] is False and series['training_eligible'] is False
    freeze=read(BASE/'install/IDENTITY01.json')
    g['source_installed_freeze']=len(freeze['members'])==freeze['package_files']==186 and freeze['python_modules']==179 and all(sha(ROOT/'src/sludge_sandbox'/n)==s==sha(PKG/n) for n,s in freeze['members'].items())
    installed=ET.parse(BASE/'install/INSTALLED_TESTS01.xml').getroot().find('testsuite')
    g['retained_installed_test_record']=int(installed.attrib['tests'])==12 and all(int(installed.attrib[k])==0 for k in ('failures','errors','skipped'))
    reviewed=read(W/'review/FINAL_READ02.json')['sha256']
    g['reviewed_plan_and_harness']=all(sha(W/name)==reviewed[name] for name in ('PLAN.md','BASELINE.json','driver.py','compare.py','run_series.py'))
    for n in (2,4):
        d=W/f'native-steps{n}';s=W/f'supervised-steps{n}'
        a=read(d/'INITIAL.json');z=read(d/'INITIALIZATION.json');r=read(d/'RUN.json')
        accepted=read(d/'ACCEPTANCE.json');inp=read(d/'INPUTS.json');obs=read(d/'OBSERVABLES.json');meta=read(s/'metadata.json');status=read(s/'status.json')
        result['attempts'][str(n)]=audit_attempt(n,a,z,r,accepted,inp,obs,meta,status,original)
        items[n]=extract_metrics(r)
        normalized={p:v['sha256'] for p,v in meta['inputs_before'].items()}
        g[f'steps{n}_all_snapshots_bound']=normalized==status['inputs_after']==table and status['inputs_unchanged'] is True
        g[f'steps{n}_byte_sizes']=all(Path(p).stat().st_size==v['bytes'] for p,v in meta['inputs_before'].items())
        summary=next(x for x in series['attempts'] if x['steps']==n)
        g[f'steps{n}_series_terminal_correspondence']=all(summary[k]==v for k,v in status.items() if not k.startswith('inputs_'))
        inputs_read[str(n)]={name:sha(d/name) for name in ('INITIAL.json','INITIALIZATION.json','RUN.json','ACCEPTANCE.json','INPUTS.json','OBSERVABLES.json')}
        del a,z,r;gc.collect()
    cc,cm=audit_comparison(items,read(W/'COMPARISON.json'));result['comparison_checks']=cc;result['metrics']['comparisons']=cm
    result['metrics']['input_counts']={'old':len(oldmeta['inputs_before']),'new_each':len(table)}
    result['metrics']['nominal_order_count']=sum(v['nominal_order'] is not None for v in cm.values())
    result['metrics']['unavailable']={k:v['reason'] for k,v in cm.items() if v['nominal_order'] is None}
except Exception:
    g['audit_exception']=False;result['exception']=traceback.format_exc()
for group,data in (('global',g),('comparison',result['comparison_checks'])):
    failed.extend(f'{group}/{k}' for k,v in data.items() if v is not True)
for n,data in result['attempts'].items():
    for group in ('checks','additional'):
        failed.extend(f'{n}/{group}/{k}' for k,v in data[group].items() if v is not True)
result.update(status='FAIL' if failed else 'PASS',failed=failed,script_sha256=sha(Path(__file__)),saved_input_sha256=inputs_read,
    limitations=['passive saved JSON/Fraction arithmetic only; 0 EOS/native/tests','same 1 s at 1/2/4 steps, nominal order descriptive only',
        'necessary resolution diagnostics are not full equilibrium error bounds','no certified field/spatial/material convergence or training eligibility'])
with (OUT/'SAVED_REVIEW01.json').open('x') as f:json.dump(result,f,default=enc,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':result['status'],'failed':failed,'original_checks':{n:len(d['checks']) for n,d in result['attempts'].items()},
    'additional_checks':{n:len(d['additional']) for n,d in result['attempts'].items()},'global_checks':len(g),
    'comparison_checks':len(result['comparison_checks']),'nominal_order_count':result['metrics'].get('nominal_order_count'),
    'exception':result.get('exception')},ensure_ascii=False))
raise SystemExit(bool(failed))
