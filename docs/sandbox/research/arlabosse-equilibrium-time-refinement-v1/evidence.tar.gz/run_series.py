"""Two serial supervised attempts, steps 2 then 4; no retry or physics import."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(WORK))
from compare import compare, read, write_exclusive
BASE = WORK.parent
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
PYTHON = Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python')
SUPERVISOR = ROOT/'docs/sandbox/research/research-process-supervisor/supervisor.py'


def verify_inputs():
    """Match every original frozen byte before allowing a new physics attempt."""
    frozen = read(WORK/'BASELINE.json')['sha256']
    for name, expected in frozen.items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
            raise ValueError('baseline_record_changed:'+name)
    metadata = read(BASE/'supervised-native01/metadata.json')
    status = read(BASE/'supervised-native01/status.json')
    acceptance = read(BASE/'native01/ACCEPTANCE.json')
    if not (status['status'] == 'complete' and status['returncode'] == 0
            and status['inputs_unchanged'] is True and acceptance['passed'] is True
            and acceptance['checks'] and all(v is True for v in acceptance['checks'].values())):
        raise ValueError('baseline_not_accepted')
    inputs = set(map(Path, frozen))
    for name, value in metadata['inputs_before'].items():
        path = Path(name)
        if (status['inputs_after'].get(name) != value['sha256']
                or hashlib.sha256(path.read_bytes()).hexdigest() != value['sha256']):
            raise ValueError('physical_runtime_or_source_changed:'+name)
        inputs.add(path)
    inputs.update(WORK/name for name in ('PLAN.md', 'BASELINE.json', 'driver.py',
                                         'compare.py', 'run_series.py'))
    started_path = WORK/'SERIES_STARTED.json'
    if started_path.exists() or started_path.is_symlink():
        started = read(started_path)['input_sha256']
        if set(started) != {str(path) for path in inputs}:
            raise ValueError('series_input_set_changed')
        for name, expected in started.items():
            if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
                raise ValueError('series_input_changed:'+name)
    return sorted(inputs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dry-run', action='store_true', help='只核输入和独占输出路径，不启动任何物性进程')
    args = parser.parse_args()
    for name in ('SERIES_STARTED.json', 'SERIES_RESULT.json', 'COMPARISON.json',
                 'native-steps2', 'native-steps4', 'supervised-steps2', 'supervised-steps4'):
        path = WORK/name
        if path.exists() or path.is_symlink():
            raise FileExistsError('refuse_repeated_series:'+str(path))
    inputs = verify_inputs()
    if args.dry_run:
        print(json.dumps({'dry_run': True, 'steps': [2, 4], 'frozen_inputs': len(inputs),
                          'new_EOS_calls': 0, 'supervisor_seconds_each': 165., 'cleanup_seconds_each': 5.}))
        return 0
    write_exclusive(WORK/'SERIES_STARTED.json', {'steps': [2, 4], 'attempts_at_most': 2,
        'init_seconds': 40., 'integration_seconds': 100., 'driver_seconds': 150.,
        'supervisor_seconds': 165., 'cleanup_seconds': 5.,
        'input_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs},
        'retry': False, 'material_qualified': False})
    spec = importlib.util.spec_from_file_location('equilibrium_time_supervisor', SUPERVISOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    results = []
    failure = None
    try:
        for steps in (2, 4):
            verify_inputs()
            result = module.run_attempt(WORK/f'supervised-steps{steps}',
                ['/usr/bin/env', '-u', 'PYTHONPATH', str(PYTHON), '-I',
                 str(WORK/'driver.py'), '--steps', str(steps)],
                cwd='/private/tmp', input_paths=inputs, timeout_s=165., cleanup_grace_s=5.)
            results.append({'steps': steps, **{key: value for key, value in result.items()
                                              if not key.startswith('inputs_')}})
            if not (result['status'] == 'complete' and result['returncode'] == 0
                    and result['inputs_unchanged'] is True):
                failure = {'reason': 'attempt_failed_no_retry', 'steps': steps}
                break
    except Exception as exc:
        failure = {'error_type': type(exc).__name__, 'reason': str(exc)}
    comparison = compare()
    write_exclusive(WORK/'COMPARISON.json', comparison)
    final = {'attempts': results, 'failure': failure,
             'comparison_available': comparison['comparison_available'],
             'material_qualified': False, 'training_eligible': False}
    write_exclusive(WORK/'SERIES_RESULT.json', final)
    print(json.dumps(final, ensure_ascii=False, indent=2))
    return 0 if failure is None and comparison['comparison_available'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
