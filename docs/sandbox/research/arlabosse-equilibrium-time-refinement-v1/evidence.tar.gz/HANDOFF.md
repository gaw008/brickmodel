# 时间加密薄 harness 交接（尚未执行 EOS）

仅本目录新增，旧 native01/原计划/源码/安装包未改。PLAN.md 固定同一 1 s 工况的 steps=2/4，初始化每档重做，原 1 步结果只读。每档新 40/100/150/165+5 s 预算来自原已测成本，不改变旧预算/物理接受门。

ROOT/独审冻结通过后，唯一串行入口为：

```sh
/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python -I /private/tmp/arlabosse-equilibrium-transport-v1/time-refinement/run_series.py
```

加 `--dry-run` 只核输入/输出路径，不创建尝试或调用 EOS。入口固定先 2 后 4；前档失败即停止，无重试。启动记录与每档目录独占创建，重新执行拒绝。监督复用原研究进程组 supervisor，仍只清理原进程组；预算/范围局限与 PLAN 一致。

文件分工：

- driver.py 显式适配原 native_driver.py 的接受主体，所有格/账本原门逐项保留；shape 随 steps 改变，输出全部 ledger 和逐步/累计水、Q、H、带符号 Eout、分解残差及两格末态 T/Nc/Nv/P/U。
- run_series.py 从被 pin 的原监督 metadata 复用完整源码/安装栈/来源输入集合，实际开始前逐一比对原 hash；两档各重新冻结和复核输入。任何差异停止，不拿新物性冒充同工况加密。
- compare.py 仅被动读取保存 JSON，先要求三档原接受、完整时刻/格数、相同物理原初与初始化/模型/政策、原冻结源输入；累计取全部动态 ledger，不取最后一面。输出三值、精确相邻差和必要条件分辨诊断。符合预登记必要门时才给描述性比值与名义 p，不给全平衡或时间收敛证书。
- BASELINE.json 固定原 1 步保存证据，不改旧 native01。比较输出 COMPARISON.json；系列状态 SERIES_RESULT.json；各尝试 native-steps2/4 和 supervised-steps2/4。任何原始 RUN/失败/监督结果保留，不自动修复后重跑。

实际非 EOS 检查：PASSIVE_GREEN05.log 为 9 项通过；包括原 1 步完整保存记录回放新 driver 纯接受 AST（不执行 imports/main/物性），全部累计取和、制造正/负名义阶、零差/异向/条件分辨不足禁止阶数、严格 JSON/拒绝覆盖，以及隔离 -I help/参数/重复系列入口。DRY_RUN02.log 实际核 2807 冻结输入通过，未创建新增 native/supervised 目录。AST 解析通过；ruff/mypy/pylint/black 不可用，未安装。

真实失败均保留：PASSIVE_RED01.log 的空 diagnostics 触发 max 单标量错误（3 failed/4 passed）；PASSIVE_GREEN02.log 实际旧 INITIAL provenance 中字符串 rational 被错误解析为整数 wire（1 failed/7 passed）。已有限修复：max 显式列表；只有原 driver 整数形式 Fraction 参与算术解码，来源文字 rational 原样保留。-I 自身目录导入为静态自查修正，没有伪造 RED。

这些是软件/保存数据检查，不是新 EOS、时间趋势或材料验证。固定组成 T 界与名义组成括区均不是全平衡误差充分界；未量化组成传播/对数/材料误差 unknown，资格持续 false。父任务和独审拥有是否开始两档实际尝试的最终冻结。

独审跨档冻结补项：SERIES_STARTED.input_sha256 现在绑定完整新输入集合；每档启动前核键集合与当前各 SHA，最终 compare 同样核当前完整集合，并要求 steps2/4 的监督 inputs_before 与 inputs_after 均等于启动表。两档之间修改计划/脚本、仅在各档内保持不变也被拒绝。BINDING_RED01 为 3 项实际制造反例失败（启动后改 PLAN、第四档快照换 SHA、第四档漏输入）；BINDING_GREEN02 为这 3 项受影响检查通过，包含最终比较当前 PLAN 修改的拒绝。全部仅隔离制造文件，无 EOS；原 9 项未无谓重跑。
