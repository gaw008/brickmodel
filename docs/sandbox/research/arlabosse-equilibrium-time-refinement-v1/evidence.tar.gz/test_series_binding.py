"""Manufactured files/records only: exercise cross-attempt input binding, no EOS."""
from copy import deepcopy
import hashlib
from pathlib import Path
import sys

import pytest

WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(WORK))
import compare as comparison
import run_series


def saved(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    comparison.write_exclusive(path, value)


def fixture(tmp_path, monkeypatch):
    base = tmp_path
    work = base/'time-refinement'
    work.mkdir()
    for module in (run_series, comparison):
        monkeypatch.setattr(module, 'WORK', work)
        monkeypatch.setattr(module, 'BASE', base)
    physics = base/'manufactured-physics.txt'
    physics.write_text('manufactured input, never a physical source')
    sha = hashlib.sha256(physics.read_bytes()).hexdigest()
    baseline = {str(physics): {'sha256': sha, 'bytes': physics.stat().st_size}}
    status = {'status': 'complete', 'returncode': 0, 'inputs_unchanged': True,
              'inputs_after': {str(physics): sha}}
    saved(base/'supervised-native01/metadata.json', {'inputs_before': baseline})
    saved(base/'supervised-native01/status.json', status)
    saved(base/'native01/ACCEPTANCE.json', {'passed': True, 'checks': {'manufactured': True}})
    saved(work/'BASELINE.json', {'sha256': {str(physics): sha}})
    for name in ('PLAN.md', 'driver.py', 'compare.py', 'run_series.py'):
        (work/name).write_text('manufactured harness record '+name)
    paths = run_series.verify_inputs()
    started = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    saved(work/'SERIES_STARTED.json', {'input_sha256': started})
    return base, work, baseline, status, started


def test_changed_harness_after_start_rejected_before_next_attempt(tmp_path, monkeypatch):
    _, work, _, _, _ = fixture(tmp_path, monkeypatch)
    assert run_series.verify_inputs()
    (work/'PLAN.md').write_text('changed after series start')
    with pytest.raises(ValueError, match='series_input_changed'):
        run_series.verify_inputs()
    report = comparison.compare()
    assert report['comparison_available'] is False
    assert report['failures']['series_binding']['reason'].startswith('series_input_changed:')


@pytest.mark.parametrize('change', ['different_snapshot', 'missing_snapshot_member'])
def test_compare_rejects_new_attempt_snapshot_not_bound_to_start(tmp_path, monkeypatch, change):
    base, work, baseline, status, started = fixture(tmp_path, monkeypatch)
    states = [{}, {}]
    initialization = {'status': 'completed', 'states': states,
                      'raw_states': states, 'flash_policies': ['manufactured']}
    for steps in (1, 2, 4):
        folder = base/'native01' if steps == 1 else work/f'native-steps{steps}'
        supervised = base/'supervised-native01' if steps == 1 else work/f'supervised-steps{steps}'
        for name, data in (
            ('INITIAL.json', {'states': states}),
            ('INITIALIZATION.json', initialization),
            ('INPUTS.json', {'steps': steps, 'duration_s': 1, 'flash_policy': 'manufactured'}),
            ('RUN_1.json' if steps == 1 else 'RUN.json', {
                'status': 'completed', 'ledgers': [{}]*steps, 'observations': [{}]*steps,
                'states': [states]*(steps+1), 'times_s': [comparison.F(i, steps) for i in range(steps+1)],
                'model_identity': 'manufactured'})):
            saved(folder/name, data)
        if steps != 1:
            saved(folder/'ACCEPTANCE.json', {'passed': True, 'checks': {'manufactured': True}})
            before = {path: {'sha256': sha, 'bytes': Path(path).stat().st_size} for path, sha in started.items()}
            after = dict(started)
            saved(supervised/'metadata.json', {'inputs_before': before})
            saved(supervised/'status.json', {**status, 'inputs_after': after})
    # This test examines only record admission, not manufactured material acceptance.
    monkeypatch.setattr(comparison, 'extract', lambda run: {
        'values': {'manufactured': 1}, 'diagnostics': {'manufactured': {}},
        'cumulative_auxiliary': {}})
    assert comparison.compare()['comparison_available'] is True
    path = str(work/'PLAN.md')
    metadata_path, status_path = work/'supervised-steps4/metadata.json', work/'supervised-steps4/status.json'
    metadata, altered_status = comparison.read(metadata_path), comparison.read(status_path)
    if change == 'different_snapshot':
        metadata['inputs_before'][path]['sha256'] = '0'*64
        altered_status['inputs_after'][path] = '0'*64
    else:
        del metadata['inputs_before'][path]
        del altered_status['inputs_after'][path]
    # Rewrite only isolated manufactured records; never the real saved attempts.
    metadata_path.unlink(); status_path.unlink()
    saved(metadata_path, metadata); saved(status_path, altered_status)
    result = comparison.compare()
    assert result['comparison_available'] is False
    assert result['primary_comparisons'] == {}
