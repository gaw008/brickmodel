"""Actual two-cell exact result captured by strict codec; no resume claim."""
from pathlib import Path
from dataclasses import fields,is_dataclass,replace
from collections.abc import Mapping
import hashlib,json,time,traceback
from sludge_sandbox.verification_case import read_case,build_case,encode
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.exact_depletion_integration import integrate_exact_depletion
from sludge_sandbox.exact_record import encode_exact_run,read_exact_run,validate_binding,pack
from sludge_sandbox.water_phase_transfer import WaterTransferEvaluation
from sludge_sandbox.deforming_solid_storage import _canonical
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent
out=root/'attempt01';out.mkdir(exist_ok=False)
source=Path('/Users/wanggaoying/Desktop/brickmodel-github/data/sandbox/cases/reacting-wet-free-paired-events-endpoint-root-v1.json')
def save(name,v):(out/name).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def capture(v):
    if type(v) is ExactFreeWaterTransfer:
        return {'schema':'research_exact_operator_reference_v1','identity':encode(v._identity),'modes':list(v.operator.interfaces)}
    if type(v) is WaterTransferEvaluation:
        # Snapshot exactly the numerical observation vectors used by the core,
        # phase diagnostics and Rates. Do not duplicate live current_host trees.
        b=v.base_evaluation
        return {'schema':'research_depletion_observation_v1','rates':encode(v.rates),
          'temperatures_k':[x.mechanical.temperature_k for x in b.storage_states],
          'temperature_errors_k':[x.temperature_error_bound_k for x in b.storage_inverses],
          'pressures_pa':[x.mechanical.pressure_pa for x in b.storage_states],
          'pressure_errors_pa':[x.pressure_error_bound_pa for x in b.storage_states],
          'cell_transfers':encode(v.cell_transfers),'interface_modes':list(v.interface_modes),
          'source_ids':list(v.source_ids),'coefficient_set_id':v.coefficient_set_id,
          'coefficient_version':v.coefficient_version,'coefficient_classification':v.coefficient_classification,
          'dry_policy':v.dry_policy,'qualification':v.qualification}
    if is_dataclass(v):return {f.name:capture(getattr(v,f.name)) for f in fields(v)}
    if isinstance(v,Mapping):return {str(k):capture(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [capture(x) for x in v]
    return encode(v)

started=time.monotonic();before=runtime_identity();save('runtime-before.json',before)
casebytes=source.read_bytes();(out/'case.json').write_bytes(casebytes)
case_sha=hashlib.sha256(casebytes).hexdigest()
report={'capture_status':'started','qualification':'Actual exact two-cell record with water EOS and manufactured solid; not resumed run or material prediction.'}
try:
    built=build_case(read_case(out/'case.json'),Path('/private/tmp/brick-free-native-events-v1/attempt01/water'))
    assert built.start_s==.5 and built.end_s==.50032 and len(built.initial.amounts_mol)==2
    assert built.policy.maximum_steps==512 and built.policy.maximum_wall_seconds==800.
    policy=replace(built.depletion_policy,ordered_event_policy='ordered_affine_packet_v1')
    op=ExactFreeWaterTransfer(built.operator);identity=op.operator_identity
    initial=encode(built.initial);save('initial.json',initial);save('initialization.json',built.initialization)
    save('original-operator-inputs.json',_canonical(built.operator));save('operator-identity.json',encode(identity))
    save('integration-policy.json',encode(built.policy));save('event-policy.json',encode(policy))
    start=ExactEventTime.from_float(built.start_s);end=ExactEventTime.from_float(built.end_s)
    save('times.json',{'start':start.to_record(),'end':end.to_record()})
    core_start=time.monotonic()
    result=integrate_exact_depletion(built.initial,op,start=start,end=end,integration_policy=built.policy,event_policy=policy)
    report.update(core_elapsed_s=time.monotonic()-core_start,core_status=result.status,core_reason=result.reason,accepted_steps=len(result.steps),events=sum(map(len,result.packets)),packets=len(result.packets),costs=encode(result.costs))
    # Preserve complete numerical fallback before new encoding/binding assertions.
    save('core-result.json',capture(result))
    codec_start=time.monotonic()
    raw=encode_exact_run(result,original_operator=op,start=start,end=end,case_sha256=case_sha,runtime_identity=before)
    (out/'exact-run-record.json').write_bytes(raw)
    decoded=read_exact_run(raw)
    checked=validate_binding(decoded,op,case_sha256=case_sha,runtime_identity=before)
    assert checked is not decoded and checked.canonical_bytes==raw
    assert pack(checked.states[-1])==pack(result.states[-1])
    assert checked.result.status==result.status and len(checked.ledgers)==len(result.steps)
    save('codec-verification.json',dict(schema=checked.result.schema,record_sha256=hashlib.sha256(raw).hexdigest(),record_bytes=len(raw),state_count=len(checked.states),ledger_count=len(checked.ledgers),fresh_live_bound_record=True,elapsed_s=time.monotonic()-codec_start,validation_scope=checked.validation_scope))
    assert identity==op.operator_identity and encode(built.initial)==initial
    report['capture_status']='captured'
except BaseException:report.update(capture_status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-after.json',after);assert before==after
        assert source.read_bytes()==casebytes==(out/'case.json').read_bytes()
    except BaseException:report.update(capture_status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_s=time.monotonic()-started,modules=len(before['modules']),case_sha256=case_sha,runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    save('report.json',report)
assert report['capture_status']=='captured',report
