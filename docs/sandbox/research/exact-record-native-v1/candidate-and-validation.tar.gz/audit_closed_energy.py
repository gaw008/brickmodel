"""Independent closed-boundary pressure-work audit of saved accepted prefixes."""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import traceback

ROOT = Path(__file__).parent
D = ROOT / 'attempt01'
ORIGINAL_GATE = F(2e-8)  # 2e-8 J, retained pre-result target.


def q(x):
    assert type(x) in (int, float)
    return F(x)


def main():
    out = {'status': 'failed', 'input_sha256': {}, 'registered_gate_j': str(ORIGINAL_GATE),
           'gate_origin': '/private/tmp/brick-free-native-events-v1/audit.py:203-217; original cells*per-cell E absolute target, retained explicitly by root'}
    def load(name):
        raw = (D / name).read_bytes(); out['input_sha256'][name] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)
    try:
        c = load('case.json'); r = load('core-result.json'); initial = load('initial.json'); p = load('integration-policy.json')
        assert load('runtime-before.json') == load('runtime-after.json')
        transport = c['transport']
        assert transport['outer_reservoir'] is None and transport['outer_surface_temperature_k'] is None
        states, steps = r['states'], r['steps']; nc = c['grid']['cells']
        assert len(states) == len(steps) + 1 and states[0] == initial
        # Exact product of represented reference dimensions, not a rounded volume recomputation.
        cell_reference = q(c['grid']['reference_face_area_m2']) * q(c['grid']['half_thickness_m']) / nc
        pe = q(c['mechanics']['external_pressure_pa'])
        assert nc * q(p['energy_absolute_tolerance_j']) == ORIGINAL_GATE
        def volume(state):
            s = state['mechanical_stretches']; assert len(s) == nc + 1 and all(q(x) > 0 for x in s)
            return cell_reference * sum(map(q, s[:-1]), F()) * q(s[-1])**2
        def energy(state):
            assert len(state['internal_energy_j']) == nc
            return sum(map(q, state['internal_energy_j']), F())
        v0, e0 = volume(initial), energy(initial)
        constraint_absolute = F(); constraint_by_cell = [F()] * nc
        traction = F(); rows = []; maximum = F(); worst = 0
        for index, (step, state) in enumerate(zip(steps, states[1:]), 1):
            assert all(q(x) == 0 for x in step['face_species_mol'][0] + step['face_species_mol'][-1])
            assert q(step['face_energy_j'][0]) == q(step['face_energy_j'][-1]) == 0
            parts = step['cell_work_components_j']
            assert set(parts) == {'body', 'external_traction', 'mechanical_constraint'}
            assert all(q(x) == 0 for x in parts['body'])
            assert all(len(v) == nc for v in parts.values())
            constraint = list(map(q, parts['mechanical_constraint']))
            constraint_absolute += abs(sum(constraint, F()))
            constraint_by_cell = [a + b for a, b in zip(constraint_by_cell, constraint)]
            traction += sum(map(q, parts['external_traction']), F())
            balance = energy(state) - e0 + pe * (volume(state) - v0)
            if abs(balance) > maximum: maximum, worst = abs(balance), index
            rows.append({'state_index': index, 'energy_plus_pressure_volume_j': str(balance),
                         'cumulative_absolute_constraint_sum_j': str(constraint_absolute),
                         'cumulative_external_traction_plus_pressure_volume_j': str(traction + pe * (volume(state) - v0))})
        out.update(prefixes=rows, checked_prefixes=len(rows), maximum_closed_energy_residual_j=str(maximum),
                   maximum_closed_energy_residual_float_j=float(maximum), worst_state_index=worst,
                   cumulative_absolute_constraint_sum_j=str(constraint_absolute),
                   cumulative_absolute_constraint_sum_float_j=float(constraint_absolute),
                   constraint_work_by_cell_j=list(map(str, constraint_by_cell)),
                   reference_total_volume_m3=str(cell_reference * nc),
                   closed_boundaries_verified=True,
                   qualification='All accepted saved prefixes only. Nonlinear external-pressure-work residual includes time quadrature error; not implied by local ledger tolerances, spatial convergence or material validation.')
        assert maximum <= ORIGINAL_GATE, 'original closed energy gate failed'
        assert constraint_absolute <= ORIGINAL_GATE, 'original constraint cancellation gate failed'
        assert any(x != 0 for x in constraint_by_cell), 'fixture constraint coupling inactive'
        out['status'] = 'passed'
    except Exception:
        out['failure'] = traceback.format_exc()
    (D / 'closed-energy-audit.json').write_text(json.dumps(out, indent=2) + '\n')
    assert out['status'] == 'passed', out.get('failure')


if __name__ == '__main__':
    main()
