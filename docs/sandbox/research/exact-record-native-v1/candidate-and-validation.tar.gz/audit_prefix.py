"""Saved exact-packet prefix arithmetic only; standard library, never invokes EOS."""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json
import math
import traceback


def number(x):
    if type(x) not in (int, float) or not math.isfinite(x):
        raise ValueError('finite JSON number required')
    return F(x)


def rational(x):
    assert type(x) is dict and set(x) == {'numerator', 'denominator'}
    n, d = x['numerator'], x['denominator']
    assert type(n) is int and type(d) is int and d > 0
    q = F(n, d)
    assert (q.numerator, q.denominator) == (n, d)
    return q


def clock(x):
    assert type(x) is dict and set(x) == {'seconds'}
    return rational(x['seconds'])


def vector(x, count):
    assert type(x) is list and len(x) == count
    return [number(v) for v in x]


def matrix(x, rows, cols):
    assert type(x) is list and len(x) == rows
    return [vector(v, cols) for v in x]


def encode(x):
    if isinstance(x, F):
        return {'numerator': x.numerator, 'denominator': x.denominator}
    if isinstance(x, dict):
        return {k: encode(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [encode(v) for v in x]
    return x


def audit(folder, report):
    def read(name):
        raw = (folder / name).read_bytes()
        report['input_sha256'][name] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
    r = read('core-result.json'); initial = read('initial.json')
    p = read('integration-policy.json'); ep = read('event-policy.json')
    assert r['schema'] == 'exact_ordered_packet_core_v1'
    assert r['initial_policy'] == p and r['event_policy'] == ep
    assert read('runtime-before.json') == read('runtime-after.json')
    schedule = read('times.json'); read('case.json')
    def declared_time(x):
        assert x['schema'] == 'exact_event_time_v1'
        return rational({k: x[k] for k in ('numerator', 'denominator')})
    times, states, steps = r['times_s'], r['states'], r['steps']
    assert states[0] == initial and len(states) == len(times) == len(steps) + 1
    assert clock(times[0]) == declared_time(schedule['start'])
    assert clock(times[-1]) <= declared_time(schedule['end'])
    report['horizon_reached'] = clock(times[-1]) == declared_time(schedule['end'])
    if r['status'] == 'completed': assert report['horizon_reached']
    nc, ns = len(initial['amounts_mol']), len(initial['amounts_mol'][0])
    n0 = matrix(initial['amounts_mol'], nc, ns)
    e0 = vector(initial['internal_energy_j'], nc)
    s0 = vector(initial['mechanical_stretches'], nc + 1)
    na, ea, sa = map(number, (p['amount_absolute_tolerance_mol'], p['energy_absolute_tolerance_j'], p['stretch_absolute_tolerance']))
    corrections = {}; frame_cells = []; rp = ep['roundoff_policy']
    signed = absolute = phase = F(); events = 0
    prior_time = clock(times[0])
    for packet in r['packets']:
        assert packet
        for frame in packet:
            t = frame['terminal']; ledger = t['terminal_panel']['ledger']
            matches = [i for i, step in enumerate(steps) if step == ledger]
            assert len(matches) == 1 and matches[0] not in corrections
            index = matches[0]; cell = t['root_order']['selected_cell']
            assert type(cell) is int and 0 <= cell < nc and cell not in frame_cells
            frame_cells.append(cell)
            assert clock(ledger['end_s']) > prior_time
            prior_time = clock(ledger['end_s'])
            assert t['status'] == 'speculative_completed'
            assert t['initial_state'] == states[index]
            assert t['corrected_state'] == states[index + 1]
            raw = t['terminal_panel']['raw_state']
            c = t['correction']; corrections[index] = c
            if c is not None:
                assert c['cell_index'] == cell
                li, vi = c['liquid_index'], c['vapor_index']
                assert type(li) is int and type(vi) is int and 0 <= li < ns and 0 <= vi < ns and li != vi
                delta = number(raw['amounts_mol'][cell][li])
                before = number(raw['amounts_mol'][cell][vi])
                after = number(states[index + 1]['amounts_mol'][cell][vi])
                residual = after - before - delta
                assert delta > 0 and number(states[index + 1]['amounts_mol'][cell][li]) == 0
                assert number(c['liquid_before_mol']) == delta and number(c['vapor_before_mol']) == before and number(c['vapor_after_mol']) == after
                assert rational(c['ideal_liquid_increment_mol']) == -delta
                assert rational(c['ideal_vapor_increment_mol']) == delta
                assert rational(c['actual_vapor_increment_mol']) == after - before
                assert rational(c['vapor_storage_roundoff_mol']) == residual
                assert number(float(before + delta)) == after
                assert delta <= number(rp['correction_absolute_mol'])
                assert delta <= number(c['positive_evaporated_mol']) * number(rp['correction_fraction_evaporated'])
                for limit, factor in [('storage_absolute_mol', F(1)), ('element_absolute_mol', F(2)), ('mass_absolute_kg', number(rp['molar_mass_kg_mol']))]:
                    assert abs(residual) * factor <= number(rp[limit])
                expected = json.loads(json.dumps(raw)); expected['amounts_mol'][cell][li] = 0.0; expected['amounts_mol'][cell][vi] = float(after)
                assert expected == states[index + 1]
                signed += residual; absolute += abs(residual); phase += delta; events += 1
            else:
                assert raw == states[index + 1]
            ct = t['candidate_totals']
            assert rational(ct['signed_storage_roundoff_mol']) == signed
            assert rational(ct['absolute_storage_roundoff_mol']) == absolute
            assert rational(ct['numerical_phase_correction_mol']) == phase and ct['events'] == events
    totals = r['roundoff_totals']
    assert totals['policy'] == rp
    assert rational(totals['signed_storage_roundoff_mol']) == signed
    assert rational(totals['absolute_storage_roundoff_mol']) == absolute
    assert rational(totals['numerical_phase_correction_mol']) == phase and totals['events'] == events
    assert phase <= number(rp['cumulative_correction_absolute_mol'])
    for limit, factor in [('cumulative_storage_absolute_mol', F(1)), ('cumulative_element_absolute_mol', F(2)), ('cumulative_mass_absolute_kg', number(rp['molar_mass_kg_mol']))]:
        assert absolute * factor <= number(rp[limit])
    cn = [[F() for _ in range(ns)] for _ in range(nc)]
    ce = [F()] * nc; cs = [F()] * (nc + 1); cx = cs.copy(); cq = cs.copy(); cp = ce.copy()
    maxima = dict.fromkeys(('amount', 'energy', 'stretch_represented', 'stretch_exact', 'stretch_absolute_quadrature', 'component_absolute'), F())
    report.update(prefix_maxima=maxima, accepted_steps=len(steps), accepted_events=len(frame_cells), event_cells=frame_cells, core_status=r['status'], core_reason=r['reason'], expected_initial_wet_cells=nc, all_initial_cells_depleted=len(frame_cells) == nc)
    schema = None
    for i, step in enumerate(steps):
        assert clock(step['start_s']) == clock(times[i]) < clock(step['end_s']) == clock(times[i + 1])
        state = states[i + 1]; before = states[i]
        assert state['energy_model_identity'] == initial['energy_model_identity']
        n = matrix(state['amounts_mol'], nc, ns); e = vector(state['internal_energy_j'], nc); s = vector(state['mechanical_stretches'], nc + 1)
        assert all(v >= 0 for row in n for v in row) and all(v > 0 for v in s)
        fn = matrix(step['face_species_mol'], nc + 1, ns); rn = matrix(step['reaction_species_mol'], nc, ns)
        fe = vector(step['face_energy_j'], nc + 1); work = vector(step['cell_work_j'], nc)
        parts = step['cell_work_components_j']; assert type(parts) is dict
        if schema is None: schema = tuple(parts)
        assert tuple(parts) == schema
        pv = {k: vector(v, nc) for k, v in parts.items()}
        for cell in range(nc):
            for sp in range(ns):
                cn[cell][sp] += fn[cell][sp] - fn[cell + 1][sp] + rn[cell][sp]
                c = corrections.get(i)
                if c is not None and cell == c['cell_index']:
                    if sp == c['liquid_index']: cn[cell][sp] += rational(c['ideal_liquid_increment_mol'])
                    if sp == c['vapor_index']: cn[cell][sp] += rational(c['ideal_vapor_increment_mol']) + rational(c['vapor_storage_roundoff_mol'])
                error = abs(n[cell][sp] - n0[cell][sp] - cn[cell][sp]); maxima['amount'] = max(maxima['amount'], error); assert error <= na
            ce[cell] += fe[cell] - fe[cell + 1] + work[cell]
            error = abs(e[cell] - e0[cell] - ce[cell]); maxima['energy'] = max(maxima['energy'], error); assert error <= ea
            residual = work[cell] - sum((v[cell] for v in pv.values()), F())
            assert rational(step['component_sum_residual_j'][cell]) == residual
            cp[cell] += abs(residual); maxima['component_absolute'] = max(maxima['component_absolute'], cp[cell]); assert cp[cell] <= ea
        inc = vector(step['stretch_increment'], nc + 1)
        assert len(step['stretch_quadrature_roundoff']) == nc + 1
        old = vector(before['mechanical_stretches'], nc + 1)
        for j, represented in enumerate(inc):
            q = rational(step['stretch_quadrature_roundoff'][j]); exact = represented - q
            cs[j] += represented; cx[j] += exact; cq[j] += abs(q)
            re = max(abs(s[j] - old[j] - represented), abs(s[j] - s0[j] - cs[j]))
            ex = max(abs(s[j] - old[j] - exact), abs(s[j] - s0[j] - cx[j]))
            for key, value in [('stretch_represented', re), ('stretch_exact', ex), ('stretch_absolute_quadrature', cq[j])]:
                maxima[key] = max(maxima[key], value); assert value <= sa
    report.update(prefix_pass=True, correction_totals={'signed': signed, 'absolute': absolute, 'phase': phase, 'nonzero_corrections': events}, qualification='Independent saved-prefix arithmetic only; not endpoint EOS/root proof or full material validation.')


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('folder', type=Path); args = parser.parse_args()
    report = {'input_sha256': {}, 'prefix_pass': False}
    try:
        audit(args.folder, report)
    except Exception:
        report['failure'] = traceback.format_exc()
    destination = args.folder / 'independent-prefix-audit.json'
    destination.write_text(json.dumps(encode(report), indent=2, allow_nan=False) + '\n')
    assert report['prefix_pass'], report.get('failure')


if __name__ == '__main__':
    main()
