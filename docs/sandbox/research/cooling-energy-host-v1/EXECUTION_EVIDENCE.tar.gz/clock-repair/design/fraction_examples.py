"""Clock lattice and exact quadrature examples only; never calls integrate."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math


def rk_panel(a, b):
    if not math.isfinite(a) or not math.isfinite(b) or not a < b:
        return None
    step = b-a
    if not math.isfinite(step):
        return None
    m = a+step/2
    left, right = m-a, b-m
    if not (a < m < b and left/2 > 0 and right/2 > 0):
        return None
    return dict(a=a, m=m, b=b, step=step, left=left, right=right)


def shorten_before_commit(a, c, b):
    """Root proposal, only the endpoint decision; no state/rate evaluation."""
    if not a < c < b or rk_panel(c, b) is not None:
        return c, 'unchanged'
    m = a+(b-a)/2
    if a < m < c and rk_panel(a, m) is not None and rk_panel(m, b) is not None:
        return m, 'reanchor_exact_new_endpoint'
    return c, 'no_certified_repartition'


def exact_fine_weights(panel):
    # These are the actual represented four SSPRK2 accepted rate weights.
    return ((F(panel['left']/2), F(panel['a'])),
            (F(panel['left']/2), F(panel['m'])),
            (F(panel['right']/2), F(panel['m'])),
            (F(panel['right']/2), F(panel['b'])))


def integral_linear(panel, p0, p1):
    return sum((weight*(p0+p1*t) for weight,t in exact_fine_weights(panel)), F())


def frac(value):
    q=F(value)
    return {'numerator':str(q.numerator),'denominator':str(q.denominator),'float':float(q)}


def example(a, c, b):
    chosen, action=shorten_before_commit(a,c,b)
    return dict(a=a,c=c,target=b,original_panel=rk_panel(a,c),
        original_tail=rk_panel(c,b),chosen=chosen,action=action,
        first_new_panel=rk_panel(a,chosen),second_new_panel=rk_panel(chosen,b),
        chosen_exact=frac(chosen))


def main():
    prefix_path=Path('/private/tmp/brick-cooling-energy-v1/native01/worker/coarse.json')
    prefix=json.loads(prefix_path.read_text())
    a,c=prefix['result']['times_s'][-2:]
    h=prefix['policy']['maximum_step_s']
    target=.1*3
    nominal=F(.2)+20*F(h)
    assert float(nominal)==c
    assert c==math.nextafter(target,-math.inf)
    old_guard=min(math.ulp(target),32*math.ulp(min(h,target-a)))
    assert target-c > old_guard
    chosen,action=shorten_before_commit(a,c,target)
    assert action=='reanchor_exact_new_endpoint'
    first,second=rk_panel(a,chosen),rk_panel(chosen,target)
    assert first and second and chosen<c
    # In this actual case, endpoint differences are exact (Sterbenz regime).
    assert F(first['left'])+F(first['right'])==F(chosen)-F(a)
    assert F(second['left'])+F(second['right'])==F(target)-F(chosen)
    assert sum((w for w,_ in exact_fine_weights(first)+exact_fine_weights(second)),F())==F(target)-F(a)
    # Constant and linear heat/work channels, including cancelling channels.
    for intercept,slope in ((F(1),F()),(F(),F(1)),(F(2**54),F(-1))):
        actual=integral_linear(first,intercept,slope)+integral_linear(second,intercept,slope)
        reference=intercept*(F(target)-F(a))+slope*(F(target)**2-F(a)**2)/2
        assert actual==reference
    missing=F(2**54)*(F(target)-F(c))
    assert missing==1  # A relabelled old endpoint loses a real 1 J at this rate.
    # No pair of subpanels can turn an intentional adjacent-float knot pair
    # into a resolvable interval; the current knot may not be skipped.
    adjacent=math.nextafter(target,math.inf)
    assert rk_panel(target,adjacent) is None
    assert shorten_before_commit(target,adjacent,adjacent)[0]==adjacent
    # A naive adjacent snap can enlarge a valid nominal panel by 50%.
    large=2.**50
    large_c,large_target=large+.5,large+.75
    assert rk_panel(large,large_c) and rk_panel(large_c,large_target) is None
    assert (large_target-large)/(large_c-large)==1.5
    assert shorten_before_commit(large,large_c,large_target)[1]=='no_certified_repartition'
    # Subnormal RK weights require more than a strict midpoint alone.
    tiny=math.ulp(0.)
    assert rk_panel(0.,2*tiny) is None
    assert rk_panel(0.,4*tiny)
    assert shorten_before_commit(0.,7*tiny,8*tiny)==(4*tiny,'reanchor_exact_new_endpoint')
    assert shorten_before_commit(0.,6*tiny,7*tiny)[1]=='no_certified_repartition'
    # No forcing boundary is crossed; each segment terminates at its own b.
    assert a < chosen < c < target < adjacent
    output=dict(purpose='pure_Fraction_clock_and_quadrature_examples_no_integrate',
        prefix_sha256=hashlib.sha256(prefix_path.read_bytes()).hexdigest(),
        failed_prefix_status=prefix['result']['status'],failed_prefix_reason=prefix['result']['reason'],
        nominal_proposed_clock=frac(nominal),old_tail=frac(F(target)-F(c)),old_guard=frac(old_guard),
        actual_case=example(a,c,target),
        actual_new_durations=[frac(F(chosen)-F(a)),frac(F(target)-F(chosen))],
        lost_heat_if_endpoint_relabelled_j=frac(missing),
        large_time_counterexample=example(large,large_c,large_target),
        subnormal_valid_split=example(0.,7*tiny,8*tiny),
        subnormal_impossible_split=example(0.,6*tiny,7*tiny),
        explicit_adjacent_knots=[target,adjacent],
        checks='all exact assertions passed',time_integrations=0)
    print(json.dumps(output,indent=2,allow_nan=False))


if __name__=='__main__':
    main()
