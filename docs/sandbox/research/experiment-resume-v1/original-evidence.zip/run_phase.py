"""Installed API experiment checkpoint evidence; one explicit phase per process."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import time
import traceback
from typing import Any
from sludge_sandbox.experiments import prepare_experiment, run_experiment, read_experiment, compare_experiment
from sludge_sandbox.run_service import read_run, runtime_identity
from sludge_sandbox.job_supervisor import read_job
from audit_ledgers import audit

HERE = Path('/private/tmp/brick-experiment-resume-v1')
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
EXPERIMENT = HERE/'experiment'


def save(name: str, value: Any) -> None:
    (HERE/name).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def audit_run(label: str, result: dict[str, Any]) -> None:
    integration = result['integration']
    assert len(integration['steps']) > 0, 'nonempty accepted prefix required before oracle'
    path = HERE/(label+'-ledger-input.json')
    save(path.name, {'run': integration, 'initial': integration['states'][0]})
    progress: dict[str, Any] = {}
    try:
        outcome = audit(path, progress)
        assert outcome['accepted_steps'] > 0 and outcome['all_saved_prefixes_pass']
        save(label+'-ledger-audit.json', {'status': 'passed', **outcome})
    except BaseException:
        save(label+'-ledger-audit.json', {'status': 'failed', 'partial': progress, 'traceback': traceback.format_exc()})
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('cancel', 'resume'))
    phase = parser.parse_args().phase
    evidence: dict[str, Any] = {'phase': phase, 'status': 'started', 'material_qualified': False}
    save(phase+'-evidence.json', evidence)
    try:
        before = json.loads((HERE/'installed-before.json').read_text())
        assert runtime_identity() == before['runtime'], 'runtime changed before phase'
        if phase == 'cancel':
            prepared = prepare_experiment(HERE/'spec.json', EXPERIMENT,
                water_directory=ROOT/'data/sandbox/water', evidence_directory=ROOT/'data/sandbox')
            save('preparation.json', prepared)
            began = time.monotonic()
            returned = run_experiment(EXPERIMENT, cancel=lambda: time.monotonic()-began >= 12.0)
        else:
            paused = json.loads((HERE/'cancel-return.json').read_text())
            assert paused['status'] == 'paused' and len(paused['attempts']) == 1
            returned = run_experiment(EXPERIMENT)
        save(phase+'-return.json', returned)
        observed = read_experiment(EXPERIMENT)
        save(phase+'-read.json', observed)
        assert len(returned['candidates']) == 1
        assert returned['charged_wall_seconds'] > 0 and returned['charged_wall_seconds'] <= 120
        attempt = returned['attempts'][-1]
        job_path = EXPERIMENT/attempt['job_artifact']
        job = read_job(job_path)
        result, manifest = read_run(job_path/'run')
        save(phase+'-job.json', job)
        save(phase+'-verified-result.json', result)
        save(phase+'-verified-manifest.json', manifest)
        assert job['child_reaped'] is True
        assert attempt['result_sha256'] == manifest['files']['result.json']
        assert result['case_sha256'] == returned['candidates'][0]['case_sha256']
        assert result['runtime_before'] == result['runtime_after'] == before['runtime']
        steps = result['integration']['steps']
        evidence.update(accepted_steps=len(steps), experiment_status=returned['status'],
            charged_wall_seconds=returned['charged_wall_seconds'], attempts=len(returned['attempts']),
            job_status=job['status'], operation=attempt['operation'],
            result_sha256=manifest['files']['result.json'])
        save(phase+'-evidence.json', evidence)
        if phase == 'cancel':
            assert returned['status'] == 'paused' and returned['candidates'][0]['status'] == 'paused'
            assert len(returned['attempts']) == 1 and attempt['operation'] == 'run'
            assert result['status'] == result['integration']['status'] == 'cancelled'
            assert result['integration']['reason'] == 'cancel_requested'
            assert 0 < len(steps) < 4, 'must actually cancel inside a nonempty accepted prefix'
        else:
            assert returned['status'] == 'completed' and returned['candidates'][0]['status'] == 'completed'
            assert len(returned['attempts']) == 2 and len(returned['invocations']) == 2
            assert attempt['operation'] == 'resume' and attempt['parent_attempt_id'] == returned['attempts'][0]['id']
            assert len(steps) == 4 and result['status'] == result['integration']['status'] == 'completed'
            assert job['status'] == 'completed' and job['returncode'] == 0
            assert returned['charged_wall_seconds'] > paused['charged_wall_seconds']
            first_result = json.loads((HERE/'cancel-verified-result.json').read_text())
            first_manifest = json.loads((HERE/'cancel-verified-manifest.json').read_text())
            prefix = first_result['integration']
            assert result['integration']['states'][:len(prefix['states'])] == prefix['states']
            assert result['integration']['steps'][:len(prefix['steps'])] == prefix['steps']
            assert result['integration']['times_s'][:len(prefix['times_s'])] == prefix['times_s']
            assert result['resume_of']['result_sha256'] == first_manifest['files']['result.json']
            assert result['initial_snapshot'] == first_result['initial_snapshot']
            assert result['integration']['elapsed_seconds'] >= prefix['elapsed_seconds']
            charged_jobs = sum(read_job(EXPERIMENT/a['job_artifact'])['elapsed_wall_seconds'] for a in returned['attempts'])
            assert charged_jobs <= returned['charged_wall_seconds']
            evidence['sum_job_wall_seconds'] = charged_jobs
            comparison = compare_experiment(EXPERIMENT)
            save('comparison.json', comparison)
            assert len(comparison['outcomes']) == 1
            item = comparison['outcomes'][0]
            assert item['outcome'] == 'completed' and item['metrics'] is not None
            assert item['result_sha256'] == manifest['files']['result.json']
        audit_run(phase, result)
        assert runtime_identity() == before['runtime'], 'runtime changed during phase'
        evidence['status'] = 'passed'
    except BaseException as exc:
        evidence.update(status='failed', reason=str(exc), error_type=type(exc).__name__, traceback=traceback.format_exc())
    finally:
        save(phase+'-evidence.json', evidence)
    print(json.dumps(evidence, indent=2), flush=True)
    return 0 if evidence['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
