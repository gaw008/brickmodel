# Installed experiment cancellation and resume evidence

Baseline: `33b5e3c`. One two-cell manufactured coupled case, temporal refinement 1. This is verification of experiment orchestration and saved conservation records; it does not qualify real sludge or a complete brick firing cycle.

- Both native phases ran sequentially through the installed `experiments` API with separate 150 s owned watchdogs. There were no concurrent native calls, retries, source changes, installations or test changes.
- The 12 s cooperative cancellation produced exactly one accepted step at 0.5000038146972656 s. Experiment status was paused, child reaped, and both saved service/integration statuses were cancelled with `cancel_requested`.
- A second call to `run_experiment` selected operation `resume`, preserved the parent attempt/result hash, and completed four total accepted steps. The original accepted states, times and ledger are preserved exactly once; the original initial snapshot remains unchanged.
- Cumulative attempt count is 2 of 4. Charged active orchestration wall is 34.99484341700736 s of 120; sum of actual saved job walls is 34.91846241601161 s. No idle interval was charged and no attempt was refunded.
- Original independent ledger oracle was copied unchanged. Nonempty accepted counts were asserted before invoking it. One-step cancelled prefix and all four final prefixes passed; final maximum local species discrepancy is 1.863788003732313e-16 mol and energy discrepancy 7.023600114458876e-11 J.
- Read-run, experiment comparison, source/runtime/case binding and cumulative accounting checks passed. All 53 actual installed Python modules matched repository sources before and after; preregistered script/input hashes stayed unchanged.

No uninterrupted run was added: the prescribed evidence gates passed without one. No claim of bit-identical adaptive evolution across a restart is made.

## Primary artifacts

`PLAN.json`, `installed-before.json`, `installed-after.json`, `cancel-evidence.json`, `resume-evidence.json`, both watchdog records/logs, both independent ledger inputs/audits, `comparison.json`, and the complete `experiment/` directory retain raw specification, frozen source inputs, state journal, both job bundles and parent checkpoint records.

Final result SHA256: `7cc8459db2461a046b002ca61ae8ba77288be979f6f03d635b33a16b4275a59d`.
