from fractions import Fraction
from pathlib import Path
import hashlib
import json
from sludge_sandbox.experiments import read_experiment, compare_experiment
from sludge_sandbox.run_service import read_run, runtime_identity
from sludge_sandbox.job_supervisor import read_job
from audit_ledgers import audit
root=Path('/private/tmp/brick-experiment-resume-v1')
plan=json.loads((root/'PLAN.json').read_text())
for name,digest in plan['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
state=read_experiment(root/'experiment')
assert state['status']=='completed' and len(state['attempts'])==2
assert len(state['invocations'])==2
assert state['candidates'][0]['attempt_ids']==[a['id'] for a in state['attempts']]
assert [a['operation'] for a in state['attempts']]==['run','resume']
assert state['attempts'][1]['parent_attempt_id']==state['attempts'][0]['id']
assert state['budget']==plan['limits']
jobwall=Fraction()
results=[]
for i,attempt in enumerate(state['attempts']):
    jobpath=root/'experiment'/attempt['job_artifact']
    job=read_job(jobpath)
    assert job['child_reaped'] is True
    assert job['status']==['cancelled','completed'][i]
    assert job['returncode']==[1,0][i]
    assert hashlib.sha256((jobpath/'job.json').read_bytes()).hexdigest()==attempt['job_sha256']
    result,manifest=read_run(jobpath/'run')
    assert manifest['files']['result.json']==attempt['result_sha256']
    assert result['runtime_before']==result['runtime_after']==runtime_identity()
    assert len(result['integration']['steps'])==[1,4][i]
    progress={}
    label=['cancel','resume'][i]
    oracle_input=root/(label+'-ledger-input.json')
    assert json.loads(oracle_input.read_text())['run']==result['integration']
    checked=audit(oracle_input,progress)
    assert checked['accepted_steps']==[1,4][i] and checked['all_saved_prefixes_pass']
    results.append(result)
    jobwall+=Fraction(job['elapsed_wall_seconds'])
charged=Fraction(state['charged_wall_seconds'])
invocationwall=sum((Fraction(i['elapsed_seconds']) for i in state['invocations']),Fraction())
assert jobwall<=invocationwall<=charged<=Fraction(120)
for field in ['states','steps','times_s']:
    prefix=results[0]['integration'][field]
    assert results[1]['integration'][field][:len(prefix)]==prefix
assert results[1]['resume_of']['result_sha256']==state['attempts'][0]['result_sha256']
assert results[1]['initial_snapshot']==results[0]['initial_snapshot']
assert compare_experiment(root/'experiment')==json.loads((root/'comparison.json').read_text())
summary={'status':'passed','jobs_reaped':2,'accepted_steps':[1,4],
         'charged_wall_seconds':float(charged),'independent_ledger_prefixes_checked':5,
         'preregistered_hashes_unchanged':True,'current_runtime_matches':True,
         'root_verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root/'root-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
