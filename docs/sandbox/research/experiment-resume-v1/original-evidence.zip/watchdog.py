"""Own one orchestration child, never infer a lost child from a saved PID."""
from __future__ import annotations
import json
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

HERE = Path('/private/tmp/brick-experiment-resume-v1')
PYTHON = '/private/tmp/brick-water-backend-probe/venv/bin/python'


def main() -> int:
    phase = sys.argv[1]
    assert phase in ('cancel', 'resume')
    began = time.monotonic()
    record = {'phase': phase, 'status': 'started', 'external_wall_seconds': 150, 'returncode': None}
    path = HERE/(phase+'-watchdog.json')
    path.write_text(json.dumps(record, indent=2))
    process = None
    try:
        with (HERE/(phase+'.stdout')).open('wb') as stdout, (HERE/(phase+'.stderr')).open('wb') as stderr:
            process = subprocess.Popen([PYTHON, str(HERE/'run_phase.py'), phase],
                cwd=HERE, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL)
            record['owned_pid'] = process.pid
            path.write_text(json.dumps(record, indent=2))
            try:
                code = process.wait(timeout=150)
                record.update(status='complete' if code == 0 else 'failed', returncode=code)
            except subprocess.TimeoutExpired:
                process.send_signal(signal.SIGINT)
                try:
                    process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                record.update(status='timeout', returncode=process.returncode,
                    limitation='No automatic retry; inspect retained child/lock evidence before any later native work.')
    except BaseException as exc:
        record.update(status='failed', reason=str(exc), traceback=traceback.format_exc())
        if process is not None and process.poll() is None:
            process.send_signal(signal.SIGINT)
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
    finally:
        record['elapsed_seconds'] = time.monotonic()-began
        path.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2), flush=True)
    return 0 if record['status'] == 'complete' else 1


if __name__ == '__main__':
    raise SystemExit(main())
