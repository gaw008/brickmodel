# Independent bounded host-profiler review

APPROVE final run.py SHA256 222434f2852a4657b51fc702df91adf7508504c01238cae32a863686be1e682d and PERFORMANCE_PLAN.md for the stated measurement scope. Read-only; no EOS, script execution or source edits.

The runner verifies the sealed replay input and exact case identity, binds all physical module bytes to that saved run, and permits only run_service.py to differ while requiring its exact committed 87b5f78 bytes. Python/platform/dependency/catalog identity must match. Final read_run plus original manifest/result SHA equality and runtime equality protect the selected input and source throughout the attempt. The added final SHA comparisons resolve the initial gap where a newly valid but replaced seal could have passed read_run alone.

It builds the actual original case once, selects saved accepted state index 1 and its actual time, checks interior clock, positive liquid in every cell, model energy identity and host state admissibility. It does not create an easier manufactured perturbation. It performs at most two explicit FreeSolidSlab.evaluate calls after construction; construction may itself perform normal initialization work and is timed separately. The loop's second call is skipped when measured remaining budget is insufficient. Root's external 40-second watchdog remains the actual hard limit; the script neither guarantees interruption of a native call nor automatically retries.

The selected fields match the real FreeSolidSlabEvaluation and inverse dataclasses and require no additional EOS calls. Call 1 is cProfile-instrumented; wall/CPU measurements are captured before profiling serialization. Binary profile, full tables/caller data and actual selected numerical outputs are saved before any two-call parity assertion. Profile-output and selected-output save durations are separately recorded. Optional call 2 repeats exactly the same state/time without profiling and compares selected outputs exactly. Exception paths retain status/traceback and partial timing/profile artifacts when possible; an external hard kill may still leave incomplete evidence as the plan states.

The plan correctly treats profiler overhead and warm repeated-state effects as confounded, does not sum overlapping cumulative timings as disjoint costs, and limits attribution to host evaluation rather than the full phase-transfer/event runtime. No physical inputs, tolerances, source guards, event gates or uncertainty contracts are changed. Any optimization requires new implementation identity and separate parity/invalidation verification.

No blocking issue found in the final runner. This approval authorizes interpretation as a bounded diagnostic measurement, not a measured speedup, complete bottleneck attribution, native result success or material qualification.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 unresolved | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE final bounded measurement runner.
