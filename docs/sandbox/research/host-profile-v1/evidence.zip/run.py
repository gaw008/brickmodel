"""Root-supervised 40-second process; at most two host evaluations."""
from __future__ import annotations
import argparse
import cProfile
import hashlib
import io
import json
from pathlib import Path
import pstats
import subprocess
import sys
import time
import traceback
from typing import Any

SOURCE=Path('/private/tmp/brick-paired-service-lifecycle-v1/replay')
REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')


def save(path: Path, value: Any) -> None:
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
    temporary.replace(path)


def selected(value: Any, encode: Any) -> dict:
    return {'rates':encode(value.rates),'geometry':encode(value.geometry),'free':encode(value.free),
        'inverses':[{'target':encode(inv.target),'thermal_state':encode(inv.state.thermal_state),
            'skeleton_state':encode(inv.state.skeleton_state),'total_energy_j':inv.state.total_energy_j,
            'energy_error_bound_j':inv.state.energy_error_bound_j,
            'total_energy_residual_j':inv.total_energy_residual_j,
            'subtraction_roundoff_j':inv.subtraction_roundoff_j,
            'temperature_error_bound_k':inv.temperature_error_bound_k} for inv in value.total_inverses]}


def profile_files(profiler: cProfile.Profile, output: Path) -> None:
    profiler.dump_stats(str(output/'call1.prof'))
    stream=io.StringIO();stats=pstats.Stats(profiler,stream=stream)
    stats.sort_stats('cumulative').print_stats()
    (output/'pstats-full.txt').write_text(stream.getvalue())
    rows=[]
    for key, (primitive,total,self_seconds,cumulative,callers) in stats.stats.items():
        rows.append({'function':list(key),'primitive_calls':primitive,'calls':total,
            'self_seconds':self_seconds,'cumulative_seconds':cumulative,
            'callers':[{'function':list(caller),'values':values} for caller,values in callers.items()]})
    save(output/'pstats-full.json',rows)


def main() -> int:
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    start=time.perf_counter();report={'status':'started','calls':[], 'external_wall_limit_seconds':40,
        'input_run':str(SOURCE),'accepted_state_index':1,'executable':sys.executable,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'qualification':'Profile of unchanged manufactured host; no speedup/material/long-time accuracy claim.'}
    save(args.output/'result.json',report);code=1
    try:
        from sludge_sandbox.run_service import read_run,runtime_identity
        from sludge_sandbox.verification_case import read_case,build_case,encode
        from sludge_sandbox.event_record import state
        from sludge_sandbox.free_solid_slab import FreeSolidSlab
        saved,manifest=read_run(SOURCE)
        current=runtime_identity();report['runtime_before']=current
        report['saved_runtime']=saved['runtime_before']
        report['manifest_sha256']=hashlib.sha256((SOURCE/'manifest.json').read_bytes()).hexdigest()
        report['result_sha256']=hashlib.sha256((SOURCE/'result.json').read_bytes()).hexdigest()
        case=read_case(SOURCE/'case.json')
        assert case.sha256==saved['case_sha256']==manifest['files']['case.json']
        assert saved['runtime_before']==saved['runtime_after']
        old=saved['runtime_before']
        differences={k:{'saved':old['modules'].get(k),'current':current['modules'].get(k)}
            for k in set(old['modules'])|set(current['modules']) if old['modules'].get(k)!=current['modules'].get(k)}
        report['module_differences']=differences
        # The one permitted query-only change is bound to actual committed bytes,
        # not merely a filename exception.
        approved=subprocess.run(['git','show','87b5f78:src/sludge_sandbox/run_service.py'],cwd=REPO,
            check=True,capture_output=True).stdout
        report['approved_run_service_sha256']=hashlib.sha256(approved).hexdigest()
        save(args.output/'result.json',report)
        assert set(differences)<= {'run_service.py'}
        assert current['modules']['run_service.py']==report['approved_run_service_sha256']
        assert all(current[key]==old[key] for key in ('versions','python','platform','catalogs'))
        build_start=time.perf_counter();built=build_case(case,SOURCE/'water')
        report['build_seconds']=time.perf_counter()-build_start
        host=built.operator.base_model;assert type(host) is FreeSolidSlab
        integration=saved['integration'];actual=state(integration['states'][1]);at=integration['times_s'][1]
        assert integration['times_s'][0]<at<integration['times_s'][-1]
        assert actual.energy_model_identity==built.initial.energy_model_identity
        liquid=host.inventory_layout.liquid_index
        assert all(row[liquid]>0 for row in actual.amounts_mol)
        host._check_state(actual)
        report['state']=encode(actual);report['time_s']=at
        report['floathex']={'time_s':float(at).hex(),
            'amounts_mol':[[float(v).hex() for v in row] for row in actual.amounts_mol],
            'internal_energy_j':[float(v).hex() for v in actual.internal_energy_j],
            'mechanical_stretches':[float(v).hex() for v in actual.mechanical_stretches]}
        save(args.output/'result.json',report)
        outputs=[]
        for index in range(2):
            # Keep the second call optional; reserve at least ten seconds and
            # twice the measured first-call duration. External watchdog is final.
            if index and 40-(time.perf_counter()-start)<max(10.,2*report['calls'][0]['wall_seconds']):
                report['second_call']='skipped_remaining_wall_budget';break
            call={'index':index+1,'status':'started','profiled':index==0}
            report['calls'].append(call);save(args.output/'result.json',report)
            wall=time.perf_counter();cpu=time.process_time();prof=cProfile.Profile() if index==0 else None
            try:
                result=prof.runcall(host.evaluate,actual,at) if prof else host.evaluate(actual,at)
            finally:
                call.update(wall_seconds=time.perf_counter()-wall,cpu_seconds=time.process_time()-cpu)
                if prof:
                    write_start=time.perf_counter();profile_files(prof,args.output)
                    call['profile_output_seconds']=time.perf_counter()-write_start
                save(args.output/'result.json',report)
            write_start=time.perf_counter()
            output=selected(result,encode);save(args.output/f'call{index+1}-output.json',output)
            call['selected_output_seconds']=time.perf_counter()-write_start
            outputs.append(output);call['status']='returned_and_saved';save(args.output/'result.json',report)
        if len(outputs)==2:
            report['selected_outputs_exact_equal']=outputs[0]==outputs[1]
            save(args.output/'result.json',report)
            assert report['selected_outputs_exact_equal']
        report['status']='completed';code=0
    except BaseException as exc:
        report.update(status='failed',exception_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
    finally:
        try:
            from sludge_sandbox.run_service import runtime_identity,read_run
            report['runtime_after']=runtime_identity()
            read_run(SOURCE)
            assert hashlib.sha256((SOURCE/'manifest.json').read_bytes()).hexdigest()==report['manifest_sha256']
            assert hashlib.sha256((SOURCE/'result.json').read_bytes()).hexdigest()==report['result_sha256']
            assert report.get('runtime_before')==report['runtime_after']
        except BaseException:
            report['final_integrity_error']=traceback.format_exc();report['status']='failed';code=1
        report['elapsed_seconds']=time.perf_counter()-start
        save(args.output/'result.json',report)
    return code


if __name__=='__main__':raise SystemExit(main())
