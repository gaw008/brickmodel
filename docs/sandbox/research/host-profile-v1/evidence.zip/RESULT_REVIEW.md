# Independent actual host-profile result review

APPROVE the bounded measurement interpretation. Read actual process.json, attempt01/result.json, pstats-full.json and both selected output files after root confirmed termination. No EOS, profile rerun or numerical tests.

The actual process exited 0 without timeout after 3.357077625 seconds. Original construction took 1.340282916 seconds. Two explicit host calls returned and were saved: profiled call 1 wall 0.887658791 s / CPU 0.884100 s; unprofiled call 2 wall 0.805863666 s / CPU 0.802701 s. Profile export and selected JSON output durations are separately recorded. Both selected output files are byte-identical, covering rates, geometry, free closure and the specified full inverse thermal/skeleton/energy diagnostics.

Direct saved-data checks confirm the selected state and time exactly match sealed replay accepted state index 1 at 0.50006103515625. Input manifest/result SHA and script SHA match current retained bytes; runtime-before equals runtime-after. The sole disclosed historical module change is run_service.py, matching its separately approved committed bytes. This was the reviewed same-state measurement, not a new easier trajectory.

The actual call table contains one profiled FreeSolidSlab.evaluate, two current total-energy inverses, eight forward solid/fluid storage evaluations, 320 rigid pressure trial calls, 320 water wrapper state_tp calls plus eight response calls, and 328 underlying kernel state_tp calls. The _transaction row has 656 generator resumptions/entries and 0.711207984 s self / 0.751092569 s cumulative time. That count must not be misrepresented as 656 independent TP solves. Its self attribution does not resolve native C internals, lock/context work or other work hidden from cProfile; these cannot be separated from this table alone.

Nested cumulative timings overlap: e.g. total-energy inverse, thermal inverse, pressure trial and kernel transaction are not disjoint costs to sum. The nine _digest calls account for 0.004169419 s cumulative in this sample, while _canonical recurses 2,217 times with 0.0033195 s cumulative nested within related operations. The evidence does not support attributing the dominant cost to hashing here. It supports investigating the pressure-trial/TP path with its actual guards and solver behavior intact.

The approximately 0.082-second difference between the first and second host calls is confounded by profiling overhead and call-history/warm effects. Two sequential calls cannot establish a speedup or isolate either effect. Host-only measurement excludes the water phase-transfer and paired-event comparison work and cannot account for the entire previous 348-second event runtime. It neither admits real brick/sludge properties nor establishes long-time or spatial accuracy. No optimization claim follows from this result alone.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE actual bounded host-profile evidence with the stated attribution limits.
