from dataclasses import replace
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from pathlib import Path
import pytest
from interval_eos import Interval
from liquid_pressure_consumer import (
    PressureProofError,LiquidBranchModelPolicy,ProofBudget,QueryBoxes,
    BoundLiquidPressureRequest,connected_tube_density,pressure_radius_checked,
    encoded,ProofOperation,COEFFICIENT_SHA,
)


def iv(a,b):return Interval(D(a),D(b))


def proposals():
    return QueryBoxes(iv('55000','56000'),iv('54000','56001'),(iv('10','11'),iv('-4','-3')),
                      (D('10.5'),D('-3.5')),((D(1),D(0)),(D(0),D(1))),(D(1),D(1)))


def test_tube_must_include_full_native_box_even_if_mechanical_narrower():
    box=connected_tube_density(iv(50000,51000),iv(55000,56000),iv(54000,56001),iv(55500,55500))
    assert box==iv(50000,56001)
    # The function constructs only a proposal. Positivity must be proved on
    # this entire interval by the actual pinned tube routine at evaluation.
    with pytest.raises(PressureProofError,match='actual_native_density'):
        connected_tube_density(iv(50000,51000),iv(55000,56000),iv(54000,56001),iv(56002,56002))
    with pytest.raises(PressureProofError,match='coexistence_below'):
        connected_tube_density(iv(55000,55100),iv(55000,56000),iv(54000,56001),iv(55500,55500))


def test_original_ambiguity_strict_and_radius_exact_at_low_decimal_precision():
    with localcontext() as ctx:
        ctx.prec=6
        got=pressure_radius_checked(100000.,iv('99999.123456789','100001.987654321'),.125,
                                    iv(10000,1000000),(F(10000),F(1000000)),iv(3000,3001))
    assert got==F('1.987654321')+F(.125)
    boundary=F(10000)+F(.01)
    # Finite exact Decimal construction avoids silently testing a rounded face.
    with localcontext() as ctx:
        ctx.prec=100
        edge=D(boundary.numerator)/D(boundary.denominator)
    with pytest.raises(PressureProofError,match='ambiguity'):
        pressure_radius_checked(11000.,Interval(edge,D(12000)),0.,iv(10000,1000000),
                                (F(10000),F(1000000)),iv(10000,10000))


def test_full_pressure_interval_cannot_be_clipped_to_nominal_domain():
    with pytest.raises(PressureProofError,match='full_pressure_interval'):
        pressure_radius_checked(100000.,iv(9999,100001),.1,iv(10000,1000000),
                                (F(10000),F(1000000)),iv(3000,3001))


@pytest.mark.parametrize('changes',[{'maximum_proof_operations':True},{'maximum_boxes_per_primitive':3},
    {'maximum_wall_seconds':float('nan')},{'precision':True}])
def test_invalid_resources(changes):
    args=dict(maximum_proof_operations=4,maximum_boxes_per_primitive=256,maximum_wall_seconds=15.,precision=60)
    args.update(changes)
    with pytest.raises(PressureProofError):ProofBudget(**args)


def test_mutable_or_boolean_proposals_rejected():
    q=proposals()
    with pytest.raises(PressureProofError):replace(q,weights=[D(1),D(1)])
    with pytest.raises(PressureProofError):replace(q,preconditioner=((True,D(0)),(D(0),D(1))))
    with pytest.raises(PressureProofError):replace(q,center=(D('NaN'),D(0)))


def test_exact_evidence_bytes_and_unknown_cost_are_preserved():
    raw=encoded(ProofOperation('attempt','failed',.1,b'raw before failure','no root'))
    assert b'bytes_hex' in raw and b'726177206265666f7265206661696c757265' in raw


def test_generic_analytic_liquid_not_mislabelled_HEOS_query(monkeypatch):
    from test_mass_wet_exact_stage import setup
    pair,states=setup(monkeypatch)
    rate=pair.evaluate(states).cells[0]
    with pytest.raises(PressureProofError,match='explicit_HEOS'):
        BoundLiquidPressureRequest.capture(pair,states,rate,0)
    with pytest.raises(PressureProofError,match='cell_index'):
        BoundLiquidPressureRequest.capture(pair,states,rate,False)


def test_policy_source_bytes_checked_before_mathematics(tmp_path):
    pdf=tmp_path/'official.pdf';pdf.write_bytes(b'wrong')
    source=tmp_path/'water.json';source.write_bytes(b'wrong')
    with pytest.raises(PressureProofError,match='pinned_sources'):
        LiquidBranchModelPolicy(str(pdf),str(source),'a'*64)
    with pytest.raises(PressureProofError,match='limited_ordinary'):
        LiquidBranchModelPolicy(str(pdf),str(source),'a'*64,temperature_domain_k=(F(270),F(310)))


def test_original_inverse_epsilon_and_full_domain_not_nominal_only():
    from liquid_pressure_consumer import inverse_temperature_interval
    args=dict(returned_temperature=300.,total_energy=1.,target_energy=0.,energy_error=.5,
              minimum_cp=10.,epsilon=.2,energy_tolerance=2.,temperature_tolerance=.3,
              domains=((295.,310.),(299.,301.)),precision=60)
    actual,required=inverse_temperature_interval(**args)
    assert required==F(3,20)
    assert F(actual.lo)<=F(300)-F(.2) and F(actual.hi)>=F(300)+F(.2)
    for changed in ({'epsilon':.1},{'domains':((299.9,300.1),)}, {'minimum_cp':False}, {'energy_error':-.1}):
        with pytest.raises(PressureProofError):inverse_temperature_interval(**(args|changed))


def test_inverse_exact_residual_cannot_round_oversized_error_to_gate():
    from liquid_pressure_consumer import inverse_temperature_interval
    with pytest.raises(PressureProofError,match='original_inverse_energy'):
        inverse_temperature_interval(returned_temperature=300.,total_energy=1.,target_energy=-2.**-54,
            energy_error=0.,minimum_cp=1.,epsilon=2.,energy_tolerance=1.,temperature_tolerance=3.,
            domains=((295.,310.),),precision=60)
