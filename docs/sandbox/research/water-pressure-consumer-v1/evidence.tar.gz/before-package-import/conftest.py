from pathlib import Path
import sys
BASE=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(BASE),str(BASE/'coexistence_candidate'),str(BASE/'density_tube_candidate'),str(BASE/'native_output_candidate'),str(Path.cwd()/'tests'/'sandbox')]
