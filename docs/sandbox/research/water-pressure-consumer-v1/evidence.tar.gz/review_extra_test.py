"""Isolated late-stage failure bookkeeping, never a physical proof PASS."""
from dataclasses import dataclass
import pytest
from test_mass_wet_pressure_interval import control_flow_only,proposals,iv
from sludge_sandbox.mass_wet_pressure_interval import ProofBudget

@dataclass(frozen=True)
class Domain:
    density: tuple

@dataclass(frozen=True)
class Coexistence:
    proved: bool
    pressure: object
    domain: Domain

@dataclass(frozen=True)
class Mechanical:
    pressure: object

@dataclass(frozen=True)
class Tube:
    proved: bool
    temperature: object
    density: object

@pytest.mark.parametrize('budget',[3,4])
def test_late_failure_preserves_all_prior_operation_evidence(control_flow_only,monkeypatch,budget):
    mod,policy,request,_,_=control_flow_only
    monkeypatch.setattr(mod.coex,'enclose_coexistence',lambda *a,**k:Coexistence(True,iv(3000,3001),Domain((iv(50000,51000),iv(1,2)))))
    monkeypatch.setattr(mod.coupled,'enclose_local_root',lambda *a,**k:Mechanical(iv(99999,100001)))
    observed=[]
    def tube(source,sha,t,rho,**kwargs):
        observed.append(rho)
        return Tube(True,t,rho)
    monkeypatch.setattr(mod.tube,'prove_density_tube',tube)
    def fail(*a,**k):raise ValueError('independent_fourth_operation_failure')
    monkeypatch.setattr(mod.native,'analyze',fail)
    result=mod.IAPWS95LiquidPressureProvider().evaluate(request,branch_policy=policy,boxes=proposals(),budget=ProofBudget(budget,8,5.))
    assert observed==[iv(50000,56001)]
    assert result.status=='unresolved' and result.pressure_radius_pa is None
    assert result.attempted_proof_operations==budget and result.completed_proof_operations==3
    assert len(result.operations)==budget
    assert all(op.status=='completed' and op.evidence_json for op in result.operations[:3])
    assert ('proof_operation_budget_exhausted' if budget==3 else 'independent_fourth_operation_failure') in result.reason
    assert result.native_calls==0 and result.bottom_level_residual_evaluation_count is None

def test_parameters_failure_keeps_captured_original_bytes(control_flow_only,monkeypatch):
    mod,policy,request,_,_=control_flow_only
    object.__setattr__(request,'captured_query_json',b'original query snapshot')
    object.__setattr__(request,'captured_source_json',b'original source snapshot')
    def fail(*a):raise ValueError('parameter_adaptation_failure')
    monkeypatch.setattr(mod,'parameters',fail)
    result=mod.IAPWS95LiquidPressureProvider().evaluate(request,branch_policy=policy,boxes=proposals(),budget=ProofBudget(4,8,5.))
    assert result.status=='unresolved' and result.pressure_radius_pa is None
    assert result.original_query_json==b'original query snapshot'
    assert result.original_source_json==b'original source snapshot'
    assert not result.operations and result.attempted_proof_operations==0

def test_changed_request_does_not_replace_original_failure_evidence(control_flow_only,monkeypatch):
    mod,policy,request,_,_=control_flow_only
    object.__setattr__(request,'captured_query_json',b'original query')
    object.__setattr__(request,'captured_source_json',b'original source')
    original_id=request.numeric_identity
    def changed(*a,**k):
        object.__setattr__(request,'captured_query_json',b'changed query')
        object.__setattr__(request,'captured_source_json',b'changed source')
        object.__setattr__(request,'numeric_identity','d'*64)
        return None
    monkeypatch.setattr(mod.coex,'enclose_coexistence',changed)
    result=mod.IAPWS95LiquidPressureProvider().evaluate(request,branch_policy=policy,boxes=proposals(),budget=ProofBudget(4,8,5.))
    assert result.status=='unresolved' and result.pressure_radius_pa is None
    assert result.original_query_json==b'original query'
    assert result.original_source_json==b'original source'
    assert result.request_sha256==original_id
