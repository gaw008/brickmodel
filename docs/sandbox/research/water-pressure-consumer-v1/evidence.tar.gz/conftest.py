from pathlib import Path
import sys
import sludge_sandbox
HERE=Path(__file__).resolve().parent
sludge_sandbox.__path__[:0]=[str(HERE),str(HERE.parent/'packaged_primitives'/'src'/'sludge_sandbox')]
sys.path.insert(0,str(Path.cwd()/'tests'/'sandbox'))
