"""No-EOS comparison of two previously completed preregistered wet paths."""
from __future__ import annotations
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main() -> int:
    paths = [json.loads((HERE/f'depletion-result-{i}.json').read_text()) for i in (0, 1)]
    assert all(path['status'] == 'passed' for path in paths)
    assert paths[0]['initial'] == paths[1]['initial']
    states = [path['run']['states'][-1] for path in paths]
    differences = {
        'amount_mol': max(abs(a-b) for a, b in zip(states[0]['amounts_mol'][0], states[1]['amounts_mol'][0], strict=True)),
        'energy_j': abs(states[0]['internal_energy_j'][0]-states[1]['internal_energy_j'][0]),
        'temperature_k': abs(paths[0]['final_temperature_k']-paths[1]['final_temperature_k']),
        'pressure_pa': abs(paths[0]['final_pressure_pa']-paths[1]['final_pressure_pa']),
        'event_time_s': abs(paths[0]['run']['events'][0]['time_s']-paths[1]['run']['events'][0]['time_s'])}
    limits = {'amount_mol': 1e-10, 'energy_j': 1e-6, 'temperature_k': 1e-5, 'pressure_pa': 1., 'event_time_s': 1e-7}
    passed = all(differences[key] <= limits[key] for key in limits)
    result = {'status': 'passed' if passed else 'failed', 'differences': differences, 'limits': limits,
              'qualification': 'two-step-cap convergence indicator, no independent wet temperature oracle'}
    (HERE/'comparison-result.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
