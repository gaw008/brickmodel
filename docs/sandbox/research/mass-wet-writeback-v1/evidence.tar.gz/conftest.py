from pathlib import Path
import sludge_sandbox
sludge_sandbox.__path__.append(str(Path(__file__).parent))
