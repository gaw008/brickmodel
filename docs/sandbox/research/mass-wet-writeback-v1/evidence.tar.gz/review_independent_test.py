"""Independent data-only numerical review; no provider or EOS calls."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_mass_wet_writeback import setup
from sludge_sandbox.mass_wet_writeback import project_mixed_depletion, MixedWritebackTotals
from sludge_sandbox.depletion_roundoff import DepletionRoundoffTotals, DepletionRoundoffError
from sludge_sandbox.exact_event_clock import ExactEventTime


def test_exact_water_mass_elements_and_unchanged_solid_energy():
    evidence,context,totals=setup()
    out=project_mixed_depletion(evidence,context=context,totals=totals)
    before=evidence.raw_states[0];after=out.states[0]
    water_error=F(after.liquid_water_mol)+F(after.gas_amounts_mol[2])-F(before.liquid_water_mol)-F(before.gas_amounts_mol[2])
    assert water_error==out.record.vapor_storage_roundoff_mol
    mass_error=water_error*F(context.water_molar_mass_kg_mol)
    assert abs(mass_error)<=F(context.policy.mass_absolute_kg)
    # Nominal water elemental mass partition only; no sludge molar mass.
    hydrogen=mass_error*F(672,6005);oxygen=mass_error*F(5333,6005)
    assert hydrogen+oxygen==mass_error
    assert abs(hydrogen)<=abs(mass_error) and abs(oxygen)<=abs(mass_error)
    assert after.solid_mass_kg==before.solid_mass_kg
    assert after.internal_energy_j==before.internal_energy_j
    assert out.states[1] is evidence.raw_states[1]


def test_sum_of_cells_cannot_escape_global_correction_budget():
    e,c,t=setup();single=project_mixed_depletion(e,context=c,totals=t)
    delta=single.record.ideal_vapor_increment_mol
    p=replace(c.policy,cumulative_correction_absolute_mol=float(delta*F(3,2)))
    # Re-localize only with the same scientific correction/clock limits.
    e=replace(e,clock=replace(e.clock,policy=p));c=replace(c,policy=p)
    prior=DepletionRoundoffTotals(p,F(),F(),delta,1)
    supplied=MixedWritebackTotals(c,(DepletionRoundoffTotals(p),prior))
    assert supplied.per_cell[0].numerical_phase_correction_mol==0
    with pytest.raises(DepletionRoundoffError,match='cumulative_phase_correction_budget'):
        project_mixed_depletion(e,context=c,totals=supplied)
    assert supplied.aggregate.numerical_phase_correction_mol==delta
    assert e.raw_states[0].liquid_water_mol>0


def test_exact_origin_translation_preserves_projection_and_budget():
    e,c,t=setup();baseline=project_mixed_depletion(e,context=c,totals=t)
    shift=F(10**12)
    time=lambda x:ExactEventTime(x.seconds+shift)
    samples=replace(e.clock.samples,start=time(e.clock.samples.start),midpoint=time(e.clock.samples.midpoint),upper=time(e.clock.samples.upper))
    clock=replace(e.clock,samples=samples,lower=time(e.clock.lower),upper=time(e.clock.upper))
    e=replace(e,clock=clock);c=replace(c,original_time=time(c.original_time))
    result=project_mixed_depletion(e,context=c,totals=MixedWritebackTotals.empty(c))
    assert float(clock.lower.seconds)==float(clock.upper.seconds)
    assert result.states==baseline.states
    assert result.totals.aggregate==baseline.totals.aggregate
    assert result.record.gross_positive_evaporation_exact_mol==baseline.record.gross_positive_evaporation_exact_mol
    assert result.record.clock_inventory_residual_mol==baseline.record.clock_inventory_residual_mol
