from pathlib import Path
import json,time
from sludge_sandbox.verification_case import read_case,build_case,snapshot
from sludge_sandbox.event_record import state
from sludge_sandbox.run_service import runtime_identity
r=Path('/private/tmp/brick-free-native-events-v1');old=json.loads((r/'attempt01/result.json').read_text());start=time.monotonic()
assert runtime_identity()==old['runtime_before']==old['runtime_after']
b=build_case(read_case(r/'case.json'),r/'attempt01/water');x=old['integration']
s=snapshot(b,state(x['states'][-1]),x['times_s'][-1])
(r/'accepted-point-snapshot.json').write_text(json.dumps(s,indent=2,allow_nan=False)+'\n')
rows=[]
for c in s['cells']:
 t=c['thermal'];f=t['fluid_state'];m=t['mechanical'];rows.append({'temperature_k':m['temperature_k'],'pressure_pa':m['pressure_pa'],'liquid_mol':m['liquid_inventory_mol'],'volume_error_bound_m3':t['volume_error_bound_m3'],'combined_pressure_error_pa':t['pressure_error_bound_pa'],'fluid_pressure_error_pa':f['pressure_error_bound_pa'],'combined_minus_fluid_pa':t['pressure_error_bound_pa']-f['pressure_error_bound_pa'],'volume_residual_m3':m['volume_residual_m3'],'volume_resolution_m3':m['volume_resolution_m3']})
assert runtime_identity()==old['runtime_before']
(r/'point-components.json').write_text(json.dumps({'elapsed_seconds':time.monotonic()-start,'rows':rows,'qualification':'Actual same-installed-model diagnostic at last accepted wet state, not rejected event state and not independent validation.'},indent=2)+'\n');print((r/'point-components.json').read_text())
