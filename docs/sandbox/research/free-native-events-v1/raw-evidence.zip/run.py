from pathlib import Path
import json,time
from sludge_sandbox.run_service import run_case,runtime_identity
r=Path('/private/tmp/brick-free-native-events-v1');root=Path('/Users/wanggaoying/Desktop/brickmodel-github');started=time.monotonic();calls=0
(r/'runtime-before.json').write_text(json.dumps(runtime_identity(),indent=2)+'\n')
def observe():
 global calls
 calls+=1
 if calls%50==0:
  tmp=r/'progress.tmp';tmp.write_text(json.dumps({'guard_calls':calls,'elapsed_seconds':time.monotonic()-started}));tmp.replace(r/'progress.json')
 return False
result=run_case(r/'case.json',root/'data/sandbox/water',r/'attempt01',cancel=observe,evidence_directory=root/'data/sandbox')
(r/'runtime-after.json').write_text(json.dumps(runtime_identity(),indent=2)+'\n')
s={'status':result['status'],'reason':result.get('reason'),'elapsed_seconds':result['elapsed_seconds'],'guard_calls':calls,'steps':len(result.get('integration',{}).get('steps',[])),'events':len(result.get('integration',{}).get('events',[]))}
(r/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s))
