from pathlib import Path
import subprocess,json,time
r=Path('/private/tmp/brick-free-native-events-v1');started=time.monotonic()
with (r/'raw.log').open('wb') as log:
 try:
  p=subprocess.run(['/private/tmp/brick-water-backend-probe/venv/bin/python',str(r/'run.py')],cwd='/private/tmp',stdout=log,stderr=subprocess.STDOUT,timeout=840)
  status={'exit_code':p.returncode}
 except subprocess.TimeoutExpired:status={'timeout_s':840}
status['elapsed_seconds']=time.monotonic()-started
(r/'process.json').write_text(json.dumps(status,indent=2)+'\n');print(status);print((r/'raw.log').read_text()[-3000:])
