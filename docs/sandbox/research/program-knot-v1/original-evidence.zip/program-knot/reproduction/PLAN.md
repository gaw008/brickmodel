# Program-knot regression preregistration

Before any source change: reproduce constant wet ManufacturedDepletionAdapter with liquid1mol, vapor0, U600J, liquid->vapor .001mol/s and power2W, start0/end.06, knot.05, ordinaryinitial/maxstep.005. No depletion can occur (tau1000s), no EOS/affine method/nested approach. Require eventual completion, exact .05/.06 boundaries, strictly positive panels, no panel crossing knot and independent Fraction N/E oracle at every prefix. Original failure must be retained with raw XML/status and actual floathex times/ledgers/evaluation times.

Controls: dyadic1/256step same knot; standalone persistent-clock ordinaryintegrate same constants; resolvable1e-12s final interval; adjacentfloat unresolvable interval mustfail rather than skip; immediatecancel and cancellation afteracceptedprefix; piecewise forcing uses explicitly separate one-sided operators/restarts (no undocumented discontinuous callback behavior). No tolerance relaxation. Original .005 affine fixtures remain unchanged and separately runnable; do not overwrite them.

Root authorized one focused noEOS reproduction with external30s limit and no concurrent tests/EOS. Only new testfile and this temp reproduction directory are owned. Source remains frozen until actual baseline report.

## Additional public guards and accuracy distinction

After root candidate made original8 controls pass, add exact safety/cap alias refusal (.045→.05,liquid.02,sink1,safe.25), signed-time/zero-knot paths and a narrow sub-ULP cap at origin1 that must not be inflated into a resolvable2ULP boundary interval. These check public outcomes, not private endpoint helpers. Preserve originaltestbytes separately. New2 affine integration cases use currentexisting rel1e-11 accuracy with .005 cap and unchanged1e-10 event/A oracle gates. Original retained rel1e-7 fixture failures are not overwritten or relabelled; they expose a separate ordinary global-accuracy limitation after clockfix. Preparation only until root schedules focusedrun.
