from fractions import Fraction as F
from pathlib import Path
import json
h=F(1,8);y=F(1)
f=lambda x:x*x
mid=y+h*f(y+h*f(y)/2)
def heun(y,h):return y+h*(f(y)+f(y+h*f(y)))/2
fine=heun(heun(y,h/2),h/2);truth=1/(1-h);direct=abs(mid-fine)
# Scale intentionally half the actual cross-method difference: D=2 rejects,
# an unwarranted Richardson factor would convert that decision to a pass.
scale=direct/2
assert direct/scale==2 and direct/scale/3<1
assert abs(fine-truth)!=direct/3
# Fraction native binary policy scales, with float policy addition preserved
# separately for a production comparison once actual records exist.
result={'status':'passed','midpoint':str(mid),'fine_heun':str(fine),'exact_solution':str(truth),'difference':str(direct),'fine_true_error':str(abs(fine-truth)),'incorrect_div3':str(direct/3),'direct_normalized':2,'incorrect_normalized':'2/3','scope':'nonlinear mathematical decision counterexample, not source-material validation'}
Path(__file__).with_name('DISCREPANCY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
