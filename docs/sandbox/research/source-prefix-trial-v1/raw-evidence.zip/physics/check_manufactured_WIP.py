"""Actual manufactured-water source; independent saved-rate arithmetic checks."""
from dataclasses import replace
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,signal,time
import pytest
from test_source_liquid_column import setup
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.integration import IntegrationPolicy,ConservedState
from sludge_sandbox.source_prefix_trial import evaluate_source_prefix_trial,normalized_prefix_discrepancy
OUT=Path(__file__).parent;FILE=Path('src/sludge_sandbox/source_prefix_trial.py');sha=lambda:hashlib.sha256(FILE.read_bytes()).hexdigest();beforehash=sha();count=0
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('independent30s')));signal.alarm(30)
def ck(ok,label):
 global count
 count+=1
 if not ok:raise AssertionError(label)
begin=time.monotonic()
with pytest.MonkeyPatch.context() as mp:
 model,states=setup(mp,count=3)
 storages=tuple(replace(s,volume=replace(s.volume,error_m3=1e-12)) for s in model.storages)
 model=replace(model,storages=storages)
 states=tuple(s.state(old.liquid_water_mol,old.gas_amounts_mol,old.internal_energy_j) for s,old in zip(storages,states))
 adapter=ExactSourceColumn(model);initial=adapter.pack(states);h=F(1,16384)
 policy=IntegrationPolicy(1/1024,1/1024,1/16384,1e-8,1e-7,1e-3,1.,1e5,4,4,25.)
 actual=[];original=ExactSourceColumn.evaluate
 def observed(self,state,when):
  actual.append((state,when));return original(self,state,when)
 mp.setattr(ExactSourceColumn,'evaluate',observed)
 out=evaluate_source_prefix_trial(adapter,initial,start=T(F()),end=T(h),integration_policy=policy,maximum_callbacks=32)
 ck(out.status=='validated_positive_numerical_trial',str(out.reason));ck(len(actual)==len(out.captures)==11,'actual callbacks11');ck(out.reference.evaluations==8,'reference8')
 for i,(cap,(s,t)) in enumerate(zip(out.captures,actual)):
  ck(cap.ordinal==i+1 and cap.state is s and cap.time==t and cap.evaluation is not None and cap.failure is None,'capture identity/count')
 r=out.captures[0].evaluation.rates;m=out.captures[1].evaluation.rates
 for energy in (False,True):
  src=initial.internal_energy_j if energy else initial.amounts_mol;pred=out.predictor.internal_energy_j if energy else out.predictor.amounts_mol;fin=out.prefix.raw_state.internal_energy_j if energy else out.prefix.raw_state.amounts_mol
  face=r.face_energy_w if energy else r.face_species_mol_s;local=r.cell_power_w if energy else r.reaction_species_mol_s
  mf=m.face_energy_w if energy else m.face_species_mol_s;ml=m.cell_power_w if energy else m.reaction_species_mol_s
  for i in range(3):
   for j in range(1 if energy else 4):
    ix=i if energy else (i,j);right=i+1 if energy else (i+1,j)
    dn=float(F(float(face[ix]))-F(float(face[right]))+F(float(local[ix])))
    increment=float(h/2*F(dn));expected=float(F(float(src[ix]))+F(increment));ck(pred[ix]==expected,'Euler net round-product-round-update')
    endpoint=float(F(float(src[ix]))+F(float(h*F(float(mf[ix]))))-F(float(h*F(float(mf[right]))))+F(float(h*F(float(ml[ix])))))
    ck(fin[ix]==endpoint,'midpoint prefix once projected face integral')
 ck(out.reference.status=='completed' and out.reference.times_s[-1]==T(h),'sameendpoint completed')
 scales=(policy.amount_absolute_tolerance_mol+policy.relative_tolerance*policy.amount_scale_mol,policy.energy_absolute_tolerance_j+policy.relative_tolerance*policy.energy_scale_j)
 direct=max(max(abs(F(float(a))-F(float(b))) for a,b in zip(out.prefix.raw_state.amounts_mol.flat,out.reference.states[-1].amounts_mol.flat))/F(scales[0]),max(abs(F(float(a))-F(float(b))) for a,b in zip(out.prefix.raw_state.internal_energy_j,out.reference.states[-1].internal_energy_j))/F(scales[1]))
 ck(float(direct)==out.discrepancy and direct<=1,'independent direct difference')
 for row,cell in zip(out.terminal_bounds,out.captures[2].evaluation.source_evaluation.cells):
  point=cell.inverse.point
  ck(row==(point.temperature_k,cell.inverse.temperature_error_bound_k,point.pressure_pa,point.pressure_error_pa),'full bounds')
  ck(point.extra_pressure_error_pa>0 and point.pressure_error_pa>point.fluid.pressure_error_bound_pa,'volume uncertainty included')
 # Actual decision negative control for standalone direct comparator, exact E delta.
 testpolicy=replace(policy,relative_tolerance=1.,energy_scale_j=1.,energy_absolute_tolerance_j=1.)
 shifted=ConservedState(initial.amounts_mol,initial.internal_energy_j+4,initial.energy_model_identity)
 ck(normalized_prefix_discrepancy(shifted,initial,testpolicy)==2.,'no erroneous factor3')
 ck(out.reference_policy.maximum_wall_seconds<policy.maximum_wall_seconds,'remaining global resource')
 result={'status':'passed','checks':count,'elapsed_s':time.monotonic()-begin,'callbacks':len(actual),'reference_calls':out.reference.evaluations,'discrepancy':out.discrepancy,'direct_fraction':str(direct),'bounds':out.terminal_bounds,'sha_before':beforehash,'sha_after':sha(),'scope':'Actual source host with manufactured water/transport, no HEOS, not native approval or physical validation.'}
 OUT.joinpath('MANUFACTURED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
signal.alarm(0)
