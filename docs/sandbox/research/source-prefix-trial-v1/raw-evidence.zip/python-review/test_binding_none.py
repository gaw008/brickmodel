"""Successful actual captures must keep their source-content binding."""
from dataclasses import replace
import pytest
from test_source_prefix_trial import fixture, run


@pytest.mark.parametrize('index', [2, 3, -1])
def test_successful_terminal_and_reference_capture_cannot_drop_binding(monkeypatch, index):
    adapter, state = fixture(monkeypatch)
    out = run(adapter, state)
    assert out.status == 'validated_positive_numerical_trial', out.reason
    captures = list(out.captures)
    captures[index] = replace(captures[index], binding=None)
    changed = replace(out, captures=tuple(captures))
    with pytest.raises(ValueError):
        changed.check()
