"""Independent callback retention and saved reference-evidence probes."""
from dataclasses import replace
import pytest
from sludge_sandbox.exact_source_column import ExactSourceColumn
from test_source_prefix_trial import fixture, run


@pytest.mark.parametrize('error_type', [TypeError, AttributeError, OverflowError])
def test_failed_terminal_callback_keeps_failure_in_attempt_record(monkeypatch, error_type):
    adapter, state = fixture(monkeypatch)
    original = ExactSourceColumn.evaluate
    count = 0
    def evaluation(self, packed, when):
        nonlocal count
        count += 1
        if count == 3:
            raise error_type('independent-terminal-callback-failure')
        return original(self, packed, when)
    monkeypatch.setattr(ExactSourceColumn, 'evaluate', evaluation)
    out = run(adapter, state)
    assert out.status == 'numerical_failure'
    assert len(out.captures) == count == 3
    assert out.captures[-1].role == 'prefix_terminal'
    assert out.captures[-1].evaluation is None
    assert out.captures[-1].failure == 'independent-terminal-callback-failure'


def test_retained_reference_ledger_cannot_be_altered_after_validation(monkeypatch):
    adapter, state = fixture(monkeypatch)
    out = run(adapter, state)
    assert out.status == 'validated_positive_numerical_trial', out.reason
    first = out.reference.steps[0]
    changed_face_energy = first.face_energy_j.copy()
    changed_face_energy[0] += 1.
    changed_step = replace(first, face_energy_j=changed_face_energy)
    forged = replace(out, reference=replace(out.reference,
                     steps=(changed_step, *out.reference.steps[1:])))
    with pytest.raises(ValueError):
        forged.check()


def test_saved_success_status_and_reason_cannot_be_relabelled_as_unsupported(monkeypatch):
    adapter, state = fixture(monkeypatch)
    out = run(adapter, state)
    assert out.status == 'validated_positive_numerical_trial', out.reason
    changed = replace(out, status='unsupported', reason='made-up-domain-exit')
    with pytest.raises(ValueError):
        changed.check()
