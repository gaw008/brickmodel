"""A failed physical callback still binds the actual state that was tried."""
from dataclasses import replace
import pytest
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.integration import ConservedState, DomainExit
from test_source_prefix_trial import fixture, run


def test_failed_terminal_capture_cannot_replace_attempted_state(monkeypatch):
    adapter, state = fixture(monkeypatch)
    original = ExactSourceColumn.evaluate
    count = 0
    def evaluation(self, packed, when):
        nonlocal count
        count += 1
        if count == 3:
            raise DomainExit('independent-terminal-domain')
        return original(self, packed, when)
    monkeypatch.setattr(ExactSourceColumn, 'evaluate', evaluation)
    out = run(adapter, state)
    assert out.status == 'domain_exit' and out.captures[-1].failure == 'independent-terminal-domain'
    capture = out.captures[-1]
    fake_state = ConservedState(capture.state.amounts_mol+1., capture.state.internal_energy_j,
                                capture.state.energy_model_identity)
    changed = replace(out, captures=(*out.captures[:-1], replace(capture, state=fake_state)))
    with pytest.raises(ValueError):
        changed.check()
