"""Independent exact Euler predictor boundaries; no EOS or source evaluation."""
from dataclasses import fields, replace
from fractions import Fraction as F
import numpy as np
import pytest
import sludge_sandbox.exact_integration as module
from sludge_sandbox.integration import ConservedState, Rates, IntegrationPolicy, IntegrationError, _Reject
from test_exact_integration import policy


def state(n=1., energy=2.):
    return ConservedState([[n]], [energy], ('review-energy',))


def rate(reaction=0., heat=0.):
    return Rates(np.zeros((2, 1)), np.zeros(2), [[reaction]], [heat])


@pytest.mark.parametrize('duration', [1., True, F(), F(-1)])
def test_duration_requires_actual_positive_fraction(duration):
    with pytest.raises(IntegrationError):
        module.advance_exact_euler(state(), rate(), duration, policy())


def test_exact_nonbinary_duration_once_projected_and_negative_energy_allowed():
    initial = state(2., -4.)
    out = module.advance_exact_euler(initial, rate(3., 6.), F(1, 3), policy())
    assert out.amounts_mol.tolist() == [[3.]]
    assert out.internal_energy_j.tolist() == [-2.]
    assert out.energy_model_identity == initial.energy_model_identity
    assert initial.amounts_mol.tolist() == [[2.]]
    assert initial.internal_energy_j.tolist() == [-4.]
    with pytest.raises(ValueError):
        out.amounts_mol[0, 0] = 9.


def test_original_nonzero_product_underflow_behavior_preserved():
    out = module.advance_exact_euler(state(), rate(1e-320), F(1, 10**100), policy())
    assert out.amounts_mol.tolist() == [[1.]]


def test_original_product_overflow_error_preserved():
    with pytest.raises(_Reject, match='unrepresentable_exact_duration_product'):
        module.advance_exact_euler(state(), rate(1.), F(2**2048), policy())


def test_negative_prediction_is_rejected_and_zero_is_retained():
    with pytest.raises(_Reject, match='trial_inventory_or_energy_invalid'):
        module.advance_exact_euler(state(), rate(-2.), F(1), policy())
    zero = module.advance_exact_euler(state(), rate(-1.), F(1), policy())
    assert zero.amounts_mol.tolist() == [[0.]]
    with pytest.raises(IntegrationError, match='outflow_from_zero_inventory'):
        module.advance_exact_euler(zero, rate(-1.), F(1), policy())


def test_existing_state_rate_policy_subclasses_remain_valid():
    class ChildState(ConservedState):
        pass
    class ChildRates(Rates):
        pass
    class ChildPolicy(IntegrationPolicy):
        pass
    base = policy()
    p = ChildPolicy(**{f.name: getattr(base, f.name) for f in fields(base)})
    s = ChildState([[1.]], [0.])
    r = ChildRates(np.zeros((2, 1)), np.zeros(2), [[1.]], [2.])
    out = module.advance_exact_euler(s, r, F(1, 2), p)
    assert type(out) is ConservedState
    assert out.amounts_mol.tolist() == [[1.5]] and out.internal_energy_j.tolist() == [.1e1]


def test_mechanical_requires_explicit_scales_and_positive_prediction():
    s = replace(state(), mechanical_stretches=[1., 1.])
    r = replace(rate(), mechanical_rates_per_s=[-2., 0.])
    missing = replace(policy(), stretch_absolute_tolerance=None, stretch_scale=None)
    with pytest.raises(IntegrationError, match='stretch'):
        module.advance_exact_euler(s, r, F(1), missing)
    with pytest.raises(_Reject, match='trial_stretch_not_positive'):
        module.advance_exact_euler(s, r, F(1), policy())


def test_state_projection_gate_not_bypassed_by_exact_duration():
    strict = replace(policy(), amount_absolute_tolerance_mol=1e-30)
    with pytest.raises(IntegrationError, match='unresolvable_amount_increment'):
        module.advance_exact_euler(state(), rate(.1), F(1), strict)
