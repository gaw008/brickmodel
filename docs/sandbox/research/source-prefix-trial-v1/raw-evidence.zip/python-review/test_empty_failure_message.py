"""An exception's empty message still means the actual callback failed."""
import pytest
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.integration import DomainExit, IntegrationError
from test_source_prefix_trial import fixture, run


@pytest.mark.parametrize('error_type', [DomainExit, IntegrationError, ValueError])
def test_failure_without_message_remains_a_checkable_attempt(monkeypatch, error_type):
    adapter, state = fixture(monkeypatch)
    def evaluation(self, packed, when):
        raise error_type()
    monkeypatch.setattr(ExactSourceColumn, 'evaluate', evaluation)
    out = run(adapter, state)
    assert len(out.captures) == 1 and out.captures[0].evaluation is None
    assert out.captures[0].failure is not None
    out.check()
