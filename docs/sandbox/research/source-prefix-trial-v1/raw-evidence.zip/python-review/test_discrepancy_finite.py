"""Direct normalized comparisons may not hide NaN in max's second operand."""
from dataclasses import replace
import numpy as np
import pytest
from sludge_sandbox.integration import ConservedState
from sludge_sandbox.source_prefix_trial import normalized_prefix_discrepancy
from test_source_prefix_trial import POLICY


@pytest.mark.parametrize('target', ['prefix', 'reference'])
def test_nonfinite_energy_input_is_rejected_even_when_amount_difference_is_zero(target):
    prefix = ConservedState([[1.]], [2.], ('review-energy',))
    reference = ConservedState([[1.]], [2.], ('review-energy',))
    altered = prefix if target == 'prefix' else reference
    object.__setattr__(altered, 'internal_energy_j', np.array([float('nan')]))
    with pytest.raises(ValueError):
        normalized_prefix_discrepancy(prefix, reference, replace(POLICY))
