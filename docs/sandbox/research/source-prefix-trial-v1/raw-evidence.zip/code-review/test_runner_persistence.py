"""Independent cheap runner persistence checks; manufactured water, no HEOS."""
import importlib.util
import json
from pathlib import Path
import signal
import pytest

from test_source_prefix_trial import fixture
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.integration import DomainExit

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
RUNNER=Path('/private/tmp/brick-source-prefix-trial-v1/root/run_native.py')


def runner(monkeypatch, adapter, state, constructor_failure=False):
    spec=importlib.util.spec_from_file_location('review_only_runner',RUNNER)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    original_spec=importlib.util.spec_from_file_location
    def substituted_spec(name,path,*args,**kwargs):
        spec=original_spec(name,path,*args,**kwargs)
        if name=='frozen_source_constructor':
            original_exec=spec.loader.exec_module
            def execute(prior):
                original_exec(prior)
                def construct(_):
                    if constructor_failure:
                        raise ValueError('manufactured constructor failure')
                    return adapter,state,'manufactured-mobility-marker'
                prior.construct=construct
            spec.loader.exec_module=execute
        return spec
    monkeypatch.setattr(importlib.util,'spec_from_file_location',substituted_spec)
    return module


@pytest.mark.parametrize('failure',[None,DomainExit('manufactured initial domain'),TimeoutError('manufactured outer timeout')])
def test_atomic_pending_and_completed_or_failed_attempt(monkeypatch,tmp_path,failure):
    adapter,state=fixture(monkeypatch)
    module=runner(monkeypatch,adapter,state)
    output=tmp_path/'result.json'
    original=ExactSourceColumn.evaluate
    checked=[]
    def observed(self,current,when):
        saved=json.loads(output.read_text())
        ordinal=len(checked)+1
        assert saved['pending_callback']==ordinal
        assert saved['captures'][-1]['ordinal']==ordinal
        assert 'evaluation' not in saved['captures'][-1]
        checked.append(ordinal)
        if failure is not None and ordinal==(1 if isinstance(failure,DomainExit) else 3):
            raise failure
        return original(self,current,when)
    monkeypatch.setattr(ExactSourceColumn,'evaluate',observed)
    status=module.run(ROOT,output)
    saved=json.loads(output.read_text())
    assert saved['material_qualified'] is False
    assert saved['duration_s']=={'numerator':1,'denominator':16384}
    assert saved['maximum_callbacks']==32
    assert saved['mobility_sha256']=='manufactured-mobility-marker'
    assert len(saved['captures'])==len(checked)
    assert 'pending_callback' not in saved
    if failure is None:
        assert status==0 and saved['status']=='validated_positive_numerical_trial'
        assert len(checked)==11
    else:
        assert status==1 and saved['status']=='failed'
        assert saved['captures'][-1]['exception_type']==type(failure).__name__
        assert saved['captures'][-1]['exception']==str(failure)
        assert saved['trial']['status'] in ('domain_exit','numerical_failure')
        assert saved['trial']['captures'][-1]['fields']['failure']
    assert not output.with_suffix('.pending').exists()


def test_constructor_failure_keeps_original_resource_plan(monkeypatch,tmp_path):
    adapter,state=fixture(monkeypatch)
    module=runner(monkeypatch,adapter,state,True)
    output=tmp_path/'result.json'
    assert module.run(ROOT,output)==1
    saved=json.loads(output.read_text())
    assert saved['status']=='failed' and saved['exception']=='manufactured constructor failure'
    assert saved['captures']==[] and saved['outer_seconds']==210.
    assert saved['policy_values']==list(module.POLICY_VALUES)


def test_registered_outer_alarm_remains_explicit_resource_failure(monkeypatch,tmp_path):
    adapter,state=fixture(monkeypatch)
    module=runner(monkeypatch,adapter,state)
    output=tmp_path/'result.json'
    original_handler=signal.getsignal(signal.SIGALRM)
    def expired(*args):
        callback=signal.getsignal(signal.SIGALRM)
        assert callable(callback) and callback is not original_handler
        callback(signal.SIGALRM,None)
        pytest.fail('outer handler returned without interrupting the source callback')
    monkeypatch.setattr(ExactSourceColumn,'evaluate',expired)
    assert module.run(ROOT,output)==1
    saved=json.loads(output.read_text())
    assert saved['status']=='resource_limit' and saved['outer_timeout_requested'] is True
    assert saved['trial']['status']=='numerical_failure'
    assert saved['captures'][0]['exception_type']=='TimeoutError'
    assert saved['captures'][0]['exception']=='outer_210s_budget_exceeded'
    assert saved['trial']['captures'][0]['fields']['failure']=='TimeoutError:outer_210s_budget_exceeded'
    assert signal.getsignal(signal.SIGALRM) is original_handler
    assert signal.getitimer(signal.ITIMER_REAL)==(0.,0.)
