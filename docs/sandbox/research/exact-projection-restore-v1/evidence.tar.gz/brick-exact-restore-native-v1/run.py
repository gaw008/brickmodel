"""One actual host rebuild and numerical projection restore/reencode; no trajectory."""
from pathlib import Path
from dataclasses import replace
import hashlib,json,time,traceback,importlib.util,sys
import sludge_sandbox
from sludge_sandbox.verification_case import build_case,read_case,encode
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.run_service import runtime_identity
from sludge_sandbox.exact_record import encode_exact_run,read_exact_run,pack,canonical
ROOT=Path(__file__).parent
PRIOR=Path('/private/tmp/brick-exact-record-native-v1/attempt01')
CANDIDATE=Path('/private/tmp/brick-exact-continuation-v1/exact_projection_restore.py')
EXPECTED_CANDIDATE='6c5ec48fda6c2600ca9000bd9b4c87c2f09a8cfa58d83e4c8e73abc0cd9e6d25'
EXPECTED_ADDED={'exact_record_audit.py': 'fb8e9a235592ad3e225fab538cb3425fdf9d6af5acf0bed30056fe786bc057a6', 'exact_terminal_proof_audit.py': 'ff991e946c72953c1e8a844cfc7c42165cd52b94ddeded9bb43ef2d49fc2ef7b', 'exact_record_comparison_audit.py': '1cef63c34c9cf77c51a62078df0b696dae2c33096140b079f8b0d8c79b988368', 'exact_resource_audit.py': 'c1bfaabb1a3325b26a40cf3fa925e9abaf18aa10278823690cbec5a317285ce0'}
WATER=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')
OUT=ROOT/'attempt01';OUT.mkdir(exist_ok=False)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
started=time.monotonic()
names=('case.json','exact-run-record.json','initial.json','event-policy.json','integration-policy.json','runtime-before.json')
paths=[PRIOR/n for n in names]+[CANDIDATE,Path(__file__),ROOT/'PLAN.md',ROOT/'supervise.py',ROOT/'preflight.json']+[p for p in WATER.rglob('*') if p.is_file()]
inputs={str(p):digest(p) for p in paths};save('inputs-before.json',inputs)
before=runtime_identity();save('runtime-actual82-before.json',before)
original=json.loads((PRIOR/'runtime-before.json').read_text());save('runtime-original78.json',original)
report={'status':'started','qualification':'Actual host rebuild and full numerical projection restore/reencode. No integration or resume authority.'}
try:
    assert str(Path(sludge_sandbox.__file__).resolve()).startswith('/private/tmp/brick-water-backend-probe/venv/')
    assert digest(CANDIDATE)==EXPECTED_CANDIDATE
    assert len(original['modules'])==78 and len(before['modules'])==82
    assert {k:v for k,v in before.items() if k!='modules'}=={k:v for k,v in original.items() if k!='modules'}
    assert all(before['modules'].get(k)==v for k,v in original['modules'].items())
    added=set(before['modules'])-set(original['modules'])
    assert added==set(EXPECTED_ADDED)
    assert {k:before['modules'][k] for k in added}==EXPECTED_ADDED
    save('runtime-compatibility.json',{'verified':True,'original_module_count':78,'actual_module_count':82,
        'unchanged_original_modules':78,'nonmodule_metadata_equal':True,'exact_added_modules':EXPECTED_ADDED,
        'scope':'Explicit restore/read-audit compatibility only; not permission to integrate/resume under a relabelled runtime.'})
    spec=importlib.util.spec_from_file_location('research_projection_restore',CANDIDATE)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    built=build_case(read_case(PRIOR/'case.json'),WATER)
    assert encode(built.initial)==json.loads((PRIOR/'initial.json').read_text())
    policy=replace(built.depletion_policy,ordered_event_policy='ordered_affine_packet_v1')
    assert encode(policy)==json.loads((PRIOR/'event-policy.json').read_text())
    assert encode(built.policy)==json.loads((PRIOR/'integration-policy.json').read_text())
    op=ExactFreeWaterTransfer(built.operator);start=ExactEventTime.from_float(built.start_s);end=ExactEventTime.from_float(built.end_s)
    audit_start=time.monotonic()
    raw=(PRIOR/'exact-run-record.json').read_bytes()
    restored=module.restore_exact_projection(raw,original_operator=op,case_sha256=digest(PRIOR/'case.json'),runtime_identity=original)
    reencoded=encode_exact_run(restored.result,original_operator=op,start=start,end=end,case_sha256=digest(PRIOR/'case.json'),runtime_identity=original)
    (OUT/'reencoded-record.json').write_bytes(reencoded)
    saved=read_exact_run(raw)
    result={'record_sha256':restored.record_sha256,'reencoded_sha256':hashlib.sha256(reencoded).hexdigest(),
        'byte_identical':raw==reencoded,'accepted_steps':len(restored.result.steps),'packets':len(restored.result.packets),
        'canonical_ledger_aliases':restored.rebound_committed_ledgers,'resume_authorized':restored.resume_authorized,
        'scope':restored.scope,'full_projection_equal':canonical(pack(restored.result))==canonical(pack(saved.result))}
    aliases=[]
    for packet in restored.result.packets:
        for frame in packet:
            ledger=frame.terminal.terminal_panel.ledger
            aliases.append(sum(ledger is item for item in restored.result.steps))
    result['identity_alias_memberships']=aliases
    save('restore-result.json',result)
    assert restored.record_sha256==digest(PRIOR/'exact-run-record.json') and raw==reencoded
    assert result['accepted_steps']==30 and result['packets']==2 and result['canonical_ledger_aliases']==2
    assert aliases==[1,1] and result['full_projection_equal'] and not restored.resume_authorized
    report.update(status='passed',restore_elapsed_s=time.monotonic()-audit_start,**result)

except BaseException:report.update(status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-actual82-after.json',after);assert before==after
        final={str(p):digest(p) for p in paths};save('inputs-after.json',final);assert inputs==final
    except BaseException:report.update(status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_s=time.monotonic()-started,actual_modules=len(before['modules']),original_modules=len(original['modules']),
        inputs=inputs,runner_sha256=inputs[str(Path(__file__))],candidate_sha256=inputs[str(CANDIDATE)])
    save('report.json',report)
assert report['status']=='passed',report
