# Exact ordered core continuation: implement the existing numerical contract

Scope: read-only design against the current exact driver/strict record and saved actual 2/4/8-cell runs. No EOS or production edits. This is a concrete next integration step, not a proposal to replace the existing numerical acceptance contract with validated true-ODE integration.

## Conclusion and smallest coherent change

Add one audited continuation input to `integrate_exact_depletion`, keep its original initial/start/end/policies arguments, and initialize its existing history/cost/roundoff closures from the audited full record. Start new computation at the last accepted exact time and state. Keep the existing proposal/refinement/common-time algorithm unchanged. Append to complete histories and return one complete cumulative result, never a suffix that a caller must merge again.

The existing strict codec is necessary but not sufficient: it checks structure/associations and sources, not the full root, numerical panel/writeback, refinement or cumulative resource contract. The old event_record auditor cannot authorize this path: event_record.py:193 explicitly refuses ordered packets. The implementation must connect the current pure exact proof functions and the already executed saved comparison audits to a narrow `audit_exact_continuation` entry before enabling the new core argument.

No new native solver primitive is required. In particular the original two consecutive numerical refinements and independently refined approach are the event acceptance evidence; do not impose a new rigorous true-RHS remainder or minimum event spacing. The new exact root intervals concern the numerical affine surrogate.

## Public interface and external authority

Proposed module `exact_continuation.py`:

```python
def audit_exact_continuation(
    raw: bytes, *, original_operator: ExactFreeWaterTransfer,
    original_initial: ConservedState, start: ExactEventTime,
    end: ExactEventTime, integration_policy: IntegrationPolicy,
    event_policy: DepletionPolicy, case_sha256: str, runtime_identity: dict,
) -> AuditedExactContinuation: ...
```

The returned frozen object holds canonical original record bytes, original input/policy identities, parent record SHA, recomputed roundoff totals and a manifest of audit outcomes. It is not a constructor-issued capability: its public restore method re-parses and re-audits against the external arguments. The core must use that freshly returned checked state, not arbitrary cached dataclass attributes. Do not accept a caller-supplied boolean `audited=True` or an unchecked totals dictionary.

Add keyword-only `continuation=None` to the core. The no-continuation branch must keep its existing result fields, ordering, callback sequence and numerical values; test parity excluding elapsed time. The resumed branch is explicitly an adaptive restart from the accepted state. It does not resume a partially evaluated RK trial or half-tested packet and does not promise bit-identical global adaptive trajectories.

Admission for the first executable version: saved `status == 'cancelled'`, nonempty accepted steps, start < last accepted time < original end. A cancellation before any accepted step may be replayed as a new run by a future service, not called continuation here. Completed, numerical/domain/unsupported and wall/panel/rejection-exhausted records are not resumed. No original budget increase or horizon extension is implicit. Continuing beyond the original end is a new experiment and requires an explicit separate contract.

External original initial state, exact start/end and full policies must equal the rebuilt original case, not just the saved policy object. `validate_binding` must be consumed through its returned checked record. Rebuild from the externally frozen case, water assets and current identical implementation; then reconstruct saved final modes from the actual original WPT. Do not execute saved code or recreate a fake provider. Validate exact energy identity, species indices, state shape, wet/dry liquid inventory and mechanical positivity before the first callback.

## Gates still required after current prefix audit

1. **Full original-prefix conservation.** Reuse/factor the driver audit_commit loop at exact_depletion_integration.py:272–314 into a pure function. Recompute signed N/E totals from actual shared-face/source/work ledgers and all committed corrections, every local and original cumulative mechanical residual, absolute component residual sum, and absolute quadrature-roundoff sum. Apply original p tolerances throughout. The roundoff total is reconstructed from actual corrections, including correction=None exact-zero events. Reapply original mass/element/storage/cumulative correction inequalities, not only numerical totals equality. The current separate prefix/closed-energy audits supply regression oracles, not automatic resume authorization.
2. **Every committed terminal's numerical evidence.** Reconstruct typed ExactAffineSamples/Evidence/RootOrder from the fixed codec allowlist. Use `verify_exact_root_order` (exact_root_order.py:168) on that terminal's actual saved initial state, first and midpoint Rates, all wet cells, actual evaporation vectors, exact times and source binding. This rechecks every candidate/exclusion and strict first order, not merely the selected cell or saved hash.
3. **Predictor/full panel binding.** Recompute the initial tau, predictor midpoint and common-domain upper using the same exact formulas in exact_terminal_executor.py:107–131. Rebuild the predictor through `build_exact_affine_panel(first, first)` and the terminal panel through `build_exact_affine_panel(first, mid)` (exact_terminal_panel.py:36). Compare complete raw state and every ledger field, including signed components and mechanical quadrature. Match the actual midpoint observation state to the predictor. Preserve the current represented-ledger N/E error contract; do not invent an unimplemented full N/E truncation certificate.
4. **Writeback and original roundoff.** Call `exact_depletion_writeback` (exact_affine_depletion.py:170) with the recomputed raw panel, saved component terms, selected exact evidence and downward gross evaporation. Seed totals with the actual earlier path/committed totals, not zero. Compare corrected state, every correction field and resulting totals. ExactAffineEvidence.__post_init__ already checks the original root/time/local/absolute/fraction budgets (lines 87–109). Writeback handles element/mass/storage constraints. Bind selected cell and liquid/vapor indices and exact mode transition. No additional latent heat or dissipation source is introduced.
5. **Empirical full-state acceptance.** Port the existing saved-data comparison logic from `/private/tmp/brick-exact-record-native-v1/audit_comparisons.py` into a pure typed audit over record data. Keep all event and common-time N/E/T/P/stretch arrays, exact time remainder (zero for exact polynomial zero), original error terms and gates. Reuse `audit_pressure_comparison` and externally derived `pressure_comparison_binding` for each mode configuration. Verify two consecutive passing terminal refinements and the passing independent path with both cap/safe fraction halved and a distinct pre-first-event grid. Verify every chosen packet matches the accepted path, coarse/previous/common metadata and conservative packet maxima. Discarded paths are evidence/cost, never additional accepted events.
6. **Resources and discarded work.** Validate all nonnegative integer counters and completed<=attempted inequalities. Match the original budget definition: `ordinary_panels + stage_replans + terminal_attempts`, rejected trials separately; predictor attempts/ordinary trials are diagnostic, not a newly stricter panel gate. Account for every refinement (coarse, failed comparisons, independent and interrupted) exactly once. Reconcile top terminal/predictor/evaluation costs with the list of all terminal attempts, and refinements with their saved phase costs. Preserve saved overall cumulative elapsed including discarded work. Require strictly positive remaining wall/panel/rejection budgets before allowing callbacks.

### What saved costs can and cannot independently prove

Current records save all terminal attempts and per-refinement costs but do not save every ordinary RK stage evaluation or OS wall timestamp. Therefore exact reconstruction of each native evaluation and elapsed wall time from saved state arrays is impossible. Do not claim that it is done. Resume debits the complete recorded cumulative wall/counters, bound to the sealed parent result/runtime, checks every reconstructible subtotal and consistency inequality, and never grants a refund for missing stage details.

For panel accounting, reconcile accepted ordinary steps outside committed packet paths plus ordinary panels across all refinement paths/costs; all terminal attempts are separately saved. Replan counts and rejected attempts have saved counters but not full per-trial observations. If these counters contradict paths/subtotals, refuse. This is the same evidentiary level as existing persisted numerical counters, not a demand to add a validated runtime before proceeding. If the parent runtime/manifest is unavailable or interrupted before a trustworthy terminal result was captured, refuse recovery rather than assume zero work. A future supervisor provides the process-reaped/run envelope; this core design never signals a persisted PID.

## Core changes at exact lines and once-only history

At exact_depletion_integration.py:125–128, branch initialization only:

- Fresh: unchanged `[start]`, `[initial]`, empty ledgers/packets/refs/attempts, zero totals/costs.
- Resume: full checked original histories; last source-bound operator in final modes; recomputed original totals; cumulative recorded cost dictionary. Keep `initial` and `start` as original arguments, not last state/time. Preserve every earlier failure/refinement record without rerunning it.
- Start a new `invocation_begin = monotonic()`, retain `prior_elapsed = checked.result.elapsed_seconds`. All elapsed checks use `prior_elapsed + monotonic() - invocation_begin`, including guard, remaining_policy, terminal cancellation guard and final result. Do not charge parent elapsed twice on repeated resume. Rebuild time is separately reported by a future service; do not silently change the current integrate-only wall scope.
- Existing guard and remaining_policy automatically subtract cumulative panel/rejection counts once initialized correctly. Ensure terminal reservations use remaining original panel budget. Predictors remain diagnostic under original semantics.
- Existing main loop begins from `times[-1]`, so no suffix replay or fake start-time projection is needed.
- Existing `audit_commit` recomputes against original initial across the combined complete history. Factor it only to make admission reuse possible; do not replace it with a suffix-local check.
- Preserve original `schema` behavior for fresh runs. Add an explicitly versioned resumed result/lineage extension in the codec: parent canonical record SHA, accepted-step/packet/refinement/attempt boundary indices, and pre-invocation cumulative costs/elapsed. A boundary is a slicing descriptor, not a second history. Do not serialize the suffix under a field implying it includes only newly computed totals when counters are cumulative.

### Important Python aliasing trap

`audit_commit` currently associates correction with a ledger using `id(frame.terminal.terminal_panel.ledger)` (lines 277–278). Decoding identical ledger values twice does not preserve object identity. Before seeding the core, map each committed frame to exactly one accepted ledger by exact start/end plus full packed ledger equality; reject ambiguity, then rebind the historical frame's ledger reference to that actual canonical ledger object. Alternatively replace the internal id map with a validated accepted-step index map. Merely reusing independent decoded frame objects would silently omit correction terms on later cumulative audits.

### No need to reconstruct live historical inverse objects

The current codec intentionally saves Observation numerical projections. The resumed driver does not reevaluate historical speculative observations; new proposals create fresh actual evaluations. Its historical audit needs only typed states/ledgers/corrections and frozen numerical evidence. Keep historical evidence as immutable nodes with the same wire representation; reconstruct only the fixed numeric record types needed by the pure audits and canonical ledger aliases. The active final operator alone is a real rebuilt ExactFreeWaterTransfer. Do not manufacture a WaterTransferEvaluation containing a fake live inverse merely to satisfy an old constructor. If a typed result wrapper is added, its historical-observation protocol must explicitly admit saved numerical evidence.

## Implementation order (one usable seam, not isolated framework growth)

1. Factor original-prefix audit + add pure terminal/root/panel/writeback and saved comparison audit in one continuation module; test against the actual sealed two-cell strict record without EOS and against controlled cancelled records.
2. Add the optional core argument and cumulative seeding/elapsed logic. Add explicit resume lineage to a new record schema while leaving fresh v1 outputs unchanged. Keep old compact captures unsupported.
3. Pure end-to-end tests: cancel before first packet, cancel after a committed packet, cancel in a speculative later packet, resume twice to the same original end. Each result contains the entire original prefix once. Compare original analytic N/E/mechanical oracles and original six gates; prove callback starts exactly at checkpoint time and no stale modes leak.
4. Adversarial tests: tamper original initial/policy/source/runtime; selected root/order/comparison arrays; correction fraction/element/mass totals; missing discarded cost; exhausted wall/panels/rejections; malformed manually constructed audit wrapper; equal-valued but unaliased terminal ledger. All fail before callbacks. Fresh no-continuation parity remains a required regression.
5. Only after review, parent runs one bounded native two-cell cancellation→resume using the same source-qualified case and original cumulative 800s budget, comparing against the already completed original horizon result. Preserve raw cancellation/continuation records and independent prefix/comparison/energy audits. Four/eight-cell lifecycle and service admission follow only after that seam works.

Completion of this task means an exact cancelled accepted prefix can continue under its original contracts with complete historical/cost retention. It does not mean longer end-time admission, full thermal cycle, new material data, convergence or physical qualification. Those remain separate required Goal work.
