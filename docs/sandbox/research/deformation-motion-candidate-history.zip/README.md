# Isolated prescribed motion candidate

Not applied to repository or installed package. Tests explicitly load this sibling candidate with importlib and use the actual repository ReferenceSlab geometry.

PrescribedSlabMotion is a frozen, identity-bearing C1 rest-to-rest smoothstep program. All stretches remain positive mathematically because each interval is a convex blend of positive endpoint stretches. Numeric geometry and velocities are validated at each sample; this is not a global floating-point error certificate. Knot rates are exactly zero. Snapshots use immutable bytes-backed arrays. Geometry is always sampled from the reference configuration.

sample(t) returns current geometry, normal/tangential stretches and rates, width rates, face velocities, area rate and volume rates with identity/source fields. validate_reference_geometry binds count, area, every width and every gas volume; accepted 2 ULP input residuals are explicit construction allowances, not physical shape uncertainty or a blanket bitwise zero-motion guarantee.

The identity/source labels are declarations, not content admission. Literature-prescribed histories require asset hashes but this module does not fetch or validate their contents. This motion is not a sintering law, automatic isotropic inference, or mechanics closure. No EOS or gas-host changes are included.

Verification history, commands and final hashes are in verification.json. The boundary RED deliberately exposed a raw TypeError for scalar-array input and was fixed with explicit shape gates; representably unresolved time intervals also reject. Independent reviewer found nonzero Fraction time underflow entering the domain as negative zero; a new RED test failed and conversion now rejects it. Final isolated suite after multicell/knot review: 29 passed in 0.08 s. Independent reviewer approval is pending.

Constructor now samples every knot. Mathematical positive stretch does not certify full-interval floating representability; every later sample retains gates. Coordinate spacing uses the sum of ULPs of both faces, width and computed difference (the subtraction inherits coordinate rounding), with that allowance itself required smaller than the width. This numerical representation allowance replaces the incorrect width-only 2 ULP check which rejected regular 16/32/64-cell slabs; it does not change reference-host input 2 ULP alignment or introduce material uncertainty. The original unresolved-face extreme still rejects.

The spacing check bounds local adjacent-coordinate consistency only. It is not an absolute face-position accuracy bound from the origin; cumulative sum errors can accumulate across cells. No global coordinate accuracy certificate is claimed.
