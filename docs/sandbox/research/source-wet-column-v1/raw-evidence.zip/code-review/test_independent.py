from dataclasses import replace
from fractions import Fraction as F
import math
import pytest
from test_mass_wet_exchange_kernel import point_case,phase_args
from test_mass_wet_transport import setup
from sludge_sandbox import mass_wet_transport as m

def test_fraction_coefficient_and_entropy(monkeypatch):
    pair,p=point_case(monkeypatch)
    args=phase_args(pair,p);args['transfer_coefficient']=F(1,10**8)
    out=m.evaluate_wet_phase(**args)
    peq=out.equilibrium.equilibrium_partial_pressure_pa
    assert out.phase_water_mol_s==float(F(1,10**8)*(F(peq)-F(out.water_partial_pressure_pa)))
    assert out.entropy_production_w_k>=0
    assert math.isclose(out.chemical_driving_force_j_mol,pair.chemical.gas_constant_j_mol_k*p.temperature_k*math.log(peq/out.water_partial_pressure_pa),rel_tol=1e-14)

def test_mismatched_vapor_before_query(monkeypatch):
    pair,p=point_case(monkeypatch)
    def forbidden(*a,**kw):pytest.fail('invalid inventory reached chemical query')
    monkeypatch.setattr(m.WaterChemicalPotential,'equilibrium_at_liquid_tp',forbidden)
    with pytest.raises(ValueError,match='phase_vapor_inventory_mismatch'):
        m.evaluate_wet_phase(**dict(phase_args(pair,p),water_vapor_mol=.125))

@pytest.mark.parametrize('field,value',[('gas_constant_j_mol_k',9.),('molar_masses_kg_mol',{'O2':.1,'N2':.2,'H2O':.3})])
def test_face_state_convention_mismatch(monkeypatch,field,value):
    pair,s=setup(monkeypatch);gs=pair.evaluate(s).gas_states
    gs=(gs[0],replace(gs[1],**{field:value}))
    with pytest.raises(ValueError):
        m.evaluate_wet_face(pair.face,gs,pair.storages[0].gas_ids,pair.storages[0].fluid_template.gas_phases)
