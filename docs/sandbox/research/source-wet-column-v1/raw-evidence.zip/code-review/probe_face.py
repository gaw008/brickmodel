from test_mass_wet_transport import setup
from sludge_sandbox import mass_wet_transport as m
from types import SimpleNamespace
import pytest
p=pytest.MonkeyPatch();pair,states=setup(p);gases=pair.evaluate(states).gas_states
phases=dict(pair.storages[0].fluid_template.gas_phases)
args=dict(face=pair.face,gas_states=gases,gas_ids=pair.storages[0].gas_ids,gas_phases=phases)
original=m.evaluate_wet_face(**args)
phases['O2'],phases['N2']=phases['N2'],phases['O2']
wrong=m.evaluate_wet_face(**args)
print('swapped real species accepted',original.face_energy_w,wrong.face_energy_w)
calls=[]
phases['O2']=SimpleNamespace(_curve=SimpleNamespace(enthalpy_j_mol=lambda t:calls.append(t) or 1e12))
wrong=m.evaluate_wet_face(**args)
print('fake provider callback invoked',len(calls),'face energy',wrong.face_energy_w)
p.undo()
