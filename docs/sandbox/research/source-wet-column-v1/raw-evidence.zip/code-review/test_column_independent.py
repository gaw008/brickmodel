from dataclasses import replace
from fractions import Fraction as F
from types import SimpleNamespace
import math
import pytest
from test_source_wet_column import setup
from sludge_sandbox.source_wet_column import SourceWetColumn,integrate_source_column
from sludge_sandbox import mass_wet_transport as exchange
from sludge_sandbox.source_wet_storage import SourceWetStorage

@pytest.mark.parametrize('fake',[False,True])
def test_reviewer_face_attacks_rejected(monkeypatch,fake):
    c,s=setup(monkeypatch);out=c.evaluate(s)
    phases=dict(c.storages[0].fluid_template.gas_phases)
    if fake:
        def forbidden(t):pytest.fail('fake curve invoked')
        phases['O2']=SimpleNamespace(_curve=SimpleNamespace(enthalpy_j_mol=forbidden))
    else: phases['O2'],phases['N2']=phases['N2'],phases['O2']
    with pytest.raises(ValueError):exchange.evaluate_wet_face(c.faces[0],out.gas_states[:2],c.gas_ids,phases)

def test_N4_distinct_adjacent_conduction(monkeypatch):
    c,s=setup(monkeypatch,4);out=c.evaluate(s)
    for j in range(1,4):
        rate=out.faces[j];face=c.faces[j-1]
        assert (rate.left_cell,rate.right_cell)==(j-1,j)
        tl=out.cells[j-1].inverse.point.temperature_k;tr=out.cells[j].inverse.point.temperature_k
        resistance=sum(d/k for d,k in zip(face.half_widths_m,face.conductivities_w_m_k))/face.area_m2
        assert math.isclose(rate.conduction_w,(tl-tr)/resistance,rel_tol=1e-14)
        assert rate.shared_evaluation.exchange==exchange.evaluate_wet_face(face,out.gas_states[j-1:j+1],c.gas_ids,c.storages[0].fluid_template.gas_phases).exchange

def test_cancel_second_step_preserves_complete_prefix(monkeypatch):
    c,s=setup(monkeypatch);counter=0
    def cancel():
        nonlocal counter
        counter+=1
        return counter==5
    run=integrate_source_column(c,s,duration_s=1/128,steps=2,cancel=cancel)
    assert run.status=='cancelled'
    assert len(run.states)==2 and len(run.ledgers)==len(run.observations)==1
    assert run.times_s==(F(0),F(1,256))
    assert run.evaluations_completed==run.evaluations_attempted==4

def test_roundoff_budget_refuses_fullstep(monkeypatch):
    c,s=setup(monkeypatch)
    run=integrate_source_column(c,s,duration_s=1/128,steps=1,energy_roundoff_budget_j=1e-30)
    assert run.status=='failed' and 'roundoff_budget' in run.reason
    assert run.states==(s,) and run.ledgers==() and run.energy_roundoff_used_j==0

def test_forged_storage_and_late_drift_prequery(monkeypatch):
    c,s=setup(monkeypatch)
    with pytest.raises(ValueError):replace(c,storages=(SimpleNamespace(),*c.storages[1:]))
    def forbidden(*a,**k):pytest.fail('drift reached inverse')
    monkeypatch.setattr(SourceWetStorage,'invert',forbidden)
    object.__setattr__(c,'coefficient_source_ids',('manufactured:changed',))
    with pytest.raises(ValueError,match='content_changed'):c.evaluate(s)
