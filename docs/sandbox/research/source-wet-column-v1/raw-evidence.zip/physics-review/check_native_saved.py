"""Offline exact saved-ledger audit; standard library only, no model imports."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path('/private/tmp/brick-source-wet-column-v1/native-one-step.json')
OUT=Path('/private/tmp/brick-source-wet-column-physics-v1')
raw=P.read_bytes();data=json.loads(raw);run=data['run'];checks={}
def q(v):return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)
def test(name,value):checks[name]=bool(value);assert value,name
test('completed',run['status']=='completed' and run['reason'] is None)
test('three_evaluations',run['evaluations_attempted']==run['evaluations_completed']==3)
test('complete_one_step_prefix',len(run['states'])==len(run['times_s'])==2 and len(run['ledgers'])==len(run['observations'])==1)
test('exact_time',list(map(q,run['times_s']))==[F(0),F(1,1024)])
test('material_unqualified',run['material_qualified'] is False)
old,new=run['states'];l=run['ledgers'][0];faces=l['faces'];rnd=l['roundoff']
test('three_cell_layout',len(old)==len(new)==len(l['midpoint_states'])==3)
test('face_layout',[f['face_id'] for f in faces]==[0,1,2,3])
test('duration',q(l['duration_s'])==F(1,1024))
for f in faces:
 test(f'face_{f["face_id"]}_energy_decomposition',q(f['energy_j'])==q(f['conduction_j'])+sum(map(q,f['diffusive_enthalpy_j']))+sum(map(q,f['advective_enthalpy_j']))+q(f['energy_decomposition_roundoff_j']))
for f in (faces[0],faces[-1]):test(f'face_{f["face_id"]}_closed',q(f['energy_j'])==0 and all(q(x)==0 for x in f['gas_mol']))
for i,(a,b) in enumerate(zip(old,new)):
 test(f'cell_{i}_fixed_mass_and_identity',a['solid_mass_kg']==b['solid_mass_kg']==[.2] and a['energy_model_identity']==b['energy_model_identity'])
 test(f'cell_{i}_nonnegative',all(x>=0 for x in [b['liquid_water_mol'],*b['gas_amounts_mol']]))
 test(f'cell_{i}_U',q(b['internal_energy_j'])-q(a['internal_energy_j'])==q(faces[i]['energy_j'])-q(faces[i+1]['energy_j'])+q(rnd['energy_j'][i]))
 test(f'cell_{i}_liquid',q(b['liquid_water_mol'])-q(a['liquid_water_mol'])==-q(l['phase_water_mol'][i])+q(rnd['liquid_mol'][i]))
 for k in range(3):
  test(f'cell_{i}_gas_{k}',q(b['gas_amounts_mol'][k])-q(a['gas_amounts_mol'][k])==q(faces[i]['gas_mol'][k])-q(faces[i+1]['gas_mol'][k])+(q(l['phase_water_mol'][i]) if k==2 else 0)+q(rnd['gas_mol'][i][k]))
global_changes={}
for name,measure,rounding in (
 ('U',lambda s:q(s['internal_energy_j']),sum(map(q,rnd['energy_j']))),
 ('O2',lambda s:q(s['gas_amounts_mol'][0]),sum(q(row[0]) for row in rnd['gas_mol'])),
 ('N2',lambda s:q(s['gas_amounts_mol'][1]),sum(q(row[1]) for row in rnd['gas_mol'])),
 ('total_water',lambda s:q(s['liquid_water_mol'])+q(s['gas_amounts_mol'][2]),sum(map(q,rnd['liquid_mol']))+sum(q(row[2]) for row in rnd['gas_mol']))):
 change=sum(map(measure,new))-sum(map(measure,old));test('global_'+name,change==rounding)
 global_changes[name]={'exact_change':str(change),'signed_roundoff':str(rounding),'balance_residual':'0'}
obs=run['observations'][0]
test('observation_structure',len(obs['cells'])==3 and len(obs['faces'])==4 and obs['model_identity']==run['model_identity'])
test('observation_unqualified',obs['material_qualified'] is False)
for i,c in enumerate(obs['cells']):
 test(f'observation_{i}_target_and_mass',q(c['inverse']['target_energy_j'])==q(new[i]['internal_energy_j']))
 test(f'observation_{i}_disabled_chemistry',all(q(v)==0 for v in c['chemistry']['solid_kg_s']+c['chemistry']['gas_mol_s']) and q(c['chemistry']['chemical_reference_power_w'])==0)
result={'source_path':str(P),'source_sha256':hashlib.sha256(raw).hexdigest(),'checks_passed':len(checks),'checks':checks,'global_balances':global_changes,'reported_elapsed_seconds':run['elapsed_seconds'],'scope':'Offline saved native ledger arithmetic only; no EOS/model execution, no independent material validation. Predictor roundoff excluded from accepted balances. Does not rederive flux constitutive evaluations.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'NATIVE_SAVED_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
