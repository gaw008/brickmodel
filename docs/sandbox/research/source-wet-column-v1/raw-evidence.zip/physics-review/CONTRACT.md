# SourceWetColumn minimum physics/numerics contract

Read-only review of mass_wet_transport.py, gas_transport.py and existing source storage. No repository edits. The mass-based WetPair currently implements only two cells and no external reservoir. Existing ideal_gas_reservoir/face_exchange are reusable primitives; programmed solid/fluid boundary wrappers are coupled to a different host/state/transport contract. Recommend an explicit closed/no-flux boundary type at both ends for this bounded implementation, included in identity and provenance. This does not implement the ultimate external kiln programme.

## Topology and physics

N >= 1 storage cells, N+1 oriented faces, all positive orientation toward increasing cell index. Boundary face 0 and N exactly zero; internal face f connects cell f-1 to f and is evaluated once. Cell i receives face[i]-face[i+1] for every transported species and for energy. Use the same face molar flux for both neighbors. Never compute independent left and right copies. This makes the middle cell of N>=3 sensitive to both faces and makes internal exchanges telescope exactly.

Fixed slab face area and cell half-widths must be explicit, consistent adjacent geometry; source available-fluid volume is a separate manufactured storage input, not an inference of bulk density or solid specific volume. Every cell contains the exact same dry-material source identity and the same caloric reference; cell dry masses may differ only as fixed constructor parameters. Same water backend/reference, vapor caloric and gas caloric/R/molar conventions are necessary for intercell enthalpy transport and phase closure. No solid transfer or reaction is admitted; explicitly disabled chemistry has zero dry mass, gas and chemical reference rates.

Per-cell phase rate r transfers -r liquid moles and +r H2O vapor moles. It adds zero explicit energy source: shared water liquid/vapor energy references cause the temperature response. No latent heat is added separately. Existing-liquid mode requires positive inventory; an undeclared dry cell or unsupported condensation nucleation terminates the segment. Do not clip or automatically change the mode.

One internal face carries mixture-averaged diffusion, Darcy advection, species enthalpy and conduction from the existing primitives. Diffusive enthalpy is evaluated at the defined face temperature; advective enthalpy uses the donor temperature, species order and the same caloric sources as storage. A reversal changes the donor. Pure conduction must reduce to q=G(Tleft-Tright), G=A/(dl/kl+dr/kr), with a zero-conductivity side yielding zero conduction according to the existing primitive.

## Exact ledger and binary projection

For each accepted midpoint step h, preserve h as a rational and each shared face increment as h*F(rate). Likewise phase increments h*F(r). Sum all relevant exact increments into each cell's old binary64 state viewed as F. Project once per inventory/energy component after aggregation; define signed projection correction rho=F(projected)-exact_candidate. Store accepted-step corrections and cumulative signed corrections explicitly. Predictor corrections must not enter the accepted trajectory ledger; the accepted midpoint step is formed from the previous accepted state, not from the predictor.

Closed-domain global U change equals the sum of signed energy projection corrections exactly. O2 and N2 totals likewise differ only by their respective projection corrections. Global liquid+vapor water change equals liquid-plus-vapor corrections; the phase and internal face increments cancel exactly. Dry masses remain bitwise unchanged and have zero ledger increments. Do not round independent left/right face increments or apply sequential face writes to the middle cell.

Check nonnegative gas/liquid inventories on the exact candidates and then representation. Nonzero underflow must fail, not silently become zero. Existing-liquid mode needs strictly positive liquid. Each entire candidate tuple is admitted and inverse-evaluated before appending any state/time/ledger. If midpoint or endpoint fails, return the complete previously accepted prefix with its times, states and ledgers aligned. No partial-cell write, fabricated event location, clipping, or automatic timestep change. Wall/cancel conditions similarly preserve accepted prefix.

The fixed-step midpoint path is a software integration algorithm, not admitted to the old exact-event, adaptive, resume, moving mesh or boundary-program wrappers solely because its state looks similar. Identity must cover ordered storages, faces, modes, policies, chemistry, source closures and explicit boundary policy.

## Boundary extension later

An existing reservoir primitive could later support a finite explicit extension. It requires two separately oriented boundary faces, explicit external P/T/full composition/R/molar conventions, source-compatible incoming species enthalpies, donor switching for outflow, and a signed external ledger. Constant prescribed species source without its incoming enthalpy is insufficient; a constant total power alone is valid as declared heat input. Neither constitutes a full kiln programme or physical heat-transfer coefficient evidence. Do not add these obligations to the current closed-column milestone implicitly.

## Independent test design

A constant-capacity manufactured caloric seam permits an independent exact discrete heat operator for N=3: C dT/dt = -B diag(G) B^T T. With incidence columns (+1,-1,0) and (0,+1,-1), initial nonuniform T and both G positive, compare one software midpoint step against [I+hL+(hL)^2/2]T. A separate matrix exponential/DOP853 is an ODE reference, not an exact match to midpoint at finite h; use h refinement only if testing order.

For the actual source caloric case, compute the derivative by the independent scalar pressure closure and printed source polynomial already reviewed, then a bounded few-point/short-step reference only. Because Cp(T) varies and real water responds to pressure, a constant-C Laplacian exponential is not an exact source-host solution. Small native runtime probe precedes any broader calculation. No long trajectory or new source search.

Material qualification remains false: actual material volume, permeability/diffusivity/conductivity/phase coefficient evidence and same-material experimental matching are absent. Native EOS plus manufactured transport is a numerical coupling test.
