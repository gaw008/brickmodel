import json,time
from dataclasses import replace
from pytest import MonkeyPatch
from test_mass_wet_transport import setup
from sludge_sandbox.mass_wet_transport import integrate_wet_pair
from sludge_sandbox.deforming_solid_storage import _canonical,_digest
start=time.monotonic()
with MonkeyPatch.context() as mp:
 pair,initial=setup(mp)
 point=pair.evaluate(initial)
 run=integrate_wet_pair(pair,initial,duration_s=.001,steps=1)
 assert run.status=='completed',run.reason
 normalized=replace(run,elapsed_seconds=0.)
 print(json.dumps({'elapsed_s':time.monotonic()-start,'identity':pair._identity,'point_digest':_digest(point),'run_digest':_digest(normalized),'point':_canonical(point),'run':_canonical(normalized)},indent=2))
