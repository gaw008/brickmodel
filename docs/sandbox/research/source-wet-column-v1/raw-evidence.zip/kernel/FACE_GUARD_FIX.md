# Public face caloric admission fix

Independent review reproduced swapped O2/N2 phase curves changing power from 135.81982271568032 to 135.3347122045993 W; an arbitrary fake curve callback also executed. Pre-fix source/test preserved here, reviewer probe remains in /private/tmp/brick-source-column-code-review-v1.

All phases now require exact IdealGasPhase and supported caloric classes with actual source/continuous Shomate or water leaves. Original adapter selection and mass identity checks are reapplied. Before any enthalpy callback, every phase must match the named species, both GasState molar masses and R, and the declared per-species mol basis/common standard formation reference. Both full storage caloric-source/energy-origin bindings remain the caller's responsibility; the face interface cannot infer these from GasState.

Seven new negative tests (species swap, fake phase, fake leaf, molar mass, R, energy reference, molar basis) all RED before the fix: 7 failed in 1.15s (wall 1.250s). Final new + existing transport tests: 29 passed in 8.26s (wall 8.369s). The frozen old complete observation, pair identity, and all one-step run contents still match exactly. No numerical tolerance changes, native liquid EOS, install or commit.
