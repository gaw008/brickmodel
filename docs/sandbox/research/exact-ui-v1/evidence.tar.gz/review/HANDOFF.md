# Exact time UI candidate

Temporary only; no repository, runner, service, installation or EOS changes.

Material description now follows actual model_id: free traction/common tangent versus prescribed motion. The JSON apply path refreshes this description. Exact presentation schema uses elapsed-from-original-start display coordinates, while exact_times numerator/denominator strings remain untouched. BigInt cross-products check strict original exact order; display coordinates may coincide, and all points are retained in their original order. No Number conversion of exact rational strings, sorting or deduplication. Original absolute origin appears verbatim in plot notes. This is structural UI validation of the saved presentation, not an independent rational-to-float projection proof.

Different absolute/elapsed semantics disable the combined time chart, with an explicit note; each run's final spatial points remain available and labeled. Malformed/unknown time metadata refuses time series. Same elapsed semantics align each run at its original start, explicitly labeled as such; they do not assert identical absolute starts. Legacy absolute-time series, exports, source trace and mechanical full-vector behavior remain.

Validation command: SANDBOX_UI_SCRIPT=/private/tmp/brick-exact-ui-v1/app.js node --test /private/tmp/brick-exact-ui-v1/ui_exact_time_test.cjs tests/sandbox/ui_export_test.cjs tests/sandbox/ui_grid_test.cjs tests/sandbox/ui_mechanical_test.cjs tests/sandbox/ui_mechanical_trace_test.cjs

Actual results in tests.log. No browser execution claimed; root is running the old static server and a separate native lifecycle. Intended changes are two assets plus the portable Node test (SANDBOX_UI_SCRIPT may override candidate path; formal test default should resolve repository app.js).
