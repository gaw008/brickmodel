# Independent exact-time UI review

Decision: BLOCK pending unknown-schema refusal.

Scope: frozen candidate app.js c3cae1dc6a4fc54990a8d03b97b9f8318c8a48b6b88a3dfe006598bde85b21a3, index.html c397db1e9621b020052624ca24febf95072040e4c534f1315c8b9084e0f913a4, portable test 6b22ebfa1dffc1bc15b44a009982d7021561c8ed92eca3736ab19da958892a0f. All independently hashed against FREEZE.json and matched. Read HANDOFF and both patches plus surrounding actual app handlers. Repository staged/working diffs inspected: candidate assets are not applied, so review is against supplied frozen patches, not a PR. PR merge readiness unavailable and not claimed. JavaScript-only changes: TypeScript check inapplicable. No package.json/eslint configuration or installed eslint executable found; lint unavailable.

## HIGH: unknown clock schema silently classified absolute

app.js timeDescriptor, lines 109-111: every schema other than exact_core_presentation_v1 enters legacy handling. A record declaring schema unknown_elapsed_clock_v2 and times_s [0,1] is accepted as absolute time when exact_times/time_semantics are absent. This contradicts the declared refusal of unknown time semantics and can overlay an unrecognized elapsed clock with genuine legacy absolute time. Preserve the actual schema-less legacy shape, but reject unknown explicit schemas (or enumerate genuinely supported historical schemas). Add a regression asserting refusal of unknown schema, not merely malformed exact metadata.

Independent executable reproduction: review_extra_test.cjs, test `review unknown schema is not implicitly legacy absolute`; independent-review-tests.log records actual assertion failure true !== false. Extra suite: 5 passed, 1 failed.

## Verified behavior

Independent rerun of supplied portable tests and four existing UI suites: 15 passed, 0 failed; independent-regression-tests.log. Additional different-origin exact runs compare using explicitly labeled elapsed-from-each-original-start coordinates and print both untouched origins; passed. Exact ordering uses BigInt cross-products without Number conversion of numerator/denominator strings. Equal projected coordinates remain in series order; no sorting or deduplication introduced. Mixed legacy absolute/exact elapsed empties combined time series, while spatial data remains. New metadata and labels enter DOM via textContent; no new HTML injection sink. Export raw-text preservation and stale-response guards pass existing regressions. Material descriptions distinguish free versus prescribed mechanics.

Limits: no browser run or native EOS execution performed by reviewer; root owns those separate observations. UI validates declared projection structure, not numerical projection correctness. This review does not qualify manufactured material physics. No repository, package installation, runtime or frozen candidate files modified; only review artifacts added to temporary directory.

## Final narrow re-review: APPROVE

Root corrected the sole production line by rejecting any explicit non-exact schema before the schema-less legacy branch. Independently compared final app.js to before-unknown-schema-fix/app.js: the guard is the only production change. Unknown, null and empty schemas now refuse, while genuine schema-less legacy remains valid. Independent final regression run: 22 tests passed, 0 failed (independent-fixed-tests.log), including the original reviewer failure and different exact origins. Prior HIGH is resolved; no remaining blocking findings in this candidate scope.

Final independently measured hashes:

- app.js: 6a05da78c0c4573112a014009578ba6eba7e2072e7a42d570c8de4739b42227b
- index.html: c397db1e9621b020052624ca24febf95072040e4c534f1315c8b9084e0f913a4
- ui_exact_time_test.cjs: c38b5bf3c17bc9cf3cb221f74d4107b4d5b5ace232025e629ac8a229f325823d

FREEZE.json still described the old candidate at re-review time; root should regenerate final freeze and patch packaging before applying. Approval binds the hashes above, not the stale freeze. Original RED evidence is retained. No source, install or runtime changes made by reviewer.
