"""Read-only manifest/stdout/XML checks; does not import package or invoke codec."""
from pathlib import Path
from collections import Counter
import hashlib,json,time,xml.etree.ElementTree as ET
BASE=Path('/private/tmp/brick-source-record-v1');ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github');start=time.perf_counter()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
run=json.loads((BASE/'root/saved-exercise/RESULT.json').read_bytes())
assert run['status']=='passed' and run['checks']==1813 and run['live_physics_calls']==0
assert all(run[k] is False for k in ('material_qualified','resume_authorized','full_run_validated','source_assets_verified'))
records=run['records'];assert len(records)==111 and len({r['record_file'] for r in records})==111
assert dict(Counter(r['kind'] for r in records))=={'n3':32,'n1':32,'programmed':47}
assert run['checks']==7+sum(9+3*r['cell_count'] for r in records)
for group,count in [('n3',32),('n1',32),('programmed',47)]:assert [r['capture_index'] for r in records if r['kind']==group]==list(range(count))
for item in records:
 p=BASE/'root/saved-exercise'/item['record_file'];b=p.read_bytes();assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['record_sha256']
 d=json.loads(b);assert d['sample_binding']==item['sample_binding'] and d['schema']=='source_observation_record_v1'
 assert d['material_qualified'] is False and d['resume_authorized'] is False
 assert json.dumps(d,sort_keys=True,separators=(',',':'),allow_nan=False).encode()==b
parity=json.loads((BASE/'root/cli-parity.json').read_bytes());assert parity['status']=='passed' and parity['checks']==7 and parity['capture_index']==16 and parity['capture_ordinal']==17
for item in parity['files']:assert sha(BASE/'root'/item['name'])==item['sha256']
imported=json.loads((BASE/'root/cli-import.json').read_bytes());inspected=json.loads((BASE/'root/cli-inspect.json').read_bytes())
assert imported['selected_cell_index'] is None and inspected['selected_cell_index']==1
assert inspected['cells']==[imported['cells'][1]]
assert {k:v for k,v in inspected.items() if k not in ('cells','selected_cell_index')}=={k:v for k,v in imported.items() if k not in ('cells','selected_cell_index')}
identity=json.loads((BASE/'root/installed-identity.json').read_bytes());assert identity['status']=='matched' and identity['module_count']==131 and identity['package_file_count']==138
assert len(identity['files'])==138
for item in identity['files']:
 assert sha(Path(identity['source'])/item['path'])==item['sha256']==sha(Path(identity['installed'])/item['path'])
freeze=json.loads((BASE/'root/EXECUTION_FREEZE.json').read_bytes())
for item in freeze['files']:assert sha(ROOT/item['path'])==item['sha256'] and (ROOT/item['path']).stat().st_size==item['bytes']
suites=[]
for name in ('source-final.xml','installed-final.xml'):
 p=BASE/'root'/name;t=ET.parse(p).getroot();s=list(t.iter('testsuite'));assert len(s)==1 and s[0].attrib['tests']=='93' and all(s[0].attrib[k]=='0' for k in ('failures','errors','skipped'))
 suites.append({'file':name,'sha256':sha(p),**s[0].attrib})
result={'status':'approved','scope':'Read-only saved-file hashes/canonical framing/manifests/CLI stdout/XML; no package import or replay','saved_result_sha256':sha(BASE/'root/saved-exercise/RESULT.json'),'saved_records_verified':111,'runner_reported_checks':1813,'reported_run_seconds':run['wall_seconds'],'reported_live_physics_calls':0,'package_files_source_installed_matched':138,'python_modules':131,'execution_files_current_matched':len(freeze['files']),'cli_parity_sha256':sha(BASE/'root/cli-parity.json'),'cli_stdout_original_cell_selection_verified':True,'test_suites':suites,'reviewer_wall_seconds':time.perf_counter()-start,'reviewer_model_calls':0,'reviewer_eos_calls':0,'reviewer_codec_calls':0}
(BASE/'code-review/SAVED_EXERCISE_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
