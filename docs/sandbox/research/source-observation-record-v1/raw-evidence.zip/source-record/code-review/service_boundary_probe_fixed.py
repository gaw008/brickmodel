"""Bounded file/JSON boundary probes only; no model or EOS calls."""
from pathlib import Path
import contextlib, hashlib, io, json, time
from unittest.mock import patch
from sludge_sandbox.cli import main
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_wet_storage import SourceWetStorage
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.water_heos import HEOSWaterProperties
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
HERE=Path('/private/tmp/brick-source-record-v1/code-review/service-fixed-review')
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
started=time.perf_counter()
def forbidden(*args,**kwargs):
    raise AssertionError('independent_probe_called_model_or_eos')
r={'scope':'One actual nested outer identity payload through new CLI; no native/model construction','source_sha256':{},'cases':[]}
for name in ('cli','source_observation_service','source_observation_record','source_observation_schema'):
 p=ROOT/'src/sludge_sandbox'/f'{name}.py'
 r['source_sha256'][name]=hashlib.sha256(p.read_bytes()).hexdigest()
 if name in ('cli','source_observation_service'):
  (HERE/f'{name}-before-boundary-probe.py').write_bytes(p.read_bytes())
doc=json.loads((ROOT/'tests/sandbox/fixtures/source-observation-v1/native-captures.json').read_bytes())
value='nested'
for _ in range(600):
 value=[value]
doc['captures'][0]['operator_identity']=value
source=HERE/'nested-outer-identity.json'
source.write_text(json.dumps(doc))
output=HERE/'nested-outer-identity-output.json'
stdout=io.StringIO()
with contextlib.ExitStack() as stack:
 for cls in (ExactSourceColumn,SourceWetStorage,WaterProperties,HEOSWaterProperties,WaterChemicalPotential):
  stack.enter_context(patch.object(cls,'__init__',forbidden))
 for cls, name in ((ExactSourceColumn,'evaluate'),(SourceWetStorage,'evaluate'),(SourceWetStorage,'invert'),(WaterProperties,'state_tp'),(HEOSWaterProperties,'state_tp'),(WaterChemicalPotential,'equilibrium_at_liquid_tp')):
  stack.enter_context(patch.object(cls,name,forbidden))
 with contextlib.redirect_stdout(stdout):
  try:
   code=main(['source-observation-import',str(source),'--capture-index','0','--output',str(output)])
   result={'outcome':'returned','returncode':code}
  except Exception as exc:
   result={'outcome':'escaped_exception','exception':type(exc).__name__,'message':str(exc)}
 result['stdout']=stdout.getvalue();result['output_exists']=output.exists()
 r['cases'].append({'id':'outer_identity_depth600','result':result})
r['wall_seconds']=time.perf_counter()-started
r['model_calls']=0;r['eos_calls']=0
(HERE/'service-boundary-probe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
