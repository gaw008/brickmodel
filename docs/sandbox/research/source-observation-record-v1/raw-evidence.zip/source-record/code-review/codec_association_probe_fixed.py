"""Narrow passive counterexamples from two original saved observations; no EOS."""
from pathlib import Path
from dataclasses import replace
from collections.abc import Mapping
import contextlib,hashlib,json,time
from unittest.mock import patch
from sludge_sandbox.source_observation_record import SourceObservationContext,import_saved_source_sample,encode_source_sample,decode_source_sample
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_wet_storage import SourceWetStorage
from sludge_sandbox.rigid_storage import RigidStorage
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.water_heos import HEOSWaterProperties
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
HERE=Path('/private/tmp/brick-source-record-v1/code-review/codec-fixed-review'); ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
start=time.perf_counter(); result={'scope':'Actual fixture passive mutations, not new physical calculations','checks':[],'source_sha256':{}}
for name in ('source_observation_record','source_observation_schema'):
 p=ROOT/'src/sludge_sandbox'/f'{name}.py'; result['source_sha256'][name]=hashlib.sha256(p.read_bytes()).hexdigest(); (HERE/f'{name}-before-association-probe.py').write_bytes(p.read_bytes())
def forbid(*args,**kwargs):raise AssertionError('unexpected_model_or_eos')
def tup(v): return tuple(tup(x) for x in v) if isinstance(v,list) else v
source=json.loads((ROOT/'tests/sandbox/fixtures/source-observation-v1/native-captures.json').read_bytes()); c=source['captures'][0]
context=SourceObservationContext(tup(c['operator_identity']),tup(c['energy_identity']),tuple(source['adapter_provenance']['fixed_dry_mass_kg']),tup(c['interface_modes']))
with contextlib.ExitStack() as stack:
 for cls in (ExactSourceColumn,SourceWetStorage,RigidStorage,WaterProperties,HEOSWaterProperties,WaterChemicalPotential):stack.enter_context(patch.object(cls,'__init__',forbid))
 for cls,name in ((ExactSourceColumn,'evaluate'),(SourceWetStorage,'evaluate'),(SourceWetStorage,'invert'),(RigidStorage,'evaluate_at_temperature'),(WaterProperties,'state_tp'),(HEOSWaterProperties,'state_tp'),(WaterChemicalPotential,'equilibrium_at_liquid_tp')):stack.enter_context(patch.object(cls,name,forbid))
 baseline=import_saved_source_sample(json.dumps({'state':c['packed_input'],'evaluation':c['evaluation'],'role':c['phase']}).encode(),context=context)
 baseline.check(); result['baseline_roundtrip']=True
 sample=baseline.sample; raw=sample.evaluation.source_evaluation
 changed_face=replace(raw.faces[1],shared_evaluation=None)
 changed_mech=replace(raw.cells[0].inverse.point.fluid.mechanical,source_ids=('forged:missing-original-water-sources',))
 changed_cell=replace(raw.cells[0],inverse=replace(raw.cells[0].inverse,point=replace(raw.cells[0].inverse.point,fluid=replace(raw.cells[0].inverse.point.fluid,mechanical=changed_mech))))
 cases=[('missing_internal_gas_observation',replace(raw,faces=(raw.faces[0],changed_face,*raw.faces[2:]))),('swapped_cell_gas_states',replace(raw,gas_states=(raw.gas_states[1],raw.gas_states[0],*raw.gas_states[2:]))),('detached_mechanical_source_labels',replace(raw,cells=(changed_cell,*raw.cells[1:])))]
 for id,changed in cases:
  modified=replace(sample,evaluation=replace(sample.evaluation,source_evaluation=changed))
  try:
   encoded=encode_source_sample(modified,context=context);out=decode_source_sample(encoded);out.check()
   outcome={'accepted':True,'canonical_sha256':out.sha256,'material_qualified':out.material_qualified}
   (HERE/(id+'-accepted.json')).write_bytes(encoded)
  except Exception as exc:outcome={'accepted':False,'exception':type(exc).__name__,'reason':str(exc)}
  result['checks'].append({'id':id,**outcome})
result['wall_seconds']=time.perf_counter()-start;result['model_calls']=0;result['eos_calls']=0
(HERE/'codec-association-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
