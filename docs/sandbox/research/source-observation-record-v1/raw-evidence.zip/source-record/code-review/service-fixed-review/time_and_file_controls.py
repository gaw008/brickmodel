"""Actual new service controls; two saved captures, no physics."""
from pathlib import Path
import contextlib, hashlib, io, json, time
from unittest.mock import patch
from sludge_sandbox.cli import main
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_wet_storage import SourceWetStorage
from sludge_sandbox.rigid_storage import RigidStorage
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.water_heos import HEOSWaterProperties
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential

HERE = Path('/private/tmp/brick-source-record-v1/code-review/service-fixed-review')
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
start = time.perf_counter()
def forbidden(*a, **k):
    raise AssertionError('unexpected_model_or_eos')
fixture = ROOT / 'tests/sandbox/fixtures/source-observation-v1/native-captures.json'
results = []
with contextlib.ExitStack() as stack:
    for cls in (ExactSourceColumn, SourceWetStorage, RigidStorage, WaterProperties, HEOSWaterProperties, WaterChemicalPotential):
        stack.enter_context(patch.object(cls, '__init__', forbidden))
    for cls, name in ((ExactSourceColumn, 'evaluate'), (SourceWetStorage, 'evaluate'), (SourceWetStorage, 'invert'), (RigidStorage, 'evaluate_at_temperature'), (WaterProperties, 'state_tp'), (HEOSWaterProperties, 'state_tp'), (WaterChemicalPotential, 'equilibrium_at_liquid_tp')):
        stack.enter_context(patch.object(cls, name, forbidden))
    for name, altered in [('ordinary_file_symlink', False), ('outer_time_mismatch', True)]:
        source = HERE / (name + '-input.json')
        output = HERE / (name + '-output.json')
        if altered:
            document = json.loads(fixture.read_bytes())
            document['captures'][0]['time']['fields']['seconds']['numerator'] += 1
            source.write_text(json.dumps(document))
        else:
            source.symlink_to(fixture)
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            code = main(['source-observation-import', str(source), '--capture-index', '0', '--output', str(output)])
        summary = json.loads(stdout.getvalue())
        results.append({'case': name, 'code': code, 'status': summary['status'], 'reason': summary.get('reason'), 'output_exists': output.exists()})
        if altered:
            assert code == 1 and summary['reason'] == 'source_capture_time_mismatch' and not output.exists()
        else:
            assert code == 0 and summary['status'] == 'observation_record_valid' and output.exists()
result = {'source_sha256': hashlib.sha256((ROOT / 'src/sludge_sandbox/source_observation_service.py').read_bytes()).hexdigest(), 'checks': results, 'wall_seconds': time.perf_counter() - start, 'model_calls': 0, 'eos_calls': 0}
(HERE / 'time-and-file-controls.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
