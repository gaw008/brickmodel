"""Execute only the actual reader AST against an idle FIFO, never import solver."""
from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,time
here=Path('/private/tmp/brick-source-record-v1/code-review')
source=Path('/Users/wanggaoying/Desktop/brickmodel-github/src/sludge_sandbox/source_observation_service.py')
text=source.read_text();tree=ast.parse(text)
selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('_require','_read_bounded')]
child='from pathlib import Path\n'+ast.unparse(ast.Module(body=selected,type_ignores=[]))+'\n_read_bounded(Path(__import__("sys").argv[1]), 1024, "test_limit")\n'
fifo=here/'idle-input.fifo'
os.mkfifo(fifo)
start=time.perf_counter();result=None
try:
 try:
  p=subprocess.run([sys.executable,'-c',child,str(fifo)],capture_output=True,text=True,timeout=.3)
  result={'outcome':'returned','returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 except subprocess.TimeoutExpired:
  result={'outcome':'external_timeout','limit_seconds':.3,'child_killed_and_reaped':True}
finally:
 fifo.unlink()
r={'scope':'Only copied actual _require/_read_bounded AST on FIFO; no production imports or model/EOS','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'result':result,'wall_seconds':time.perf_counter()-start}
(here/'file-boundary-probe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
