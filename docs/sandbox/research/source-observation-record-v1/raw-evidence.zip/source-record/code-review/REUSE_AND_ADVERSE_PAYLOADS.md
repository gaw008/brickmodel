# Source observation codec: independent preparation

Baseline: `ac04d8bd0641f7d74d33b42009d6fc54a1bf0128`. Read-only preparation, before the new production codec is available. No production edits, model construction, EOS evaluation, integration, installation, or old test execution. Findings below are design/test obligations, not claims of defects in the forthcoming implementation.

## Actual saved input

The current N3 native artifact is `/private/tmp/brick-source-multicell-transition-v1/root/native-result.json`, 45,527,737 bytes, SHA-256 `2660d33ec0e832e006d5adcccd8ddcf38cc314ac5e65a17830cdf2f73cbdc51d` (verified from bytes). Its 32 captures contain 31 passive record classes, 192 float64 arrays, and 800 canonical Fraction leaves. The first 16 captures are all wet; the last 16 have modes `(existing_liquid, depleted_no_nucleation, existing_liquid)`.

`NATIVE_CAPTURE_INVENTORY.json` records all class names, counts, first actual JSON pointers, array shapes, and qualification strings. `ADVERSE_PAYLOADS.json` specifies 38 focused mutation/control cases; each base pointer was checked against the actual original JSON. The mutations have not been run through a new codec and are not 38 reported failures.

The saved observation shape is N cells by four mol inventories ordered `(liquid_water, O2, N2, H2O)`, with N energies in J. Rates retain `(N+1,4)` oriented face mol/s, `(N+1,)` face W, `(N,4)` local mol/s, and `(N,)` extra W. The saved fixed solid mass is one kg value per cell, outside those four mol slots. Temperature is K, pressure Pa, volume m3. N3 source storage objects are distinct even where their content identities coincide.

The outer native capture includes historical object-identity booleans, phase, ordinal and interface modes. Those booleans are observations from that run; decoded records cannot recreate `is` identity or authorize a new live adapter/storage association. The public record may explicitly import these as historical metadata or limit itself to a `SavedSourceSample`; it must state which boundary it supports. Importing the whole native capture requires checking its time, packed input, identities and modes against the nested observation.

## Reuse with narrow boundaries

- `exact_record.py` supplies established patterns for strict duplicate-key rejection, canonical finite binary64/Fraction encodings, exact field sets, immutable decoded arrays/mappings, and content bindings. Its current registry and resume semantics belong to a different host. Extending source observation support must not fabricate that host or claim its run/resume authorization.
- `source-net-panel-v1/replay_native.py` has an explicit passive class allowlist and checks all dataclass fields by reconstructing init fields and re-encoding the complete object. That protects constructor-derived GasState fields without assigning `init=False` fields. Its only missing class for these 32 captures is `LiquidSourceColumnRates`.
- The old research decoder is tied to a frozen artifact SHA. Its plain `json.loads` does not reject duplicate keys; malformed tag-shaped dictionaries fall back to plain mappings; array conversion can coerce numeric strings/bools and shape equality is not an integer-type check. It should not be exposed unchanged as an untrusted public reader. These are scope differences, not regressions in the previous fixed-artifact experiment.
- `source_net_panel._validate` already checks packed/source state binding, fixed kg, operator/energy layout, inactive chemistry, N-cell rates, oriented shared face mapping and programmed boundary time. Reuse those relations rather than cloning them. It is not a complete nested schema: fields typed `object`, such as `SourceColumnCell.inverse`, require explicit expected classes and structural validation at the codec boundary.
- `SourceWetPoint`, `SourceWetInverse`, and several saved state classes have few or no constructor guards. Canonical roundtrip alone cannot reject a valid allowed class inserted into the wrong semantic position, nor a coherently changed qualification. Explicit position/type and fixed qualification checks are needed.

## Essential rejection and preservation cases

The companion JSON provides concrete pointers for unknown classes; missing/extra wrapper and dataclass fields; a permitted class in the wrong field; NaN/Infinity and exponent overflow; bool-as-integer; non-integer/negative/huge array shapes; wrong dtype; ragged, bool or string array values; noncanonical/bool/negative-denominator Fractions; duplicate JSON keys; material and direction-certification escalation; capture time mismatch; inventory/energy/model/species binding changes; derived GasState tamper; and mode mismatch.

Keep read arrays immutable or make every use revalidate their binding. The established bytes-backed array construction also prevents simply re-enabling writeability. A serialized content digest establishes internal consistency or comparison with a caller-supplied expected digest. It does not authenticate historical measurements: an adversary who coherently rewrites a whole record and its digest cannot be disproved by passive decoding alone.

Do not reject a legitimate dry observation merely because `WetPhaseEvaluation.equilibrium` still includes liquid chemical metadata. The actual dry selected cell has zero liquid inventory, no mechanical liquid pressure, zero liquid volume, and a dry `LiquidTransportState` without liquid molar volume/enthalpy; its recorded chemical reference remains present. The wet cells remain wet. Preserve all fixed-temperature-only liquid direction and conditional volume/error qualifications.

A passive read/save roundtrip should run with provider constructors (including native HEOSCandidate construction), EOS methods, storage evaluate/invert, adapter evaluate and integrator entry points forbidden. Passive metadata constructors and derived GasState arithmetic are acceptable; no dynamically named class import or callback invocation is needed.

## Reusable real golden inputs

| Input | Verified bytes and SHA-256 | Coverage |
|---|---|---|
| Current N3 native JSON | 45,527,737; `2660d33ec0e832e006d5adcccd8ddcf38cc314ac5e65a17830cdf2f73cbdc51d` | 32 `LiquidSourceColumnRates` captures, 16 wet plus 16 mixed wet/dry, all cell records |
| `docs/sandbox/research/exact-source-column-v1/native-result.json` | 6,476,290; `033dccd09ed268eeb2ce9570a37d52f66d4eb5da18b68f2f44a89bd01054c4f2` | 47 `ProgrammedLiquidSourceRates` captures; the older decoder already uses a subset with fixed input SHA |
| `/private/tmp/brick-source-dry-shared-pressure-v1/root/native-result.json` | 14,524,919; `a9d2d658a259e72f871e4f96c8d3e0172def2720a2901bc91c06e78e5a97d4dc` | 32 N1 `SourceColumnRates` captures without liquid transport, wet and dry |

These are original saved observations, not new material facts. A schema may support all three families or explicitly reject an out-of-scope family. Failed-attempt capture support, complete transition persistence, restart authority, and reconstruction of live model instances are separate deliverables and must not be implied by successful observation roundtrip.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: PREPARATION COMPLETE — no new production implementation was reviewed or approved. The actual codec/CLI and its failure tests remain to be independently reviewed when frozen.
