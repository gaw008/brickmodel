# Source observation service/CLI interim review

Reviewed the new `source_observation_service.py`, CLI additions, CLI tests and two-capture native fixture. Production files remain read-only. Codec author is still fixing an annotation compatibility issue, so this is not final codec approval.

The fixture is 307,778 bytes, SHA-256 `22402009534a13111e0989a6f4d93bb22f313ee306a99f6bc328033f43e0e5d3`. Both full capture objects equal original native captures 0 and 16, retaining ordinals 1 and 17. File provenance and the declared observation-only, no-assets-authentication/no-resume/no-material-validation scope are accurate.

[MEDIUM] Deep outer identity escapes the structured failure boundary

File: `src/sludge_sandbox/source_observation_service.py`, `_tuple_tree` and context construction in `import_source_capture`.

An otherwise original fixture with a 600-level list in the selected `operator_identity` passes JSON parsing, then raises `RecursionError` before reaching the codec. CLI returns no structured JSON because it catches only ValueError/OSError. Actual reproduction: 0.052217625 s, stdout empty, output absent, no model/EOS calls. See `service_boundary_probe.py`, `service-boundary-probe.json` and preserved input/source snapshots. Reject the fixed identity schema before recursive conversion, or explicitly budget and translate conversion recursion.

[MEDIUM] Non-regular file can block the nominally bounded reader indefinitely

File: `src/sludge_sandbox/source_observation_service.py`, `_read_bounded`.

The size check alone accepts an idle FIFO (size zero). Opening it in blocking mode then waits for a writer indefinitely. A pure AST extraction of the actual reader against an actual FIFO hit a 0.3 s external timeout; its child was killed and reaped, and the FIFO removed. No production/model imports occurred. See `file_boundary_probe.py` and `file-boundary-probe.json`. Safely open without blocking, require a regular file from the opened descriptor, and preserve the existing byte cap. Ordinary file symlinks can remain supported.

A third static gap was sent to Root for confirmation: outer capture `time` is never forwarded or compared, so any mismatch versus nested `evaluation.time` is invisible to codec validation. This has not yet been exercised through a working codec and is not counted below.

The writer uses a temporary file, flush/fsync and exclusive hard-link publication, preserving existing output even when the input and output path coincide. Summary reads the actual saved cell quantities and keeps original cell indices; it does not recompute EOS or turn the reported fixed-temperature pressure error into a full inverse qualification. Existing author tests already cover duplicate keys and no-overwrite, so they were not rerun here.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 2 | info |
| LOW | 0 | pass |

Verdict: INTERIM — two concrete boundary defects require closure before final service approval. Final codec/CLI review is pending frozen implementation bytes.
