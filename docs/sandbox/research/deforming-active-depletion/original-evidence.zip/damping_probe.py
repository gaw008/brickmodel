from pathlib import Path
import json,hashlib,math
import CoolProp.CoolProp as CP
from sludge_sandbox.water_properties import load_water_properties
r=Path(__file__).resolve().parent
DATA=Path('/Users/wanggaoying/Desktop/brickmodel-github/data/sandbox/water')
# Construction verifies the installed source/runtime before the isolated native probe.
w=load_water_properties(DATA,backend='heos',backend_manifest=DATA/'heos-8.0.0-approved-manifest.json')
x=json.loads((r/'replay-result.json').read_text())
c=next(v for v in x['kernel_failure_context'] if v['label']=='chemical')
t=c['temperature_k'];assert len(c['coexistence'])==8
start=c['coexistence'][0]['rho'];full=c['coexistence'][1]['rho']
assert start==c['coexistence'][2]['rho'] or start[0]==c['coexistence'][2]['rho'][0]
a=CP.AbstractState('HEOS','Water')
def state(rho,phase):
    a.specify_phase(CP.iphase_liquid if phase=='liquid' else CP.iphase_gas)
    try:
        a.update(CP.DmassT_INPUTS,rho,t)
        return dict(p=a.p(),h=a.hmass(),u=a.umass(),s=a.smass(),rho=a.rhomass(),temperature=a.T())
    finally:a.unspecify_phase()
rows=[]
for fraction in (0.,1.,.5,.25):
    densities=[u*math.exp(fraction*math.log(v/u)) for u,v in zip(start,full)] if fraction not in (0.,1.) else (start if fraction==0 else full)
    l,v=state(densities[0],'liquid'),state(densities[1],'vapor')
    dp=l['p']-v['p'];dg=(l['h']-t*l['s'])-(v['h']-t*v['s'])
    rows.append(dict(fraction=fraction,densities=densities,liquid=l,vapor=v,dp=dp,dg=dg,original_coexistence_gates=abs(dp)<=1e-4 and abs(dg)<=1e-6))
result=dict(scope='isolated native EOS backtracking feasibility only; no solver fix or candidate admission',temperature_k=t,implementation=json.loads(w.implementation.canonical_json),replay_sha256=hashlib.sha256((r/'replay-result.json').read_bytes()).hexdigest(),rows=rows)
(r/'damping-probe-result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps([{'fraction':x['fraction'],'dp':x['dp'],'dg':x['dg'],'original_coexistence_gates':x['original_coexistence_gates']} for x in rows],indent=2))
