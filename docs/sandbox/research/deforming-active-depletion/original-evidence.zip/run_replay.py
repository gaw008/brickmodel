from pathlib import Path
import sys,json
r=Path('/Users/wanggaoying/Desktop/brickmodel-github');d=Path('/private/tmp/brick-deforming-depletion')
sys.path.insert(0,str(r/'docs/sandbox/research/research-process-supervisor'))
from supervisor import run_attempt
script,attempt=sys.argv[1:]
inputs=list(Path('/private/tmp/brick-water-backend-probe/venv/lib/python3.12/site-packages/sludge_sandbox').glob('*.py'))+list((r/'src/sludge_sandbox').glob('*.py'))+list((r/'tests/sandbox').glob('*.py'))+list((r/'data/sandbox/water').rglob('*'))+list(d.glob('*.py'))+[d/'callback-result.json',d/'depletion-result.json']+[d/'PLAN.json',r/'docs/sandbox/research/research-process-supervisor/supervisor.py']
v=run_attempt(d/attempt,['/usr/bin/env',f'PYTHONPATH={r}/tests/sandbox','PYTHONDONTWRITEBYTECODE=1','/private/tmp/brick-water-backend-probe/venv/bin/python',str(d/script)],cwd='/private/tmp',input_paths=[p for p in inputs if p.is_file()],timeout_s=30)
print(json.dumps({k:v[k] for k in ('status','returncode','elapsed_s','cleanup')},indent=2))
