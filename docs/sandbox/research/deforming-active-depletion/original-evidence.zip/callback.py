MODE='callback'
from pathlib import Path
from dataclasses import replace
from decimal import Decimal,localcontext
from fractions import Fraction as F
import json,time,traceback
import numpy as np
from test_solid_fluid_heat import solid_host
from test_water_phase_transfer import transfer,DATA
from sludge_sandbox.water_properties import load_water_properties
from sludge_sandbox.ideal_water_vapor import IdealWaterVapor
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.geometry import ReferenceSlab
from sludge_sandbox.deformation_program import PrescribedSlabMotion
from sludge_sandbox.skeleton_energy import DiagonalSkeletonEnergy
from sludge_sandbox.deforming_solid_storage import DeformingSolidStorage,DeformationErrorBounds,solid_provider_identity
from sludge_sandbox.deforming_solid_heat import DeformingSolidHeat
r=Path(__file__).resolve().parent;started=time.monotonic();result={'attempt_id':'installed-'+MODE+'-integration'}
try:
    selection=dict(backend='heos',backend_manifest=DATA/'heos-8.0.0-approved-manifest.json')
    import sys,hashlib,importlib.metadata
    result['loaded_modules']={n:m.__file__ for n,m in sys.modules.items() if n.startswith('sludge_sandbox') and getattr(m,'__file__',None)}
    assert all('/site-packages/sludge_sandbox/' in p for p in result['loaded_modules'].values())
    root=Path('/Users/wanggaoying/Desktop/brickmodel-github')
    result['loaded_module_sha256']={}
    for name,path in result['loaded_modules'].items():
        installed=Path(path);relative=installed.relative_to('/private/tmp/brick-water-backend-probe/venv/lib/python3.12/site-packages')
        assert installed.read_bytes()==(root/'src'/relative).read_bytes()
        result['loaded_module_sha256'][name]=hashlib.sha256(installed.read_bytes()).hexdigest()
    result['versions']={n:importlib.metadata.version(n) for n in ('numpy','scipy','iapws','CoolProp')}
    ingredients=(load_water_properties(DATA,**selection),IdealWaterVapor(DATA,**selection),WaterChemicalPotential(DATA,**selection))
    result['implementation']=json.loads(ingredients[0].implementation.canonical_json)
    base=solid_host(ingredients)
    from sludge_sandbox.phase_storage import InversePolicy
    base=replace(base,transport=replace(base.transport,inverse_policy=InversePolicy(1e-6,1e-6,120)))
    reference=ReferenceSlab(half_thickness_m=.01,reference_area_m2=.01,cells=1)
    motion=PrescribedSlabMotion(reference=reference,knot_times_s=(0.,1.),
        normal_stretches_at_knots=((1.,),(.9,)),tangential_stretches_at_knots=(1.,.9),
        motion_id='manufactured-wet-callback-motion',version='1',classification='manufactured_test_fixture',
        source_ids=('manufactured-wet-callback-motion',),source_asset_sha256=())
    skeleton=DiagonalSkeletonEnergy(reference=reference,cell_index=0,fixed_solid_inventory_mol=(('fixture_solid',2.),),
        solid_provider_identity=solid_provider_identity(base.storages[0].solid_phases),bulk_modulus_pa=1000.,
        shear_modulus_pa=400.,viscosity_pa_s=3.,interface_energy_j_m2=.5,reference_interface_area_m2=.003,
        stretch_range=(.5,2.),maximum_absolute_log_rate_per_s=2.,model_id='manufactured-wet-callback-skeleton',version='1',
        source_ids=('manufactured-wet-callback-skeleton',),classification='manufactured_test_fixture',allow_manufactured=True)
    point=DeformingSolidStorage(template=base.storages[0],motion=motion,skeleton=skeleton,
        error_bounds=DeformationErrorBounds((0.,1.),0.,0.,('manufactured-callback-extra-bounds',),'conditional_declared_not_material_admission'),
        model_id='manufactured-wet-callback-point',version='1',allow_manufactured=True)
    host=DeformingSolidHeat(base_model=base,point_storages=(point,),
        mechanical_regime='prescribed_cellwise_quasistatic_incompressible_skeleton',
        transport_regime='manufactured_relative_moving_faces',model_id='manufactured-wet-callback-host',version='1',
        source_ids=('manufactured-wet-callback-host',),allow_manufactured=True)
    op=replace(transfer(ingredients,base_model=host),coefficients_mol_s_pa=(1e-6,))
    if MODE=='disabled':op=replace(op,coefficients_mol_s_pa=(0.,))
    assert base.inventory_layout.species_order==('fixture_solid','H2O','H2O_liquid','fixture')
    state=host.state_from_temperatures([[2.,1e-8,1e-6,.001]],[300.],time_s=.5)
    out=op.evaluate(state,.5)
    result.update(status='passed',liquid_mol=float(state.amounts_mol[0,2]),rate_mol_s=out.cell_transfers[0].rate_mol_s,
        layout=list(base.inventory_layout.species_order),inverse_policy=vars(base.transport.inverse_policy),
        inverse_temperature_errors_k=[x.temperature_error_bound_k for x in out.base_evaluation.storage_inverses],
        energy_identity_matches=state.energy_model_identity==host.energy_model_identity,
        components=list(out.rates.cell_power_components_w),initial_amounts=state.amounts_mol.tolist(),initial_energy=state.internal_energy_j.tolist())
    result['total_energy_residual_j']=[x.total_energy_residual_j for x in out.base_evaluation.total_inverses]
    result['temperature_k']=[x.mechanical.temperature_k for x in out.base_evaluation.storage_states]
    result['cell_power_w']=out.rates.cell_power_w.tolist()
    result['cell_power_components_w']={k:v.tolist() for k,v in out.rates.cell_power_components_w.items()}
    result['reaction_species_mol_s']=out.rates.reaction_species_mol_s.tolist()
    assert max(abs(x) for x in result['total_energy_residual_j'])<=1e-6
    assert max(abs(x-300.) for x in result['temperature_k'])<=1e-6
    assert np.array_equal(out.rates.cell_power_w,out.base_evaluation.rates.cell_power_w)
    assert all(np.array_equal(v,out.base_evaluation.rates.cell_power_components_w[k]) for k,v in out.rates.cell_power_components_w.items())
    assert out.rates.reaction_species_mol_s[0,1]==-out.rates.reaction_species_mol_s[0,2]==result['rate_mol_s']
    assert out.rates.reaction_species_mol_s[0,0]==out.rates.reaction_species_mol_s[0,3]==0
    assert result['rate_mol_s']>0 and result['energy_identity_matches']
    assert max(result['inverse_temperature_errors_k'])<=1e-6
    assert set(result['components'])=={'elastic','interface','dissipation','pore','body'}
except BaseException as exc:
    result.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
finally:
    result['elapsed_s']=time.monotonic()-started
    (r/'callback-result.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
if result['status']!='passed':raise SystemExit(1)
