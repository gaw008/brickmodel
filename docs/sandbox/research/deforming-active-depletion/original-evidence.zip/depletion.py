MODE='depletion'
from pathlib import Path
from dataclasses import replace
from decimal import Decimal,localcontext
from fractions import Fraction as F
import json,time,traceback
import numpy as np
from test_solid_fluid_heat import solid_host
from test_water_phase_transfer import transfer,DATA
from sludge_sandbox.water_properties import load_water_properties
from sludge_sandbox.ideal_water_vapor import IdealWaterVapor
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.geometry import ReferenceSlab
from sludge_sandbox.deformation_program import PrescribedSlabMotion
from sludge_sandbox.skeleton_energy import DiagonalSkeletonEnergy
from sludge_sandbox.deforming_solid_storage import DeformingSolidStorage,DeformationErrorBounds,solid_provider_identity
from sludge_sandbox.deforming_solid_heat import DeformingSolidHeat
r=Path(__file__).resolve().parent;started=time.monotonic();result={'attempt_id':'installed-'+MODE+'-integration'}
try:
    selection=dict(backend='heos',backend_manifest=DATA/'heos-8.0.0-approved-manifest.json')
    import sys,hashlib,importlib.metadata
    result['loaded_modules']={n:m.__file__ for n,m in sys.modules.items() if n.startswith('sludge_sandbox') and getattr(m,'__file__',None)}
    assert all('/site-packages/sludge_sandbox/' in p for p in result['loaded_modules'].values())
    root=Path('/Users/wanggaoying/Desktop/brickmodel-github')
    result['loaded_module_sha256']={}
    for name,path in result['loaded_modules'].items():
        installed=Path(path);relative=installed.relative_to('/private/tmp/brick-water-backend-probe/venv/lib/python3.12/site-packages')
        assert installed.read_bytes()==(root/'src'/relative).read_bytes()
        result['loaded_module_sha256'][name]=hashlib.sha256(installed.read_bytes()).hexdigest()
    result['versions']={n:importlib.metadata.version(n) for n in ('numpy','scipy','iapws','CoolProp')}
    ingredients=(load_water_properties(DATA,**selection),IdealWaterVapor(DATA,**selection),WaterChemicalPotential(DATA,**selection))
    result['implementation']=json.loads(ingredients[0].implementation.canonical_json)
    base=solid_host(ingredients)
    from sludge_sandbox.phase_storage import InversePolicy
    base=replace(base,transport=replace(base.transport,inverse_policy=InversePolicy(1e-6,1e-6,120)))
    reference=ReferenceSlab(half_thickness_m=.01,reference_area_m2=.01,cells=1)
    motion=PrescribedSlabMotion(reference=reference,knot_times_s=(0.,1.),
        normal_stretches_at_knots=((1.,),(.9,)),tangential_stretches_at_knots=(1.,.9),
        motion_id='manufactured-wet-callback-motion',version='1',classification='manufactured_test_fixture',
        source_ids=('manufactured-wet-callback-motion',),source_asset_sha256=())
    skeleton=DiagonalSkeletonEnergy(reference=reference,cell_index=0,fixed_solid_inventory_mol=(('fixture_solid',2.),),
        solid_provider_identity=solid_provider_identity(base.storages[0].solid_phases),bulk_modulus_pa=1000.,
        shear_modulus_pa=400.,viscosity_pa_s=3.,interface_energy_j_m2=.5,reference_interface_area_m2=.003,
        stretch_range=(.5,2.),maximum_absolute_log_rate_per_s=2.,model_id='manufactured-wet-callback-skeleton',version='1',
        source_ids=('manufactured-wet-callback-skeleton',),classification='manufactured_test_fixture',allow_manufactured=True)
    point=DeformingSolidStorage(template=base.storages[0],motion=motion,skeleton=skeleton,
        error_bounds=DeformationErrorBounds((0.,1.),0.,0.,('manufactured-callback-extra-bounds',),'conditional_declared_not_material_admission'),
        model_id='manufactured-wet-callback-point',version='1',allow_manufactured=True)
    host=DeformingSolidHeat(base_model=base,point_storages=(point,),
        mechanical_regime='prescribed_cellwise_quasistatic_incompressible_skeleton',
        transport_regime='manufactured_relative_moving_faces',model_id='manufactured-wet-callback-host',version='1',
        source_ids=('manufactured-wet-callback-host',),allow_manufactured=True)
    op=replace(transfer(ingredients,base_model=host),coefficients_mol_s_pa=(1e-6,))
    if MODE=='disabled':op=replace(op,coefficients_mol_s_pa=(0.,))
    assert base.inventory_layout.species_order==('fixture_solid','H2O','H2O_liquid','fixture')
    state=host.state_from_temperatures([[2.,1e-8,1e-6,.001]],[300.],time_s=.5)
    from dataclasses import fields,is_dataclass
    from collections.abc import Mapping
    def enc(v):
        if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
        if isinstance(v,np.ndarray):return v.tolist()
        if isinstance(v,np.generic):return v.item()
        if is_dataclass(v):return {f.name:enc(getattr(v,f.name)) for f in fields(v)}
        if isinstance(v,Mapping):return {str(k):enc(w) for k,w in v.items()}
        if isinstance(v,(tuple,list)):return [enc(w) for w in v]
        return v
    from sludge_sandbox.depletion_integration import integrate_depletion
    from test_depletion_integration import policies
    pol,event=policies()
    pol=replace(pol,initial_step_s=1/1024,maximum_step_s=1/256,maximum_steps=500,maximum_wall_seconds=120.)
    event=replace(event,time_absolute_s=1e-7,amount_absolute_mol=1e-10,energy_absolute_j=1e-6,
        temperature_absolute_k=1e-5,pressure_absolute_pa=1.,terminal_window_s=1/16384,common_time_horizon_s=1/256,
        roundoff_policy=replace(event.roundoff_policy,molar_mass_kg_mol=op.chemical.reference.molar_mass_kg_mol))
    original=json.loads((r/'callback-result.json').read_text())
    assert state.amounts_mol.tolist()==original['initial_amounts'] and state.internal_energy_j.tolist()==original['initial_energy']
    result.update(initial=enc(state),policy=enc(pol),event_policy=enc(event),inverse_policy=vars(base.transport.inverse_policy))
    run=integrate_depletion(state,op,start_s=.5,end_s=.5+1/128,integration_policy=pol,event_policy=event)
    result['run']={f.name:enc(getattr(run,f.name)) for f in fields(run) if f.name!='operator'}
    result['final_interfaces']=list(run.operator.interfaces)
    assert run.status=='completed',(run.status,run.reason)
    assert run.times_s[-1]==.5+1/128 and len(run.events)==1
    assert run.operator.interfaces==('depleted_no_nucleation',)
    assert run.operator.coefficients_mol_s_pa==op.coefficients_mol_s_pa==(1e-6,)
    assert .5<run.events[0].time_s<run.times_s[-1]
    energy=F();water0=F(float(state.amounts_mol[0,1]))+F(float(state.amounts_mol[0,2]));prefix=[]
    for t,x,step in zip(run.times_s[1:],run.states[1:],run.steps):
        assert x.energy_model_identity==state.energy_model_identity
        assert np.array_equal(x.amounts_mol[:,[0,3]],state.amounts_mol[:,[0,3]])
        assert set(step.cell_work_components_j)=={'elastic','interface','dissipation','pore','body'}
        represented=sum((F(float(v[0])) for v in step.cell_work_components_j.values()),F())
        assert represented+step.component_sum_residual_j[0]==F(float(step.cell_work_j[0]))
        energy+=F(float(step.cell_work_j[0]))+F(float(step.face_energy_j[0]))-F(float(step.face_energy_j[1]))
        er=F(float(x.internal_energy_j[0]))-F(float(state.internal_energy_j[0]))-energy
        wr=F(float(x.amounts_mol[0,1]))+F(float(x.amounts_mol[0,2]))-water0
        assert abs(er)<=F(1e-7) and abs(wr)<=F(1e-12)
        assert np.all(step.face_species_mol==0) and np.all(step.face_energy_j==0)
        if t>=run.events[0].time_s:assert x.amounts_mol[0,2]==0
        prefix.append({'t':t,'energy_residual_j':enc(er),'water_residual_mol':enc(wr)})
    result['prefix_audit']=prefix
    correction=sum((c.vapor_storage_roundoff_mol for c in run.corrections),F())
    assert correction==run.roundoff_totals.signed_storage_roundoff_mol
    last=run.operator.evaluate(run.states[-1],run.times_s[-1])
    assert last.cell_transfers[0].rate_mol_s==0
    result.update(status='passed',final_temperature_k=last.base_evaluation.storage_states[0].mechanical.temperature_k,
        qualification='real water with manufactured prescribed skeleton and phase coefficient; first combined depletion path, not full-trajectory accuracy or material validation')
except BaseException as exc:
    result.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
finally:
    result['elapsed_s']=time.monotonic()-started
    (r/'depletion-result.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
if result['status']!='passed':raise SystemExit(1)
