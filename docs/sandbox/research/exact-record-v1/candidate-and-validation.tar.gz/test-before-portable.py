from dataclasses import replace
from fractions import Fraction as F
import json
import sys
from pathlib import Path
import pytest
sys.path[:0]=['/private/tmp/brick-exact-packet-bridge-v1','/private/tmp/brick-exact-terminal-executor-v1']
from test_driver import setup
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.exact_depletion_integration import integrate_exact_depletion
from sludge_sandbox.water_phase_transfer import WaterPhaseTransfer
from exact_record import encode_exact_run,read_exact_run,validate_binding,ExactRecordError,pack


def make(monkeypatch,cancelled=False):
    s,v,p,e,calls=setup(monkeypatch)
    # Existing algebra fixture constructs an intentionally partial native host.
    # Permit only dataclass reconstruction in this test; source digests stay real.
    monkeypatch.setattr(WaterPhaseTransfer,'__post_init__',lambda self:None)
    start,end=T(F()),T(F(3,100))
    result=integrate_exact_depletion(s,v,start=start,end=end,integration_policy=p,event_policy=e,
        cancel=(lambda:len(calls)>15) if cancelled else None)
    raw=encode_exact_run(result,original_operator=v,start=start,end=end,case_sha256='a'*64,runtime_identity={'modules':{'test':'b'*64}})
    return raw,v,result


def test_full_roundtrip_and_live_binding(monkeypatch):
    raw,v,result=make(monkeypatch)
    record=read_exact_run(raw)
    assert record.result.status=='completed'
    assert record.canonical_bytes==raw
    assert len(record.ledgers)==len(result.steps)
    assert pack(record.states[-1])==pack(result.states[-1])
    assert sum(map(len,record.result.packets))==2
    validate_binding(record,v,case_sha256='a'*64,runtime_identity={'modules':{'test':'b'*64}})
    with pytest.raises(ExactRecordError):validate_binding(record,v,case_sha256='c'*64,runtime_identity={'modules':{'test':'b'*64}})
    with pytest.raises(ValueError):record.states[0].amounts_mol[0,0]=0


def test_cancelled_prefix_and_no_live_getter_during_capture(monkeypatch):
    raw,v,result=make(monkeypatch,True)
    assert result.status=='cancelled' and result.steps
    assert read_exact_run(raw).result.status=='cancelled'
    object.__setattr__(v.operator,'coefficient_version','mutated')
    raw2=encode_exact_run(result,original_operator=v,start=result.times_s[0],end=T(F(3,100)),case_sha256='a'*64,runtime_identity={})
    assert read_exact_run(raw2).result.status=='cancelled'
    with pytest.raises(ValueError):validate_binding(read_exact_run(raw2),v,case_sha256='a'*64,runtime_identity={})


@pytest.mark.parametrize('mutation', ['bool_cost','fraction','extra','compact','ledger_time','event_cell','mode','observation_error'])
def test_tampered_records_refused(monkeypatch,mutation):
    raw,_,_=make(monkeypatch);d=json.loads(raw);r=d['result']['fields']
    if mutation=='bool_cost':r['costs']['mapping']['ordinary_trials']=True
    elif mutation=='fraction':d['start']['exact_time']['denominator']=True
    elif mutation=='extra':d['unlisted']=0
    elif mutation=='compact':d['capture_kind']='research_compact'
    elif mutation=='ledger_time':r['steps']['sequence'][0]['fields']['end_s']=d['start']
    elif mutation=='event_cell':r['packets']['sequence'][0]['sequence'][0]['fields']['terminal']['fields']['root_order']['fields']['selected_cell']=True
    elif mutation=='observation_error':
        obs=r['terminal_attempts']['sequence'][0]['fields']['observations']['sequence'][0]['fields']['evaluation']
        obs['fields']['pressure_errors_pa']['sequence'][0]={'float_hex':(-1.).hex()}
    elif mutation=='mode':r['operator']['fields']['modes']['sequence'][0]='existing_liquid'
    with pytest.raises(ExactRecordError):read_exact_run(json.dumps(d).encode())


def test_duplicate_and_nonfinite_json():
    for raw in (b'{"schema":1,"schema":2}',b'{"x":NaN}',b'{"x":Infinity}'):
        with pytest.raises(ExactRecordError):read_exact_run(raw)


def test_decoded_evidence_array_cannot_restore_writeability():
    import numpy as np
    from exact_record import unpack
    array=unpack(pack(np.array([[1.,2.]])))
    with pytest.raises(ValueError):array.setflags(write=True)
    with pytest.raises(ValueError):array.base.setflags(write=True)
