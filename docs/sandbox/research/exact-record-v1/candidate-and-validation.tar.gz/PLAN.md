# Versioned exact core record

Only this temporary directory is writable for this task. No EOS, production changes or legacy resume admission.

API: encode_exact_run(run, *, original_operator, start, end, case_sha256, runtime_identity) -> canonical JSON bytes; read_exact_run(bytes, *, expected_binding=None) -> immutable ExactRunRecord; validate_binding(record, actual_original_operator, *, case_sha256, runtime_identity) -> freshly reparsed ExactRunRecord; callers consume the returned record.

Schema `exact_depletion_run_record_v1`, capture_kind `schema_complete_numerical_evidence`. Completeness means the declared numerical projection only: all accepted states/ledgers/packet and speculative numerical evidence, original policies, counters and exact times. Live inverse/provider object graphs are deliberately replaced by observation vectors actually used in comparisons. Operator references preserve constructor-frozen source identity and modes; capture does not invoke a possibly failing live getter. A separate live binding check is necessary before use. Rebuilding a model requires the externally frozen case, water/source and implementation inputs; this codec does not reconstruct or execute saved code.

Finite floats have explicit hex tags, rational seconds use canonical integer ratios, arrays carry shape and values, and dataclasses are identified only by a fixed local allowlist. No module/class name from JSON is imported. Records reject unknown fields/tags, duplicate keys, nonfinite values, bool-as-integer, malformed rational/time/shape data, compact historical captures, discontinuous accepted trajectories and inconsistent committed event membership/modes. Failed records preserve accepted prefixes and speculative attempts.

Decoding exposes immutable evidence and typed state/ledger projections, not a runnable ExactDepletionResult. Structural/association checks are not a substitute for independent root, full refinement, conservation or source-physics audit. Roundtrip is not resume certification. Tests cover roundtrip, malformed and tampered data, failure prefix and source binding; actual native execution remains parent-owned.
