"""Temporary candidate overlay only; do not apply this helper to production."""
import importlib.util
from pathlib import Path
import sys
spec=importlib.util.spec_from_file_location('sludge_sandbox.exact_record',Path(__file__).with_name('exact_record.py'))
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
