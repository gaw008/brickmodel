"""Independent association attacks; candidate author owns implementation."""
import json
from test_exact_record import make
from sludge_sandbox.exact_record import read_exact_run


def test_final_mechanics_missing_attack(monkeypatch):
    raw,_,_=make(monkeypatch)
    d=json.loads(raw)
    d['result']['fields']['states']['sequence'][-1]['fields']['mechanical_stretches']=None
    try:read_exact_run(json.dumps(d).encode())
    except ValueError:return
    raise AssertionError('accepted final state with absent mechanical state')


def test_correction_cell_attack(monkeypatch):
    raw,_,_=make(monkeypatch)
    d=json.loads(raw)
    frames=d['result']['fields']['packets']['sequence']
    for packet in frames:
        for frame in packet['sequence']:
            t=frame['fields']['terminal']['fields'];c=t['correction']
            if c is not None:
                c['fields']['cell_index']=1-t['root_order']['fields']['selected_cell']
                try:read_exact_run(json.dumps(d).encode())
                except ValueError:return
                raise AssertionError('accepted correction belonging to another cell')
    # Exact-zero fixture still permits fabricated untyped six-gate diagnostics.
    frame=frames[0]['sequence'][0]['fields']
    frame['packet_maximum_differences']['sequence']=[True]*6
    try:read_exact_run(json.dumps(d).encode())
    except ValueError:return
    raise AssertionError('accepted bool six-gate diagnostics')
