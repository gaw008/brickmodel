"""Temporary candidate overlay; never deploy this file into permanent tests."""
import importlib.util
from pathlib import Path
import sys

spec=importlib.util.spec_from_file_location('sludge_sandbox.arlabosse_caloric',Path(__file__).with_name('arlabosse_caloric.py'))
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)


def pytest_collection_modifyitems(items):
    root=Path.cwd().resolve()
    assert (root/'data/sandbox/research/arlabosse2005/source.json').is_file(), 'Run candidate tests from repository root; original cache is required.'
    for item in items:
        if item.module.__name__=='test_arlabosse_caloric':item.module.REPOSITORY=root
