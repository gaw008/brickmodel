"""One bounded actual manufactured source path; no native backend."""
from dataclasses import replace
import time
import pytest
import test_source_dry_transition as fixtures
from sludge_sandbox._heos_kernel import HEOSCandidate
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_dry_shared_pressure import declare_source_shared_dry_volume
from sludge_sandbox.source_dry_transition import evaluate_source_dry_transition


def test_shared_pressure_cannot_override_stricter_temperature_gate(monkeypatch):
    started=time.monotonic()
    monkeypatch.setattr(HEOSCandidate,'__init__',lambda *a,**k:pytest.fail('native forbidden'))
    old_policy=fixtures.policies
    def stricter():
        numerical,event=old_policy()
        return numerical,replace(event,temperature_absolute_k=1e-20)
    monkeypatch.setattr(fixtures,'policies',stricter)
    old_evaluate=ExactSourceColumn.evaluate
    calls=[]
    def counted(self,state,when):
        assert len(calls)<48 and time.monotonic()-started<40
        calls.append((self.interfaces,when))
        return old_evaluate(self,state,when)
    monkeypatch.setattr(ExactSourceColumn,'evaluate',counted)
    column,_=fixtures.setup(monkeypatch,count=1)
    storage=replace(column.storages[0],volume=replace(column.storages[0].volume,error_m3=1e-12))
    refinement,end=fixtures.prepare(monkeypatch,base=replace(column,storages=(storage,)))
    result=evaluate_source_dry_transition(refinement,end=end,maximum_callbacks_per_path=32,
        shared_volume=declare_source_shared_dry_volume(storage))
    assert result.selected_pressure_gates==(True,True)
    assert all(row[:2]==(True,True) and row[2] is False for row in result.endpoint_gates)
    assert not result.numerical_event_accepted
    assert all(c.status=='executed_dry_candidate' for c in result.candidates)
    before=len(calls)
    monkeypatch.setattr(ExactSourceColumn,'evaluate',lambda *a,**k:pytest.fail('passive check called source'))
    result.check()
    assert len(calls)==before==46
    print({'actual_source_callbacks':len(calls),'elapsed_seconds':time.monotonic()-started,
           'selected_pressure_gates':result.selected_pressure_gates,'temperature_gates':[row[2] for row in result.endpoint_gates],
           'numerical_event_accepted':result.numerical_event_accepted})
