"""Independent actual fixture coexistence check, no native backend."""
import pytest
from test_source_dry_transition import actual,shared_programmed
from sludge_sandbox._heos_kernel import HEOSCandidate

def test_shared_fixture_can_follow_existing_module_fixture(monkeypatch):
    monkeypatch.setattr(HEOSCandidate,'__init__',lambda *a,**k:pytest.fail('native forbidden'))
    first=actual.__wrapped__()
    second=shared_programmed.__wrapped__()
    try:
        next(first)
        value=next(second)
        assert value.numerical_event_accepted
    finally:
        second.close()
        first.close()
