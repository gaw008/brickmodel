# 来源干态共享体积压力比较：接口复用审查

只读基线 `c684bce`。范围为现有 paired_pressure、paired_pressure_host、pressure_comparison 与 source dry 比较接口。没有实现、EOS、模型求值或测试；不重复联合压力物理推导。下面是最小衔接判断，非新控制器设计。

## 可直接借用与不可直接套用

| 位置 | 可复用内容 | 当前限制 |
|---|---|---|
| `paired_pressure.py:22–36` | 严格 Fraction、正域、区间顺序验证方式 | `_interval` 要求正端点，不能原样校验可能跨零的 ΔP 区间；不可只看函数名复用。 |
| `paired_pressure.py:151` | 独立界与成对界同时保存、合格证据下取更紧界、分解项与输入 canonical JSON/hash、最终 binary64 向外投影方式 | `certify_paired_pressure` 是共同压力根枢轴/顺应性公式，不是本次干态完整 T/共享 V 箱的直接差值核。不要为复用而强迫新问题经过旧根反解。 |
| `paired_pressure_host.py:73` | `_outward_root` 是纯定温名义压力±误差的向外 binary64 区间转换，可在确需该表示格式时使用 | 它不是来源绑定或联合误差证明。新核若全程 Fraction，不必为了调用它先投影。 |
| `pressure_comparison.py:32–61` | canonical Fraction 编解码和严格字段集合的通用部分可小幅提取复用；`PressureComparisonResult` 的 immutable record 设计可借鉴 | `restore_pressure_comparison_policy`、`compare_pressure_pair`、`audit_pressure_comparison` 的旧 schema/host/state 假设不能接收新 source 模型。 |
| `source_dry_pressure.py:99/122` | `SourceDryPressure.check()` / `enclose_source_dry_pressure` 已被动验证实际 source state/inverse/原来源/闭合/域；`continuation` 已保存完整 T/V 区间、准确输入和原保守 P 围栏 | 不修改旧半径、资格和失败。它给单端独立围栏，不能仅凭两端数值相同推断共同参数。 |
| `source_dry_transition.py:274` | 原候选检查、两条实际事件/共同终点配对、时间与 N/U/T 差异、全前缀账本已有；新压力证据应在这些已求值端点上使用 | 无需另写推进、根排序、写回或干态 driver；事件配对时刻不同，不能误用只允许同一时刻的 `measure_source_endpoint_pair`。 |

## 旧对象不适配的具体原因

`PressureState` 保存 mol 固体、bulk volume 和 Jacobian；`SharedVolumes` 强制非空固体物种、每种正 molar volume，并绑定 `manufactured_shared_constant_volume_parameters_v1`。来源主机固定干质量是 kg，当前可用流体体积不是旧 reference slab 减 mol 固相体积这一建模对象。不要造一个零 mol 的虚构固体、任意 molar volume 或假 Jacobian 来满足旧 constructor。

`PairedPressureCertificate.to_record()` 固定 `temperature_uncertainty_included=False`，资格是 reported temperatures。旧 `LiquidEndpoints` 的稳定液体单调性也不是干态所需证明。即使两端 liquid=0 让旧核跳过 EOS，这些 schema 仍不表示本次完整逆温度区间证据。

`prepare_paired_pressure` 精确要求 `WaterPhaseTransfer → FreeSolidSlab`、`CurrentSolidStorage/CurrentSolidInverse`、`ManufacturedReactingSkeletonEnergy` 和 `reacting_manufactured`。它读取 `ConservedState.mechanical_stretches`、宿主 mol 库存布局、变形后的 skeleton/current storage，再核 reference geometry 和固体体积误差。来源 `SourceWetStorage/SourceWetInverse`、无 mechanical stretches 的四类流体状态不满足这些语义，不能包装成假 mechanical host。湿态分支还可能执行至多四次 water endpoint EOS；本次已有干态记录无需进入该分支。

## 最小输入与原记录保留

新纯核消费两个已核对的 `SourceDryPressure`，以及独立、显式、可溯源的“同一个恒定可用体积参数”声明。源体积身份的详细证明由父代理负责；值相等、误差相等或同一 provider 名称本身不是相关误差抵消证据。

优先绑定 `continuation.inputs`：其中 Ng 已是各已表示气体库存的精确 Fraction 和，不能换成 math.fsum 再转 Fraction。保留完整 T 区间、原 R/库存/域、实际 nominal P、原误差和投影项。`initial_bounds_pa[0]` 是重算 closure nominal 下界，并非保证等于实际 `inverse.point.fluid.pressure_error_bound_pa`；后者允许更大的合法原声明，不能用前者静默替代。共享体积项如何与其他独立误差拆开，应由本次证明确定，而不是直接从原半径减 eV 贡献。

旧 `DepletionPolicy.pressure_comparison` 精确要求旧 `PressureComparisonPolicy`；`SourceTerminal` 还明确要求该字段为 None。保留这些旧拒绝和 codec，不把新的 source 声明塞进旧机械 schema。新声明应有独立类型、完整绑定、默认不启用和明确“包含全 T、同参数假设”的新资格。

旧 `SourceDryTransition` 原样留存：`endpoint_differences/gates`、`conditional_pressure_bounds_pa/gates`、`numerical_event_accepted=false` 和原 JSON/hash 都不改。若接通新证据，新增记录应同时包含原比较、所用声明、两组 event/common 联合界、选用证据的标识及相同原 `pressure_absolute_pa` 下的新条件结论。

当前接受表达式要求旧报告 P 和旧独立全 T P 都通过。因此仅额外 AND 一个更紧 gate 不能让旧 P 拒绝获得新的条件接受；更不能直接翻改旧 gate。若目标是允许在新的严格共同参数合同下准入，应明示采用另一份新条件比较结果：复用旧 clock、两组 N/U/T 和全账本检查，以经绑定且完整域有效的 event/common 联合 P 证据检验原 1e-4 Pa 门槛，同时保留旧两套失败。这与既有机械比较保存 original bound/selected bound 的结构一致，不需要并行控制器。缺声明、条件不成立或证据未决时保留原比较结论，不能自动授予通过。

此处的新条件数值接受不等于材料/物理事件认证；旧 candidate/terminal/pressure 的资格标记保持。来源完整流程 Goal 的其余范围也不因这一窄接口而消失。

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: 只读复用调查完成；尚无新实现可批准。最小适配层应复用现有来源端点和既有比较流程，保持旧结果与新条件证据分开。
