"""Conditional joint-volume arithmetic only; no live correlation certification."""
from fractions import Fraction as F
from pathlib import Path
import math,json,runpy,hashlib,time
P=Path(__file__).parent;m=runpy.run_path('/private/tmp/brick-source-dry-transition-v1/physics/audit_manufactured.py');start=time.monotonic();f=Path('/private/tmp/brick-source-dry-transition-v1/root/native-result.json');raw=f.read_bytes();assert hashlib.sha256(raw).hexdigest()=='0a242ef8c239226b68ee085abe51641e1b95165c464f7edb175454555543fa49';r=m['dec'](json.loads(raw));t=r['transition'];checks=0

def ck(x):
 global checks
 checks+=1
 assert x

def up(x):
 v=float(x)
 if F(v)<x:v=math.nextafter(v,math.inf)
 return F(v)
def spacing(x):return F(math.ulp(float(up(x))))
rows=[]
for k in (0,-1):
 ends=[]
 for c in t['candidates']:
  cap=c['captures'][k];inv=cap['evaluation']['source_evaluation']['cells'][0]['inverse'];p=inv['point'];me=p['fluid']['mechanical'];ns=cap['state']['amounts_mol'][0][1:];N=sum(map(F,ns),F());R=F(me['gas_constant_j_mol_k']);T=F(me['temperature_k']);eT=F(inv['temperature_error_bound_k']);V=F(p['available_pore_volume_m3']);eV=F(p['available_volume_error_m3']);pres=F(me['pressure_pa']);fluid=F(p['fluid']['pressure_error_bound_pa']);pmax=F(p['fluid']['envelope']['pressure_range_pa'][1]);globalextra=up(eV*pmax*pmax/(N*R*T));globalerror=up(fluid+globalextra);extra=up(eV*min(pmax,pres+globalerror)**2/(N*R*T));total=up(fluid+extra)
  ck(F(p['global_pressure_error_pa'])==globalerror and F(p['extra_pressure_error_pa'])==extra and F(p['pressure_error_pa'])==total)
  projection=abs(total-fluid-extra);nhat=F(math.fsum(ns));nr=F(float(float(nhat)*float(R)));Thi=T+eT;dn=abs(nhat-N);dnr=abs(nr-nhat*R);mult=spacing(abs(nr)*Thi);eta=((dn*R+dnr)*Thi+mult)/(V-eV)+spacing((abs(nr)*Thi+mult)/(V-eV));independent=fluid+projection+eta
  ends.append(dict(N=N,R=R,T=T,eT=eT,V=V,eV=eV,independent=independent,fluid=fluid,projection=projection,box_rounding=eta,fsum_error=dn))
 a,b=ends;ck(a['V']==b['V'] and a['eV']==b['eV'] and a['R']==b['R']);vm=a['V']-a['eV'];vp=a['V']+a['eV'];low=a['R']*(a['N']*(a['T']-a['eT'])-b['N']*(b['T']+b['eT']));high=a['R']*(a['N']*(a['T']+a['eT'])-b['N']*(b['T']-b['eT']));corners=[x/v for x in (low,high) for v in (vm,vp)];margin=a['independent']+b['independent'];interval=[min(corners)-margin,max(corners)+margin];bound=max(map(abs,interval))
 for ia in range(3):
  for ib in range(3):
   for iv in range(3):
    ta=a['T']+(ia-1)*a['eT'];tb=b['T']+(ib-1)*b['eT'];v=a['V']+(iv-1)*a['eV'];delta=a['R']*(a['N']*ta-b['N']*tb)/v;ck(interval[0]<=delta<=interval[1])
 rows.append({'kind':'event' if k==0 else 'common','input_details':ends,'hypothetical_shared_interval_pa':interval,'hypothetical_shared_bound_pa':bound,'original_independent_bound_pa':t['conditional_pressure_bounds_pa'][0 if k==0 else 1],'old_numerical_event_accepted':t['numerical_event_accepted'],'shared_live_identity_certified':False,'new_event_accepted':False})
def enc(x):
 if isinstance(x,F):return {'numerator':x.numerator,'denominator':x.denominator,'decimal':float(x)}
 raise TypeError(type(x).__name__)
res={'checks':checks,'elapsed_s':time.monotonic()-start,'input_sha256':hashlib.sha256(raw).hexdigest(),'rows':rows,'scope':'conditional algebra on saved data; live shared parameter identity unavailable and old rejection unchanged'};(P/'SAVED_ANALYSIS.json').write_text(json.dumps(res,default=enc,indent=2)+'\n');print(json.dumps(res,default=enc,indent=2))
