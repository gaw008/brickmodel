"""Saved shared dry transition Fraction oracle; no model imports/EOS."""
import json,runpy,hashlib,math,time,sys
from fractions import Fraction as F
from pathlib import Path
P=Path(__file__).parent;m=runpy.run_path('/private/tmp/brick-source-dry-transition-v1/physics/audit_manufactured.py');ck=m['ck'];start=time.monotonic();p=Path(sys.argv[1]);raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest();ck(sha==sys.argv[2],'terminal input SHA');r=m['dec'](json.loads(raw))
def up(x):
 y=float(x)
 return F(math.nextafter(y,math.inf)) if F(y)<x else F(y)
def spacing(x):return F(math.ulp(float(up(x))))
results={}
for name,t in r.get('cases',{'native':r.get('transition')}).items():
 ck(t is not None,'actual returned transition');paths=m['audit'](t);ep=t['candidates'][0]['event_policy'];limits=[F(ep[k]) for k in ('amount_absolute_mol','energy_absolute_j','temperature_absolute_k','pressure_absolute_pa')];is_shared=t['pressure_strategy']=='explicit_shared_source_dry_volume';new=[]
 ca,cb=[c['terminal']['clock'] for c in t['candidates']];distance=max(abs(ca['lower']['seconds']-cb['upper']['seconds']),abs(ca['upper']['seconds']-cb['lower']['seconds']));ck(distance==t['clock_distance_upper_s'] and t['clock_gate']==(distance<=F(ep['time_absolute_s'])),'absolute complete root clock gate')
 for i,c in enumerate(t['candidates']):
  z=c['terminal'];pc=z['prior_clock'];choice=pc['choices'][i];used=choice['order']['refinement_level']+choice['additional_refinement_rounds']+pc['additional_rounds'][i];ck(pc==t['refinement']['clock'] and z['root_index']==i and z['reused_clock_rounds']==used and z['clock']['iterations']==used+z['additional_clock_rounds']<=ep['maximum_refinements'],'actual reused prior plus added root budget')
 if is_shared:
  dec=t['shared_volume'];vol=dec['volume'];ck(dec['volume_interval_m3']==[F(vol['value_m3'])-F(vol['error_m3']),F(vol['value_m3'])+F(vol['error_m3'])],'original shared V box')
  ck(len(dec['object_identity'])==2 and all(type(i) is int and i>0 for i in dec['object_identity']),'saved declaration object identities')
 for idx,k in enumerate((0,-1)):
  cs=[c['captures'][k] for c in t['candidates']];ivs=[c['evaluation']['source_evaluation']['cells'][0]['inverse'] for c in cs];me=[v['point']['fluid']['mechanical'] for v in ivs]
  diff=[max(abs(F(a)-F(b)) for a,b in zip(cs[0]['state']['amounts_mol'][0],cs[1]['state']['amounts_mol'][0])),abs(F(cs[0]['state']['internal_energy_j'][0])-F(cs[1]['state']['internal_energy_j'][0])),abs(F(me[0]['temperature_k'])-F(me[1]['temperature_k']))+sum((F(v['temperature_error_bound_k']) for v in ivs),F()),abs(F(me[0]['pressure_pa'])-F(me[1]['pressure_pa']))+sum((F(v['point']['pressure_error_pa']) for v in ivs),F())]
  ck(t['endpoint_differences'][idx][3]==diff and t['endpoint_gates'][idx]==[v<=tol for v,tol in zip(diff,limits)],'unchanged event common original gates')
  orig=abs(F(me[0]['pressure_pa'])-F(me[1]['pressure_pa']))+sum((c['pressure_endpoints'][k]['continuation']['radius_pa'] for c in t['candidates']),F());ck(t['conditional_pressure_bounds_pa'][idx]==orig and t['conditional_pressure_gates'][idx]==(orig<=limits[3]),'old independent pressure record preserved')
  if not is_shared:continue
  pair=t['shared_pressure_pairs'][idx];ck(pair['shared_volume']==dec and pair['endpoints']==[c['pressure_endpoints'][k] for c in t['candidates']],'actual declaration and endpoint bindings')
  details=[]
  for j,end in enumerate(pair['endpoints']):
   co=end['continuation'];point=end['inverse']['point'];fluid=F(point['fluid']['pressure_error_bound_pa']);N,R,T,eT,V,eV,pres,err=co['inputs'];ns=end['state']['gas_amounts_mol'];ck(N==sum(map(F,ns),F()) and end['storage_identity']==dec['storage_identity'] and end['state']['solid_mass_kg']==[t['candidates'][j]['seed']['fixed_dry_mass_kg'][0]],'exact N fixedkg storage identity')
   maxp=F(point['fluid']['envelope']['pressure_range_pa'][1]);g=up(fluid+up(eV*maxp**2/(N*R*T)));ex=up(eV*min(maxp,pres+g)**2/(N*R*T));total=up(fluid+ex);projection=abs(total-fluid-ex);ck([F(point[v]) for v in ('global_pressure_error_pa','extra_pressure_error_pa','pressure_error_pa')]==[g,ex,total],'strict original error decomposition')
   nh=F(math.fsum(ns));nr=F(float(float(nh)*float(R)));dn=abs(nh-N);dnr=abs(nr-nh*R);h=T+eT;vmin=V-eV;mult=spacing(abs(nr)*h);box=((dn*R+dnr)*h+mult)/vmin+spacing((abs(nr)*h+mult)/vmin);eta=fluid+projection+box
   values=[end['initial_bounds_pa'][0],fluid,g,ex,total,projection,dn,dnr,box,eta];ck(list(pair['error_parts'][j].values())==values,'all ten independently recomputed error parts')
   tb=[T-eT,T+eT];vb=[V-eV,V+eV];ck(co['temperature_interval_k']==tb and vb==dec['volume_interval_m3'],'entire T V boxes')
   analytic=[N*R*tb[0]/vb[1],N*R*tb[1]/vb[0]];pd=co['pressure_domain_pa'];env=point['fluid']['envelope']['pressure_range_pa'];ck(max(pd[0],F(env[0]))<=analytic[0]-eta<=analytic[1]+eta<=min(pd[1],F(env[1])),'expanded full P box')
   details.append((N,R,tb,vb,eta))
  a,b=details;ck(a[1]==b[1] and a[3]==b[3],'same R V');num=[a[1]*(a[0]*a[2][0]-b[0]*b[2][1]),a[1]*(a[0]*a[2][1]-b[0]*b[2][0])];corners=[x/v for x in num for v in a[3]];ideal=[min(corners),max(corners)];margin=a[4]+b[4];joint=[ideal[0]-margin,ideal[1]+margin];bound=max(map(abs,joint))
  ck(pair['ideal_interval_pa']==ideal and pair['joint_interval_pa']==joint and pair['joint_bound_pa']==pair['bound_pa']==bound,'joint-only no min');ck(pair['independent_bound_pa']==orig,'original independent bound remains')
  ck(pair['status']=='conditional_shared_dry_pressure_enclosure' and all(pair[f] is False for f in ('source_certified','material_qualified','event_admitted')),'conditional shared evidence only')
  ck(t['selected_pressure_bounds_pa'][idx]==bound and t['selected_pressure_gates'][idx]==(bound<=limits[3]),'explicit selected strategy gate');new.append(float(bound))
  for ia in (0,1):
   for ib in (0,1):
    for v in a[3]:ck(joint[0]<=a[1]*(a[0]*a[2][ia]-b[0]*b[2][ib])/v<=joint[1],'independent full T corners')
 if name in ('programmed','shared_programmed'):
  for c in t['candidates']:
   ck({'seconds':F(.0002)} in c['reference']['times_s'],'exact accepted furnace knot');A,B=c['captures'][0],c['captures'][-1];ck(A['state']['internal_energy_j']!=B['state']['internal_energy_j'],'real dry energy change');ck(A['evaluation']['source_evaluation']['cells'][0]['inverse']['point']['fluid']['mechanical']['temperature_k']!=B['evaluation']['source_evaluation']['cells'][0]['inverse']['point']['fluid']['mechanical']['temperature_k'],'real dry temperature change')
 expected=t['clock_gate'] and all(all(row[:3]) for row in t['endpoint_gates']) and all(t['selected_pressure_gates']);ck(t['numerical_event_accepted']==expected and t['material_qualified'] is False,'conditional numerical only acceptance')
 results[name]={'paths':paths,'original_gates':t['endpoint_gates'],'old_conditional_gates':t['conditional_pressure_gates'],'new_bounds_pa':new,'selected_gates':t['selected_pressure_gates'],'numerical_event_accepted':t['numerical_event_accepted']}
out={'checks':ck.__globals__['checks'],'elapsed_s':time.monotonic()-start,'input_sha256':sha,'cases':results,'scope':'offline saved arithmetic and retained live-declaration evidence, not recreation of live object identity or EOS'};(P/'SHARED_SAVED_RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
