# 同一干态恒定可用体积参数的联合压力差

只读 source_dry_pressure.py、source_wet_storage.py、rigid_storage.py 与 paired_pressure.py；没有EOS、模型构造或生产更改。

## 可准入的相关性与温度条件

两个实际 SourceDryPressure.check 均通过是前提。当前最小足够关联证据是 a.storage is b.storage，且该已检查 SourceWetStorage 的唯一 ManufacturedFixedFluidVolume 对象相同；再次检查model/energy identity、固定dry kg、gas_ids/provider、R/reference来源、原volume.value/error和两保存input绑定。应由实际共享storage生成共同参数证据，不能开放用户字符串宣称shared。

仅同volume数值、rationale、source_id或digest不够：现volume dataclass只哈希(value,error,rationale,classification)，两个独立不确定参数可内容相同而不相关。同source/kg/energy身份必要，但其内容digest同样不单独证明同一个物理参数。离线JSON省略live storage，不足独立证明Python对象相同；可审核已存身份/参数及runner构造路径，但新实现必须在live准入处产生并绑定共享对象证明，不能给旧输出倒添共享证书。

干态必须Nl=0、pure_gas_analytic_rounded。现源码储能 U(T)=md us(T)+Σni ui(T)，gas_phases 为 IdealGasPhase，ui只依赖T；液体项和 Nl*B*extra_pressure_error 严格为零。因此对固定库存，源干物常比容/无反应以及理想气caloric假设下，U和dU/dT不依赖V，已有完整eT可在所有V复用。每个Ta±eTa必须在原source/caloric域，所有对应P角点在原gas/fluid压力域。不能将同样推理推广wet、可变体积功/非理想气/反应/固体质量变化。

## 联合物理包络

Ni=Σj Fraction(ni,j) 为实际binary64状态数值的精确和；R=Fraction(saved R)。保留每端独立温度区间[Li,Hi]，不假设eTa/eTb相关抵消。对于共同V∈[Vmin,Vmax]，

Alo=R*(Na*La−Nb*Hb), Ahi=R*(Na*Ha−Nb*Lb)。
Dideal=[min(Alo/Vmin,Alo/Vmax,Ahi/Vmin,Ahi/Vmax),max(四角)]。

这对跨零/负差也正确；独立误差ηa,ηb扩张为[Dlo−ηa−ηb,Dhi+ηa+ηb]，绝对界max(abs端点)。单体压力箱仍需原域内；不能从差很小推断两个绝对压力都合法。R视为声明模型的同一数值常量，非未声明CODATA测量不确定性；如未来R有误差须作为共享参数加入角点。

## 表示/闭合误差必须显式保留

不能用 total_eP−extra_eP 做精确误差剥离：total_eP已有binary64相加投影。已有独立fluid.pressure_error_bound_pa是源dry验证器检查过的名义闭合半径，保留该字段及验证得到的nominal下界，和V项分别绑定。即使名义Pa=Pb，也不能抵消它们。

已有名义fluid半径不是自动的整个(T,V)箱机器算术证书。若新接口要连同潜在跨箱浮点求值误差保守覆盖，可直接再加一个无EOS的显式全箱前向舍入上界。设 Nhat=math.fsum(ni)，nr=float(Nhat*R_float)，dN=|F(Nhat)−Nexact|，dnr=|F(nr)−F(Nhat)*R|；所有输入正、有限、正常范围且不溢出。
取 S(x) 为 >=x 的有限binary64点的一个ULP（向上取点后测间距，覆盖round-to-nearest误差，故故意不用half-ULP）。Then
eta_box=(dN*R*H + dnr*H + S(abs(F(nr))*H))/Vmin
        + S((abs(F(nr))*H+S(abs(F(nr))*H))/Vmin)。
第一项显式包含库存求和误差与R乘法误差；后两项覆盖nRT乘法及除V的全箱舍入。应使用Fraction比较/向上取整求S，并拒绝无法证明有限的范围。保留η=原fluid名义半径+eta_box（可能重复计数，但安全）；这不借原pressure_error_pa的体积项作减法。此界把任意箱内乘除舍入的误差相加，不假设两路径同误差。

若只使用现有nominal fluid半径而不加/证明全箱扩张，应明确限制所比较对象为理想气精确数学压力加原名义输出误差，不声称所有可能native跨箱输出的前向误差都已认证。未知真实非理想气偏差不在此模型内，仍conditional/source_certified=false。

## 与旧模块关系和拒绝条件

paired_pressure.py基于reported温度、机械Jacobian/bulk/固体mol体积构造；不能给固定kg source编造solid_mol或假bulk几何以满足其类型。可复用其Fraction角点/向上投影思想，不复用其“temperature_uncertainty_included=false”的证书。新结果应旁列旧两个独立半径失败；不能改旧SourceDryPressure或transition.event gates记录。

拒绝：不同live参数、只有内容相等、液体非零、声明误差缺失/变化、非法T/P/V箱、未知gas caloric/provider、跨域、R/固定kg/source身份不一致、非finite舍入界。新联合差即使小于原1e-4Pa也只是新条件证据，必须单独政策准入，不使旧事件自动accepted。

## 本轮选择的严格分解规则与已执行新分析

选严格重建，不猜测任意surplus去向。已检查单体后，以现wet_fluid_pressure_bounds逐式重建 directed-upper global/extra/total；保存point的这三字段必须与原生产输出完全相等。若任意字段比重建值更大也拒绝新shared准入（原单体结果依然有效）。使用实际fluid.pressure_error_bound_pa，不是initial_bounds[0]的下界；另保留 abs(F(total)−F(actual_fluid)−recomputed_extra) 正扩张，捕获总和投影。extra本身是有证明的共享体积敏感度有向上界，而非任意可减常数。

独立脚本analyze_saved.py只读取已冻结native SHA0a242ef8c239226b68ee085abe51641e1b95165c464f7edb175454555543fa49；60项Fraction核查通过，0.081366s。事件/共同终点的严格重建分解都一致，exactsum−fsum差绝对值2.1294316410686045e-17mol未丢弃；每端全箱舍入补量3.1079923554744416e-10Pa。假设确为同一V参数后的联合界均8.606093363963303e-6Pa，原eV1e-12与阈值1e-4不变。原独立条件界0.002035256129739854Pa及旧event=false完整保留。JSON只提供条件代数分析，没有live共享对象证明，不产生新certificate或event接受。

反例边界：两个存储参数数值相同但独立V_a,V_b∈[Vmin,Vmax]，即使NaTa=NbTb也可取V_a=Vmin,V_b=Vmax，压力差非零；本联合公式只适用同一个变量V。温度误差即使名义Ta=Tb、Na=Nb也必须独立保留，故本例新界非零。可在两种有效同目标包络上取min作为新selected数值，但必须保留原独立失败记录，不能把此替换动作悄悄当旧policy通过。
