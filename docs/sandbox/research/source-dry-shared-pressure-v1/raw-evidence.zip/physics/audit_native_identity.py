"""Actual call identity and unchanged previous physical observations; stdlib only."""
from pathlib import Path
import json,runpy,hashlib,time
P=Path(__file__).parent;decode=runpy.run_path('/private/tmp/brick-source-dry-transition-v1/physics/audit_manufactured.py')['dec'];start=time.monotonic();checks=0

def ck(x,label):
 global checks
 checks+=1
 if not x:raise AssertionError(label)

def read(path,sha):
 raw=Path(path).read_bytes();ck(hashlib.sha256(raw).hexdigest()==sha,'file SHA');return decode(json.loads(raw))
a=read('/private/tmp/brick-source-dry-shared-pressure-v1/root/native-result.json','a9d2d658a259e72f871e4f96c8d3e0172def2720a2901bc91c06e78e5a97d4dc');b=read('/private/tmp/brick-source-dry-transition-v1/root/native-result.json','0a242ef8c239226b68ee085abe51641e1b95165c464f7edb175454555543fa49');t=a['transition']
ck(a['status']==b['status']=='completed','both actual completed');ck(b['numerical_event_accepted'] is False and a['numerical_event_accepted'] is True and a['material_qualified'] is False,'old failure/new conditional acceptance separate')
for k in ('initial','initial_temperature_k','initial_energy_point','horizon','integration_policy','event_policy'):ck(a[k]==b[k],'original physical input '+k)
ck(len(a['captures'])==len(b['captures'])==32,'actual call count')
for i,(x,y) in enumerate(zip(a['captures'],b['captures'])):
 for k in ('packed_input','time','evaluation','operator_identity','energy_identity','interface_modes'):
  ck(x[k]==y[k],'unchanged physical capture '+str(i)+' '+k)
 ck(x['ordinal']==i+1,'actual ordinal')
trials=[a['seed'],a['approach']['trial'],a['refinement']['shifted_trial'],*t['candidates']];stored=[v for obj in trials for v in obj['captures']];ck(len(stored)+1==len(a['captures']),'all recorded attempts')
for x,c in zip(a['captures'][1:],stored):ck(x['packed_input']==c['state'] and x['time']==c['time'] and x.get('evaluation')==c['evaluation'],'actual callback/returned capture binding')
for k in ('backend_constructors_started','backend_constructors_completed','constructor_reference_anchor_checks'):ck(a[k]==4,'explicit constructors')
ck(a['initial_energy_evaluations_attempted']==1 and a['expected_callbacks_not_measurement']==32,'energy and estimate separate')
for k,v in dict(time_absolute_s=1e-8,amount_absolute_mol=1e-11,energy_absolute_j=1e-7,temperature_absolute_k=1e-5,pressure_absolute_pa=1e-4,maximum_refinements=32).items():ck(a['event_policy'][k]==v,'original gate '+k)
ck(t['shared_volume']==a['shared_volume_declaration'],'top shared declaration')
ck(t['shared_volume']['volume']['error_m3']==1e-12,'original volume error')
r={'status':'passed','checks':checks,'elapsed_s':time.monotonic()-start,'actual_callbacks':len(a['captures']),'all_previous_physical_captures_equal':True,'previous_event_accepted':b['numerical_event_accepted'],'new_conditional_event_accepted':a['numerical_event_accepted'],'scope':'exact saved numerical payload equality; no normalization or discarded physical fields'};(P/'NATIVE_IDENTITY_RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
