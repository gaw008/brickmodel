from pathlib import Path
root=Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox')
link='[来源共享体积干压力](research/source-dry-shared-pressure-v1/REPORT.md)'
additions={
'WORLD_SPEC.md':f'{link}要求两端属于同一实际 storage/volume 对象，固定干质量、零液水和理想气储能；以独立完整T区间和同一原V±eV计算Fraction联合差，另加实际流体误差、总投影和全箱机器舍入。严格重建原误差分解，完整绝对T/P域不足则未决。显式shared_volume选择新joint界，旧两套P值/失败保持；原clock/N/U/T与全前缀门槛不变。只形成条件数值比较，无新材料参数或真实烧成验证。以下保留先前版本定义。',
'KNOWN_GAPS.md':f'{link}已关闭当前N1真实水湿→干候选的共享常量压力比较缺项：新实际运行以8.606093364e-6Pa通过原1e-4Pa，未缩小eV或改写原独立P失败。该关联只适用于同一live参数，不能推广到不同空间格或湿态。下一步为[N格唯一单元事件和液体供体焓](research/source-dry-shared-pressure-v1/next-runtime-slice.md)；纯输运残差、再润湿、重复事件、来源保存/应用、同材料原泥反应烧结冷却、三机制留出和全周期/多代仍必需未完成。',
'ACCEPTANCE_MATRIX.md':f'{link}推进P04/P05/P10/P16与V05/V06的限定数值部分：源码/安装各79项，127模块一致；新实际水两条湿→干路径以完整T/V联合压力界通过原门槛，原独立P失败保留。新transition仅条件数值接受，材料false；不将N格运输事件、应用、同材料全周期或现实三个机制验收整体升级verified。',
'EQUATION_CODE_MAP.md':f'`source_dry_shared_pressure.enclose_source_dry_pressure_pair`使用A=[R(Na La−Nb Hb),R(Na Ha−Nb Lb)]与共同[Vmin,Vmax]的四角构成压力差，再加两端独立流体、投影和全T/V舍入界。`declare_source_shared_dry_volume`绑定实际同对象，`source_dry_transition`显式策略选择joint-only并保留旧独立值与gate。完整域/严格原分解检查和推导见{link}及[公式](research/source-dry-shared-pressure-v1/DERIVATION.md)，无新材料本构。',
'VALIDATION_REPORT.md':f'当前{link}：源码79项32.96s、安装79项32.90s，127模块/134包文件一致。独立严格T反例1项12.03s/46source调用确认共享P通过不能越过其他门槛；制造保存187项Fraction核算0.105584s通过。新实际水单跑18.995829s完成32source求值，4构造锚点/初U1另计；事件/common联合P界8.606093364e-6Pa通过原1e-4Pa，数值事件true、材料false，原两套独立P gate仍false。旧记录、原eV和全部科学阈值不变。',
}
for name,paragraph in additions.items():
    p=root/name;s=p.read_text();first,rest=s.split('\n',1);p.write_text(first+'\n\n'+paragraph+'\n'+rest)
p=root/'GOAL_STATUS.md';s=p.read_text();needle='## 当前恢复入口（后续详细历史保留）\n\n';assert s.count(needle)==1
new=f'''{link}已实际完成本阶段：显式live storage/volume声明，完整T/V联合差、严格原误差分解和全箱舍入；实际湿→干入口可选新界，旧独立P值/失败保持。源码79项32.96s、非editable安装79项32.90s通过，127模块/134包文件一致；独立制造187项0.105584s，严格T反例1项12.03s/46source调用通过。原min草稿与夹具共存RED均保留且已修复。

新真实水单次18.995829s、32source求值，4构造/锚点和初U1另计；新event/common联合P界均8.606093364e-6Pa通过原1e-4Pa，原clock/N/U/T通过，transition数值事件true、材料false。旧报告P0.002026653258Pa和独立完整T界0.002035256130Pa及其false gate保持，eV1e-12m3未缩小。完整JSON SHA a9d2d658a259e72f871e4f96c8d3e0172def2720a2901bc91c06e78e5a97d4dc。源码74135、安装41481、原生29672均终态0，无待跑过程，不重复已通过的不变检查。

下一实际实现：[N格唯一单元事件/液流与供体焓](research/source-dry-shared-pressure-v1/next-runtime-slice.md)。复用N维面板、根和前缀账本；先保留正蒸发及原phase correction预算，纯输运不能冒充液→汽修正。继续混合湿干压力/全格累计账本、来源保存/应用、再润湿及重复事件。原Goal完整同材料原泥反应烧结冷却、三机制公开留出、空间时间收敛、全周期与多代均仍必需未完成，Goal保持active。

### 前一来源单格湿→干执行阶段（已完成，保留历史）

'''
p.write_text(s.replace(needle,needle+new))
print('Updated six central documents; prior historical evidence retained.')
