from pathlib import Path
import hashlib,json
from fractions import Fraction as F
p=Path('/private/tmp/brick-source-dry-shared-pressure-v1/root/native-result.json')
x=json.loads(p.read_text()); t=x['transition']['fields']
def number(v):
    return float(F(v['numerator'],v['denominator'])) if isinstance(v,dict) and set(v)=={'numerator','denominator'} else v
result={k:x[k] for k in ('status','scope','wall_seconds','build_seconds','numerical_comparison_completed','numerical_event_accepted','material_qualified','backend_constructors_started','backend_constructors_completed','constructor_reference_anchor_checks','initial_energy_evaluations_attempted','pressure_strategy','shared_parameter_runtime_admission')}
result.update(input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),input_bytes=p.stat().st_size,actual_source_callbacks=len(x['captures']),clock_distance_upper_s=number(t['clock_distance_upper_s']),clock_gate=t['clock_gate'],endpoint_gates=t['endpoint_gates'],original_conditional_pressure_bounds_pa=[number(v) for v in t['conditional_pressure_bounds_pa']],original_conditional_pressure_gates=t['conditional_pressure_gates'],selected_pressure_bounds_pa=[number(v) for v in t['selected_pressure_bounds_pa']],selected_pressure_gates=t['selected_pressure_gates'],shared_volume_declaration=t['shared_volume'],pairs=[])
for label,entry in zip(('event','common'),t['shared_pressure_pairs']):
    pair=entry['fields']
    row={'label':label,'status':pair['status'],'source_certified':pair['source_certified'],'event_admitted':pair['event_admitted'],'material_qualified':pair['material_qualified']}
    for key in ('joint_bound_pa','independent_bound_pa','bound_pa'):row[key]=number(pair[key])
    row['error_parts']=[{key:number(v) for key,v in e['fields'].items()} for e in pair['error_parts']]
    result['pairs'].append(row)
out=Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/source-dry-shared-pressure-v1/native-summary.json');out.write_text(json.dumps(result,indent=2)+'\n')
print('Saved compact summary; exact full records remain in original JSON.')
