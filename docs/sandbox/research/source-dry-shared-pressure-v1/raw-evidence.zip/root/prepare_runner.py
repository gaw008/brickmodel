from pathlib import Path
import hashlib
root=Path('/Users/wanggaoying/Desktop/brickmodel-github')
base=root/'docs/sandbox/research/source-dry-transition-v1/run_native.py'
assert hashlib.sha256(base.read_bytes()).hexdigest()=='a7916d30ee0eb0abf5852a76c5b92eec3a70acd1b0e130cd05a1dc556f2d6e71'
dest=root/'docs/sandbox/research/source-dry-shared-pressure-v1'
dest.mkdir(exist_ok=True)
s=base.read_text()
def change(old,new):
    global s
    assert s.count(old)==1,old
    s=s.replace(old,new)
change('Prepared single HEOS/source wet-to-dry study;', 'Prepared single HEOS/source shared-volume wet-to-dry study;')
change("PREVIOUS_RUNNER = 'source-root-comparison-v1/run_native.py'", "PREVIOUS_RUNNER = 'source-dry-transition-v1/run_native.py'")
change("PREVIOUS_RUNNER_SHA256 = '5b8c0e650e051a0ab4eb36e919eaaef18b271f51bb499add23f5e534c8434f28'", "PREVIOUS_RUNNER_SHA256 = 'a7916d30ee0eb0abf5852a76c5b92eec3a70acd1b0e130cd05a1dc556f2d6e71'")
change("scope='new_virtual_N1_1e-11mol_source_wet_to_dry_numerical_scenario',", "scope='explicit_shared_volume_N1_source_wet_to_dry_numerical_scenario',\n        pressure_strategy='explicit_shared_source_dry_volume',\n        prior_independent_pressure_failure_unchanged=True,")
change('        from sludge_sandbox._heos_kernel import HEOSCandidate', '        from sludge_sandbox._heos_kernel import HEOSCandidate\n        from sludge_sandbox.source_dry_shared_pressure import declare_source_shared_dry_volume')
change("        require(column.liquid_transport is None, 'no_liquid_transport_in_N1_scenario')", "        require(column.liquid_transport is None, 'no_liquid_transport_in_N1_scenario')\n        shared = declare_source_shared_dry_volume(storage)\n        shared.check()\n        result['shared_volume_declaration'] = encode(shared)\n        result['shared_parameter_runtime_admission'] = dict(\n            same_initial_storage_object=shared.storage is storage,\n            same_initial_volume_object=shared.volume is storage.volume,\n            object_identity_scope='current_process_only_not_offline_reconstruction')\n        save()")
change("            require(not result.get('outer_timeout_requested'), 'outer_timeout_already_requested')", "            require(len(self.column.storages) == 1 and self.column.storages[0] is shared.storage\n                    and self.column.storages[0].volume is shared.volume,\n                    'same_declared_live_storage_and_volume_required')\n            require(not result.get('outer_timeout_requested'), 'outer_timeout_already_requested')")
change('                same_object_as_initial_adapter=self is adapter)', '                same_object_as_initial_adapter=self is adapter,\n                same_declared_storage_object=self.column.storages[0] is shared.storage,\n                same_declared_volume_object=self.column.storages[0].volume is shared.volume)')
change('                    maximum_callbacks_per_path=DRY_PATH_CALLBACK_CAP)', '                    maximum_callbacks_per_path=DRY_PATH_CALLBACK_CAP, shared_volume=shared)')
change('            material_qualified=False, wall_seconds=result[\'wall_seconds\'])))', "            selected_pressure_bounds_pa=[None if x is None else float(x) for x in transition.selected_pressure_bounds_pa],\n            selected_pressure_gates=transition.selected_pressure_gates, pressure_strategy=transition.pressure_strategy,\n            material_qualified=False, wall_seconds=result['wall_seconds'])))")
(dest/'run_native.py').write_text(s)
print(hashlib.sha256(s.encode()).hexdigest())
