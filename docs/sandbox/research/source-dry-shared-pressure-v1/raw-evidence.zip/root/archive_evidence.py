"""Archive completed stage evidence once, then re-read and compare every member."""
from pathlib import Path
import hashlib,json,zipfile
root=Path('/Users/wanggaoying/Desktop/brickmodel-github')
tmp=Path('/private/tmp/brick-source-dry-shared-pressure-v1')
stage=root/'docs/sandbox/research/source-dry-shared-pressure-v1'
def sha(data):return hashlib.sha256(data).hexdigest()
freeze=json.loads((tmp/'root/pre-install-freeze.json').read_text())
for item in freeze['files']:
    assert sha((root/item['path']).read_bytes())==item['sha256'],item['path']
paths=sorted(p for p in tmp.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and not p.name.endswith('.pending'))
archive=stage/'raw-evidence.zip'; members=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in paths:
        name=str(path.relative_to(tmp));data=path.read_bytes();z.writestr(name,data)
        members.append({'path':name,'sha256':sha(data),'bytes':len(data)})
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(members)==len(set(z.namelist()))
    for item in members:
        data=z.read(item['path']);assert data==(tmp/item['path']).read_bytes()
        assert sha(data)==item['sha256'] and len(data)==item['bytes']
result={'baseline':'c684bce','reviewed_execution_files_unchanged':freeze['files'],
        'archive':{'path':'raw-evidence.zip','sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'member_count':len(members),'all_members_reopened_and_byte_equal':True,'members':members},
        'installed_identity_sha256':sha((tmp/'root/installed-identity.json').read_bytes()),
        'scientific_status':'conditional_numerical_comparison_only_material_unqualified',
        'original_goal_status':'active_incomplete'}
(stage/'final-freeze.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result['archive'].items() if key!='members'}))
