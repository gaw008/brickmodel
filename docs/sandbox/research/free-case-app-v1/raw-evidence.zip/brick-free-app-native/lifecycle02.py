from pathlib import Path
import json
from sludge_sandbox.run_service import run_case,replay_run,resume_run,read_run,trace_run
root=Path('/Users/wanggaoying/Desktop/brickmodel-github');out=Path('/private/tmp/brick-free-app-native');record={}
def save():
 p=out/'lifecycle02.json.tmp';p.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');p.replace(out/'lifecycle02.json')
count=0
def cancel():
 global count
 count+=1
 return count>=19
r=run_case(root/'data/sandbox/cases/reacting-wet-free-slab-v1.json',root/'data/sandbox/water',out/'cancel02',cancel=cancel,evidence_directory=root/'data/sandbox')
record['cancel']={'status':r['status'],'reason':r.get('reason'),'elapsed_seconds':r['elapsed_seconds'],'calls':count,'steps':len(r.get('integration',{}).get('steps',[]))};save()
assert r['status']=='cancelled' and len(r['integration']['steps'])==1
parent=r
r=resume_run(out/'cancel02',out/'resume02');record['resume']={'status':r['status'],'reason':r.get('reason'),'elapsed_seconds':r['elapsed_seconds']};save();assert r['status']=='completed'
assert r['integration']['states'][:2]==parent['integration']['states']
assert r['integration']['steps'][:1]==parent['integration']['steps']
record['resume']['original_prefix_preserved']=True
record['resume']['mechanical_trace']=trace_run(out/'resume02','mechanical_stretches')['value'];save()
for name in ('cancel02','resume02'):read_run(out/name)
print(json.dumps(record),flush=True)
