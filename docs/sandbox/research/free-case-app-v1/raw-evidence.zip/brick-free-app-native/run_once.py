from pathlib import Path
import json
from sludge_sandbox.run_service import run_case,trace_run,read_run
root=Path('/Users/wanggaoying/Desktop/brickmodel-github');out=Path('/private/tmp/brick-free-app-native')
result=run_case(root/'data/sandbox/cases/reacting-wet-free-slab-v1.json',root/'data/sandbox/water',out/'attempt01',evidence_directory=root/'data/sandbox')
print(json.dumps({'status':result['status'],'reason':result.get('reason'),'elapsed_seconds':result['elapsed_seconds']},allow_nan=False),flush=True)
assert result['status']=='completed'
traces={q:trace_run(out/'attempt01',q) for q in ('amounts_mol','internal_energy_j','temperature_k','pressure_pa','mechanical_stretches','geometry','free')}
(out/'traces.json').write_text(json.dumps(traces,indent=2,allow_nan=False)+'\n')
assert all(not t['dependency_graph']['missing_source_assets'] for t in traces.values())
read_run(out/'attempt01')
