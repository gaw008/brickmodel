"""Source-only provenance check: no model construction or native EOS."""
import hashlib,json,pathlib,shutil,traceback
from sludge_sandbox.run_provenance import build_graph,query_graph
ROOT=pathlib.Path('/Users/wanggaoying/Desktop/brickmodel-github');HERE=pathlib.Path(__file__).resolve().parent
result={'status':'started','native_eos_calls':0}
try:
 legacy=ROOT/'src/sludge_sandbox/catalogs/wet-slab-equations-v1.json'
 before=hashlib.sha256(legacy.read_bytes()).hexdigest()
 bundle=HERE/'bundle';bundle.mkdir(exist_ok=True)
 shutil.copytree(ROOT/'src/sludge_sandbox',bundle/'implementation',dirs_exist_ok=True)
 shutil.copyfile('/private/tmp/brick-free-case-integration-candidate/verification_case.py',bundle/'implementation/verification_case.py')
 shutil.copyfile('/private/tmp/brick-free-case-integration-candidate/reacting-wet-free-slab-v1.json',bundle/'case.json')
 catalog=json.loads((HERE/'free-wet-slab-equations-v1.json').read_text())
 for eq in catalog['equations']:
  for source in eq['sources']:
   name=source['artifact']
   if name=='case.json':continue
   origin=ROOT/'data/sandbox'/name.removeprefix('evidence/')
   if origin.is_file():
    target=bundle/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin,target)
 for name in catalog['supporting_assets']:
  origin=ROOT/'data/sandbox'/name.removeprefix('evidence/')
  if origin.is_file():
   target=bundle/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin,target)
 shutil.copyfile(HERE/'free-wet-slab-equations-v1.json',bundle/'equation_catalog.json')
 graph=build_graph(bundle,catalog)
 result['roots']={q:{'nodes':len(trace['nodes']),'missing_source_assets':trace['missing_source_assets']} for q in catalog['result_roots'] for trace in [query_graph(graph,q)]}
 (HERE/'graph.json').write_text(json.dumps(graph,indent=2)+'\n')
 result['legacy_sha256']=before
 assert hashlib.sha256(legacy.read_bytes()).hexdigest()==before
 assert len(result['roots'])==7
 assert not any(x['missing_source_assets'] for x in result['roots'].values())
 result['catalog_sha256']=hashlib.sha256((HERE/'free-wet-slab-equations-v1.json').read_bytes()).hexdigest()
 result['status']='passed'
except Exception:
 result['status']='failed';result['traceback']=traceback.format_exc();raise
finally:
 (HERE/'graph-check-result.json').write_text(json.dumps(result,indent=2)+'\n')
