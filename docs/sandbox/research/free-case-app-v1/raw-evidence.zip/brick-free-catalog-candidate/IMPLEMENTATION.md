# Free wet slab equation catalog candidate

Temporary only; legacy catalog and repository sources are unchanged. Twenty equation declarations reuse the existing source-qualified thermal, pressure, reaction, phase and transport links. Current geometry, total-energy inverse and the shared thermal assembler now anchor CurrentSolidStorage / FreeSolidSlab. No prescribed-motion anchor remains.

The added reduced traction closure uses eta_i=q_i*eta_ref_i and sum(V0_i*eta_i) for the tangent denominator. Local constraint power is explicitly retained in each cell; its global sum is only enclosed by zero. External work is -pe*dV/dtime; composition derivatives, viscous dissipation, latent and reaction energy are not duplicate heat sources. Constitutive coefficients and the reduced kinematic assumption remain manufactured declarations.

New parent additional volume/energy error fields explicitly divide by the number of children. Mechanical stretches are accepted-state data; geometry and free are snapshot reconstructions. All seven result roots are present. The graph remains a single-stage acyclic derivation plus accepted update/reconstruction, not a recursive feedback graph.

Validation preregistration: copy actual Python source assets and actual frozen free case into a temporary bundle, substitute only the reviewed candidate verification_case source, copy all declared local source assets, then call actual build_graph/query_graph for every root. Require parameter pointers and source JSON locators, code AST anchors, DAG roots and all declared source artifacts to resolve; require original legacy SHA unchanged. No model construction or EOS is performed. Missing scientific applicability cannot be cured by graph coverage.

Execution: PYTHONPATH=src /private/tmp/brick-water-backend-probe/venv/bin/python /private/tmp/brick-free-catalog-candidate/check_graph.py

Actual result: passed, 7 roots, zero missing declared assets, zero native EOS calls. See graph-check-result.json and graph.json. This establishes declaration binding, not scientific validation or material qualification. check_graph.py uses only provenance and file operations, and persists failures/tracebacks if any check fails.
