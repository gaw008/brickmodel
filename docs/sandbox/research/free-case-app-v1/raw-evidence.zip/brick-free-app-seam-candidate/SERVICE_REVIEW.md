# Independent model/catalog service seam review

Verdict: **APPROVE** for the two scoped source patches. No blocking findings. Both supplied before-files are byte-identical to current production. Read-only inspection; no EOS, install, test run, or repository edits.

## Inspected SHA-256

| File | SHA-256 |
|---|---|
| run_provenance.py | 6a31f32b768298308c941e5e89b010d0e92f4213a210b9212e5e42b0b3c467e4 |
| run_service.py | f19c8fff466670f68253e58381f327a266811eed499b8565fbe275288a81ab07 |
| test_selection.py | d7c972cff96c36979727806f9bfabd33d0a20a50afa84bc7122f054197dd0e39 |
| candidate.patch | c5e87803fb1b6e2f89f1d12df3d2882d1b791bf800ba44c4092d99e4b4ffb487 |

## Source review

- `run_provenance.py:85–108`: model selection is an explicit two-entry allowlist to fixed package-relative filenames. No model string is interpolated into a path. Type checking short-circuits before dictionary membership for non-string inputs. Parsed catalog model identity must match the requested model. The returned catalog bytes remain original bytes, preserving legacy default catalog hashing and serialization.
- `run_service.py:148`: normal runs choose the catalog using the already validated copied case model. The existing graph builder independently checks catalog/case model equality, resolves source/implementation anchors, and rejects unsupported graph content. Catalog read/build failures stay within the existing structured run failure boundary.
- `run_service.py:328–334`: resume selects the expected packaged catalog hash from the copied, validated case model, rejects a missing expected hash, and compares the frozen run catalog against it. Existing runtime, implementation, case SHA/ID, policy, cancelled-prefix, copied-source, and parent-artifact checks remain. Moving `read_case` before the selected catalog check does not remove case binding validation. Replay retains its runtime gate and dispatches through the same normal-run selection path.
- Runtime identity continues to hash all packaged catalogs. Its value will necessarily change when source/catalog assets change, intentionally making runs from an older installation ineligible for strict same-runtime resume/replay. The patch does not weaken that contract; legacy default catalog bytes remain unchanged.

## Test review and limits

Tests cover both explicit selections, traversal/unknown/non-string rejection, exact legacy default bytes, mismatched payload model rejection, actual normal-run dispatch before model construction, and both resume catalog branches before the existing case-binding guard. Synthetic free catalog fixtures are clearly labeled as dispatch fixtures rather than scientific catalogs. These tests do not execute a full free run, successful resume, replay, or scientific graph validation. The actual packaged free catalog, case builder changes, and their joint graph/service tests remain required integration dependencies; this source-only approval does not establish those outcomes.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE** for the frozen seam candidate.
