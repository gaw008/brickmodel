# Native probe and refinement evidence review

Verdict: **APPROVE for the stated build/initial-snapshot probe only**. No blocking implementation finding. Read-only review; no EOS, process rerun, test execution, install, or source edit by this reviewer.

Inspected SHA-256:

- `probe.py`: `b0620941d253aad4db7f3c1b108f98f88f613786685ebfc8fe7b9b7f4e090c5f`
- `PLAN.md`: `155476bc75285d8fe9f791d01a490f854123208b89e3559c10cc5dc9275fb331`
- Candidate `verification_case.py`: `e471398ba380a941aa4864ad7b7fd6b9342d660a47ddac897d9f7ccdb4642a34` (preceding code review).

## Probe assertions and interpretation

The probe builds the actual source-bound, gradient, two-cell sample, persists initialization and snapshot before assertions, checks free rather than prescribed output fields, and checks actual storage/reaction/inverse object reuse. The three-component mechanical-vector length is correct for this exact case. The temperature comparison is against the actual two parent temperatures; the snapshot itself additionally enforces the existing source/reconstruction/inverse temperature enclosure, so the coarse `1e-5 K` probe check does not replace that scientific gate.

The captured candidate hash records content but the script does not itself assert it equals an expected frozen hash or check candidate bytes again at exit. Source-before/after matching must therefore remain an external launcher acceptance condition. The case file itself is rechecked inside build and snapshot. `zip` in the temperature assertion assumes the existing builder's validated two-cell result shape; for stronger standalone evidence, assert exactly two returned temperatures and the exact declared initial normal/tangent vector, not only vector length.

The atomic strict-JSON writer preserves completed diagnostic stages. Python exceptions are recorded and re-raised. An externally killed process may leave a partial artifact without a terminal status; launcher timeout/exit evidence must classify that outcome. The 60 s bound belongs to the launcher, not this Python file. The probe's stated interpretation is appropriate: it does not integrate, establish refinement convergence, or qualify manufactured material parameters. No run outcome was independently verified here.

## Minimal additional independent two/four-cell checks

1. **Nonzero current B and q.** Keep the schema's initial B=0; construct a later conserved solid inventory using a positive dyadic reaction extent, e.g. parent A=1.5, B=0.5 from initial A=2, with each child exactly half. Derive `q = q0 + sum(beta_i*N_i/V0)` independently from case values using Fraction/Decimal, explicitly accounting for represented beta/V0 coefficients. Require q greater than q0 and parent/child equality. Evaluate actual reacting skeletons at nontrivial stretches and nonzero represented rates: parent elastic/interface energies and dissipation must enclose the sum of child values, while Piola stresses must agree within returned arithmetic bounds. Compare against the independent q times reference-law result, and include a negative control retaining initial inventory. Checking doubled weights alone with B=0 cannot detect failure to use current composition.

2. **Uniform normal mapping.** Start with different declared parent normals, temperatures, and rows; select `profile='uniform'`. In both two- and four-cell builds require every normal to equal parent 0, the common tangent to remain unchanged, and rows/temperatures to replicate parent 0. This verifies the geometry mapping follows the same uniform semantics as thermal/composition initialization rather than preserving the discarded second parent normal.

3. **Additional bulk error scaling.** Set nonzero parent additional bulk and mechanical errors. Assert child declared errors are exactly half of the parent with Fraction arithmetic, including the currently unasserted additional bulk field. At nontrivial J, independently check the returned current volume-error enclosure contains `J*reference_error + current-volume rounding + additional_current_bulk_error`. Do not demand exact equality of complete returned bounds: geometry rounding and outward rounding contribute. Keep reference bulk error separate from additional current-volume error.

4. **Actual thermal/mechanical evolution.** A short dry manufactured uniform case with A-to-B reaction and free mechanics can test two/four partition equivalence without native EOS. Use an independent ODE oracle or closed-form first-order A(t), with total energy including formation/thermal and q-scaled stored mechanical energy. The energy derivative contains only external pressure work for this sealed uniform branch; composition storage derivatives must not be added as external heat. Require nonzero reaction, temperature change, and stretch change, exact species totals, complete stretch evolution, current q, and per-cell/global ledgers. Compare temperatures, pressure, stretches, and extensive parent-versus-child sums with preregistered numerical gates.

A heterogeneous coupled two/four trajectory is a separate spatial discretization test: new internal faces alter the discrete problem, so exact partition equivalence is not expected there. Native wet transient validation and native water qualification cannot be inferred from the dry oracle or this initial snapshot.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE**, with the evidence limits and independent follow-up tests above. These are additional validation requirements for broader claims, not observed source defects in the bounded probe.
