"""Bounded native case initializer/snapshot probe; no trajectory claim."""
from pathlib import Path
import hashlib, importlib.util, json, sys, time, traceback
root=Path('/Users/wanggaoying/Desktop/brickmodel-github')
candidate=Path('/private/tmp/brick-free-case-integration-candidate')
out=Path('/private/tmp/brick-free-case-native')
spec=importlib.util.spec_from_file_location('sludge_sandbox._free_case_probe',candidate/'verification_case.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
record={'qualification':'Native build and selected snapshot only; manufactured material, no trajectory or spatial convergence.', 'candidate_sha256':hashlib.sha256((candidate/'verification_case.py').read_bytes()).hexdigest()}
def save():
 p=out/'attempt01.json.tmp';p.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');p.replace(out/'attempt01.json')
start=time.monotonic();save()
try:
 case=m.read_case(candidate/'reacting-wet-free-slab-v1.json');record['case']=case.payload;save()
 built=m.build_case(case,root/'data/sandbox/water');record['initialization']=m.encode(built.initialization);record['initial']=m.encode(built.initial);record['build_elapsed_seconds']=time.monotonic()-start;save()
 record['snapshot']=m.snapshot(built,built.initial,built.start_s);record['elapsed_seconds']=time.monotonic()-start;save()
 snap=record['snapshot']
 assert 'motion' not in snap and 'geometry' in snap and 'free' in snap
 assert all(c['reaction_binding_same_object'] and c['current_storage_same_object'] and c['thermal_inverse_reused'] for c in snap['cells'])
 assert len(built.initial.mechanical_stretches)==3
 assert all(abs(a-b)<1e-5 for a,b in zip(snap['temperature_k'],case.payload['initial']['parent_temperatures_k']))
 record['status']='passed';save();print(json.dumps({'status':'passed','elapsed_seconds':record['elapsed_seconds']}))
except BaseException as exc:
 record.update(status='failed',reason=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc(),elapsed_seconds=time.monotonic()-start);save();raise
