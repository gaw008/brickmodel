from pathlib import Path
from dataclasses import replace
import importlib.util,sys,json,copy
from fractions import Fraction as F
import pytest
from test_dynamic_solid_storage import water,forbid_water_eos
spec=importlib.util.spec_from_file_location('sludge_sandbox._free_case_candidate',Path(__file__).with_name('verification_case.py'))
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)


def payload():return json.loads(Path(__file__).with_name('reacting-wet-free-slab-v1.json').read_text())
def save(tmp,p,name='case.json'):
    f=tmp/name;f.write_text(json.dumps(p));return m.read_case(f)


def test_strict_free_and_old_payload(tmp_path):
    p=payload();case=save(tmp_path,p)
    assert case.payload==p
    old=Path('data/sandbox/cases/reacting-wet-slab-v1.json')
    assert m.read_case(old).payload==json.loads(old.read_text())
    for mutate in (lambda x:x['mechanics'].update(knot_times_s=[0,1]),lambda x:x['numerics']['integration'].pop('stretch_scale'),lambda x:x['mechanics'].update(viscosity_pa_s=0.)):
        bad=copy.deepcopy(p);mutate(bad)
        with pytest.raises(ValueError):save(tmp_path,bad,'bad.json')


def test_dry_build_two_four_extensive_q_and_mechanics(tmp_path,monkeypatch,water):
    import sludge_sandbox.water_properties as wp
    import sludge_sandbox.ideal_water_vapor as iv
    import sludge_sandbox.water_chemical_potential as wc
    for module in (wp,iv,wc):monkeypatch.setattr(module,'load_water_properties',lambda *a,**k:water)
    # Test-only manufactured caloric substitute for zero-inventory gas water;
    # no water/source qualification is asserted by this builder wiring test.
    monkeypatch.setattr(iv.IdealWaterVapor,'_caloric',lambda self,t:(30*t,(30-self.gas_constant_j_mol_k)*t,30.,30-self.gas_constant_j_mol_k,t))
    p=payload()
    for row in p['initial']['parent_amounts_mol']:row[2]=row[3]=0.
    p['transport']['phase_coefficient_density_mol_s_pa_m3']=0.
    p['mechanics']['initial_parent_normal_stretches']=[.98,1.02]
    p['mechanics']['parent_additional_bulk_volume_error_m3']=1e-18
    p['mechanics']['parent_additional_mechanical_energy_error_j']=1e-10
    coarse=m.build_case(save(tmp_path,p,'two.json'),tmp_path)
    p['grid']['cells']=4
    fine=m.build_case(save(tmp_path,p,'four.json'),tmp_path)
    assert tuple(coarse.initial.mechanical_stretches)==(.98,1.02,1.)
    assert tuple(fine.initial.mechanical_stretches)==(.98,.98,1.02,1.02,1.)
    for i in range(2):
        for j in range(5):assert F(float(coarse.initial.amounts_mol[i,j]))==sum((F(float(fine.initial.amounts_mol[k,j])) for k in (2*i,2*i+1)),F())
        assert F(float(coarse.initial.internal_energy_j[i]))==sum((F(float(fine.initial.internal_energy_j[k])) for k in (2*i,2*i+1)),F())
        a=coarse.operator.base_model.point_storages[i];b=fine.operator.base_model.point_storages[2*i]
        assert b.skeleton.reference_model.reference_interface_area_m2*2==a.skeleton.reference_model.reference_interface_area_m2
        assert b.error_bounds.additional_mechanical_energy_error_j*2==a.error_bounds.additional_mechanical_energy_error_j
        for (_,wa),(_,wb) in zip(a.skeleton.composition_weights_per_mol,b.skeleton.composition_weights_per_mol):assert wb==2*wa
    assert fine.policy.stretch_absolute_tolerance==1e-9


def test_prescribed_default_construction_path_unchanged(tmp_path,monkeypatch,water):
    # Read-only old payload equality is already tested. Here dry substitute
    # bypasses only original wet input schema to check actual legacy builder.
    import sludge_sandbox.water_properties as wp
    import sludge_sandbox.ideal_water_vapor as iv
    import sludge_sandbox.water_chemical_potential as wc
    import sludge_sandbox.verification_case as old
    for module in (wp,iv,wc):monkeypatch.setattr(module,'load_water_properties',lambda *a,**k:water)
    monkeypatch.setattr(iv.IdealWaterVapor,'_caloric',lambda self,t:(30*t,(30-self.gas_constant_j_mol_k)*t,30.,30-self.gas_constant_j_mol_k,t))
    raw=json.loads(Path('data/sandbox/cases/reacting-wet-slab-v1.json').read_text())
    case=save(tmp_path,raw)
    # _make_model creates no pointforward EOS; same verified rawcase inputs.
    other=old.read_case(case.path)
    a,rows,temps=m._make_model(case,tmp_path,2)
    b,old_rows,old_temps=old._make_model(other,tmp_path,2)
    assert rows==old_rows and temps==old_temps
    assert a.base_model.energy_model_identity==b.base_model.energy_model_identity
    assert a.source_ids==b.source_ids
