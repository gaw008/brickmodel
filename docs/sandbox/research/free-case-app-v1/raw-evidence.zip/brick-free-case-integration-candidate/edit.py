from pathlib import Path
import json
out=Path(__file__).parent;s=(out/'before.py').read_text()
pos=s.index('\n\ndef _require(')
s=s[:pos]+'''

_FREE_MODEL = 'manufactured_reacting_wet_free_slab_v1'
_FREE_MECHANICS = (_KEYS['mechanics'].split())
_FREE_MECHANICS = ' '.join(k for k in _FREE_MECHANICS if k not in (
    'knot_times_s','normal_stretches_at_knots','tangential_stretches_at_knots',
    'additional_bulk_volume_error_m3','additional_mechanical_energy_error_j')) + (
    ' initial_parent_normal_stretches initial_tangential_stretch external_pressure_pa'
    ' parent_additional_bulk_volume_error_m3 parent_additional_mechanical_energy_error_j')


def _free_normals(payload: dict[str, Any], cells: int) -> tuple[float, ...]:
    parent = payload['mechanics']['initial_parent_normal_stretches']
    return tuple(float(parent[0 if payload['profile']=='uniform' else i//(cells//2)]) for i in range(cells))
'''+s[pos:]
s=s.replace("p.get('model_id') == 'manufactured_reacting_wet_prescribed_slab_v1'","p.get('model_id') in ('manufactured_reacting_wet_prescribed_slab_v1', _FREE_MODEL)")
s=s.replace('    for pointer, names in _KEYS.items():','''    free = p['model_id'] == _FREE_MODEL
    keys = dict(_KEYS)
    if free:
        keys['mechanics'] = _FREE_MECHANICS
        keys['numerics/integration'] += ' stretch_absolute_tolerance stretch_scale'
    for pointer, names in keys.items():''')
a=s.index("    knots = _range(mech['knot_times_s']");b=s.index("    for value in mech['composition_beta",a)
old=s[a:b]
common="""    stretch = _range(mech['stretch_range'], 'stretch bounds')
    _require(stretch[0] > 0, 'positive stretch range')
    if free:
        normals=mech['initial_parent_normal_stretches']
        _require(type(normals) is list and len(normals)==2,'two parent normal stretches required')
        for value in normals+[mech['initial_tangential_stretch']]:
            _require(stretch[0]<=_number(value,'initial stretch',positive=True)<=stretch[1],'initial stretch outside domain')
        _number(mech['external_pressure_pa'],'external pressure',nonnegative=True)
        for key in ('bulk_modulus_pa','shear_modulus_pa','composition_offset','maximum_absolute_log_rate_per_s','viscosity_pa_s'):
            _number(mech[key],key,positive=True)
        for key in ('interface_energy_j_m2','micro_interface_area_density_m2_m3','parent_additional_bulk_volume_error_m3','parent_additional_mechanical_energy_error_j'):
            _number(mech[key],key,nonnegative=True)
    else:
"""
s=s[:a]+common+''.join('    '+line+'\n' for line in old.splitlines())+s[b:]
s=s.replace("    _require(knots[0] <= start < end <= knots[1], 'time outside motion range')","    _require(start < end if free else knots[0] <= start < end <= knots[1], 'invalid time domain')")
s=s.replace("_require(index == 1 or value > 0, 'positive initial A/water/carrier required')","_require((index in (1,2,3) if free else index == 1) or value > 0, 'positive initial A/water/carrier required')")
s=s.replace("        _number(transport[key], key, positive=True)","        _number(transport[key], key, positive=not (free and key=='phase_coefficient_density_mol_s_pa_m3'), nonnegative=free and key=='phase_coefficient_density_mol_s_pa_m3')")
s=s.replace('    from .deforming_solid_heat import DeformingSolidHeat','    from .deforming_solid_heat import DeformingSolidHeat\n    from .current_solid_storage import CurrentSolidStorage\n    from .dynamic_solid_storage import DynamicStorageErrorBounds\n    from .free_solid_slab import FreeSolidSlab')
a=s.index('    motion = PrescribedSlabMotion(');b=s.index('    parent_rows',a);block=s[a:b];s=s[:a]+"    free = p['model_id'] == _FREE_MODEL\n    if not free:\n"+''.join('    '+v+'\n' for v in block.splitlines())+s[b:]
a=s.index('        points.append(DeformingSolidStorage');b=s.index('    operator = WaterPhaseTransfer',a)
old=s[a:b];pointend=old.index('    host = DeformingSolidHeat');oldpoint=old[:pointend];oldhost=old[pointend:]
s=s[:a]+'''        if free:
            points.append(CurrentSolidStorage(template=template,skeleton=skeleton,
                error_bounds=DynamicStorageErrorBounds(tuple(m['stretch_range']),tuple(m['stretch_range']),
                    m['parent_additional_bulk_volume_error_m3']*scale,m['parent_additional_mechanical_energy_error_j']*scale,
                    source,'conditional_declared_not_material_admission'),
                model_id=source[0]+':point',version='1',allow_manufactured=True,solid_inventory_regime='reacting_manufactured'))
        else:
'''+''.join('    '+v+'\n' for v in oldpoint.splitlines())+'''    if free:
        host=FreeSolidSlab(base_model=base,point_storages=tuple(points),external_pressure_pa=m['external_pressure_pa'],
            mechanical_regime='reduced_common_tangent_quasistatic_reacting_manufactured',
            transport_regime='manufactured_relative_moving_faces',model_id=source[0]+':host',version='1',
            source_ids=source,allow_manufactured=True,solid_inventory_regime='reacting_manufactured')
    else:
'''+''.join('    '+v+'\n' for v in oldhost.splitlines())+s[b:]
s=s.replace('def _forward(operator: Any, rows: list[list[float]], temperatures: list[float], start: float)', 'def _forward(operator: Any, rows: list[list[float]], temperatures: list[float], start: float, payload: dict[str, Any])')
s=s.replace('    state = host.state_from_temperatures(rows, temperatures, time_s=start)', '''    if payload['model_id']==_FREE_MODEL:
        geometry=dict(normal_stretches=_free_normals(payload,len(rows)),tangential_stretch=payload['mechanics']['initial_tangential_stretch'])
    else:
        geometry=dict(time_s=start)
    state = host.state_from_temperatures(rows, temperatures, **geometry)''')
s=s.replace('.forward(temperature, time_s=start,','.forward(temperature, **geometry,')
s=s.replace('_forward(operator, rows, temperatures, start)','_forward(operator, rows, temperatures, start,p)').replace('_forward(parent_operator, parent_rows, parent_temperatures, start)','_forward(parent_operator, parent_rows, parent_temperatures, start,p)')
s=s.replace('energy_model_identity=operator.base_model.energy_model_identity)\n    checks', 'energy_model_identity=operator.base_model.energy_model_identity,\n                             mechanical_stretches=forward_state.mechanical_stretches)\n    checks')
s=s.replace('cells=cells, motion=base.motion, internal_faces=faces,','cells=cells, internal_faces=faces,')
s=s.replace("    if time_s == built.start_s", "    if built.case.payload['model_id']==_FREE_MODEL:\n        result.update(geometry=encode(base.geometry),free=encode(base.free))\n    else:\n        result['motion']=encode(base.motion)\n    if time_s == built.start_s")
(out/'verification_case.py').write_text(s)
p=json.loads(Path('data/sandbox/cases/reacting-wet-slab-v1.json').read_text());p['model_id']='manufactured_reacting_wet_free_slab_v1';p['case_id']='reacting-wet-free-slab-v1';p['scope']='Manufactured reacting reduced common-tangent free slab; source-qualified water. No material or full firing-cycle admission.'
m=p['mechanics']
for k in ('knot_times_s','normal_stretches_at_knots','tangential_stretches_at_knots'):m.pop(k)
for k in ('additional_bulk_volume_error_m3','additional_mechanical_energy_error_j'):m['parent_'+k]=m.pop(k)
m.update(initial_parent_normal_stretches=[1.,1.],initial_tangential_stretch=1.,external_pressure_pa=101325.,viscosity_pa_s=1e6)
p['numerics']['integration'].update(stretch_absolute_tolerance=1e-9,stretch_scale=1.)
(out/'reacting-wet-free-slab-v1.json').write_text(json.dumps(p,indent=2)+'\n')
