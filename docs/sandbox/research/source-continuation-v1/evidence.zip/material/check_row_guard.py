"""Failure controls in private copied fixtures; original data untouched."""
from pathlib import Path
import json,shutil,subprocess,sys,hashlib
p=Path('data/sandbox/research/gnest2021/basis-audit-v1');out=Path('/private/tmp/brick-source-continuation-v1/material/row-guard-regression');out.mkdir(exist_ok=True);results=[]
for case in ('missing','duplicate','missing_product'):
 d=out/case/'basis-audit-v1';d.mkdir(parents=True,exist_ok=True);shutil.copyfile(p/'check_basis.py',d/'check_basis.py');original=d.parent/'table4-table5-audit-v1';original.mkdir(exist_ok=True);shutil.copyfile(p.parent/'table4-table5-audit-v1/quantitative-record.json',original/'quantitative-record.json');r=json.loads((p/'BASIS_ARITHMETIC.json').read_text())
 if case=='missing':r['rows'].pop()
 elif case=='duplicate':r['rows'][-1]=r['rows'][0]
 else:r['rows'][0]['independent_multiplication_of_printed_y_and_composition'].pop()
 (d/'BASIS_ARITHMETIC.json').write_text(json.dumps(r));proc=subprocess.run([sys.executable,str(d/'check_basis.py')],capture_output=True,text=True);(out/(case+'.log')).write_text(proc.stdout+proc.stderr);assert proc.returncode!=0;results.append({'case':case,'exit_code':proc.returncode,'failure':proc.stderr.splitlines()[-1]})
result={'controls':results,'checker_sha256':hashlib.sha256((p/'check_basis.py').read_bytes()).hexdigest(),'original_data_sha256':hashlib.sha256((p/'BASIS_ARITHMETIC.json').read_bytes()).hexdigest()};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
