"""Produce traceable endpoint facts and a derived fuel-inventory node, no host admission."""
from pathlib import Path
import json,hashlib
from sludge_sandbox.evidence import EvidenceRegistry
r=Path(__file__).parent
facts=json.loads((r/'source_facts.json').read_text())
common={'applicability':{'status':'conditional','rationale':'Only paper-linked10K/min El Salitre prepared-sludge endpoint data; individual aliquot pairing/covariance not established.'},'uncertainty':{'status':'unquantified','rationale':'Joint yield/LHV covariance and endpoint uncertainties not provided; displayed precision is not uncertainty.'},'domain':{'material_classes':['El_Salitre_prepared_digested_sludge'],'atmospheres':['nitrogen_pyrolysis'],'notes':'Discrete570/960C endpoints, dry basis; not a caloric curve or reaction heat.'}}
source={'id':'GNEST_003738_SAME_MATERIAL_ENDPOINTS','title':'A comprehensive study of the high temperature pyrolysis of sewage sludge: kinetics, energy analysis and products formation','url':'https://cosmos.gnest.org/publication/gnest_03738','authors':['Libardo Mendoza-Geney','S. Rincón Prat','A. Gómez'],'year':2022,'license':'Landing CC BY4 versus PDF all-rights-reserved conflict; facts only','retrieved_at':'2026-09-08','read_status':'data_checked','reading_scope':'Cached primary full-text sections2.1–2.4,3.2,Tables2/4 and paragraph belowFig3, with prior registeredPDF hashes','assets':facts['source_hashes']}
def node(id,unit,value,loc,dependencies,derivation):
 return dict(common,id=id,evidence_kind='derived_from_evidence',role='physical_parameter',unit=unit,basis='per original kg dry feed' if unit=='1' else 'as specified by node derivation',value=value,dependencies=dependencies,derivation=derivation,citations=[{'source_id':source['id'],'locator':loc,'support':'value'}])
nodes=[
 node('GNEST_TG3_SOLID_YIELD','1',[.6919,.5687],'Table4 TG3(10K/min)570/960C',[],'Reported corrected solid mass / initial dry-feed mass; processed experimental readouts, no normalization.'),
 node('GNEST_REPORTED_DRY_SOLID_LHV_MJ_KG','J/kg',[7.77,5.19],'Section3.2 belowFig3 Solid1/Solid2 dryLHV',[],'Literal source numerical readout in MJ/kg; see actual unit field below.'),
 node('GNEST_DRY_SOLID_LHV','J/kg',[7770000.,5190000.],'Section3.2 belowFig3',['GNEST_REPORTED_DRY_SOLID_LHV_MJ_KG'],'Unit conversion of published MJ/kg drysolid to J/kg drysolid: multiply by1e6; no physical model.'),
 node('GNEST_RETAINED_CHAR_LHV_PER_DRY_FEED','J/kg',[5376063.,2951553.],'Table4 + Section3.2 belowFig3',['GNEST_TG3_SOLID_YIELD','GNEST_DRY_SOLID_LHV'],'calculate.py: multiply paper-linked endpoint yield by dry-solid LHV; nominal fuel inventory, not reaction heat. Source factsSHA '+hashlib.sha256((r/'source_facts.json').read_bytes()).hexdigest())]
for n in nodes[:2]:n['evidence_kind']='measured_public_data'
nodes[0]['basis']='kg dry solid product / kg original dry feed; normalized processed experimental mass readout'
nodes[1]['unit']='MJ/kg'
nodes[1]['basis']='per kg dry solid product; published fuel characterization readout, not raw calorimeter signal'
nodes[2]['basis']='per kg dry solid product'
nodes[3]['basis']='per kg original dry feed'

payload={'schema_version':'1.0','sources':[source],'nodes':nodes}
(r/'evidence_registry.json').write_text(json.dumps(payload,indent=2)+'\n')
trace=EvidenceRegistry.from_dict(payload).trace(nodes[-1]['id'])
(r/'registry_trace.json').write_text(json.dumps(trace,indent=2)+'\n')
print('trace validated',len(trace['nodes']))
