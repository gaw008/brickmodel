# Root source and numerical review

Read the cached published primary full text: title/DOI/year; sections 2.3 and 2.4 including Eq. 2; section 3.2 and Table 4. The nitrogen, 10 K/min, dry-feed denominator and 570/960 C endpoints support the paired paper-level calculation. Individual aliquot matching and joint uncertainty are not established. Source facts retain that limit.

Independently checked all four registered source-file SHA-256 values and recomputed each reported-yield times dry-solid-LHV product using exact Fraction arithmetic, separately from the author's Decimal calculation. See root-independent-check.json. The difference is retained solid fuel energy, not reaction heat, sensible heat or process heat demand. The declared real-material runtime admission remains false.

The first registry draft failed the existing derived-node upstream-dependency guard. It was not admitted. The final design uses measured source readouts, a separate mass-specific-energy unit conversion, and a derived inventory node. MJ/kg is represented as a physical unit with its SI scale, not as a dimensionless coefficient. The unit implementation and its positive/negative controls received Tesla code review approval. Root ran units and evidence tests: 42 passed in 0.07 s; root-unit-tests.xml retained. Registry syntax checks do not prove material applicability or full external validation.

Only factual readouts and original-source hashes may be copied to the repository. Full PDFs and extracted full text are not redistributed, given unresolved license wording. Existing source preparation locations remain evidence cache paths, not guaranteed future file locations.
