# Same-material admission assessment and actual data calculation

## Decision

The best currently inspected within-study candidate is Global NEST DOI10.30955/gnj.003738, El Salitre anaerobically digested/dewatered sludge. It is not presently admissible as the mixed thermal reaction host's real-material package. Changing solids from mol to kg removes the need to invent molecular masses, but does not repair missing stoichiometry, references, caloric/volume closure or uncertainty.

Read this turn: repository raw-sludge-closure-audit-v1 and gnest-related-energy-v1 READMEs; gnest2021 source_facts/audit_result/README; KNOWN_GAPS opening reference correction; actual cached accepted/published full-text methods/Table2/energy discussion. Accepted and published PDF hashes match the already registered source identities. No failed related-paper search was repeated and no web snippet was promoted into new evidence. Actual source paragraph identities and hashes are saved in source_facts.json. Material preparation:50kg dewatered El Salitre sample, predrying/crushing, quartering1kg,105°C10h drying,0.18–0.25mm sieving. This is the specified prepared sample, not all raw sludge or a clay brick.

## What can and cannot enter the new bridge

| Contract | Same-study evidence | Admission consequence |
|---|---|---|
| Reaction heat differences |25°C lower-heating-value product balance gives reported2.18MJ/kg dry feed to570°C. It is derived from the same product analysis, not independent calorimetric per-channel heat. | It can be retained as an aggregate conditional endpoint constraint. It cannot be split into six q_i, added again as external heat, or described as a full furnace heating demand. |
| Mass coefficients |Table3 fitted parallel pseudo-components; Eq11 requires product sums=yi. R5/R6 each miss0.050, exceeding the existing conditional0.008 printed-rounding bound. | Full B cannot be instantiated without unresolved data correction/new-species hypotheses. R1–R4 near mass closure alone do not prove element closure or individual component identities. |
| Complete element composition |Bulk feed and product analyses exist; liquid composition/yield partly inferred by difference. Oxygen analytical basis subtracts ash and is not total mineral oxygen.960°C mass total0.9507 and element gaps remain. | Do not construct complete component element_mass_fractions by filling residual as oxygen/ash or normalizing. The network's exact mass/element constraints correctly reject an unsupported full pathway. |
| Cp and U(T) |No complete same-material feed/pseudo-component/char/liquid caloric functions over the trajectory are supplied by the inspected facts. | LHV constrains combustion-energy differences, not Cp(T) or fixed-volume heat capacity. Arlabosse low-temperature drying sample is a different specimen and cannot silently complete this one. |
| Volume and phase/reference bridge |No same-component specific volume/thermal expansion/porosity closure or complete compatible condensed/gas energy-reference mapping. | The new constant-v/Cp manufactured host cannot be populated by copying unrelated coefficients. No positive pore-volume or U→T/P certificate can yet be claimed for this real sludge. |
| Kinetics/domain |Six fitted conversion channels, listed Ea/lnk0/n/yi; nitrogen-pyrolysis small-particle/TG protocol, not the new finite-O2 artificial reaction. | These rates may support a qualified prescribed-temperature TG model after resolving equations/data. They are not elementary mass-action oxygen kinetics or brick firing/sintering laws. |
| Uncertainty |Triplicate standard deviations for some inputs, inferred products and unspecified covariances/fit errors. | Nominal exact algebra is not an interval proof. Do not set unknown fit/reference uncertainty to zero. |

Related CEST2019 study still has only a website relationship and failed official full-text retrieval in existing audit; no demonstrated same batch or complementary Cp data. The separate Energies candidate is a different study/material. None may fill this package by name matching.

## One actual real-data calculation completed now

A bounded useful calculation requires no guessed reaction scheme: recoverable chemical fuel energy retained in the reported dry solid per kg original dry feed,

    retained_solid_LHV = reported solid yield × reported dry-solid LHV.

Actual Table4 TG3 at10K/min and the text belowFig3 give:

-570°C:0.6919kg solid/kg dry feed ×7.77MJ/kg solid = **5.376063MJ/kg original dry feed**, nominal47.5758% of feed LHV11.3MJ/kg.
-960°C:0.5687×5.19 = **2.951553MJ/kg original dry feed**, nominal26.1199%.
-Reduction of retained solid fuel energy: **2.424510MJ/kg original dry feed**.

`calculate.py` executed with standard-library Decimal50 precision, verified original source file hashes, saved result.json and checked independent exact products. No solver/EOS or runtime material installation. This is an actual measured/derived source-data fuel-inventory calculation, useful for deciding whether residual char retains appreciable chemical energy. It is neither heat released between570/960°C nor total reactor heat demand: energy may transfer to gas/liquid, mass closure is imperfect and sensible/external heat are omitted. No confidence interval is invented; source readout precision is not uncertainty. The reported40% solid energy fraction in the article uses a different total-energy denominator and is not silently substituted for47.5758% of nominal feed LHV.

## Concrete next material action

Keep this source-specific mass/energy inventory calculation and its signed unresolved residuals separate from simulation. For admission, request or locate the same experiment's corrected Table3 R5/R6 product coefficients, complete product elemental/basis data and compatible caloric/volume measurements across the intended interval. A valid reduced aggregate endpoint network may be built only when its admitted reaction row is mass/element balanced and its inferred/uncertain inputs are explicitly represented. Until then, the mixed host's successful artificial A+O2→2B test proves an interface and energy-accounting mechanism, not a real sludge reaction.

## Pairing and registry closeout

Primary methods2.3 explicitly ran additional10K/min tests to570°C to obtain solid samples;2.2 states nitrogen purge with oxygen below0.05%;2.4 Eq2 defines product mass/original dry-feed mass. Section3.2 links Fig3's10K/min endpoints to detailed Tables4/5; Table4 explicitly labels TG3(10K/min), dry basis. The belowFig3 paragraph supplies dry Solid1/Solid2 LHV. Thus within-study endpoint pairing is supported. Exact individual replicate/aliquot IDs and yield–LHV covariance are not established; these are nominal paired endpoint readouts, not independent repeated observations. Yield is processed/normalized experimental mass data; LHV is reported fuel characterization with the article's LHV conversion procedure, not newly inspected raw calorimeter signals.

`evidence_registry.json` now has four valid nodes: reported TG3 normalized solid yield; reported dry-solid LHV in actual MJ/kg; explicit J/kg unit conversion through production sludge_sandbox.units.convert; derived retained-char J/kg dryfeed product. Root added genuine MJ/kg SI-scale support and separately tested dimensional conversion. The raw LHV node preserves its physical mass-specific energy unit and the downstream conversion calls convert(value,'MJ/kg','J/kg'). Each node states its own mass basis. Source year2022 follows the published24(1):16–28 issue, with2021 online date kept in the original facts. measured_public_data inputs mean published processed experimental readouts; conversion/product are derived nodes with real dependencies. The prior dimensionless-readout workaround was removed and retained only in clearly named history files.

Actual production EvidenceRegistry.from_dict(...).trace(...) now resolves all4 nodes and source. The initial missing-dependency failure and subsequent unsupported-MJ/kg-unit failure were retained before correction; registry validation was not relaxed. Final registry-green03 uses the new real MJ/kg unit and resolves all4 nodes. Registry trace verifies declared metadata/dependencies, not specimen equivalence or material admission. This artifact can support an offline screening/fuel-inventory report; it cannot directly initialize MixedCell or assign its reaction q/Cp/v/kinetics.
