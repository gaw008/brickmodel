"""Nominal source-specific char LHV retained per original dry feed; no solver."""
from pathlib import Path
from decimal import Decimal as D,localcontext
import hashlib,json
root=Path(__file__).parent
raw=(root/'source_facts.json').read_bytes();facts=json.loads(raw)
for name,digest in facts['source_hashes'].items():
    if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest:raise ValueError('source_changed:'+name)
rows=[]
with localcontext() as c:
    c.prec=50
    for x in facts['facts']:
        energy=D(x['solid_yield'])*D(x['solid_lhv_mj_kg'])
        rows.append({'temperature_c':x['temperature_c'],'retained_solid_lhv_mj_per_kg_initial_dry_feed':str(energy),'fraction_of_nominal_feed_lhv':str(energy/D(facts['feed_lhv_mj_kg']))})
    difference=D(rows[0]['retained_solid_lhv_mj_per_kg_initial_dry_feed'])-D(rows[1]['retained_solid_lhv_mj_per_kg_initial_dry_feed'])
result={'status':'computed_from_reported_values','facts_sha256':hashlib.sha256(raw).hexdigest(),'rows':rows,'decrease_of_solid_retained_lhv_mj_per_kg_initial_dry_feed':str(difference),'interpretation':'Recoverable chemical fuel-energy inventory retained in reported dry char only; difference is not reaction heat and excludes transfer to gas/liquid, sensible heat, external heat and mass-balance deficit.','uncertainty':'unknown; no confidence interval inferred from printed precision or incomplete covariance','material_runtime_admission':False}
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
assert rows[0]['retained_solid_lhv_mj_per_kg_initial_dry_feed']=='5.376063'
assert rows[1]['retained_solid_lhv_mj_per_kg_initial_dry_feed']=='2.951553'
print(json.dumps(result,indent=2))
