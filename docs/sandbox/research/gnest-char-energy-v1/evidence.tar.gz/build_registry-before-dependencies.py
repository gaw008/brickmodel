"""Produce traceable endpoint facts and a derived fuel-inventory node, no host admission."""
from pathlib import Path
import json,hashlib
from sludge_sandbox.evidence import EvidenceRegistry
r=Path(__file__).parent
facts=json.loads((r/'source_facts.json').read_text())
common={'applicability':{'status':'conditional','rationale':'Only paper-linked10K/min El Salitre prepared-sludge endpoint data; individual aliquot pairing/covariance not established.'},'uncertainty':{'status':'unquantified','rationale':'Joint yield/LHV covariance and endpoint uncertainties not provided; displayed precision is not uncertainty.'},'domain':{'material_classes':['El_Salitre_prepared_digested_sludge'],'atmospheres':['nitrogen_pyrolysis'],'notes':'Discrete570/960C endpoints, dry basis; not a caloric curve or reaction heat.'}}
source={'id':'GNEST_003738_SAME_MATERIAL_ENDPOINTS','title':'A comprehensive study of the high temperature pyrolysis of sewage sludge: kinetics, energy analysis and products formation','url':'https://cosmos.gnest.org/publication/gnest_03738','authors':['Libardo Mendoza-Geney','S. Rincón Prat','A. Gómez'],'year':2022,'license':'Landing CC BY4 versus PDF all-rights-reserved conflict; facts only','retrieved_at':'2026-09-08','read_status':'data_checked','reading_scope':'Cached primary full-text sections2.1–2.4,3.2,Tables2/4 and paragraph belowFig3, with prior registeredPDF hashes','assets':facts['source_hashes']}
def node(id,unit,value,loc,dependencies,derivation):
 return dict(common,id=id,evidence_kind='derived_from_evidence',role='physical_parameter',unit=unit,basis='per original kg dry feed' if unit=='1' else 'as specified by node derivation',value=value,dependencies=dependencies,derivation=derivation,citations=[{'source_id':source['id'],'locator':loc,'support':'value'}])
nodes=[node('GNEST_TG3_SOLID_YIELD','1',[.6919,.5687],'Table4 TG3(10K/min)570/960C',[],'Published yields: corrected measured solid mass / initial dry-feed mass; no normalization.'),node('GNEST_DRY_SOLID_LHV','J/kg',[7770000.,5190000.],'Section3.2 belowFig3 Solid1/Solid2 dryLHV',[],'Published solid endpoint characterization; values MJ/kg drysolid converted×1e6, no raw calorimeter data inferred.'),node('GNEST_RETAINED_CHAR_LHV_PER_DRY_FEED','J/kg',[5376063.,2951553.],'Table4 + Section3.2 belowFig3',['GNEST_TG3_SOLID_YIELD','GNEST_DRY_SOLID_LHV'],'calculate.py: multiply corresponding paper-linked endpoint yield by dry-solid LHV; nominal fuel inventory, not q_reaction or heating demand. Inputs source_facts SHA '+hashlib.sha256((r/'source_facts.json').read_bytes()).hexdigest())]
payload={'schema_version':'1.0','sources':[source],'nodes':nodes}
(r/'evidence_registry.json').write_text(json.dumps(payload,indent=2)+'\n')
trace=EvidenceRegistry.from_dict(payload).trace(nodes[-1]['id'])
(r/'registry_trace.json').write_text(json.dumps(trace,indent=2)+'\n')
print('trace validated',len(trace['nodes']))
