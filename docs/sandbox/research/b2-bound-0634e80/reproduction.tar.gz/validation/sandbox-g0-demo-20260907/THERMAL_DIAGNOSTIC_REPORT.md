# 给温反应—输运与条件化原料研究报告

## 条件方向与限制（先读）

这是外部空间均匀给温、固定孔隙/壁几何、固定参考浓度的 synthetic 无量纲实验，不是真实污泥配方、供应商筛选或烧成秒数。
寻找原料时，应联合核对干基可氧化需氧负荷、基料—原泥配对、氧化时序、壁/肋厚和热态输运；本轮没有识别这些真实材料映射。
低负荷、提前升温、较小壁厚的方向必须以本页实际配对为条件，不能保证普遍改善；U0/U1只是假设包，不是概率区间或最坏界。
恒摩尔浓度源库不等于恒压空气；不建能量、压力、热膨胀流、孔关闭、收缩、强度、裂纹或排放模型。physical_time_seconds=null，material_mapping=unknown_real_material。

## 已验证事实：当前运行

- 绑定状态：bound；原因：matching_source_contract_inputs_executed_coverage。
- 实际源提交：0634e80b1fa4d69c195022f1c7ecd79a16110fe2。合同：B2-1.0.1；详见 manifest.json 的逐文件实算SHA256与完整展开输入。
- focused证据：{'path': 'validation/sandbox-g0-tests-20260907/verification.json', 'sha256': '85a47cc225f89a6ac44938f5f9af6a07a5ef9c96497ff80ac9d43c8d19e11afc'}。当前raw文件与audit身份均见manifest；无证据时不升级。
- 离散筛选状态计数（逐情景，不是供应商）：{'diagnostic_only': 10, 'sampled_candidate_under_assumptions': 10, 'unresolved_in_assumption_envelope': 2}。
- 数值标签只对应本次实际代表覆盖与逐例库存审计，不代表24门全部批准；独立Safety尚待单独审核，production_approved=false。

| 情景 | Γ | 最大局部剩余 f | 平均剩余 f | 芯部氧 u | 数值验证 | 条件筛选 |
|---|---:|---:|---:|---:|---|---|
| R01 | 2 | 4.1398861e-08 | 3.0957749e-08 | 0.99998526 | passed_frozen_suite | diagnostic_only |
| R02 | 2 | 1.4912263e-74 | 4.2258834e-75 | 0.99999848 | passed_frozen_suite | diagnostic_only |
| R03 | 2 | 0.3893443 | 0.37500264 | 3.8966168e-06 | passed_frozen_suite | diagnostic_only |
| R04 | 2 | 0.010655895 | 0.0085489706 | 0.48112918 | passed_frozen_suite | diagnostic_only |
| W01 | 0.5 | 6.3184379e-27 | 5.2950876e-27 | 0.99999972 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W02 | 0.5 | 2.9296354e-20 | 2.7213447e-20 | 0.99999758 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W03 | 2 | 2.8075181e-24 | 1.56581e-24 | 0.99999804 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W04 | 2 | 3.4432939e-19 | 2.5417669e-19 | 0.99998232 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W05 | 8 | 1.0138872e-12 | 2.8288433e-13 | 0.99882196 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W06 | 8 | 6.2450097e-11 | 2.0142355e-11 | 0.99675642 | passed_frozen_suite | unresolved_in_assumption_envelope |
| W07 | 0.5 | 1.3805427e-13 | 1.0946718e-13 | 0.9999818 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W08 | 0.5 | 2.4802068e-10 | 2.2076135e-10 | 0.99986463 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W09 | 2 | 1.4266887e-11 | 7.0556158e-12 | 0.99984764 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W10 | 2 | 3.1293849e-09 | 1.9885877e-09 | 0.99903215 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W11 | 8 | 0.0021849646 | 0.00054910603 | 0.85056192 | passed_frozen_suite | sampled_candidate_under_assumptions |
| W12 | 8 | 0.0094285714 | 0.002639467 | 0.73052084 | passed_frozen_suite | unresolved_in_assumption_envelope |
| L01 | 2 | 4.8817197e-18 | 1.3585921e-18 | 0.98970325 | passed_frozen_suite | diagnostic_only |
| L02 | 2 | 1.1036244e-14 | 3.7396872e-15 | 0.97835725 | passed_frozen_suite | diagnostic_only |
| C01 | 2 | 1 | 1 | 1 | passed_frozen_suite | diagnostic_only |
| C02 | 2 | 0.5 | 0.5 | 4.60155e-28 | passed_frozen_suite | diagnostic_only |
| C03 | 2 | 0.39753989 | 0.375 | 1.3857491e-14 | passed_frozen_suite | diagnostic_only |
| C04 | 2 | 0.00011274486 | 7.4795326e-05 | 0.99993652 | passed_frozen_suite | diagnostic_only |

## 实际配对与可证伪反例

以下差值均为后者减前者，正差表示所列后者局部残余更多；不是材料因果证明。

### 给温程序配对
- W01→W02：末态 f_max 差=2.9296348e-20；实际采样最小芯部氧分别 0.73996945/0.86006471。
- W03→W04：末态 f_max 差=3.4432659e-19；实际采样最小芯部氧分别 0.22275265/0.53076891。
- W05→W06：末态 f_max 差=6.143621e-11；实际采样最小芯部氧分别 0.0068767587/0.059851134。
- W07→W08：末态 f_max 差=2.4788263e-10；实际采样最小芯部氧分别 0.72875482/0.85823698。
- W09→W10：末态 f_max 差=3.1151181e-09；实际采样最小芯部氧分别 0.22316465/0.51666942。
- W11→W12：末态 f_max 差=0.0072436068；实际采样最小芯部氧分别 0.0069889427/0.038618929。
- L01→L02：末态 f_max 差=1.1031363e-14；实际采样最小芯部氧分别 0.047927678/0.21745998。

### 壁厚配对（共同τ，不是磨细颗粒）
- W03→L01：末态 f_max 差=4.8817169e-18；实际采样最小芯部氧分别 0.22275265/0.047927678。
- W04→L02：末态 f_max 差=1.10359e-14；实际采样最小芯部氧分别 0.53076891/0.21745998。
本离散域未观察到“早升温使末态局部残余更高”的反转；这不能证明连续域或真实材料必然如此。
- R03：氧预算转化上界=0.625；末态剩余均值=0.37500264；末态源率=3.0165435e-06；平均99事件={'tau': None, 'bracket_tau': None, 'status': 'excluded_by_oxygen_budget'}；局部99事件={'tau': None, 'bracket_tau': None, 'status': 'excluded_by_oxygen_budget'}。
- C03：氧预算转化上界=0.625；末态剩余均值=0.375；末态源率=3.8871963e-14；平均99事件={'tau': None, 'bracket_tau': None, 'status': 'excluded_by_oxygen_budget'}；局部99事件={'tau': None, 'bracket_tau': None, 'status': 'excluded_by_oxygen_budget'}。
- R04：氧预算转化上界=None；末态剩余均值=0.0085489706；末态源率=0.0083453848；平均99事件={'tau': 19.674699960825766, 'bracket_tau': [19.6, 19.700000000000003], 'status': 'reached_diagnostic_threshold'}；局部99事件={'tau': None, 'bracket_tau': None, 'status': 'not_reached_by_horizon'}。

## 合理推断与待验证假设

- 仅在同一基料代理、供氧边界和给温窗口内讨论负荷—输运条件。finite总氧库存的必要上界不因提前反应而改变；反应近停不是燃尽。
- f_max是最大cell平均，不是连续场严格最大值；事件由0.1τ输出包围区间插值，null表示未发生，不是0误差。guard=0.005是报告缓冲，不是已证明的全域误差界。
- 不把PSD磨细当作减小壁半厚；脱水不自动降低干基可氧化碳Γ。预氧化/混配可能改变孔隙、塑性、多组分气体和排放，这些联动未建模。
- S02输运拟合限环境温度至500°C，A600异常；S09为N2预热后切气的873–1273K颗粒准等温试验，40–60%转化拟合、80/100%O2自热排除；非整数分压阶与K0单位未解决。没有把这些候选参数迁为B2材料常数（原来源定位见CONTRACT.md §3）。
- 守恒审计仅重建导出库存/通量/派生指标，不是完整ODE真实性或任意协同篡改检测。独立数学参考、源码身份、实际重跑是不同证据层。
- thermal_profiles.svg / conditional_screening.svg 来自CSV，结构和坐标可复算；未做GUI/CJK像素验收。

## 证据与复现

manifest.json → 完整inputs、raw_result_files、current_audit、focused_evidence、coverage；verification.json → 本次逐情景标签；test_results.json → 原24门与未执行独立审核；resources.json → 计算机墙钟/RSS，不是过程时间。
复现顺序与离线封包见README.md。无部署；失败则停止使用隔离模块并保留证据，撤销提交须Manager批准revert，不删除B1/Stage1或改写历史。
