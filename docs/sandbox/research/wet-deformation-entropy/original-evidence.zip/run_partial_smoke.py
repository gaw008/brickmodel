from pathlib import Path
import os,subprocess,time,json
p=Path(__file__).resolve().parent;r=Path('/Users/wanggaoying/Desktop/brickmodel-github');start=time.monotonic()
env=dict(os.environ,PYTHONPATH=f'{r}/src:{r}/tests/sandbox:{p}',PYTHONDONTWRITEBYTECODE='1')
command=[str(r/'.venv/bin/python'),str(p/'partial_smoke.py')]
with (p/'partial-smoke.log').open('w') as stream:
    try:
        done=subprocess.run(command,cwd=r,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=30)
        status={'status':'finished','exit_code':done.returncode}
    except subprocess.TimeoutExpired:
        status={'status':'timeout','hard_limit_seconds':30}
status.update(elapsed_seconds=time.monotonic()-start,command=command)
(p/'partial-smoke-run-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status))
