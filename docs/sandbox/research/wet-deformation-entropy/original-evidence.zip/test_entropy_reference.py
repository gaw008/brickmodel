import math
from dataclasses import replace
import pytest
from entropy_reference import FixedInventoryEntropyReference,OracleInputs,OraclePolicy,EntropyOracleError

class ForbiddenWater:
    def __getattribute__(self,name):raise AssertionError('dry reference accessed water')


def fixture(**changes):return OracleInputs(**(dict(liquid_mol=0.,gas_mol=.01,solid_mol=2.,gas_cp_j_mol_k=30.,solid_cp_j_mol_k=5.,solid_molar_volume_m3_mol=2e-5,initial_temperature_k=300.,initial_bulk_volume_m3=1.4e-4,gas_constant_j_mol_k=8.31446261815324)|changes))


def policy():return OraclePolicy((295.,310.),(1e4,1e6),1e-9,1e-6,1e-8,1e-14,100)


def test_dry_independent_analytic_compression_no_water():
    data=fixture();r=FixedInventoryEntropyReference(data,policy(),ForbiddenWater())
    for lam in (1.,.97,.94,.9):
        volume=data.initial_bulk_volume_m3*lam**3;s=r.solve(volume)
        vp=volume-data.solid_mol*data.solid_molar_volume_m3_mol
        vp0=data.initial_bulk_volume_m3-data.solid_mol*data.solid_molar_volume_m3_mol
        capacity=.01*(30-data.gas_constant_j_mol_k)+2*5
        expected=300*(vp0/vp)**(.01*data.gas_constant_j_mol_k/capacity)
        assert abs(s.temperature_k-expected)<2e-9
        assert abs(s.pressure_pa-.01*data.gas_constant_j_mol_k*expected/vp)<1e-5
        assert abs(s.entropy_residual_j_k)<=1e-8
        assert s.water_calls==0


def test_same_volume_returns_initial_state():
    r=FixedInventoryEntropyReference(fixture(),policy(),None);s=r.solve(1.4e-4)
    assert abs(s.temperature_k-300)<1e-9


@pytest.mark.parametrize('kw',[{'liquid_mol':-1.},{'gas_mol':0.},{'gas_cp_j_mol_k':2.},{'solid_mol':float('nan')},{'initial_temperature_k':True}])
def test_invalid_inputs(kw):
    with pytest.raises(EntropyOracleError):fixture(**kw)


def test_pore_exhaustion_and_temperature_bracket_failure():
    r=FixedInventoryEntropyReference(fixture(),policy(),None)
    with pytest.raises(EntropyOracleError):r.solve(1e-5)
    with pytest.raises(EntropyOracleError):r.solve(4.01e-5)


def test_dry_volume_residual_must_obey_explicit_policy_gate():
    p=replace(policy(),volume_residual_tolerance_m3=1e-100)
    with pytest.raises(EntropyOracleError,match='residual_exceeds_gate'):
        r=FixedInventoryEntropyReference(fixture(),p,None)
        r.solve(.00013502023808)
