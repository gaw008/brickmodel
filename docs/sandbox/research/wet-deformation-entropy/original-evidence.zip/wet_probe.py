"""One bounded measurement: executed only after root's EOS release."""
from pathlib import Path
from dataclasses import asdict,replace
import json,time,traceback,hashlib
from entropy_reference import OracleInputs,OraclePolicy,FixedInventoryEntropyReference
from sludge_sandbox.water_properties import load_water_properties

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
OUT=Path(__file__).resolve().parent/'wet-probe-result.json'
started=time.monotonic()
result={'status':'running','stages':[],'qualification':'independent_water_entropy_points_not_trajectory_validation'}
def save():
    result['elapsed_seconds']=time.monotonic()-started
    OUT.write_text(json.dumps(result,indent=2)+'\n')
def stage(name,value):
    result['stages'].append({'name':name,'value':value,'elapsed_seconds':time.monotonic()-started});save()
try:
    w=load_water_properties(ROOT/'data/sandbox/water')
    result['water_reference']=asdict(w.reference);result['water_assets']=dict(w.source_asset_sha256);result['water_limits']=asdict(w.numerical_limits)
    inputs=OracleInputs(1.,.01,2.,30.,5.,2e-5,300.,1.4e-4,8.31446261815324)
    policy=OraclePolicy((295.,310.),(1e4,1e6),1e-9,1e-6,1e-8,1e-14,100)
    result['inputs']=asdict(inputs);result['policy']=asdict(policy);save()
    ref=FixedInventoryEntropyReference(inputs,policy,w)
    stage('initial',{'temperature_k':300.,'pressure_pa':ref.initial_pressure_pa,'gas_volume_m3':ref.initial_gas_volume_m3,'water_calls':ref.initial_water_calls,'elapsed_seconds':ref.initial_elapsed_seconds})
    endpoint=ref.solve(inputs.initial_bulk_volume_m3*.9**3);stage('endpoint',asdict(endpoint))
    tight=FixedInventoryEntropyReference(inputs,replace(policy,temperature_xtol_k=policy.temperature_xtol_k/2,pressure_xtol_pa=policy.pressure_xtol_pa/2),w)
    second=tight.solve(inputs.initial_bulk_volume_m3*.9**3)
    delta_t=abs(endpoint.temperature_k-second.temperature_k);delta_p=abs(endpoint.pressure_pa-second.pressure_pa)
    stage('endpoint_half_xtol',asdict(second)|{'delta_temperature_k':delta_t,'delta_pressure_pa':delta_p,'additional_initial_water_calls':tight.initial_water_calls})
    assert delta_t<=2e-7 and delta_p<=.002,'oracle refinement gate'
    if time.monotonic()-started<15:
        # Independent timing only; this call is NOT used to construct truth.
        from test_deforming_solid_storage import exact_volume_wet_model
        from sludge_sandbox.phase_storage import InversePolicy
        point=exact_volume_wet_model(w)
        point=replace(point,motion=replace(point.motion,tangential_stretches_at_knots=(1.,.9)))
        t=time.monotonic();forward=point.forward(endpoint.temperature_k,liquid_mol=1.,gas_mol={'fixture':.01},solid_mol={'fixture_solid':2.},time_s=1.)
        forward_seconds=time.monotonic()-t
        t=time.monotonic();inverse=point.temperature_from_total_energy(point.target(forward.total_energy_j,forward.energy_error_bound_j),liquid_mol=1.,gas_mol={'fixture':.01},solid_mol={'fixture_solid':2.},time_s=1.,temperature_bracket_k=(295.,310.),policy=InversePolicy(1e-6,1e-6,100))
        inverse_seconds=time.monotonic()-t
        actual=inverse.state.thermal_state.mechanical
        stage('point_storage_cost',{'forward_seconds':forward_seconds,'inverse_seconds':inverse_seconds,'temperature_k':actual.temperature_k,'pressure_pa':actual.pressure_pa,'temperature_difference_from_entropy_k':actual.temperature_k-endpoint.temperature_k,'pressure_difference_from_entropy_pa':actual.pressure_pa-endpoint.pressure_pa,'temperature_error_bound_k':inverse.temperature_error_bound_k,'interpretation':'point initialized with entropy T; roundtrip/comparison only, not evolved path'})
    else:stage('point_storage_cost',{'status':'skipped','reason':'protect_remaining_30_second_budget'})
    result['status']='completed';save()
except BaseException as exc:
    result['status']='failed';result['exception_type']=type(exc).__name__;result['exception']=str(exc);result['traceback']=traceback.format_exc();save();raise
