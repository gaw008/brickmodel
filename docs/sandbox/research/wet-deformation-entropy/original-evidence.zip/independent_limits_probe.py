"""Independent analytic limits; mocked incompressible liquid, no wet EOS calls."""
from dataclasses import replace
from types import SimpleNamespace
import math
from entropy_reference import OracleInputs,OraclePolicy,FixedInventoryEntropyReference
from sludge_sandbox.water_properties import WaterProperties,load_water_properties
R=8.31446261815324
p=OraclePolicy((200.,500.),(1e3,1e7),1e-10,1e-7,1e-10,1e-14,100)
i=OracleInputs(0.,.01,0.,30.,5.,2e-5,300.,1.4e-4,R)
r=FixedInventoryEntropyReference(i,p,None)
for f in (.8,1.,1.2):
 s=r.solve(i.initial_bulk_volume_m3*f)
 assert abs(s.temperature_k-300*f**(-R/(30-R)))<2e-9
print('pure ideal gas no solid/liquid: three closed adiabatic points PASS')
w=load_water_properties('data/sandbox/water')
M=w.reference.molar_mass_kg_mol
original=WaterProperties.state_tp
calls=[]
def manufactured(self,t,p,phase):
 assert phase=='liquid';calls.append((t,p))
 # Exact incompressible caloric fixture v=18e-6 m3/mol, Cp=75 J/mol/K.
 return SimpleNamespace(density_kg_m3=M/18e-6,native_entropy_j_kg_k=75/M*math.log(t/300.))
WaterProperties.state_tp=manufactured
try:
 i=replace(i,liquid_mol=1.,solid_mol=2.)
 r=FixedInventoryEntropyReference(i,p,w)
 v0=i.initial_bulk_volume_m3-2*2e-5-18e-6
 C=75+.01*(30-R)+2*5
 for f in (.8,1.,1.2):
  bulk=i.initial_bulk_volume_m3*f;s=r.solve(bulk);vg=bulk-2*2e-5-18e-6
  expected=300*(v0/vg)**(.01*R/C)
  assert abs(s.temperature_k-expected)<2e-9
  assert abs(s.pressure_pa-.01*R*expected/vg)<1e-5
 print('fixed incompressible liquid + ideal gas + solid: three points PASS; only manufactured calls',len(calls))
finally:
 WaterProperties.state_tp=original
