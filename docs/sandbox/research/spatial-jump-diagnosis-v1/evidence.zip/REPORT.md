# Next spatial diagnosis from retained evidence

Read-only analysis, 2026-09-08. No EOS, source edits, or new run. Sources: docs/sandbox/FREE_SPATIAL_STUDY.md; research/free-spatial-study-v1/{README,FOUR_AUDIT,matrix-audit-metrics,initial-rate-scales}; original reacting-wet-free-slab-v1.json; retained time-matrix-final/audit_matrix.py.

## Finding

The observed doubling is quantitatively consistent with an unresolved **internal initial temperature/concentration jump**, rather than evidence of a geometry bug. It is not an outer furnace thermal boundary layer: this case has no prescribed outer surface temperature. This diagnosis is supported, but not a proof excluding every discretization defect.

For initial temperature jump 1 K at the central material plane, Fourier conductance is k A / dx. With k=1 W/(m K), A=.01 m² and dx=.01/.005/.0025 m, initial heat transfer magnitudes are 1/2/4 W. Over duration 2^-16 s the leading short-time integrals are 1.52587890625e-5, 3.0517578125e-5, 6.103515625e-5 J. Actual fine-time central-face total energy integrals are 1.5258650869062363e-5, 3.0517162345275274e-5, 6.1033209574449025e-5 J: they agree with this leading scaling to about 9.1e-6, 1.36e-5, 3.19e-5 relative. Actual total face energy also contains species enthalpy, and geometry/temperatures evolve; the small differences are not asserted to be conduction error alone.

The parent-restricted E discrepancies 1.52586e-5 and 3.05161e-5 J follow the successive flux differences. Parent solid heat capacity is approximately 2 mol ×5 J/(mol K)=10 J/K; gas/liquid add a small contribution. E differences divided by this capacity give ~1.526e-6 and ~3.052e-6 K, closely matching measured 1.52254e-6 and 3.04496e-6 K. Thus the temperature comparison is measuring a genuine mesh-dependent transfer, not merely comparing differently sized cells incorrectly.

## Distinguish thermal and mass scales

The archived sqrt(D dt)=.391 micrometres uses **water diffusivity**, not thermal diffusivity. It cannot by itself explain the thermal scale numerically. Initial parent reference volume is .0001 m³ and solid capacity ~10 J/K, so rough volumetric heat capacity is ~1e5 J/(m³ K), alpha≈1e-5 m²/s, and sqrt(alpha dt)≈12.35 micrometres. This is an initial constant-coefficient estimate, not the coupled model's certified diffusivity: gas/liquid calorics, pressure closure, mechanical/reaction feedback remain. Even this thermal scale is ~200 times smaller than the 8-cell 2500 micrometre width. Thermal Fourier numbers are roughly1.53e-6/6.10e-6/2.44e-5. The discrete interface has hardly relaxed, so integrated transfer scales as dt/dx and doubles on each refinement. A continuum initial-step heat solution instead has early transferred energy proportional to sqrt(time), but invoking that continuum result is qualitative here, not a quantitative oracle for the full wet coupled system.

## Norm and geometry assessment

The registered norm restricts extensive N/E to the same original parent bins and averages T by reference volume; common tangent is compared separately. This is a legitimate weak diagnostic for this fixed material-coordinate study. It is not a pointwise norm, nor exact thermodynamic temperature reconstructed from restricted E/N, and can conceal fine-scale errors. None of these qualifications makes its resolved increasing E/T discrepancy disappear. Changing to a norm that yields smaller numbers would not repair the failed original gate.

Evidence against a simple geometry/scaling fault includes initial conservative parent-to-child E/N checks, q(N) scaling and reference geometry tests, complete prefix conservation audits, correct kA/dx leading factor, and the same doubling in central water exchange. Conservation alone does not prove correct face coefficients. The next check should explicitly test the saved actual current widths/face areas against the actual initial flux before drawing a stronger conclusion. No observed spatial order should be reported: D48>D24 and current grid is far outside a resolved-interface regime.

## One minimum next experiment: initial-jump scaling audit on the original six runs

Do a saved-data-only, independent arithmetic experiment before spending another native run. Preserve all original failed spatial gates and cases. For each retained2/4/8 fine run:

1. Read original initial/current geometry, temperatures, gas inventories and complete face ledger. At the original central face independently compute the Fourier contribution k A (T_left−T_right)/distance using actual current area and half-width sum, not guessed index spacing. Independently evaluate the saved-data gas mass-frame contribution and common-face-temperature enthalpy combination when the needed source caloric coefficients are present. No new EOS samples.
2. Compare initial face rates across meshes and compute the frozen-initial-rate integral over the actual duration. Compare with recorded full central-face integral. Reconstruct parent E changes from all actual boundary/internal transport and body/external/constraint work; avoid attributing phase/reaction/mechanical local terms to conduction. Use saved prefix terms and original arithmetic error allowances.
3. Restrict the resulting frozen-rate increment to original parent bins, reconstruct its predicted leading E/T mesh discrepancy using actual saved storage capacity only if present. If capacity is missing, report the 10 J/K dimensional estimate separately, never fill a certificate with it.
4. Preregister interpretations: matching actual geometric conductance and complete face arithmetic plus dt/dx leading behavior supports pre-asymptotic jump explanation; disagreement beyond existing arithmetic allowances indicates a concrete geometry/assembler/record issue to fix before another spatial run. Neither outcome turns the original nonconvergence into a pass. Missing saved initial diagnostics means this part is unavailable, not guessed.

Estimated cost: standard-library JSON/Fraction audit of six existing bundles, minutes of implementation and seconds to tens of seconds of processing; zero native calls. This is the smallest discriminating experiment because another identical-horizon 16-cell run is expected merely to double the same unresolved transfer again. It does not substitute a smooth or dry easy case for the original wet case.

## What a later real resolution study would cost

At unchanged alpha, an8-cell thermal Fourier number near1 requires ~.625 s (about40960 original horizons), whereas mass diffusion requires~625 s. These are scale estimates, not planned valid integration times. Existing initial liquid/rate scales are .267–.283 ms; depletion occurs long before thermal spatial relaxation and therefore event handling is a required prerequisite. Later kinetics, temperature and stretch domains may prevent reaching either horizon.

Keeping the original tiny time cap to .625 s would require ~81920 panels instead of2; extrapolating measured8-cell 15-evaluation58.9s/29-evaluation106.6s gives order days, not a safe budget estimate. Adaptive/event-controlled time steps and fresh domain/resource preregistration are necessary. Conversely resolving ~12 micrometres at the original time would need order1600 cells over .02m (more for several cells per layer), outside current2/4/8 admission; native cost and stiffness rise substantially. No such run is recommended now.

All original spatial failures remain. The immediate saved-data diagnostic can locate a real assembler error if present, or establish why the observed factor-of-two is expected in this regime. It cannot certify full wet-to-fired/cooled convergence, a raw-sludge material, or meaningful final brick quality.
