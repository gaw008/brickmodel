"""Saved ZIP/JSON arithmetic only; no model, EOS, or numerical solver imports."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import traceback
import zipfile

HERE = Path(__file__).resolve().parent
ARCHIVE = Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/free-spatial-study-v1/raw-evidence.zip')
RUNS = {(2,0):'two-coarse-baseline', (4,0):'brick-free-spatial-study/native-four/attempt01',
        (4,1):'brick-free-spatial-study/matrix-next/four-fine',
        (8,0):'brick-free-spatial-study/matrix-next/eight-coarse',
        (2,1):'brick-free-spatial-study/time-matrix-final/two-fine',
        (8,1):'brick-free-spatial-study/time-matrix-final/eight-fine'}


def read(raw: bytes) -> dict:
    def pairs(items):
        output={}
        for key,value in items:
            if key in output:raise ValueError('duplicate JSON key')
            output[key]=value
        return output
    def invalid(value):raise ValueError('nonfinite JSON '+value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def exact(value):
    if type(value) not in (int,float) or not math.isfinite(value):raise ValueError('finite number required')
    return F(value)


def magnitude(value):
    return {'numerator':value.numerator,'denominator':value.denominator,'float':float(value)}


def audit(report):
    report['archive_sha256']=hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    initial_parents={}
    with zipfile.ZipFile(ARCHIVE) as archive:
        for (cells,refinement),prefix in RUNS.items():
            row={'cells':cells,'refinement':refinement,'prefix':prefix}
            report['runs'].append(row)
            manifest=read(archive.read(prefix+'/manifest.json'))
            row['manifest_sha256']=hashlib.sha256(archive.read(prefix+'/manifest.json')).hexdigest()
            for name,digest in manifest['files'].items():
                if hashlib.sha256(archive.read(prefix+'/'+name)).hexdigest()!=digest:
                    raise ValueError('manifest hash mismatch '+prefix+'/'+name)
            row['verified_manifest_members']=len(manifest['files'])
            payloads={name:archive.read(prefix+'/'+name) for name in ('case.json','result.json')}
            row['inputs_sha256']={name:hashlib.sha256(data).hexdigest() for name,data in payloads.items()}
            case,result=(read(payloads[name]) for name in ('case.json','result.json'))
            if result['status']!='completed' or case['grid']['cells']!=cells or case['refinement']!=refinement:
                raise ValueError('run identity/status')
            snap=result['initial_snapshot'];run=result['integration'];states=run['states'];steps=run['steps']
            if not steps or len(states)!=len(steps)+1:raise ValueError('empty/incomplete trajectory')
            factor=cells//2
            def parents(state):
                return {'N':[[sum((exact(state['amounts_mol'][i][j]) for i in range(p*factor,(p+1)*factor)),F())
                    for j in range(len(state['amounts_mol'][0]))] for p in range(2)],
                    'E':[sum((exact(state['internal_energy_j'][i]) for i in range(p*factor,(p+1)*factor)),F()) for p in range(2)]}
            initial_parents[cells,refinement]=parents(states[0])
            final=parents(states[-1]);first=parents(states[0])
            row['parent_energy_changes_j']=[magnitude(x-y) for x,y in zip(final['E'],first['E'])]
            row['parent_child_indices']=[list(range(p*factor,(p+1)*factor)) for p in range(2)]
            geometry=snap['geometry'];normals=states[0]['mechanical_stretches'][:-1];t=exact(states[0]['mechanical_stretches'][-1])
            area=exact(case['grid']['reference_face_area_m2'])*t*t
            widths=[exact(case['grid']['half_thickness_m'])/cells*exact(n) for n in normals]
            row['geometry_width_max_representation_difference_m']=magnitude(max(abs(w-exact(v)) for w,v in zip(widths,geometry['widths_m'])))
            row['geometry_area_max_representation_difference_m2']=magnitude(max(abs(area-exact(v)) for v in geometry['face_areas_m2']))
            temperatures=list(map(exact,snap['temperature_k']))
            nominal=[exact(case['initial']['parent_temperatures_k'][i//factor]) for i in range(cells)]
            row['decoded_vs_nominal_initial_temperature_max_k']=magnitude(max(abs(a-b) for a,b in zip(temperatures,nominal)))
            conductivity=exact(case['transport']['coupled_conductivity_w_m_k'])
            if case['transport_mode']!='coupled':raise ValueError('original coupled study required')
            duration=exact(run['times_s'][-1])-exact(run['times_s'][0])
            face_records={entry['face_index']:entry for entry in snap['internal_faces']}
            row['faces']=[]
            for face in range(1,cells):
                distance=(widths[face-1]+widths[face])/2
                heat=conductivity*area*(temperatures[face-1]-temperatures[face])/distance
                face_data=face_records[face]
                # Saved gas flux/enthalpy combination is disclosed as dependent
                # source evidence; only Fourier arithmetic is independently recomputed.
                exchange=face_data['exchange_reconstructed']
                if any(exact(v)!=0 for v in exchange['advective_mol_s'].values()):raise ValueError('unexpected advection')
                gas=sum((exact(v)*exact(face_data['enthalpy_j_mol_at_face_temperature'][species])
                         for species,v in exchange['diffusive_mol_s'].items()),F())
                expected=heat+gas;actual=exact(snap['rates']['face_energy_w'][face])
                residual=actual-expected
                # Existing face arithmetic diagnostic allowance, not a spatial gate.
                allowance=F(1e-12)+64*F(math.ulp(float(expected)))
                total=sum((exact(step['face_energy_j'][face]) for step in steps),F())
                first_integral=exact(steps[0]['face_energy_j'][face])
                first_dt=exact(steps[0]['end_s'])-exact(steps[0]['start_s'])
                row['faces'].append({'index':face,'central':face==cells//2,
                    'fourier_initial_w':magnitude(heat),'saved_gas_enthalpy_combination_w':magnitude(gas),
                    'actual_initial_total_w':magnitude(actual),'initial_rate_residual_w':magnitude(residual),
                    'arithmetic_allowance_w':magnitude(allowance),'rate_within_original_arithmetic_allowance':abs(residual)<=allowance,
                    'full_integral_j':magnitude(total),'frozen_fourier_integral_j':magnitude(heat*duration),
                    'full_minus_frozen_total_j':magnitude(total-actual*duration),
                    'first_minus_frozen_total_j':magnitude(first_integral-actual*first_dt),
                    'short_time_approximation_relative_difference':None if actual==0 else float((total-actual*duration)/(actual*duration))})
            if not all(f['rate_within_original_arithmetic_allowance'] for f in row['faces']):
                raise ValueError('initial face arithmetic inconsistency')
            # Exact parent ledger mapping: left-minus-right face energy and all
            # local work, including mechanical constraint/body, without relabeling.
            row['parent_energy_ledger_residuals_j']=[]
            for parent in range(2):
                lo,hi=parent*factor,(parent+1)*factor
                ledger=sum((exact(step['face_energy_j'][lo])-exact(step['face_energy_j'][hi])+
                    sum((exact(step['cell_work_j'][i]) for i in range(lo,hi)),F()) for step in steps),F())
                row['parent_energy_ledger_residuals_j'].append(magnitude(final['E'][parent]-first['E'][parent]-ledger))
    baseline=initial_parents[2,0]
    report['initial_parent_mapping_exact']={str(key):value==baseline for key,value in initial_parents.items()}
    if not all(report['initial_parent_mapping_exact'].values()):raise ValueError('initial parent mapping mismatch')
    report['status']='arithmetic_audit_completed'
    report['spatial_convergence']='not_established_original_failed_gate_unchanged'


def main():
    report={'status':'started','runs':[],'qualification':'Independent saved-data Fourier/geometry/parent arithmetic. Frozen-rate short-time approximation is diagnostic, not an error certificate.',
            'command':'python3 /private/tmp/brick-next-spatial-diagnosis/audit.py',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    code=0
    try:audit(report)
    except BaseException:
        report['status']='failed';report['traceback']=traceback.format_exc();code=1
    temporary=HERE/'audit-result.json.tmp'
    temporary.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    temporary.replace(HERE/'audit-result.json')
    return code


if __name__=='__main__':raise SystemExit(main())
