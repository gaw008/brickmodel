from fractions import Fraction as F
import pytest
from test_source_liquid_column import setup
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_wet_column import SourceWetColumn
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.integration import IntegrationPolicy,IntegrationError,DomainExit
from sludge_sandbox.exact_integration import integrate_exact

@pytest.mark.parametrize('domain',[False,True])
def test_failure_category_and_original_cause(monkeypatch,domain):
 c,s=setup(monkeypatch,count=1);h=ExactSourceColumn(c);state=h.pack(s)
 failure=DomainExit('independent_domain') if domain else ValueError('independent_source_failure')
 def fail(*a,**k):raise failure
 monkeypatch.setattr(SourceWetColumn,'evaluate',fail)
 with pytest.raises(type(failure)) as raw:h.evaluate(state,T(F()))
 assert raw.value is failure
 with pytest.raises(DomainExit if domain else IntegrationError) as converted:h(state,T(F()))
 if domain:assert converted.value is failure
 else:assert converted.value.__cause__ is failure
 p=IntegrationPolicy(1/128,1/128,1/4096,1e-8,1e-7,1e-3,1.,1e5,8,8,5.)
 r=integrate_exact(state,h,start_s=T(F()),end_s=T(F(1,128)),policy=p)
 assert r.status==('domain_exit' if domain else 'numerical_failure')
 assert len(r.states)==1 and not r.steps
