# Exact-source native runner static review

Reviewed original runner and final exception-only correction, SHA60d1329d0473281c722169cad75690f9b409b4d4788931c7f7e69d48f5bcf9e4. AST parse only; no EOS execution. Reuses archived actual source-liquid construction and its source/table identity, packs fluid-only mol state with source dry kg retained in model identity.

Each callback calls adapter.evaluate once and preserves ordinal, packed input, exact time and full physical evaluation; same-time stages are not merged. Corrected boundary preserves both DomainExit and IntegrationError explicitly; other ValueError becomes IntegrationError with original cause. This avoids bypassing the adapter callback classification while preserving full observation. Pending input snapshots survive a failed call. Original integrator result is saved before unpack/audit, failure snapshots preserve captures and return1. Atomic JSON disallows NaN.75s integrator and90s outer alarm are explicit resource limits.

Independent ledger audit uses actual accepted float integrals as exact Fractions, reports nonzero local/cumulative state-minus-ledger residuals and checks them against original per-quantity absolute policy budgets. Global water and U residuals equal sums of local residuals; derived global bounds reflect cell/species count. Paired phase terms cancel exactly and liquid exterior flux stays zero. Fixed dry masses/no mechanics are checked. These are arithmetic assembly bounds, not claimed truncation or physical fit certificates. No extra EOS or callback for audit; unpack validates only.

No unresolved critical functional issue identified. Final runner is eligible for the authorized bounded native attempt after installing matching adapter. This review does not claim native completion.
