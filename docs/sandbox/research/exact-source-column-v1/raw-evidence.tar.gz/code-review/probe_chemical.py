from dataclasses import replace
from fractions import Fraction as F
from pytest import MonkeyPatch
from test_source_liquid_column import setup
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_wet_column import SourceWetColumn
from sludge_sandbox.exact_event_clock import ExactEventTime
m=MonkeyPatch();c,s=setup(m,count=1);host=ExactSourceColumn(c);packed=host.pack(s)
original=SourceWetColumn.evaluate
for changes in ({'chemical_reference_power_w':F(1)},{'phase_transfer_included':True}):
 def altered(self,states):
  out=original(self,states);cell=out.cells[0]
  return replace(out,cells=(replace(cell,chemistry=replace(cell.chemistry,**changes)),))
 m.setattr(SourceWetColumn,'evaluate',altered)
 out=host.evaluate(packed,ExactEventTime(F()))
 print('accepted',changes,'cell_power',out.rates.cell_power_w.tolist())
m.undo()
