from dataclasses import replace
from fractions import Fraction as F
import numpy as np
import pytest
from test_source_liquid_column import setup
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.source_wet_column import SourceWetColumn

@pytest.mark.parametrize('changes',[{'chemical_reference_power_w':F(1)},{'phase_transfer_included':True}])
def test_reject_unsupported_chemical_metadata(monkeypatch,changes):
 c,s=setup(monkeypatch,count=1);h=ExactSourceColumn(c);packed=h.pack(s);original=SourceWetColumn.evaluate
 def altered(self,states):
  out=original(self,states);cell=out.cells[0]
  return replace(out,cells=(replace(cell,chemistry=replace(cell.chemistry,**changes)),))
 monkeypatch.setattr(SourceWetColumn,'evaluate',altered)
 with pytest.raises(ValueError):h.evaluate(packed,T(F()))

def test_different_dry_mass_identity_cannot_reinterpret_U(monkeypatch):
 c,s=setup(monkeypatch,count=1);h=ExactSourceColumn(c);packed=h.pack(s)
 changed=ExactSourceColumn(replace(c,storages=(replace(c.storages[0],dry_mass_kg=.25),)))
 assert changed.energy_model_identity!=h.energy_model_identity
 with pytest.raises(ValueError,match='energy_binding'):changed.unpack(packed)

def test_actual_N3_derivative_shared_face_and_phase(monkeypatch):
 c,s=setup(monkeypatch);h=ExactSourceColumn(c);state=h.pack(s);out=h.evaluate(state,T(F()))
 dn,du=out.rates.derivatives(state)
 for i,cell in enumerate(out.source_evaluation.cells):
  left,right=out.source_evaluation.faces[i:i+2]
  expected=np.array([getattr(left,'liquid_mol_s',0.)-getattr(right,'liquid_mol_s',0.)-cell.phase.phase_water_mol_s,*[left.gas_mol_s[k]-right.gas_mol_s[k]+(cell.phase.phase_water_mol_s if k==2 else 0) for k in range(3)]])
  assert np.allclose(dn[i],expected,rtol=1e-15,atol=0)
  assert du[i]==left.energy_w-right.energy_w
