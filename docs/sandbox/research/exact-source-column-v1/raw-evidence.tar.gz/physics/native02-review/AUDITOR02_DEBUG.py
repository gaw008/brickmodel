"""Offline exact-source adapter audit; no numpy/model/EOS imports."""
from pathlib import Path
from fractions import Fraction as F
import math,json,hashlib
BASE=Path('/private/tmp/brick-source-column-event-v1/native02');OUT=Path('/private/tmp/brick-source-column-event-v1/physics/native02-review')
def unpack(v):
 if isinstance(v,list):return [unpack(x) for x in v]
 if isinstance(v,dict):
  if set(v)=={'numerator','denominator'}:return F(v['numerator'],v['denominator'])
  if 'type' in v and 'fields' in v:return unpack(v['fields'])
  if 'dtype' in v and 'shape' in v and 'values' in v:return unpack(v['values'])
  return {k:unpack(x) for k,x in v.items()}
 return v
checks={}
def check(name,ok):checks[name]=bool(ok);assert ok,name
def add(*vs):return float(sum(map(F,vs),F()))
def mapvec(fn,*rows):return [mapvec(fn,*(row[i] for row in rows)) for i in range(len(rows[0]))] if isinstance(rows[0],list) else fn(*rows)
def flatten(v):return [x for row in v for x in flatten(row)] if isinstance(v,list) else [v]
raw=(BASE/'runtime.json').read_bytes();d=unpack(json.loads(raw));r=d['integrator_result'];caps=d['captures'];p=d['policy'];prov=d['adapter_provenance']
check('four_fluids',prov['species_ids']==['liquid_water','O2','N2','H2O'])
check('original_scientific_parameters',[p[k] for k in ('initial_step_s','maximum_step_s','minimum_step_s','relative_tolerance','amount_absolute_tolerance_mol','energy_absolute_tolerance_j','amount_scale_mol','energy_scale_j','maximum_steps','maximum_rejections')]==[1/1024,1/1024,1/16384,1e-8,1e-7,1e-3,1.,1e5,4,4])
check('resource_only',p['maximum_wall_seconds']==450. and d['outer_seconds']==510.)
check('same_interval',d['duration_s']==F(1,1024))
check('ordinals',[c['ordinal'] for c in caps]==list(range(len(caps))))
check('prefix_layout',len(r['states'])==len(r['times_s'])==len(r['steps'])+1)
for j,c in enumerate(caps):
 e=c['evaluation'];state=c['packed_input'];src=e['source_evaluation'];rates=e['rates'];ss=e['source_states']
 check(f'{j}_time',e['time']==c['time'])
 check(f'{j}_state_shapes',len(state['amounts_mol'])==3 and all(len(row)==4 for row in state['amounts_mol']) and state['mechanical_stretches'] is None)
 check(f'{j}_energy_binding',state['energy_model_identity']==prov['energy_model_identity'])
 for i in range(3):
  check(f'{j}_{i}_pack',[ss[i]['liquid_water_mol'],*ss[i]['gas_amounts_mol']]==state['amounts_mol'][i] and ss[i]['internal_energy_j']==state['internal_energy_j'][i] and ss[i]['solid_mass_kg']==[prov['fixed_dry_mass_kg'][i]])
  phase=src['cells'][i]['phase']['phase_water_mol_s'];check(f'{j}_{i}_phase',rates['reaction_species_mol_s'][i]==[-phase,0.,0.,phase]);check(f'{j}_{i}_no_extra_power',rates['cell_power_w'][i]==0)
 for f,face in enumerate(src['faces']):
  check(f'{j}_{f}_face_map',rates['face_species_mol_s'][f]==[face.get('liquid_mol_s',0.),*face['gas_mol_s']] and rates['face_energy_w'][f]==face['energy_w'])
  check(f'{j}_{f}_liquid_energy_retained',face['energy_w']==math.fsum([face['conduction_w'],*face['diffusive_enthalpy_w'],*face['advective_enthalpy_w'],face.get('liquid_enthalpy_w',0.)]))
 check(f'{j}_closed_liquid',rates['face_species_mol_s'][0][0]==rates['face_species_mol_s'][-1][0]==0)
def divergence(rate):
 n=[[math.fsum((rate['face_species_mol_s'][i][k],-rate['face_species_mol_s'][i+1][k],rate['reaction_species_mol_s'][i][k])) for k in range(4)] for i in range(3)]
 u=[math.fsum((rate['face_energy_w'][i],-rate['face_energy_w'][i+1],rate['cell_power_w'][i])) for i in range(3)]
 return n,u
def update(state,dn,du):
 return {**state,'amounts_mol':mapvec(lambda a,b:math.fsum((a,b)),state['amounts_mol'],dn),'internal_energy_j':mapvec(lambda a,b:math.fsum((a,b)),state['internal_energy_j'],du)}
def euler(state,rate,h):
 dn,du=divergence(rate);return update(state,mapvec(lambda v:float(h*F(v)),dn),mapvec(lambda v:float(h*F(v)),du))
def heun(state,a,b,h):
 fields={k:mapvec(lambda x,y:math.fsum((float(h/2*F(x)),float(h/2*F(y)))),a[k],b[k]) for k in ('face_species_mol_s','face_energy_w','reaction_species_mol_s','cell_power_w')}
 dn,du=divergence(fields);return update(state,dn,du)
def rates(i):return caps[i]['evaluation']['rates']
def rates(i):return caps[i]['evaluation']['rates']
def normerror(coarse,fine):
 ns=p['amount_absolute_tolerance_mol']+p['relative_tolerance']*p['amount_scale_mol'];us=p['energy_absolute_tolerance_j']+p['relative_tolerance']*p['energy_scale_j']
 rows=[]
 for i in range(3):
  for k in range(4):rows.append((abs(fine['amounts_mol'][i][k]-coarse['amounts_mol'][i][k])/ns,i,prov['species_ids'][k],fine['amounts_mol'][i][k]-coarse['amounts_mol'][i][k]))
  rows.append((abs(fine['internal_energy_j'][i]-coarse['internal_energy_j'][i])/us,i,'U',fine['internal_energy_j'][i]-coarse['internal_energy_j'][i]))
 peak=max(rows);return peak[0]*F(1,3),{'cell':peak[1],'quantity':peak[2],'difference':peak[3]}
def control(value):
 f=float(value)
 if F(f)>value:f=math.nextafter(f,-math.inf)
 return F(f)
trials=[];balances=[];index=1;accepted=0;rejected=0;current=d['initial'];start=F();expected_h=F(p['initial_step_s'])
cn=[[F()]*4 for _ in range(3)];cu=[F()]*3
check('initial_validation',caps[0]['packed_input']==current and caps[0]['time']['seconds']==start)
while index<len(caps):
 rec={'capture_start':index,'available':len(caps)-index};trials.append(rec)
 if len(caps)-index<6:rec['status']='partial_trial_insufficient_stages';break
 times=[c['time']['seconds'] for c in caps[index:index+6]];end=times[1];h=end-start
 # The original integrator also clips a tiny subminimum tail by bisecting remaining interval.
 target=F(1,1024);expected_end=min(start+expected_h,target)
 if 0<target-expected_end<F(p['minimum_step_s']) and F(p['minimum_step_s'])<=(target-start)/2<=expected_h:expected_end=start+(target-start)/2
 
 if end!=expected_end:print('DEBUG',index,str(end),str(expected_end),str(expected_h),json.dumps(trials,default=str),flush=True)
 check(f'trial{index}_controlled_endpoint',end==expected_end)
 check(f'trial{index}_semantic_times',times==[start,end,start,start+h/2,start+h/2,end])
 check(f'trial{index}_starts',caps[index]['packed_input']==caps[index+2]['packed_input']==current)
 check(f'trial{index}_coarse_predictor',euler(current,rates(index),h)==caps[index+1]['packed_input'])
 coarse=heun(current,rates(index),rates(index+1),h);half=heun(current,rates(index+2),rates(index+3),h/2)
 check(f'trial{index}_half_predictor',euler(current,rates(index+2),h/2)==caps[index+3]['packed_input'])
 check(f'trial{index}_half_initial',half==caps[index+4]['packed_input'])
 check(f'trial{index}_second_predictor',euler(half,rates(index+4),h/2)==caps[index+5]['packed_input'])
 fine=heun(half,rates(index+4),rates(index+5),h/2);err,peak=normerror(coarse,fine)
 rec.update(start=str(start),end=str(end),h=str(h),normalized_error=err,controlling=peak)
 if err>1:
  rejected+=1;rec['status']='rejected_error';expected_h=control(h*F(max(.2,.9*err**(-1/3))));rec['next_h']=str(expected_h);index+=6;continue
 if index+6>=len(caps):rec['status']='partial_before_accepted_endpoint';break
 check(f'trial{index}_endpoint_validation',caps[index+6]['packed_input']==fine and caps[index+6]['time']['seconds']==end)
 if accepted>=len(r['steps']):rec['status']='endpoint_validated_without_commit';break
 l=r['steps'][accepted];check(f'ledger{accepted}_times',l['start_s']['seconds']==start and l['end_s']['seconds']==end)
 check(f'ledger{accepted}_state',r['states'][accepted]==current and r['states'][accepted+1]==fine)
 for saved,field in [('face_species_mol','face_species_mol_s'),('face_energy_j','face_energy_w'),('reaction_species_mol','reaction_species_mol_s'),('cell_work_j','cell_power_w')]:
  v=[rates(i)[field] for i in (index+2,index+3,index+4,index+5)]
  calc=mapvec(lambda a,b,c,d:math.fsum((math.fsum((float(h/4*F(a)),float(h/4*F(b)))),math.fsum((float(h/4*F(c)),float(h/4*F(d)))))),*v)
  check(f'ledger{accepted}_{saved}_two_level_rounding',calc==l[saved])
 rn=[];ru=[]
 for i in range(3):
  row=[]
  for k in range(4):
   term=F(l['face_species_mol'][i][k])-F(l['face_species_mol'][i+1][k])+F(l['reaction_species_mol'][i][k]);delta=F(fine['amounts_mol'][i][k])-F(current['amounts_mol'][i][k]);res=delta-term;row.append(res);cn[i][k]+=term
   check(f'ledger{accepted}_{i}_{k}_local',abs(res)<=F(p['amount_absolute_tolerance_mol']))
   check(f'ledger{accepted}_{i}_{k}_cumulative',abs(F(fine['amounts_mol'][i][k])-F(d['initial']['amounts_mol'][i][k])-cn[i][k])<=F(p['amount_absolute_tolerance_mol']))
  rn.append(row);term=F(l['face_energy_j'][i])-F(l['face_energy_j'][i+1])+F(l['cell_work_j'][i]);res=F(fine['internal_energy_j'][i])-F(current['internal_energy_j'][i])-term;ru.append(res);cu[i]+=term
  check(f'ledger{accepted}_{i}_U_local',abs(res)<=F(p['energy_absolute_tolerance_j']))
  check(f'ledger{accepted}_{i}_U_cumulative',abs(F(fine['internal_energy_j'][i])-F(d['initial']['internal_energy_j'][i])-cu[i])<=F(p['energy_absolute_tolerance_j']))
  check(f'ledger{accepted}_{i}_phase_cancels',F(l['reaction_species_mol'][i][0])+F(l['reaction_species_mol'][i][3])==0)
 water=lambda s:sum(F(row[0])+F(row[3]) for row in s['amounts_mol'])
 wb=sum(F(l['face_species_mol'][0][k])-F(l['face_species_mol'][-1][k]) for k in (0,3));wr=water(fine)-water(current)-wb
 ur=sum(F(b)-F(a) for a,b in zip(current['internal_energy_j'],fine['internal_energy_j']))-F(l['face_energy_j'][0])+F(l['face_energy_j'][-1])-sum(map(F,l['cell_work_j']))
 check(f'ledger{accepted}_global_water',wr==sum(row[0]+row[3] for row in rn));check(f'ledger{accepted}_global_U',ur==sum(ru))
 balances.append({'step':accepted,'water_change':str(water(fine)-water(current)),'water_external':str(wb),'water_actual_residual':str(wr),'U_actual_residual':str(ur),'local_amount_residuals':[[str(x) for x in row] for row in rn],'local_U_residuals':[str(x) for x in ru]})
 rec['status']='accepted';accepted+=1;index+=7;current=fine;start=end
 expected_h=max(F(p['minimum_step_s']),control(min(F(p['maximum_step_s']),h*F(2 if err==0 else min(2,max(.2,.9*err**(-1/3)))))))
check('all_accepted_ledgers_reconstructed',accepted==len(r['steps']))
check('first_rejection_actual',trials[0]['status']=='rejected_error')
check('counts',rejected<=r['rejected_trials'] and len(trials)==r['attempted_trials'])
if r['status']=='completed':check('completed_endpoint',start==F(1,1024) and index==len(caps) and rejected==r['rejected_trials'])
result={'input_sha256':hashlib.sha256(raw).hexdigest(),'outer_status':d['status'],'inner_status':r['status'],'reason':r['reason'],'checks_passed':len(checks),'checks':checks,'trials':trials,'accepted_ledgers':balances,'callback_count':len(caps),'reported_elapsed_seconds':r['elapsed_seconds'],'scope':'Offline actual saved stages only; no EOS. Same-time stages retained, coarse trials excluded from accepted ledger. Partial outcomes remain partial.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
