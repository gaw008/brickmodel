"""Offline exact-source adapter audit; no numpy/model/EOS imports."""
from pathlib import Path
from fractions import Fraction as F
import math,json,hashlib
BASE=Path('/private/tmp/brick-source-column-event-v1/native');OUT=Path('/private/tmp/brick-source-column-event-v1/physics/native-review')
def unpack(v):
 if isinstance(v,list):return [unpack(x) for x in v]
 if isinstance(v,dict):
  if set(v)=={'numerator','denominator'}:return F(v['numerator'],v['denominator'])
  if 'type' in v and 'fields' in v:return unpack(v['fields'])
  if 'dtype' in v and 'shape' in v and 'values' in v:return unpack(v['values'])
  return {k:unpack(x) for k,x in v.items()}
 return v
checks={}
def check(name,ok):checks[name]=bool(ok);assert ok,name
def add(*vs):return float(sum(map(F,vs),F()))
def mapvec(fn,*rows):return [mapvec(fn,*(row[i] for row in rows)) for i in range(len(rows[0]))] if isinstance(rows[0],list) else fn(*rows)
def flatten(v):return [x for row in v for x in flatten(row)] if isinstance(v,list) else [v]
raw=(BASE/'runtime.json').read_bytes();d=unpack(json.loads(raw));r=d['integrator_result'];caps=d['captures'];p=d['policy'];prov=d['adapter_provenance']
check('actual_hash',hashlib.sha256(raw).hexdigest()=='c9485fc029de2593183f2db5ecaeca1faba3d7c4561691ede9398521c5b85a48')
check('outer_failure',d['status']=='failed' and d['exception']=='complete_original_segment_required')
check('inner_resource_limit',r['status']=='resource_limit' and r['reason']=='wall_time_limit')
check('no_accepted_ledger',r['steps']==[] and r['states']==[d['initial']] and len(r['times_s'])==1)
check('actual_counters',len(caps)==r['evaluations']==12 and r['attempted_trials']==2 and r['rejected_trials']==1)
check('ordinals_preserved',[c['ordinal'] for c in caps]==list(range(12)))
check('four_fluids',prov['species_ids']==['liquid_water','O2','N2','H2O'])
for j,c in enumerate(caps):
 e=c['evaluation'];state=c['packed_input'];src=e['source_evaluation'];rates=e['rates'];ss=e['source_states']
 check(f'{j}_time',e['time']==c['time'])
 check(f'{j}_state_shapes',len(state['amounts_mol'])==3 and all(len(row)==4 for row in state['amounts_mol']) and state['mechanical_stretches'] is None)
 check(f'{j}_energy_binding',state['energy_model_identity']==prov['energy_model_identity'])
 for i in range(3):
  check(f'{j}_{i}_pack',[ss[i]['liquid_water_mol'],*ss[i]['gas_amounts_mol']]==state['amounts_mol'][i] and ss[i]['internal_energy_j']==state['internal_energy_j'][i] and ss[i]['solid_mass_kg']==[prov['fixed_dry_mass_kg'][i]])
  phase=src['cells'][i]['phase']['phase_water_mol_s'];check(f'{j}_{i}_phase',rates['reaction_species_mol_s'][i]==[-phase,0.,0.,phase]);check(f'{j}_{i}_no_extra_power',rates['cell_power_w'][i]==0)
 for f,face in enumerate(src['faces']):
  check(f'{j}_{f}_face_map',rates['face_species_mol_s'][f]==[face.get('liquid_mol_s',0.),*face['gas_mol_s']] and rates['face_energy_w'][f]==face['energy_w'])
  check(f'{j}_{f}_liquid_energy_retained',face['energy_w']==math.fsum([face['conduction_w'],*face['diffusive_enthalpy_w'],*face['advective_enthalpy_w'],face.get('liquid_enthalpy_w',0.)]))
 check(f'{j}_closed_liquid',rates['face_species_mol_s'][0][0]==rates['face_species_mol_s'][-1][0]==0)
def divergence(rate):
 n=[[math.fsum((rate['face_species_mol_s'][i][k],-rate['face_species_mol_s'][i+1][k],rate['reaction_species_mol_s'][i][k])) for k in range(4)] for i in range(3)]
 u=[math.fsum((rate['face_energy_w'][i],-rate['face_energy_w'][i+1],rate['cell_power_w'][i])) for i in range(3)]
 return n,u
def update(state,dn,du):
 return {**state,'amounts_mol':mapvec(lambda a,b:math.fsum((a,b)),state['amounts_mol'],dn),'internal_energy_j':mapvec(lambda a,b:math.fsum((a,b)),state['internal_energy_j'],du)}
def euler(state,rate,h):
 dn,du=divergence(rate);return update(state,mapvec(lambda v:float(h*F(v)),dn),mapvec(lambda v:float(h*F(v)),du))
def heun(state,a,b,h):
 fields={k:mapvec(lambda x,y:math.fsum((float(h/2*F(x)),float(h/2*F(y)))),a[k],b[k]) for k in ('face_species_mol_s','face_energy_w','reaction_species_mol_s','cell_power_w')}
 dn,du=divergence(fields);return update(state,dn,du)
def rates(i):return caps[i]['evaluation']['rates']
initial=d['initial'];h=F(1,1024)
coarse=heun(initial,rates(1),rates(2),h)
half=heun(initial,rates(3),rates(4),h/2)
fine=heun(half,rates(5),rates(6),h/2)
check('coarse_start',caps[1]['packed_input']==initial)
check('coarse_euler',euler(initial,rates(1),h)==caps[2]['packed_input'])
check('first_half_start',caps[3]['packed_input']==initial)
check('first_half_euler',euler(initial,rates(3),h/2)==caps[4]['packed_input'])
check('second_half_start',half==caps[5]['packed_input'])
check('second_half_euler',euler(half,rates(5),h/2)==caps[6]['packed_input'])
nscale=p['amount_absolute_tolerance_mol']+p['relative_tolerance']*p['amount_scale_mol'];uscale=p['energy_absolute_tolerance_j']+p['relative_tolerance']*p['energy_scale_j']
errors=[]
for i in range(3):
 for k in range(4):errors.append({'cell':i,'quantity':prov['species_ids'][k],'fine_minus_coarse':fine['amounts_mol'][i][k]-coarse['amounts_mol'][i][k],'scale':nscale,'normalized_error':abs(fine['amounts_mol'][i][k]-coarse['amounts_mol'][i][k])/nscale/3})
 errors.append({'cell':i,'quantity':'U','fine_minus_coarse':fine['internal_energy_j'][i]-coarse['internal_energy_j'][i],'scale':uscale,'normalized_error':abs(fine['internal_energy_j'][i]-coarse['internal_energy_j'][i])/uscale/3})
# Match integrator operation order: maximum scaled difference, then Fraction1/3.
err=max(abs(v['fine_minus_coarse'])/v['scale'] for v in errors)*F(1,3)
check('initial_trial_rejected',err>1)
desired=h*F(max(.2,.9*err**(-1/3)));binary=float(desired)
if F(binary)>desired:binary=math.nextafter(binary,-math.inf)
next_h=F(binary)
check('selected_next_h',next_h==F(523754638258309,1152921504606846976))
check('second_trial_actual_times',[c['time']['seconds'] for c in caps[7:]]==[F(),next_h,F(),next_h/2,next_h/2])
check('second_trial_restart',caps[7]['packed_input']==caps[9]['packed_input']==initial)
check('second_full_euler',euler(initial,rates(7),next_h)==caps[8]['packed_input'])
check('second_half_euler',euler(initial,rates(9),next_h/2)==caps[10]['packed_input'])
check('second_half_partial_state',heun(initial,rates(9),rates(10),next_h/2)==caps[11]['packed_input'])
check('unchanged_final_unpack',all([s['liquid_water_mol'],*s['gas_amounts_mol']]==row and s['internal_energy_j']==u for s,row,u in zip(d['final_unpacked_states'],initial['amounts_mol'],initial['internal_energy_j'])))
result={'input_sha256':hashlib.sha256(raw).hexdigest(),'checks_passed':len(checks),'checks':checks,'controlling_error':max(errors,key=lambda v:v['normalized_error']),'all_local_errors':errors,'integrator_error':err,'next_h_exact':str(next_h),'next_h_float':float(next_h),'coarse_trial_state':coarse,'fine_trial_state':fine,'reported_elapsed_seconds':r['elapsed_seconds'],'accepted_steps':0,'actual_capture_times':[str(c['time']['seconds']) for c in caps],'remaining_second_trial_callbacks_minimum':2,'scope':'Offline failed-trial reconstruction, no EOS. Reconstructed fine state is rejected, not accepted. No temporal success or zero trajectory error inferred.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};(OUT/'FAILURE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
