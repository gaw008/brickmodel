"""Offline exact-source adapter audit; no numpy/model/EOS imports."""
from pathlib import Path
from fractions import Fraction as F
import math,json,hashlib
BASE=Path('/private/tmp/brick-source-column-event-v1/native');OUT=Path('/private/tmp/brick-source-column-event-v1/physics/native-review')
def unpack(v):
 if isinstance(v,list):return [unpack(x) for x in v]
 if isinstance(v,dict):
  if set(v)=={'numerator','denominator'}:return F(v['numerator'],v['denominator'])
  if 'type' in v and 'fields' in v:return unpack(v['fields'])
  if 'dtype' in v and 'shape' in v and 'values' in v:return unpack(v['values'])
  return {k:unpack(x) for k,x in v.items()}
 return v
checks={}
def check(name,ok):checks[name]=bool(ok);assert ok,name
def add(*vs):return float(sum(map(F,vs),F()))
def mapvec(fn,*rows):return [mapvec(fn,*(row[i] for row in rows)) for i in range(len(rows[0]))] if isinstance(rows[0],list) else fn(*rows)
def flatten(v):return [x for row in v for x in flatten(row)] if isinstance(v,list) else [v]
raw=(BASE/'runtime.json').read_bytes();d=unpack(json.loads(raw));check('completed',d['status']=='completed')
r=d['integrator_result'];caps=d['captures'];p=d['policy'];prov=d['adapter_provenance'];check('actual_eight',len(caps)==r['evaluations']==8)
check('accepted_prefix',len(r['states'])==2 and len(r['steps'])==1 and r['rejected_trials']==0)
check('fluid_layout',prov['species_ids']==['liquid_water','O2','N2','H2O'])
check('qualified_false',d['material_qualified'] is False and prov['material_qualified'] is False)
old,new=r['states'];l=r['steps'][0];dt=l['end_s']['seconds']-l['start_s']['seconds'];check('duration',dt==F(1,1024))
check('ordinal_sequence',[c['ordinal'] for c in caps]==list(range(8)))
check('stage_times',[c['time']['seconds'] for c in caps]==[F(),F(),dt,F(),dt/2,dt/2,dt,dt])
for j,c in enumerate(caps):
 e=c['evaluation'];state=c['packed_input'];src=e['source_evaluation'];rates=e['rates'];ss=e['source_states']
 check(f'{j}_time',e['time']==c['time'])
 check(f'{j}_state_shapes',len(state['amounts_mol'])==3 and all(len(row)==4 for row in state['amounts_mol']) and state['mechanical_stretches'] is None)
 check(f'{j}_energy_binding',state['energy_model_identity']==prov['energy_model_identity'])
 for i in range(3):
  check(f'{j}_{i}_pack',[ss[i]['liquid_water_mol'],*ss[i]['gas_amounts_mol']]==state['amounts_mol'][i] and ss[i]['internal_energy_j']==state['internal_energy_j'][i] and ss[i]['solid_mass_kg']==[prov['fixed_dry_mass_kg'][i]])
  phase=src['cells'][i]['phase']['phase_water_mol_s'];check(f'{j}_{i}_phase',rates['reaction_species_mol_s'][i]==[-phase,0.,0.,phase]);check(f'{j}_{i}_no_extra_power',rates['cell_power_w'][i]==0)
 for f,face in enumerate(src['faces']):
  check(f'{j}_{f}_face_map',rates['face_species_mol_s'][f]==[face.get('liquid_mol_s',0.),*face['gas_mol_s']] and rates['face_energy_w'][f]==face['energy_w'])
  check(f'{j}_{f}_liquid_energy_retained',face['energy_w']==math.fsum([face['conduction_w'],*face['diffusive_enthalpy_w'],*face['advective_enthalpy_w'],face.get('liquid_enthalpy_w',0.)]))
 check(f'{j}_closed_liquid',rates['face_species_mol_s'][0][0]==rates['face_species_mol_s'][-1][0]==0)
# Actual accepted fine quadrature: captures3,4 make first half;5,6 second half.
# Each product is rounded, then the half sum, then the total of halves.
quadrature_errors={}
for saved,ratefield in [('face_species_mol','face_species_mol_s'),('face_energy_j','face_energy_w'),('reaction_species_mol','reaction_species_mol_s'),('cell_work_j','cell_power_w')]:
 stage=[caps[i]['evaluation']['rates'][ratefield] for i in (3,4,5,6)]
 calc=mapvec(lambda a,b,c,d:add(add(float(dt/4*F(a)),float(dt/4*F(b))),add(float(dt/4*F(c)),float(dt/4*F(d)))),*stage)
 check(saved+'_accepted_four_stage_rounding',calc==l[saved])
 exact=mapvec(lambda a,b,c,d:dt/4*(F(a)+F(b)+F(c)+F(d)),*stage)
 errors=[F(a)-b for a,b in zip(flatten(calc),flatten(exact))];quadrature_errors[saved]={'maximum_abs':str(max(map(abs,errors))),'signed_errors':[str(x) for x in errors]}
check('accepted_endpoint_capture',caps[7]['packed_input']==new)
check('final_unpack',all([s['liquid_water_mol'],*s['gas_amounts_mol']]==row and s['internal_energy_j']==u and s['solid_mass_kg']==[m] for s,row,u,m in zip(d['final_unpacked_states'],new['amounts_mol'],new['internal_energy_j'],prov['fixed_dry_mass_kg'])))
resn=[];resu=[]
for i in range(3):
 row=[]
 for k in range(4):
  delta=F(new['amounts_mol'][i][k])-F(old['amounts_mol'][i][k]);term=F(l['face_species_mol'][i][k])-F(l['face_species_mol'][i+1][k])+F(l['reaction_species_mol'][i][k]);err=delta-term;check(f'local_{i}_{k}_amount_policy',abs(err)<=F(p['amount_absolute_tolerance_mol']));row.append(err)
 resn.append(row)
 err=F(new['internal_energy_j'][i])-F(old['internal_energy_j'][i])-F(l['face_energy_j'][i])+F(l['face_energy_j'][i+1])-F(l['cell_work_j'][i]);check(f'local_{i}_U_policy',abs(err)<=F(p['energy_absolute_tolerance_j']));resu.append(err)
 check(f'phase_integral_{i}',F(l['reaction_species_mol'][i][0])+F(l['reaction_species_mol'][i][3])==0)
balances={}
for name,cols in [('liquid',[0]),('O2',[1]),('N2',[2]),('water',[0,3])]:
 change=sum(F(new['amounts_mol'][i][k])-F(old['amounts_mol'][i][k]) for i in range(3) for k in cols)
 flux=sum(F(l['face_species_mol'][0][k])-F(l['face_species_mol'][-1][k]) for k in cols);source=sum(F(l['reaction_species_mol'][i][k]) for i in range(3) for k in cols);err=sum(resn[i][k] for i in range(3) for k in cols)
 check('global_'+name,change-flux-source==err);balances[name]={'change':str(change),'change_float':float(change),'boundary':str(flux),'local_source':str(source),'roundoff':str(err),'roundoff_float':float(err)}
change=sum(F(b)-F(a) for a,b in zip(old['internal_energy_j'],new['internal_energy_j']));external=F(l['face_energy_j'][0])-F(l['face_energy_j'][-1])+sum(map(F,l['cell_work_j']));check('global_U',change-external==sum(resu));balances['U']={'change':str(change),'change_float':float(change),'external':str(external),'roundoff':str(sum(resu)),'roundoff_float':float(sum(resu))}
result={'input_sha256':hashlib.sha256(raw).hexdigest(),'checks_passed':len(checks),'checks':checks,'balances':balances,'local_amount_residuals':[[str(x) for x in row] for row in resn],'local_U_residuals':[str(x) for x in resu],'quadrature_rounding':quadrature_errors,'reported_elapsed_seconds':r['elapsed_seconds'],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Offline saved adapter/stage/ledger audit only, no EOS or trajectory; four fine stages3..6, not coarse stages1..2, form accepted quadrature.'};(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
