"""Construct one fresh actual native host evaluation; no saved success consumed.

The source water is real. Solids, kinetics, face and declared error envelopes
remain the original manufactured research case. This is not a trajectory.
"""
from pathlib import Path
from dataclasses import replace
import importlib.util,json,time
OLD=Path('/private/tmp/brick-mass-wet-transport-native-v1')
_spec=importlib.util.spec_from_file_location('reviewed_native_mass_builder',OLD/'run.py')
_builder=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_builder)


def build_and_query(output:Path,guard):
    """Return live pair/states/rates for an immediate bound certificate request.

    Caller freezes current runtime, this helper, old builder and all inputs
    before entry and checks them afterward. No old runtime admission is used.
    Caller owns cumulative wall/external watchdog and consumer math budget.
    """
    from sludge_sandbox.mass_wet_transport import WetPair,WetFace
    from sludge_sandbox.phase_storage import InversePolicy
    from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
    output.mkdir(exist_ok=False)
    case=json.loads((OLD/'inputs/case.json').read_bytes())
    case['initial_temperatures_k']=[300.125,305.25]
    case['case_role']='new virtual temperature choice within original295..310K domain; actual current native water, manufactured remaining parameters'
    case['operation']='one current WetPair.evaluate; no trajectory and no saved result as admission'
    _builder.save(output/'case.json',case)
    costs={'initial_forward_attempted':0,'initial_forward_completed':0,'host_attempted':0,'host_completed':0,'native_internal_call_count':None}
    started=time.monotonic()
    def checkpoint(status,reason=None):
        _builder.save(output/'operation-status.json',dict(status=status,reason=reason,costs=costs,elapsed_seconds=time.monotonic()-started))
    checkpoint('started')
    try:
        guard();st=_builder.build_storage(output);guard()
        _builder.save(output/'storage-inputs.json',_builder.capture(st))
        water=OLD/'inputs/water'
        chemical=WaterChemicalPotential(water,backend='heos',backend_manifest=water/'heos-8.0.0-approved-manifest.json')
        face={k:tuple(v) if isinstance(v,list) else v for k,v in case['face'].items()}
        pair=WetPair((st,st),(InversePolicy(**case['inverse_policy']),)*2,chemical,tuple(case['rate_constants_per_s']),tuple(case['oxygen_references_mol']),tuple(case['transfer_coefficients_mol_s_pa']),tuple(case['coefficient_source_ids']),WetFace(**face))
        identity=pair.binding();_builder.save(output/'pair-inputs.json',_builder.capture(pair))
        initial=[]
        for i,(values,t) in enumerate(zip(case['initial_cells'],case['initial_temperatures_k'],strict=True)):
            state=st.state(tuple(values['solid_mass_kg']),values['liquid_water_mol'],tuple(values['gas_amounts_mol']),0.)
            _builder.save(output/f'initial-prototype-{i}.json',_builder.capture(state))
            guard();costs['initial_forward_attempted']+=1;checkpoint('initial_forward')
            point=st.evaluate(state,t);costs['initial_forward_completed']+=1
            _builder.save(output/f'initial-forward-{i}.json',_builder.capture(point));guard()
            initial.append(replace(state,internal_energy_j=point.total_internal_energy_j))
        initial=tuple(initial);_builder.save(output/'initial.json',_builder.capture(initial))
        guard();costs['host_attempted']+=1;checkpoint('host_evaluation')
        rates=pair.evaluate(initial);costs['host_completed']+=1
        _builder.save(output/'rates.json',_builder.capture(rates))
        guard();assert pair.binding()==identity
        checkpoint('completed_current_query')
        return pair,initial,rates
    except Exception as exc:
        checkpoint('failed',type(exc).__name__+': '+str(exc));raise
