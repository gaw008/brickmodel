# Fresh actual host-query helper review

Decision: APPROVE preparation helper `bee6cefe5f310ea92a1756b44018d824e63db5018cc97a744a8be02f7b473fee` for use by the future frozen/budgeted caller. This is not approval of an absent runner, installed-runtime snapshot or completed native result. No HIGH/CRITICAL issue found. Reviewer executed no EOS and changed no repository/helper source.

Actual read-only checks: AST parses; all 23 HELPER_FREEZE file hashes match; every original input file outside the deliberately excluded old implementation snapshot is covered (no missing nonimplementation asset). Both new design temperatures 300.125 and 305.25 K lie in the unchanged original 295..310 K domain. Details are saved in `review_preflight01.json`.

## Construction and data association

The old module performs no EOS on import. Only its `build_storage`, `capture`, and atomic JSON `save` helpers are used. Old `verify`, historical runtime identity, old trajectory integration and saved successes are not used as admission. `build_storage` reads only the original frozen case, gas facts and water/element assets, then imports the current package. Its water, vapor, reference anchors and manufactured thermochemical model are constructed afresh.

The two temperature changes are explicit virtual design inputs. All solids, original inventories, artificial reaction, face transport coefficients, inverse/pressure policies and numerical envelopes retain the existing fixture values. Forward evaluation initializes each state's **total U** from its own proposed temperature. Exactly one `pair.evaluate(initial)` then returns fresh actual rates and live objects. The return tuple can immediately supply provider capture in the same process; no encoded historical result replaces the live rate. Pair identity is saved and checked after the host call, with caller guards on either side of native work. The consumer must still perform its request/rate/inverse/reference binding checks.

Storage creation performs provider construction and reference-anchor evaluation before the two explicitly counted forward evaluations. Therefore the reported two-forward/one-host counters are correctly specific categories, not a total primitive EOS count. `native_internal_call_count=None` is essential and must remain unknown; do not later report zero or three native calls. The caller must budget **all** construction and query work from before helper entry, not start its timer at the first host call.

## Inputs and caller obligations

The helper's 23-item freeze covers builder and concrete nonruntime inputs. The old builder has other globals pointing to original archives/repository assets, but those are used in its excluded prepare/verify/experiment functions, not this construction path. Gas facts carry source metadata; no extra gas cache file is dereferenced in build_storage.

The future caller must pin the **then-current installed** sludge package and relevant dependency/native files/configuration plus the approved backend manifest, source JSON/assets, this helper, builder and inputs. A HELPER_FREEZE alone does not prove current runtime identity. Imported current water/kernel code already validates the approved CoolProp manifest; the caller still needs recorded before/after runtime bindings and a real external watchdog. The proposed 30/40 s budgets do not exist in this helper and cannot be claimed until that runner is reviewed and executed.

## Failure and checkpoint scope

Fresh output directory is exclusive-create. Prototype state is saved before each forward attempt; attempted cost is checkpointed before entering its callback; actual point is saved after return; initial states are saved before host entry; actual rates are saved before the final guard. Ordinary callback/guard failures record a failed operation with current actual costs and re-raise, leaving caller responsible for terminal process status. All returned live objects are in memory; no integration state is committed.

Atomic status snapshots may lag a just-returned callback during an external kill, as expected for partial evidence. The preserved point/rate files can then establish additional completed work, but incomplete operation status must never be relabeled successful. Setup failures before the initial status file (case parse/output errors) and hard process termination need the outer runner's independent terminal record; helper-only exception handling does not provide that guarantee.

[LOW] `build_storage` also writes `attempted-point.json` using the original case, including old initial temperatures and trajectory fields that it does not use for storage construction. The authoritative fresh query is `case.json`; archive/report should label attempted-point as **original builder storage-parameter snapshot**, not the selected fresh initial state. Its unchanged reference-temperature/physics use is correct; no physical parameter needs modification.

No material qualification, native-wide numerical accuracy, trajectory convergence or consumer pressure admission follows from helper construction alone. Those remain explicit downstream query/evidence checks under the original conditional envelopes.
