from pathlib import Path
import sys,importlib.util,unittest,json
from types import SimpleNamespace as S
from decimal import Decimal as D
from fractions import Fraction as F
BASE=Path('/private/tmp/brick-water-pressure-interval-v1')
import sludge_sandbox
sludge_sandbox.__path__.insert(0,str(BASE/'packaged_primitives/src/sludge_sandbox'))
sludge_sandbox.__path__.insert(0,str(BASE/'consumer_candidate'))
spec=importlib.util.spec_from_file_location('review_propose',BASE/'fresh_query/propose_boxes.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from sludge_sandbox.mass_wet_pressure_interval import data,ProofBudget,LiquidPressureEvidence
from sludge_sandbox.water_interval_eos import I
class Tests(unittest.TestCase):
 def setup_proposal(self):
  m.parameters=lambda *a:S(observed_query=(300.125,1e6,1000.,.018,.018,.02,3.6e-7,1e-16),liquid_mol=D('.02'),public_native_scale=I(1))
  m.evaluate_box=lambda *a,**kw:S(jacobian=((I(1),I(0)),(I(0),I(1))),residual=(I(0),I(0)))
  return S(rate=S(inverse=S(point=S(fluid=S(mechanical=S(temperature_k=300.125)))))),S(coefficient_json=str(BASE/'heos-water.json'))
 def test_seed_is_untrusted_and_saved(self):
  r,p=self.setup_proposal();records=[];b=m.propose(r,p,lambda:None,lambda x:records.append(json.loads(json.dumps(data(x)))))
  self.assertEqual(records[-1]['status'],'completed_untrusted_proposals');self.assertEqual(records[-1]['attempted'],1);self.assertEqual(records[-1]['completed'],1)
  self.assertEqual(b.weights,(D('4e-6'),D('.001')))
 def test_guard_failure_saved_without_evaluation(self):
  r,p=self.setup_proposal();records=[]
  def stop():raise TimeoutError('synthetic budget')
  with self.assertRaises(TimeoutError):m.propose(r,p,stop,lambda x:records.append(json.loads(json.dumps(data(x)))))
  self.assertEqual(records[-1]['status'],'failed');self.assertEqual(records[-1]['attempted'],0)
 def test_actual_evidence_error_shape_serializable(self):
  e=LiquidPressureEvidence('unresolved','synthetic', '0'*64,None,None,(),0,0,0.,ProofBudget(4,256,20.,60),(),None,b'{}',b'{}',b'{}',b'{}')
  saved=json.loads(json.dumps(data(e),allow_nan=False));self.assertEqual(saved['fields']['status'],'unresolved');self.assertFalse(saved['fields']['consumer_admission'])
if __name__=='__main__':unittest.main()
