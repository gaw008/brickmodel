"""Saved fresh query audit only. No model imports or EOS execution."""
from pathlib import Path
from decimal import Decimal as D
from fractions import Fraction as F
from itertools import product
from collections import deque
import hashlib,json
R=Path(__file__).parent;O=R/'attempt01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def decode(v):
    if isinstance(v,list):return [decode(x) for x in v]
    if not isinstance(v,dict):return v
    if set(v)=={'float_hex'}:return float.fromhex(v['float_hex'])
    if set(v)=={'decimal'}:return D(v['decimal'])
    if set(v)=={'fraction'}:return F(*v['fraction'])
    if set(v)=={'bytes_hex'}:return bytes.fromhex(v['bytes_hex'])
    if set(v)=={'type','fields'}:return decode(v['fields'])
    return {k:decode(x) for k,x in v.items()}
def read(p):return decode(json.loads(p.read_bytes()))
def blob(v):return decode(json.loads(v))
def iv(v):return F(v['lo']),F(v['hi'])
def pt(v):return v,v
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
    v=[x*y for x in a for y in b];return min(v),max(v)
def isum(xs):
    s=pt(F())
    for x in xs:s=add(s,x)
    return s
def encloses(saved,exact):
    a,b=iv(saved);assert a<=exact[0]<=exact[1]<=b
s=read(O/'summary.json');freeze=read(R/'EXECUTION_FREEZE.json');watch=read(R/'supervisor-result01.json')
assert s['freeze']==freeze and s['source_after']==freeze['files']=={p:sha(Path(p)) for p in freeze['files']}
assert len(freeze['files'])==247 and len(freeze['installed_python_members'])==101
assert s['installed_python_members_after']==freeze['installed_python_members']==sorted(str(p) for p in Path(freeze['installed_package_root']).rglob('*.py'))
assert s['asset_directory_members_after']==freeze['asset_directory_members']=={d:sorted(str(p) for p in Path(d).rglob('*') if p.is_file()) for d in freeze['asset_directory_members']}
assert s['inputs_unchanged'] and s['membership_unchanged'] and s['status']=='proved_conditional_query' and s['selected_cell']==0
assert watch['returncode']==0 and not watch['external_timeout'] and watch['runner_unchanged']
assert watch['runner_sha256']==sha(R/'run.py') and watch['freeze_sha256']==sha(R/'EXECUTION_FREEZE.json') and watch['supervisor_sha256']==sha(R/'supervise.py')
assert s['elapsed_seconds']<60 and watch['elapsed_seconds']<watch['external_limit_seconds']==70
h=O/'host';case=read(h/'case.json');states=read(h/'initial.json');rates=read(h/'rates.json');pair=read(h/'pair-inputs.json');status=read(h/'operation-status.json')
assert case['initial_temperatures_k']==[300.125,305.25]
assert status['status']=='completed_current_query' and status['elapsed_seconds']<30
assert status['costs']=={'initial_forward_attempted':2,'initial_forward_completed':2,'host_attempted':1,'host_completed':1,'native_internal_call_count':None}
for i,T in enumerate(case['initial_temperatures_k']):
    p=read(h/f'initial-forward-{i}.json');proto=read(h/f'initial-prototype-{i}.json')
    assert p['fluid']['mechanical']['temperature_k']==T and states[i]['internal_energy_j']==p['total_internal_energy_j']
    assert all(states[i][key]==proto[key] for key in ('solid_mass_kg','liquid_water_mol','gas_amounts_mol','energy_model_identity'))
e=read(O/'pressure-evidence.json');assert e['status']=='proved_conditional_query' and e['reason'] is None
raw=(O/'bound-numeric-request.json').read_bytes();assert raw==e['original_query_json'] and hashlib.sha256(raw).hexdigest()==e['request_sha256']
assert blob(raw)==[states,rates['cells'][0],0]
p=blob(e['parameters_json']);record=blob(p['original_numeric_record']);assert record['state']==states[0] and record['rate']==rates['cells'][0]
inv=rates['cells'][0]['inverse'];point=inv['point'];m0=point['fluid']['mechanical'];st=pair['storages'][0];ip=pair['inverse_policies'][0];w=rates['cells'][0]['equilibrium']['liquid']['state']
assert inv['target_energy_j']==states[0]['internal_energy_j'] and point['model_identity']==states[0]['energy_model_identity']==st['_identity']
err=abs(F(point['total_internal_energy_j'])-F(inv['target_energy_j']))+F(point['energy_error_j']);cp=F(point['minimum_heat_capacity_j_k']);eps=F(inv['temperature_error_bound_k']);T=F(m0['temperature_k'])
assert cp>0 and err/cp==p['inverse_error_required']<=eps==p['inverse_error_saved']<=F(ip['temperature_tolerance_k']) and err<=F(ip['energy_tolerance_j'])
encloses(p['temperature'],(T-eps,T+eps));lo,hi=map(F,inv['final_temperature_bracket_k']);assert lo<=iv(p['temperature'])[0]<=iv(p['temperature'])[1]<=hi
seed=read(O/'seed-proposals.json');assert seed['status']=='completed_untrusted_proposals' and seed['attempted']==seed['completed']==len(seed['iterations'])==5
boxes=blob(e['proposals_json']);assert boxes==seed['boxes']
ops=e['operations'];assert [o['name'] for o in ops]==['coexistence','coupled_mechanical_root','full_temperature_connected_density_tube','observed_native_query']
assert all(o['status']=='completed' and o['evidence_json'] for o in ops) and e['attempted_proof_operations']==e['completed_proof_operations']==4
assert e['budget']['maximum_proof_operations']==4 and e['budget']['maximum_boxes_per_primitive']==256 and e['elapsed_seconds']<=e['budget']['maximum_wall_seconds']<=20
assert e['source_before']==e['source_after'] and e['native_calls']==0 and e['bottom_level_residual_evaluation_count'] is None and not e['consumer_admission']
a,m,tube,qout=[blob(o['evidence_json']) for o in ops];k=a['krawczyk']
assert p['temperature']==a['domain']['temperature']==a['center']['temperature']==m['temperature']==tube['temperature']
assert k['center']==seed['iterations'][-1]['center'] and k['preconditioner']==seed['iterations'][-1]['matrix']
assert k['jacobian']==a['domain']['jacobian'] and k['center_residual']==a['center']['residual']
X=list(map(iv,k['box']));c=list(map(F,k['center']));C=[list(map(F,row)) for row in k['preconditioner']];J=[[iv(v) for v in row] for row in k['jacobian']];f=list(map(iv,k['center_residual']));weights=list(map(F,k['weights']))
assert weights==[F('4e-6'),F('.001')] and C[0][0]*C[1][1]-C[0][1]*C[1][0]!=0
A=[[sub(pt(F(int(i==j))),isum(mul(pt(C[i][u]),J[u][j]) for u in range(2))) for j in range(2)] for i in range(2)]
image=[add(sub(pt(c[i]),isum(mul(pt(C[i][j]),f[j]) for j in range(2))),isum(mul(A[i][j],sub(X[j],pt(c[j]))) for j in range(2))) for i in range(2)]
for saved,exact in zip(k['image'],image):encloses(saved,exact)
norm=max(sum(max(abs(lo),abs(hi))*weights[j]/weights[i] for j,(lo,hi) in enumerate(row)) for i,row in enumerate(A));assert norm<=F(k['contraction_upper'])<1
for i in range(2):
    lo,hi=iv(k['image'][i]);assert all(0<F(saved)<=exact for saved,exact in zip(k['strict_margins'][i],(lo-X[i][0],X[i][1]-hi)))
assert k['proved'] and a['proved'] and all(iv(v)[0]>0 for v in a['domain']['stability'])
pressures=list(map(iv,a['domain']['pressure']));assert iv(a['pressure'])==(max(x[0] for x in pressures),min(x[1] for x in pressures))
q=qout['query'];t,target,rhom,mp,mn,nl,vhost,decl=map(F,q);scale=mp/mn;rn=rhom/mn
assert q==p['observed_query'] and q[:3]==[w['temperature_k'],w['pressure_pa'],w['density_kg_m3']] and w['temperature_k']==m0['temperature_k'] and w['pressure_pa']==m0['liquid_pressure_pa']==m0['pressure_pa']
assert q[5]==states[0]['liquid_water_mol'] and q[6]==m0['liquid_volume_m3'] and q[7]==st['fluid_template']['envelope']['liquid_v_error_m3_mol']
assert m0['gas_inventory_mol']==dict(zip(('O2','N2','H2O'),states[0]['gas_amounts_mol'],strict=True))
encloses(p['public_native_scale'],(scale,scale));encloses(p['gas_mol'],pt(sum(map(F,states[0]['gas_amounts_mol']))))
volume=F(st['bulk_volume_m3'])-sum(F(x)*F(solid['volume_m3_kg']) for x,solid in zip(states[0]['solid_mass_kg'],st['solids'],strict=True));ve=F(st['bulk_volume_error_m3'])+nl*decl;encloses(p['effective_volume'],(volume-ve,volume+ve))
assert iv(m['lower_residual'])[1]<0<iv(m['upper_residual'])[0] and iv(m['liquid_pressure_derivative'])[0]>0 and iv(m['total_residual_derivative'])[0]>0
corners=[]
for tt,V,rho,sc,ng in product(iv(p['temperature']),iv(p['effective_volume']),iv(boxes['mechanical_density']),iv(p['public_native_scale']),iv(p['gas_mol'])):
    vg=V-nl*sc/rho;assert vg>0;corners.append(ng*F(p['gas_constant'])*tt/vg)
encloses(m['pressure'],(min(corners),max(corners)))
union=[iv(a['domain']['density'][0]),iv(boxes['mechanical_density']),iv(boxes['observed_density']),iv(qout['metrics']['native_density'])]
assert iv(tube['density'])==(min(x[0] for x in union),max(x[1] for x in union)) and union[0][1]<union[1][0]
assert union[2][0]<=rn<=union[2][1] and qout['density_box']==boxes['observed_density']
queue=deque([iv(tube['density'])]);positive=[]
for visit in tube['visits']:
    box=queue.popleft();assert iv(visit['density'])==box
    lo,hi=iv(visit['derivative'])
    if visit['decision']=='positive':assert lo>0;positive.append(box)
    else:
        assert visit['decision']=='split' and lo<=0<hi
        mid=sum(box)/2;queue.extend([(mid,box[1]),(box[0],mid)])
leaves=list(map(iv,tube['leaves']));assert not queue and not tube['pending'] and leaves==sorted(positive)
assert leaves[0][0]==iv(tube['density'])[0] and leaves[-1][1]==iv(tube['density'])[1] and all(x[1]==y[0] for x,y in zip(leaves,leaves[1:]))
assert tube['proved'] and tube['evaluations_attempted']==tube['evaluations_completed']==len(tube['visits'])<=256 and tube['source_before']==tube['source_after']
metrics=qout['metrics'];assert qout['status']=='passed_observed_query' and qout['source_before']==qout['source_after']==e['source_before']
assert qout['attempted']==qout['completed']==len(qout['visits'])==4 and not qout['pending']
assert qout['accepted_leaves'][0][0]==qout['density_box'] and qout['accepted_leaves'][0][1]==qout['visits'][3]['derivative']
for j,key in enumerate(('lower_residual','upper_residual','observed_residual')):
    lo,hi=iv(qout['visits'][j]['pressure']);encloses(metrics[key],(lo-target,hi-target))
assert iv(metrics['lower_residual'])[1]<0<iv(metrics['upper_residual'])[0]
slope=F(metrics['minimum_slope']);assert slope==iv(qout['visits'][3]['derivative'])[0]>0
assert F(metrics['density_error_bound'])>=max(map(abs,iv(metrics['observed_residual'])))/slope
assert F(metrics['native_volume_error_bound'])>=scale*F(metrics['density_error_bound'])/(iv(qout['density_box'])[0]*rn)
assert q[6]==q[5]*q[3]/q[2]
roundoff=vhost-nl*mp/rhom;assert F(metrics['host_volume_roundoff_exact'])==roundoff;encloses(metrics['host_per_mol_roundoff'],pt(roundoff/nl))
assert F(metrics['combined_volume_error_bound'])>=F(metrics['native_volume_error_bound'])+max(map(abs,iv(metrics['host_per_mol_roundoff']))) and F(metrics['combined_volume_error_bound'])<=decl
fixed=F(point['pressure_error_pa']);assert fixed==F(p['original_fixed_T_error_pa'])
assert e['pressure_radius_pa']==max(abs(F(m0['pressure_pa'])-x) for x in iv(m['pressure']))+fixed
policy=blob(e['policy_json']);lo,hi=iv(m['pressure']);assert iv(p['pressure_domain'])[0]<=lo-fixed<=hi+fixed<=iv(p['pressure_domain'])[1] and policy['pressure_domain_pa'][0]<=lo-fixed<=hi+fixed<=policy['pressure_domain_pa'][1]
assert lo>iv(a['pressure'])[1]+max(F(.01),F(2e-8)*iv(a['pressure'])[1])
assert tube['elapsed_seconds']<=tube['maximum_wall_seconds']<=20 and qout['elapsed_seconds']<=qout['maximum_wall_seconds']<=20
out={'status':'PASS','selected_cell':0,'summary_sha256':sha(O/'summary.json'),'evidence_sha256':sha(O/'pressure-evidence.json'),'sources':247,'installed_python_members':101,'host_costs':status['costs'],'host_elapsed_seconds':status['elapsed_seconds'],'seed_evaluations':5,'proof_operations':4,'tube_visits':len(tube['visits']),'tube_leaves':len(leaves),'native_query_math_evaluations':4,'pressure_radius_exact':str(e['pressure_radius_pa']),'pressure_radius_pa':float(e['pressure_radius_pa']),'combined_volume_error_bound':str(metrics['combined_volume_error_bound']),'original_volume_error':q[-1],'proof_elapsed_seconds':e['elapsed_seconds'],'supervisor_elapsed_seconds':watch['elapsed_seconds'],'review_EOS_calls':0,'scope':'One cell current query; source/model/conditional envelope bound, not trajectory or universal native accuracy'}
with (R/'review_saved_fresh01.json').open('x') as stream:stream.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
