"""One fresh two-cell host query and one first-cell pressure certificate."""
from pathlib import Path
import hashlib
import json
import os
import time
import traceback

HERE = Path(__file__).resolve().parent


def main():
    begun = time.monotonic()
    output = HERE / 'attempt01'
    output.mkdir(exist_ok=False)
    freeze = json.loads((HERE / 'EXECUTION_FREEZE.json').read_bytes())
    files = freeze['files']
    summary = {'status': 'started', 'freeze': freeze, 'selected_cell': 0,
               'qualification': 'current_native_water_manufactured_other_parameters_conditional_error_envelopes',
               'host_snapshot_note': 'host/attempted-point.json is the old builder parameter snapshot; host/case.json contains actual new initial temperatures',
               'native_internal_call_count': None,
               'whole_wall_seconds': 60., 'query_wall_seconds': 30.,
               'proof_operation_budget': 4, 'proof_wall_seconds': 20.}
    def sha(path):
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    def save(path, value):
        from sludge_sandbox.mass_wet_pressure_interval import data
        tmp = path.with_suffix('.partial')
        tmp.write_text(json.dumps(data(value), indent=2, allow_nan=False) + '\n')
        os.replace(tmp, path)
    def guard():
        if time.monotonic() - begun >= 60.:
            raise TimeoutError('whole_fresh_study_60_seconds')
        if any(sha(path) != digest for path, digest in files.items()):
            raise ValueError('frozen_source_changed')
        root = Path(freeze['installed_package_root'])
        if sorted(str(p) for p in root.rglob('*.py')) != freeze['installed_python_members']:
            raise ValueError('installed_package_membership_changed')
        for directory, members in freeze['asset_directory_members'].items():
            if sorted(str(p) for p in Path(directory).rglob('*') if p.is_file()) != members:
                raise ValueError('source_asset_membership_changed')
    try:
        guard()
        from build_query import build_and_query
        from propose_boxes import propose
        from sludge_sandbox.mass_wet_pressure_interval import (
            BoundLiquidPressureRequest, LiquidBranchModelPolicy,
            IAPWS95LiquidPressureProvider, ProofBudget, encoded,
        )
        def query_guard():
            guard()
            if time.monotonic() - begun >= 30.:
                raise TimeoutError('fresh_query_30_seconds_including_construction')
        save(output / 'summary.json', summary)
        pair, states, rates = build_and_query(output / 'host', query_guard)
        query_guard()
        request = BoundLiquidPressureRequest.capture(pair, states, rates.cells[0], 0)
        (output / 'bound-numeric-request.json').write_bytes(encoded((states, rates.cells[0], 0)))
        policy = LiquidBranchModelPolicy(freeze['official_pdf'], freeze['coefficient_json'],
                                         pair.storages[0].water.implementation.sha256)
        boxes = propose(request, policy, guard, lambda value: save(output / 'seed-proposals.json', value))
        guard()
        evidence = IAPWS95LiquidPressureProvider().evaluate(
            request, branch_policy=policy, boxes=boxes,
            budget=ProofBudget(4, 256, min(20., 60. - (time.monotonic() - begun)), 60),
            cancel=lambda: time.monotonic() - begun >= 60.)
        save(output / 'pressure-evidence.json', evidence)
        guard()
        summary.update(status=evidence.status, reason=evidence.reason,
                       proof_operations_attempted=evidence.attempted_proof_operations,
                       proof_operations_completed=evidence.completed_proof_operations)
    except Exception as exc:
        summary.update(status='failed', reason=type(exc).__name__ + ': ' + str(exc), traceback=traceback.format_exc())
    finally:
        summary['elapsed_seconds'] = time.monotonic() - begun
        summary['source_after'] = {p: sha(p) if Path(p).is_file() else None for p in files}
        summary['inputs_unchanged'] = summary['source_after'] == files
        summary['installed_python_members_after'] = sorted(str(p) for p in Path(freeze['installed_package_root']).rglob('*.py'))
        summary['asset_directory_members_after'] = {directory: sorted(str(p) for p in Path(directory).rglob('*') if p.is_file()) for directory in freeze['asset_directory_members']}
        summary['membership_unchanged'] = (summary['installed_python_members_after'] == freeze['installed_python_members'] and summary['asset_directory_members_after'] == freeze['asset_directory_members'])
        if not summary['inputs_unchanged'] or not summary['membership_unchanged'] or summary['elapsed_seconds'] >= 60.:
            summary['status'] = 'failed'
        save(output / 'summary.json', summary)
    print(summary['status'], summary.get('reason'), summary['elapsed_seconds'])
    return 0 if summary['status'] == 'proved_conditional_query' else 1


if __name__ == '__main__':
    raise SystemExit(main())
