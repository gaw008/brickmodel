"""Bounded numerical seed proposals; none is accepted without fresh proofs."""
from decimal import Decimal as D, localcontext
from pathlib import Path
import json
import math

from sludge_sandbox.water_interval_eos import I, Interval, residual
from sludge_sandbox.water_coexistence import evaluate_box
from sludge_sandbox.mass_wet_pressure_interval import QueryBoxes, parameters


def propose(request, policy, guard, save):
    """No native query. Save every attempted point-refinement operation."""
    record = {'status': 'started', 'attempted': 0, 'completed': 0,
              'maximum_iterations': 12, 'precision': 60,
              'stopping_residual': '1e-30', 'iterations': [],
              'qualification': 'untrusted_numerical_proposals_not_certificates'}
    save(record)
    try:
        guard()
        params = parameters(request, policy, 60)
        raw = json.loads(Path(policy.coefficient_json).read_text())[0]
        equation = raw['EOS'][0]
        with localcontext() as context:
            context.prec = 60
            temperature = request.rate.inverse.point.fluid.mechanical.temperature_k
            center = []
            for name, kind in (('rhoL', 'rhoLnoexp'), ('rhoV', 'rhoV')):
                ancillary = raw['ANCILLARIES'][name]
                if ancillary['type'] != kind or not ancillary['Tmin'] <= temperature <= ancillary['Tmax']:
                    raise ValueError('ancillary_seed_domain')
                theta = 1 - temperature / ancillary['T_r']
                total = math.fsum(n * theta ** power for n, power in zip(ancillary['n'], ancillary['t'], strict=True))
                rho = ancillary['reducing_value'] * (1 + total if name == 'rhoL' else math.exp(ancillary['T_r'] / temperature * total))
                center.append(D(rho).ln())
            center = tuple(center)
            kwargs = dict(reducing_density=equation['STATES']['reducing']['rhomolar'],
                          reducing_temperature=equation['STATES']['reducing']['T'],
                          gas_constant=equation['gas_constant'],
                          jet=lambda d, tau: residual(d, tau, equation['alphar']))
            def midpoint(value):
                return (value.lo + value.hi) / 2
            for iteration in range(12):
                guard()
                record['attempted'] += 1
                save(record)
                value = evaluate_box(I(temperature), tuple(I(x) for x in center), **kwargs)
                record['completed'] += 1
                a, b = map(midpoint, value.jacobian[0])
                c, d = map(midpoint, value.jacobian[1])
                determinant = a * d - b * c
                if determinant == 0:
                    raise ValueError('singular_seed_jacobian')
                matrix = ((d / determinant, -b / determinant), (-c / determinant, a / determinant))
                residuals = tuple(map(midpoint, value.residual))
                record['iterations'].append(dict(iteration=iteration, center=center,
                                                  value=value, matrix=matrix))
                save(record)
                if max(map(abs, residuals)) < D('1e-30'):
                    break
                center = tuple(center[j] - sum((matrix[j][k] * residuals[k] for k in range(2)), D(0)) for j in range(2))
            else:
                raise ValueError('bounded_seed_not_converged')
            weights = (D('4e-6'), D('1e-3'))
            log_boxes = tuple(Interval((I(x) - I(r)).lo, (I(x) + I(r)).hi) for x, r in zip(center, weights, strict=True))
            query = params.observed_query
            observed = I(query[2]) / I(query[4])
            mechanical = I(params.liquid_mol) * params.public_native_scale / I(query[6])
            def expand(value):
                return Interval((value - I(D('.2'))).lo, (value + I(D('.2'))).hi)
            boxes = QueryBoxes(expand(mechanical), expand(observed), log_boxes, center, matrix, weights)
            record.update(status='completed_untrusted_proposals', boxes=boxes)
            guard()
            save(record)
            return boxes
    except Exception as exc:
        record.update(status='failed', reason=type(exc).__name__ + ': ' + str(exc))
        save(record)
        raise
