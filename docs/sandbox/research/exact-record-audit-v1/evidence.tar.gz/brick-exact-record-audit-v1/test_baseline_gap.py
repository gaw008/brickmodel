import json
import pytest
from test_exact_record import make
from sludge_sandbox.exact_record import read_exact_run,validate_binding,ExactRecordError


def test_structural_validation_does_not_reject_wrong_prefix_energy(monkeypatch):
    raw,op,_=make(monkeypatch)
    d=json.loads(raw)
    a=d['result']['fields']['states']['sequence'][-1]['fields']['internal_energy_j']['array']['values']
    a[0]={'float_hex':(float.fromhex(a[0]['float_hex'])+1).hex()}
    with pytest.raises(ExactRecordError):
        validate_binding(read_exact_run(json.dumps(d).encode()),op,case_sha256='a'*64,runtime_identity={'modules':{'test':'b'*64}})
