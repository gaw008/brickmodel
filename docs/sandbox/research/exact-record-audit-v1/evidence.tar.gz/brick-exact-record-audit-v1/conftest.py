"""Temporary candidate package path only; never apply to repository tests."""
from pathlib import Path
import sludge_sandbox

sludge_sandbox.__path__.append(str(Path(__file__).resolve().parent))
