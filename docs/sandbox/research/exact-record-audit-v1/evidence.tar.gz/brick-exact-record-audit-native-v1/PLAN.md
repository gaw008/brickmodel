# Original native strict-record prefix audit

Use the completed two-cell exact record from brick-exact-record-native-v1/attempt01, its original case/initial/policies/runtime and cached water evidence. Build the original actual host under the same frozen78 installed modules; exact runtime equality must hold before any audit. The newly reviewed audit implementation is loaded separately from its frozen temporary path and independently hash-bound by the supervisor. It is not falsely declared part of the original run runtime.

One process,45-second external supervisor. Prior complete case initialization plus encoding took~2 seconds; no integration is called here. Native work is limited to build_case initialization required to reconstruct and validate the actual host. Recompute selected affine writeback and complete original30prefixes with original budgets. Preserve partial_audit and resume_authorized=false; missing full root/quad/comparison/resources remain missing. Save result, original input hashes, before/after runtime and structured failure. Do not modify or re-run the original trajectory.

Only after this process terminates may the new audit source be installed, changing runtime membership to79. Such a later installation must not be presented as the78-module runtime used in this saved verification.
