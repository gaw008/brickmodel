"""Audit original native record against actual rebuilt host; no integration."""
from pathlib import Path
from dataclasses import replace
import hashlib,json,time,traceback,sys
sys.path.insert(0,'/private/tmp/brick-exact-record-audit-v1')
from exact_record_audit import audit_exact_run
from sludge_sandbox.verification_case import build_case,read_case,encode
from sludge_sandbox.exact_record import read_exact_run
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent;out=root/'attempt01';out.mkdir(exist_ok=False)
prior=Path('/private/tmp/brick-exact-record-native-v1/attempt01')
def save(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
started=time.monotonic();before=runtime_identity();save('runtime-before.json',before)
inputs={name:(prior/name).read_bytes() for name in ('case.json','exact-run-record.json','initial.json','event-policy.json','integration-policy.json','runtime-before.json')}
report={'status':'started','qualification':'Actual original host rebuilt for independent prefix audit; no new trajectory or resume.'}
try:
    assert before==json.loads(inputs['runtime-before.json'])
    built=build_case(read_case(prior/'case.json'),Path('/private/tmp/brick-free-native-events-v1/attempt01/water'))
    assert encode(built.initial)==json.loads(inputs['initial.json'])
    policy=replace(built.depletion_policy,ordered_event_policy='ordered_affine_packet_v1')
    assert encode(policy)==json.loads(inputs['event-policy.json']) and encode(built.policy)==json.loads(inputs['integration-policy.json'])
    op=ExactFreeWaterTransfer(built.operator)
    record=read_exact_run(inputs['exact-run-record.json'])
    start=ExactEventTime.from_float(built.start_s);end=ExactEventTime.from_float(built.end_s)
    audit_start=time.monotonic()
    result=audit_exact_run(record,op,original_initial=built.initial,start=start,end=end,integration_policy=built.policy,event_policy=policy,case_sha256=hashlib.sha256(inputs['case.json']).hexdigest(),runtime_identity=before)
    save('audit-result.json',encode(result))
    assert result.record_sha256==hashlib.sha256(inputs['exact-run-record.json']).hexdigest()
    assert result.accepted_prefixes==30 and result.committed_events==2
    assert result.resume_authorized is False
    report.update(status='passed',audit_elapsed_s=time.monotonic()-audit_start,accepted_prefixes=result.accepted_prefixes,committed_events=result.committed_events,scope=result.scope,resume_authorized=result.resume_authorized)
except BaseException:report.update(status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-after.json',after);assert before==after
        assert all((prior/name).read_bytes()==raw for name,raw in inputs.items())
    except BaseException:report.update(status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_s=time.monotonic()-started,modules=len(before['modules']),inputs={name:hashlib.sha256(raw).hexdigest() for name,raw in inputs.items()},runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),audit_module_sha256=hashlib.sha256(Path('/private/tmp/brick-exact-record-audit-v1/exact_record_audit.py').read_bytes()).hexdigest())
    save('report.json',report)
assert report['status']=='passed',report
