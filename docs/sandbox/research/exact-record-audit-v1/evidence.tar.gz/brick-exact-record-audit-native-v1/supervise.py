from pathlib import Path
import importlib.util,sys,json
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location('supervisor','/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/research-process-supervisor/supervisor.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
r=m.run_attempt(root/'supervised01',['/private/tmp/brick-water-backend-probe/venv/bin/python',str(root/'run.py')],cwd='/private/tmp',input_paths=[root/'run.py',root/'PLAN.md','/private/tmp/brick-exact-record-audit-v1/exact_record_audit.py','/private/tmp/brick-exact-record-native-v1/attempt01/exact-run-record.json'],timeout_s=45,cleanup_grace_s=.1)
print(json.dumps(r,indent=2))
