# Bounded native original-host audit runner review

APPROVE. Inspected hashes:

- run.py: f2799d73d5e2ba05355b55c51af0c7fb4ecc54d4c8c48d428cd2be3c5ad497b0
- PLAN.md: e39d65f1bc432e8d3c1ee1c7d0cf250e2c5eb2135c43d9528647c353a2253db3
- supervise.py: d7d0412feafbc443a9ab55333864f88392fc40a8d00d9a9636a7d8a3c29b7f6a

The runner requires current installed runtime to equal the original saved 78-module runtime before build_case. It rebuilds the original case and checks complete initial state and both policies against original saved bytes, then passes original exact start/end, case hash and runtime to the new partial auditor. There is no integration call. Native work is limited to original initialization needed for actual operator binding.

The temporary audit module is separately imported and hash-recorded, not presented as part of the old installed runtime. The supervisor binds its file alongside runner/plan/record and imposes the actual 45-second external limit. Run-local output is created exclusively. The result is saved before assertions, with exact original record SHA, 30 accepted prefixes / 2 committed events and resume_authorized=false required. Finally the runtime and all original input bytes are checked unchanged; structured failures are retained.

This verifies only the approved partial prefix/selected-writeback audit against the actual rebuilt host. It does not rerun the original trajectory or claim missing root/quadrature/comparison/resource gates. A subsequent 79-module installation has a distinct runtime and must remain distinguished from this verification. No EOS, source edits or execution occurred during review.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — bounded original-host reconstruction and partial saved-record audit.
