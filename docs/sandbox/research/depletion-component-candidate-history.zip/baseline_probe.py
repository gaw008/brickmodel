import json
from test_depletion_integration import policies,oracle
from sludge_sandbox.integration import ConservedState
from sludge_sandbox.depletion_integration import integrate_depletion
p,e=policies()
r=integrate_depletion(ConservedState([[1e-4,0.]],[600.]),oracle(knots=(.05,.15)),start_s=0,end_s=.2,integration_policy=p,event_policy=e)
print(json.dumps(dict(status=r.status,reason=r.reason,times=r.times_s,amounts=[x.amounts_mol.tolist() for x in r.states],energy=[x.internal_energy_j.tolist() for x in r.states],evaluations=r.evaluations,rejected=r.rejected_trials,attempted=r.attempted_steps,events=[x.time_s for x in r.events],refinements=[(x.level,x.evaluations,x.event_time_s,x.status) for x in r.refinements],steps=[(x.face_species_mol.tolist(),x.face_energy_j.tolist(),x.reaction_species_mol.tolist(),x.cell_work_j.tolist()) for x in r.steps]),sort_keys=True))
