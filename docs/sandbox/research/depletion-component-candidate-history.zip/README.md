# Isolated depletion component-work candidate

2026-09-07. Repository source and tests were not modified. Only these candidate production files differ intentionally: depletion_integration.py, water_phase_transfer.py, programmed_solid_fluid_heat.py. The package snapshot contains unchanged dependencies to make import identities reproducible. Root's newer integration.py and depletion_roundoff.py were copied unchanged for the new energy_model_identity contract; the original baseline keeps its earlier snapshot.

## Actual evidence

- red.log: tests-first failure, terminal StepLedger components None.
- attempt01.log: first 5 tests passed; attempt02.log: expanded 12 passed.
- final.log and final.xml: **25 passed in 0.65 s**, 14 new accounting/wiring cases plus 11 preexisting manufactured depletion cases. No water EOS run.
- baseline.json and candidate-final.json: identical bytes for old None-mode times, states, arrays, event times, per-step exchanges and evaluation/rejection/panel/refinement counts. Timing fields are deliberately excluded. Probe source is baseline_probe.py.
- budget_probe*.py were exploratory numerical-budget fixture construction, not physical accuracy validations. They selected explicit 3e-18 and 4.4e-18 J test budgets to exercise ordinary cross-segment versus whole-event-path rejection; no production tolerance was changed. Their original tool output was observed but not saved as a raw local log.
- manifest.json binds candidate dependencies, production files, tests and persisted evidence.

Command (from repository root):

`PYTHONPATH=/private/tmp/brick-depletion-components-candidate/candidate:tests/sandbox .venv/bin/python -m pytest /private/tmp/brick-depletion-components-candidate/tests tests/sandbox/test_depletion_integration.py -q --junitxml=/private/tmp/brick-depletion-components-candidate/final.xml`

Stdout/stderr were redirected to final.log in the actual run.

## Implementation differences and limits

The two wrapper evaluate methods forward the existing component map without adding power. Wrapper tests deliberately instrument actual methods with manufactured collaborators and bypass constructors; they certify field wiring only, not source gates, real EOS or host material admission. Existing production constructors are unchanged.

Every ordinary callback checks the shared depletion schema even when no post-event stage check is needed; its old evaluation/decode counting route remains unchanged. Observe handles schema checks for terminal/refinement/mode paths. Terminal component quadrature uses exact represented endpoint-start interval, with individually recorded rounding. Global commit prechecks cumulative per-cell absolute decomposition residual over all proposed path panels before changing history or mode. Post-event component classifications cannot disappear merely because values become zero.

Terminal state construction preserves root's opaque total-energy identity; observations and ordinary stages check against the initial binding. The identity is not a material qualification. Initial cancellation leaves no schema and no invented component record.

This does not implement a deforming-solid thermal inverse or relax the exact host admission of the two real wrappers. Net-energy and event-state error estimates still do not certify large mutually cancelling component truncation errors. No additional heat source, latent heat, inventory clipping or event correction was introduced.

## Frozen provenance

Baseline source commit is `41e59113cf97d073119dd3d9088239758c2a41cd`. Actual `git show 41e5911:src/sludge_sandbox/<file>` byte comparison confirmed the baseline copies of all five files below match that commit. Baseline integration therefore predates the root's new opaque energy binding. Candidate dependency additions were copied from root's then-current working tree, not falsely attributed to the committed baseline.

Candidate files relative to this directory:

| File | SHA256 |
|---|---|
| candidate/sludge_sandbox/depletion_integration.py | d777acbd443cf4af6ed1ca7f5074fe6a9388cac4691a0e961f9ef238091e8469 |
| candidate/sludge_sandbox/water_phase_transfer.py | 208141aab520492fb85a6e91f4270f59978418d8fb3f1b24fb254475a36c42a6 |
| candidate/sludge_sandbox/programmed_solid_fluid_heat.py | 915c9e85ac64b93a2ee0a89d80427acf5d9bed69bf2737bfbc3224fe0663713a |
| candidate/sludge_sandbox/integration.py (unchanged copied root dependency) | cedefb0c3af415be8d9a7fb165c1d2288249b354666567191bbf57c33d405b50 |
| candidate/sludge_sandbox/depletion_roundoff.py (unchanged copied root dependency) | 65b53e7a9f94b651e5dbc833054b637129ff659b63a290e0512154f3f9333148 |

Elapsed wall seconds are excluded from the None-baseline JSON comparison because independent runs observe different wall-clock durations even with identical states and operation counts. The comparison does include actual evaluations, rejected trials, attempted panels and per-refinement evaluation counts. It makes no runtime-equality or performance claim.
