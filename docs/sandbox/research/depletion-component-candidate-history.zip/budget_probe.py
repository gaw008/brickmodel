from dataclasses import replace
from test_depletion_integration import policies,oracle
from sludge_sandbox.integration import ConservedState
from sludge_sandbox.depletion_integration import integrate_depletion
p,e=policies();op=oracle(a=1/1024);old=op.evaluate_callback
def evaluate(s,t,m):
 x=old(s,t,m);r=replace(x.rates,cell_power_w=[.5],cell_power_components_w={'elastic':[.1],'body':[.4]})
 return replace(x,rates=r)
op=replace(op,evaluate_callback=evaluate)
for tol in (1e-8,1e-17,1e-18,1e-19):
 r=integrate_depletion(ConservedState([[1/8192,0]],[0]),op,start_s=0,end_s=.25,integration_policy=replace(p,initial_step_s=1/32,maximum_step_s=1/32,energy_absolute_tolerance_j=tol),event_policy=e)
 print(tol,r.status,r.reason,len(r.events),len(r.steps),r.times_s[-1],r.cumulative_absolute_component_residual_j)
