# Candidate: component work through ordinary/terminal depletion paths

Prepared 2026-09-07 while repository source/tests are frozen. Design only; no EOS run. Existing integration source remains authoritative. This does not admit an unimplemented deforming-solid host.

## Actual current chain and losses

1. `SolidFluidHeat.evaluate` assembles zero cell power and optional gas/liquid faces/reaction inventories; it presently has no mechanical component supplier. Leave its default Rates components None.
2. `ProgrammedSolidFluidHeat.evaluate` copies base power when replacing exterior gas/heat face values, but reconstructs Rates with four positional arrays. This currently drops optional components.
3. `WaterPhaseTransfer.evaluate` copies base power when replacing liquid/vapor reaction sources, but likewise drops optional components. Neither boundary exchange nor water phase transfer changes cell power. Forward the exact base component map into the new immutable Rates constructor; do not reclassify enthalpy as body work or add latent heat.
4. `integrate_depletion.observe` validates Rates and observations. `normal` sometimes bypasses observe (`stage_check is None`) and passes the operator directly to ordinary integrate. Ordinary integrate locks component schema only within that segment. Cross-segment/mode identity therefore is not enforced yet.
5. `terminal` uses one observed state and a directed representable event endpoint. It integrates four arrays with exact Fraction(endpoint-start)*Fraction(rate), converts once, and constructs a four-field StepLedger. This loses terminal component quadrature.
6. `commit` validates all speculative path prefixes before mutating global history; it already accumulates exact represented N/U ledgers and event writeback terms. It has no cross-segment absolute component residual accumulator. Discarded coarse/fine paths must not consume the committed component budget.

## Proposed minimal production scope after freeze release

Changes would be limited to depletion_integration.py, water_phase_transfer.py, programmed_solid_fluid_heat.py and new tests. Ordinary integration.py need not change. Initial SolidFluidHeat's None is preserved. New deforming host admission/type unions and total-energy mechanics are explicitly separate work.

- Both wrappers pass `cell_power_components_w=base.rates.cell_power_components_w`. Reconstruction validates the same classification sum; preserve existing full base_evaluation and source identity. No new default zero dictionary.
- Establish one immutable schema for the whole depletion call from the initial observed Rates: None or sorted key tuple. All future Rates, including ordinary RK stages, trial refinement, terminal observations, and post-event mode changes, must match. Schema changes are contract failures, not refinable physics failures. Keep stable zero-valued components after depletion rather than removing keys.
- Route ordinary stages through a small checked callback in all cases. Validate schema without a second thermodynamic decode. Avoid double-counting `evaluations`: choose the existing observe-based accounting consistently, rather than both incrementing observe and adding run.evaluations. Preserve pending common-time replan handling and resource/cancellation guards.
- Terminal components use exactly the existing `interval=Fraction(endpoint)-Fraction(start)` (not requested tau). For each cell/key compute exact integral interval*F(rate), round once to its represented J value, and save `F(represented)-exact` in component_quadrature_roundoff_j. Build StepLedger with these components. Its component_sum_residual_j compares to the already-authoritative terminal cell_work_j; never replace total power or endpoint thermal energy.
- Add trailing optional `DepletionResult.cumulative_absolute_component_residual_j`. In `commit`, start from committed per-cell Fraction totals, add abs(step.component_sum_residual_j) for every ordinary/terminal accepted path panel, and reject if any prefix exceeds the original energy_absolute_tolerance_j. Check the entire speculative path before committing any global trajectory, modes, corrections or component totals. Ordinary segment budget checks are useful but do not replace this cross-segment check.
- Defaults stay None throughout result/ledgers for old callers. Source schema lock includes None: once classified, every segment and dry mode must remain classified, including zero power. Event writeback moves only liquid/vapor inventory, adds no component work and no energy.

## Bounds and failure semantics

The residual budget is representation/decomposition error only. Per-component exact arithmetic error remains separately recorded; neither net U adaptivity nor event N/U/T/P refinement certifies the time integration error of large mutually cancelling component work. A future mechanical oracle must compare each component and refine time explicitly.

Original failed/unsupported/cancelled/resource-limit paths retain the same accepted global state; speculative event paths and their component records are discarded. Missing schema at a later stage is numerical contract failure. No EOS/domain exception may be swallowed as an absent mechanical component. Whole-path precommit rejection retains the old all-or-nothing event-path behavior, rather than partially accepting an event whose common-time comparison failed.

## Tests to write before implementation (no EOS first)

- Manufactured depletion adapter: constant evaporation with constant five-category powers, known event time and continued dry state. Independently sum terminal exact interval powers plus ordinary RK component integrals and reconstruct prefix total J.
- None baseline remains None through terminal, ordinary restart and final result.
- Schema change only after with_depleted_cells, only in a normal segment or only in a discarded refinement must fail without committing that speculative path.
- Two component residuals of opposite signs cannot cancel across ordinary/terminal/restart prefixes; cumulative absolute budget rejects the crossing path and preserves previously committed history.
- Terminal subnormal products and unequal represented times retain exact Fraction rounding evidence; terminal components use real endpoint interval, never tau or an endpoint elastic-energy difference.
- Cancel/resource-limit after accepted prior path preserves component fields and totals; failed refinement produces no extra committed work.
- Wrapper-only propagation tests must exercise real evaluate methods with controlled source-gated base fixtures or explicit reviewed manufactured instrumentation, without weakening production type guards. Assert same component keys/values and old body power with independently changed gas-face enthalpy and phase source, zero duplicated latent/body heat. Such tests are wiring checks, not a new source-derived mechanical law.

Heavy real wet EOS/integrated deforming-host validation remains separately scheduled; do not infer it from manufactured adapter tests. No candidate production code or copied test tree has been generated yet.
