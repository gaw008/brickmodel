from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
base=Path('/private/tmp/brick-source-study-record-v1/implementation')
files=['src/sludge_sandbox/source_study_record.py','src/sludge_sandbox/source_study_schema.py','src/sludge_sandbox/source_study_audit.py','src/sludge_sandbox/source_dry_transition.py','tests/sandbox/test_source_study_record.py']
checks={}
for name in ('boundary01','final02','original-pressure-fixed01','returned-failure-fixed01'):
 root=ET.parse(base/(name+'.xml')).getroot()
 suite=root if root.tag=='testsuite' else root.find('testsuite')
 checks[name]=dict(suite.attrib)
info={'status':'implementation_frozen_pending_final_independent_review_and_root_installation',
 'files':{p:{'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'bytes':Path(p).stat().st_size} for p in files},
 'actual_xml_results':checks,
 'command':'PYTHONPATH=src:tests/sandbox /private/tmp/brick-water-backend-probe/venv/bin/python -m pytest tests/sandbox/test_source_study_record.py -q',
 'final_test_collection':22,'final_full_22_run':'owned by root combined source/installed verification; not repeated here',
 'old_full_native_passive_audit':'native-final-audit02.json used pre-P-gate frozen 5f89a534 and complete original native record; no new physics',
 'preserved_reds':['api-red.log','shared-comparison-red.log','source_study_audit.before-dag-equality.py',
  'source_study_audit.before-original-pressure-gates.py','source_study_audit.before-returned-failure.py'],
 'scope':'Complete closed 96-class saved typed fields, content DAG, successful source observations, explicit unvalidated failed returns, saved exact arithmetic and declared associations. No live reconstruction, asset authentication, EOS hypothesis certification, material validation, or resume.'}
(base/'CORE_FREEZE.json').write_text(json.dumps(info,indent=2)+'\n')
