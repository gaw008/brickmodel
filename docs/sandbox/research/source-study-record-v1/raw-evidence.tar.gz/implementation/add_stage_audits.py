from pathlib import Path
p=Path('src/sludge_sandbox/source_study_audit.py');s=p.read_text()
pos=s.index('\ndef _pressure(')
new='''
def _proposal(node,memo,checks):
    from .source_approach import choose_positive_approach
    event=reify(node.event_policy,memo);trial=node.original_trial
    require(node.policy_binding==event_binding(event),'source_study_proposal_policy_binding')
    require(_same(node.effective_maximum_refinements,min(event.maximum_refinements,256) if event else None),
            'source_study_proposal_budget')
    if node.roots is not None:
        roots=reify(node.roots,memo)
        require(len(trial.captures)>=2 and roots.sample_bindings[:2]==tuple(c.binding for c in trial.captures[:2])
                and roots.start==trial.start and roots.upper==trial.end
                and roots.operator_identity==trial.operator_identity
                and roots.order.maximum_refinements==node.effective_maximum_refinements,
                'source_study_proposal_source_binding')
        wanted=choose_positive_approach(roots.order,safe_fraction=F(event.safe_inventory_fraction),
            minimum_step_s=F(trial.policy.minimum_step_s),maximum_step_s=F(trial.policy.maximum_step_s),
            horizon_s=trial.end.elapsed_since(trial.start))
        require(_same(reify(node.choice,memo),wanted),'source_study_proposal_choice')
        require(node.status==wanted.status and _same(node.end,
            trial.start.shifted(wanted.duration_s) if wanted.status=='positive_numerical_proposal' else None),
            'source_study_proposal_end')
    else:
        require(node.choice is None and node.end is None and node.status in (
            'missing_explicit_event_policy','stopped_seed_requires_explicit_restart',
            'seed_interval_crosses_program_knot','missing_actual_initial_midpoint'),
            'source_study_unexecuted_proposal')
    checks['proposal_source_and_choice_bindings']+=1


def _approach(node,memo,checks):
    proposal=node.proposal;trial=node.trial
    require(type(node.maximum_callbacks) is int and node.maximum_callbacks>0,'source_study_approach_budget')
    if trial is None:
        require(proposal.status!='positive_numerical_proposal' and node.status=='not_evaluated'
                and node.reason==proposal.status and node.comparison is None and node.pressure is None
                and node.new_evaluations==0,'source_study_approach_unexecuted')
    else:
        original=proposal.original_trial
        require(proposal.status=='positive_numerical_proposal'
                and _same((trial.initial,trial.start,trial.end,trial.policy),
                          (original.initial,original.start,proposal.end,original.policy))
                and trial.operator_identity==original.operator_identity and trial.energy_identity==original.energy_identity
                and trial.maximum_callbacks==node.maximum_callbacks and node.new_evaluations==len(trial.captures),
                'source_study_approach_trial_connection')
        if trial.status=='validated_positive_numerical_trial':
            require(node.status=='validated_positive_numerical_approach' and node.reason is None
                    and node.comparison is not None and node.pressure is not None
                    and _same(node.comparison.trial,trial) and _same(node.pressure.comparison,node.comparison)
                    and node.comparison.policy_binding==proposal.policy_binding,'source_study_approach_assessments')
        else:
            require(node.status==trial.status and node.reason==trial.reason
                    and node.comparison is None and node.pressure is None,'source_study_approach_failure')
    checks['approach_connections']+=1


def _refinement(node,memo,checks):
    prior=node.approach.trial;original=node.approach.proposal.original_trial;trial=node.shifted_trial
    require(node.approach.status=='validated_positive_numerical_approach'
            and _same((trial.initial,trial.start,trial.end,trial.policy),
                      (prior.reference.states[-1],prior.end,original.end,original.policy))
            and _same((trial.operator_identity,trial.energy_identity,trial.fixed_dry_mass_kg),
                      (original.operator_identity,original.energy_identity,original.fixed_dry_mass_kg))
            and _same(node.shifted_proposal.original_trial,trial)
            and node.shifted_proposal.policy_binding==node.approach.proposal.policy_binding
            and node.new_evaluations==len(trial.captures),'source_study_shifted_reference_connection')
    require(trial.start<original.start.shifted(node.approach.proposal.choice.selected_root.lower),
            'source_study_shifted_start_before_root')
    proposal=node.shifted_proposal
    if node.clock is not None:
        require(proposal.status=='positive_numerical_proposal' and node.status=='partitioned_surrogate_roots_compared'
                and node.reason is None and _same(node.clock.choices,(node.approach.proposal.choice,proposal.choice))
                and _same(node.clock.starts,(original.start,trial.start))
                and node.clock.time_absolute_s==F(proposal.event_policy.time_absolute_s),
                'source_study_root_clock_stage_binding')
    else:
        require(node.status=='root_comparison_not_available' and node.reason==(
            'partitioned_first_inventory_label_changed' if proposal.status=='positive_numerical_proposal' else proposal.status),
            'source_study_missing_clock_reason')
    checks['shifted_reference_connections']+=1


def _comparison(node,memo,checks):
    trial=node.trial;event=reify(node.event_policy,memo)
    require(trial.status=='validated_positive_numerical_trial' and node.policy_binding==event_binding(event),
            'source_study_comparison_trial_policy')
    first,last=trial.captures[2],trial.captures[-1]
    data=reify(node.differences,memo)
    require(_same((data.first.state,data.first.evaluation,data.second.state,data.second.evaluation),
                  tuple(reify(x,memo) for x in (first.state,first.evaluation,last.state,last.evaluation)))
            and _same(node.integration_discrepancy,trial.discrepancy),'source_study_endpoint_sample_binding')
    gates=tuple(x<=F(y) for x,y in zip(data.maxima,(event.amount_absolute_mol,event.energy_absolute_j,
        event.temperature_absolute_k,event.pressure_absolute_pa))) if event else (None,)*4
    status='missing_explicit_event_policy' if event is None else ('reported_endpoint_gates_satisfied'
        if all(gates) else 'endpoint_tolerance_not_certified')
    pgate='unresolved' if event is None or any(row[1] or row[5] for row in data.inverse_inputs) else (
        'within_tolerance' if gates[3] else 'not_certified')
    require(_same((node.gates,node.status,node.full_inverse_pressure_gate),(gates,status,pgate)),
            'source_study_reported_endpoint_gates')
    checks['reported_endpoint_associations']+=1


def _bound_pairs(pairs,captures,memo):
    require(len(pairs)==len(captures[0].evaluation.source_states),'source_study_pressure_pair_cells')
    bounds=[]
    for i,pair in enumerate(pairs):
        require(len(pair)==2,'source_study_pressure_pair_shape')
        for bound,capture in zip(pair,captures):
            require(_same(bound.state,capture.evaluation.source_states[i])
                    and _same(bound.inverse,capture.evaluation.source_evaluation.cells[i].inverse),
                    'source_study_pressure_observation_binding')
        a,b=pair
        bound=(abs(F(a.inverse.point.pressure_pa)-F(b.inverse.point.pressure_pa))
               +a.continuation.radius_pa+b.continuation.radius_pa
               if a.continuation.status==b.continuation.status=='conditional_pressure_enclosure' else None)
        bounds.append(bound)
    return tuple(bounds)


def _trial_pressure(node,memo,checks):
    comparison=node.comparison;trial=comparison.trial
    bounds=_bound_pairs(node.endpoint_bounds,(trial.captures[2],trial.captures[-1]),memo)
    maximum=max(bounds) if all(v is not None for v in bounds) else None
    event=comparison.event_policy
    gate=maximum<=F(event.pressure_absolute_pa) if maximum is not None and event is not None else None
    require(_same((node.conditional_cell_bounds_pa,node.maximum_conditional_bound_pa,node.conditional_gate),
                  (bounds,maximum,gate)),'source_study_trial_pressure_gates')
    checks['trial_pressure_associations']+=1


def _transition_balances(node,memo,checks):
    from .source_dry_transition import _audit_balance_fields
    expected=[]
    seeds=(node.refinement.approach.proposal.original_trial,node.refinement.shifted_trial)
    for index,(candidate,seed) in enumerate(zip(node.candidates,seeds)):
        require(_same(candidate.seed,seed)
                and candidate.event_policy_binding==node.refinement.approach.proposal.policy_binding
                and _same(candidate.terminal.prior_clock,node.refinement.clock)
                and type(candidate.terminal.root_index) is int and candidate.terminal.root_index==index,
                'source_study_transition_original_seed_and_prior_clock')
        ordinary=(node.refinement.approach.trial,) if index else ()
        first=ordinary[0] if ordinary else seed
        previous,start=first.initial,first.start
        for trial in ordinary:
            require(trial.status=='validated_positive_numerical_trial'
                    and _same((trial.initial,trial.start,trial.policy),(previous,start,seed.policy)),
                    'source_study_transition_wet_connection')
            previous,start=trial.reference.states[-1],trial.reference.times_s[-1]
        require(_same((seed.initial,seed.start),(previous,start)),'source_study_transition_terminal_connection')
        masses=tuple(g.molar_masses_kg_mol for g in reify(candidate.captures[0].evaluation,memo).source_evaluation.gas_states)
        terminal=candidate.terminal
        expected.append(_audit_balance_fields(reify(first.initial,memo),first.start,reify(seed.policy,memo),masses,
            wet_references=tuple(reify(t.reference,memo) for t in ordinary),terminal_prefix=reify(terminal.prefix,memo),
            corrected_state=reify(terminal.corrected_state,memo),selected_cell_index=terminal.selected_cell_index,
            signed_storage_roundoff_mol=terminal.totals.signed_storage_roundoff_mol,
            dry_reference=reify(candidate.reference,memo)))
    require(_same(reify(node.balance_paths,memo),tuple(expected)),'source_study_cumulative_all_cell_balances')
    checks['complete_transition_balance_rows']+=sum(map(len,expected))

'''
s=s[:pos]+new+s[pos:]
s=s.replace("        elif name=='SourceDryTransition':_transition(node,memo,checks)","        elif name=='SourceDryTransition':\n            _transition(node,memo,checks);_transition_balances(node,memo,checks)")
s=s.replace("        elif name in ('SourceApproachProposal','SourceEndpointComparison'):\n            require(node.policy_binding==event_binding(reify(node.event_policy,memo)),'source_study_nested_event_policy_binding')", "        elif name=='SourceApproachProposal':_proposal(node,memo,checks)\n        elif name=='SourceApproachResult':_approach(node,memo,checks)\n        elif name=='SourceRootRefinement':_refinement(node,memo,checks)\n        elif name=='SourceEndpointComparison':_comparison(node,memo,checks)\n        elif name=='SourceTrialPressure':_trial_pressure(node,memo,checks)")
s=s.replace("'available_event_endpoint_and_gate_associations'),", "'available_event_endpoint_and_gate_associations','complete_transition_local_and_global_cumulative_balances',\n                  'pressure_input_associations_and_saved_joint_margin_sums'),")
p.write_text(s)
