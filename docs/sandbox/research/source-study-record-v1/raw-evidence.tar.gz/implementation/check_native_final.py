import json,time,hashlib
from pathlib import Path
from sludge_sandbox.source_study_record import decode_source_study,_graph
from sludge_sandbox.exact_record import canonical
from sludge_sandbox.source_study_schema import CLASSES
start=time.monotonic()
p=Path('/private/tmp/brick-source-study-record-v1/implementation/native-before-balance-extraction.json')
r=decode_source_study(p.read_bytes())
nodes,root=_graph(r.roots['transition'].balance_paths)
balances=canonical({'nodes':nodes,'root':root})
Path('/private/tmp/brick-source-study-record-v1/implementation/original-native-balance-goldens.json').write_bytes(balances)
print(json.dumps({'seconds':time.monotonic()-start,'canonical_bytes':len(r.canonical_bytes),'nodes':len(json.loads(r.canonical_bytes)['nodes']),'captures':len(r.captures),'observations':len(r.observations),'registry_classes':len(CLASSES),'checks':dict(r.audit['checks']),'balance_sha256':hashlib.sha256(balances).hexdigest(),'balance_bytes':len(balances),'scope':'Originally saved N3 complete balance rows match extracted pure helper. No new physics.'},indent=2))
