from pathlib import Path
p=Path('src/sludge_sandbox/source_study_audit.py');s=p.read_text();target="    ledger=prefix.ledger\n    terms=(float(ledger.face_species_mol[cell,0])"
addition='''    from .source_terminal import _clock_from_order
    from .exact_affine_depletion import ExactAffineSamples
    panel=reify(node.panel,memo);roots=reify(node.root_order,memo);seed=node.seed
    require(event.terminal_method=='affine_midpoint' and event.ordered_event_policy is None
            and event.nested_approach is None and event.pressure_comparison is None
            and seed.status not in ('cancelled','resource_limit') and len(seed.captures)>=2,
            'source_study_terminal_original_policy_and_seed')
    require(roots.order.maximum_refinements==min(event.maximum_refinements,256)
            and _same(roots.panel,panel) and _same(prefix.panel,panel)
            and roots.order.complete and roots.order.status=='ordered'
            and roots.order.earliest_labels==(('liquid',cell,0),)
            and panel.sample_bindings[:2]==tuple(c.binding for c in seed.captures[:2])
            and panel.first.evaluation.time==seed.start and panel.upper==seed.end
            and all(p.initial>0 for p in panel.inventories),'source_study_terminal_selected_source_root')
    first,middle=(reify(c,memo) for c in seed.captures[:2])
    require((first.role,middle.role)==('initial','euler_midpoint') and all(
        c.evaluation is not None and c.binding is not None and c.failure is None for c in (first,middle)),
        'source_study_terminal_samples')
    rates=[c.evaluation.rates for c in (first,middle)]
    evaporation=[c.evaluation.source_evaluation.cells[cell].phase.phase_water_mol_s for c in (first,middle)]
    h=seed.end.elapsed_since(seed.start);hm=middle.time.elapsed_since(first.time)
    e0,em=map(F,evaporation)
    require(min(e0,e0+(em-e0)*h/hm)>0,'source_study_terminal_gross_evaporation')
    samples=ExactAffineSamples(first.time,middle.time,seed.end,float(reify(seed.initial,memo).amounts_mol[cell,0]),
        *[tuple((float(r.face_species_mol_s[cell,0]),-float(r.face_species_mol_s[cell+1,0]),
                 float(r.reaction_species_mol_s[cell,0]))) for r in rates],
        *evaporation,('source-operator:'+repr(seed.operator_identity),))
    selected=next(r for r in roots.order.roots if
        (r.polynomial.family,r.polynomial.cell,r.polynomial.index)==('liquid',cell,0))
    spent=roots.order.refinement_level
    if node.prior_clock is None:
        require(node.root_index is None,'source_study_terminal_root_index_without_prior')
    else:
        prior=reify(node.prior_clock,memo)
        require(type(node.root_index) is int and node.root_index in (0,1),'source_study_terminal_root_index')
        choice=prior.choices[node.root_index]
        require(prior.starts[node.root_index]==seed.start and prior.time_absolute_s==F(event.time_absolute_s)
                and _same(choice.order,roots.order)
                and _same((choice.safe_fraction,choice.minimum_step_s,choice.maximum_step_s,choice.horizon_s),
                          (F(event.safe_inventory_fraction),F(seed.policy.minimum_step_s),
                           F(seed.policy.maximum_step_s),h)),'source_study_terminal_prior_root_budget')
        selected=prior.refined_roots[node.root_index];spent=max(spent,selected.refinements)
    expected_clock,extra=_clock_from_order(samples,roots.order,event,selected,spent)
    require(_same((clock,node.reused_clock_rounds,node.additional_clock_rounds),(expected_clock,spent,extra))
            and middle.time<clock.lower and clock.upper.elapsed_since(seed.start)<=F(event.terminal_window_s)
            and all(p.minimum(clock.upper.elapsed_since(seed.start))[0]>0 for p in panel.inventories
                    if (p.family,p.cell,p.index)!=('liquid',cell,0)),
            'source_study_terminal_clock_or_other_inventory')
    ledger=prefix.ledger
    terms=(float(ledger.face_species_mol[cell,0])'''
assert target in s;s=s.replace(target,addition)
s=s.replace("        'full_pressure_producer_decomposition_without_live_storage','material_validation'", "        'full_pressure_producer_decomposition_without_live_storage','terminal_live_configuration_and_transport_law','material_validation'")
p.write_text(s)
