from pathlib import Path
p=Path('src/sludge_sandbox/source_dry_transition.py')
s=p.read_text(); start=s.index('def _audit_path(candidate, ordinary=()):'); end=s.index('\n@dataclass(frozen=True)\nclass SourceDryTransition:',start)
old=s[start:end]
body=old[old.index('    count=initial.amounts_mol.shape[0]'):]
body=body.replace("    masses=tuple(g.molar_masses_kg_mol for g in candidate.captures[0].evaluation.source_evaluation.gas_states)\n    policy=seed.policy\n",'')
a=body.index('    for trial in ordinary:');b=body.index('    pieces=',a)
body=body[:a]+"    for reference in wet_references:\n        for state,ledger in zip(reference.states[1:],reference.steps):\n            step(state,ledger,'wet_reference')\n"+body[b:]
body=body.replace('terminal.prefix','terminal_prefix').replace('terminal.corrected_state','corrected_state')
body=body.replace('terminal.selected_cell_index','selected_cell_index').replace('terminal.totals.signed_storage_roundoff_mol','signed_storage_roundoff_mol')
body=body.replace('candidate.reference.states','dry_reference.states').replace('candidate.reference.steps','dry_reference.steps')
helper='''def _audit_balance_fields(initial, start, policy, masses, *, wet_references,
        terminal_prefix, corrected_state, selected_cell_index,
        signed_storage_roundoff_mol, dry_reference):
    """Pure balances for already validated saved states and ledger fields.

    No adapter or provider is accepted. Callers validate reference connections
    and complete records before supplying this numerical projection. Original
    local and global absolute budgets are each retained without a grid factor.
    """
    previous,previous_time=initial,start
'''+body
wrapper='''def _audit_path(candidate, ordinary=()):
    """Validate live path connections, then share the exact saved-field audit."""
    seed=candidate.seed; terminal=candidate.terminal
    initial=ordinary[0].initial if ordinary else seed.initial
    start=ordinary[0].start if ordinary else seed.start
    policy=seed.policy

    def references():
        previous,previous_time=initial,start
        for trial in ordinary:
            trial.check()
            _require(trial.status=='validated_positive_numerical_trial'
                     and _same((trial.initial,trial.start,trial.policy),(previous,previous_time,policy)),
                     'source_transition_ordinary_path_connection_changed')
            yield trial.reference
            if trial.reference.steps:
                previous=trial.reference.states[-1]
                previous_time=trial.reference.steps[-1].end_s
        _require(_same((seed.initial,seed.start),(previous,previous_time)),
                 'source_transition_terminal_connection_changed')

    masses=tuple(g.molar_masses_kg_mol for g in candidate.captures[0].evaluation.source_evaluation.gas_states)
    return _audit_balance_fields(initial,start,policy,masses,wet_references=references(),
        terminal_prefix=terminal.prefix,corrected_state=terminal.corrected_state,
        selected_cell_index=terminal.selected_cell_index,
        signed_storage_roundoff_mol=terminal.totals.signed_storage_roundoff_mol,
        dry_reference=candidate.reference)


'''
p.write_text(s[:start]+wrapper+helper+s[end:])
