# Installed passive checker review

Scope: root/check_native_record.py and PASSIVE_RUN_PLAN.md. The full checker has not been executed by this reviewer. No installed/source core, native input, model or EOS was executed for this checker review.

[MEDIUM — fixed] CLI diagnostic stdout could be lost when import/inspect returns a nonzero code. Initially each inline block asserted the return code before saving StringIO. Root replaced both paths with invoke_cli, which saves stdout in finally before checking the code; the outer failure record now includes current stage and counts. Exact AST-helper control probes cover return=1 and a thrown TimeoutError, both preserving the stdout and original failure, in 0.000598458 s. Fixed runner SHA: 2449ef04c904655887f1a847a5f97c3ede1b3d3fd1e48245a02632310a55f0c4. The first reviewer probe targeted the old inline AST after Root had already changed it, and stopped at AST selection (StopIteration); this harness failure and its scope are explicitly retained. It was not a checker/native/core failure.

[MEDIUM — pending] The 32 indexed public observation records are checked only for operator_identity equality, while the independent full-field comparison examines record.captures. All wet captures can share an operator identity despite different states/times. A reordered/duplicated public observations tuple could therefore evade the indexed-observation loop. To substantiate complete original-position correspondence, independently compare original packed_input to observation.sample.state, original evaluation to observation.sample.evaluation, and original phase to sample.role for each index; permit only the exact observed passive dataclass type/fields in the independent comparator. Do not use core _legacy for this comparison. The plan should otherwise narrow its claim to count/identity checks.

Remaining static review: fixed input SHA; exact source/decoded scalar type equality, binary64 hex equality, ndarray shape/bytes and read-only flag, exact Fraction/event-time values, full mapping key sets and sequence order, typed field sets with only six known omitted live fields represented explicitly as unavailable. Import/decode/query run under constructor/evaluation guards, installed package location is checked, and the caller must separately establish frozen source/install identity. Original pressure failure values are covered by the all-original-values comparison. The 180-second alarm, exclusive output directory/record publication, current stage and partial count retention are consistent with the stated passive acceptance scope. Mathematical audit claims are explicitly those of the core, not an independent EOS proof. Material/resume authority remain false.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 1 | pending |
| LOW | 0 | pass |

Verdict: PENDING — one indexed-observation coverage correction before final checker approval.
