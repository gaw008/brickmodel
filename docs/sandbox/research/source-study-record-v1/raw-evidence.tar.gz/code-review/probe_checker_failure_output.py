"""Execute only the copied CLI-output AST block with a failing fake CLI.

Does not import/run the checker, core, original dataset, models or EOS.
"""
import ast,hashlib,io,json,time
from contextlib import redirect_stdout
from pathlib import Path
p=Path('/private/tmp/brick-source-study-record-v1/code-review/runner-failure-red')
text=(p/'check_native_record.py').read_text();tree=ast.parse(text)
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
stack=next(n for n in run.body if isinstance(n,ast.With))
ix=next(i for i,n in enumerate(stack.body) if isinstance(n,ast.With) and isinstance(n.items[0].context_expr,ast.Call) and getattr(n.items[0].context_expr.func,'id',None)=='redirect_stdout')
# The real redirect/assert followed by JSON parse and intended write.
block=ast.Module(body=stack.body[ix:ix+3],type_ignores=[])
stream=io.StringIO()
message={'status':'failed','error_type':'ValueError','reason':'retained_core_failure_probe'}
def main(argv):
    print(json.dumps(message))
    return 1
namespace=dict(redirect_stdout=redirect_stdout,stream=stream,main=main,source=Path('never-read'),target=p/'never-created',output=p,json=json)
t=time.perf_counter()
try:exec(compile(block,'copied-runner-output-block','exec'),namespace)
except Exception as exc:failure={'type':type(exc).__name__,'message':str(exc)}
assert failure=={'type':'AssertionError','message':''}
assert not (p/'cli-import.json').exists()
result={'status':'confirmed_failure_stdout_not_persisted','runner_sha256':hashlib.sha256(text.encode()).hexdigest(),'executed':'Only original three-statement CLI output block with fake failed CLI; entire run() not called.','in_memory_cli_failure':json.loads(stream.getvalue()),'outer_failure_record_would_be':failure,'cli_failure_file_exists':False,'elapsed_s':time.perf_counter()-t,'model_EOS_core_calls':0}
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
