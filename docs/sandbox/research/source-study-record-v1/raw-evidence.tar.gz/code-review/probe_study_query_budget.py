from pathlib import Path
import json,time,hashlib
from sludge_sandbox.source_study_record import encode_source_study,decode_source_study
from sludge_sandbox.source_study_schema import SourceStudyFailure
import sludge_sandbox.source_study_service as service
p=Path('/private/tmp/brick-source-study-record-v1/code-review/service-query-budget-red')
started=time.perf_counter()
value='x'*4096
for _ in range(10):value=(value,value)
raw=encode_source_study({'failure':SourceStudyFailure('builtins.ValueError','display only test','inspection',{'data':value})},contexts=())
record=decode_source_study(raw)
(p/'record.json').write_bytes(raw)
original_plain=service._plain
original_dump=service.json.dumps
calls=0
serialized=[]
def counted_plain(v):
    global calls
    calls+=1
    return original_plain(v)
def counted_dump(*args,**kwargs):
    text=original_dump(*args,**kwargs)
    serialized.append(len(text.encode()))
    return text
service._plain=counted_plain
service.json.dumps=counted_dump
try:
    try:service.query_source_study(record,'failure')
    except Exception as exc:failure={'type':type(exc).__name__,'message':str(exc)}
finally:
    service._plain=original_plain
    service.json.dumps=original_dump
result={'status':'confirmed_late_limit','scope':'Supported passive failure record with small shared metadata DAG; no numerical model or EOS.','record_bytes':len(raw),'unique_DAG_nodes':len(json.loads(raw)['nodes']),'configured_query_bytes':service.MAX_QUERY_BYTES,'expanded_plain_visits_before_rejection':calls,'serialized_byte_lengths_before_limit':serialized,'exception':failure,'elapsed_s':time.perf_counter()-started,'service_sha256':hashlib.sha256(Path(service.__file__).read_bytes()).hexdigest()}
assert max(serialized)>service.MAX_QUERY_BYTES and calls>2000,result
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
