"""Prepare rehashed mutation inputs only. Never imports the model or decoder.

Input is an existing canonical DAG; outputs are explicitly prospective, not REDs.
Use final frozen baseline later before executing a bounded admission check.
"""
from pathlib import Path
import argparse,copy,hashlib,json

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def rebuild(original, changes):
    nodes={};memo={};active=set()
    def token(value):
        if set(value)=={'value'}:return copy.deepcopy(value)
        old=value['ref']
        if old in memo:return {'ref':memo[old]}
        if old in active:raise ValueError('unexpected source graph cycle')
        active.add(old)
        body=copy.deepcopy(changes.get(old,original['nodes'][old]))
        if 'fields' in body:body['fields']={k:token(v) for k,v in body['fields'].items()}
        elif 'mapping' in body:body['mapping']={k:token(v) for k,v in body['mapping'].items()}
        elif 'tuple' in body:body['tuple']=[token(v) for v in body['tuple']]
        elif 'array' not in body:raise ValueError('unexpected node kind')
        key=hashlib.sha256(canonical(body)).hexdigest()
        nodes[key]=body;memo[old]=key;active.remove(old)
        return {'ref':key}
    root=token(original['root'])
    return dict(original,nodes=nodes,root=root)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('input',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    raw=args.input.read_bytes();original=json.loads(raw)
    assert all(hashlib.sha256(canonical(body)).hexdigest()==key for key,body in original['nodes'].items())
    assert canonical(rebuild(original,{}))==raw, 'source baseline is not the same canonical complete graph'
    args.output.mkdir(exist_ok=False)
    def first(kind):
        return next((key,body) for key,body in sorted(original['nodes'].items()) if body.get('class','').rsplit('.',1)[-1]==kind)
    planned=[]
    for case,kind,field in (
        ('terminal_shared_clock_rounds','SourceTerminal','additional_clock_rounds'),
        ('shifted_actual_evaluation_count','SourceRootRefinement','new_evaluations'),
    ):
        key,body=first(kind);changed=copy.deepcopy(body)
        changed['fields'][field]['value']+=1
        planned.append((case,{key:changed},kind+'.'+field,'Reject inconsistent preserved counter against underlying retained computation.'))
    key,body=first('SourceDryTransition')
    balance_ref=body['fields']['balance_paths']['ref']
    planned.append(('missing_cumulative_balance_rows',{balance_ref:{'tuple':[]}},'SourceDryTransition.balance_paths','Reject removed complete cumulative path balance evidence while transition acceptance is retained.'))
    gate_ref=body['fields']['cell_conditional_pressure_gates']['ref']
    gate_body=original['nodes'][gate_ref]
    first_row_ref=gate_body['tuple'][0]['ref']
    changed=copy.deepcopy(original['nodes'][first_row_ref])
    assert any(v=={'value':False} for v in changed['tuple'])
    changed['tuple']=[{'value':True} for _ in changed['tuple']]
    planned.append(('original_pressure_failure_relabelled',{first_row_ref:changed},'SourceDryTransition.cell_conditional_pressure_gates','Reject old P failure relabelled as pass even though selected shared strategy may pass.'))
    output=[]
    for name,changes,target,expectation in planned:
        transformed=canonical(rebuild(original,changes))
        path=args.output/(name+'.json');path.write_bytes(transformed)
        output.append({'name':name,'target':target,'expected':expectation,'input_bytes':len(transformed),'sha256':hashlib.sha256(transformed).hexdigest(),'admission_executed':False})
    result={'status':'prospective_not_executed','source_path':str(args.input),'source_sha256':hashlib.sha256(raw).hexdigest(),'cases':output,'model_EOS_calls':0,'decoder_calls':0,'preparation':'Each mutation updates all referencing ancestors, recomputes every changed SHA and retains only reachable nodes. Baseline rebuild equals original bytes.'}
    (args.output/'MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'cases':len(output),'source_sha256':result['source_sha256']}))

if __name__=='__main__':main()
