from pathlib import Path
import hashlib,json,time
from sludge_sandbox.source_study_service import import_source_study,inspect_source_study
p=Path('/private/tmp/brick-source-study-record-v1/code-review');out=p/'service-failure-contract-fixed'
raw=json.loads((p/'core-returned-failure/input.json').read_bytes())
results=[];t=time.perf_counter()
for key,value in (('exception_type','IntegrationError'),('failure','')):
    data=json.loads(json.dumps(raw));c=data['captures'][0]
    for name in ('failure','failure_kind','exception','exception_type'):c.pop(name,None)
    c[key]=value
    source=out/(key+'-source.json');record=out/(key+'-record.json')
    source.write_text(json.dumps(data))
    imported=import_source_study(source,record)
    result=inspect_source_study(record,capture_index=0)
    assert imported['failed_capture_indices']==result['failed_capture_indices']==[0]
    assert result['unreturned_capture_indices']==[] and result['selected_capture']['observation'] is None
    assert result['selected_capture'][key]==value
    assert result['selected_capture']['recorded_return_path']=='captures/0/evaluation'
    results.append({'key':key,'value':value,'failed_indices':[0],'unreturned_indices':[],'observation':None})
repo=Path('/Users/wanggaoying/Desktop/brickmodel-github')
files=['src/sludge_sandbox/'+n for n in ('source_study_record.py','source_study_schema.py','source_study_audit.py','source_dry_transition.py','source_study_service.py','source_record_io.py','source_observation_service.py','cli.py')]+['tests/sandbox/test_source_study_record.py','tests/sandbox/test_source_study_cli.py']
result={'status':'approved','cases':results,'elapsed_s':time.perf_counter()-t,'sha256':{n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in files},'model_EOS_calls':0}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
