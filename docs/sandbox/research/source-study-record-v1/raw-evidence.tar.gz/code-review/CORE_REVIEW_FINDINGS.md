# Core review findings and bounded evidence

Production, tests and original input records remain read-only. No new model/EOS or manufactured physical fixture was run by the reviewer. All graph variants preserve the full original record except the named mutation, recompute content hashes through every ancestor and remove unreachable nodes. Thus rejection is not merely a checksum test.

[HIGH — closed on b97efb53...] Original pressure failures could be relabelled as passed
File: src/sludge_sandbox/source_study_audit.py, _transition.
Initial audit SHA: 5f89a534df056062c6600d0554799e872dd6f1c979c65d9b2a8f17ea793da8b4.
The complete actual native baseline was accepted. A fully rehashed variant changing original cell_conditional_pressure_gates from False to True was also accepted, with original pressure bounds and selected conditional event strategy still present. Existing arithmetic checked bounds and selected gates but omitted the original conditional gate matrix/top aggregate and strategy label binding.
Evidence: core-four-frozen/RESULT.json and prospective-core-mutations/original_pressure_failure_relabelled.json (SHA 2909836f910ce9d2065ac4ea768bfaacca307ce6991aba0d126552b3375949ee).
Fix: Recompute the original per-cell and aggregate conditional gates/bounds and bind the pressure strategy to actual declarations/selection. Independent recheck on b97efb53b99d3b360d8e2a563a8179a754e849bd06c26b5007e47c8791471974 retained acceptance of the original baseline, with its complete 2×3 old conditional gate matrix False, and rejected the same mutation with source_study_original_conditional_pressure_gates. Evidence: core-pressure-gates-fixed/RESULT.json (4.503072459 + 3.734046292 s). The original failure input/result was not overwritten.

[HIGH — pending] Known finite returned-validation failures cannot be archived as failed observations
File: src/sludge_sandbox/source_study_audit.py, audit_study top capture return branch.
The runtime capture helper records evaluation before validating it, and retains that returned evaluation when validation fails (binding=None plus failure fields). The study importer instead treats every non-None evaluation as a successful observation requiring cross-time/source admission. A declared failed capture whose known-type, finite returned evaluation has an incorrect time is rejected at source_study_capture_return_binding, rather than preserving the original failed return with observations[index]=None.
Evidence: core-returned-failure/input.json and RESULT.json; 0.037736709 s. This is a deliberately constructed failure envelope around an archived observation, changing only returned time and explicit failure metadata. It is not a claim that the original experiment or EOS produced this failure. Root has confirmed that returned-failure preservation is within the intended stage scope and requested a failure-only branch; the author is implementing it. The final recheck will require both acceptance/preservation of this explicitly failed return and continued rejection of the same wrong time without failure metadata.

Other executed frozen checks: original canonical baseline accepted; changed terminal additional clock rounds, changed shifted actual evaluation count, and missing cumulative balance rows were each rejected by the corresponding numerical/association checks. Total first batch: five passive decodes, 19.360278750 s, zero guarded constructor/evaluation/state_tp calls. Their rejected cases were not rerun after the unrelated pressure-gate fix.

Static review of source_dry_transition.py extraction (SHA 1992d111f2c7d4d843889e85ceee1c360ff4215d40e0abd402fea64d53d20ae1): numerical update expressions and per-cell/global budgets remain unchanged. The original wrapper retains trial.check() and inter-trial/seed connection guards; its generator resumes after each consumed reference, preserving validation order. The new _audit_balance_fields accepts explicit saved numerical fields and no adapter/provider. The passive audit validates its own stage connections before using the helper and compares all returned cumulative rows. No ArchivedTrialView or fake runtime .check method is introduced. Remaining whole-core approval is pending the returned-failure fix and final hashes.

## Review Summary

| Severity | Open | Closed |
|----------|------|--------|
| CRITICAL | 0 | 0 |
| HIGH | 1 | 1 |
| MEDIUM | 0 | 0 |
| LOW | 0 | 0 |

Verdict: WARNING — one explicitly scoped failure-preservation issue remains pending.
