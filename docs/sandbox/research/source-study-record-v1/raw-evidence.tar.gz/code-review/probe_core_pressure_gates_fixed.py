from pathlib import Path
import hashlib,json,time
from sludge_sandbox.source_study_record import decode_source_study
p=Path('/private/tmp/brick-source-study-record-v1/code-review');out=p/'core-pressure-gates-fixed'
source=Path('/Users/wanggaoying/Desktop/brickmodel-github/src/sludge_sandbox/source_study_audit.py')
sha=hashlib.sha256(source.read_bytes()).hexdigest()
assert sha=='b97efb53b99d3b360d8e2a563a8179a754e849bd06c26b5007e47c8791471974'
paths=[('baseline',Path('/private/tmp/brick-source-study-record-v1/implementation/native-third-record.json')),('original_pressure_failure_relabelled',p/'prospective-core-mutations/original_pressure_failure_relabelled.json')]
results=[];started=time.perf_counter()
for name,path in paths:
    raw=path.read_bytes();t=time.perf_counter()
    try:
        record=decode_source_study(raw)
        row={'case':name,'admitted':True,'cell_conditional_pressure_gates':record.roots['transition'].cell_conditional_pressure_gates,'numerical_event_accepted':record.roots['transition'].numerical_event_accepted}
    except Exception as exc:row={'case':name,'admitted':False,'exception_type':type(exc).__name__,'exception':str(exc)}
    row.update(input_sha256=hashlib.sha256(raw).hexdigest(),elapsed_s=time.perf_counter()-t);results.append(row)
    (out/'RESULT.json').write_text(json.dumps({'source_audit_sha256':sha,'results':results,'elapsed_s':time.perf_counter()-started},indent=2)+'\n')
    print(json.dumps(row),flush=True)
assert results[0]['admitted'] and not results[1]['admitted']
assert results[1]['exception']=='source_study_original_conditional_pressure_gates'
