"""Strict stdlib inventory of a saved source study; no record/model import."""
from pathlib import Path
from collections import Counter,defaultdict
from hashlib import sha256
import json,time
P=Path('/private/tmp/brick-source-wet-shared-pressure-v1/root/native01/native-result.json')
O=Path('/private/tmp/brick-source-study-record-v1/code-review')
start=time.monotonic();raw=P.read_bytes()
assert sha256(raw).hexdigest()=='6c55383e8d2063ed6c81f2126b40542ba44ee173fc1671b227573b908bfbfc53'
def unique(items):
    d={}
    for k,v in items:
        if k in d:raise ValueError('duplicate:'+k)
        d[k]=v
    return d
obj=json.loads(raw,object_pairs_hook=unique,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
stack=[(obj,0,'$')];nodes=depth=0;types=Counter();record_fields=defaultdict(set);first={};arrays=Counter();primitive_counts=Counter();max_int_bits=0;max_string_bytes=0;max_sequence=0
while stack:
    x,d,p=stack.pop();nodes+=1;depth=max(depth,d);primitive_counts[type(x).__name__]+=1
    if type(x) is dict:
        if set(x)=={'type','fields'} and type(x['type']) is str and type(x['fields']) is dict:
            name=x['type'];types[name]+=1;record_fields[name].add(tuple(sorted(x['fields'])));first.setdefault(name,p)
        if set(x)=={'dtype','shape','values'}:arrays[str((x['dtype'],x['shape']))]+=1
        stack.extend((v,d+1,p+'.'+k) for k,v in x.items())
    elif type(x) is list:
        max_sequence=max(max_sequence,len(x));stack.extend((v,d+1,p+'['+str(i)+']') for i,v in enumerate(x))
    elif type(x) is int:max_int_bits=max(max_int_bits,x.bit_length())
    elif type(x) is str:max_string_bytes=max(max_string_bytes,len(x.encode()))
compact=json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
result={'input':str(P),'sha256':sha256(raw).hexdigest(),'raw_bytes':len(raw),'compact_legacy_json_bytes':len(compact),'raw_value_nodes_including_container_values':nodes,'maximum_value_depth':depth,'longest_sequence':max_sequence,'largest_integer_bits':max_int_bits,'longest_string_utf8_bytes':max_string_bytes,'primitive_type_counts':dict(primitive_counts),'typed_record_instances':sum(types.values()),'typed_record_class_count':len(types),'classes':[{'type':k,'instances':types[k],'observed_field_sets':[list(f) for f in sorted(record_fields[k])],'first_path':first[k]} for k in sorted(types)],'arrays':dict(arrays),'top_level_keys':list(obj),'important_top_level_counts':{'captures':len(obj['captures']),'returned_candidates':len(obj['returned_candidates']),'wet_pair_items':len(obj['new_pressure_study']['wet_pairs']),'extra_requests':len(obj['new_pressure_study']['extra_requests'])},'elapsed_seconds':time.monotonic()-start,'scope':'Observed saved sample shape only, not an allowlist inferred to authorize arbitrary future payload or a full association audit.'}
(O/'NATIVE_INVENTORY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('classes','arrays','top_level_keys')},indent=2))
print('CLASSES',json.dumps(sorted(types),indent=2))
