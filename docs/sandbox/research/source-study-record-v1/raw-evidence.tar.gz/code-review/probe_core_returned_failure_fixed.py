"""Original failed return, unchanged wrong-return success control and CLI query."""
from pathlib import Path
from fractions import Fraction
import hashlib,json,time
from sludge_sandbox.source_study_record import import_saved_source_study
from sludge_sandbox.source_study_service import import_source_study,inspect_source_study
p=Path('/private/tmp/brick-source-study-record-v1/code-review');out=p/'core-returned-failure-fixed'
source=p/'core-returned-failure/input.json';raw=source.read_bytes();started=time.perf_counter()
r=import_saved_source_study(raw)
assert len(r.captures)==1 and r.observations==(None,)
assert r.captures[0]['evaluation'].time.seconds==Fraction(1)
assert r.captures[0]['time'].seconds==Fraction(0)
assert r.captures[0]['failure']=='saved post-return validation rejected wrong evaluation time'
assert r.audit['checks']['unvalidated_returned_top_captures']==1
r.check()
untagged=json.loads(raw)
for key in ('failure','failure_kind','exception','exception_type'):untagged['captures'][0].pop(key,None)
try:
    import_saved_source_study(json.dumps(untagged).encode())
    raise AssertionError('wrong-time unfailed observation admitted')
except ValueError as exc:unfailed_error=str(exc)
assert unfailed_error=='source_study_capture_return_binding'
import_source_study(source,out/'record.json')
summary=inspect_source_study(out/'record.json',capture_index=0,value_path='captures/0/evaluation/time/seconds')
assert summary['failed_capture_indices']==[0] and summary['unreturned_capture_indices']==[]
assert summary['selected_capture']['observation'] is None
assert summary['selected_capture']['recorded_return_path']=='captures/0/evaluation'
assert summary['selected_value']['value']=={'numerator':1,'denominator':1}
result={'status':'closed','original_input_sha256':hashlib.sha256(raw).hexdigest(),'canonical_sha256':r.sha256,'observations':[None],'retained_return_time':'1','retained_attempt_time':'0','unfailed_control_error':unfailed_error,'service_selected_value':summary['selected_value'],'recorded_return_path':summary['selected_capture']['recorded_return_path'],'elapsed_s':time.perf_counter()-started,'scope':'Only passive same-input import/check and original raw-return query; no model/EOS or physical fixture.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
