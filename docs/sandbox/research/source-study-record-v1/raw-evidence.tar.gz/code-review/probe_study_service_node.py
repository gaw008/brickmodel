from pathlib import Path
import hashlib, json, time
from sludge_sandbox.source_study_record import encode_source_study, decode_source_study
from sludge_sandbox.source_study_schema import SourceStudyFailure
from sludge_sandbox.source_study_service import query_source_study, inspect_source_study
p=Path('/private/tmp/brick-source-study-record-v1/code-review/service-interface-red')
t=time.perf_counter()
raw=encode_source_study({'failure':SourceStudyFailure('builtins.ValueError','retained actual failure text','comparison',{'detail':'retained detail'})},contexts=())
(p/'record.json').write_bytes(raw)
record=decode_source_study(raw)
result={'scope':'Actual supported passive failure record; no numerical model or EOS. Core is not yet frozen.','bytes':len(raw),'root_type':type(record.roots['failure']).__module__+'.'+type(record.roots['failure']).__name__}
try:result['query_result']=query_source_study(record,'failure/message')
except Exception as exc:result['query_exception']={'type':type(exc).__name__,'message':str(exc)}
result['stage_summary']=inspect_source_study(p/'record.json')['stages']
result['elapsed_s']=time.perf_counter()-t
result['service_sha256']=hashlib.sha256((p/'source_study_service.py').read_bytes()).hexdigest()
assert result.get('query_exception',{}).get('message')=='source_study_path_not_found:message',result
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
