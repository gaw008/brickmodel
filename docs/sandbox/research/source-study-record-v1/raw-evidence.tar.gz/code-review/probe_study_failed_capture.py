from pathlib import Path
import json,time
from test_source_study_record import minimal_saved_study
from sludge_sandbox.source_study_service import import_source_study,inspect_source_study
p=Path('/private/tmp/brick-source-study-record-v1/code-review/service-exception-capture-red')
t=time.perf_counter()
saved=json.loads(minimal_saved_study())
capture=saved['captures'][0]
capture['evaluation']=None
capture['exception']='ValueError: retained callback failure'
capture.pop('failure',None)
capture.pop('failure_kind',None)
source=p/'input.json'
source.write_text(json.dumps(saved))
import_source_study(source,p/'record.json')
summary=inspect_source_study(p/'record.json',capture_index=0)
result={'scope':'Constructed failure envelope around unchanged archived capture input; no model/EOS or fabricated returned observation.','failure_text':capture['exception'],'failed_capture_indices':summary['failed_capture_indices'],'unreturned_capture_indices':summary['unreturned_capture_indices'],'selected_capture':summary['selected_capture'],'elapsed_s':time.perf_counter()-t}
assert summary['failed_capture_indices']==[] and summary['unreturned_capture_indices']==[0]
assert 'exception' not in summary['selected_capture']
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('failed_capture_indices','unreturned_capture_indices','elapsed_s')}))
