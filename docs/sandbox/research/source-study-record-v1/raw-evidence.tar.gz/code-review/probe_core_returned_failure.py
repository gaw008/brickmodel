"""Construct a finite, known-type post-return validation failure; no model run."""
from pathlib import Path
import json,time
from test_source_study_record import minimal_saved_study
from sludge_sandbox.source_study_record import import_saved_source_study
p=Path('/private/tmp/brick-source-study-record-v1/code-review/core-returned-failure')
d=json.loads(minimal_saved_study());c=d['captures'][0]
c['evaluation']['fields']['time']['fields']['seconds']={'numerator':1,'denominator':1}
c['failure']='saved post-return validation rejected wrong evaluation time'
c['failure_kind']='IntegrationError'
d['status']='numerical_failure'
d['scope']='constructed validation-failure envelope; original saved observation changed only in returned time'
raw=json.dumps(d,allow_nan=False).encode();(p/'input.json').write_bytes(raw)
t=time.perf_counter()
try:
    r=import_saved_source_study(raw)
    result={'admitted':True,'observations_complete':[v is not None for v in r.observations]}
except Exception as exc:result={'admitted':False,'exception_type':type(exc).__name__,'exception':str(exc)}
result.update(elapsed_s=time.perf_counter()-t,scope=d['scope'],model_EOS_calls=0)
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
