# Initial service review — source-study-record-v1

Reviewed current root-owned source_study_service.py, CLI diff, source_observation_service.py extraction, source_record_io.py and test_source_study_cli.py. Core is still being completed; this is not a final codec approval. Production/tests remain untouched. Three bounded probes use actual supported encode/decode APIs, not fake physics objects; no EOS/model/native execution or full test suite was run.

[HIGH] Query and stage display do not recognize the codec's actual node type
File: src/sludge_sandbox/source_study_service.py:55 (also 39, 59, 94)
Issue: Core returns SourceStudyNode, while _values/_plain special-case only EvidenceNode. A canonical supported failure record (1,608 bytes) decodes successfully but querying failure/message raises source_study_path_not_found:message. Real stage fields are hidden beneath the generic dataclass kind/values wrapper. Existing navigation tests manufacture EvidenceNode and therefore do not exercise this contract.
Fix: Handle the actual passive node type explicitly and cover a real codec round trip in service tests; update the interface document's stale EvidenceNode claim.
Evidence: service-interface-red/RESULT.json; probe_study_service_node.py. Elapsed 0.001679208 s.

[HIGH] Query byte limit is checked after expanding and serializing a shared DAG
File: src/sludge_sandbox/source_study_service.py:82
Issue: A supported 12,000-byte canonical record with 16 unique nodes expands to 4,200,714 serialized bytes before the configured 1,048,576-byte limit rejects it. _plain recursively duplicates each DAG reference; greater depth amplifies work and memory exponentially despite the small input DAG. The bounded probe made 2,054 display visits; it did not attempt an unbounded stress case.
Fix: Enforce output expansion node/depth/string/array budgets before and during materialization, then retain a final exact output-size check. Apply the same safe conversion boundary to summaries which call _plain.
Evidence: service-query-budget-red/RESULT.json; probe_study_query_budget.py. Elapsed 0.014941500 s.

[MEDIUM] A supported exception-only failed capture is labelled unreturned and loses its error text in the summary
File: src/sludge_sandbox/source_study_service.py:99 (also 123)
Issue: The core accepts capture.exception as a saved failure field. With an unchanged archived input, no returned evaluation and exception='ValueError: retained callback failure', import succeeds but inspect reports failed_capture_indices=[] and unreturned_capture_indices=[0]; selected_capture omits exception. The error is preserved in the canonical record, so this is misleading classification/display, not record data loss.
Fix: Recognize and display the same supported failure fields as the core.
Evidence: service-exception-capture-red/RESULT.json; probe_study_failed_capture.py. Elapsed 0.038399541 s. The outer failure envelope is explicitly constructed for this test and not claimed as an actual model failure.

Reviewed service SHA: 76d363c71a9def6e9c6d94c5f903e9613b1c73ddec72bf44959020f4b5580169. Pre-fix service and CLI test copies are retained in service-interface-red/. The root has been notified and is preparing fixes.

Other inspected behavior: input files use O_NONBLOCK plus fstat regular-file and bounded reads; output publication uses exclusive hard linking of a fully written temporary file and cleanup; observation summary extraction preserves values without falsely claiming a separate observation file; CLI routes to the same service and catches ValueError/OSError as structured failures. No additional confirmed issue was found in those scoped diffs. Original I/O extraction review remains applicable.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 2 | warn |
| MEDIUM | 1 | info |
| LOW | 0 | pass |

Verdict: WARNING — resolve the two HIGH findings and recheck the three preserved probes before final service approval.
