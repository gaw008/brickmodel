"""Only run the exact final invoke_cli AST helper under two fake failure modes."""
import ast,hashlib,io,json,time
from contextlib import redirect_stdout
from pathlib import Path
p=Path('/private/tmp/brick-source-study-record-v1/code-review/runner-output-fixed')
source=Path('/private/tmp/brick-source-study-record-v1/root/check_native_record.py')
raw=source.read_bytes();tree=ast.parse(raw)
helper=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='invoke_cli')
block=ast.Module(body=[helper],type_ignores=[])
cases=[];t=time.perf_counter()
for mode in ('returns_nonzero','raises_timeout'):
    trace={'checks':{}}
    expected={'status':'failed','reason':mode}
    def main(arguments):
        print(json.dumps(expected))
        if mode=='raises_timeout':raise TimeoutError('retained callback interruption')
        return 1
    scope=dict(trace=trace,io=io,redirect_stdout=redirect_stdout,main=main,output=p,json=json)
    exec(compile(block,'actual-final-invoke-cli-helper','exec'),scope)
    try:scope['invoke_cli'](['fake_cli'],mode)
    except Exception as exc:failure={'type':type(exc).__name__,'message':str(exc)}
    assert json.loads((p/(mode+'.json')).read_text())==expected
    assert trace['stage']==mode
    if mode=='returns_nonzero':assert failure=={'type':'AssertionError','message':mode+': CLI returned 1'}
    else:assert failure=={'type':'TimeoutError','message':'retained callback interruption'}
    cases.append({'mode':mode,'stage':trace['stage'],'persisted_stdout':expected,'propagated_failure':failure})
result={'status':'passed','runner_sha256':hashlib.sha256(raw).hexdigest(),'elapsed_s':time.perf_counter()-t,'cases':cases,'scope':'Only AST-extracted exact invoke_cli helper; full checker run(), source core, native input, model and EOS not executed.'}
(p/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
