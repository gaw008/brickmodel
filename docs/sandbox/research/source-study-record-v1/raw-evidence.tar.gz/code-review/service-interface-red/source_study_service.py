"""File and query interface for complete passive source-study evidence."""
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from .exact_event_clock import ExactEventTime
from .exact_record import EvidenceNode
from .source_observation_service import describe_source_observation
from .source_record_io import publish_record_bytes, read_record_bytes


MAX_IMPORT_BYTES = 64 * 1024 * 1024
MAX_RECORD_BYTES = 64 * 1024 * 1024
MAX_QUERY_BYTES = 1024 * 1024


def _require(ok, reason):
    if not ok:
        raise ValueError(reason)


def _plain(value):
    """Display only values already admitted by the passive record decoder."""
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) is float:
        _require(math.isfinite(value), 'source_study_nonfinite_display')
        return value
    if type(value) is Fraction:
        return {'numerator': value.numerator, 'denominator': value.denominator}
    if type(value) is ExactEventTime:
        return value.to_record()
    if type(value) is EvidenceNode:
        return {'type': value.kind, 'fields': _plain(value.values)}
    if type(value) is np.ndarray:
        return {'dtype': str(value.dtype), 'shape': list(value.shape), 'values': value.tolist()}
    if isinstance(value, Mapping):
        _require(all(type(k) is str for k in value), 'source_study_display_keys')
        return {k: _plain(v) for k, v in value.items()}
    if type(value) is tuple:
        return [_plain(v) for v in value]
    if is_dataclass(value):
        return {'type': type(value).__module__ + '.' + type(value).__qualname__,
                'fields': {f.name: _plain(getattr(value, f.name)) for f in fields(value)}}
    raise ValueError('source_study_unsupported_display_value')


def _values(value):
    if type(value) is EvidenceNode:
        return value.values
    if isinstance(value, Mapping):
        return value
    if is_dataclass(value):
        return {f.name: getattr(value, f.name) for f in fields(value)}
    raise ValueError('source_study_path_requires_record_or_sequence')


def query_source_study(record, value_path):
    """Select a saved stage field, for example transition/cell_selected_pressure_gates."""
    _require(type(value_path) is str and 0 < len(value_path) <= 1024,
             'source_study_value_path')
    parts = value_path.split('/')
    _require(len(parts) <= 32 and all(parts), 'source_study_value_path')
    value = record.roots
    for part in parts:
        if type(value) is tuple:
            _require(part.isascii() and part.isdecimal() and len(part) <= 9,
                     'source_study_sequence_index')
            index = int(part)
            _require(0 <= index < len(value), 'source_study_sequence_index')
            value = value[index]
        else:
            values = _values(value)
            _require(part in values, 'source_study_path_not_found:' + part)
            value = values[part]
    result = _plain(value)
    size = len(json.dumps(result, ensure_ascii=False, allow_nan=False).encode())
    _require(size <= MAX_QUERY_BYTES, 'source_study_query_too_large_select_specific_field')
    return result


def _summary(record, path, raw, *, capture_index=None, cell_index=None, value_path=None):
    _require(capture_index is None or (type(capture_index) is int
             and 0 <= capture_index < len(record.captures)), 'source_study_capture_index')
    _require(cell_index is None or capture_index is not None,
             'source_study_cell_requires_capture_index')
    stages = {}
    for name, value in record.roots.items():
        content = _values(value)
        stages[name] = {key: _plain(content[key]) for key in
            ('status', 'reason', 'qualification', 'numerical_event_accepted', 'material_qualified')
            if key in content}
    failed = [i for i, capture in enumerate(record.captures)
              if capture.get('failure') is not None or capture.get('failure_kind') is not None]
    result = {
        'status': 'source_study_record_valid',
        'record_path': str(Path(path).resolve()),
        'record_sha256': record.sha256,
        'file_sha256': hashlib.sha256(raw).hexdigest(),
        'file_is_canonical': raw == record.canonical_bytes,
        'provenance': dict(record.provenance),
        'reported_status': record.metadata.get('status'),
        'stages': stages,
        'capture_count': len(record.captures),
        'complete_observation_count': sum(value is not None for value in record.observations),
        'failed_capture_indices': failed,
        'unreturned_capture_indices': [i for i, value in enumerate(record.observations)
                                       if value is None and i not in failed],
        'audit': _plain(record.audit),
        'material_qualified': False,
        'resume_authorized': False,
        'source_assets_verified': False,
        'physical_run_reexecuted': False,
    }
    if capture_index is not None:
        capture = record.captures[capture_index]
        selected = {key: _plain(capture[key]) for key in
                    ('ordinal', 'phase', 'role', 'time', 'failure', 'failure_kind', 'interface_modes')
                    if key in capture}
        selected['capture_index'] = capture_index
        observation = record.observations[capture_index]
        if observation is None:
            _require(cell_index is None, 'source_study_capture_has_no_complete_cell_observation')
            selected['observation'] = None
            selected['recorded_input'] = _plain(capture.get('packed_input', capture.get('state')))
        else:
            selected['observation'] = describe_source_observation(observation, cell_index=cell_index)
        result['selected_capture'] = selected
    if value_path is not None:
        result['selected_value'] = {'path': value_path, 'value': query_source_study(record, value_path)}
    return result


def inspect_source_study(path, *, capture_index=None, cell_index=None, value_path=None):
    from .source_study_record import decode_source_study
    raw = read_record_bytes(path, MAX_RECORD_BYTES, size_reason='source_study_file_limit',
                            regular_reason='source_study_regular_file_required')
    record = decode_source_study(raw)
    return _summary(record, path, raw, capture_index=capture_index,
                    cell_index=cell_index, value_path=value_path)


def import_source_study(source, output, *, source_format='source_multicell_native_v1'):
    from .source_study_record import import_saved_source_study
    raw = read_record_bytes(source, MAX_IMPORT_BYTES, size_reason='source_study_import_file_limit',
                            regular_reason='source_study_regular_file_required')
    record = import_saved_source_study(raw, source_format=source_format, provenance={
        'input_path': str(Path(source).resolve()),
        'input_sha256': hashlib.sha256(raw).hexdigest(),
        'input_format': source_format,
    })
    result = _summary(record, output, record.canonical_bytes)
    publish_record_bytes(output, record.canonical_bytes, temporary_prefix='.source-study-')
    return result
