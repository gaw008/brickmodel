"""Independent offline table/coordinate audit. Does not run digitize_tg.py."""
from pathlib import Path
from fractions import Fraction
import csv, hashlib, itertools, json, math, time

started = time.perf_counter()
root = Path('/Users/wanggaoying/Desktop/brickmodel-github')
assets = Path('/private/tmp/brick-source-study-record-v1/material')
out = Path('/private/tmp/brick-source-study-record-v1/code-review')
record = json.loads((assets / 'tg-observations.json').read_text())
manifest = json.loads((assets / 'DIGITIZATION_MANIFEST.json').read_text())
checks = []
def require(label, condition):
    checks.append(label)
    if not condition:
        raise AssertionError(label)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def ratio(value):
    if isinstance(value, dict):
        return Fraction(value['numerator'], value['denominator'])
    return Fraction(value)
def value_at(pixel, calibration):
    lo, hi, val_lo, val_hi = calibration
    return ((pixel - lo) * val_hi + (hi - pixel) * val_lo) / (hi - lo)
def bounds(pixel, calibration, residual):
    lo, hi, val_lo, val_hi = calibration
    points = [value_at(ratio(pixel) + p, (lo + a, hi + b, val_lo, val_hi))
              for p, a, b in itertools.product((-2, 2), (-1, 1), (-1, 1))]
    return min(points) - residual, max(points) + residual

audit_hashes = {}
for name, expected in manifest.items():
    path = root / expected['path'] if name == 'linked_figure4' else assets / name
    actual = {'sha256': sha(path), 'bytes': path.stat().st_size}
    audit_hashes[name] = actual
    require('hash:' + name, actual['sha256'] == expected['sha256'])
    if 'bytes' in expected:
        require('bytes:' + name, actual['bytes'] == expected['bytes'])
source = root / 'runs/sandbox/source-cache/areias2025-20260907'
require('original PDF hash', sha(source / 'minerals-15-00879.pdf') == record['original_pdf_sha256'])
require('read image hash', sha(source / 'page-08-figure3.png') == record['read_image_sha256'])
require('source scope', record['figure'] == 3 and record['pdf_page_one_based'] == 8 and record['source_doi'] == '10.3390/min15080879')
require('not qualified or fitted', record['runtime_material_qualified'] is False and record['kinetics_fitted'] is False)
require('coordinate and error conventions', record['read_image_size'] == [990, 1400] and record['point_pixel_error'] == 2 and record['axis_endpoint_pixel_error'] == 1 and record['coordinate_origin'] == 'top-left; x right,y down')
rows = record['rows']
csv_rows = list(csv.DictReader((assets / 'tg-observations.csv').open()))
require('CSV row count and exact contents', len(csv_rows) == len(rows) and all(c == {k: '' if v is None else str(v) for k, v in r.items()} for c, r in zip(csv_rows, rows)))
require('44 unique ordered targets', [(r['panel'], r['target_temperature_c']) for r in rows] == [(p, t) for p in ('A', 'B') for t in range(50, 1101, 50)])
require('35 readable, 9 unknown', sum(r['status'] == 'readable' for r in rows) == 35 and sum(r['status'] == 'unknown' for r in rows) == 9)
require('exact unknown target set', [(r['panel'], r['target_temperature_c']) for r in rows if r['status'] == 'unknown'] == [('A', 50), ('A', 250), ('A', 400), ('A', 600), ('A', 1100), ('B', 200), ('B', 400), ('B', 600), ('B', 1100)])
calibrations = {}
for panel, original in record['calibration'].items():
    c = {axis: tuple(map(ratio, original[axis])) for axis in ('x', 'y')}
    residuals = {axis: max(abs(value_at(ratio(p), c[axis]) - ratio(v)) for p, v in original['ticks_' + axis]) for axis in ('x', 'y')}
    calibrations[panel] = {'residuals': {axis: {'exact': str(v), 'float': float(v)} for axis, v in residuals.items()}}
    require(panel + ': axis directions', c['x'][0] < c['x'][1] and c['x'][2] < c['x'][3] and c['y'][0] < c['y'][1] and c['y'][2] > c['y'][3])
    for row in (r for r in rows if r['panel'] == panel):
        tag = panel + str(row['target_temperature_c'])
        require(tag + ': formulation', row['sample'] == ('MIA1' if panel == 'A' else 'MIA3'))
        lo, hi, val_lo, val_hi = c['x']
        expected_x = round(lo + Fraction(row['target_temperature_c'] - val_lo) * (hi - lo) / (val_hi - val_lo))
        require(tag + ': sampled x column', row['pixel_x'] == expected_x)
        axes = [('x', 'pixel_x', 'temperature_c', 'temperature_lower_c', 'temperature_upper_c')]
        if row['status'] == 'unknown':
            require(tag + ': unknown values absent', all(row[k] is None for k in ('pixel_y', 'tg_percent', 'tg_lower_percent', 'tg_upper_percent')))
        else:
            axes.append(('y', 'pixel_y', 'tg_percent', 'tg_lower_percent', 'tg_upper_percent'))
        for axis, pixel, nominal, lower, upper in axes:
            center = value_at(ratio(row[pixel]), c[axis])
            low, high = bounds(row[pixel], c[axis], residuals[axis])
            require(tag + ':' + axis + ': exact-derived nominal', row[nominal] == float(center))
            low_decimal = Fraction(math.floor(low * 100), 100)
            high_decimal = Fraction(math.ceil(high * 100), 100)
            require(tag + ':' + axis + ': decimal outward rounding', row[lower] == float(low_decimal) and row[upper] == float(high_decimal))
            require(tag + ':' + axis + ': stored binary64 bounds enclose exact envelope', Fraction(row[lower]) <= low <= center <= high <= Fraction(row[upper]))

result = {'status': 'approved', 'checks': len(checks), 'elapsed_s': time.perf_counter() - started,
          'scope': 'Offline hash, CSV/JSON, coordinate and exact Fraction readout audit; visual review is separate. No original digitization script, model, EOS, or fitted kinetics executed.',
          'counts': {'targets': 44, 'readable': 35, 'unknown': 9}, 'calibration_residuals': calibrations,
          'files': audit_hashes, 'checks_performed': checks}
(out / 'MATERIAL_NUMERIC_AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('status', 'checks', 'elapsed_s', 'calibration_residuals')}, indent=2))
