"""Recheck only the original three saved service RED records, without a model."""
from pathlib import Path
import hashlib,json,time
import sludge_sandbox.source_study_service as service
from sludge_sandbox.source_study_record import decode_source_study
p=Path('/private/tmp/brick-source-study-record-v1/code-review')
out=p/'service-three-fixed'
t=time.perf_counter()
results=[]

raw=(p/'service-interface-red/record.json').read_bytes()
record=decode_source_study(raw)
value=service.query_source_study(record,'failure/message')
summary=service.inspect_source_study(p/'service-interface-red/record.json')
assert value=='retained actual failure text'
assert summary['stages']['failure']=={'exception_type':'builtins.ValueError','message':value,'stage':'comparison'}
results.append({'case':'actual SourceStudyNode fields','status':'closed','record_sha256':hashlib.sha256(raw).hexdigest(),'query_value':value,'stage_summary':summary['stages']})

raw=(p/'service-query-budget-red/record.json').read_bytes()
record=decode_source_study(raw)
original_dump=service.json.dumps
calls=[]
container_calls=[]
def watched(value,*args,**kwargs):
    if type(value) in (dict,list):container_calls.append(type(value).__name__)
    encoded=original_dump(value,*args,**kwargs)
    calls.append(len(encoded.encode()))
    return encoded
service.json.dumps=watched
try:
    try:
        service.query_source_study(record,'failure')
        raise AssertionError('expected early resource rejection')
    except ValueError as exc:
        assert str(exc)=='source_study_query_too_large_select_specific_field'
        failure=str(exc)
finally:
    service.json.dumps=original_dump
assert calls and max(calls)==4098 and not container_calls
results.append({'case':'same 16-node display DAG','status':'closed','record_sha256':hashlib.sha256(raw).hexdigest(),'exception':failure,'individual_scalar_serializations':len(calls),'maximum_individual_serialized_bytes':max(calls),'expanded_container_serializations':len(container_calls)})

raw=(p/'service-exception-capture-red/record.json').read_bytes()
summary=service.inspect_source_study(p/'service-exception-capture-red/record.json',capture_index=0)
assert summary['failed_capture_indices']==[0] and summary['unreturned_capture_indices']==[]
assert summary['selected_capture']['exception']=='ValueError: retained callback failure'
assert summary['selected_capture']['observation'] is None and summary['selected_capture']['recorded_input'] is not None
results.append({'case':'exception-only capture','status':'closed','record_sha256':hashlib.sha256(raw).hexdigest(),'failed_capture_indices':summary['failed_capture_indices'],'unreturned_capture_indices':summary['unreturned_capture_indices'],'exception':summary['selected_capture']['exception']})

repo=Path('/Users/wanggaoying/Desktop/brickmodel-github')
files={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in ('src/sludge_sandbox/source_study_service.py','tests/sandbox/test_source_study_cli.py','src/sludge_sandbox/source_record_io.py','src/sludge_sandbox/source_observation_service.py','src/sludge_sandbox/cli.py')}
result={'status':'approved_scoped_service_fixes','elapsed_s':time.perf_counter()-t,'cases':results,'file_sha256':files,'model_or_EOS_calls':0,'old_evidence_overwritten':False,'core_final_approval':False}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
