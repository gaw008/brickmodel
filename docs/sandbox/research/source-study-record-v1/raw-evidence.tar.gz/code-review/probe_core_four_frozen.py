"""Five passive decodes: original canonical record plus four rehashed cases."""
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
import hashlib,json,time
from sludge_sandbox.source_study_record import decode_source_study
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_wet_storage import SourceWetStorage
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.water_heos import HEOSWaterProperties
p=Path('/private/tmp/brick-source-study-record-v1/code-review')
out=p/'core-four-frozen';repo=Path('/Users/wanggaoying/Desktop/brickmodel-github')
expected={'source_study_record.py':'4a86d785ae38b2f6546eac17721c8387bcef1d78a0952711a08e777a8cb1c4bf','source_study_schema.py':'b9a1fe5e5c6581841351e102c88da15e4b9be566b9dea5e7733eaec23dbe2fbd','source_study_audit.py':'5f89a534df056062c6600d0554799e872dd6f1c979c65d9b2a8f17ea793da8b4','source_dry_transition.py':'1992d111f2c7d4d843889e85ceee1c360ff4215d40e0abd402fea64d53d20ae1'}
for name,digest in expected.items():assert hashlib.sha256((repo/'src/sludge_sandbox'/name).read_bytes()).hexdigest()==digest,name
count=0
def forbidden(*args,**kwargs):
    global count
    count+=1
    raise AssertionError('review attempted live physics')
manifest=json.loads((p/'prospective-core-mutations/MANIFEST.json').read_text())
inputs=[('baseline',Path(manifest['source_path']))]+[(c['name'],p/'prospective-core-mutations'/(c['name']+'.json')) for c in manifest['cases']]
results=[];started=time.perf_counter()
with ExitStack() as stack:
    for cls in (ExactSourceColumn,SourceWetStorage,WaterProperties,HEOSWaterProperties):stack.enter_context(patch.object(cls,'__init__',forbidden))
    for cls in (ExactSourceColumn,SourceWetStorage):stack.enter_context(patch.object(cls,'evaluate',forbidden))
    for cls in (WaterProperties,HEOSWaterProperties):stack.enter_context(patch.object(cls,'state_tp',forbidden))
    for name,path in inputs:
        raw=path.read_bytes();t=time.perf_counter()
        row={'case':name,'input_sha256':hashlib.sha256(raw).hexdigest()}
        try:
            record=decode_source_study(raw)
            row.update(admitted=True,capture_count=len(record.captures),audit_checks=dict(record.audit['checks']))
        except Exception as exc:row.update(admitted=False,exception_type=type(exc).__name__,exception=str(exc))
        row['elapsed_s']=time.perf_counter()-t;results.append(row)
        (out/'RESULT.json').write_text(json.dumps({'source_sha256':expected,'results':results,'forbidden_calls':count,'elapsed_s':time.perf_counter()-started},indent=2)+'\n')
        print(json.dumps(row),flush=True)
        if name=='baseline' and not row['admitted']:break
print(json.dumps({'done':True,'elapsed_s':time.perf_counter()-started,'forbidden_calls':count}),flush=True)
