# 物理沙盒 Goal 进度

更新时间：2026-09-10 UTC。完整任务合同：[GOAL_BRICK_PHYSICS_SANDBOX.md](../GOAL_BRICK_PHYSICS_SANDBOX.md)。最新状态以当前恢复入口及其实际产物为准，较早段落保留当时状态。

## 当前恢复入口（后续详细历史保留）

[完整来源运行记录](research/source-study-record-v1/REPORT.md)已实现并验收：96类闭合完整字段、
原始capture位置、试算/事件/失败返回、逐格及全域累计账本，以及同一CLI/Python查询。
原失败压力标签篡改、返回后校验失败丢失、共享DAG展开和失败分类等实际问题均已修复独审；
旧失败和旧代码保留。源码修复前141项114.83s、受影响50项42.72s、最终服务31项1.80s分别记录，
最终非editable安装149项115.30s通过，138模块/145包文件与源码一致。

一次最终安装版被动验收26.321774667s完成：原46,566,617字节N3结果全字段保留，32个原索引观测完整对应，
3参考回放、7累计行、2原失败试算及CLI/Python查询通过。新记录805,727bytes/1,371节点，
SHA5aa6746744e8804409669466f72d839c9fa869a0c59b88fafbabc9498d29a024，0新EOS/物理运行。
可直接查询的example-study.json与完整证据归档均在阶段目录。源23544/36218、安装57897、被动56434已终态0。

同阶段Areias2025图3完成35读点/9unknown，实际看图和356项独立计算核查通过；与图4仅按同文命名配方连接。
不推定TG气氛、反应热或未处理原泥适用性。下一实际步骤见阶段[NEXT_STEP.md](research/source-study-record-v1/NEXT_STEP.md)：
来源运行/取消出口、明确配置保存和受控重建，再接界面；不再重跑不变EOS来完善文件格式。
完整Goal保持active：同材料原泥反应/烧结/冷却、三机制公开留出、时空收敛、全周期、多代与全部应用验收仍必需未完成。

### 前一湿格共享体积压力阶段（已完成，保留历史）

[来源湿格共享体积压力比较](research/source-wet-shared-pressure-v1/REPORT.md)已接入实际 N3 唯一耗尽路径：同一 live storage/volume、全 J 根/舍入/温度传播、完整 2×N 证据和所有原门槛保留。代码独审发现并修复取消回调临时修改物性配置的绑定漏洞，原 RED/GREEN 和旧版本保留。修复前源码/安装各151项87.63/88.09s，最终受影响源码/安装各44项29.84/30.13s通过；133模块/140包文件相同。独立制造1414项及实际生产桥接34项通过。

唯一新安装版真实水试验已终态：父求解72.571767s、包装器73.542000s，32 source观测、4构造参考锚点、3初U，另8实际液态查询/4唯一键/4湿pair，passive EOS=0。两时刻选用P界约[4.197615451e-5,1.005692709e-5,4.162917358e-5]Pa，全部低于原1e-4Pa；数值事件true、材料false。原独立P失败、N/U/T/时间及eV=1e-12m3保持，物理共同末端仍仅1.093759627e-6s。JSON SHA6c55383e8d2063ed6c81f2126b40542ba44ee173fc1671b227573b908bfbfc53。

新原生保存独审281项通过（66/0.308364s + 215/0.522750s）：逐项重构四湿pair全J/Γ/温度界及原门槛，32完整物理观测/输入/模式与前次一致，仅排除运行时elapsed_seconds。审计器原字段/时间假设错误与修正保留，未重跑EOS。资格仍为条件性数值范围，不证明全域物性假设或材料实测。

实际运行结构/文件独审另394项0.551023s通过（含280包文件核对），原父输出、8完整返回和冻结配置匹配。145成员原证据归档全部重开匹配，10,312,995bytes，SHAcead9f4f2079e2420c5cc20ef464c85a246e2023d5b7eb99d29b0e5f03470755，见阶段RAW_MANIFEST.json。

根源码36011/13544、安装91838/10507、原生36473均终态0；没有待跑原生过程。下一实际工作见[来源完整运行记录接入](research/source-wet-shared-pressure-v1/NEXT_STEP.md)，复用已保存真实结果，不重跑不变EOS；新pair研究JSON不等于live resume。完整Goal保持active，合同未改，同材料原泥反应/烧结/冷却、三机制公开留出、空间时间收敛、全周期和多代仍必需未完成。本轮有实际实现与验证，属于progress。

### 前一完整来源观测阶段（已完成，保留历史）

[完整来源观测读写](research/source-observation-record-v1/REPORT.md)已实际实现：39类被动白名单、完整字段/关联校验、显式旧观测导入及同一CLI/Python服务；未知模式保持null，来源/材料/恢复资格不升级。源码93项15.94s、非editable安装93项16.03s通过，131模块/138包文件逐字相同。独审实际发现并关闭7个输入/关联/资格缺陷，原失败、错误接收与修复证据保留。一次安装版被动读取三原文件全部111观测，1813检查20.660949s通过、0物性调用；安装CLI原N3 capture16/原格1与Python另7项一致。源码8183、安装88788、被动57716均终态0，无本阶段待跑进程。

同阶段独立湿格预算92项0.251474s完成：原湿0/2完整P界约0.00208677/0.00208642Pa、event=false不变；V额外项约98%，原温度余量约占1e-4Pa预算1.33%。[下一数学桥接](research/source-observation-record-v1/wet-pressure/DERIVATION_CANDIDATE.md)必须获得共同支点全压力区间的液体v包络和稳定条件，保留独立压力/温度误差及全部原门槛；未创建新证书或执行EOS。来源单观测保存已完成，完整trial/事件/失败/账本协议与受控live resume、应用/界面仍需接续。

本轮有实际代码与验证，属于progress；Goal保持active、工作合同未改。原同材料原污泥反应烧结冷却、三机制公开留出、空间时间收敛、全周期和多代等仍为必需未完成。继续上述有界推导和运行协议，不重跑不变检查、不把单观测完整误称全模型完成。

### 前一 N 格唯一单元湿干阶段（已完成，保留历史）

[N格唯一单元湿→干及液流供体焓](research/source-multicell-transition-v1/REPORT.md)已完成本阶段实际实现：完整4N根竞争选k，仅k液汽写回/模式改变；原Darcy/供体焓、完整2×N湿干压力和每格/全域累计账本接线。当前全初始湿、正蒸发子域不包括纯输运残余、重复耗尽和再润湿。源码52项78.58s、安装52项78.33s，128模块/135包文件一致；原N1的54字段/3失败保持。独审发现selected兼容视图不同storage漏洞，实际RED保留，修复后同探针1项11.97s通过。制造保存221项Fraction核算0.229196s通过，负参考焓的首轮错误测试已修并保留失败。

唯一新真实水N3运行71.769374s/32source求值完成，4provider构造锚点和3初U分别保留。物理共同末端仅1.093759627e-6s，实际k1耗尽及两个mixed dry候选各1步；根界1.018643031e-14s与所有N/U/T通过。两时刻选用P界均约[0.002086766985,0.00001005692709,0.002086423472]Pa，原1e-4门槛为false/true/false，总数值事件false、材料false，原独立P失败未删。独立原生保存397项审核通过（0.247575s+0.250040s），完整3/4前缀、正负非零rho、实际几何/液体焓和32回调身份核对，无EOS重跑。JSON SHA2660d33ec0e832e006d5adcccd8ddcf38cc314ac5e65a17830cdf2f73cbdc51d。源码73037、安装32272、原生8377均终态0，无本阶段待跑过程。

下一具体步骤从已保存湿端点分析原压力界及同一实际参数的联合湿态比较可行性，保留当前失败和所有原门槛；随后接来源记录/恢复与应用，不重跑已完成实验或把dry关联套到wet。完整Goal同材料原泥反应烧结冷却、三机制公开留出、空间时间收敛、全周期与多代等仍必需未完成。前一3fdea98阶段提交和本阶段实现/验证均属progress，Goal保持active，工作合同未改。

### 前一来源共享体积干压力阶段（已完成，保留历史）

[来源共享体积干压力](research/source-dry-shared-pressure-v1/REPORT.md)已实际完成本阶段：显式live storage/volume声明，完整T/V联合差、严格原误差分解和全箱舍入；实际湿→干入口可选新界，旧独立P值/失败保持。源码79项32.96s、非editable安装79项32.90s通过，127模块/134包文件一致；独立制造187项0.105584s，严格T反例1项12.03s/46source调用通过。原min草稿与夹具共存RED均保留且已修复。

新真实水单次18.995829s、32source求值，4构造/锚点和初U1另计；新event/common联合P界均8.606093364e-6Pa通过原1e-4Pa，原clock/N/U/T通过，transition数值事件true、材料false。旧报告P0.002026653258Pa和独立完整T界0.002035256130Pa及其false gate保持，eV1e-12m3未缩小。独立保存审核370项通过（0.081474s+0.163133s），新旧32次物理观测逐项完全一致，无EOS重跑。完整JSON SHA a9d2d658a259e72f871e4f96c8d3e0172def2720a2901bc91c06e78e5a97d4dc。源码74135、安装41481、原生29672均终态0，无待跑过程，不重复已通过的不变检查。

下一实际实现：[N格唯一单元事件/液流与供体焓](research/source-dry-shared-pressure-v1/next-runtime-slice.md)。复用N维面板、根和前缀账本；先保留正蒸发及原phase correction预算，纯输运不能冒充液→汽修正。继续混合湿干压力/全格累计账本、来源保存/应用、再润湿及重复事件。原Goal完整同材料原泥反应烧结冷却、三机制公开留出、空间时间收敛、全周期与多代均仍必需未完成，Goal保持active。

### 前一来源单格湿→干执行阶段（已完成，保留历史）

来源单格湿→干执行已实际实现：[阶段报告](research/source-dry-transition-v1/REPORT.md)。完整来源终端账本绑定原微量液汽写回，接显式dry与原积分器；两条实际路径比较事件及同一后续时刻。根细化接上先前已用深度，实际剩余运行政策与失败输入时间均冻结，来源标签和时间/预算原反例已修复。源码153项99.17s、安装153项100.55s通过，126模块/133包文件一致；制造闭合和带热边界两例条件数值接受，独立保存144项核对通过0.06650s，程序节点和真实dry U/T变化有证据。

本阶段真实水单跑18.946748s完成32次source求值，两条实际dry各1步；另计4构造锚点和初U1次。事件区间距离1.02963836e-14s、N/U/T通过，报告P0.002026653258Pa和条件P0.002035256130Pa均未过原0.0001Pa，数值事件未接受、材料false。原体积误差1e-12m3未缩小，体积项占报告P界99.9998717%。独立174项保存审核通过0.08585s；完整JSON SHA0a242ef8c239226b68ee085abe51641e1b95165c464f7edb175454555543fa49。源码4721、安装6525、原生14536均终态0，无这三批待完成进程，不重复运行。

下一工作先基于实际同源干态记录，核实共享体积参数的联合压力差包络是否有严格依据，或为明确的新虚拟几何推导独立数值体积误差；保留原保守P失败，不倒推误差值或放宽1e-4Pa门槛。随后继续来源N格液流/供体焓耗尽、干界面/再润湿、通用调度和保存/应用。完整Goal保持active，同材料原泥反应烧结冷却、三机制公开留出、全周期和多代仍必需未完成。

### 前一分区根与正库存终点阶段（已完成，保留历史）

来源分区根与实际共同终点比较 `source_root_comparison` 已实现：[本阶段报告](research/source-root-comparison-v1/REPORT.md)。从上一真实参考状态重算新面板，绝对有理根区间含宽度比较；两条实际路径续算到同一正库存时刻，原始初态到每个前缀的累计N/U账本不重置。细化/积分/事件政策保持，时钟内部类型漏洞已修复，第二路径及后处理失败保留实际试算。

最终源码41项38.40s、安装41项36.33s通过，123模块/130包文件逐字一致。一次原生真实物性运行107.148309s，4provider构造/锚点、初U1次、source38次分别保存。两个数值根距离上界2.2652043864e-9s通过原1e-8；实际共同终点0.02879266519s，N/U/T通过，但报告P界0.002739827049Pa及条件P界0.002745619913Pa均未通过原0.0001Pa。体积误差为主要贡献，未缩小原误差或放宽门槛；事件/材料资格保持false。完整JSON SHA6aa52124fec977dfb39c65cac64538c87918fc8ed3cff82d3b3a5d5cd0474ae8。

下一具体实现：[一次来源湿→干运行片段](research/source-root-comparison-v1/next-runtime-slice.md)，接真实终端状态/账本写回、干态压力区间及原积分器续算，按原门槛决定是否提交；不能再用正库存比较代替事件实现。运输成对液体/同供体焓、再润湿、来源保存/应用、原泥成套材料、反应烧结冷却、三机制公开留出、全周期/多代仍必需未完成。独立保存审核及归档身份见本阶段报告，完整Goal保持active。

源码87566、安装52830、原生60604均终态0，无本阶段待跑root测试/EOS，不重复已通过的不变检查。

### 前一来源首根引导正库存阶段（已完成，保留历史）

来源首根引导的单次正库存接近 `source_approach` 已实现：[本阶段报告](research/source-approach-v1/REPORT.md)。由原失败前缀的实际起点/中点构建全4N根竞争；排序与正下界细化共用预算，原safe_fraction、步长和炉程约束保持。真正重算更短区间的中点/终点及原积分器参考，保留原N/U/T/P与条件压力门槛。后处理异常保留完整实际trial和已完成比较，政策在回调前复制并最终核对；无事件或材料资格升级。

最终源码135项78.04s、非editable安装135项76.62s通过，122模块/129包文件一致；独立109精确检查、3项代码行为、12个Python反例及3项无EOS运行器检查通过。一次实际水安装运行完成32.312098s，新试算26.083941s，4个provider构造/参考锚点+初态U1次+source14次(研究phase1/种子2/新trial11)分别保存。H约0.110556577s、新h约0.0138195721s，原D=3.065855e-10；原N/U/T通过、报告T处P与conditionalP未通过，事件时间未评。原JSON SHA6f6c32330f9bd3159186705345fbe35bce0729e592f006611c9707082f068ca2。没有为通过压力门槛改容差。

下一实际工作：按[既有路线](research/source-prefix-trial-v1/next-route.md)建立独立实际求值的粗细面板及首根区间比较，相同首根标签/源/政策；不同时间状态须真正续算到共同终点后比较原N/U/T/P。不能对同一对样本重复二分冒充独立时间细化。全域EOS/材料误差、运输成对液体/供体焓、干界面/再润湿、来源保存/应用、原污泥成套材料、反应烧结冷却、三机制公开留出、全周期/多代均仍必需未完成。

本轮属于实际progress，完整Goal保持active。源码14773、安装91364、原生2207均终态0，首次新增测试36349为20项通过；安装身份首读因XML未写入而失败，等待原进程结束后完成核查，未重启测试。独立保存数据104显式检查0.00972s通过，无新EOS，重建根/步长/参考水能量账本及原未通过压力门槛。无本阶段待跑EOS或测试，不重复不变检查。完整记录及最终文档审查见本阶段报告。

### 前一来源条件逆压力阶段（已完成，保留历史）

来源温度反解的条件压力传播 `source_inverse_pressure` 已实现：[本阶段报告](research/source-inverse-pressure-v1/REPORT.md)。实际 storage/state/inverse 绑定、原闭合残差/体积误差、热容/能量误差先核对，再以全域稳定液相/uP条件给出完整温度区间上的压力围栏，域内验证后才收紧。原事件四门槛不变，条件压力 gate 另存，无政策则 null，无事件/材料认证升级。

相关集成源码107项67.96s/安装107项67.65s通过；实际保存端点发现dict与只读来源映射互操作误拒绝，修复后受影响模块源码31项16.67s/安装31项16.88s通过，未重跑其他77项。最终121模块/128包文件一致。独立Python29项、HEAD helper14项、映射8项及解析1030检查/492根通过；原液压/资格/映射RED均保留。一次原生失败后按原输入/预算复验，六保存端点35检查完成1.148738s；三成对压力界约0.00258531/0.00293490/0.00353928Pa，与原独立Fraction结果全等。另86项标准库保存审核通过。两次各2个HEOS构造锚点、0新端点，累计4锚点，不能说完全无EOS。

下一步复用[根引导路线](research/source-prefix-trial-v1/next-route.md)，从真实首/中点求值及原4N首根竞争提出严格正库存接近区间，采用原DepletionPolicy.safe_inventory_fraction、步长/炉程节点约束，再调用SourcePrefixTrial取得新的实际中点、终点与同区间参考；普通推进留在integrate_exact，不复制控制器。全域EOS/材料误差证书仍缺，事件时间、运输成对液体/同供体焓、干界面/再润湿、来源保存/应用，以及完整原泥反应烧结冷却、三机制实测、全周期/多代继续未完成。

上一轮只核对/提供Goal提示词，属于no progress；本轮有实际实现、独立反例修复和原生来源端点证据，属于progress，完整Goal保持active。root20563/6969/34469/27128/67291/40075均测试终态0；99082首轮端点核算终态1、77552修复复验终态0。无本阶段待跑EOS或测试，不重跑已完成不变检查。

### 前一来源端点比较阶段（已完成，保留历史）

来源同端点误差比较 `source_endpoint_comparison` 已实现：原成功试算检查/参考恢复保持，复用原完整事件政策编解码，按精确 Fraction 分别核对 N/U/T/报告温度处 P 门槛。缺政策不猜容差；全反解压力与事件时间仍未准入。[本阶段报告](research/source-endpoint-comparison-v1/REPORT.md)。

源码81项63.75s、非editable安装81项63.19s通过，120模块/127源包文件匹配；Python独审15项、代码独审10项含27代数案例通过。保存的7c0907真实物性端点在源码/安装版各完成30检查，安装0.202008s，无新EOS；除耗时外结果全等。最大N/U/T/报告T处P差异为1.19545e-10mol/1.15254e-6J/5.61826e-8K/0.00338039Pa；原记录无来源事件政策，未作门槛决定。原fixture/审查脚本失败均保留，40成员原始归档重开逐字一致。

当时的下一步是[条件性压力传播接口](research/source-endpoint-comparison-v1/pressure-path.md)，现已按当前恢复入口实现；全域EOS/材料资格尚缺。随后按[既有根引导路线](research/source-prefix-trial-v1/next-route.md)获得实际重新求值的正库存接近区间。事件时间、运输成对液体/同供体焓、干界面/再润湿、来源保存/应用及完整原泥反应烧结冷却、三机制实测、全周期/多代仍未完成。

上一00ec847及本阶段均属实际progress；完整Goal保持active。root1230/82966/41547/85090/51962均已终态，前两次失败已解释修复，最终两批81项通过；两次保存端点核算和安装身份核对也已终态，无本阶段待跑EOS或测试，不重跑不变检查。

### 前一来源前缀试算阶段（已完成，保留历史）

实际来源前缀 `source_prefix_trial` 已接通：原Euler更新共用，真实起点/中点/终点求值，同区间原 `integrate_exact` 参考及直接N/U差异门槛。全部尝试含失败输入/类型均保存；成功记录按原积分器被动重放参考，含可恢复DomainExit，不再将原参考正常恢复误判失败。参考账本篡改、结果改标签、NaN差异、失败输入及空异常消息缺陷均有真实RED并修复。[本阶段报告](research/source-prefix-trial-v1/REPORT.md)。

12组旧完整回调/结果保持；源码143项55.59s、非editable安装143项47.69s通过，119模块/126源包文件匹配。代码独审46项及最终运行器5项、Python25反例、冻结三格制造水56检查均通过。一次安装版真实水试算完成：1/16384s、11实际求值=3前缀+8参考，参考1接受0拒绝，直接差异0.001086768806259706<=1。试算81.125177s/180、全运行82.732120s/210、32调用上限，原科学容差未动。JSON SHA7c0907af104450ffc42cf142e3e3aebefaf21c597eb6806f09b7bdbe6d6d3505。独立标准库235检查0.026472s重构参考及账本；原审计器失败保留，未再跑EOS。

root旧基线11615/helper49981、恢复反例89948、最终源码21813/安装76958及native5228全部终态0，无本阶段待跑root进程。前一cc94ecb与本回合均有实际实现和验证，属于progress；完整Goal保持active。

下一具体工作：[保存真实端点的原事件门槛比较](research/source-prefix-trial-v1/next-route.md)及[独立约束](research/source-prefix-trial-v1/next-route-review.md)。复用原DepletionPolicy、实际来源逆解温度误差和包含体积误差的P界，精确向外求差异；报告温度处P界不能冒充完整逆温度传播后的P界。先用保存端点，无需新EOS；随后根引导的真实正库存接近需独立新样本和原预算。事件时间、运输修正/同供体焓、干界面/再润湿、来源保存/应用、同材料域、完整原泥反应烧结冷却、三机制留出与全周期/多代仍必需未完成。

### 前一来源前缀账本阶段（已完成，保留历史）

来源数值前缀 `source_net_prefix` 已实现：复用提取的精确仿射积分/状态投影，共享面一次积分，成对液汽转换，完整库存最小值、局部/累计已表示与精确积分残差分别受原门槛约束。独立反例发现并修复累计漏算积分投影、政策可被追溯性放宽、面编号与数组类型遗漏，原 RED 全部保留。[本阶段报告](research/source-net-prefix-v1/REPORT.md)。

13组提取前旧完整结果保持；源码131项10.37s、非editable安装131项10.79s通过，118模块/125包文件与源码匹配。独立制造算术79基准+144对照、代码56项及Python32反例通过。安装版回放原七试步为七个独立前缀完成0.382550s，最终JSON SHA8ca3d79c533801f70002b3ad6bace09e84446c87e62d9bd4233d8fce57fc95e0；无新EOS、原三拒四受身份保持。独立标准库818检查0.050866s核对245积分、105状态、84最小值与28面诊断，最大完整残差2.38177e-17mol/6.87474e-12J。没有把这些前缀拼接成新轨迹。原生审计器一次边界字段假设失败及修正亦保留。85成员原始归档全部重开逐字匹配。

root源码51805/安装81581及快速回放全部终态0，没有本阶段待跑EOS/测试；两项代码审查及最终原生独审已完成。前一1fd9e87与本回合均有实际实现和验证，属于progress，完整Goal保持active。

下一具体工作：[实际来源前缀试算](research/source-net-prefix-v1/next-route.md)与[独立约束](research/source-net-prefix-v1/next-route-review.md)：仅提取原Euler更新，真实求值起点/预测中点/前缀终点，对比原积分器完成同一精确区间的结果。先廉价测试和独审，再冻结一次安装版短真实水预算；保留原容差和政策绑定，资源核算涵盖全部回调。数值boundary、零初始或未完成参考不能升级为通过，直接差异不除以3。运输修正/同供体焓、干界面/再润湿、来源保存/应用，以及同材料域、完整原泥反应烧结冷却、三机制留出与全周期/多代仍未完成。

### 前一来源净库存首根阶段（已完成，保留历史）

来源净库存首根与竞争排序已实现 `source_net_roots`：共用提取的有理二分/GCD，复用原库存最小值，覆盖排水/凝结净消耗、初期增加、凸型下降后回升、切触、气体优先及同时首根群组。任一零初始库存明确不完整，未决区间保留；不使用或放宽原蒸发修正预算。[本阶段报告](research/source-net-roots-v1/REPORT.md)。

17组提取前旧完整结果/失败诊断保持一致；合并源码123项17.99s、最终非editable安装123项18.01s通过，117模块/124包文件与源码匹配。独立117组有理因式案例1152断言、另588组因式检查及Python29反例完成；最终只补六处返回注解，算术未变。安装版回放原七个试步的14条来源记录完成0.283783s，全部84库存多项式给出严格正最小值的no_roots证据，原拒步身份保持，没有新EOS。最终JSON SHAb1f45c66d896528e1ffe22fdeaed71cee85a6612794d51bf5c2091cd29238b87。root24821/60569/52652/2112及快速回放均终态，无本阶段待跑求值。前一80ea73d及本回合均有实际实现/验证，属于progress；完整Goal继续active。

最终原生记录独立复算450项通过0.042049s，核对全部84库存、三个内部凸顶点及原试步身份，最小数值库存1/256mol。它依赖已冻结且先前经审计的插值记录，不是重新求解真实轨迹。

下一具体工作：[来源面板积分/账本复用路线](research/source-net-roots-v1/next-route.md)及[独立约束](research/source-net-roots-v1/next-route-review.md)，提取原终端面板的共用积分与状态更新，按共同面一次积分/舍入建立来源前缀；分别记录分量投影、状态投影和总残差，验证全部液/气在整个所选前缀的非负性并保留累计预算。下一步仍拒绝全部零初始，不采用恒零特例。排序complete仅表示数值多项式的先后关系，不证明事件时刻精度。运输残余必须保持成对液体与同供体焓，不能变成蒸发；零初始、干界面、源事件/保存/应用、同材料体积/吸附/输运、完整原泥反应烧结冷却、三机制留出与全周期/多代仍未完成。

### 前一来源净库存插值阶段（已完成，保留历史）

来源N格净库存插值已实际接入 `source_net_panel`：完整源样本与共同面历史形成四类流体及总U二次多项式，复用原 `InventoryPolynomial.minimum`，没有把kg改为mol或复制根算法。实际来源测试发现并修复炉程时刻/化学零类型检查缺失，独审材料资格标记可被改写的漏洞也已关闭；原派生项篡改RED保留。[本阶段报告](research/source-net-panel-v1/REPORT.md)。

源码20项10.160s、非editable安装20项10.115s通过，115模块/122包文件匹配。固定回放上一阶段七个实际试步的14条记录 completed0.279171s，238导数/全域检查、84库存最小值，未额外求解EOS。独立标准库445检查核实105多项式、84最小值和五时点的水/U边界积分；原拒/收/拒/收/拒/收/收身份保持。96449红灯、43128源码绿灯、87151安装绿灯及快速回放均已终态，无本阶段待跑root进程。上一8b6ef80及本回合均有实际实现/验证，属于progress；完整Goal继续active。

下一实际实现：按[纯根复用路线](research/source-net-panel-v1/next-root-route.md)及[独立澄清](research/source-net-panel-v1/next-root-review.md)，从旧locate/order提取共用二分转移和纯GCD算术，保留旧dyadic步、>=分支、零端点及蒸发ULP/比例准入不变；新来源层处理净液流、初期增加、凸型下降后恢复、切触与气体竞争。不能把凸多项式在终点的第二根当首根，不能把共用后根当同时首根；零初始库存需独立证据，不能静默过滤。纯根位置仍不授权物理事件或运输校正/干界面。源记录/应用、同材料体积/吸附/输运、完整原泥反应/烧结冷却、三机制公开留出、全周期及多代仍必需未完成。

### 前一来源精确积分阶段（已完成，保留历史）

来源固定干质量已通过 `ExactSourceColumn` 接入既有 `ConservedState/Rates/integrate_exact`：动态数组只含液水/O2/N2/H2O四类真实摩尔库存，固定干 kg 与原来源 Cp 仍在总 U/储能身份中。完整来源求值、共同液/气/能量面及显式关闭化学反应契约保持。实际修复了化学元数据被丢弃与来源异常越过结构化失败的两个接口缺口。[本阶段报告](research/exact-source-column-v1/REPORT.md)。

最终非editable安装39项通过13.308s，XML零失败/错误/跳过，114模块/121包文件与最终源码一致。首次原生运行因首步误差拒绝后触及75s内预算而失败，12captures/0accepted，独立272检查解释原始失败。仅把资源调整为450/510s后，同完整1/1024s案例实际completed：4接受、3拒绝、47评价，积分448.601522s、总墙钟450.468822s，所有原误差/步长/步数门槛未动。独立1215项离线检查重构全部7试步、接受四阶段两级舍入及局部/全局/累计账本；前12原始捕获与首轮完全相同。成功JSON SHA033dccd09ed268eeb2ce9570a37d52f66d4eb5da18b68f2f44a89bd01054c4f2。7031及本阶段既有58221/61057等root进程均终态，无本阶段待跑EOS。首次失败、审计器运算顺序修正和全部原证据已保存。属于实际progress，完整Goal保持active。

下一实际工作：来源 N 格净液库存 affine panel，逐格使用 J_left−J_right−phase，复用既有 InventoryPolynomial；之后才可接运输/蒸发耗尽、独立成对液体/焓数值修正、干界面与保存/恢复。临时候选 `/private/tmp/brick-source-net-panel-candidate` 及独审 `/private/tmp/brick-source-net-panel-review` 尚未应用；实际9作者测试、12项独审组合通过，派生多项式可被替换而不受check核对的HIGH已有真实RED并修复。恢复先读取最终候选/审查，再补实际来源求值接线验证，不把人工记录当作真实轨迹。固定来源低温域、同材料体积/吸附/输运、原泥完整反应与烧结冷却、三机制公开留出、全周期/多代与应用验收仍全部必需未完成。

### 前一来源液流阶段（已完成，保留历史）

来源 N 格跨格液水及供体焓已实际接入：共享 `decoded_liquid_state` 复用原 T/P、全体积影响压力误差与原液水参考，旧 SolidFluidHeat 完整结果保持；SourceWetColumn 的内部面新增液流/焓/投影，开放包装保持内部液流、外界液流为零。完整源/安装测试和实际水短步均通过，材料资格仍false。[本阶段报告](research/source-liquid-column-v1/REPORT.md)。

最终源码26项28.777s、共享提取41项0.58s、独立代码33+2项通过；非editable安装72项47.009s，XML零失败/错误/跳过，113模块/120包文件一致。独立人工液体三格2/4/8步参考误差比约4，事前3..5判据通过；真实水源码probe completed3.953s、安装开放三格单步completed积分22.167228s，总墙钟23.676868s，3评价/80检查。原JSON SHA9644aa69ee7ddc150184f91b35961df8bd8d1988afc44acf2a12c49b4b9ccca3。66790/81138/60188/18128均终态0，无本批待跑测试或EOS。上一提示词答复保留了初次8项通过证据；本回合完成新增验证、实际安装/原生运行与证据保存，属于progress，Goal保持active。

下一实际工作：将来源 N 格的 kg 固体/mol 液气布局、共享液/气/总U面账本和材料身份接到既有精确耗尽、干态续算与保存/恢复体系，再完成参数查询和CLI/UI。不能简单放宽旧两格事件主机的类型/数量检查；活动液面两侧须有液体，耗尽后的连接与相态要显式处理。原泥同材料体积/吸附/输运、完整温域反应、烧结冷却、三机制公开留出、全周期时空和多代/应用验收全部仍必需未完成。

终态来源探针与安装首阶段全量相同；独立保存结果审查仅标准库复算166项通过，无额外EOS，液流/供体焓、全三阶段、积分与全域开放余额逐项成立。独审及原始产物见上述本阶段报告。

### 已保存的先前阶段记录

来源多格开放炉程已实际接入：`ProgrammedSourceWetColumn` 复用原共享气体面与新提取的表面平衡函数，右端能流为气体焓流减入格导热，对流/辐射不重复加入。`integrate_source_column` 共用原中点算法，显式 ExactEventTime 起点/阶段/节点细分，保留完整旧封闭结果；接受步另记真实中点边界和表面热量分项。气体和固体温区分别检查，材料资格仍 false。[本阶段报告](research/programmed-source-column-v1/REPORT.md)。

源码新/旧多格 16 项、共享/旧边界 23 项、独立代码 19 项通过。非 editable 安装 39 项通过 19.25 s、112 模块一致；1 个未改动的耗时球形网格研究未重跑。独立人工液体开放 N=1、0.125 s 的 2/4/8 步误差比约 4，原判据通过；8 步仍有 0.161553 J 差异，不声称满足任意时间精度。真实水开放三格评价探针 2.38626 s，安装完整一步 22.20617 s completed，3 次评价/25 内置检查；离线独审 60 项通过，开放边界贡献及舍入精确解释每格/全局 U/O₂/N₂/总水变化。全部冻结代码和原失败/黄金/轨迹/审查已归档。42199/73156/38600/89514 均终态 0，无本批待跑进程。上一 e2c815a 及本阶段都是实际 progress，完整 Goal 保持 active。

下一具体实现：复用既有 `liquid_transport` 的受限液水面迁移和供体焓，在来源 N 格添加同一液水/能量面账本；不伪造毛细或真实渗透参数。之后迁移精确耗尽、保存/恢复记录和参数查询/CLI/UI。当前程序边界只扩展了有域限制的固定低温路径，原泥反应、烧结冷却、同材料体积/吸附/输运、三机制公开留出、全周期时空验证及多代/应用验收仍必需未完成。以下“来源路径无开放炉程”是此前阶段记录，不能据此重跑旧实验。

来源 N 格热湿路径已实际实现：`SourceWetColumn` 共享旧 WetPair 提取的相变/面计算，固定来源干质量、关闭化学反应，以 N+1 个面账本推进逐格液水/三组分气体/总 U。非均匀半格几何、正性、显式干态及完整接受步保持均有测试；公共面误接气体焓函数的独审 HIGH 已修复，旧完整黄金结果不变。两端目前明确闭合，几何/输运仍为测试值，材料资格为 false。[本阶段报告与证据](research/source-wet-column-v1/REPORT.md)。

实际新多格源码 9 项、共享/旧两格 29 项、独立代码 41 项通过；独立人工液体三格 0.25 s 的 2/4/8 步对照呈约 4 倍误差缩小，逐格/全局守恒余额精确为零。最终非 editable 安装 38 项通过 14.41 s、XML 零失败/错误/跳过，110 模块与源码一致。真实 HEOS 三格 1/1024 s 一完整步源码 23.03119 s/安装 22.56292 s 均 completed、3 次评价、20 内置账本检查，除耗时外结果相同；独立离线 47 检查通过。保存总水变化约 −8.67e−18 mol，恰等已记录舍入，不能称库存数值严格不变。98593/31942/45695 均终态 0，无该批待跑进程。代码/测试/原失败/审查均已归档；4ff9572 及此阶段均属实际 progress，完整 Goal 保持 active。

下一具体实现：复用已有程序气体库和表面对流/辐射计算，接入来源 N 格的显式时间、开放边界与统一气体/焓/热面账本；先验证单格与三格的开放极限，再迁移精确耗尽、保存记录和应用入口。当前来源路径尚无跨格液体迁移、开放炉程、事件自动定位或全周期。真实同材料体积、吸附/有效输运、原泥反应、烧结冷却、三机制公开留出、全周期与多代/应用验收全部仍必需未完成。以下为历史恢复记录，不再重复旧实验或把旧“源 N 格未接入”当作当前状态。

本轮实际完成来源干物湿态储能连接：`SourceWetStorage`使用原Arlabosse Cp积分、固定干质量和显式ReactionDisabled，与旧`WetMixedStorage`共享新提取的真实水气机械/储能内核。没有A/B或形成能网络，没有虚构固体体积/材料总焓。来源材料体积仍缺，当前只接受明确测试用恒定流体容积，fit误差保持unknown。独审实际发现公开helper非binary Fraction库存与EOS转换不一致导致压力界偏小，已按无损表示契约修复，原代码/RED/误差值保留；三组旧完整point和identity不变。[本轮报告](research/source-wet-storage-v1/REPORT.md)。

实际源码59项8.02s、独立代码45项1.45s、独立物理13项均通过；非editable安装59项8.23s、XML零失败/错误/跳过，109实际模块与源一致，5独审文件hash保持。真实水+公开O2/N2的安装算例5.37203s完成：331.25K原态，固定U将1/1024mol液水转气后331.1392713338K，水总量精确不变；独立温度根差约2.20e-8K在其声明数值界内。源/安装产物除耗时外全等。33917/48126/36461/2155均终态0，无本轮待跑进程。上一回合caf7777阶段提交属progress，本轮代码/独立与安装验证也属progress，完整Goal保持active。

下一具体代码工作：从`mass_wet_transport.WetPair.evaluate`提取原共享相变/cell和face计算，保留旧A/B回归；明确源固定质量/关闭化学反应分支，随后接N格拓扑、单次共享面账本与逐格边界源。当前旧`WetPair`/exact stage/controller/record仍未准入SourceWetStorage，不能只放宽type/len检查。源湿输运/吸附/真实体积、反应烧结冷却、三机制公开留出、完整周期、多代与应用验收全部仍必需未完成。以下为较旧恢复状态，不应重复运行历史已结束的实验。

最新实际实现：`source_mass_caloric.py`将既有Arlabosse来源Cp/Δh用于固定正干质量的恒组成、不可压缩名义储能，明确域内能量坐标与ReactionDisabled，无A/B、氧参考、虚构摩尔质量或体积。完整温区Cp下界用于精确Fraction反解；源fit误差和比容仍未知。独审发现运行时替换provider/caloric可保持身份的HIGH，原RED已保留，修复两层exacttype检查；源19项/独立4项通过。实际安装0.2kg、40→80°C得到13051.2J，反解与7节点溯源已保存。证据：[来源干质量储能](research/source-mass-caloric-v1/REPORT.md)。这只是干物point，尚未接入现有WetMixedStorage/原泥湿格。

旧水AST失败已由合法host行为回归替代，水源码未改；作者15项通过，涵盖原化学/干政策及机械上下文。[行为回归证据](research/water-behavior-regression-v1/REPORT.md)。Root非editable最终33项4.70s通过（19新储能+5水行为+完整9deforming-wet-admission），108安装模块与源匹配，35120终态0，无该批运行进程。上轮2258695/832a012和本轮新实现/实际独立验证均属progress，Goal保持active。

下一必须推进真实湿格软件接口：在保留原WetMixedStorage/WetPair回归的前提下，将已实现来源质量比热与显式无化学反应接入共享fluid storage/cell/face计算；真实骨架比容或可用流体容积仍需同材料证据，缺失时不准入实际材料。温度域不能为迁就旧298.15K扩张；可先做明确制造几何的数值接线验证但不得升级材料资格。随后迁移N格共享面账本与事件/记录。原湿烧冷全流程、反应/烧结材料证据、三机制留出、多代和界面验收仍未完成。以下较旧状态保留历史。


最新身份修复已正式应用：精确CurrentSlab七字段数组编码恢复规定变形wrapper构造，不跳过私有缓存、不接受任意ndarray；独审17tmp检查通过。应用后31源码测试通过、1旧水模块AST镜像测试失败（实际水代码与HEAD相同，未修改）；原移动半格/一次逆解测试现已通过。非editable安装13项通过0.48s，107模块匹配。详见[实际身份修复](research/current-slab-identity-v1/REPORT.md)。旧AST测试需按实际分拆后的行为重建回归，失败保留；完整Goal仍未完成。

下一具体工作：修复上述陈旧水回归断言并保持真实化学/耗尽行为覆盖；随后按sphere-surface-v1/next-AUDIT.md推进kg固体来源Cp与显式关闭反应。旧身份候选未应用的段落为历史。全部本轮root数值/测试进程已终态，Goal active。

当前增量：ProgrammedSolidFluidHeat球形对流/辐射已复用实际外面积与半壳阻力，源19项79.04s通过，Bi=1解析模态4/8/16格RMS0.01337399/0.00330482/0.000815453K、半dt最大差1.64533e-8K。首轮30s/格资源失败已保留，仅按实测将该验证预算升至90s，误差门槛不变。独审28旧平板golden逐位一致、3独立物理检查通过。安装扩展检查初29通过2陈旧fixture失败，已保留旧版同失败并修为真实构造主机，4项wrapper专测通过1.12s；107实际安装模块匹配。报告：[球形程序边界](research/sphere-surface-v1/REPORT.md)。65244/52866/25491均终态，无该批运行进程。

新发现既有软件缺陷：ProgrammedSolidFluidHeat包装规定变形主机时，motion._reference_state的CurrentSlab七数组无法被身份编码；旧HEAD同样失败，未进入surface。修复候选只在/private/tmp/brick-current-slab-identity-candidate，13tmp测试通过、独审中，尚未应用。下一先修复此实际阻塞，再按已保存[质量基内核审计](research/sphere-surface-v1/next-AUDIT.md)实现来源Cp适配与显式ReactionDisabled；不能靠虚构A/B和域外298.15K填补原泥储能。完整材料、全湿烧冷、三机制实测留出、多代和使用验收仍未完成。上一回合提交6d05c43属progress，本回合实现/验证/缺陷定位同属progress，Goal保持active。下文旧状态保留历史。

最新实际增量：Nylen2024 Figure8已提取43个明确可辨内部温度符号，独立SciPy连通域/Fraction坐标复核通过；不可辨平台保留缺项，读图界不是实验标准差，全部为development数据。固定球壳体积/面积/半壳阻力已接入原RigidFluidHeat/SolidFluidHeat和既有integrate；4/8/16格解析模态RMS约0.0493323/0.0122302/0.00302994 K，最细时间步减半差3.44535e-6 K。非editable实际安装四组相关测试55项34.20s通过，107模块源/安装字节核实，session85588已终态0。证据见[球形传热与温度读数](research/nylen2024-radial-v1/REPORT.md)。这是制造物性的数值验证，未完成Nylen材料预测、原泥湿烧冷全流程或原Goal验收。

下一具体实现为共享表面对流/辐射求解的球形半壳阻力接线；当前球形程序边界/液体输运/平板变形明确拒绝。MSJ/CB同材料Cp/k/湿输运/实际热边界与收缩仍缺，不能拼接Rosheim/Arlabosse参数。上一说明prompt回合没有新增实现；本回合实际审核/安装验证/证据落盘属于progress，Goal保持active。以下为历史状态。

当前实际进展：Amadou2006 Rosheim原污泥的Oswin解吸关系已正式实现`amadou_desorption.py`，原始k/n与两个温度点独立核读，打印域不等号/百分号冲突显式保留。源28、独立28+3、安装28项均通过；实际安装aw0.4/30°C得到Xeq0.09461588564kg/kg并输出三节点追溯。16个原实验符号用SVG重建并经独立Fraction/mpmath复核，全部打印拟合落入保守图示包络；这是原作者拟合重建，不是新留出。报告见[解吸实现](research/amadou2006-desorption-v1/REPORT.md)。原PDF/SVG仅忽略缓存，元数据8070dddb固定，未改既有水资产或接入整体U。

新公开证据：Nylen2024合法全文已取得并核读，data/sandbox/research/nylen2024-drying/source.json保存Table2十组条件，独立审计通过；首行编号为空、run1为本项目行序ID，22内部温度/22质量试验分开，18表面温度记录不额外算独立试验。已隔离摘要工艺/气速冲突、未定义MR、Figure3/4缺原料身份、Table3直径缩率矛盾。下一具体工作以明确MSJ/CB的Figure8/9温度场对照为目标，事前定义新条件划分并取得同域热湿本构；不能把Rosheim/Wang/Nylen参数拼成同材料。解吸热/连续T/动力学仍缺，完整原Goal保持active。本轮属progress；所有root安装/测试已终态，无运行进程。

最新科学进展：Wang2021真实干燥数据的D1三参数一维扩散假设已完成实际校准和一次温度留出，结果未满足事前登记的图示一致性条件。方案先提交088a841，40/60°C校准117点后锁参，50°C留出57点；训练/留出RMSE分别0.099318/0.082112 MR，101/117和41/57点超出原读图界加1e-6数值余量。九起点均收敛但Ea均近150000 J/mol搜索上界，未拓界或重新拟合。独立高精度差小于6e-13 MR、保存统计审计通过；这些只支持计算记录，不授予真实材料资格。

实际两进程均exit0、无超时且已回收，root无运行进程。完整结果、174点源图比较、复算脚本和独立审查见[Wang留出报告](research/wang2021-drying-holdout-v1/REPORT.md)。归档116成员5360933bytes，SHA256 ee51cbf37f0057886b8d2bd96d18c0361d299563a3ff960a0b50b5c003d13b7a，逐成员解包复核；含28冻结输入副本。下文“尚未拟合/解锁”是已完成前的历史，禁止重跑为新留出。

事后凸性诊断：仅t>0时12曲线均无区间不相容见证；包含定义初值时40°C/RH60%的0/20/100min有0.0046132 MR间隔见证，独立复核17013个三点组合。不能解释全部50°C偏差、确定遗漏机制或冒充统计拒绝。下一实际工作转向有来源支持的热启动/含水相关输运与吸附/几何变化，先确定可辨识观测和新验证边界，再构建耦合候选；50°C现已看过，不能重新称全新留出。完整原材料/湿烧冷全周期/三机制公开验证/空间/多代/应用要求不变，Goal active且未完成。

最新正式实现：native controller51325b50/helper1a7f13d2/test22d0ee81已应用；独立14+2测试及默认parity通过，正式source14项127.33s（98355终态0），安装3关键集成项41.90s（72337终态0），105模块源码/实际安装全等。证据research/water-native-controller-v1已逐成员归档。仅编排测试使用instrumented session，完整原生controller尚未执行；新codec/service/resume未准入。

最新原生测量：新tiny-positive库存制造案例2forward+1pair完成（73780终态0，whole6.920674/external7.045134s），254源/104旧安装身份前后相同，独立保存结果审计通过，全部254输入副本已保。research/water-native-near-event-initial-v1（310成员7342863bytes，ff85aed3）归档逐成员核实；两tau约0.0001998285/0.0003998356仅诊断，未定位事件。旧104执行冻结不能拿新105安装继续跑。当前root无运行进程。

下一实际工作：Wang2021真实干燥温度留出检验正在/private/tmp/brick-wang-drying-holdout-v1/candidate实现；source_review核允许有限一维MR假设，numerical_review独立数学审查中。固定40/60°C校准、50°C留出，尚无数据拟合/预测/解锁heldout；PREREGISTRATION_DRAFT定义三参数Robin扩散、原图读数/未知实验误差分开及固定120s训练预算。root仅为独立高精度oracle在隔离环境新增BSD mpmath1.3.0，其余既有依赖未动。须先审查冻结数值实现与源/参数/训练计划，再实际拟合并锁参数、最后单次留出。完整材料/全湿烧冷/三机制公开对照/空间/多代/应用验收保持原合同未完成；本轮属于progress，Goal active。

继续进度（证据提交d3d25d3之后）：native_controller_candidate仍只在tmp，尚未应用/安装/原生运行。作者已复现并修复比较失败时丢失先前完整比较行的RED；ref/path本身原已保存（Stop继承ValueError，已更正初判）。新pure测试与冻结待完成，之后交Ptolemy独审。Carson只读保存轨迹计数：原四路径共396host/36ordinary/8terminal/116chargedpanels；同网格native压力预计98query/392proof，实测外推约40.6分钟而非上界。因此先设计并冻结新正液库存短时耗尽制造案例，只测初态forward+一次pair observation；尚未批准或运行新native，不直接放大全controller预算。成本与审查合同在tmp native_controller_cost_review、native_controller_review；完整Goal仍active且未完成。

最新完成：ordinary native full/fine保存证据独审PASS，9callbacks/18cell观测的U/误差、三path原strict守恒及全six比较、4query的Krawczyk/机械角点/全tube/native体积界均复核。源252/安装104成员字节保持；没有重跑native。证据正式归档research/water-native-stage-actual-v1（318成员8079937bytes，全部成员逐SHA解包核实）。原生session83328与tests3803/50006已终态，当前root无运行进程。HEAD726362a已保存正式实现；下一仅tmp native_controller_candidate在实现，未准入。完整科学与软件Goal保持未完成，active。

最新实际进展：session/provider_v2/seed与native stage已应用（stage6ece806a、session7a7e8376、seedf0061733、provider768c4d23），正式源码110项20.23s/安装110项20.07s，104安装模块与源码全等。独审组合46+stage2负控、session13+3负控通过。原stage policy/initial变更两个HIGH实际RED与runner import路径HIGH均已修并保原字节。

唯一ordinary native full/fine实际attempt01完成，root session83328终态exit0/reaped，whole62.257310250s/120、trial60.742858917s/90、外62.378195833s/130无timeout；2initialforward+9host、4freshqueries、seed20/proof16，252source与104membership前后相同。冻结audit_stage.py e7ae独立重算原六gate及逐path原strict全局/局部守恒全部通过，pressure比较0.005876366498482038Pa<1Pa，其余门槛亦保原值。完整原生数学4query保存证据正由Ptolemy复核，尚未终归档；禁止重跑该attempt/native或poll旧handle。actual数据tmp native_stage_study，252原输入副本已保存。

pure证据research/water-pressure-session-v1（20成员22575bytes）与water-native-stage-v1（42成员39309bytes）已逐SHA解包核实，待阶段提交。下一Tesla只在新tmp native_controller_candidate实现共享session贯穿所有事件/独立路径的optin接线，尚未审或应用。完整Goal原材料/全湿烧冷却/空间/三机制留出/多代及使用验证仍必需未完成；当前属于progress，Goal保持active。

最新：新鲜cell0实际查询保存结果已独立Fraction复核PASS，无HIGH。source247/安装101/全部冻结副本、原U与epsilon门槛、共存Krawczyk/机械压力角点/四盒完整tube/固定native体积误差及精确radius均核实。全证据正式归档research/water-fresh-pressure-query-v1，含下一接线方案；所有归档成员逐SHA解包核实。没有重跑EOS。session21184已终态，当前root无native/测试运行。原条件性声明与原完整Goal未完成范围保持。

最新实际增量：fresh_query唯一受监督attempt01完成，session21184终态exit0/reaped，无timeout。全8.374428209s/60，外部8.450848292s/70，host6.480168s完成2initialforward+1pair，seed5，四proof1.344589084s全部完成；tube31求值16叶、fixedquery4。cell0压力Fraction约0.0032806839757006973Pa，原完整T/U/Cp/体积条件保持，247source与101membership前后一致。保存结果正在Ptolemy独立Fraction复核，尚未归档，不能重复native或pol旧handle。原fixedinput副本已存fresh_query/frozen-inputs供归档。

HEAD121f659（pressure consumer），前4f517dd（5数学原语+Capone来源）。Carson已在新tmp pressure_session_candidate实现统一seed/proof/caller累计预算及结构化失败；只候选不改当前安装/旧freeze，尚未审/准入。下一实际acceptance为ordinary full/fine原六gate，通过后才接controller/event，完整原Goal科学与软件范围不变。

最新：conditional pressure provider已按643c6c2a/test44077055应用并非editable安装（101模块）。独审25项0.42s，源码64项1.48s/安装64项1.52s通过，sessions76083/1323终态。MEDIUM失败时丢原始snapshot已修，旧冻结/RED保留research/water-pressure-consumer-v1（36成员41520bytes逐SHA核实）。尚无stage/controller准入。fresh_query当前freeze b810a64c（247文件101模块）已生成，最终runner独审中，尚未执行native。

最新：五个water区间原语正式应用，源码43项1.30s/安装43项1.27s通过，实际100模块成员及字节匹配。独审MEDIUM测试写fixture已修，完整旧失败/映射/许可/审核归档research/water-packaged-primitives-v1（45成员69754bytes，逐成员SHA解包核实）。sessions65059/95436均终态，无root native运行。

Capone2025公开污泥热预处理原文已核读，Table2干基原值/3节点来源链落data/sandbox/research/capone2025-endpoints-v1，实际安装trace及原100.1%舍入行保留；原文SHA bff7a1e488bdc810a0da0017113c542ef0f0dbb8d6133f68032c57edb8f7b9f0。Fermi热估算/Dulong热值不能作实测反应热；凝液单位/最大值冲突隔离；三次补充材料入口失败已保存。仅同批预处理污泥终态验证候选，未准入材料或完成外部验证。

Carson pressure consumer冻结后独审发现MEDIUM：输入变更失败时丢原始快照，正在tmp修复，尚未应用。Root fresh_query中新300.125/305.25K实际host→cell0压力证书runner/seed候选准备中，whole60/query30/proof20/external70预算事前声明，尚未完整冻结/执行。不要把已保存16 PASS作为新查询准入。Goal全材料/全湿烧冷却/公开三机制留出/空间/多代等仍未完成，保持active。

最新：全16保存端点唯一受监督研究全部通过，内部28.420998/60s、外部28.524549/70s，source前后保持，496tube/64fixed-query求值；独立Fraction逐16复算通过。research/water-all-saved-correspondence-v1保存201成员归档及消费者接口计划，所有成员解包SHA核实。session44010已终态，不重poll；这不是连续轨迹/全局相/全部native误差认证。

mixed exact_record已按8b59ac0b/test7c53a7a1应用，18源码2.70s/18安装2.72s、独立21项4.08s通过；95实际安装模块及全部原测试/水资产清单/字节与前后匹配。两HIGH（全局上下文与普通state能量身份）实际RED保留并已关闭。

唯一实际制造轨迹controller29.812730s完成18面板2事件396回调。原capture在报告pack(MixedReplayAudit)处失败，原record40763391bytes及所有数据已保存；之后仅从原记录离线续审9.590764s通过，export逐字同SHA52bef9f423a93ffa4917966ab9fd67fa14f51ba49670392ce050d1174d1797a8。18accepted/4refs/80checkedpathsteps/8projections，partial_audit明确5unknown与noresume，独立保存数据核验通过。sessions88150/4490及tests71834/9310均终态，勿重启轨迹或poll旧handle。证据research/mass-wet-exact-record-v1；所有原失败保留。

下一Carson仅tmp consumer_candidate实现source-supported普通液水分支的逐query压力证书（完整T/原误差条件/同一tube覆盖native query root）。来源允许显式物理分支假设，不要求所有物相全局唯一性；仍须严格query数学包围，六gate不变。候选未冻结/未审/未应用。mixed完整根/六差值审计、service/resume、原污泥全材料/全周期/公开三个机制留出/空间/多代仍按原Goal必需未完成。当前有实际实现与验证进展，Goal保持active。

最新已落地：research/water-saved-output-correspondence-v1归档最大误差端点实际T区间连接和固定native输出数学偏差；两项独审均通过（native7pure及全部保存Fraction复算），原窄根盒/前置绑定失败均保留，全部归档成员SHA解包复核。没有修改生产内核或安装，仍94模块/3c85dce数值实现。当前无root EOS/测试运行；84575终态勿重poll。

Tesla的all_saved_correspondence仅准备全16统一研究runner/事前60s预算及70s外部watchdog计划，尚未运行；Carson的mixed exact_record候选已冻结，待独审及真实完整轨迹导出/离线审计，未应用。完整科学/软件Goal范围保持未完成。下列“待独审”表述是归档前历史，以上两项已完成独审。

当前实际增量：HEAD 3c85dce 后没有改安装/求解器。最大saved inverse epsilon端点step8/cell1已选定并核原T±epsilon/targetU/bracket。actual_inverse_connection/study01原1e-6液log盒严格K包含失败（.455179s），原结果保留；独审允许仅扩大数值根盒到4e-6后study02实际通过1.638728459s，31次tube/16正导数叶覆盖全实际T。session84575已终态，不重poll。新结果在tmp等待保存数据独审与归档，不能用单点冒全部16或native准入。

独立native_output_candidate的step8/cell1保存原生密度固定查询已实际通过：4数学EOS求值，.124s量级，公有mol体积数值误差加实际host舍入约1.62099e-20，小于原1e-16声明；第一次仅runner把gas mapping当scalar的前置失败保留。无新native调用；已交独审。Carson mixed record候选11纯测试1.37s通过，未冻结/未审/未应用。Tesla仅tmp准备全16固定顺序统一研究runner/预算，尚未运行。根源/误差声明与完整Goal科学要求保持不变。

最新：完整mixed exact controller已按7e9bd6d3/mainbe021e80/helperbc05a282应用；源码77项77.65s、实际安装77项76.75s通过，XML零失败/错误/跳过，94实际模块匹配。独审7+9及应用核验通过。research/mass-wet-exact-controller-v1保存31成员及原失败，逐成员SHA解包核实。sessions30695/66749均终态；当前root无运行中的测试或EOS，不重poll。制造解析液体两次耗尽及干态尾完整通过；整个请求区间一个原子packet，尚无mixed codec/service/resume。

真实水数学共存/连接研究已归档research/water-coexistence-connection-v1（119成员），原3/6与加权5/6共存盒、所有原失败、不可变绑定修复、源码/原始HEOS JSON/许可及独立复算保留。connected session47230已终态：T300±1e-7K、31次/16正导数叶完整覆盖，tube1.099692s/15s，whole1.208409s；独立Fraction复算通过，原歧义带后压力余量>1007161.7809Pa。温度是声明研究扰动，非U inverse误差；global phase/native error均未准入。

下一实际工作：Carson仅tmp exact_controller_record实现混合单位运行记录/导出/离线审计候选；Tesla在tmp native_correspondence_plan推导实际inverse T与原生provider误差衔接条件。候选未审核、未应用；完整材料域、全湿坯到烧冷、三个公开机制留出、空间/多代和统一界面仍按原合同未完成。当前回合有实际实现与测试证据，属于progress，Goal保持active。

最新exact_terminal已应用4f186cfb/test7d0242c4；63源码11.13s、63安装11.27s通过，93实际模块匹配，独立13项及应用核验通过，research/mass-wet-exact-terminal-v1归档逐成员SHA重读。sessions26269/97809均终态，不重poll。所有root原生EOS/测试已结束。

Carson在/tmp/brick-mass-wet-integration-v1/exact_controller继续完整两格湿湿→干湿→干干控制器（两连续pass+独立halfapproach、全六gate、模式lineage与原累计totals不重置、原子packet）；尚未freeze/准入。Tesla在/tmp/brick-water-pressure-interval-v1/coexistence_candidate实现参数T的两log密度共存残差/Jacobian及Krawczyk数学候选，纯解析无EOS。来源接口依据已保存research/water-pressure-interval-v1/phase-admission，核读原IAPWS/HEOS，辅助饱和式只作初值不代证书；整个295..310K稳定分支还未求证。

最新：writeback提交b671032；源码/安装92模块验证已完成。Root压力区间研究已保存research/water-pressure-interval-v1，全部成员SHA解包核实；actual study02 session24604终态exit0，16端点1.413235750s/原10s内，全16 Fraction复核通过，原8项下舍入RED保留。当前无EOS/测试进程，勿重poll45617/63760/24604。源码数学原语尚仅研究归档，不宣称stable/native误差认证。

下一连接层exact_terminal4f186cfb/test7d0242c4在tmp，11pure2.58s通过，Tesla正独审；内部actual两callback→严格全根排序→全kg/mol/U积分→原writeback，不切mode/不提交。Python审查者在/tmp/brick-water-pressure-interval-v1/phase-admission核读原来源，推进实际WaterProperties稳定分支和误差接口。原Goal完整材料/全湿烧冷却/公开三机制留出/空间/多代仍未完成。

最新writeback已应用ceb76234/test66ae28a7；52源码8.97s、52安装8.79s通过，92实际模块匹配，独立28项及应用核验通过。证据research/mass-wet-writeback-v1。sessions83016/19861终态，不重poll。exact_stage已提交c2b9d98；Carson继续tmp exact_terminal实际样本→根证据→全分量账本连接器，未准入。

Root真实水区间研究已接显式public/native质量比（原源M相差1ULP），原单位scale版本保留；16原fine端点纯数学区间通过，但独审发现result01的combined radius8项Decimal向下舍入，RED保留review-radius-rounding01。study02已改Interval.hi并冻结source/所有实现SHA，唯一session24604待终态复核；原source/材料包络和10秒预算不变，没有新native轨迹。不得把局部根/条件原误差包络当stable相认证或材料误差证书。

最新：exact_stage已应用9bd9ffd5/de4ae1d9/guards3b11612c；48源码15.52s、48安装15.90s通过，91实际模块匹配，独立28项及应用审查通过；原HIGH/MEDIUM/RED完整保存在research/mass-wet-exact-stage-v1。它拒绝缺全温P包络的generic wet，不具原生湿事件/续算许可。tests sessions22469/28361均终态，不重poll。

真实水区间研究位于/private/tmp/brick-water-pressure-interval-v1，interval_eos28bcfac0数学原语已独审；新coupled_rectangle通过全T/V矩形面符号和导数正性包围局部P，2pure0.147s，原窄括区失败保留。尚待coupled独审，未作stable液相/实际native误差衔接或生产准入。mixed_writeback ceb76234/test66ae28a7已有独立28pure0.32s通过，尚未应用。

恢复优先：HEAD f45a32a（C host），前提交0559fd7（B native）。当前无原生EOS或测试在运行；B sessions68137/89156与C tests92136/20084均已终态，不重poll。实际安装90模块对应C f12bd910。

exact_stage旧freeze467658a3/test3296082b仅tmp，独审发现HIGH：fixed-T pressure_error不能当同U反解压力总包络；MEDIUM：endpoint回调失败缺已计算new/ledger直接证据。原17测试5.96s及独立5测试2.14s、RED与CODE_REVIEW保留。Carson正在修复：dry解析理想气体传播T区间；wet无全域体积依据明确拒绝，只允许完整绑定且明确制造常数液体契约的纯测试，不把HEOS伪装成常数水；补全未提交attempt证据。新freeze尚待复审，不得应用旧版。

Tesla在/private/tmp/brick-mass-wet-integration-v1/mixed_writeback实现kg/mol分离的局部耗尽投影与原修正门槛，只有临时候选，无根定位或整事件许可；新增显式本格原初库存fraction<=1e-8是额外数值限制，不谎称旧字段。两名实现者仅tmp，Python审查者待复审；不改原材料/完整Goal验收范围。

最新C host已应用f12bd910/test2906f43e，源码41项14.89s、安装41项14.79s通过，90实际模块匹配；独立15项及应用核验通过。research/mass-wet-depletion-host-v1保存原失败/完整审核/测试并逐成员SHA核实。默认wet保parity，显式dry仅精确0液，strict再凝结/未知域拒绝；没有自动耗尽或写回许可。B已提交0559fd7且原生两档全部终态，旧90原生freeze仍完整归档，不跨新C版本续算。

下一：Carson的exact_stage临时候选正在纯测试，尚未审查准入；必须保持kg/mol/U/T/P/time各门槛并检查全二次面板，ordinary wet严格正液、dry恒0。Goal第11节全部完整范围仍未完成。

最新：B原生4/8步均已终态exit0并回收（sessions68137/89156，不重poll）。同freeze3f144dee、90安装模块、原输入及150s内/180s外预算不变；积分64.535696667/130.575182458s，4/8接受步、12/24完成回调，各接受前缀九项原守恒门槛通过，全局U精确差0。coarse/fine均已独立保存数据复核通过；163成员归档见research/mass-wet-transport-native-v1，逐成员SHA重读核实。未宣称时间阶或空间收敛。下列“正在运行”是历史记录。

C host候选f12bd910/test2906f43e已独立15项9.98s通过，尚未应用；必须等B全部结果复核与归档后才改变安装。Carson在/private/tmp/brick-mass-wet-integration-v1/exact_stage继续kg/mol分离的精确试步候选，尚未冻结或准入。完整材料/湿干事件/全周期仍未完成。

B两格正液动态已应用原审source7b56d8f5/testb825af0c，37源码14.10s/37安装13.98s通过，90实际模块一致，独立11测试通过；纯测证据research/mass-wet-transport-v1。真实水两档实验位于/private/tmp/brick-mass-wet-transport-native-v1，freeze3f144dee（原90runtime/16water/案例与全部脚本），4步coarse正在工具session68137执行，尚无完成结论。必须同handle等待，不重启；终态核全prefix后才允许同freeze8步fine。原.01s、每档180外/150内预算固定，跨两档不可改source/安装。

下一C host候选由Carson在/private/tmp/brick-mass-wet-integration-v1/depletion_host准备，Python审查者等待freeze：是B的明确diff，默认全wet保parity，新增逐格精确零液dry与strict再凝结域退出，不授event/writeback许可；尚未repo应用。真正湿湿→干湿→干干同一kg事件积分与全部原门槛仍需实现。

湿质量储能A现已实际应用：mass_wet_storage60f6ec5d、test481e2378；库存负数/非零下溢HIGH已修、6RED保留，来源聚合RED修复。14正式+独立23通过，46源码7.43s/46安装7.49s通过，89实际模块一致。证据research/mass-wet-storage-v1。

实际HEOS一点v1因1000Pa不稳定液相正确拒绝，原失败完整保留；经独审在新v2仅把压力下界收紧为10000Pa（原温度/库存/容差/90s保持），真实前向/反解与独立Brent/能量对照通过，runner4.080275834s、supervisor4.301904792s exit0/reaped。全89runtime及输入前后不变，独立保存数据14样本/全部Fraction门槛复核通过，见research/mass-wet-native-v1。native sessions43298(失败)/9452(完成)均终态，无EOS仍运行。

下步B候选 `/private/tmp/brick-mass-wet-integration-v1/transport` 已冻结source7b56d8f5/testb825af0c，作者7tests6.86s通过，正在wet_storage_review独立审查，尚未repo应用。它在同一kg湿储能上实现两格有限O2/相变/3气体传输，仍仅正液短轨迹；审过后应用/实际验证，继续C单位分离的耗尽/干态共同终点/记录审计。Goal原材料/全周期/三机制公开留出/空间/多代要求全部保持未完成。

同质量基准湿态接入正在实现：候选 `/private/tmp/brick-mass-wet-integration-v1/candidate/mass_wet_storage.py`，尚未repo准入或原生执行。新增可追查水元素名义约定 data/sandbox/research/water-element-convention-v1，CIAAW2024原H/O值实际核读，Fraction分数672/6005和5333/6005、有限摘录SHA均独立复核；不替换实际EOS M、不宣称同位素测定，水化学计量必须0。独审和接口设计见research/water-element-convention-v1。湿态需完整传播固体占积→压力→液体能量误差，旧干公式不可照搬。原生一点前向/反解计划在/private/tmp/brick-mass-wet-native-v1，代码/纯测审查及正式安装完成后才允许运行；原90秒和能量门槛保持。

两格质量传输现已接入：mass_transport_bridge d9d532c2、test04673c96，32源码7.34s/32安装7.23s通过；88实际模块一致，独立原8项及应用复核通过。共同面传质/焓流/导热、有限O2与共同总U反解实际耦合，参考能量同时输运；证据research/mass-transport-bridge-v1。仍是制造刚性干态，湿态和全周期未完成。

旧87模块UI进程89834/session60913已核身份后SIGINT关闭，终态130/KeyboardInterrupt发生在空闲serve_forever；两个原计算子任务此前均已回收，非模拟失败。随后才安装88模块，当前无旧UI监听承诺。下一工作正在/private/tmp/brick-mass-wet-integration-v1设计同一kg基准的液相库存/占积/储能/蒸发接入，不能把现有mol固体湿态直接冒充质量桥接。

最新精确服务及界面已实际应用：exact_run_service 643511f3、run_service 4ae72fef、app.js 6a05da78。源码/安装服务各76通过，前端各16通过，独立服务20/前端22通过，87实际安装模块一致。构建前取消及未知时间schema两缺陷已修复，RED保留。永久证据 research/exact-service-v1、exact-service-native-v1、exact-ui-v1 均有逐成员核验归档。

真实水服务取消1步→续算30步/2事件→重放30步/2事件全部完成且回收；续算/重放全部非墙钟核心字段一致，19处耗时差异保留。实际浏览器另取消13步→续算30步，比较/来源展开/完整导出通过；5,766,261字节可见报告中的5,035,493字节规范记录与磁盘逐字节一致。所有EOS子任务终态；本地UI监听8767（工具session60913）仍供查看，不是公开部署。完整操作见 EXACT_EVENT_APPLICATION.md。

下一执行：审查通过的 `/private/tmp/brick-mass-transport-bridge-v1` 两格kg固体/mol流体传输候选（source d9d532c2）尚未应用；核最终冻结后做源码/安装验证并接入，继续湿态、真实材料闭合、空间验证与全周期。Goal第11节全部范围保持，制造固体短时服务成功不等于真实污泥烧成模型完成。以下旧候选状态保留作历史，以此入口为准。

混合质量热桥已实际应用：source cc98bc97 / portable test 5a612eec，三审查HIGH均修复并保留RED；68源码3.05s/68安装3.01s通过，86实际安装模块一致。实际kg固体/mol流体、有限O2、共同总U反解T/P；无双计反应热。证据 `research/mass-storage-bridge-v1`。仍是制造固定单格干态，非完整材料。

同研究GNEST干固体燃料库存来源链已落 `data/sandbox/research/gnest-char-energy-v1`，4节点实际安装trace、原全文及Fraction独立复核通过；热值保留真实MJ/kg并显式转J/kg。端点5.376063/2.951553 MJ/kg干进料不冒称反应热，完整原泥准入仍不满足。证据 `research/gnest-char-energy-v1`。

服务候选独立70测试37.72s通过后，代码审查发现exact续算在build前取消时误继承parent presentation而没有child canonical记录；仍tmp未准入，正在修复并保留RED。下一步继续服务修复/独立审查及实际安装生命周期，随后推进湿态/输运与真实材料闭合；Goal全部§11范围保持未完成。

已有诊断失败测试合同已修复：保留accepted末状态原值的直接检查，同时最终trace在无final_snapshot时返回unknown。生产逻辑和门槛未变；47测试通过，独立审查通过，原baseline失败及GREEN XML见 `research/diagnostic-trace-contract-v1`。Mixed候选d09暂不准入：独立元素交换负控发现可把named O2错误声明为C但仍过内部配平，已交作者修复。精确service候选冻结643511f3/目录04da3c78，正在root overlay回归；尚未repo应用或原生安装验证。

质量参考原语现已实际应用：`reaction_reference.py` 52511676、正式测试 efbf0109，16源码/16安装通过，独立最终18测试通过。原不可变network完整保留，未知热不填零，anchor温压/相态严格绑定；实际安装85模块一致，制造例子验证依赖反应热−30且未知组分焓拒绝。证据 `research/mass-reaction-reference-v1` 含24成员归档及逐成员核验。此增量尚不是实时热学provider或真实材料闭合。

下一工作已有实际候选：`/private/tmp/brick-mass-storage-bridge-v1/candidate` 的固体kg/流体mol同总U反解与有限O2短时耦合正在补负控及复审；`/private/tmp/brick-exact-service-v1/candidate` 的精确运行/续算/重放/追溯正在补完整raw导出再冻结审查。后者旧诊断测试失败已在基线独立复现，不可隐藏。尚未应用这些候选或宣称CLI/UI完成。原Goal§11实际材料、三个机制公开留出、全湿烧冷却、空间验证、多代实验和完整使用交付仍未完成，Goal active。

同新版本精确续算已实际完成（基线a8a6aae）：driver5c06f392/admissiona3819fba，portabletestf1753143+baselinebe323；65源码47.41s/25安装15.11s通过，84实际模块一致，代码/数值独立审查通过。原initial/start/end/fullpolicies、全历史/修正/schema/cost与累计wall保持；on_commit仅全局原子提交后通知。四fresh审计+restore实际入场，不从partial报告授许可。证据research/exact-continuation-v1（90成员，含原RED及独立结果复核）。

/tmp/brick-exact-continuation-native-v1实际PhaseA session62924已exit0/reaped：cancelled1step/0packets/9eval，core1.358061333s，parent9b4b6eba18aee151843efd2cc097a3399b864ef37b14f40a1af926b41d3f5a47。PhaseB session25676已exit0/reaped，supervisor84.099186s：completed30steps/2packets/685eval至原end，累计79.548731666s，79charged剩433/100reject，recordf33e5df59b064218d0790b2b372ba68d7d417fe7968412703cad90a4bea11285。父历史一次保留、4audits/reencode/原84runtime前后一致；独立复核旧78与新84网格/状态/账本及全部非wall字段全同，19项elapsed差异保留。root无活动EOS/测试，不重poll62924/25676/18903/80522。冻结202输入未改，不冒称旧78记录被跨版本续算。

质量基准能量参考评估已保存research/material-energy-reference-v1，两个一手来源root核读；允许同材料计量+反应热差+一致参考的质量表示，不能抹掉反应热或混入未桥接NIST零点。新的reaction_reference候选在/tmp/brick-mass-reaction-reference-v1（最终anchor状态绑定source1a043d63/test47bd1b7a，14pure；前版独立100精确系统数学核查通过），仍tmp待最终审查/应用。下一可执行工作：核最后anchor复审与应用该质量参考桥接原语，并继续精确路径服务/CLI/UI父子记录生命周期、长时空间验证及实际材料闭合；不能停留在原语。原Goal§11的材料/3机制公开留出/全湿烧冷却/空间/多代/最终应用完整范围仍必需未完成，Goal active，本轮有效progress。

精确数值恢复已应用（基线447649b）：exact_projection_restore6c5ec48f/test75dfbe4f，固定数值白名单、fresh外部实际绑定、完整pack不变、committed terminal ledger与accepted step同对象恢复；历史Observation明确EvidenceNode无伪inverse。27源码22.15s/8安装10.22s通过，83实际非editable模块逐字匹配；独立代码审及8pure通过。35成员完整证据见research/exact-projection-restore-v1。

唯一actual restore session30141已终态exit0/reaped，原supervisor3.436563125s：原strict30steps/2packets/2aliases完整恢复，重编码4,192,254bytes全等ac03be01；actual82/old78严格四verifier新增allowlist与原所有模块/非模块字段一致，input/runtime前后保持。独立结果审查已完成。没有integrate/resume，之后83安装身份另存，不能把只读兼容作为跨版本续算许可。root无EOS或测试在运行，不重poll30141/47040/89005。

下一实际实现正在/tmp/brick-exact-continuation-v1/core由Averroes准备：同新版本权威parentbytes/hash、原initial/start/end/policies与实际runtime绑定，fresh四审计+restore，seed全prefix/histories/corrections/schema/costs/cumulativewall；纯取消/反复续算/资源用尽零物理callback及未提交细化成本测试。尚未repo准入、未宣称续算已完成。Carson准备NATIVE_PLAN，只在候选审查/安装后执行同版本新parent→resume，不复用原78执行身份。原Goal§11完整材料/公开3机制留出/全湿烧冷却/空间/多代/CLIUI仍必需未完成；本轮有效progress，Goal active。


终端/比较/资源三个exact审计已应用（基线d00a89a）：proof ff991e94/test8af128、comparison 1cef63c3/testf4064bb、resource c1bfaabb/testef45b0f6；独立代码审查关闭粗解锚HIGH及3个resource低报HIGH。原RED/修复前源码/实际测试与95成员证据见research/exact-record-gates-v1。31+13源码相关测试通过；最终37安装34.83s通过，82实际非editable模块全部匹配源码。安装检查器首次漏传输出参数IndexError，随后按原接口提供路径成功；不是模块不匹配。

实际宿主proof唯一运行exit0/2.10263s，2terminals/2candidates/1exclusion；comparison唯一运行exit1（runner误断言1packet），函数实际已返回2packets/6compare/24cert/24endpoint，原8refs独立重数一致，后续仅数据核查，不覆盖原FAILED或重跑。两者实际79与原78严格只读singleton兼容及全部input/runtime前后不变，完整独立结果审查已保存；不冒称最终82曾运行该native。资源纯原记录审计.25273s pass：原累计79charged/433remaining/100remainingreject，原elapsed完整保留，无EOS。root无活动EOS或测试，不重poll22182/12409/14366/25825。

下一明确实现：/private/tmp/brick-exact-continuation-v1/exact_projection_restore.py 6c5ec48f/test75dfbe4f候选8pure及独立8pure9.79s通过、CODE_REVIEW批准，仅固定白名单恢复数值对象和actual modes/source，frame terminal ledger与accepted step同一对象修复原id关联陷阱；未repo准入、无续算授权。接下来组合完整审计/原记录恢复、保持原initial/time/policies/全部prefix/corrections与累计资源，实现真实取消续算及一次拼接，保留科学边界。原泥材料闭合、公开3机制留出、全湿烧冷却、空间收敛、逐代与CLIUI全部仍必需未完成；Goal active，本轮实际progress。


原始exact前缀审计已应用（基线0fdc06f）：exact_record_audit fb8e9a23/testca0ff0ba，fresh规范字节和外部原initial/time/policies/实际host绑定；全prefix N/E/sharedface/components/stretch及已选terminal写回、累计预算重算。40源码23.98s、26实际安装23.83s通过，79实际非editable模块逐字匹配。审查/原RED/32成员完整证据见research/exact-record-audit-v1。

安装前实际原78宿主审计已exit0（session64876，监督2.1953s，audit0.5147s），没有重复原77s积分；30prefix/2events通过，六项Fraction最大残差与独立原prefix审计完全一致。78原运行+单独hash绑定tmpaudit与后续79安装身份分别保存。仍resume_authorized=false。

当前继续工作：terminal proof ff991候选已独立审查，Averroes在/tmp/brick-exact-proof-native-v1按严格78→79只读兼容检查准备实际原record复核，不执行积分或续算。比较候选在/tmp/brick-exact-record-comparison-audit-v1发现首coarse标签绕过原步长HIGH，Carson修复中；资源候选在/tmp/brick-exact-resource-audit-v1发现refinement/committed不重叠工作漏计HIGH，root修复中，均未repo准入。完整续算仍待全部门禁和累计资源、原前缀一次拼接。原泥材料、公开三机制留出、全湿烧冷却、空间收敛与逐代/CLIUI全部保持必需未完成；Goal active，当前实际progress。


严格record与来源比热应用检查点（基线23a2ba4）：exact_record18fc9628/teste5c0993，保留源快照/完整schema数值projection、immutable arrays、strict类型/shape/每已commit state-ledger-mode-correction关联、fresh live binding返回；真实WaterState闭包、合法int1policy与全部HIGH攻击已修，原RED保留。89源码18.21s/39安装12.39s通过，78实际非editable模块与源码匹配。ArlabosseDryCaloric42e828/testf606bd同包应用，真实已核Eq2+kg干基+35–105°C、精确Cp与Δh两节点来源trace，实际安装例子已存；仍无formationH/Cv/摩尔材料准入，不冒全周期参数包。

新strictcodec native2cell session95900已terminal exit0/supervisor79.516s：原2cellcase/初态/政策保持，显式ordered，core77.250s completed30steps2packets2events1→0；685eval/8terminal/24pairedendpoint。strictrecord4,192,254bytes encode/read/消费freshchecked source绑定成功0.690s，78runtime保持。原prefix/energy审计无字节修改实际pass，global9.99353e-11J/constraint1.26425e-20J均原2e-8J。完整比较审计与独立结果复核已pass：8refs/6compare/24cert/24endpoint，strict全部accepted times/states/ledgers与fallback独立对齐；证据research/exact-record-native-v1。无root native/测试进程，不重poll95900/61695。

下一明确工作：Carson在/tmp/brick-exact-record-audit-v1实现原始全prefix审计候选，外部原initial/start/end/policies/source严格绑定，保存累计N/E/stretch/components/correction预算不重置；尚未repo准入。严格record结构与source复核不授resume许可，后续全numerical/refinement/root审计、恢复实际operator、累计资源和exact前后段一次拼接仍必需。8格短时事件已支持，但长时4/8空间收敛、原泥材料闭合、公开3机制留出、全湿烧冷却、多代/最终CLIUI验收均保持原范围未完成。Goal active，本轮有实际实现/两native/来源组件及独立证据，属于progress。

最新8格实证（基线b49fc57）：同物理parent初态与.5→.50032，grid4→8及4个局部extensive数值量减半显式入新case，原global2e-8J及全部event/source gates保持。session61695已terminal exit0，supervisor395.34s/core392.31s，completed36steps2packets8events顺序7→0，781eval/32terminal/528pairedendpoint。全部76runtime保持；原prefix/energy审计无字节修改实际pass，globalmax9.55378e-11J、constraint1.86335e-20J；8适配comparison审计pass，384purecert/6compare/8refs。证据research/exact-eight-cell-v1。无root native进程，不重poll61695。这是短时8格事件支持，非空间收敛；旧15us FAIL与完整原泥/公开留出/全周期范围均保留。

当前exact_record候选f03abafa修复真实WaterState闭包/嵌套shape/机械字段/六gate类型/immutable bytes与fresh verified return，18纯测和独立代码审通过，数值终审待核；Arlabosse来源绑定Cp与独立积分trace组件42e828已源审，portable tests收尾。均仍tmp，非本次76运行源码。Root新增material-closure-next-v1只读材料缺口与原文图核查，非整包准入。后续推进严格record审计与续算、长时空间矩阵及真实材料/三机制公开验证，不缩Goal。

最新完整exact packet检查点（基线be2f48d）：新exact_depletion_integration sourcebe323c82/test3e96e5a5，实际完整ordinary→terminal→mixed continuation→每event/common六gate→连续2pass+独立pre-first-grid→原初全prefix→原子commit已实现，代码/数值审查通过。明确新independent_halved_controls_no_spine_reuse策略，所有计算计费，不冒称旧cache使用。76源码11.33s、46安装6.59s通过，76实际模块匹配。

原四格case/initial/policies保持，attempt01/session39872已终态exit0：supervisor172.1024s/runner171.7776s/core170.1767s，completed，32接受steps/2packets/4events，顺序3→2→1→0，exact .50032目标到达、全部depleted_no_nucleation。717evaluations/71ordinarytrials/16terminal/120pairedendpoint，原512panel/800s及全部科学gate未改。旧失败作为历史保留；本次完成显式新精确数值路径，不再停留在单terminal探针。prefix和comparison独立审计已pass，另行32prefix闭合E+peΔV独立审计pass，最大6.16683e-11J、累计abs constraint2.31071e-20J，均原2e-8J；外boundary/body全0实际核查，不由账本恒等式推得。

证据research/exact-packet-native-v1。root当前无EOS/测试进程。新的record候选在/tmp/brick-exact-record-v1由Averroes准备，仅严格版本化numerical record及source/state/policy绑定，不冒称旧服务/续算已准入。恢复先核候选与独立审计结论。后续严格record/audit/restore/resume/CLI接入、原污泥完整材料闭合、三机制公开留出、全湿烧冷却、空间收敛和最终应用全部必需未完成。Goal active，本轮实际progress。


本阶段最终分类修复：native e324成功后发现DomainExit被写为failed，d004b1b7现保留domain_exit（同reason的IntegrationError仍failed）。实际RED1fail12pass→GREEN13；58源码.66s/58安装.75s、75finalmodules匹配；独立复审成功路径未变，不重复EOS。native证据仍绑定e324，before-domain-fix日志/身份及失败审计历史均保留，未混称finald004实际运行。原生完整账本独立Fraction审计通过，ratio3.11236609e-9<原1e-8；只speculative终端，不是packet。

最新实际终端执行器（基线b4d48c7）：exact_terminal_executor sourcee3246434/testa771，完整actual初/mid/endpoint三观测→root/panel/writeback→候选mode；12pure seamtests及57源码.66s/57安装.73s通过，75实际模块匹配，独立代码审查通过。原mass/source/energy/mode内容约束保持，失败/cancel/wall保存阶段/尝试成本，明确不提交原state/op/totals。

实际native01/session30444已终态exit0：45s监督2.55845s/runner2.22706s/core.814022s，speculative_completed，初始Rates与保存旧样本相同、midpoint重新实际采样，cell2根27级，3observations/1predictor/1terminal/1mode；delta4.86807e-21mol/gross1.56410707e-12mol仍原1e-8门槛。原case/initial/source/runtime75/输入state保持。起点已含未提交cell3，totals1→2均speculative，不能称已提交2events或完整trajectory。root无活动EOS/测试。证据research/exact-terminal-native-v1。

下一实际任务：Averroes正在 /private/tmp/brick-exact-packet-bridge-v1 实现完整exact_depletion_integration driver（PLAN已落），直接接exactordinary和executor，保原common/per-event六gate、连续2pass、独立approach/实际不同网格、pairedP真实operator绑定、全局wall/成本/原初全prefix账本及oncecommit。核实际代码/tests/review再原四格全程。旧record/continuation仍未准入，原四格FAILED未关闭。原污泥材料闭合、三机制公开留出、全湿烧冷却、空间收敛和最终应用验收继续必需；Goal active，本轮progress。

最新完整终端面板检查点（基线a89bf04）：新增exact_terminal_panel（全N/E/face/source/components/stretch一次积分与whole-polynomial minima）及exact_root_order（全wet集合/严格根分离/无根排除）。rootorder验证初版bool/int混同HIGH实际5RED后用逐层exacttype校验修复；source1cc3/testb925，panel2fdf。68源码5.18s、36安装.40s通过，74实际模块匹配。完整原failedpanel安装版重放选cell2、排除0/1、26级，原修正比例9.2264e-9<1e-8；全部积分独立复算。不是新的完整trajectory。

实际native01/session18952已终态exit0：45s监督1.8402s，runner1.5418s。原case/initial身份、replay完整state、exact端点、dry2/3模式，真实water host求值成功；phase率[.0017456959735,.0017457070151,0,0]，来源/runtime74/状态保持。两事件和totals仍属未提交分支，原四格packet FAILED未关闭。root无活动EOS/测试。见research/exact-full-panel-replay-v1及两个模块研究目录。

下一实际实现：Carson在 /private/tmp/brick-exact-terminal-executor-v1 构建actual initial/midpoint观测→fullrootorder/panel/writeback→mode/endpoint观测的完整speculative执行器，需核实际候选/测试/审查；随后原逐事件与共同端点全部比较、连续两pass及独立approach、全prefix budgets和一次packet提交/record/resume。不可停在原语或端点探针。原污泥完整材料、三机制公开留出、全湿烧冷却、空间收敛及最终CLI/UI验收继续必需未完成；Goal active，本轮progress。

最新宿主接线（基线1717de9）：FreeSolidSlab/WPT共享原评估body并提供explicit autonomous exact入口，原float顺序/公式保留。初审发现thermal独立water实现漏绑，actual RED4fail后修复全部provider槽/type/fullimplementation；38源码2.94s、38安装3.01s通过，72实际模块匹配。45s监督native01已exit1/1.91s（旧encode不支持嵌套HEOSCandidate，exact尚未调用），修研究捕获保留全部数值字段后native02/session9900已exit0/2.2378s，runner1.9258s：原四格case/initial相同，legacy与exact自主时间10^12+10^-10的完整1,079,815 bytes输出逐字相同，runtime/source绑定未变。两个native已终态无root EOS运行。见research/exact-native-host-v1；此为真实water+制造solid点对照，不关闭四格event失败或材料验证。

下一具体动作：TMP /private/tmp/brick-exact-terminal-panel-v1 已完成full-state affine panel及5puretests、code review；N/E局部门槛是represented ledger残差，不是exact affine quadrature总误差，midpoint/source真实性由调用方保证。/private/tmp/brick-exact-root-order-v1 Carson正构建全wet-cell严格根顺序候选。先核这两候选实际文件与审查，再整合actual exact observe、terminal writeback/mode、原全状态比较和packet原子提交；不要停在原语。精确单格已提交1717de9、时间积分0c53982。原污泥完整材料、三机制公开留出、全湿烧冷却、空间收敛及最终使用仍为必需未完成，Goal active，本轮progress。

精确单格耗尽核算增量（基线0c53982）：exact_affine_depletion源码冻结8448d319，已移植并获代码/数值独立审查。93源码4.97s、54安装.18s通过，71实际模块匹配。保存cell2旧时钟仍拒绝；新26级有理区间满足原1e-8修正比例，未改物理或科学门槛。本次无EOS；完整panel、根排序、mode切换/packet比较与record尚未接入。见research/exact-affine-depletion-v1。宿主exact入口的热学独立水provider绑定缺口已在tmp修复待复审；whole-state panel候选由Averroes在tmp开发。Goal完整范围仍未完成。

最新精确时间/积分检查点（基线5462deb）：新增 exact_event_clock（规范单Fraction时间/区间、严格codec、独立显示误差）、exact_boundary_program（已校验程序的精确节点/权重、显式全schedule平移）、exact_integration（独立exact SSPRK2/ledger/result；回调和实际求积端点均精确）。原程序/积分器未改；旧kernel/program/checkpoint明确拒绝新时间，未准入新事件/续算/服务。源码185项7.22s、安装132项6.98s通过；原语先前源码/安装64项各.11s通过。当前70实际安装模块匹配源码，三个模块及测试已获代码/数值审查。

所有actual stage/endpoints保持Fraction，未来名义步长明确向下量化以阻止有理分母爆长；原30s失败及修复保留。非整数倍终点的短尾用合法剩余区间二分规划，未丢尾/降min；185初轮仅root新boundary regex把实际invalid_evaluation_time写错，保RED后修正，生产行为未改。此轮无EOS；17389/4565源码安装测试均已终态，后续候选工作由子代理在tmp继续。原四格FAILED依然有效；不得把新制造积分路径当已通过湿耗尽。

下一具体动作：Carson已在 `/private/tmp/brick-exact-affine-depletion-v1` 冻结精确仿射根/逐项积分绑定/原writeback预算候选及真实保存cell2样本测试，待独立审核；未repo准入。Averroes已完成 `/private/tmp/brick-exact-native-host-v1/PLAN.md`：实际direct WPT→FreeSolidSlab的time只作数值检查，可提取共享state-only评估，再接显式exacttyped入口，不用float sentinel；programmed宿主仍需精确forcing装配。恢复先核实际候选/审查，再接完整有序事件比较/原子提交及新record/resume。证据 `research/exact-integration-v1/README.md`。原污泥材料闭合、三机制公开留出、全湿烧冷却、空间收敛、完整CLI/UI仍必需未完成，Goal active，本轮progress。

最新失败诊断检查点（基线599efe0）：有序仿射writeback异常现在在原refinement.comparison_details中保存不可变完整初/raw/clock/gross/积分/先前未提交帧；保留原异常、default/success语义和0额外物性回调。源码114相关测试37.09s通过，安装65项3.13s通过，67模块与源码逐字一致，代码/数值审查通过。永久4项测试包含真实短面板拒绝、完整算术重建、成功/default和诊断捕获错误对照。

同原case/policy的实际诊断session17279已终态exit0/39.039s，仍FAILED correction_exceeds_evaporation_fraction，13步132eval15attempt0event/packet；完整数值结果除wall及新诊断外与旧结果完全相同。case/initial/allpolicies/final/interfaces逐字相等，原512步/800s及外部840s未改。失败cell2在未提交cell3之后，h=8.452095690003603e-10s；delta5.673486681192076e-20mol/gross1.5641070214850036e-12mol=3.6273008197389976e-8，超过原1e-8约3.63倍。独立全失败panel算术显示clock残余5.673486686333683e-20mol，raw与其差仅−5.14160749e-29mol，已定位绝对时钟向下取整主导；不是材料物理不可行。13已提交prefix原账本复算通过。证据 `research/ordered-packet-failure-evidence-v1/README.md`；当前无EOS/测试进程。

下一实际动作是完整一致的局部/精确事件时间路径，不能只替换root定位器：stage/query时间、所有ledger积分端点、program节点、事件比较与record/resume必须同一语义。Carson已完成仅保存仿射样本的算术原型 `/private/tmp/brick-ordered-local-clock-prototype-v1`，不是新耦合轨迹；下一有界canonical clock及精确program插值候选正在 `/private/tmp/brick-exact-event-clock-v1` 准备，仅tmp、未准入。恢复检查其实际产物/测试再审核；原完整Goal所有材料、三机制留出、全湿烧冷却、空间收敛和应用验收继续未完成，Goal active，本轮为progress。

有序耗尽核心检查点（基线cd89a46）：显式 `ordered_affine_packet_v1`、完整逐事件细化和原子提交已实现；legacy记录/restore/audit/service及续算明确拒绝新packet合同。源码323项回归通过792.65s，安装61项通过3.00s，67实际模块与源码一致。默认真实水测试保存passed，但仍是制造固体。两项核心审查和记录边界审查通过，证据 `research/ordered-packet-v1/README.md`。

实际四格运行session47684已终态exit0/39.018s（仅表示捕获成功）。核心FAILED `correction_exceeds_evaporation_fraction`，13普通步、132评估、15尝试、末时刻.500262030378867，目标.50032未到、0packet/0event；原512步/800s、物理参数和全部科学门槛未改，外部840s监督。独立13prefix N/E/stretch/component账本通过，全局E+peΔV最大6.166889743e-11J，C绝对累计1.854993883e-20J，通过原2e-8J。当前无活动EOS/测试进程。

下一具体动作：在writeback失败边界保留已计算的cell/初值/raw/积分项/clock/gross及未提交frame，保持原拒绝和回滚、不增加EOS观察；经测试/审查/冻结安装后再做同一有界四格诊断。当前记录缺少失败数值，不能把短面板时钟ULP假设称为实际根因。只读Fraction机制例子在 `/private/tmp/brick-ordered-packet-next-v1`，Averroes/Tesla审计均建议先补诊断。完整packet记录/独立审计/续算/CLI/UI接入仍待完成。原污泥材料闭合、三机制公开对照与留出、完整湿烧成冷却、空间收敛仍为必需未完成项；Goal active。本Goal续轮已产生回归/真实失败与审计证据，属于progress。

f9d57c0 后实际进展：新增 depletion_group_roundoff 原子精确同根记账，逐cell仿射三分量/真实面板/完整rawstate绑定、每member原grossfraction及累计预算、zero None、失败不返回局部结果。初审两HIGH已通过实际RED反例并修复，旧代码和失败保留；20专属/116源码回归通过，冻结非editable安装52通过、67模块一致。仅核算已给共享panel，非完整group轨迹/模式切换。

另实际66模块四格短探针session32911已exit0/4.384s：原初态/精度，推进2^-14s，一个accepted step8stage+2observation；候选gap0→3.371786427888473e-10仍小于原1e-8。独立所有prefixN/E/stretch及global E+peΔV核算通过原门槛，global1.20454e-11J。无活动native/tests，不再poll。证据research/depletion-group-roundoff-v1。新67安装未native复跑，不混称source身份。

下一实施：按INTEGRATION_NEXT含ordering补充，保旧默认，显式数值策略容许普通正stage推进并在terminal用严格仿射根区间判断先后，实际mixed模式重新估后事件；时间定位最大误差不是最低事件间隔。联合精确同根核算是已具备原语，完整event容器/六gate路径比较/commit/record/resume仍待接入。无需凭空增加true-RHS验证门槛，也不冒称真实根证明。4/8空间矩阵、真实原污泥全参数/三机制留出/湿烧成冷却及最终使用仍未完成，Goal active。


38b01fd 后实际进展：新增 depletion_group_clock 显式仿射库存多根原语及 16 项测试，独立代码审查通过；相关源码回归 80 passed/30.10s，非 editable 离线安装后新测试 16 passed，66 实际安装模块与源码一致。原单事件积分器未改；不宣称真实 wet group、状态修正或空间收敛通过。首轮测试断言错误日志保留。研究证据 research/depletion-group-clock-v1。当前无活动测试/EOS。

新材料来源：实际下载并核读 Elsässer 2011 大学论文 pp41–48/117，获得含水样品量热及扣水推导的 14 个干基 Cp 值；逐值复算均值/方差/SD，独立来源审查完成。research/source-elsasser2011 记录源 PDF SHA/定位、数值、统计含义及适用性；未转载许可未明 PDF。低温测量不能补高温 Cp(T)，亦未匹配现构造材料，不作为全周期准入。

下一步：将多根原语用于明确仿射的联合事件测试，建立逐单元库存修正和一次共同账本；真实 wet 接入仍须明确数值终端近似的误差/顺序合同。LOCALIZATION_REVIEW 证实两采样无真实 RHS 余项界，不能将其当真根证书。原污泥身份/热物性高温域、三组公开对照及全周期/空间/最终使用验收继续未完成，Goal active。


c5ddeb1之后实际progress：同原湿态10ms pilot session9698 exit0/67.54s，34steps2events620eval74attempts，原prefix审计通过，globalmax2.509e-10J。真实保存dry终态profile77466 exit0/1.410s，两output和saved base_rates精确同；unprofiled.01719s，仅单位成本样本。四格一次initialWPT51175 exit0/1.790s，首两N/(-net)候选Fraction gap0，满足当前selector拒绝条件；未运行四格integrator/未证明真实同时事件。

按实测资源推进同湿态2格elapsed.625s：coarse79355 exit0/119.00s，349steps389attempt2825eval2events end1.125；fine80816 exit0/173.67s，669steps709attempt5065eval2events，同end。fine仅id/refinement1(ordinaryinitial/max半)/maxsteps1024事前资源预算改，其他physical/所有原gates/800s保持；原512不足640dry+events，不是accuracy放宽。两组原audit_prefix SHA287bc实际exit0，globalmax1.18122e-9/4.07154e-10J<2e-8。全部65运行源码身份一致，无活动EOS/测试，不再poll上述会话。

标准库比较已补独立审核指出的原audit实际SHA及完整case->policy绑定，原脚本/原已通过report也保留；新比较exit0、独立最终review通过。两mesh实际不同，原初态N/E/stretch相同而case关联identity不同明确记录；eventtime差exact0。终态max N1.3982e-10mol/E1.26136e-7J/stretch4.09054e-9/T1.30858e-8K/P9.87175e-4Pa，T/P低于点误差界，不宣称两级收敛阶或全时间误差证明。证据research/thermal-timescale-v1，说明THERMAL_TIMESCALE_STUDY.md，三可运行新case已保存。

下一具体实现合同research/thermal-timescale-v1/NEXT_GROUP_PLAN.md：初始tau相等不是root同刻，保原单事件默认；先纯解析affine多root区间/正库存/ordering/union证书，再完整group correction/全cell六gate/模式切换/共同panel账本及record/resume接入。没有timing-displacement或ordered分支界不能直接zero所有tie。4/8完整空间矩阵尚未准入，原15us空间FAIL保持。真实原污泥材料、三组公开机制留出、完整湿烧成冷却与最终使用验证仍必需，Goal active。


f619433之后实际实现progress：PressurePolicy显式endpoint策略及不可变trialledger，defaultNone公开encode/原二分数字序列保留；case可选strategy严格唯一值并真实转发。新dataclass身份改变不冒称旧model字节相同。源码66/安装66通过，65模块一致；独立审查通过。原始RED/中间测试失败保留。见PRESSURE_ENDPOINT_STRATEGY.md及research/pressure-endpoint-strategy-v1。

实际同accepted wetstate1点比较session30911已exit0：baseline.80005s、新.13375s，两格最终root38→3，T/P原界通过；同物理N/E/stretch显式新数值身份重绑不是旧checkpoint恢复。实际单次新case service session83456已exit0/67.896s监督（service67.69s），30steps2events592eval70panels24endpoint、原.50032终点通过，事件时刻与旧记录相同。原6组×6gate经独立核查；原audit_prefix.py SHA287bc逐prefix实际exit0：N5.58085e-16mol/E7.62952e-11J/stretch4.21229e-16、全局外压功max9.99274e-11J/C累积绝对2.13932e-20J均过原门槛。当前无活动EOS/测试，不再poll30911/83456。新case data/sandbox/cases/reacting-wet-free-paired-events-endpoint-root-v1.json SHA9d930a6c6d60cf328e5abe2e61dc6a5f9f0cf06d9453827b84d0f0b56e5746f4。

下一步按实际较长空间pilot设计推进可解析时长与适应步长，用真实取消/续算同时检验新policy服务生命周期；原15us空间FAIL保持，不能改D/k/初始库存阶跃或放宽norm/gate。后续设计已保存research/pressure-endpoint-strategy-v1/LONGER_SPATIAL_PLAN.md：先同湿初态2格到.51的10ms成本pilot，再决定.625s热尺度；10ms不是空间验证。4/8格同父子单元可能触发simultaneous_events_not_separated，须实证分离或联合事件处理，不能扰动初态/改gate。计划未执行。新策略全取消/续算/重放尚未实际复验，不用旧default证据替代。原污泥材料/三机制留出/全湿烧成冷却仍全部必需，Goal active。


87b5f78之后实际进展：原accepted wet state1有界host profile已完成。session80931 exit0/3.357s，build1.340s，两个显式evaluate .887659s(profiled)/.805864s(unprofiled)，选定输出逐字相同；runtime/父封存前后一致，仅run_service历史查询修复差异已明确绑定。8 thermalforwards、320 pressuretrials、328 nativeTP；两最终closure均38二分，宽7.2032e-6Pa。_transaction self.711s是剖析归因，不能拆C内部或当656独立TP；digest9次累计.00417s不支持hash主导。独立脚本/结果审核通过，完整证据research/host-profile-v1。无活动EOS/测试，不再poll80931。生产源码未修改，本轮是实测证据进展。

下一实际实现合同research/host-profile-v1/PRESSURE_ROOT_NEXT_PLAN.md：default旧bisection保持；显式新数值策略用端点液体体积生成候选，但每个候选必须真实EOS+sign验证，保原width/residual/单调/guard及trial预算，不足收缩回二分。先独立解析根/假位停滞/浮点/异常测试及review，再原wetstate两次40s实际probe；未实现，不声明加速或事件通过。后续仍需事件/续算/空间收敛原门槛复验，不以点加速代替完整Goal。

限定新来源检索实际核读Houdkova2007公开PDF，指出PRES2006 Elsäßer热物性原研究，但当前正文Cp只有定性、fig5/6为流变；未取得可准入Cp数据，不补未知值。核查research/source-lead-houdkova2007/REPORT.md；只有网页解析原文，未保存PDF字节，未声称PDFhash。原污泥完整参数、三组机制留出及全烧成冷却仍未完成。Goal active。


0c2191d 之后实际进度（2026-09-09 UTC）：修复 v2 resume preflight 的构造顺序；保留实际完整盒/来源/前缀审计。源码与冻结安装 43 项通过、65 模块一致。真实 service start/session48184 cancelled 7steps；resume/session99452 completed30steps/2events至原0.50032，原前缀和累计预算保持；replay/session19128 exit0，353.89s、30steps/2events/592eval，times/states/steps/events/corrections与resume逐项相同。三会话均终态，不再poll/重跑。325成员完整证据 research/paired-service-lifecycle-v1。

真实取消T来源查询曾 quantity_unavailable，失败保留。随后修复合法量无final_snapshot时保来源图、value/pointer null及明确原因，未知量仍拒绝。永久RED14fail→GREEN32pass，实际安装32pass/65模块一致，真实取消7查询通过、完整7查询逐项不变、原封存不变；research/partial-run-trace-v1。源码查询修复在生命周期运行之后，二者runtimeSHA不同，不冒称新源码已重跑native。独立代码审查均通过。当前无活动EOS/测试。

空间保存数据独立诊断通过原六封存输入、parent N/E映射及初态几何通量核算，支持内部初始阶跃尚未解析；原空间收敛FAIL保持。0.391µm是水扩散尺度，粗估热尺度12.35µm，均远小于最细2500µm网格；不能把估算当完整耦合定理。research/spatial-jump-diagnosis-v1 另附 PERFORMANCE_PLAN.md，仅设计、未运行profile。

下一可执行步骤：按该有界计划先测真实已接受wet state的最多2次host evaluate（40s监督、source/输入绑定、原误差门槛；串行且保留实际profile），用实测调用成本确定原空间问题可解析尺度/时长策略。并继续原污泥材料闭合、三组公开机制及留出验证、完整湿坯烧成冷却与气液联合耦合。现仅制造材料短湿轨迹/事件与软件生命周期进度，不是完整Goal验收。Goal active，全部原§11范围保持。


3e04fce之后实际progress：新增pressure_comparison完整typed策略/codec/双路径实际host及数据审计；depletion只在opt-in捕获当次total inverses，event/common全格比较、before/after guard与累计attempt/completed；event_record v2/旧v1兼容及source/state/observations/成本/续算审计；case显式v2假设避免sourcehash自引用，真实build派生box并beforeforward验证；service允许v2续算形状后仍严格audit。

独立审核关闭真实WaterState mass序列化错位与bool/string采样漏洞。冻结安装实际140pass8.67s、65模块与源码一致。真实helper两格probe session1078已exit0（3.18093s），8endpoint完成/最大条件界3.7403908677e-5Pa过原1e-4门槛，非event成功声明。文档PAIRED_EVENT_COMPARISON.md。

实际事件session87636已终态exit0：监督352.383s/积分348.660s，completed30steps/2events/592eval/70panels，24endpoint全部完成，到原0.50032。事件cell1在0.5002686445571594、cell0在0.5002848875613792；每event两successive+独立细化通过原六gate。原独立P界仍.005135/.002784Pa>1e-4，只有显式新共享族界（max5.17914e-9Pa）通过，旧failed不改。独立审核的audit_prefix.py实际exit0：所有prefix N5.58089e-16/E7.62853e-11/stretch3.84743e-16，全局E+peΔV−boundary−body max9.99128e-11J、C跨格累计绝对和1.29891e-20J过原2e-8；gross/2correction均独立重算。运行前后water/65源码一致且physicalinputs与旧case逐字段复原相同。无活动EOS/测试，不再poll87636/1078。证据research/paired-event-comparison-v1；新增可复现data/sandbox/cases/reacting-wet-free-paired-events-v1.json。

下一步为新case真实service run/replay/resume及来源/交互核验，以及继续原空间收敛缺口/真实原污泥证据及全烧成耦合；不能把制造300K短湿轨迹当全周期。现数值器可在显式共享误差族完成两耗尽事件；默认独立族旧失败仍成立。原Goal继续active，所有原§11未完成项不缩减。


上一Goal回合仅重述提示词，按no-progress处理。本回合恢复实际未提交模块并独立重算四个保存证书exit0，冻结125文件证据包，新增PAIRED_PRESSURE说明，属于progress；完整Goal仍active。

新增paired_pressure/paired_pressure_host及31项专属测试：明确新制造共享常数参数盒，只计算reported-T条件压力差；默认unavailable，保留原点误差。旧版源码/安装相关60项通过、64模块核对；两个两格真实端点探针分别3.2685/3.1109s，非零差3.6015990190e-5Pa、上界3.7279046258e-5/3.7405558044e-5Pa。没有接入事件接受，原failed保持。来源、全部输入、四证书、审核和旧64模块已封存research/paired-pressure-v1/evidence-before-identity-fix.zip及逐文件manifest。

最终identity修复已完成独立审查：last observer后复核thermal/chemical两implementation与捕获值，原RED1fail保留，15主机检查通过。非editable安装专属34项通过0.34s、64实际模块匹配；真实两格非零neighbor正常observer补验session28048已exit0，3.40284s探针/3.78762s监督，两个上界及全部端点与旧运行相同。无活动EOS/测试。27项修复/审查/新native/设计证据封存identity-fix-and-adoption.zip；旧125项包不覆盖。原audit只证保存算术及内容一致性，不独立重建所有host误差项/材料物性。

下一实施合同已冻结research/paired-pressure-v1/ADOPTION_PLAN.md：实际旧压力gate也是reported-T条件界，温度误差独立检查，因此不凭新增Ttube要求阻断；新共享常数误差族必须显式opt-in，default原公式/旧记录保持。需新增before-call取消/尝试计费、实际event/common全格inverse快照与两op绑定、记录/审计/续跑版本分支及新案例声明。未接入/未宣称事件通过。完整原污泥材料/三机制公开留出/全周期/空间收敛仍未完成。


9121200之后实际原生耗尽attempt01已终态：session90003 exit0但模型failed correction_exceeds_evaporation_fraction，499.457s服务/496.887s积分，13accepted steps/0events/751eval/90attempt。固定end0.50032未到，停于0.5002620305782048。level1–11仅P比较失败，~0.005135Pa点误差包络大于原1e-4Pa门槛；不加refinement或放宽gate重跑。独立每prefix N/E/stretch通过，全局pe功最大2.76765e-11J、C累计绝对抵消9.25615e-21J通过原2e-8目标。单点实际安装诊断session46463已终态2.306s，证明流体项与约2e-12m3体积包络均有贡献。全部失败/审查/账本见FREE_NATIVE_EVENT_FAILURE.md及research/free-native-events-v1。

下一数值修复为有证明的成对压力差包络，而非削减原物性误差。reacting_skeleton_provider在/private/tmp/brick-paired-pressure-design-v1准备共享单调闭合推导（仅设计、未应用、无EOS）；恢复先读其实际最终状态/设计再审核实现。当前无活动EOS/测试。Kim2008定向原文检索仍未取得合法全文，未准入Cp或材料。原完整Goal继续active，原污泥材料/三机制留出/全周期/空间收敛都未完成。


2026-09-08 free-event application实际检查点：新显式event case、事件记录严格审计、完整累计续算、run/replay/resume与事件来源目录已接入。源码100+6通过；冻结非editable安装后从/private/tmp无PYTHONPATH实际106通过5.77s，62真实安装模块与源码一致。真实water构造4项通过，但service事件生命周期使用analytic callback/builder替身，原生耦合短前缀2步19.188s通过且七trace无缺来源，但0个耗尽事件，尚未做真实耗尽event run/replay/resume。首轮监督脚本证据目录误传导致4来源缺项，原封包保留，正确目录重跑通过。已关闭系数内容绑定、删小额correction、观测/refinement严格类型审查缺口；原失败保留。详见FREE_EVENT_APPLICATION.md及research/free-event-application-v1。当前无活动EOS或测试；下一实际动作是事前登记有界原生耦合事件应用实验。空间收敛仍未成立、原污泥材料及全流程/三机制留出仍必需，Goal active。



80b5331后实际progress：free schema2/4/8准入（旧prescribed仍2/4）、catalog域和UI模型专属gridoptions；修复JSON8在旧select空值→0问题，未知/不支持值在写case前拒绝。8格N/E/9stretches/当前非零Bq/界面/父误差测试通过。源码61回归1.30s，安装61回归1.24s+11Node UI通过；61实际模块和catalog/assets前后匹配。

完整实际2/4/8×粗细时间矩阵已完成，新增5原生组、复用原2coarse；均2/4steps、15/29eval无拒步。4coarse32.52s、4fine53.14s、8coarse58.90s、2fine26.49s、8fine106.55s；27357/92902/10876/98307全终态，无活动EOS。逐prefix/封存/当前科学模块逐字比较审计通过；最后2fine/8fine为实际安装运行，不重旧成功组。

关键结论为不支持空间收敛：时间细化后的父格温差2→4为1.52254e-6K，4→8为3.04496e-6K，增长约一倍；大于可用时间+反解界10倍门槛。时间变化低于约8.24e-8K反解界，不能宣称其极小差是独立精度。完整证据research/free-spatial-study-v1，说明FREE_SPATIAL_STUDY.md，原科学/精度门槛未宽。

下一具体事件服务设计由reacting_skeleton_provider仅在/private/tmp/brick-free-event-service-design准备，需显式DepletionPolicy/校正/最终interfaces/全机械prefix与checkpoint累计预算，避免ordinary服务在液水耗尽后继续错误模式。初态Nliq/r约0.27–0.28ms仅量级估计非事件定位。原GNEST缺质量/产品caloric材料问题仍保留，不重做已拒绝审计冒进度。原污泥、三机制公开留出、全湿烧成冷却及完整空间验证仍未完成，Goal active。


7f3d24b后实际完成free case应用接入：独立严格schema/current储能+反应自由主机/全机械初态及快照、2/4格beta/V0/界面/父误差缩放；独立20方程7root目录，run/replay/resume/trace真实模型选择与自由锚点；UI逐格n/全局t分开、溯源完整向量。说明FREE_CASE_APPLICATION.md，证据research/free-case-app-v1。

真实水应用2steps15eval16.59s通过；独立逐prefix全物种9.89e-17mol/局部E2.33e-11J/全局外功1.46e-11J，反应/两格蒸发/水蒸气扩散/热/自由形变真实共同活动，7trace无缺来源。重放逐位相同；首次callback3取消零前缀的测试失败保留，按实际guard位置callback19后取消1step+续算成功、原prefix不变，合计19.33s。91971/12781/56117均已终态；无活动EOS，不重复成功native。

安装93计算服务测试通过；22localapp因沙盒socket错误，获准loopback重测22通过2.60s；8Node UI测试通过。61安装模块前后与源相同，2catalog+JS/HTML逐字相同；1848/13200均终态，未重复原生EOS。案例/目录/服务code-review与TS UI review通过。尚无本阶段浏览器渲染或空间轨迹收敛证据。

下一实际空间研究由program_knot_review仅在/private/tmp/brick-free-spatial-study准备：现free schema2/4，研究自由分支8格准入与原实际案例2/4/8的网格/时间细化、统一物理量比较和实测资源预算。未repo应用/未运行，恢复从实际PLAN继续。原污泥材料、三机制公开留出、完整湿坯烧成冷却和联合所有输运仍必需，Goal active；本回合属progress。


ae5bf54 后实际完成动态炉程自由主机接入：当前几何表面热交换、完整机械率/分项功、程序内容身份及受控非法修改错误保留前缀。原生水 attempt01 130.70s 完成，3/7步、22/50eval、两个节点精确命中；独立170源码hash及Fraction逐prefix审计通过，最大水1.86e-16mol/局部E1.75e-10J/含边界热全局E6.30e-11J。源码34dry+1native通过，安装42dry10.27s通过，61实际模块前后逐字匹配。37884/65002已exit0，无活动EOS；不重复native。全部原始失败/JSON/XML/审计与身份见research/programmed-free-slab-v1，说明PROGRAMMED_FREE_SLAB.md。仍为短时制造材料、无物质面流/反应/耗尽，不是完整烧成。

下一实际候选由reacting_skeleton_provider仅在/private/tmp/brick-free-case-integration-candidate构建独立free schema、CurrentSolidStorage/FreeSolidSlab反应主机、完整初态与真实快照和2/4格广延参数缩放；未repo应用/未EOS。program_knot_review只读设计free catalog及run/replay/resume/UI接入，路径/private/tmp/brick-free-app-seam。恢复读取真实候选/审查后继续，不能把应用设计当已实现。原污泥材料及三机制公开留出、全湿烧成冷却、空间收敛仍全部必需，Goal active。

d969905后实际progress：free_slab_rates显式reacting_manufactured精确当前qeta及共同t加权分母，FreeSolidSlab显式反应模式重绑当前reaction storages、当前Ns/总E/孔隙/温压/自由形变真实闭环，fixed模式守卫与身份保留。源码65项3.83s+独立轨迹1项5.16s通过，正式安装104项14.01s通过（31745已exit0），61实际模块前后逐字匹配。无活动EOS/测试。证据research/reacting-free-slab-v1，说明REACTING_FREE_SLAB.md。

独立305/306K干态A→B两格0.1s轨迹23/32steps通过全部原门槛和每prefixDOP853对照；E最大1.395e-6/7.266e-7J，stretch3.173e-8/1.652e-8，解析A/B1.574e-10/8.058e-11mol，外功8.026e-9/4.556e-9J。原300K边界越域零step、域内粗E4.326e-6失败完整保存，仅收紧内部控制，未宽源域/外部gate。两份独立审查通过。仍为制造材料、无湿/气物质面流，非真实原泥/全周期。

下一候选仅由reacting_skeleton_provider在/private/tmp/brick-programmed-free-slab-candidate隔离准备：ProgrammedSolidFluidHeat显式FreeSolidSlab准入、真实当前表面几何、保留mechanicalrates与外功、原程序断点/来源身份；机械Pe独立常数，不随气库压力静默改能量身份。设计/private/tmp/brick-programmed-free-slab-design/PLAN.md。未应用候选、未原生EOS。完整原Goal的动态烧成/冷却、气液联合/空间收敛、原污泥资料及三机制公开留出仍未完成，Goal active。

f1f1349后已实际接入CurrentSolidStorage显式reacting_manufactured模式：当前Ns→q储能/固体体积/孔隙/总E反解；默认fixed身份/数值保留。FreeSolidSlab提前明确拒reacting点，尚未扩自由速率。源码39项3.68s、安装62项3.84s通过（45446/99141已exit0），61实际模块逐字匹配；两份独立审查通过。原候选/RED/源码hash/安装XML保存research/reacting-current-point-v1，说明REACTING_CURRENT_STORAGE.md。无活动EOS/测试，当前阶段可提交。

下一候选由reacting_skeleton_provider仅在/private/tmp/brick-reacting-free-rates-candidate隔离准备：solve_free_slab_rates显式reacting模式，实际q(N)*eta与加权共同t分母，固定路径兼容/当前Ns与误差界；没有repo应用、没有host反应准入。恢复先查看候选与审查，不重跑旧439s事件。原三机制公开留出/原泥材料/全湿烧成冷却/空间收敛仍未完成，Goal active。

233bb8c后本阶段实际progress已完成：真实水两格mixed depletion运行439.44s/积分436.173s、305eval、19步、唯一cell0事件3.041741648e-5s，cell1仍湿且凝结。原两终端+独立不同网格六门槛通过。逐prefix水3.84e-16mol/局部E1.65e-10J/全局外功1.06e-10J，实际局部C约4.25e-6J且全局抵消。163源码hash在解冻前独立一致；session58808已exit0，无活动EOS。全部初末snapshot/失败/分支审计见FREE_SLAB_DEPLETION.md与research/free-slab-depletion-v1。

另新增独立dry gas/enthalpy/自由力学轨迹：16/32步对DOP853通过，原失败保留、外部gate未放宽；陈旧几何负对照可辨。正式安装61实际模块匹配，18相关气流/机械事件测试9.25s通过（99499已exit0），另候选installed5项3.57s。生产源码仍233bb8c，无重复7分钟原生EOS。下一已审候选仅在/private/tmp/brick-reacting-current-point-candidate：CurrentSolidStorage显式reacting_manufactured/currentNs/q储能与孔体积，4drypass，另FreeSlab固定模式提前拒reactingpoint的最小guard1pass；尚未应用repo。先核候选与两个审查再推进自由rates当前qeta、真实反应源与整体能量；完整原泥/边界/空间收敛/三机制留出仍必需，Goal active。

233bb8c后当前唯一native验证session58808：tests/sandbox/test_free_slab_depletion.py，两格cell0耗尽/cell1仍湿，600s积分/660s外层硬限，完整源测试冻结；初始真实callback已保存，尚未积分终态。原六门槛不变，补局部constraint非零、跨cell累计绝对和及初末数值界审计。最终snapshot保存先于断言。路径/private/tmp/brick-free-slab-depletion-v1；恢复先poll同58808，不重启、不并发EOS。无生产源码变化；此测试尚未提交/未通过声明。

另独立dry gas trajectory候选/private/tmp/brick-free-slab-gas-trajectory已审：16/32不同网格对独立DOP853通过；原失败与内部收紧记录保留，未放宽外部gate。尚未应用repo（native冻结中）。reacting当前点候选由reacting_skeleton_provider仅在/private/tmp/brick-reacting-current-point-candidate隔离准备。Goal仍active，完整原§11未完成。

从23be5b6完成多格真实水相间转移准入与当前几何Darcy独立测试，属于实际progress。WaterPhaseTransfer显式接纳FreeSolidSlab，保留真实来源/热化学桥及external_traction、mechanical_constraint、body。源码4真实测试44.25s通过：两档1/2步、8/15eval，蒸发与凝结共同活动，逐prefix水最大5.4063e-17mol、全局外功1.3595e-11J；独立Fraction审计162hash匹配。干态非零Darcy两个方向独立公式/负对照与相关35项通过。资料见FREE_SLAB_PHASE_TRANSFER.md及research/free-slab-phase-v1。

正式非editable安装已终态：97测试61.68s通过，XML零失败/错误/跳过；61实际site-packages模块测试前后逐字一致。session87831/43779已exit0，无活动EOS，不再轮询。骨架/输运/相间系数仍制造，尚非原泥材料或完整干燥。下一推进两格一格耗尽一格仍湿，原六门槛保留；候选在/private/tmp/brick-free-slab-depletion-design，未运行。完整固体反应/动态边界/空间收敛/真实原泥及三机制公开留出仍未完成，Goal active。

本回合从5c5f09a推进多格自由主机，属于实际progress：新增free_slab_rates/CurrentSolidStorage/FreeSolidSlab，全局共同t_dot、局部constraint功和同次当前温压/共享热流真正连接。主机源码b78efa42，瞬时率21bc4cb2，点储能4b94d58a。独立代码/数值审查通过；固体与力学/输运仍是制造参数，material_qualified=False。

实际干态两格独立DOP853对照通过：6/8steps，E误差1.605862e-6/6.980263e-7J，stretch误差3.928e-8/1.707e-8；漏局部constraint的负对照虽全局守恒仍过，局部E偏差.0810722J。真实水两档固定相态轨迹41.693s完成：1/2steps、8/15eval、13.126/24.586s，T终值299.9999889194692/300.99999007520626K；全prefix外功残差最大4.208e-11J。独立Fraction复算通过，全数据见research/free-slab-v1。没有蒸发或液/气物质面流，不能叫完整干燥或完整材料验证。

安装已终态：61真实site-packages模块逐字节匹配；150相关测试8.46s通过（session40608已exit0），之后仅补3项纯测试覆盖tdot零但R非零/正确物理重编号/第二cell反解失败保留prefix，installed3项0.54s通过。运行源码未改变；真实wet记录160源/测试hash在当时独立核查一致，后来2个测试文件只增3测试，有单独最终XML。当前无活动测试/EOS，不重复29920/40608。全部原失败/候选/审查/安装身份已归档，随本阶段本地提交保存。

下一直接工作：WaterPhaseTransfer显式准入FreeSolidSlab（保留真实水caloric/source gate与constraint组件），实际多格蒸发/耗尽、非零Darcy/液面迁移组合；之后组成相关自由骨架/固体反应与动态炉温。空间收敛、完整原污泥材料证据、三机制公开留出、全周期/应用入口仍全部必需。Goal active，原§11未满足。


本阶段全部运行已终态：源码真实自由液相耗尽1项178.373s通过，安装172相关轻测53.36s通过（session83000已exit0），58真实site-packages模块测试后再次逐字节匹配。research/mechanical-depletion-v1已保存完整原始产物。无活动测试/EOS，不重启旧61001/83000。独立原始结果复核已通过：152源/测试hash一致、19prefix Fraction审计通过，实际独立分支113eval与6项门槛已核。阶段提交后推进多格自由几何/反应/材料域。Goal仍active，原§11未满足。


自由机械液相耗尽真实attempt03已完成：177.721s/305eval/19已提交steps/1事件，终点1e-4s；两次终端比较与独立halved-controls全部通过，原精度门槛保留。事件3.0417417141788028e-5s，逐prefix外压功最大残差1.12965e-10J、水4.68239e-21mol。research/mechanical-depletion-v1保存全部原失败/JSON/XML/sourcehash与审查。session61001已exit0，无活动EOS，不再轮询。自由主机仍是固定固体单格制造骨架，不能称真实原泥全周期。

当前唯一安装轻测session83000，100s外层硬限；非editable实际58模块与源码逐字节一致，src/tests冻结。恢复先poll同handle，完成后核实际XML并复制installed-*证据，完成本阶段本地提交。新源码SHA c9139510，机械候选加干态共同端点修复；没有重复实际湿干EOS。下一工作需将自由几何/全能量/共享面接入一维多格并接固体反应，继续真实原泥材料证据及三机制公开留出验证。Goal原第11节仍未完成。


当前唯一实际EOS试验session61001：自由湿干attempt03，固定源码SHAc9139510应用机械耗尽+已审干态共同端点修复，36针对性测试10.55s通过。原attempt02失败来自tc-at再相加舍入到tc前驱float，不是机械守恒/材料失败。按106.9s192eval实测成本，attempt03资源上限180s/外层210s，原物理与精度门槛全部不变。恢复须先poll同session，不重启；src/tests冻结。输出/private/tmp/brick-free-mechanical-depletion-v1/attempt03.*；新版本尚未安装验证，Goal仍active。


机械耗尽生产候选已按审查SHA9d569f8696精确应用，13制造新例+11旧例+4host guard共28项6.18s通过；生产应用独立code-reviewer再次APPROVE。非机械旧guard改为缺机械尺度前置拒绝，未改物理参数。来源/原RED/中间失败在research/mechanical-depletion-v1。相关轻测session46325已exit0，168 passed in53.42s；未安装新版本。

真实自由湿干attempt01在积分前被actual水摩尔质量逐位匹配拒绝，正确改为从actual chemical.reference绑定后attempt02运行106.90s/192eval/23试算panels，返回numerical_failure:unresolvable_stage_time。首轮相邻终端细化6维全通过，但level2终端细化的dry续算时间分割失败，尚未进入独立halved-controls验证，因此没有事件提交，保留12湿态有效steps；不能冒称真实事件组合验证成功。原门槛/物理未改，全部JSON/XML/log/源hash与事前合同已保存。program_knot_review正在隔离只读诊断实际时钟边界及轻量复现，禁止跳过独立更细门槛。无活动EOS；测试84176已exit1。Goal仍active，原§11未完成。


普通自由液汽转移安装终态：session40338已exit0，80 passed in10.57s，XML实际零失败/错误/跳过；58实际site-packages模块与源码逐字节一致。源码与安装实际蒸发轨迹数值相同，证据research/free-phase-v1完整保存。无活动EOS，不再轮询40338；后面的运行中仅为历史。

下一机械耗尽候选现已冻结在/private/tmp/brick-mechanical-depletion-candidate/depletion_integration.py，SHA9d569f869666fceee92bd13c4a412ab8578391dbb48419b010a025cb347de43f，candidate.patch/PLAN/测试及RED/中间失败保留。作者13新noEOS5.62s、11旧0.35s通过；尚未Root应用/安装/真实wet验证。program_knot_review与mechanical_code_review已启动独立只读审查该候选；恢复先取实际审查结果及文件。不得把候选完成当repo准入，现repo仍明确拒机械耗尽。Goal active。

2026-09-08 UTC 普通自由相转移：WaterPhaseTransfer现显式接纳ClosedFreeSolidCell，真实当前TP/气体积计算液汽源，原热化学桥核查不变，外功和机械率逐项保留。顶层source_ids补入实际基础评价完整来源。源码4真实测试9.63s+76回归1.53s通过；实际.001s液水减少3.2293e-7mol、蒸汽等量增加，T299.999736919K/外功残差1.35e-11J，原预算和checkpoint通过。候选与RED/输出见FREE_PHASE_TRANSFER.md及research/free-phase-v1。源码冻结，安装58实际模块已逐字匹配；唯一活跃安装验证session40338，60s硬限，恢复须先poll该句柄确认终态。

下一机械耗尽候选reacting_skeleton_provider正在/private/tmp/brick-mechanical-depletion-candidate隔离实现（不改repo/不EOS）：frozen/affine终端推进mechanical state与ledger，event/common-time比较、全局原初态累计审计。候选RED4项被原guard拒绝；首轮候选2守卫通过、两terminal完成但独立exp(t)普通approach精度未过1e-8，保留失败并收紧内部数值预算、外部验证门槛不变。未审查/未应用，不能宣称耗尽机械已完成。Goal仍active，完整第11节未满足。

动态储能/自由单格安装终态：session28559已exit0，167 passed in26.70s，外层26.965s回收。XML实际解析零失败/错误/跳过，58个实际安装模块与源码逐字节一致。安装湿轨迹与源码温压/伸长/功残差相同，粗细耗时6.612/12.512s；下文进行中为历史，不再轮询28559。没有活动EOS。

下一只读/隔离候选reacting_skeleton_provider在/private/tmp/brick-free-phase-candidate准备：新动态点/ClosedFreeSolidCell接实际液汽相间转移，保持总E与相参考能，不伪造旧host类型或丢机械state；随后耗尽terminal panels真正推进机械量/账本。该候选不改repo/不安装/不EOS，不属于167已通过结果。恢复从实际代理/文件状态继续。原第11节仍未完成，Goal active。

2026-09-08 UTC 动态储能/自由单格阶段：已新增dynamic_solid_storage.py及free_solid_cell.py，当前(n,t,N,E)真实反解温压再求自由牵引率；不构造PrescribedSlabMotion。integration新增独立external_traction/body功schema，保留原schema；数值错误保留接受前缀。dry/source审查通过。源码163回归3.24s+3真实wetpoint3.08s通过；实际湿fixedphase自由轨迹0→.001s两档1/2步通过，T差5.5e-12K、stretch差1.8e-12、外功残差<6e-11J。原宽误差精度失败与资源失败均保留，详见DYNAMIC_SOLID_STORAGE.md及research/dynamic-solid-v1。

当前唯一活跃验证session28559：非editable安装已完成且58个site-packages模块实际与源码逐字相同；安装167相关测试含真实wet两档正运行，外层90s硬限。恢复先poll同句柄，未终态不得宣称安装通过/重启。源码和tests冻结，下一任务不得并行跑EOS。下一必需阶段是固定相host接相间水分转移/耗尽事件及源误差传播，然后多格相容、输运/反应/烧结冷却完整周期；本阶段短单格轨迹不是目标完成。Goal继续active。

机械状态安装验证终态：唯一session47407已exit0，284 passed in44.62s。实际XML解析零失败/错误/跳过，56个实际site-packages模块与源码逐字节相同。安装cwd=/private/tmp、无PYTHONPATH。不存在待运行本阶段测试，不再轮询47407；下文“进行中”仅保存当时状态。

机械core独立审查已实际读完整修改与测试，无阻断；checkpoint/service修复后code-reviewer复核APPROVE。下一点储能候选仅由reacting_skeleton_provider在/private/tmp/brick-dynamic-storage-candidate准备，不改repo、不安装、不跑EOS；恢复先读代理/候选实际文件。候选方向为不依赖PrescribedSlabMotion的单格DynamicSolidStorage，零速率恢复能→实际温压→自由率，完整几何/来源/误差身份保留；尚未应用，不属于284通过版。

2026-09-08 UTC 机械动态状态阶段：从 f7bfa7a 实际推进 integration.py 的显式 mechanical_stretches/rates、独立误差尺度、全RK阶段及拒步/取消事务和伸长求积账本；checkpoint 保存/逐位连接/原初态累计审计机械字段。旧固定/规定几何主机和未同步实现的耗尽路径明确拒绝机械状态，库存舍入回写保留字段。具体合同见 MECHANICAL_STATE.md。源码122核心/检查点/轨迹测试3.16s及162服务/搜索/旧事件测试31.70s通过。旧非机械基准16接受/1拒的原字段逐字一致，新字段均None。相关原始XML、RED和修复前缺import失败已保存在 research/mechanical-state-v1。非editable安装实际56模块匹配；安装同组验证进行中，恢复先检查下述终态记录/唯一session47407，不重复启动。

新的下一执行点：新增直接接受当前机械状态的点储能入口，不能构造预定motion代替动态状态。由(n,t,N)构造体积/孔体积，以Etotal减恢复能反解温压，然后调用自由牵引闭合，给总能量加入真实外压功；先验证单格干/湿轨迹，再实现耗尽事件、多格机械相容和CLI/UI场景。当前DOP853对照只是制造自由机械轨迹（0→0.1s，p0、pe0/100），并未做真实污泥或全湿烧制验证。Goal仍active，§11未完成。

2026-09-08 UTC：新增 free_skeleton_rates.py，实现制造固定固相单格的瞬时自由牵引双速率闭合。法向/横向分别求解，保留实际牵引与功率残差及数值误差证书，不截断越域速率、不追加重复耗散热。独立物理/Python 审查无阻断；源码39测试0.14s及非editable安装39测试0.12s通过，实际56个安装模块与源逐字节相同。证据见 research/free-skeleton-rates-v1。Olevsky 教程/镍粉压力辅助论文核读见 data/sandbox/research/free-sintering-source-v1；没有准入真实污泥参数，没有分发未确认许可的教程PDF/截图。

下一可执行步骤是把 (n,t,N,E) 纳入真实积分阶段和误差控制、拒步、域终止及 checkpoint，替换只能 prescribed motion 的机械状态来源，随后验证完整自由形变轨迹；多格还需共同切向伸长与空间力学相容。当前函数的孔压由调用者提供，并非 EOS 耦合或全周期模型。Goal 继续 active；原第11节尚未完成。材料与公开验证缺口继续保留。

Agar2018 Fig3已推进为实际可重放数据：原PDF第5页矢量导出，六运行各30标记，共180项保留path顺序索引/形状/颜色，排除图例与设定TGA虚线；全标记控制点包络和轴线宽度通过Fraction角点映射为时间/温度条件区间。6个30min末点包络越图域明确flag不截断。来源和脚本哈希见data/sandbox/research/agar2018-heat/figure3；尚不是仪器原始数组、实验不确定性或模型外部验证。墙/料温不同运行身份保持，alpha/Cp循环不能作为验证。下一材料工作继续取得独立热物性或边界依据，再预登记真正的预测/留出对照，不因有180点就准入完整材料。Goal active。

比热来源追查有实质新证据：取得德国国家图书馆Agar2018原PDF（10.1007/s11356-018-1463-y），依第9页CCBY4保留未改动source.pdf及哈希，root与独立审查目视第5页。Cp1950仍是Kim&Parker引用输入；式4用Cp和同一温度曲线反推alpha，因此alpha/Bi不能独立验证Cp。Fig3的六次温度标记是可提取的传热验证候选，墙温与料温不同运行、TGA虚线为设定，尚未数字化/拟合或准入。材料9.8%湿基预干颗粒，主反应器初有空气，TGA氮气不能移作边界。详见data/sandbox/research/agar2018-heat。Kim原文机构搜索未取得，PubMed验证页，不重复无变化请求。下一主线以独立热物性/边界证据打断Cp—alpha循环，并准备该实测温曲线的预登记提取与运行级留出；完整原泥/烧结冷却仍必需未完成，Goal active。

真实材料主线新增Liu2023审计（DOI10.1093/ce/zkac058）：出版社HTML及表1/2/6/脚注/参考文献32实际读取，下载哈希，不再分发全文。Decimal与独立Fraction发现daf元素和68.78%、显热分项比例4.15684%而刊载4.02%、可用能按脚注65.16564%而刊载73.56%；比热1.95借用Kim&Parker2008，不能当同批实测。原值、条件舍入和未知基准保留于data/sandbox/research/liu2023-energy。无材料准入或EOS/求解器修改。下一具体入口：核读原引文32 DOI10.1016/j.biortech.2007.01.056的材料、比热性质和温域，继续补原泥热量/产物闭合；审计不替代烧结冷却/全周期实现，Goal active。

多代搜索已完成首个实际增量：search.py冻结目标/约束/变量/策略及来源，确定性坐标邻居、父结果关系、越界省略、全部评估和停止原因；跨代与恢复共享尝试和活动wall预算。源码/非editable安装各132相关测试通过，55模块前后匹配。原生两代五次均completed/exit0/reaped，78.995392375s；独立账本五条通过，CLI/Python一致。入选300.375K案例温差0.6249899491094197K，单独refinement1四步复算差2.9558577807620168e-12K，原1e-5K门槛通过且账本通过；不是空间收敛或现实材料验证。证据research/search-v1，详情SEARCH.md。所有原生与测试句柄终态，无活动EOS。相关会议能源研究的官方文件读取失败记录在data/sandbox/research/gnest-related-energy-v1，摘要片段未准入；不能据来源不可访问断言物性不存在。下一主线回到真实原泥产物/热容参考能的材料闭合和自由烧结冷却证据：以明确材料身份定位可核读原始数据，不能继续以制造搜索/界面功能替代全周期和三个公开机制留出验收。Goal保持active。

敏感性设计首阶段已实际交付：sensitivity.py严格1..3因子全端点设计、五条物理输入路径与单位/分类白名单、失效分支因子拒绝、冻结设计/候选绑定及所有端点完整后的高低均值差/斜率；不把网格/步长/开关作为工艺变量。CLI sensitivity-prepare/analyze已实现。128源码/安装相关测试通过；最终安装128通过3.26s，54模块匹配。原生初温300/300.5K两候选均2接受步completed，累计32.878858667s，2进程exit0/reaped，两轨迹原独立账本通过。审查后仅补指标计算模块身份字段，最终重新分析原封存结果，16原指标独立重算、8组差/斜率和CLI/Python一致；不声称metadata变更后原生重跑。证据research/sensitivity-v1共240成员重开核验。方法见SENSITIVITY.md；只是制造案例的限定端点对比，概率不确定性/全局敏感性/多代搜索仍为必需未完成。所有本阶段句柄终态，无活动EOS/测试。下一可执行项：有冻结目标/约束、父代变化和总预算的多代搜索基础，维持真实材料准入阻断；科学主线继续补同材料可闭合反应/热容参考能及自由烧结冷却，不能以应用功能替代材料全周期/公开三机制留出验收。Goal保持active。

实验级中途续算已实际核验：基线33b5e3c同一安装53模块，refinement1单候选12s取消后1接受步→run_experiment实际resume完成4累计步；两原生作业reaped，退出1/0，2次累计wall34.994843417s，原前缀和父结果SHA严格保留。根代理read_run/read_experiment及原精确账本重复核验1+4前缀、Fraction预算和代码身份通过；未新增不中断对照，不宣称一般跨重启逐位一致。证据research/experiment-resume-v1，243成员重开SHA/字节核验，无活动EOS。补齐上一阶段实际中途续算，不改物理/运行时代码。

科学来源有新决定性证据：data/sandbox/research/gnest2021已逐页目视接受稿表3/4/5并找到出版版核对；R5/R6产物和分别0.070/0.090，对式11要求的0.12/0.14均差−0.050，超过最近舍入条件界0.008。出版表3同值；TG3高温干进料产物差0.0493，表5仅分析基准账目，不是完整矿物元素。Decimal与独立Fraction审计一致，页码13修正保留审查说明。来源只作为事实/拟合候选，未做归一化、未填未知产物或Cp/反应热；论文25°C热值平衡不能补齐各伪组分动态能量。该来源直接用作全周期成套材料包的路线被阻断，停止对同表反复尝试。下一可执行工作：推进实验设计/敏感性和有父代记录的搜索接口；并寻找可解释缺失产物/分析基准及成套热容参考能的独立同材料来源，保持材料身份不混用。原泥/自由烧结冷却/全周期/公开三机制与留出/多代搜索完整要求仍未完成，Goal保持active。

批量实验阶段完成首个实际增量：experiments.py共享已有job/run服务，冻结候选/来源/代码与预算，累计尝试和活动wall，锁定顺序执行，取消请求/队列继续/描述性比较及CLI已实现。99相关源码测试2.97s与非editable安装测试2.93s通过，53模块前后匹配；最终两候选coupled/control实际31.86395s完成，两个子进程exit0并reaped，原独立账本两条通过，CLI/Python状态和比较完全一致。证据research/experiment-batch-v1共452成员重开SHA/字节核验。原归档脚本路径替换错误导致账本glob空循环误报和两CLI错误，原始产物保留，最终verify_saved显式要求两轨迹并实际核验；未改变物理门槛。审查修复总预算超限仍完成、损坏journal异常、方程目录绑定及超限覆盖原失败原因。accepted-prefix仅新编排分支测试，已有checkpoint自身验证不等同本实验端到端取消续算；pid=null的supervisor_failed仍保守拒绝，说明见EXPERIMENTS.md。所有本阶段原生/测试句柄终态，无活动EOS。新公开来源审计data/sandbox/research/raw-sludge-closure-audit-v1找到Global NEST/Energies两个不同污泥研究，产物/热化学完整准入尚未建立，不合并材料或安装猜测参数。下一步：实验端到端取消/续算、资源耗时敏感性与多代候选接口，并对Global NEST同研究产物和热效应闭合做有界可行性核查。原泥材料、自由烧结/冷却、全周期、三公开机制留出和多代搜索全部仍属Goal必需未完成，保持active。

本地中文界面阶段已实际验证：local_app与安装assets调用同一case/job/trace服务，CLI ui仅监听127.0.0.1，Host/Origin/token/JSON大小/UUID路径/来源清单守卫和单工作线程/20任务上限已实现。101相关安装测试通过5.65s，52模块前后匹配；2项无损导出/异步绑定Node回归在源码和安装资产通过。实际浏览器编辑/非法材料拒绝/求解/重放/来源打开/温压端点/对比/焦点/取消/超时/续算已执行。7原生子进程均终态reaped：3条2步completed，立即取消0步，超时0步，refinement1取消1步→续算4累计步completed21.6468s。五接受轨迹独立原账本通过，run/replay数值与诊断完全一致。发现浏览器JSON重序列化舍入大整数后已改rawtext无损导出，最终页面完整报告与原结果/manifest完全相同；旧失败、下载事件未确认、晚到取消操作和截图时序问题均保留research/local-ui-v1。四测试服务器40104/23725/57004/76677均停止，无活动EOS/测试/界面服务。Ctrl-C仍在关闭后打印KeyboardInterrupt非零退出，未称修复；Blob下载未获平台确认，可复制报告实际通过。下一实际交付：同服务下有预算的实验定义/比较和证据准入，继续补原泥成套反应/自由烧结来源与全周期闭合；炉温界面编辑、完整材料/三公开机制留出/多代搜索仍为Goal必需未完成，保持active。

整进程监督阶段已实际验证：新增job_supervisor/job_child及CLI supervise、job-status、cancel-job，实际Popen句柄控制SIGINT宽限/SIGKILL回收；父目录范围继承flock、UUID取消请求、状态/日志/CPU和原生RSS观察均保存。79相关源码和安装测试通过，51安装模块前后逐字节匹配。实际制造湿态run/replay各2步completed，外部15.7283/15.7448s，保存数值/账本/初终态诊断完全一致；10秒实际CLI取消后10.8449s退出，1接受步保留；0.05工作+0.1宽限启动超时强杀/reaped，外部0.2698s。三条接受轨迹独立原账本审计通过，四原生进程均终态，无活动EOS/测试。证据research/job-supervisor-v1保留实验外层备用时限150与预登记10不一致的偏差及原脚本；产品内层时限实际执行，不宣称外层10已强制验证。汇总校验已补足状态/退出码断言，原版本保留。仍无父监督器死亡后的独立看门狗、内存硬上限或一般强杀恢复；RSS单位明确未归一化。下一实际交付：共享服务的轻量本地中文界面，呈现运行/取消/来源缺项；原泥材料闭合、自由烧结冷却、三公开机制/留出、多代搜索、完整周期仍为Goal必需未完成，保持active。

检查点续算阶段已实际验证：新增checkpoint原始初态/逐步/累计N/E与功分项舍入审计，以及共享Python/CLI resume。仅允许普通积分器已取消且有内部接受步的同输入/同实现记录；剩余步数、拒绝次数和积分wall按完整历史扣减，后缀先保存再审计并合并，重启不重置累计误差额度。50相关安装测试通过，49安装模块前后匹配。预登记真实水+制造反应/规定变形refinement1案例按1步取消→累计2步取消→累计4步完成，CLI末次续算15.6419s；与不中断4步27.0513s的所有保存N/E、账本、终态T/P完全一致，独立原账本审计通过；累计积分26.8253s。当前无活动EOS/测试，证据 research/checkpoint-v1。早期两次测试取消触发器在提交前取消导致3失败的原文件/XML保留，已根据实际8次初态/RK/接受态评估确定下一试探时取消，未改物理/数值门槛。下一实际交付：整个服务进程的资源监督与持久运行状态，再接中文界面（当前仍无强杀恢复、通用耗尽事件检查点或完整全周期应用）；真实原泥材料、自由烧结冷却、公开三机制/留出、多代搜索保持必需未完成，Goal active。

来源图阶段完成实际增量：以525142d为基线新增安装包内19方程/38参数/4输出目录与运行时DAG，实际解析案例指针、AST函数行号、来源JSON位置及缺项，保留非JSON位置的声明性质。严格元数据/分类、引用/环路/路径、目录及代码/来源绑定检查已审查。40入口/来源测试通过；48实际安装模块及目录字节匹配。新CLI单例/重放completed各2步，外部15.5579/15.5387s，数值和完整来源图一致；独立账本通过，CLI/Python压力查询一致，四量均可追到登记来源资产。原生运行全部终态，当前无活动EOS/测试。证据 research/run-provenance-v1；方程目录仅覆盖当前制造湿态模型，资产可读率不代表材料/物理参数/实验覆盖率。下一可执行步骤：为已接受前缀接入冻结输入/实现身份的检查点续算及整个运行的资源预算，随后接共享服务的中文界面；真实原污泥完整证据、自由烧结冷却、三公开机制/留出、多代搜索和完整周期仍保持必需未完成，Goal active。上一段“完整依赖图下一步”已在本制造模型声明范围内取得增量，不能扩大为全Goal来源完成。

统一入口阶段实际完成：独立安装的 verification_case/run_service/CLI 不再依赖 tests 或临时实验帮助函数。严格 JSON/rawSHA 制造案例与真实水来源分开；25 新入口测试通过，47 实际安装模块前后匹配。两格 CLI run/replay 均 completed（外部15.5208/15.4597s，各2接受步），全部数值结果/账本及初终态诊断一致，独立原账本审计通过；四格新父态守恒初始化+初态callback通过4.0832s，未运行本入口四格轨迹。初态温度重构门槛已真正接入run服务。审查阻断项已修复，证据 research/cli-delivery-v1，操作 docs/sandbox/CLI.md。当前无活动EOS/测试。下一可执行工作：把来源导航提升为结果量—完整方程—派生参数—原始证据位置的机器可检查依赖图，补齐运行预算/恢复和界面；材料研究继续保留真实原泥关键证据缺项。此入口只有制造验证模型，不能替代材料/自由烧结冷却/公开三机制和留出/多代搜索/全周期必需交付，Goal继续active。下文历史live句柄均已终态。

程序节点修复已完成完整验证：session33496终态exit0，XML1293通过/零失败错误跳过573.270s，前后43实际安装模块及冻结源码/tests字节一致。当前无活动EOS/测试。14新回归、102相关验证、原2失败6通过和旧粗精度affine残余2失败全部保留，归档research/program-knot-v1。仅修ordinary端点表示，未放宽中点/库存/能量门槛。下一实际交付按归档NEXT_DELIVERY_STEP：接通新沙盒统一案例加载、CLI/Python运行与结果来源查询，去掉运行对tests帮助函数的依赖；真实原污泥缺项必须结构化阻断，不能自动退到制造案例。完整材料证据、自由烧结冷却、三公开机制/留出、全周期界面/多代搜索仍为Goal必需未完成项。旧live句柄为历史已终态记录。

程序节点修复候选（c3abc7a后未提交）：已在旧源码复现.005步长停在.05前一个float（2失败6通过）；新ordinary端点函数仅在已知节点、32cap-ULP界及精确库存安全余量内合并前一完整panel，不跳时间/不改中点守卫。14新回归及102相关测试实际通过。旧rel1e-7的两个保留affine算例现可完成节点/事件，但A误差1.83e-10/1.65e-10仍超原1e-10门槛，失败与全轨迹保留；当前rel1e-11同.005回归通过，不能称旧配置全通过。审查在 /private/tmp/brick-program-knot-v1/；新源码已非editable安装、43实际模块字节匹配。当前唯一EOS/测试为完整安装回归session33496，XML目标 /private/tmp/brick-program-knot-v1/installed-full-tests.xml，先poll同句柄，不重启、不并发EOS；源码/tests/安装冻结。下一步终态XML/43模块后核、归档失败和新验证、阶段Git提交。完整Goal仍active；当前不得宣称完整suite/材料/全周期通过。

固定域4格阶段已完成实际验证：2初态callback各144项面代数检查通过，171项无EOS缩放和6负控通过；4格2/4步轨迹completed30.990010/55.240541s，局部账本门槛减半后仍通过，2/4网格保守比较已完成。空间T诊断差±1.4464e-6K，远大于时间cap差，空间收敛仍未证明。43实际安装模块/4监督输入before-after-current一致，无活动EOS/测试。归档 research/fixed-domain-spatial-v1；原中间孔容构造缺陷候选保留并已修正。下一优先动作按归档NEXT_NUMERICAL_PRIORITY复现/修复普通分段时间节点单ULP尾段问题，保留原失败与中点可表示性门槛；不是继续把极短跳跃场网格比较称为全周期完成。生产/测试仍67730b2。原污泥材料闭合、自由烧结冷却、三公开机制及留出、CLI/UI、多代搜索等完整Goal继续未完成。下文live句柄为已终态历史记录。

固定域4格运行检查点：修正中间流体模板体积构造后，冻结fixture66639ad9/PLAN1ad81a3b（原候选保存在preflight-original）。两初态callback84987/58680终态通过，gradient/uniform各144项独立面代数审计通过，初N/E保守继承及同温forward广延性通过。wet4 coarse session71600已completed30.990010s/2步，逐格账本通过；当前唯一EOS为fine session15156，先轮询同句柄，未通过不可执行网格比较。源码/安装/实验脚本冻结。下一步fine账本、保守2/4网格差异与时间cap分开比较、源身份复核及归档。该短跳跃初场两网格不证明收敛；完整Goal仍active。

固定域空间细化准备中：当前生产/测试仍 67730b2，上一阶段证据提交 c62fb2f。新实验 /private/tmp/brick-fixed-spatial-v1 保持0.02m半板，4格库存/微界面面积/相变系数减半、q权重倍增，初始N/E保守细分。独立无EOS缩放检查已实际通过171项及6个错误权重负控，证据 /private/tmp/brick-fixed-spatial-audit-v1/scaling-result.json。新脚本/初态来源界正在交叉审查；尚未运行新callback或4格轨迹，无活动EOS/测试。下一步完成审查后先初态callback，再固定两timecap轨迹与独立账本/保守网格比较；两个网格不能宣称空间收敛，完整材料/全周期Goal仍未完成。

两格阶段实际完成：4 条轨迹全部 completed（coupled 2/4 步，control 2/4 步），逐格/全域独立账本通过，四组固定判据比较完成。温度约 ±1.4464e-6 K 与能量效应分辨，水库存及相变速率效应未分辨。6 个监督进程均终态，无活动 EOS/测试；全部输入 before/after/current 一致（callback 各180、wet 各181），43 实际安装模块与源码一致。生产/测试仍 67730b2，本轮仅实验/审计及文档证据。归档目标 research/two-cell-wet-coupling-v1；下一步按其中 NEXT_SPATIAL_SCOPE 保持固定物理域与广延量做空间细化，不能简单复制 q(N) 权重。完整 Goal 的真实原泥材料、自由烧结冷却、三个公开机制/留出、CLI/UI 和多代搜索仍未完成。下文旧 live 句柄均为历史检查点，不得据此重启。

当前两格验证（生产仍67730b2，源码/测试未改）：新冻结实验 /private/tmp/brick-reacting-wet-two-cell-v1，2格300/301K、规定变形、A/B反应、活动相变及内部传热/质量修正扩散；制造系数与真实水来源分开。coupled/control freshcallback66328/61026均terminalcomplete2.467376/2.453034s，耦合内面非零/对照全零，43源码安装字节匹配。当前唯一EOS为wet-coupled-0 session25354，2步上限起始设置，内部120/外部150秒100panel。审计脚本 /private/tmp/brick-two-cell-audit-v1 保存逐格/全域精确账本及失败；完整4run两mode两cap尚未完成，不能宣称空间收敛或全砖完成。先poll25354终态和独立账本，再依次剩余三条，保持所有输入冻结。

最新阶段完成：affine_midpoint及不可变二次时钟已通过1279完整安装回归（session8135终态exit0，XML585.898s，零失败错误跳过），运行前后43模块字节一致。v5两条联合湿反应/规定变形/耗尽/干态延续及原N/E/T/P/时间对照通过；独立14/16步账本、相修正及每次182输入核查通过。跨cap湿态路径相同、只干态网格改变，不能把事件时差0解释为收敛阶数；每条内部不同湿态网格检查真实通过。当前无活动EOS/测试。证据归档 research/affine-terminal-v1/（含全部候选失败、审查、原v5结果、完整suite）。下一实际步骤见该归档 readable/affine-terminal/NEXT_COUPLED_SCOPE.md：用现有模块建立2格非均匀湿态反应/传热/传质及关闭输运对照，再固定域空间细化；.005普通程序节点失分辨率仍是独立未修bug。原污泥材料闭合、自由烧结冷却、三公开机制/留出、CLI/UI与多代搜索仍为必需未完成项，Goal active。

最新v5两条均完成并比较passed：18043/36073均terminalcomplete，内层87.845694/85.501777s，260/303eval、31/36panel、14/16接受步，各1耗尽事件。compare.py exit0，N6.65799e-12mol/E2.61061e-8J/T2.60496e-9K/P3.96649e-7Pa/time0，原gate全部通过。当前唯一EOS为完整安装回归session8135，XML /private/tmp/brick-affine-terminal-v1/installed-full-tests.xml；43模块运行前匹配。先轮询终态并核XML/运行后43模块，再归档所有控制失败/独立审计/v5证据并阶段提交。源码/tests/安装/脚本冻结；不能把v5或99目标测试代替完整suite及全Goal验收。

最新v5第一条已通过：session18043 terminalcomplete/child0/89.429237s，内层completed87.845694s260评估31panel、1实际耗尽事件(.5002854010435919s)、14接受步，到.5078125s；两次末端比较及独立减半检查均通过原门槛。当前唯一EOS第二轨迹session36073（depletion1），同原120/150预算。先轮询36073终态，若通过才compare.py；随后当前源码完整安装回归与43模块复核、归档阶段提交。第一条通过只属制造反应/规定变形/真实水物性的组合，非完整原泥全周期或材料现实验证。

当前候选（e9db77b后，未提交）：新增不可变affine_depletion_clock与可选affine_midpoint末端，同权积分全部物种/能量/分项；59新测试+40旧相关测试实际99pass34.213s。来源最终switch/common漏洞已故障注入后修复；非线性公开无关制造oracle通过，较粗普通路径误差与.005旧knot失败完整保留。已非editable安装43模块字节匹配；v5 freshcallback46178终态complete2.014814s。当前唯一EOS session18043，/private/tmp/brick-reacting-wet-v5/depletion0-attempt01；原120s内部150s外部500panel及全部物理/门槛，唯一改动terminal_method。源码/tests/安装/脚本冻结，先轮询该句柄真实终态；未通过不执行depletion1。当前源码完整suite尚未执行，旧1220不能转移。Goal仍active且完整材料/全周期任务未完成。

最新完成阶段：HEOS TP回溯修正完整安装回归 session9190 terminal exit0，1220通过/零失败错误跳过，XML539.545s；前后42实际导入模块与源码逐字节一致。当前无活动EOS/测试。原生九点旧8pass1fail/新9pass；v4通过旧TP失败点和两次末端比较，但必需独立减半检查在原120s预算耗尽，0事件，depletion1未运行。74项原始证据已归档并逐项复读核SHA/长度：research/heos-tp-backtracking-v1/，包含失败XML、原始候选、源码绑定、v4结果与独立审计。下一有限数值步骤见其中 readable/wet-v4/NEXT_NUMERICAL_STEP.md：研究二阶末端积分与真实事件时钟证据，保留全部门槛和独立检查，先解析/制造解验证再原联合实验；暂未实现。完整Goal仍active；原污泥材料闭合、自由烧结冷却、三公开机制/留出、全周期CLI/UI与多代搜索仍未完成。

当前最新终态：v4 callback session26272 complete/child0/2.087812s；depletion0 session10907 terminal failed/child1/121.780958s，内部resource_limit:wall_time_limit120.127148s、365评估44试算panel、6接受步、0事件。TP旧失败点已通过；level4/5两次末端比较均通过原门槛，但独立减半普通接近检查在13panel/122评估时耗尽预算，未提交事件；depletion1未运行。完整安装回归唯一活动session9190，XML /private/tmp/brick-heos-tp-backtracking-v1/installed-full-tests.xml，42模块运行前匹配，源码/测试/安装冻结。先轮询同句柄至终态、核XML及运行后身份，再归档全部失败/审查并本地阶段提交。Goal仍active，真实材料/全周期完整范围未完成。

当前未提交TP修正：六分数原生探针session54000 complete1.16260s，五短步原动态gate+完整snapshot通过；候选控制30通过，原生九点旧版8pass1fail、新版9pass（session64092 complete1.46507s，XML1.031s）。kernel已应用c1ecb59c702382c78891f4fcf6b6ac5eb8c68cc57869b1e261ec8a3a4a796b12；manifest5f9e39bf...、wrapper和source注册仅绑定hash同步，42实际安装模块匹配。证据 /private/tmp/brick-heos-tp-backtracking-v1 与 /private/tmp/brick-heos-tp-step-probe-v1。当前无活动EOS/测试。worker准备 /private/tmp/brick-reacting-wet-v4 原5脚本/物理/门槛/120s内部150s外部500panel；还未运行联合v4或当前源码完整套件，旧1192不能移到新源码。完成review后先v4，再完整安装回归。Goal仍active且完整材料/全周期范围未完成。

最新终态：1192完整安装测试通过（session11689/535.553s），42模块前后匹配；v3联合轨迹仍在level3 HEOS TP失败，0事件。诊断43826已terminal failed49.48452s，精确捕捉295K/53692.54782795906Pa的8次双密度周期；295K是反解下界、非实际砖温。独立公开接口单点92373已terminal failed1.18991s，复现相同heos_tp_not_converged；原动态min(1e-4,rho*1e-7)Pa门槛未改。当前无活动EOS/测试。全部本轮证据归档 research/depletion-spine-v1/（旧失败/审查/安装/原v3/异常捕捉/单点），下一TP修正设计见 TP_FAILURE_NUMERICAL_REVIEW.md；须先保留精确失败并预登记有界校正，不重复整条无诊断运行。完整Goal仍active，原污泥材料闭合、自由烧结冷却、三公开机制/留出、全周期CLI/UI与多代搜索仍未完成。

完整安装新终态：session11689 exit0，1192通过/零失败错误跳过，XML535.553s；前后42实际模块与源码逐字节一致。当前唯一EOS句柄为诊断session43826，目录 /private/tmp/brick-reacting-wet-v3-diagnostic/diagnostic-attempt01；已完成两份只读脚本审查，原120s内部/150s外部限额，异常追踪不改求解器/来源守卫且不增加EOS调用。原v3失败仍未解决；先poll43826至终态，再核实际失败TP/迭代及source证据，不能把捕捉成功称轨迹通过。

最新运行入口：v3 callback session39396已terminal complete/child0/2.09734s；depletion0 session45698已terminal failed/child1/47.38958s，内部45.76055s147评估18试算panel、6已接受步、0事件，原因为 liquid_property_solution:heos_tp_not_converged；复用12观测9普通panel。不能称新事件策略完成联合轨迹；第二全轨迹细化未运行。完整新安装回归唯一session11689正在运行，XML /private/tmp/brick-depletion-spine-v1/installed-full-tests.xml；源码/tests/安装冻结，轮询同句柄，不并行EOS。下一终态核XML和42实际模块后归档提交；v3独立账本审计与TP失败捕捉方案由只读代理准备。

当前新改动（未提交）：耗尽普通湿态接近策略已应用 src/sludge_sandbox/depletion_integration.py，新增20独立测试；实际55相关测试通过13.26s，候选最终SHAab465ad7a1da9d39787afd7dd2c6dfc24e680936e9a6c99593b345ddbc49135a。可变观测别名、重复计费和最终来源绑定漏检均保留失败后修复；最后20通过5.828s。重新非editable安装，42实际模块逐字节匹配。下一串行执行 /private/tmp/brick-reacting-wet-v3 的原物理/门槛/120s内部150s外部500panel联合实验；随后完整安装回归。证据准备 /private/tmp/brick-depletion-spine-v1。原1172完整证据仅属a4f968f，不能移到当前源码。Goal完整§11仍未完成。

最新终态：压力传播修正完整安装 **1172通过/零失败错误跳过，XML557.992s，session36717 exit0**；前后42模块实际导入与源码逐字节一致。当前无活动测试/EOS。代码/7解析回归/48相关回归、v2湿态实际仍超时、独立算术与完整来源身份已归档 research/solid-pressure-bound-v1/。下一算法预登记 NEXT_EVENT_PREREGISTRATION.md；暂未实现。CLI_UI_NEXT_SCOPE.md核实应用层仍缺真实sandbox入口/持久运行与结果溯源，旧synthetic CLI不能充当完成。完整Goal仍active；真实原污泥材料、自由烧结冷却、三公开机制/留出、全周期CLI/UI及多代实验仍为必需未完成项。

最新恢复入口：v2 depletion0 session87557已终态failed/child1/121.7245s，内层wall120.0288s325评估6接受步0事件。已完成的三次细化压力指标变为0.00607/0.00519/0.00492Pa，原压力门槛通过；库存最后仍6.1412e-10mol高于1e-10，因此不能宣布联合轨迹完成。v1/v2所有失败保留；下一机制需提高事件定位收敛效率，不能增加本次上限或删去事件库存比较。当前完整安装回归 **session36717正在运行**，XML /private/tmp/brick-solid-pressure-bound-v1/installed-full-tests.xml，cwd/private/tmp无PYTHONPATH；同目录installed-identity.json已记录运行状态。源码/测试/安装/脚本冻结，轮询同句柄，无其他活动EOS。尚未提交solid_fluid_storage.py与新test_solid_pressure_bound.py，完整suite过后核XML+42模块再归档提交。tg_code_review正在只读v2算术审计，python_backtracking_integration_review在写下一事件数值设计；记录在pressure-bound-v1临时目录。

最新运行入口（994adec之后，未提交数值改动）：solid_fluid_storage.py已在保留原全局包络/越域拒绝后，以该已证明区间上端收紧同一体积误差的压力传播，原流体误差及液体能量界一致保留。7新解析测试：旧实现3预期失败/4通过，新实现7通过；48相关回归通过，两份代码/Python审查批准。重新安装42模块逐字节一致。v2位于 /private/tmp/brick-reacting-wet-v2，沿用原脚本字节/物理参数/误差/资源/事件门槛；callback session1060已终态passed，depletion0 **session87557正在运行**（120s内部/150s外部）。冻结源码/测试/安装/脚本，轮询同句柄，不并发EOS。完整新安装suite尚未启动；之前1165通过不能转移到这次源码改动。新数值证据目录 /private/tmp/brick-solid-pressure-bound-v1/。

最新终态：湿态联合callback通过，depletion0 session48458已终态failed/child1/122.0877s，内部wall_time_limit120.2988s。六接受步322评估、无事件；守恒前缀通过，但试探压力门槛含约1.602Pa误差下限，原1Pa门槛不可靠细化跨越。完整失败及173输入核验已归档 research/reacting-wet-v1-failure/。当前无活动EOS/测试，第二轨迹未运行。下一实际实现：保留全局区间及旧越域拒绝，使用已证实局部压力上端收紧同一体积不确定性的传播；证明/预登记在归档中。worker正在 tests/sandbox/test_solid_pressure_bound.py 写无EOS解析回归，root尚未改生产源码；不要把新误差界当已验证。

最新运行入口：公开 Lu2026 补充材料六条 MS 多速率失重记录及逐页独立核对已提交7af6f8d，见 data/sandbox/research/lu2026/。正文官方链接拒绝下载，基准/制备/气氛组成未知保留，未准入运行。湿态联合实验 /private/tmp/brick-reacting-wet-v1 已预登记并完成两份交叉审查；修正的是监督退出状态与失败证据保存，不改物理门槛。callback session42799 已终态complete/child0，实际同时A→B与蒸发、当前反应储能绑定通过。depletion0 **session48458正在运行**，同目录depletion0-attempt01监督，原120s内部/150s外部上限；不要重启同run或并发EOS。当前求解器/安装/脚本/PLAN冻结。下一步轮询同句柄，核实际完整结果与终态；成功后按原计划第二步长运行及独立账本审计，失败则保留原因诊断。

本次实现与完整证据已提交 **69a14f4**。当前下一阶段由 reacting_skeleton_provider 在 /private/tmp/brick-reacting-wet-v1 准备湿态反应/耗尽预登记与脚本；python_backtracking_integration_review 与 tg_code_review 等待最终文件进行只读审查。尚未运行新 EOS/轨迹，原完整安装 session99225 已终态。下一次恢复先读三代理结果与该目录 PLAN/审查，不重复旧全suite；先受监督回调，再按预登记执行联合轨迹。

最新终态：反应—规定变形完整安装回归 session99225 exit0，实际1165通过/零失败错误跳过，XML561.281s；前后42安装模块逐字节一致。93相关测试、两阶段细化与旧能量失败、独立代码/算术审查已归档 research/reacting-deformation-v1/，原始ZIP逐条重开核验。当前无活动测试/EOS。下文“99225运行中”为旧检查点。下一实验准备于 /private/tmp/brick-reacting-wet-v1，构建反应+真实水相变+耗尽联合验证，尚未执行；先审查预登记与脚本再运行。真实污泥材料/自由烧结/全周期范围继续未完成。

最新恢复检查点（dfa30aa之后，未提交）：新增显式 manufactured 的组成依赖骨架储能 q(N) 与规定变形反应耦合，旧固定固体库存路径保留。实际源码及测试变更见 Git 工作区；尚不属于真实污泥材料准入或自由烧结。93 项相关测试通过，Python 与代码审查通过。原细化对能量差 4.7827488742768764e-6 J 超过原 1e-6 J 门槛，失败保留；新 64/128 步结果由独立账本审核确认 ΔN=2.943464569304943e-11 mol、ΔE=2.9892544262111187e-7 J、ΔT=2.927231435023714e-8 K、ΔP=2.3685191990807652e-5 Pa，原物理门槛通过。新细化仅把显式步数资源上限从 100 提至 160，其余门槛未放宽。证据在 /private/tmp/brick-reacting-deformation-v1/，旧失败与修正均须归档。

当前完整安装回归 session_id=99225 仍在运行，XML 目标 /private/tmp/brick-reacting-deformation-v1/installed-full-tests.xml；不要重新启动或并发运行 EOS。42 个实际安装模块已与源码逐字节核对，测试期间冻结源码、测试与安装。下一步轮询同一句柄至终态，核实实际 XML 和安装身份，归档轨迹/失败/独立审查后再提交。尚不能声称完整回归通过。完整目标继续 active；材料证据、自由烧结冷却、公开机制与留出验证、全周期 CLI/UI/多代搜索仍未完成。下文为旧检查点。

最新恢复检查点（18087a6之后）：Areias2019 Figures38–40已按冻结预登记实际点选39目标，35可辨/4unknown。Fig38的300/400与Fig39的300完整抗锯齿列足迹超±2；Fig39的400被品红遮挡，不换列/补值。数据及来源链、原像素RGB、独立看图/74区间核算、精确舍入修复、4测试、实际JSON/CSV重放与图像重提取/再现证据在 data/sandbox/research/areias2019/tg_digitization/。

中间Decimal舍入对1e-100量级偏移可向内，独立发现已改Fraction整数floor/ceil，原发现与最终复审均保存。35观测是条件坐标读图候选，不是实验置信区间、反应转化率或模型外部验证；N2单速率、基准/制样/产物未知不变，材料/训练/动力学准入false。原论文及六张审阅图保留ignored缓存，无新增再分发许可。

物理src与既有1135安装验证版本不变，本轮不重复全suite或EOS；当前无测试/EOS待轮询句柄。本轮已产生实际来源数据与可重放转换器，属于progress。TG数据与代码/独立审查已提交ef5216f。下一实现的只读代码事实已保存 research/REACTING_DEFORMATION_SCOPE.md：host构造、host库存与skeleton三层仍限制固定Ns；反应config必须重绑实际current_storages。现有热U已含Ns形成能，不能额外加反应热；总压力功与组成依赖机械储能的拟议分账仍须独立推导审核，不能直接删guard。下一具体动作：预登记并实现新的显式制造反应骨架接口，先不改旧固定Ns身份/拒绝；以干态A→B不同占积/形成能+规定压缩、独立标量温度参照和非一阶速率当前体积检查推进实际耦合。随后验证组成依赖机械储能及水/输运组合；自由烧结和真实材料本构不因制造例通过而准入。当前无活动子任务。完整材料域、自由烧结冷却、三公开机制与留出、全周期CLI/UI/多代搜索继续为Goal必需未完成项。Goal active。

本次数值修复及1135完整安装验证已本地提交 `4f4590b`。TG下一步预登记已保存 `research/areias2019-tg-preregistration/`：三图分别校准，六映射/中间刻度残差经独立Fraction核算，固定每图13个目标温度，尚未选择TG曲线点。下一动作按预登记选可辨绿色重量点、保留遮挡unknown、核条件像素包络并独立复读；不能从读图误差推断实验不确定性或反应参数。当前没有待轮询EOS/测试进程。

最新恢复检查点（ae38c70之后）：HEOS共存求解已应用有界回溯Newton，保留原dp≤1e-4Pa、dg≤1e-6J/kg、分支/稳定性/源身份和8个外层状态上限；每次至多6个半分试探，总计至多43对EOS状态。kernel SHA 88bbbdd91fbe12d351faf6415883c177fec2fec4a7e51d77d98d864b49d51d93，manifest及固定包装摘要同步更新，11项数值控制回归已加入。独立代码/Python集成审查通过。

原精确失败温度及邻点：旧版11通过1失败，新版12通过；原30状态/7导数/17故障路由检查通过。冻结非editable安装后192项相关测试通过。**完整安装套件session85070已exit0：1135通过、0失败/错误/跳过，517.635s；测试后再次核41个实际site-packages模块与源字节一致。** 所有本轮EOS/测试句柄均终态，无待轮询进程。证据见 research/heos-coexistence-backtracking/。

原callback脚本/物理字段不变，新组合耗尽session70146 exit0/57.216599209s，14提交步/15状态/1事件到0.5078125s；原事件门槛和独立逐步/累计水能量与浮点修正账本通过。修正预算含原显式numerical_clock_inventory_residual，未放宽为任意容差。只保存的refinement指标已核门槛，不能从未保存的全部参考态独立重建T/P差。旧失败和不同版本保持分开，不迁移其验证身份。

本轮为数值修复和制造夹具耦合验证，不是自由烧结或真实原污泥全周期。下一来源动作：按三批TG各自刻度预登记稀疏数字化及读图误差，生成经独立复读的观测候选，不由单速率推断唯一动力学。下一实现须推进反应/空间输运/自由烧结冷却的实质缺项；原污泥材料闭合、三个公开机制及留出、全周期CLI/UI/多代搜索仍为Goal必需未完成项。Goal active。下文为历史检查点。

最新恢复检查点（2e16a70后）：规定形变/活动蒸发/耗尽组合已实际运行并揭示HEOS共存求解故障，证据 research/deforming-active-depletion/。单callback通过；耗尽attempt01 exit1/27.881735s、72评估、6提交步、0事件，heos_coexistence_not_converged，不能称耗尽通过。已提交前缀能量/水与5功精确分项检查通过。

真实末状态重启诊断exit0/6.0085565s，内部仍失败：chemical kernel在299.9996124454831K八轮密度更新振荡，dp略超1e-4Pa而dg已在1e-6J/kg内。两端点独立native probe复现，半步/四分之一步均过原dp/dg，实际exit0/1.149743s。未改kernel、未放宽门槛、未将调试exit0称物理成功。replay unused vapor的−Infinity是未初始化私有诊断，原件保留，不作物性。

**所有句柄6613/41736/24073/77192均终态，目前无活动测试/EOS进程。** 下一可执行动作：隔离实现有界回溯Newton，先以保存的精确失败温度和邻近点复现/验证原共存及Table3门槛，保持源/运行身份；通过相关数值/故障/安装检查后，重新原组合耗尽案例，保留旧失败。生产仍是9ba520d源码及1124安装回归证据，本轮没有新生产修改或完整suite。

TG原图提取可行性已核三原生图及8资产哈希，见 research/AREIAS2019_TG_EXTRACTION_FEASIBILITY.md；绿色重量可以有限读图，Figure40纵轴不同，三图分别校准；有界未发现仪器数组，不声称不存在。尚未数字化。来源与完整材料域、反应/输运/自由烧结冷却、三机制/留出、全周期CLI/UI/多代搜索仍为必需未完成项。Goal active，本轮是真实运行、故障定位与局部数值证据进展。

最新来源检查点（9ba520d之后）：已核读Areias2019 Tables16–22和热分析方法/批次对应。六组成表83条转录与原页逐项复核，独立Decimal保留Table20条件总和[91.66,92.31)%而不归一化。三批日期支持Tables17–19与Figures38–40的明确名义批次链接，见 data/sandbox/research/areias2019/batch-links.json；不证明同分样/共同质量基准，处理泥与Table21未强行匹配。

热值四项、氧弹/He等温TG-MS/N2升温TG-DSC/膨胀仪条件已机器记录。N2方法与300°C氧化解释、1050°C方法与1100°C结果文字冲突保留；没有据此拟合耗氧反应或自由烧结。源码未改，1124完整安装通过仍属于9ba520d的既有证据，本轮未重跑EOS或测试。

下一来源步骤：按三批明确身份核查Figures38–40坐标及原始数据可得性，建立带读图误差的TG观测候选，并保持单速率/机制不可唯一辨识限制。实现工作仍须完成湿态活动相变与变形/耗尽组合、空间输运、自由烧结冷却及全流程应用；来源核读不替代物理实现。当前无待轮询进程；Goal active，本轮有实际新证据与材料映射进展，未达到§11完成条件。

最新恢复检查点：最终 v2 普通积分器时钟修正已完成实际冻结安装验证：**1124 pass / 0 fail / 0 error / 0 skip，525.571 s，session83463 exit0**。测试后再次导入核对41个实际安装模块与源码逐字节一致。当前没有待轮询测试或EOS句柄。证据见 research/integration-clock-correction/；原v1完整1121pass/2fail、独立失败重现、修复与审查均保留。

最终v2用Fraction累加名义时间，拒步重锚，并保留原严格局部1ULP guard；实际RK与全部账本仍完整积分表示后的端点差。新增12项clock回归。原活动相变制造三尺度实际2/4/8步、15/29/57评估全部到.51s，原25/30s资源及两最细N/E/T/P门槛通过。不是完整湿变形、原污泥实验或全模型现实验证。

新增 data/sandbox/research/areias2019/：UENF官方论文的实验室15%石灰基准为采集污泥干质量；采前已有不明剂量加灰，不能把 lodo bruto 当作确证未经处理原泥。与2025筛分/制样不同，同批未证实，材料参数未准入。2025 Fig.4 已完成26点数字化的旧错误描述已更正，原始历史事实不覆盖。

下一步：核读2019自身三批采集泥与实验室处理泥的组成/热分析及样品映射，评估可闭合的材料域，不能迁移2025参数冒充同批；实现方向继续完整湿态活动相变/变形与耗尽组合及自由烧结，保留原门槛与实测成本控制。原污泥热化学/反应/输运/烧结/冷却本构、三个公开机制与独立留出、全周期CLI/UI和多代搜索仍为必需未完成项。Goal active，本轮为实际实现、验证和来源核读进展。下文是历史检查点，状态以本段为准。

运行中检查点（本轮尚未提交）：普通integrate已试行Fraction名义时钟、接受推进/拒绝重锚/断点同步，实际RK/账本仍端点差。先10clock7fail3pass，修改后38pass，另补第11常功测试后联合117pass。已安装这一v1（integration SHA a2afb84f开头），同原活动相变三尺度实际2/4/8步15/29/57eval，原25/30时间限制及两最细N/E/T/P门槛通过。结果 /private/tmp/brick-clock-fix/wet，源码/数值独立审查已通过。但它不是最终版本。

完整安装v1 suite **session61318已终态：1121pass/2fail，520.78s**，实际XML与身份保留在/private/tmp/brick-clock-fix。两项失败：test_depletion_components 的 terminal_and_all_normal_components_preserved 与 total_energy_binding_survives_terminal_and_normal_restart，原因unresolvable_stage_time。定向无EOS重现2fail，trace定位.15→.2名义.01在binary输入差下尚留1ULP；先前单ULP端点合并仍有必要。

上述v1完整suite期间源码/安装保持冻结，终态后已应用受审v2并加入第12个clock回归、重新安装。正在/private/tmp/brick-clock-final重新原三尺度，尚未完成最终完整suite。受审v2已在/private/tmp/brick-clock-fix/v2/sludge_sandbox/integration.py，SHA b3d3665b0dc73d372af4b88c1b3c17b4637288a271d66b9168d89b3682587524，仅在exact时钟后恢复原min(ulp(target),32ulp(step))局部guard，再同步target并完整积分。50目标测试/独立大origin短步拒绝/两个原fail通过，COMPATIBILITY_REVIEW.md已批准。/private/tmp/brick-clock-fix/test_local_endpoint.py是先失败的新增常3W端点回归，尚未并入生产tests。

下一步：等待61318真实终态并保存v1完整报告；应用受审v2、合入新增回归、冻结重装，重新原三尺度和全suite，核真实安装41模块、归档所有初失败/补正/审查并本地commit。此前goal缺项均保留；不可把v1三尺度通过或v2定向通过称最终全套已过。当前有实际实现/失败诊断/验证进展，Goal active。

最新检查点：2b1d07f生产源码未改，已用实际安装HEOS验证非零相变与规定变形，证据research/heos-active-phase。原callback独立Decimal/Fraction算术、当前几何/一次逆解/液汽精确±/无重复潜热通过，exit0/1.956s。明确layout[solid,H2O汽,H2O液,carrier]、初态[2,1e-8,1e-4,.001]为制造fixture。两条同初态/模型/运动/精度t.5→.51轨迹，K1e-7/K0，实际各2步15eval、外部7.998/7.930s，全部prefixN/E/总水与反应对称账本通过。活跃汽增3.4788077e-6mol、比K0末温低.0014410767K，满足预登记1e-4K；局部亲和力/熵产生可独立重算，不能称全系统熵或独立轨迹真值。

按预登记减半步长：fine .0025完成实际5步36eval/14.562s积分，含2.22e-16s尾步，所有prefix账本通过；finer .00125失败wall_time_limit25.052s/外26.543s、62eval8接受停.5099999999999998，未到同终点。未提高25/30上限，三尺度refinement_compare未执行，不能宣布三尺度通过。无EOS解析常库存复现同时间行为：8步cap在57eval停、10步cap实际64eval9步完成，尾步=2ulp(.51)。原失败/算术审核/源绑定全部保存，41安装模块与当前源字节匹配。

本轮所有句柄64204/78508/68872/83417/44702均终态。下一动作：为时间推进累加舍入尾步建立数值政策/回归并修复（仍须完整积分剩余区间并入账本，不能snap终态或放宽物理门槛），然后重跑同finer并完成三尺度比较。当前活动相变短积分已实现运行，但完整湿变形/耗尽、实际原污泥材料、空间输运/烧结冷却、三个公开机制及全周期CLI/UI/多代搜索仍为必需缺项。Goal active，本轮属于progress。

最新检查点：HEOS运行时检查优化已应用，证据 research/heos-runtime-optimization。阶段7仅runtime canonical重编码改rawSHA，构造双核验/前后读取/配置/锁/警告不变，30点7导数9故障stub通过；原湿前缀仍wall_limit/27eval3接受。阶段8另将原饱和try-body原样提取为私有锁内方法，公开饱和和温压各自完整事务，内部不重复，无缓存。原算术AST等价，17故障/公开路由stub和30点7导数通过；stage8原四步积分14.502s/29eval4接受0拒，所有原门槛通过，阶段7共同3步账本/4状态库存能量精确一致。旧失败均保留。

两源码与对应真实manifest/source摘要经独立审查后应用；源码身份改变不冒充旧结果。普通uv pip离线无法选缓存numpy失败后，uv sync --frozen --no-editable --inexact --extra dev --extra water --offline成功安装锁中numpy2.5.2并保留单独核查CP8.0.0。实际41site-packages模块与源码字节一致，水相关212tests/0fail/error/skip/1.486s，测试后再核41模块；本轮未重跑全1112。安装湿态runner仅tests helper在PYTHONPATH、无候选包，并assert所有sludge导入site-packages；原四步14.40582975s积分/18.59541429s外部，29eval4接受，T误差8.606e-9K/P1.1998e-5Pa/孔压功7.35993e-7J及全部Fraction账本/独立Python熵原门槛通过。独立审查已核实际源码/来源/安装/数值记录。

所有本轮工具句柄已终态，无EOS待轮询。下一动作：把显式HEOS接入原非零相变系数的规定变形callback及实际活动相变短积分，保留共同化学/能量/源身份、当前孔隙、单次逆解及耗尽门槛。不要把当前固定库存前缀称为活动蒸发或完整10%变形。仍需完整原污泥材料证据、干燥反应/供氧输运、自由烧结冷却、三公开机制/留出、全周期CLI/UI和多代搜索。Goal active，本轮有实际实现与验证progress。

最新检查点：dcabd8d 生产源码未改，HEOS 原四步湿压缩短前缀已实际尝试并暴露成本瓶颈，证据 research/heos-wet-stage6。预登记保持原 0..1/64s、4步、1e-6J/K逆解、T2e-5K/P.2Pa/各功1e-6J、25秒积分/30秒外限，独立 Python entropy oracle 原文件不改。初态库存精确、新旧身份规范化后不同且各自匹配 operator；同300K初能差1.74623e-10J通过原1e-6J，未覆盖能量。执行前修正测试tuple/list假身份差异，审查记录保留。

attempt01 缺pytest导入失败未进EOS，离线补锁中pytest8.4.2及已记依赖后原脚本attempt02实际exit1/28.734s；积分wall_time_limit，26.853s/10eval/1接受/0拒，未到熵参照或末端门槛，不能称湿轨迹通过。没有放宽门槛重跑。session29821已终态。

一次实际同初态求值profile exit0/4.56048s（session19385终态）：求值约2.72s，205水状态，410事务/820生成器进出，事务累计2.648s，JSON encode/decode自身约1.077/.610s；累计项不相加。独立审查核脚本、输入、失败和profile，表明当前主要成本是反复完整fluid JSON核验，不是原生EOS计算，未证明整体加速。生产41模块/1112完整安装测试仍是dcabd8d证据，本轮只有制造诊断而无新完整suite。

下一动作明确：隔离候选仅将runtime流体canonical重编码检查改为构造时已同时核读的原始字符串SHA，保留每次前后读取/配置/lock/warnings及全部数值门禁；格式变化更严格拒绝。先单变量故障和公式验证、更新真实实现manifest后再回原四步短前缀。不要同时缓存/嵌套去重或提高超时。完整原污泥域、活动相变/全周期、烧结冷却、公开对照及CLI/UI/搜索仍为完整Goal必需缺项。上一轮和本轮均为progress；Goal active，无运行句柄待轮询。

最新检查点：HEOS stage5 已把显式可选混合后端接入生产源码。真实液汽 EOS 用已审查 HEOS 内核，理想部分保留 Python IAPWS；物理参考态与不可变软件实现身份分开，完整 canonical 身份绑定 provider/schema/source IDs/定义及代码。身份贯穿水状态、化学、相、闭合储能与目标记录。默认 Python 不变，状态 dataclass 新增 implementation=None 字段；不宣称历史全部 JSON 字节不变。

清单固定 SHA、实际运行 descriptor 二次比对与来源路径已独立审核；不接受调用者自行改写清单来准入未验证构建。来源记录 data/sandbox/water/heos-8.0.0-source.json、固定 manifest 与 docs/sandbox/HEOS_BACKEND.md 可查询软件、许可证、原始流体及 IAPWS。缺少可选依赖时明确 WaterSourceError，无静默降级。实际已安装默认环境没有 CoolProp，该拒绝已验证。

隔离候选默认相关 212/298 测试通过；最终固定清单候选 smoke 与原闭合储能制造测试逆解合并实际 exit0/3.948618084s，保留原逆解 1e-5J/1e-4K 等门槛。默认 canonical 与旧记录相同，替代实现身份不同且稳定、剥离身份与混用拒绝。早期 descriptor 摘要未涵盖完整 envelope 的碰撞已修复；原候选、失败/修复及独立复审归档 research/heos-stage5。应用的 13 个源码文件与最终审查候选逐字节一致。

冻结非 editable 离线安装后，实际从 /private/tmp、无 PYTHONPATH 运行全 sandbox 套件：**1112 passed in 519.65s**，XML 1112 tests/0 failures/0 errors/0 skipped、time519.651s。session34061 已 exit0，41 个实际 site-packages 模块在测试后重新导入并与当前源逐字节及 SHA 一致。证据 research/installed-sandbox-heos-interface-tests.xml 与 identity.json。本套件证明默认安装回归，替代后端的有界运行证据来自单独已核查的 HEOS 环境；不将二者混称替代后端完整主机测试。目前无待轮询测试/EOS句柄。

下一动作：完善可选依赖锁定/安装契约及替代后端集成故障测试，再以原门槛验证活动相变湿逆解、短前缀和实际成本。尚无整体提速证明，不能直接扩大为长湿扫描。全原污泥材料证据、反应/输运/自由烧结/冷却、三公开机制与留出对照、全周期 CLI/中文 UI/逐代搜索仍是完整 Goal 必需项。Goal active，当前为阶段性实现和验证，尚未完成全模型。

最新检查点：HEOS stage4隔离TP改进与扩大验证已归档research/heos-stage4，生产src仍6dc5aa9。初30state网格28pass/2fail，293/300K100MPa液体energy残差2.314e-6/2.096e-6>1e-6保持失败。新增nativePT只做phase-verifiedseed，再解pEOS(rho,T)=原targetP，logrhoNewton slope=rhoRTD，max8/step<.1，目标min1e-4Pa,rho*1e-7。nativeh/u/s与targetP不重置，原全部gate不变。新同30cases全部通过1.52217s/exit0，两原失败实际一步密度更新改善，raw迭代独立重算通过。

另外7原liquid/vapor中心差分案例通过1.50251s，原33IAPWS印刷点通过1.03654s；实际5snapshots/导数差分与单位/API经独立复审。math.isclose symmetric与原pytest.approx尺度略异，已对实际21+33数值额外按原expected尺度重算54项全部通过，不重标代码执行方式。275/625K是raw backend公式核，不扩candidate293–500K域，也不算实测材料验证。

参考态初测试错误预期existing实例跟随global setter，identity01 failed保留。核读官方Reference States后不改kernel/gate、更正验证对象：旧snapshot完全不变，新nativeh实际变，新candidate被原anchor拒绝；DEF恢复后4workers/12calls（4独特点重复3次）sharedinstance结果与sequential相同，identity02exit0/1.40425s。不是多实例或并发全局mutation安全证明。所有research脚本/失败/实际过程及review保存；没有待轮询运行句柄（13010/5191/52153/27773已终态，其余本轮工具直接exit）。

下一工作保持完整Goal：完成HEOS剩余故障/种子拒绝与显式loader/immutable公共descriptor，贯穿caloric/chemical/provider/closed-storage身份后才准入原wet逆解与短前缀，不把30点称为全域或完整stage4。测完整验证后端成本再扩大湿积分。cache尚未新增，需先定义契约；全原污泥物性/反应/输运/自由烧结/冷却/三公开机制对照/CLI/UI/多代全周期仍未完成。Goal active，本回合真实代码/失败修复/验证属于progress。

最新检查点：隔离HEOS stage3候选已实际实现并归档research/heos-stage3，生产源码仍6dc5aa9。初始QT饱和蒸汽h-u-p/rho2.74099875e-6J/kg未过1e-6；独立子进程关superancillary反而.00182574，两失败保留，不声称开关唯一根因。改用QT种子、DmassT原生EOS评估与同T双相p/Gibbs共存门禁，能量/熵不代数重置；Newton Jacobian已独立核对。seed重评已过gate，最终删除强制更新，不能称为Newton误差改善或广域收敛证明。

最终attempt05实际exit0/1.169895s、59声明输入不变：300K两饱和相+两液态TP点4对照、6域拒绝、3不可变、5故障拒绝均通过。原pressure/caloric/Gibbs/cp-cv/energy等门槛不变，最大h-u-p/rho9.818086e-8J/kg。raw JSON、不同版本候选、原失败/运行日志/监督器证据与review03均保留。实际来源/28package文件/loadedextension/完整fluid/精确M与R/adapterSHA/effectiveconfig进入区别于Python的descriptor，ideal h/s anchor及前后config/fluid检查已实现。原设计R字面值舍入已纠正。不代表完整backend/主机准入或已提速。

下一可执行工作：HEOS stage4分批验证官方点、293–500K液/汽与高低压、响应有限差分、确实需要迭代的共存种子与拒绝路径、fluid/reference故障、并发与cache契约；随后才能把descriptor贯穿现有桥接/化学/储能身份并接原湿前缀。保留受控单进程研究范围，不能把instance lock当进程全局修改安全。无EOS运行句柄待轮询（40652/18934/94515/72418/64056/82691全部已终态）；生产38模块/212相关安装测试为上一轮，旧1112完整套件是更早源码证据。全原污泥域/全周期/公开机制对照/CLI/UI/多代搜索仍未完成。Goal active；本回合有真实代码、失败诊断与验证进展。

最新检查点：默认Python水后端调用层已独立审核并应用（下文ecfb3e9/1112为历史完整suite）。新增私有固定静态调用类，仅转发当前native对象，不改变来源、单位、参考、容差、异常作用域或缓存。独立AST九调用逆变换后与旧模块整体相同。隔离117+95相关测试通过；冻结非editable安装后212相关测试实际1.46s通过，38实际site-packages模块与源逐字节一致，session12878已exit0。没有运行新全套或湿轨迹，不把旧1112升级为本版本完整证据。

初轮golden因直接执行candidate目录脚本可能污染sys.path，不作为旧/新比较证据，原记录保留。修正bound_golden.py在stdin独立进程运行，先断言实际加载路径并记录不同源码hash；old ed7adf/new66ccc，5温度30数值+4域错误、reference is和冷热canonical检查，JSON逐字节相同。证据research/water-python-seam。本轮有实现与实际验证进展，Goal active。

下一动作：按water-backend-feasibility/ADAPTER_DESIGN第3步，在隔离目录实现显式HEOS来源/二进制/流体/常数身份与小范围TP、饱和及Helmholtz检查。先原两液态点与300K两饱和相，原门槛不变；尚未准入任何替代后端，不应修改生产科学引用来伪装，也不立即跑长湿扫描。全原污泥材料域、反应/输运/自由烧结/冷却力学、公开三个机制组、CLI/UI和逐代实验仍未完成。

最新源码ecfb3e9：当前孔隙模板、规定变形程序边界与相变显式组合已应用。冻结非editable离线安装从/private/tmp无PYTHONPATH实际 **1112 passed514.98s**；37个真实site-packages模块与源码匹配。research/installed-sandbox-wet-admission-tests.xml及identity.json保存实际证据。session45600已exit0；旧75509/89265/46721均已结束，不再轮询。当前无运行中的测试/EOS进程。

真实callback01在相变化学前被参考孔体积门禁拒绝，保留后修复当前bulk减固定固体占积；9noEOS独立通过。callback02实际1.387s/exit0、113声明输入不变、非零K/液汽精确成对/无额外潜热/当前几何/单次反解通过独立审核。其原fixture反解1e-5J/1e-4K，不能混同下一段1e-6J/K。原候选/失败/先RED/回调与应用34测试73s在research/deforming-wet-admission。

独立湿态熵端点2.07s通过不等于轨迹。原0→1/64s短前缀2接受/15评估的孔压功2.97406436e-6J未通过1e-6J，保留research/wet-deformation-entropy。refinement02同原1s/10%运动及同短终点，将initial/maxstep1/128→1/256；实际4接受/29评估/0拒，25.5696s/exit0，初始N/E/tag精确匹配原失败，所有原精度门槛保持，孔压功7.35992551e-7J通过。原生u/s及全部账本保留，已归档research/wet-prefix-refinement。因含当前孔隙源码修复，不宣称严格同源码收敛阶；只有末端独立组件真值，全部prefix检查是账本闭合。完整10%湿轨迹、活动相变积分/变形耗尽仍未验证。

研究监督器research/research-process-supervisor已独立17测试1.38s通过，实际TERM取消清理/failed传播通过；历史子进程残留与EPERM失败保留。它已用于callback02/refinement02，不是通用进程沙箱。默认生产水EOS仍为iapws1.5.5。可选快后端只有两点可行性与设计，见research/water-backend-feasibility；不要把原始flash倍率冒称完整主机加速。

新增Arlabosse2005低温比热来源记录，原文/3图、4资产哈希、干基单位与35–105°C温区已独立核读；原始文件在ignored .tools缓存，登记data/sandbox/research/arlabosse2005。进水85%工业/15%市政、初始水分正文/表差异保留。它只是特定材料低温关系，缺绝对参考能/误差等，未准入运行材料包。

下一可执行步骤：依据已审查ADAPTER_DESIGN，在隔离目录实现可选后端接口的**现有Python默认路径**，先证明原源码行为/来源/相域/错误/缓存等价；通过后才准备HEOS实现，不能直接替换EOS或启动数小时2048步湿扫描。并保持同原污泥域热化学/动力学/输运/烧结/力学及三个公开机制组、CLI/中文界面/逐代搜索等必需缺项。Goal active，软件仍在实现，科学状态无完整原污泥材料域，部署仅离线研究。

## 当前状态

- Goal：active；持续实现中，本回合已修补数值缺陷并完成阶段提交，属于 progress。
- software_status：implementation_in_progress。
- scientific_status：partial_sources_no_complete_raw_sludge_domain；完整原污泥材料域尚未成立。
- deployment_status：offline_research_only。
- 当前阶段：G0 历史B2故障已修复；G1 基础模块已提交；G2 守恒积分、配平反应、刚性气热、独立账本、纯水适配器已通过有界验证与独立复审；完整湿砖全周期未实现。
- 基线：`4b4f2d3`；分支：`codex/physics-sandbox-v1`。
- 开始时已有未跟踪文件仅 `docs/GOAL_BRICK_PHYSICS_SANDBOX.md`，为本 Goal 合同，保留并纳入本任务。
- 当前工作目录 `/Users/wanggaoying/Desktop/brickmodel-github`；未修改 Hermes、同步任务或远程仓库。

## 已核对

- 适用父目录及仓库无 AGENTS.md；Git 历史与既有研究记录已读取。
- 已读取完整任务合同、模型架构/公式/参数与研究状态、B1 冻结合同、B2 推导/失败范围。
- 早期 VME 的固定有效热容能量恒等式、累计供氧上界、synthetic 黏度/收缩/性能关系不能直接承担新模型的材料结论。
- 当前机器 macOS arm64；系统 Python 3.14.2，使用 Python 3.12.13 的隔离 `.venv`。锁定 numpy/scipy/pytest/Pillow 已安装。使用 `UV_CACHE_DIR=/private/tmp/brick-sandbox-uv-cache`。

## 本轮已实现与验证

- 本地阶段提交 `0634e80b1fa4d69c195022f1c7ecd79a16110fe2`：B2 暴露量积分曲率步长界、真实失败审计、Darwin RSS换算与回归；没有改原1e-6门槛。
- 实际提交绑定 `run_tests.py`：14单元测试，全部8类NUM门槛通过，34次focused积分；77.61s、41.52MiB。实际default 22情景完成，绑定bound；15.92s、94.63MiB。独立audit 322204 checks通过，最大暴露误差6.9171e-8。
- 完整原始源码/输入/结果/验证打包在 `research/b2-bound-0634e80/reproduction.tar.gz`（565成员），摘要和命令在同目录 `summary.json`。这是实际绑定验证和离线包，未宣称对离线包做了全部重新积分。旧失败原样保留。
- `sludge_sandbox` 新包：证据DAG/分类/域/未知阻断、单位、干湿料账目与独立分析类别、相容半板几何；所有制造值仅是测试。
- NIST四气体10段80个Shomate系数核读与移录；真实表点/导数/能量反解测试。原始接缝保留，能量间隙、多解及浮点精度不足会拒绝；没有低温水汽/液水/固体补值。
- 实际集成基础测试：`PYTHONPATH=src .venv/bin/python -m pytest tests/sandbox/test_evidence.py tests/sandbox/test_units.py tests/sandbox/test_materials.py tests/sandbox/test_geometry.py tests/sandbox/test_thermochemistry.py -q --junitxml=docs/sandbox/research/g1-core-tests.xml`，122 passed。
- 公开研究：7篇候选资料、Wang 12条件186图中实验符号派生读数、Mohajerani24终态值、Nowicki9拟合率等。条件冲突/基准争议均隔离；没有拼成完整原污泥材料包。
- 气体中心修正曾从零物种格移出物质，已添加先失败回归并改为correction drift成分上风，79测试与独立150场景/450方向复查通过；不能靠无限减步长补救。物质焓接口有10项实际测试，net与diff/adv分项必须一致。
- 干净非editable冻结离线安装已实际验证：从/private/tmp运行，未用PYTHONPATH，site-packages真实导入；最终211 sandbox测试通过。报告 `VALIDATION_REPORT.md`，原始XML `research/g1-installed-final-tests.xml`。仍未完成全流程CLI/UI安装验收。
- `WORLD_SPEC`、`EVIDENCE_POLICY`、`VALIDATION_PLAN`、`SUPPORTED_DOMAIN`、`KNOWN_GAPS`、方程映射已建立并明确已实现/未实现。

平台细节：本地工具回合会使 `.venv` 文件隐藏，Python3.12跳过隐藏 `.pth`，editable导入不稳定。开发显式 `PYTHONPATH=src`；最终必须另测干净非editable安装，不能靠该路径声明安装验收。外部`/usr/bin/time -l`曾因sandbox kern.clockrate/sysctl被拒绝，内部RSS/耗时单独报告，未反复重跑掩盖该问题。

## G2 已完成的有界能力

| 本地提交 | 实现与验证 |
|---|---|
| `e3dda49` | 配平反应、库存分辨率守卫；49测试、独立复审通过 |
| `a18310b` | 13份IAPWS原始/派生资产；33个官方数值独立重算 |
| `e259c29` | 守恒积分器28测试、刚性气热26测试；实际stage时刻、累计舍入、正性/取消/超时与独立审核 |
| `8bb92ca` | 独立精确加权审计37测试；系统/单元分步和前缀，保留权重舍入与局部漂移反例 |
| `2842691` | 来源门禁IAPWS适配器78测试；Cp/Cv导数和SI有限性修补，独立66状态复验 |
| `f2f2f31` | 刚性气相导热7个实际收敛案例；空间阶1.967/1.992、时间阶2.012/2.006；独立解析审核 |

水适配器使用IAPWS原生R与同相统一参考偏移；未与混合载气/高温Shomate拼接。审计器检查存储U账本，不冒充多相热物性重建。收敛案例为明确制造解，不是现实砖试验。

收敛脚本提交前 `git diff --cached --check` 曾报告文件末尾多一空行，编排未在该非零结果后停止提交。保留这项格式检查失败记录；不把它称为通过，也未改变绑定数值产物的源码字节。独立数值审核与源hash验证通过。

## 完整安装复验与来源增量

从 `/private/tmp` 在 `/private/tmp/brick-sandbox-g2-install-20260907` 运行冻结、非editable、离线安装；无PYTHONPATH。最后实际429测试通过（16.01s，0失败/跳过），13个实际site-packages模块源码hash与工作区一致。证据：`research/g2-installed-final-tests.xml`、`research/g2-installed-final-identity.json`。较早排除审计/水模块的314测试与11模块hash快照作为历史证据保留，不能混作最终版本。

Baloi2025出版商HTML/JATS原文、5组配比/终态热物性及派生提取已独立审核通过；4份清单资产逐一核验bytes/hash。详见 `research/BALOI2025_COVERAGE.md`、`research/CODE_REVIEW_BALOI2025.md`。体积配比没有擅自转质量；烧后低温有效cp没有冒充湿坯/高温热容。

独立代理的早期额度错误已终止；实际账户限额重新读取后可继续，未使用重置信用。恢复后的水、收敛和Baloi审核均完成。审核是代码/数值独立核查，不是外部科学专家认证。

## 当前关键缺项

1. 同一原污泥材料域的成套组成、产物、参考能、湿热/烧结/力学关系及独立实验覆盖尚未闭合。
2. 纯水/载气的闭合储能及已存在液界面的相变已实现；单相固体provider已有，固体整体储能/占积耦合、液态跨格迁移与泥中吸附/毛细仍缺，不能将纯水EOS当泥料干燥本构。
3. 烧结、闭孔/渗透演变、几何反馈和冷却应力尚未实现。
4. 全周期CLI/界面、可恢复批量运行、多代搜索与公开实验预测对照尚未完成。

## 当前增量检查点

- `34dbfe1`：Baloi成对来源与提取独立审核后本地提交。
- `a0f5697`：保存429测试安装证据、广延mol/J世界定义和当时支持域。
- `622d376`：连续边界程序41测试及独立审核，真实积分节点/解析能量检查通过。
- `7d3aaca`：显式理想水汽转换28测试，独立2071温点审核，保留h和生成能参考，固定R的u/Cv差及来源公开。
- 新增后完整冻结非editable离线重装：498 passed in1.99s，15安装模块hash与工作区一致；证据 `research/g2-installed-boundary-vapor-tests.xml`、`research/g2-installed-boundary-vapor-identity.json`。未修改已绑定G1/G2原源码来刷新旧报告。

## 最新已核验进展

上一回合属于progress：已有实测与阶段提交。本回合继续新增实际模块，没有把边界/储能原语缩为整个Goal。

- `b004db5`：Wang原PDF hash复核，SOURCE_COVERAGE与已存在来源注册表对齐2mm污泥层/钢板几何；有界热湿材料检索未得到两条新线索的完整合法正文，未引入摘要参数。
- `a84f46e`：动态气氛与半格/膜串联物理边界15测试、独立80表面根及真实积分通过。
- `23cee3d`：给定相压力物种储能22测试；大能量平台、相消、下界下溢与身份风险先失败后修补，独立审核通过。
- 上一检查点535项非editable安装测试通过（2.94s），17模块源码hash一致；最终 `research/g2-installed-programmed-storage-final-tests.xml` 和 `research/g2-installed-programmed-storage-identity.json`。上一份同535测试快照保留；当时绑定的17模块源码未再修改。
- 审核关于pytest abs/rel语义的误判已由实际源码与反例纠正，报告不再称原门槛被放宽；显式rel=0只作澄清。

## 最新机械闭合与连续热量检查点

- `e46321b`：RigidWaterGas平界面固定流体腔的液水—理想气压力/体积闭合，17测试及独立审核；保留压力域、受压液体占积、微量分压与数值失败证据。另有闭合热容推导及独立3状态差分验证，最大偏差2.79e-7 J/K，小于预登记1e-4 J/K。
- `1c1a019`：原Shomate Cp连续积分派生，原系数/温区/能量偏移均保留；22测试和独立120点Decimal核查。真实GasHeatModel制造例跨接缝至700 K，5400 J解析热量和每步账本通过；该例的接缝时刻显式提供，未验证自动事件探测。
- 最新冻结非editable离线安装，实际 **574 passed in5.63s，0失败/跳过**，19个site-packages模块hash与工作区一致。证据 `research/installed-sandbox-574-20260907.xml`、`research/installed-sandbox-574-identity-20260907.json`。报告绑定最终22项连续热量测试源码；旧535项检查点保留。
- 两项实现已独立审核，无关键未关闭代码问题。此处的APPROVE不等于材料物性资格或外部科学认证。

## 当前闭合储能检查点

上一回合为progress：连续热量模型、独立审核、574项安装证据均已提交。本回合继续实际接口和耦合反解实现，未缩减Goal范围。

- `94257d6`：新增水state_tp_response局部α/κ及摩尔体积/内能导数，21新测试+78旧水测试；压力模型现23测试，并返回最终数值括区、端点残差和求解路径。两个接口独立审核通过，均不冒充EOS严格误差界。
- `315337a`（rigid_storage）：固定液水/理想气库存，每次温度试算重新解压力/液体占积，得到U/H/闭合热容；条件温度反解保存数值envelope和有向误差区间。18测试实际通过18.48s，独立审核复跑18.72s并APPROVE；错误H2O跨相质量和温度区间向内舍入均保留反例后修补。
- 真实integrate单格热量反馈试验每次operator均执行实际闭合反解；库存保持、功账本与U变化在1e-8 J内、终温与独立嵌套压力/能量求根在1e-4 K内一致。此检查不自动证明时间离散收敛，更不是完整湿砖实验。
- 最新冻结非editable离线安装 **619 passed in23.27s，0失败/跳过**，20个site-packages模块hash与工作区一致。产物 `research/installed-sandbox-closed-storage-tests.xml` 与 `research/installed-sandbox-closed-storage-identity.json`；18项模块原始XML为 `research/rigid-storage-tests.xml`。旧574项/旧源码身份快照保留。

## 最新多格与证据检查点

上一回合为progress：闭合储能、独立审核及619项安装证据均实际提交。本回合增加多格面耦合、连续相适配及新的原始实验文件。

- `e24a560`：IdealGasPhase显式支持连续Cp派生全温区，旧原Shomate单段与水桥门禁保留；新增3测试，独立7个NIST O2跨缝反解最大误差5.30e-11 K。未自动拼接低高温水汽。
- `b8ae2aa`：RigidFluidHeat每trial每格实际U/库存→P/T/气孔闭合，共享面导热与气体/焓输运；16测试独立通过40.10s，含真实两格积分、双气列/质量修正/焓、进出气供体焓、域退出和半格热阻。液水库存固定但占积参与P/T闭合。保存原反解诊断与条件资格。
- 多格审核发现同一来源独立加载的IdealWaterVapor因私有EOS实例身份被误拒；已先RED，改按来源hash、共同参考、方法、R、域和数值政策等完整语义身份匹配并复验。跨格不同能量曲线/锚/分段仍拒绝。关于ContinuousCaloricError继承的主代理疑问经源码确认原本已被ThermochemistryError捕获，没有虚构修补；新增域退出仅是覆盖。
- `eacdad3`：Ghodke2022公开CC BY原TGA工作簿、单页拟合表、官方元数据/文件清单/manifest，11575条逐行提取已独立复核。单次氮气运行没有独立升温条件，DTA µV未当反应热，动力学拟合表尚未准入。原CSV因CRLF触发暂存检查失败后停止提交，旧脚本/CSV/audit归档，改LF并核字段完全不变，最终检查通过。
- 当前冻结非editable离线安装 **638 passed in63.82s，0失败/跳过**，21个site-packages模块与工作区hash一致。证据 `research/installed-sandbox-fluid-heat-tests.xml`、`research/installed-sandbox-fluid-heat-identity.json`；旧619项原始证据保留。TGA提取审核独立于软件单测，不能把11575行叫11575次实验。

## 638测试检查点的后续计划（历史）

本轮有界实现/代码/数据审核完成，主代理保存统一阶段记录。Goal继续active，未满足第11节完整完成条件。

1. 现有RigidFluidHeat已经真实接通多格气体/热量与液体储能/占积，不重复停留纯气或固定压力primitive。下一步加入液水迁移与相间质量转移，并在同一库存/能量定义下处理携带焓；需要有源毛细/有效输运/活度关系，不能假设已具备污泥干燥参数。
2. 先明确相容的气液化学势/焓参考和相变模型。理想水汽桥有固定R转换、液水保留IAPWS原生R；不能只用饱和压公式和任意相变常数绕过热力学一致性。低高温水汽热量衔接仍待推导；连续气体相适配本身已实现。
3. 补多格时间/空间收敛、液相/气相/热量各极限和独立全系统能量审计；目前两格0.001s有界制造案例验证连接与守恒，不等于生产时间尺度效率或收敛。记录数值成本后可针对实际热点优化，保留有效域和原门槛。
4. DeclaredNumericalEnvelope全域界仍未独立准入；现误差结果为条件性声明。补可审查的水EOS/气体热量数值误差预算，不能把局部导数、求根残差或所有有限点测试当严格全域证书。
5. 新Ghodke原TGA可作为已取得的单次源曲线，但还缺独立热历史、完整制样/元素基准/产物计量及反应热。继续同一原污泥域的干燥、有限氧反应、烧结/连通性/几何和冷却力学来源与实现，随后完成多代搜索与CLI/UI。未知材料参数不能用制造值顶替。

恢复入口：`RIGID_FLUID_HEAT.md`、`RIGID_STORAGE.md`、`CONTINUOUS_PHASE.md`及三个本轮独立审核报告；新数据详情为 `data/sandbox/research/ghodke2022/README.md`。全部当前软件资格仍限定数值研究，液迁移/相变/固体反应/烧结/应力、完整材料包和公开预测验收均未完成。

## 最新化学势与相间迁移检查点

上一个用户问答回合重申了Goal提示词，但未改变实现，按no-progress重新核查工作区与仍运行的三个代理；本回合实际完成以下实现、独立证据和提交，属于progress。完整Goal保持active。

- `f92de4f`：WaterChemicalPotential固定1bar标准态，共用native水熵参考与能量平移，液/汽mu相等派生peq；36项新测试、独立导数与数值检查通过。主代理另按Table1显式系数计算8温点，不调用新模块或_phi0作为参考；最大peq相对实现差2.59e-13。真实液EOS仍共用，独立性没有夸大。500K相对nativepsat约−11.24%是理想汽近似差异，原始结果及范围保留。
- `f8b5a86`：WaterPhaseTransfer用明确K(peq−pv)在已有液界面等摩尔变更液/汽库存，保持同一U源，不重复潜热；下一trial真实反解T/P。16项最终独立测试通过61.11s；蒸发冷却/凝结升温均实积分，水库存≤1e-11mol、U≤1e-7J；零汽、无液成核域退出、有限库存超步拒绝、微小K下溢等通过。局部熵产有代数审查，完整轨迹熵验证尚未执行。K/载气与数值误差envelope仍是明确制造/条件声明，没有泥料预测资格。
- 冻结非editable离线重装，在/private/tmp无PYTHONPATH运行全量sandbox：**690 passed in124.57s，0失败/错误/跳过**；实际23个site-packages模块与工作区hash一致。证据 `research/installed-sandbox-phase-transfer-tests.xml` 与 `research/installed-sandbox-phase-transfer-identity.json`。旧638项和来源原始文件保留。
- 实际一次闭合反解性能定位：5次储能前向、200次压力trial、205次饱和对；带profiler约1.543s，不是裸吞吐基准。`research/CLOSED_STORAGE_PERFORMANCE.md`、`closed-storage-profile.json`与只读`WATER_CACHE_DESIGN.md`给出下一步有界缓存方案。尚未实现缓存，不能声称已加速。

### 690测试检查点的后续计划（历史）

1. 依据实测热点优化重复饱和求解，保留当前来源/域/数值门禁与原容差；先验证容量与失效行为，再测实际加速，避免把长时多格实验直接扩大。
2. 将固体储能与占积、液态跨格迁移及对应焓接入同一库存/能量定义，补真实动态外边界、多格时空收敛和完整轨迹热力学诊断。现相变制造例只有0.01s，不能冒充完整干燥。
3. 明确耗尽后无液分支、泥中活度/毛细/迁移速率和低高温水汽衔接，取得同材料域的依据；不得靠无液时截小正数延续烧成。
4. 原污泥热解/有限供氧、烧结/连通性/几何、冷却应力、三机制公开预测验证、完整材料包、多代搜索与CLI/UI仍属必需未完成项，沿用原合同，不缩减范围。

三个有界代理任务已完成，无其声明中的计算进程待恢复。下一回合先看本最新段、实际Git状态与上面的来源/性能产物，不重跑已通过且未变更的同一测试来代替实现。Goal尚不符合第11节完成条件，也未达到无法继续推进的阻塞状态。

## 最新固体来源与性能检查点

上一Goal回合为progress：化学势、相变及690项完整安装验证已实际提交。本回合继续完成实现、来源与测量，未将单相provider缩为完整湿砖Goal。

- `3ed9aa1`：水饱和求解每实例容量1缓存不可变成功快照，命中仍检查当前两相EOS/Gibbs；18新缓存测试及181相关独立测试通过。审核发现预热后删除底层求解器会逃逸AttributeError，经RED后恢复原WaterNumericalError，未放宽门槛。相同反解输入3次裸计时中位1.3000s→0.8261s，约1.57倍，T/P/残差/最终括区/迭代数逐值一致；旧新源码hash与完整计时代码保存在 `research/water-cache-performance.json`。只作为单例单机测量。
- `77b4515`：取得NIST Quartz与JANAF O-037原HTML，有限事实2温段/16系数、19温点×4输出=76值独立复核。847K JANAF双行差728J/mol、Shomate拟合差729.127J/mol/非零Gibbs接缝差均保留，不能连续化抹去相变。原完整SRD页仅ignored本地缓存，有限事实/许可/位置/hash及旧三列提取归档在 `data/sandbox/solids/quartz/`。纯石英不代表泥中含量、体积或全砖热容。
- `12f6f06`：SolidShomateCaloric与IncompressibleSolidPhase单一晶相温段、恒摩尔体积、u=h0−p0v/h=u+pv；全域Fraction正Cp下界不要求气体Cp>R。29新测试及与旧PhaseStorage组合51项独立通过，实际储能求和/反解已连接；另50组独立驻点/内能导数检查通过。u误差至少包含p0*εv，其余误差仍明确条件声明；体积/误差来源与制造门禁保留。尚未接rigid整体固体库存与占积。
- 当前冻结非editable离线安装，从/private/tmp无PYTHONPATH运行全量sandbox：**737 passed in78.91s，0失败/错误/跳过**。24个实际site-packages模块与工作区hash一致；证据 `research/installed-sandbox-solid-cache-tests.xml`、`research/installed-sandbox-solid-cache-identity.json`。旧690项及旧水源码身份快照保留。

### 当前下一步：整体固液气闭合

1. 按已审查 `research/SOLID_COUPLING_DESIGN.md` 实施真实固体库存和占积：流体腔体=bulk−ΣNs vs，整体U含ΣNs us，每个试探温度重新求固液气体积/压力/总储能，不能从目标U减去固定热容后调用旧inverse。先有界惰性固体阶段，为后续反应/收缩保留真实库存列。
2. 扩展体积误差→压力→液相内能传播，尤其无液纯气支也不能忽略固体体积误差。保持来源/数值条件区别、方向舍入和域检查。接新固体模型后，再扩展共享面输运与WaterPhaseTransfer主机接口，实际验证固体改变蒸发冷却幅度。
3. 补液水跨格迁移/携带焓、真实动态边界、多格时空收敛、完整轨迹热力学诊断；低高温水汽衔接与液界面耗尽后路径仍需实现。不要再以缓存微调或重复单相自测代替这些必需耦合工作。
4. 同一原污泥材料包、成套热解/有限氧计量与反应热、烧结/连通性/几何、冷却应力、三机制公开预测验证、多代搜索、CLI/UI仍保持原Goal必需未完成范围。Quartz只补一个固相来源，不能掩盖这些缺口。

本轮代理任务及所有测试进程已结束；关键代码/来源独立审核均APPROVE，含义仅限各自有界范围，不是外部科学认证。完整Goal继续active，没有满足第11节完成条件，也没有发生无法继续的阻塞。


## 最新固液气实际耦合检查点

本回合为progress，完整Goal继续active。原合同§11仍未满足；没有因为局部模型通过而缩减原污泥全周期范围。

- `96d70dd`：SolidFluidStorage整体固体库存/占积/储能，每trial真实闭合P/T。23项独立测试及单独Decimal三状态/反解/25W十秒积分通过；固体体积误差连干支压力也传播。几何virtual_design_choice保留ID/版本/来源和制造材料门禁，不能给材料升格。实现说明及独立oracle在SOLID_FLUID_STORAGE.md和research目录。
- `3f69e34`：SolidFluidHeat共享多格气体/焓/热量通量，WaterPhaseTransfer明确支持完整固体布局。固体Cp实际改变蒸发降温，两个终温条件误差区间分离。独立审核发现wrapper制造固体/几何门禁缺项，已修复复验。裸ConservedState不带列身份，未宣称自动识别同形状列置换。
- 审核29项原收集版与2项后强化版分别保留XML；最终全量安装执行全部强化断言。冻结非editable离线安装，在/private/tmp无PYTHONPATH实际 **773 passed in96.01s，0失败/错误/跳过**，26个安装模块与当前源码hash一致。产物research/installed-sandbox-solid-fluid-tests.xml与installed-sandbox-solid-fluid-identity.json。旧737项证据保留。

下一步执行：液水跨格迁移及携带焓、完整主机动态炉温/气氛边界、多格时空收敛与轨迹账本仍需接入。低高温水汽参考衔接、液界面耗尽后路径、反应库存与能量、烧结/连通性/变形、冷却应力继续按原合同实现；制造例不替代来源支持的材料域。原污泥同域参数、公开三机制预测、全周期和多代搜索、CLI/UI仍未完成。不要重复无变化测试代替这些工作。


另取得并核读USGS Bulletin1248石英离散体积/密度表：有限事实、原文hash与温度/晶相/历史常数/误差边界在data/sandbox/solids/quartz/usgs-b1248/。压力保持unknown；两个不同温度点不成为高温恒体积关系，纯石英来源不解决同一原污泥材料包缺项。完整原文仅ignored缓存，不作为可发布原文。


## 最新动态固液气炉温与气氛检查点

上一回合真实完成固液气耦合/USGS来源及阶段提交，属于progress。本回合同样有实现、独立计算与完整安装证据；完整Goal继续active，软件与科学资格未满足§11。

- `427ead1`：ProgrammedSolidFluidHeat每trial只做一次完整固液气解码，构造完整动态气体库与半格导热/对流/辐射表面平衡；WaterPhaseTransfer显式第三主机外包，保留完整诊断/源身份及breakpoints。8项新program测试+5项新phase组合，含真实升温保温冷却、真实气氛入流与供体h、外热和水相变账本。独立32项含旧主机回归通过68.29s，报告和原XML已提交。
- 主代理单独60位Decimal解析对照实际40s程序，首轮十进制dt非均匀节点余步导致整体判定false，原script/plan/result保留zip。第二轮仅将实验步长改二进制精确.5/.25/.125，原门槛和积分器不变；均匀且零拒步，maxTerror .000520179/.000127759/.0000316464K，ratios4.07158/4.03707，逐步与前缀账本均通过。独立审查重算JSON和公式，不冒称代理重复执行整套积分。反解界和表面累计数值扰动均远小于观察误差。
- 当前冻结非editable离线安装，从/private/tmp无PYTHONPATH实际 **786 passed in109.64s，0失败/错误/跳过**；27个安装模块与工作区源码一致。最终XML与身份research/installed-sandbox-programmed-solid-tests.xml / installed-sandbox-programmed-solid-identity.json。旧773项及首轮非均匀证据保留。
- 下一步液水面输运的方程与接入设计见research/LIQUID_FACE_DESIGN.md，独立审核REVIEW_LIQUID_FACE_DESIGN.md。已实际核读已有MOOSE原始快照的每相Darcy与质量通量乘比焓，并核其hash；没有新造材料参数。冻结mobility/upwind离散并非任意可压缩两半格精确解，限制已加入设计。

### 下一步实际执行

1. 在SolidFluidHeat共享面层接真实液水库存和同参考供体焓，保留单次decode与现有动态炉温/相变组合。须有显式液相mobility/饱和度关系/连通条件；不可把气相krel直接当液相值，平界面P_l=P_g只支持受限压力流，不冒充毛细干燥。先独立面手算和真实两格守恒积分，再接来源支持的材料本构与公开数据。
2. 补实际湿相变/液迁移多格时空收敛、完整轨迹账本与误差预算；本轮40s干极限仅证明所选固定步时间阶数。十进制节点余步效率问题仍在，不以反复改时钟策略取代物理工作。
3. 低高温水汽参考衔接、液界面耗尽后路线、原泥热解/残炭有限氧计量与热效应、烧结连通性/几何、冷却应力、同一原污泥材料包、公开三机制预测、多代搜索与CLI/UI仍属必需未完成项，不缩减合同。

所有本轮代理任务与实际测试进程均结束；没有待轮询的运行句柄。来源/设计审核不是外部科学认证，制造系数运行不成为真实泥料性能结论。本轮没有不可继续推进的阻塞。


## 最新液相共享面与整体接入检查点

上一Goal回合实际完成动态炉温/气氛、解析程序与安装验证，属于progress。本回合继续实现液水跨格mol/焓与完整固液气反馈；Goal保持active，未满足§11，不因面算子通过缩小原合同。

- `7bd4a38`：新增LiquidTransportState、SaturationMobilityTable、LiquidConnection及Fraction单供体Darcy面。独立20测试0.04s通过，正反供体/极端量程另核对。每cell液相关系独立于气相krel；frozen_manufactured只测试，tabulated允许真实来源局部平台或常值，不以数值变化代替准入。source/域/连接始终显式，material_qualified=false。
- 同提交将液面接入SolidFluidHeat，单次整体decode后从同参考真实水provider取供体v/h，S=Vl/(bulk−Vs)，共享mol与焓进入同一面。ProgrammedSolidFluidHeat/WaterPhaseTransfer保持完整诊断并补仅液制造参数门禁。6项新host独立测试22.89s，实际两格0.001s逐prefix水/U与面账本通过、固定solid/封闭gas不变。T变化仅名义，不宣称超过inverse预算；压力方向资格只fixed-decoded-T，未虚构全域dp/dT界。
- 主代理真实生成300K、50→1MPa、制造λ下纯水可压缩连续流参考：独立Gauss/brentq，共用水EOS，2353调用9.35s；参考0.00274052205113mol/s。4/8/16/32候选面实际误差比1.97752/1.98862/1.99428，最细相对误差.000346795，预登记门槛通过。Gauss16/32一致性非严格误差证书；恒温外约束的面收敛不叫完整湿砖时空验证。所有节点/面、脚本/源身份保留，独立review报告限定APPROVE。
- 最终冻结非editable离线安装，从/private/tmp无PYTHONPATH全sandbox **812 passed in134.01s，0失败/错误/跳过**，28个安装模块与当前源码一致。research/installed-sandbox-liquid-transport-tests.xml和installed-sandbox-liquid-transport-identity.json为最终证据，旧786项保留。所有本轮代理与实际进程均已终止，无待轮询session。

### 下一步保持完整Goal继续

1. 固体反应与有限供氧仍需实际接入当前共享库存/总U核。本轮已读现有reactions.py：SpeciesDefinition已区分固液气，ArrheniusMassAction明确按current_cell_bulk_volume归一化，反应算子不额外加热。因此下一步可审查显式网络→完整InventoryLayout映射、各相摩尔质量/元素/能量参考、真实T/库存/体积输入，再连接产物库存与总U反解。不能把文献表面/气孔浓度速率擅自改成现有bulk浓度形式；不为原污泥编造伪组分、A/E/产物或生成焓。需要时扩展有源速率形式，而非强行套旧公式。
2. 湿相变+液迁移+热/气完整多格时空收敛、液界面耗尽后的受控路线、低/高温水汽共同参考衔接仍必需。不能将这一轮恒温面离散对照冒充整体瞬态验证，不能在无液/孔体积耗尽时clip继续。
3. 同一原污泥材料域的毛细/饱和度输运、热解/残碳氧化计量与热效应、烧结/连通性/几何和冷却力学仍缺来源或实现；三机制公开持出预测、全周期、多代搜索和CLI/UI保持原必需范围。现无有源材料表被自动准入，方程真不等于泥料参数真。

恢复优先读LIQUID_TRANSPORT.md、LIQUID_SOLID_FLUID_HEAT.md及CODE_REVIEW_LIQUID_TRANSPORT.md。不要重复无变化的812项测试代替反应/干燥完成路径和真实来源工作。当前仍有可独立继续的实现与证据任务，不符合blocked条件。


## 最新固相反应与整体热力学反馈检查点

上一Goal回合仅给出任务书入口，按no progress处理；本回合重新核对实际工作区并完成实现的独立解析验证、来源审核及本地提交，属于progress。完整Goal继续active，§11仍未满足。

- `82f9f15`：SolidReactionConfig显式多相provider/网络/全列绑定，反应源接入SolidFluidHeat单次整体T反解，改变真实Ns/Ng及Vs/Vg/P/T，形成能留在总U中不重复加热。13项绑定与8项host最终独立通过，有限O2/零氧无氧通道/正Ea比/诊断组合/制造门禁覆盖。位置参数兼容和kinetic域分类两处审核缺陷已修复。连续净源ODE并未调用旧gross-extent限步工具，不宣称通用刚性网络已验证。
- 三档2s独立解析候选最终attempt002实际32/64/128均匀步、零拒步，最大Ns误差6.13022e-7→1.51459e-7→3.76428e-8mol，比4.04745/4.02358；最细T误差0.000352617K、P1.56026Pa，U/step/prefix差0，质量max5.421e-20kg。原预登记门槛未改；001首次PASS记录保留，002只补报告字段。独立审核重推227个节点及全部误差/hash，不冒称重跑积分。制造Xsolid→Xgas不是真实碳或污泥。
- 最终冻结非editable离线安装，在/private/tmp无PYTHONPATH实际 **833 passed in136.56s，0失败/错误/跳过**，29个真实安装模块与当前源码一致。证据research/installed-sandbox-solid-reactions-tests.xml及installed-sandbox-solid-reactions-identity.json。独立局部XML也复制到research保留，旧812项证据未覆盖。完整回归进程12298已exit0，不再轮询或重启。
- `b4dd270`：Areias/Maciel/Holanda2025官方来源有限事实与独立审核已提交。先干燥并混熟石灰的市政污泥，不是SSA也不是未经处理原泥；Table3、TG/dilatometry与四峰温烧成方法可追查，TG气氛/膨胀仪几何未知，图文阶段失重2.808/2.806差异保留。未数字化、未材料准入、未外部预测。

下一步：先实现液界面耗尽后的守恒事件/干态路径及低高温水汽共同参考。现water_caloric_join_probe已实际测得500K高减低h/u=0.17481133254477754J/mol、Cp/Cv=−0.007918945959858092J/(mol K)，仅模型端点差，不是物性误差证书或实现了拼接；方案见research/WATER_CALORIC_JOIN_DESIGN.md。液耗尽方案已写入research/LIQUID_DEPLETION_DESIGN.md，独立设计审查中；它明确原SSPRK2中间Eulerstage限制会使有限时间耗尽难以到达，拟用有误差控制和完整账本的终端事件panel。尚未实施，不可用静默clip、关闭相变或纯干例替代湿→干实际路径。

之后仍需湿相变/液迁移/热气多格时空收敛、真实原污泥计量/形成能/动力学、烧结连通性/几何与冷却力学、同域公开三机制持出验证、全周期、多代搜索和CLI/UI。以上原合同范围全部保留，软件通过不替代材料适用性与现实验证；目前仍有可继续实现的工作，不满足blocked条件。


恢复补充：`c49fdf4`已提交833项安装证据、29模块身份与独立水汽端点测量。湿干设计审核明确保留REQUEST CHANGES：逐操作两库存float精确增量相等可能使正常耗尽无解，不能把普遍unsupported当完成。设计末尾主代理已要求选择实际补偿库存表示，或精确成对extent账本加独立、显式、逐步/全prefix有界存储舍入残差合同；数值相间修正、实际蒸发量与存储舍入三者分开。原δ的局部ULP及相对蒸发积分上限继续有效，不能只凭一般atol或扩大阈值验收。此为下一实现前须关闭的数值设计项，不影响已验证反应实现，也不使Goal无可推进工作。

低高水汽设计可独立实施：完整域须证明Cp>R、保留h锚与各高温接缝偏移、gas_u_error包含锚/积分/偏移数值预算；0.1748J/mol是模型差而非误差界。高温chemical未知不能被当成已证明不凝结。所有本回合运行测试已结束；设计review终态见research/REVIEW_WET_DRY_CONTINUATION_DESIGN.md。下一回合直接开始上述实现/针对性反例，不再重复833项或同一设计措辞。


## 最新水汽跨域与事件写回检查点

上一回合实际完成反应/来源/安装验证并提交，属于progress；本回合继续新增实际caloric/host/写回实现、反例修复与独立审核，属于progress。原§11未满足，Goal继续active，无须外部输入即可继续下一实现。

- `4ef76a2`：源门禁JoinedWaterVapor低293–500K保持原bridge，500以上按原NIST Cp从同一低h锚分段Fraction积分至6000K，保留500/1700 Cp跳、原h/偏移/sourceassets。低正理想项及高区间有理数证明Cv>0；低h全域误差仍显式条件声明，不将接缝差当误差证书。budget最大float的溢出由独立2RED修复。IdealGasPhase/mass、反应完整identity、WaterPhaseTransfer仅low_modelchemical相容和RigidStorage活动Joined实际数值预算门禁均接通。四条实际SolidFluidHeat ±100W/4s轨迹跨500/1700升降温，完整mol/U与独立系数积分终温检查通过；这不是湿耗尽或真实高温固相验证。
- `624d89c`：选择耗尽方案(b)的具体写回部件depletion_roundoff。独立成对±δ与实际汽浮点残差分账；局部液ULP/绝对/真实蒸发积分相对限和逐事件/全prefix水mol/H/O/Mkg预算；累计绝对残差不抵消，JSON恢复保留Fraction与原政策。部分正常事件无需逐位相等即可按事前预算继续，但未定位事件或切换模式。主代理非零Fraction输入下溢反例先RED后拒绝修复，最终16作者测试通过，独立旧15+新增单项分开保留；另120边界算术独立通过。
- 独立provider31项与host9+写回初15项均实际通过；新两份CODE_REVIEW_JOINED_WATER和CODE_REVIEW_DEPLETION_ROUNDOFF为限定组件APPROVE。旧设计review被迟到精简覆盖后，经原审核者确认恢复602ebdc的完整历史；原worker节点/第二事件澄清+2行保留，没有新造已通过门槛。
- 最终冻结非editable离线安装在/private/tmp无PYTHONPATH实际 **889 passed in136.85s，0失败/错误/跳过**，31个实际安装模块与源码一致。research/installed-sandbox-joined-water-tests.xml及installed-sandbox-joined-water-identity.json为最终证据。进程22155已exit0，所有代理本轮执行已结束，没有待轮询测试句柄。旧833项证据保留。

### 下一步直接实现完整事件主机

1. 不再重写同一设计或重复889项。在已选方案(b)上实现depletion_integration事件panel、显式existing_liquid/depleted_no_nucleation模式与完整结果/跨段账本，实际关闭湿→干连续积分缺项。普通RK中间Eulerstage限制仍真实存在，不能靠最大step数趋近耗尽。写回函数只处理panel后的δ与存储残差，不能自行授权事件、伪造正向蒸发积分、丢弃原face/reaction/U误差或重置prefix。实际host绑定H2O两列与原native水摩尔质量。
2. 预登记并执行恒定汇/时变汇独立耗尽时刻、粗细事件面的时间/状态差、共同物理时刻继续积分差、节点先后/其他事件、微小蒸发但液流主导、实水/固体/气体/液面/反应组合。每个fine段都受下一程序节点限制；节点两侧事件未分离不能强行推进。完整状态反解和每step/prefix mol/元素/M/U/面账本照常保留，数值修正与物理传质及存储舍入三者分开。
3. 高温dry chemical驱动力超原293–500K域时strict unknown/unsupported或明确记录的亚稳无成核研究分支，不把未计算当成不会凝结。Joined高温热量域不解除液相、固相或材料范围约束；真实湿干/烧结高温材料资格依然未完成。
4. 持续保留原Goal全范围：湿相变/液迁移/热气多格时空收敛、原泥成套动力学/计量/形成能、烧结连通性/几何、冷却力学、同域三机制公开留出预测、完整原污泥全周期、多代搜索与CLI/UI。不能把本次caloric接缝测试或数值写回部件当成完整模型。

## 最新实际湿→耗尽→干态继续检查点

本回合为progress，原Goal仍active，§11未完成。`89d5d26`实现显式existing_liquid/depleted_no_nucleation与strict/metastable研究分支；`7da961b`实现完整Rates耗尽panel、clock表示误差独立预算、实际干态共同时间续算和跨全部段的精确库存/能量账本。旧SSPRK2有限时间耗尽失败、clock表示残量超库存ULP以及相邻级实际同一terminal的反例均保留并有对应修复。

31项事件/clock/写回测试独立通过；非线性cubic探针证明局部event指标不能认证此前普通湿段误差，原普通容差失败及100倍更严普通容差对照均保存，不将local completed当完整ODE误差证书。

实际真实水provider+制造固体/载气/K/传热主机attempt03在86.82s、224评估、27个接受试算panel、0拒步完成；21保存状态，事件0.00028422061165952946s，终时0.03125s，程序节点保留。完整水量max残差1.15805e-22mol、全prefixU6.81945e-11J、逐stepU2.02577e-11J；独立G=1/15传热和干升温超反解区间断言通过。执行前后所有源码/fixturehash一致；独立reviewer另外只读重算JSON账本，未冒称重跑物性。attempt01/02各120s失败原样保留；第三次收紧terminal_window减少重复湿前段，精度门槛及资源上限不变。

首轮冻结安装917项出现3failed/914passed（230.46s）：默认None模式物化成单格tuple导致原有两格液面/反应wrapper组合失败。`3c65ee7`保留None声明、由interfaces按当前host生成默认模式；显式tuple仍严格长度检查，不自动复制dry。原3测试未改，12模式+原3失败节点独立15passed5.54s。首次失败XML原字节在installed-sandbox-depletion-tests.raw.zip，可读XML仅去行尾空白，normalization.json记录hash；曾因此git diff --cached --check非零，保留raw后重新检查exit0才提交。

最终冻结非editable离线安装已实际完成：/private/tmp运行、不设PYTHONPATH，**918 passed in234.43s，0失败/错误/跳过**，32个真实site-packages模块在执行后与源码再次hash匹配。最终证据research/installed-sandbox-depletion-final-tests.xml和installed-sandbox-depletion-identity.json。包括修复默认模式后的真实湿干host测试，未只跑旧失败节点来代替整体集成。所有本轮代理与测试进程均结束；最后测试session84474已exit0，不再轮询。上一轮889通过和本轮917的3失败证据都保留。

### 下一可执行物理工作

1. 在现真实事件积分器上补两格非同时耗尽、液水共享面和反应同时活动的全过程；现最早候选/第二事件歧义会明确unsupported，未证明通用多事件路径。对完整湿前段和事件后段分别做有独立参照的时空收敛；不得用已通过的单格低温制造轨迹代替一维砖分布场。
2. 衔接真实湿态低温到干态高温的相态适用反解括号；当前固定括号不能在仍有液水时跨过液EOS稳定/压力域。保留strict未知或显式metastable资格、同一K与来源，不能预置dry或抹去液域限制。
3. 原污泥成套反应/毛细输运/烧结/孔隙几何/力学证据与实现、三机制公开留出预测、全周期、多代搜索和CLI/UI全部仍为原合同必需项。来源参数不能由制造值升格，不因本次数值修复宣称模型全部完成。

## 多格事件与湿态到高温：当前回合

上一回合实际实现湿干事件、修复安装组合回归并完成918项冻结验证，属于progress。本回合`9194fd1`进一步实现明确分离的多格事件：共同时间遇第二耗尽候选时有界缩短、清空原比较重新细化，每个普通RKstage重查完整状态，两个事件实际进入制造解析轨迹，所有共享面与反应源一次推进。新5+旧31共36项独立通过2.09s；加速第二事件的原失败及中间100拒步失败保留。不是同时事件或任意刚性多事件求解器。

同提交新增显式dry反解括号数值政策：仅实际NL精确0使用，正液量沿原wet括号；原EOS域/形成能/预算均不放宽。9项独立测试1.57s通过，真实单格wet300K/dry502K完整解码及mixed选择/默认语义覆盖。单独解码两状态不等于连续湿→高温轨迹。

Root真实两格fixture、事前合同和runner在test_depletion_coupled_host.py及research/COUPLED_DEPLETION_PLAN.md、coupled_depletion_run.py，初始diagnostics通过。曾错误认为裸Dfixture0代表总flux0，实际混合物校正仍迁移fixture，已修正审计为完整示踪/质量外边界账本，原物理算子不变。首次真实积分已终止：coupled-depletion-attempt-01.json，360.97s/314eval/35接受试算panel，原360s预算耗尽、无已提交事件，源绑定一致；第二事件共同tc重选实际生效，但逐格液体携焓放大终端N误差，原U门槛未达到。第二次已事前登记收紧window与显式safe_fraction及基于成本的600s预算，物理输入/精度门槛全部保留。

wet→hot同主机600s/恒1000K炉温首轮也已真实终止：wet_to_hot_attempt01.json，179.88s、4523eval、526试算panel，one event于0.0002842209402078s成功接受并继续干态到198.0041396848s，但100拒步上限耗尽；尚未完成600s或>500K。独立partial账本重算通过，不当成功。原因是全干态仍每2s重新启动普通integrate，反复从maxstep2拒到约.47s而丢自适应步长历史；拟只在所有格明确dry时一次推进到下一程序节点，保留原误差/域/资源与maxstep。高温下一次保持原240s/100reject预算，不以增加拒步解决重启缺陷。独立干段参考仅条件于实际eventU/time，不认证event时间。所有这些仍是制造固体/动力学配真实水provider的数值验证，不授予原污泥材料资格。

## 两格耗尽与湿态到高温：实际通过检查点

上一提示词答复回合没有推进实现，判为no progress；本回合实际运行、保存新证据并提交代码，属于progress。Goal保持active，原§11全范围未完成。

- `fa88647`：统一可审计safe_inventory_fraction（默认.25、严格0<f<.5）与仅全显式dry时保持普通积分自适应历史；55项独立轻测试通过7.36s，XML已保存research/depletion-safe-dry-review.xml。默认fraction历史逐位一致只适用于单独fraction补丁，不能冒称组合改动保持旧干段网格。
- 两格attempt02实际completed，444.525s/494evaluations/58试算panels，42已提交steps；两真实事件0.00028837917551549386s和0.0010885050887795723s，完整推进至1/256s，保留1/512程序节点。完整湿相变、液共享面、反应、气热组合保持原物理参数和精度门槛，使用已事前登记.4 fraction/1/1048576 window/600s预算。独立JSON复算N残差8.2756816e-18mol、元素1.1232598e-17mol、质量1.5340836e-19kg、U6.6127672e-13J通过；82个运行源码/fixture/runner文件前后及审核时一致。原attempt01失败保留。CODE_REVIEW_COUPLED_DEPLETION.md说明：原K由绑定源码与运行断言核，JSON本身无operator快照；细化摘要不是未保存试探轨迹的独立复算或全时空收敛证书。
- wet_to_hot_attempt02实际completed，198.3825s/8953evaluations/1272试算panels，原240s/100reject门槛未改。真实湿初态经一事件耗尽后至600s，终温530.7349451167803K；独立条件干段参照530.7349459107604K，差小于原5e-4K门槛。max水量5.3932176e-22mol、逐库存prefix4.6652987e-22mol、U7.1303175e-10J；运行源hash一致。高温chemical仍明确unknown/metastable，无成核结论不升级。失败attempt01仍原样保存。
- Areias2025 Fig4 A/B共26读图点及像素/刻度/误差/许可来源已实际产出，非仓库cwd重现通过。独立来源/代码审查尚在执行，未将其准入收缩本构。下一变形—几何—机械功实现合同在research/DEFORMING_HOST_DESIGN.md：规定形变气体执行器是数值耦合验证入口，湿固体/自由烧结所需骨架应力与能量仍为必需后续，不缩减Goal。

### 当前唯一重测试进程与恢复动作

非editable冻结离线安装已完成，实际从/private/tmp、不设PYTHONPATH启动完整tests/sandbox，PTY session **78292** 仍在运行（最近工具返回带此session的进度，而非终态）。目标XML为research/installed-sandbox-multicell-hot-tests.xml。恢复时先轮询同一session；观察超时不重启。完成后读取真实XML，并逐模块核源码与实际site-packages身份；未完成前不得宣称新版本全套通过。两实际实验66952及97463均已exit0，不再轮询或重复运行。src/tests/runner冻结至全套终态。

之后完成来源数字化独立审核、保存整体测试/身份和阶段提交；继续可变几何与机械功、原污泥成套材料证据、烧结/连通性/冷却力学、三机制公开留出验证、全周期、多代搜索及CLI/UI。所有原Goal必需项保留。

### 本检查点最终核验与下一步

上面78292运行记录已终止：实际exit0，**954 passed in444.54s，0失败/错误/跳过**。新XML已由ElementTree读取计数；32个真实site-packages模块在测试后逐一核对源码hash一致，cwd=/private/tmp且无PYTHONPATH。证据为research/installed-sandbox-multicell-hot-tests.xml和installed-sandbox-multicell-hot-identity.json。不要再轮询或重启78292，也不要重复旧918项。冻结版本已包含本轮全部src/tests修复；尚未加入后述隔离motion候选。

`f3aabfc`保存两实际通过实验及原失败；`01c1d42`保存Areias26点独立审查通过的数字化证据。Areias独立检查25资产hash、26点原图与Decimal75角点/舍入一致；不授予材料准入。高温结果原独立预审者也已只读复核1259状态与81依赖、完整pair/storage/逐步及prefix，报告追加在CODE_REVIEW_WET_TO_HOT.md，未冒称再次运行EOS。

可变几何设计及独立审查已完成：DEFORMING_HOST_DESIGN.md/CODE_REVIEW_DEFORMING_HOST_DESIGN.md。审查发现同V但A×2/width÷2会破坏零变形等价，已补全部格数/面积/宽度/体积与参考构形绑定及明确算术容差/拒绝测试。设计最终hash652d5af0b356466ab5b426215e44638d8f849c71b412176a7e7d6d2928ff0e59。

下一工作已经分配给review_water_resume：仅在/private/tmp/brick-deformation-motion-candidate/准备C1运动学provider与独立测试候选，不动仓库src/tests，不做GasHeat refactor。恢复先检查代理实际状态和候选文件；取得独立代码审查后再应用。先完成统一V/A/d/Vdot入口，再接可审计规定形变气体功测试及湿固体真正机械储能/烧结闭合，不能停留在气腔并改称完整砖模型。其余原Goal必需项仍全部未豁免，Goal保持active。

## 规定几何与机械功实际接入

上一回合已实际运行与保存954项安装证据，属于progress。本回合新增代码、解析验证与独立审查，亦为progress；原Goal§11未完成，仍active。

- `bb3098c`：GasHeatEvaluation公开原有一次解码的T/p/source，__call__保持Rates。Root新3测试先缺API失败后44相关通过；独立审查从HEAD旧__call__保存黄金对照，非零共享热/流/反应/外边界四Rates逐位一致，新增冻结回归后独立30通过。不是仅新evaluate与新__call__自比。
- `1dca610`：PrescribedSlabMotion正式接入固定参考C1法/切伸长与当前V/A/d及完整Vdot；独立29轻测通过，应用后29再核。原负Fraction时间下溢放入域、0维输入异常、16/32/64格按width ULP误拒均有真实失败；按坐标加法/减法ULP传播修复局部一致性，非累计位置误差证书。完整隔离源码/测试/原始失败zip与verification已保存，构造逐knot/运行逐sample检查不冒全域float证明。
- 同提交DeformingGasHeat在同一当前几何及同次T/p上计算相对输运与−p*Vdot；只允许显式压力匹配气体执行器/制造输运网络。父thermo变更在replace之前拒绝；flow h不额外pQ；当前bulk用于反应；参考count/A/width/V完整匹配。14实际host测试4.87s通过，独立host+motion+gas诊断共47通过4.87s，并用同次测试hook确认三档每个实际step均为规定dt。
- 闭式绝热压缩/膨胀三档dt=1/128,1/256,1/512s，实际256/512/1024steps。最大T误差6.7844911e-4、1.6957182e-4、4.2387968e-5K，减半比4.000954/4.000471；最细P与等熵不变量相对误差7.8168645e-8，U解析误差9.3253496e-4J。原最细门槛不变，粗档结果没有冒称通过最细要求。各档stdout、XML及从XML抽取metrics一致，未重复运行补造指标。

当前冻结非editable离线全sandbox测试 **session1707** 已实际启动并返回进度，XML目标research/installed-sandbox-deforming-gas-tests.xml；尚未终态，不宣称新全套通过。恢复先轮询同一session，不重启；src/tests冻结。结束后解析真实XML与34个预期新安装模块（须实际计数）再保存身份。原954版本和两实际实验均已终止，不重跑。

下一物理工作由review_water_resume独立准备research/DEFORMING_SOLID_ENERGY_DESIGN.md，只读现湿固体整体U/几何并核2–3份原理主来源，定义总应力功、骨架/界面储能与thermalU分账，不把气体孔压乘bulk变化代替湿砖力学。仅文档/证据，不动冻结源码；完成后独立审核再实现。真实原污泥材料、自由烧结/孔道/冷却力学、公开三机制留出预测、完整周期、多代搜索和CLI/UI仍为原合同必需，不缩范围。

### 规定气腔分支最终冻结检查点

session1707已实际exit0：**1001 passed in448.58s，0失败/错误/跳过**。XML已实际解析；34个真实site-packages模块在测试后与源码再次hash匹配。cwd=/private/tmp、无PYTHONPATH，结果为research/installed-sandbox-deforming-gas-tests.xml与installed-sandbox-deforming-gas-identity.json。所有测试进程已终止，不再轮询1707/19915，也不重复旧954整套。当前源实现止于bb3098c/1dca610加上述验证，尚无skeleton_energy实现。

湿固体下一合同DEFORMING_SOLID_ENERGY_DESIGN.md已核读三主来源并给具体接口：Etotal=thermalU+温度独立骨架/界面内能；同势给应力，Wtot含储能率、耗散与真实孔体积功；初始固定Ns，反应体积/机械能导数后续仍必需。独立初审纠正耗散功率D与Rayleigh势Phi=D/2术语，并把湿恒温oracle限定为固定液汽库存，活跃相变不能据U恒定推T恒定。修订hash ef7c5795cd5c6e451b4cf97cac6ffd1f46ecf9fae3da434d099573547184a219；boundary_program正在完成最终来源/接口审查，恢复先读其实际状态/报告再实现。没有待运行EOS；不因文档预登记而宣称湿固体机械实现完成。

湿固体设计最终APPROVE已闭合：Root在热U推导中补齐总E已含的explicit_body_heat，最终设计hashbc8392df0f4d3921b10fc6207f0d6fa526038218545400516d0fee174477cb08；独立CODE_REVIEW_DEFORMING_SOLID_ENERGY.md实际核读绑定，保留原修订史。总/热能身份、target误差传播、accepted RK分项功账本仍为下一真实实现必需门槛。

review_water_resume已接新的隔离任务，仅/private/tmp/brick-skeleton-energy-candidate/准备skeleton_energy.py及独立测试/失败记录：明确制造的log-strain势、内部界面能、Rayleigh耗散、Piola和能量率及保守数值预算；不改repo src/tests、不做EOS/storage/integrationhook。恢复先检查代理与实际文件，完成后独立审查再应用。尚不能宣称该provider已经完成或通过；本版本完整安装证据仍仅1001项/34模块。

## 骨架、目标区间与普通RK分项功：实际完成检查点

本回合新增可执行源码与独立验证，属于progress，Goal仍active，原§11未完成。

- `skeleton_energy.py`：温度独立log-strain弹性/显式取向内部界面势，同势Piola与能量率；D与Rayleigh D/2区分。只准入显式制造参数。23测试通过0.08s；独立240项有理atanh对数级数核75个输出包络。原候选与失败历史zip保留；Root应用时误去sys import导致1failed22passed，application-failure.xml原样保存，恢复import后23通过。
- `solid_fluid_storage.py`：显式target_energy_error_bound_j向外传播，负tiny Fraction拒绝、正tiny不归零，默认零旧结果逐位兼容。新11加旧23共34测试通过0.69s，独立34通过0.66s，保存两个XML。尚非Etotal storage。
- `integration.py`：可选elastic/interface/dissipation/pore/body分项功，schema每次评价锁定，实际接受stage同权积分；每项quadrature roundoff和总量分解残差有理记录，累计绝对分解残差受既有能量绝对预算约束。独立44通过0.50s，旧HEAD nonlinear 123接受/3拒默认路径逐位一致。仅普通integrate；wet wrappers/耗尽panel尚未转发，净U自适应不证明抵消分项截断准确。

冻结非editable安装session46721已实际exit0：**1051 passed in446.61s，0失败/错误/跳过**。XML实际解析；35个真实site-packages模块逐一与源hash相同，cwd=/private/tmp，无PYTHONPATH。证据：research/installed-sandbox-skeleton-components-tests.xml和installed-sandbox-skeleton-components-identity.json。不要再轮询46721或重复原1001全套。

下一工作：review_water_resume在/private/tmp/brick-deforming-solid-storage-candidate/准备有明确TotalEnergyTarget与实际完整固体身份的点储能候选，9项dry轻测先通过，独立review_convergence_resume审核中；Root仅在完整suite终态后开放≤90s真实wet验证。尚未应用repo，不属于上述1051安装证据。boundary_program在/private/tmp/brick-depletion-components-candidate/追耗尽panel/wrapper分项功后续，不改repo。点储能完成仍需明确作用域的积分状态、实际湿机械host和独立轨迹验证；材料证据、自由烧结/孔道/冷却力学、三机制公开留出、全周期、多代实验及CLI/UI全部仍必需。

## 模型能量身份、点储能与耗尽分项的应用检查点

`41e5911`保存上一1051/35安装版。新ConservedState追加默认None不透明energy_model_identity，RK与inventory writeback保留，旧三热主机拒绝非None；新13项先RED后共73通过，独立73通过并实际比旧HEAD三个默认轨迹。DeformingSolidStorage完整固体provider绑定与显式TotalEnergyTarget、机械/几何/表示误差传播，独立11通过、应用后11通过；全部原wet大误差拒绝和新exact rational制造volume定义保存archive。后者不是实际原泥物性证据。

耗尽分项候选正式按原字节应用：terminal取实际Fraction(end-start)权重、全程schema/tag核查、跨普通/事件段累计绝对分解残差在整path commit前检查；两真实wrapper仅转发原cell components，不额外加heat。独立25通过，另实际时变分项经29拒步/1573observations完整越event至.2s，终端有理权重和prefix复核；dry schema变更保留19已commitsteps及原湿模式。Root应用再测38（含身份13）通过0.93s。README/原RED/log/manifest/两基线源码及输出均归档；旧None默认baseline实际重跑逐字节相同。

新完整冻结安装session89265仍运行，唯一恢复动作先poll同session；新src/tests冻结，不能把局部测试当新完整suite。终态后解析实际XML与真实site-packages逐文件身份，再保存版本验证/提交。下一新host隔离候选需同次total->thermal inverse供传热/输运/porework，保留完整误差/几何/source，尚未接实际时间推进或wet/depletionhost准入。原§11未完成，Goal持续active，本回合有实际实现/测试属于progress。

### 总储能/耗尽分项整包终态

session89265已实际exit0：**1089 passed in453.56s，0失败/错误/跳过**。XML实际解析，36个真实site-packages模块逐一与32965ce源码核对一致，cwd=/private/tmp，无PYTHONPATH。research/installed-sandbox-total-storage-tests.xml及installed-sandbox-total-storage-identity.json已保存。没有尚未观察终态的旧完整suite，不再轮询89265/46721。

下一host仍隔离，不在此1089证据中：私有thermal assembler复用、point current_storage与全能量scope候选正在审核。初等向压缩η0解析试验attempt05温度过2e-5K但pore功未过1e-6J，保留失败；64→128呈二阶趋势不等于门槛通过。事前登记下一512/1024/2048三档与实际网格/拒步统计，原门槛不动，只因已测成本扩资源wall20→90s且整个attempt≤150s。作者已收到安装终态后开跑通知。新current_storage曾插入中部破坏旧positional，独立审查指出后改尾追加并新增回归1pass；尚待最后代码/物理审查与应用。

## 规定形变总能量主机当前恢复点

本回合实际完成点储能、identity/depletion组件与干态机械主机，属于progress，Goal仍active。干态首轮pore失败保持；细化后512/1024/2048实际无拒步，finestpore7.2252e-7J过1e-6J。源码修复只涉及审核提出的current_storage尾追加和initializer严格输入，原physics/gate不变。独立13轻测及真实旧热/气/反应golden通过，Root应用13通过；完整archive/readme与3src应用精确比较已核。

新fullsuite唯一session75509正在运行（开始已返回6%进度），源码/tests冻结。完成后实际XML计数与37预期实际安装模块身份逐一核，不重旧1089套件。下一wet entropy oracle在/tmp独立推导，尚不运行湿EOS；未来用同Nl=1/Ng=.01/Ns2/300K与10%isotropic，独立water EOS entropy closure与主机energy积分比较，不能调用被测storage作参照。当前还没有此湿积分验证成果。

### 规定形变固体主机完整安装实际终态

源码fa3194b冻结安装session75509实际exit0：**1103 passed in523.90s，0失败/错误/跳过**，包含正式默认fine3档扫描。37个实际site-packages模块与源hash逐一相同，cwd=/private/tmp、无PYTHONPATH。实际XML和installed-sandbox-deforming-solid-identity.json已保存。当前没有待结束的旧完整suite。

独立湿熵参照已完成数学/代码审核和9轻测试，dry volume残差漏门槛先RED后修，没放宽gate。真实30s硬限两点probe仅2.0704s：初态p304469.313540Pa；lambda=.9，T300.186070144980K/p567435.655362327Pa，ΔS−4.01e-11J/K、ΔV−1.36e-20m3；halfxtol差T2.503e-10K/P4.899e-7Pa过原gate。154是公开water.state_tp调用次数，不是内部EOS求解次数。optional已测storage forward.1696s/inverse.8125s，使用oracleT初始化的roundtrip不冒实际trajectory。结果与完整source/assets/limits在/private/tmp/brick-wet-deformation-oracle。

按实测成本不盲跑2048步湿扫描或450s粗pilot。Root另事前登记30s硬限真实wet host前缀smoke：同物理motion/库存，只推进原曲线0→1/64s，cap1/128、≤4接受/4拒，原gate不动，失败保存；不能将此前缀升级成原完整10%轨迹通过。并行仅可做来源/无EOS准入设计与快速同EOS后端微探针，生产backend未改。
