Root reviewed script 4b66880cbd80ffd7c5880b4f2cc038787a17ea61eaecda1a38d10bda2da4aefe.
Exact prior case bytes and whole initial state retained; actual policy is saved
and differs only by the named ordered-event opt-in. The original end time,
512-panel/800-second resource budget and all science gates are checked. Raw
result is saved before type or completion claims. A captured failure is not a
completed integration. No legacy codec/restore claim is made. Runtime before
and after must agree. Root will supervise the one call with an external840s
subprocess timeout; do not execute before code review and current installed
identity/test checks pass. This review itself performs no EOS call.
