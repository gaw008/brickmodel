"""Research packet-core capture; never emits a legacy auditable event record."""
import argparse
from dataclasses import fields, replace
import hashlib
import json
from pathlib import Path
import time
import traceback

PRIOR=Path('/private/tmp/brick-four-cell-candidate-probe-v1/attempt01')
WATER=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')


def save(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)


def require(ok,message):
    if not ok:raise AssertionError(message)


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    output=parser.parse_args().output;output.mkdir(parents=True,exist_ok=False)
    started=time.monotonic()
    report={'capture_status':'started','external_watchdog_seconds':840,
        'script_sha256':sha(Path(__file__)),
        'qualification':'Research ordered packet core only. Not a legacy auditable record, checkpoint, resume artifact, spatial convergence or material validation.'}
    save(output/'runner.json',report)
    original=None;prior_initial=None
    try:
        from sludge_sandbox.run_service import runtime_identity
        from sludge_sandbox.verification_case import read_case,build_case,encode
        from sludge_sandbox.depletion_integration import integrate_depletion,OrderedPacketResult
        before=runtime_identity();report['runtime_before']=before
        save(output/'runtime-before.json',before)
        require(len(before['modules'])==67,'registered installed 67-module runtime')
        original=(PRIOR/'case.json').read_bytes();prior_initial=(PRIOR/'initial.json').read_bytes()
        (output/'case.json').write_bytes(original)
        report.update(case_sha256=sha(output/'case.json'),prior_initial_sha256=sha(PRIOR/'initial.json'))
        save(output/'runner.json',report)
        definition=read_case(output/'case.json');case=definition.payload
        require(case['grid']['cells']==4 and case['grid']['parent_cells']==2,'actual prior four-cell case')
        build_start=time.monotonic();built=build_case(definition,WATER)
        report['build_seconds']=time.monotonic()-build_start
        save(output/'initial.json',encode(built.initial))
        save(output/'initialization.json',built.initialization)
        save(output/'original-integration-policy.json',encode(built.policy))
        save(output/'original-depletion-policy.json',encode(built.depletion_policy))
        require(encode(built.initial)==json.loads(prior_initial),'exact prior initial state')
        require(built.start_s==.5 and built.end_s==.50032,'original complete horizon')
        require(built.policy.maximum_steps==512 and built.policy.maximum_wall_seconds==800.,'original resources')
        policy=replace(built.depletion_policy,ordered_event_policy='ordered_affine_packet_v1')
        restored=encode(policy);require(restored.pop('ordered_event_policy')=='ordered_affine_packet_v1','explicit opt-in')
        require(restored==encode(built.depletion_policy),'only ordered packet policy changed')
        save(output/'actual-depletion-policy.json',encode(policy))
        save(output/'original-interfaces.json',list(built.operator.interfaces))
        report.update(start_s=built.start_s,end_s=built.end_s)
        save(output/'runner.json',report)
        call_start=time.monotonic()
        out=integrate_depletion(built.initial,built.operator,start_s=built.start_s,end_s=built.end_s,
            integration_policy=built.policy,event_policy=policy)
        report['core_call_seconds']=time.monotonic()-call_start
        # Deliberately bypass the unsupported legacy codec. This diagnostic has
        # no operator reconstruction, event_record audit, seal or resume claim.
        raw={f.name:encode(getattr(out,f.name)) for f in fields(out) if f.name!='operator'}
        save(output/'core-result.json',{'research_schema':'ordered_packet_core_capture_v1',
            'qualification':report['qualification'],'actual_result_type':type(out).__name__,'result':raw})
        save(output/'final-interfaces.json',list(out.operator.interfaces))
        save(output/'final.json',encode(out.states[-1]))
        report.update(core_status=out.status,core_reason=out.reason,accepted_steps=len(out.steps),
            final_time_s=out.times_s[-1],evaluations=out.evaluations,attempted_steps=out.attempted_steps,
            rejected_trials=out.rejected_trials,core_elapsed_seconds=out.elapsed_seconds,
            phase_costs=encode(out.phase_costs),packet_count=len(getattr(out,'packets',())))
        save(output/'runner.json',report)
        require(type(out) is OrderedPacketResult,'explicit packet result type')
        # A non-completed core outcome is retained scientific evidence, not
        # runner success at integration. capture_status describes capture only.
        report['capture_status']='captured_core_result'
    except BaseException as exc:
        report.update(capture_status='capture_failed',exception_type=type(exc).__name__,
            reason=str(exc),traceback=traceback.format_exc())
    finally:
        try:
            from sludge_sandbox.run_service import runtime_identity
            after=runtime_identity();save(output/'runtime-after.json',after);report['runtime_after']=after
            require(report['runtime_before']==after,'runtime changed')
            require(original is not None and (PRIOR/'case.json').read_bytes()==original==(output/'case.json').read_bytes(),'case changed')
            require(prior_initial is not None and (PRIOR/'initial.json').read_bytes()==prior_initial,'prior initial changed')
        except BaseException:
            report['integrity_error']=traceback.format_exc();report['capture_status']='capture_failed'
        report['runner_elapsed_seconds']=time.monotonic()-started;save(output/'runner.json',report)
    require(report['capture_status']=='captured_core_result',report.get('reason','capture failed'))


if __name__=='__main__':main()
