# Frozen ordered affine packet candidate

Core SHA256: 3866f15b11f0e78c4e77591ffb8fe156bafefe05a379165ff78e635fe52c3223
Tests SHA256: 5ac506d3f2dba1ab588c9b8299e37d380ea0d03a2d4c55dc4a366fb389ab13c5

Actual final command:

```
PYTHONPATH=src:tests/sandbox /private/tmp/brick-water-backend-probe/venv/bin/python -m pytest tests/sandbox/test_depletion_ordered_packet.py tests/sandbox/test_depletion_integration.py tests/sandbox/test_depletion_spine.py tests/sandbox/test_depletion_continuation.py tests/sandbox/test_depletion_multicell.py -q
```

49 passed in 8.33s; full output green09.log. Fourteen new cases, thirty-five existing cases. Earlier failed fixture runs remain in green01.log and green08.log. The initial no-progress test keyword failure remains red-no-progress-fixture-error.log; the corrected actual RED red-no-progress.log demonstrates unchanged speculative retries until explicit cancellation, before the new structured unsupported guard. No EOS, installation, or commit was performed.

Default numeric/diagnostic parity of two actual old/new manufactured runs is recorded separately in default-parity.json and check_default.py; wall duration and live operator objects are excluded. The original default tie refusal and completed separated-event case were compared. This is bounded parity, not exhaustive proof.

Every packet frame retains its own numerical affine root ordering evidence and actual event state/observation. Six accepted event metadata bounds are conservative maxima across the complete packet, not per-event raw differences. Per-event detailed comparisons remain in refinement diagnostics. Two successive comparisons and the independent finer approach are required before atomic commit. Speculative callbacks, cancellations, source mutation, and comparison disagreement never commit an initial subset of a packet.

The stage-preview injection tests exercise actual integrator rejection/control flow and retained ledgers; the artificial preview is explicitly not represented as a physical RK solution. An accelerating prediction which cannot be localized inside the fixed common endpoint now returns unsupported, rather than retrying without progress. Exact coincident or unrepresentably separated numerical roots remain unsupported. Root proof applies to a numerical affine surrogate, not a rigorous enclosure of the full wet nonlinear trajectory.

The result is an OrderedPacketResult subtype. Old event codec/service continuation is not admitted; parent-owned boundary guards explicitly reject it. No real-water packet success, spatial convergence, material admission, or complete wet-to-fired validation is claimed.

No ruff, mypy, or black executable was available on PATH. Independent mathematical and transaction reviews were requested against the above frozen hashes.
