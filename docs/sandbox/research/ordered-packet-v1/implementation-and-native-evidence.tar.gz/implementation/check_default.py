import importlib.util,sys,json
from pathlib import Path
from dataclasses import fields,replace,is_dataclass
from fractions import Fraction
import numpy as np
from sludge_sandbox import depletion_integration as current
from test_depletion_ordered_packet import setup
here=Path(__file__).parent
spec=importlib.util.spec_from_file_location('sludge_sandbox.packet_original',here/'before.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
def clean(x):
 if is_dataclass(x):return {f.name:clean(getattr(x,f.name)) for f in fields(x) if f.name not in ('operator','elapsed_seconds')}
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,Fraction):return [x.numerator,x.denominator]
 if hasattr(x,'items'):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [clean(v) for v in x]
 return x
checks=[]
for gap in (1e-9,.005):
 p,e,op,initial,calls=setup(gap)
 e=replace(e,ordered_event_policy=None)
 previous_args={f.name:getattr(e,f.name) for f in fields(old.DepletionPolicy)}
 previous_args['nested_approach']=old.NestedApproachPolicy(**{f.name:getattr(e.nested_approach,f.name) for f in fields(old.NestedApproachPolicy)})
 ep=old.DepletionPolicy(**previous_args)
 def callback(state,t,modes):
  obs=op.evaluate_callback(state,t,modes)
  return old.DepletionEvaluation(**{f.name:getattr(obs,f.name) for f in fields(old.DepletionEvaluation)})
 operator=old.ManufacturedDepletionAdapter(**{f.name:(callback if f.name=='evaluate_callback' else getattr(op,f.name)) for f in fields(old.ManufacturedDepletionAdapter)})
 a=old.integrate_depletion(initial,operator,start_s=0.,end_s=.03,integration_policy=p,event_policy=ep)
 b=current.integrate_depletion(initial,op,start_s=0.,end_s=.03,integration_policy=p,event_policy=e)
 assert clean(a)==clean(b)
 checks.append({'gap':gap,'status':b.status,'all_nonwall_result_fields_equal':True})
try:
 old.DepletionPolicy(**dict(previous_args,ordered_event_policy='ordered_affine_packet_v1'))
except TypeError as exc:
 (here/'red-baseline.json').write_text(json.dumps({'old_optin_unavailable':str(exc),'existing_tie_status':checks[0]['status']}))
else:raise AssertionError('old unexpectedly supports option')
(here/'default-parity.json').write_text(json.dumps(checks,indent=2))
