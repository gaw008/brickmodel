from pathlib import Path
p=Path('src/sludge_sandbox/depletion_integration.py');s=p.read_text()
s=s.replace("    pressure_comparison: object = field(default=None,metadata={'omit_when_none':True})", "    pressure_comparison: object = field(default=None,metadata={'omit_when_none':True})\n    ordered_event_policy: str | None = field(default=None,metadata={'omit_when_none':True})")
needle="        if self.pressure_comparison is not None:\n"
pos=s.index(needle)
s=s[:pos]+"""        if self.ordered_event_policy is not None:
            if (type(self.ordered_event_policy) is not str or self.ordered_event_policy!='ordered_affine_packet_v1'
                    or self.terminal_method!='affine_midpoint' or self.nested_approach is None):
                raise DepletionIntegrationError('ordered_packet_requires_affine_and_independent_approach')
"""+s[pos:]
pos=s.index('@dataclass\nclass _Path:')
s=s[:pos]+"""@dataclass(frozen=True)
class OrderedEventFrame:
    event: DepletionEvent
    state: ConservedState
    observation: DepletionEvaluation
    root_order: Mapping


@dataclass(frozen=True)
class OrderedPacketResult(DepletionResult):
    packets: tuple = ()
    packet_schema: str = 'sandbox_ordered_affine_packet_core_v1'


"""+s[pos:]
s=s.replace('    approach_grid: tuple = ()\n','    approach_grid: tuple = ()\n    packet_frames: list = field(default_factory=list)\n    packet_snapshots: list = field(default_factory=list)\n    pending_order: object = None\n',1)
s=s.replace('    nested=ep.nested_approach\n','    nested=ep.nested_approach\n    ordered=ep.ordered_event_policy is not None\n    committed_packets=[]\n    if ordered and continuation is not None:\n        raise DepletionIntegrationError(\'ordered_packet_continuation_not_admitted\')\n',1)
s=s.replace('        if len(options)>1 and abs(options[1][0]-options[0][0])<=Fraction(ep.time_absolute_s):','        if not ordered and len(options)>1 and abs(options[1][0]-options[0][0])<=Fraction(ep.time_absolute_s):')
needle='        clock=locate_affine_depletion_clock(t,midpoint,float(state.amounts_mol[cell,li]),\n'
pos=s.index(needle)
s=s[:pos]+"""        if ordered:
            from .depletion_group_clock import AffineInventory
            candidates=[];proof=[]
            for index,mode in enumerate(path.op.interfaces):
                if mode!='existing_liquid':continue
                def terms(observed):
                    r=observed.rates
                    return (float(r.face_species_mol_s[index,li]),-float(r.face_species_mol_s[index+1,li]),
                            float(r.reaction_species_mol_s[index,li]))
                left,right=terms(obs),terms(middle)
                rate=sum(map(Fraction,left),Fraction())
                acceleration=(sum(map(Fraction,right),Fraction())-rate)/hm
                model=AffineInventory(index,Fraction(float(state.amounts_mol[index,li])),rate,acceleration)
                row={'cell_index':index,'initial_mol':model.initial_mol,'rate_mol_s':rate,
                     'acceleration_mol_s2':acceleration,'upper_elapsed_s':Fraction(upper)-Fraction(t)}
                if model.minimum(Fraction(upper)-Fraction(t))>0:
                    row['root_interval_s']=None
                else:
                    located=locate_affine_depletion_clock(t,midpoint,float(state.amounts_mol[index,li]),
                        left,right,upper,ep.time_absolute_s)
                    lo=Fraction(located.end_s)
                    hi=lo+located.event_time_rounding_s
                    row['root_interval_s']=(lo,hi)
                    candidates.append((lo,hi,index))
                proof.append(row)
            if not candidates:raise _Failure('unsupported','ordered_packet_no_affine_root')
            candidates.sort()
            lo,hi,selected=candidates[0]
            if len(candidates)>1 and not hi<candidates[1][0]:
                raise _Failure('unsupported','ordered_packet_roots_not_strictly_separated')
            cell=selected
            binding=spine_binding(path.op,state,t,tc,0.,0.,cell)
            path.pending_order=_freeze_diagnostic({'qualification':'numerical_affine_surrogate_order_not_true_rhs_certificate',
                'start_s':t,'midpoint_s':midpoint,'selected_cell':cell,'roots':proof})
"""+s[pos:]
# Bind source again after all clocks and save immutable actual per-event frame.
needle="            clock.event_time_rounding_s,evap,terminal_evidence=AffineTerminalEvidence(clock,predictor,obs,middle))\n"
s=s.replace(needle,needle+"""        if ordered:
            path.packet_frames.append(OrderedEventFrame(path.event,path.event_state,path.event_observation,path.pending_order))
            path.packet_snapshots.append(path.event_pressure_snapshot)
""")
# packet continuation reuses actual mixed RHS. No stage callback may mutate path.
pos=s.index('    def continue_after_event(path,tc):')
s=s[:pos]+"""    def continue_packet(path,tc,cap,ordinary_cap,safe):
        while path.times[-1]<tc:
            guard();at=path.times[-1];current=path.states[-1]
            obs=observe(path.op,current,at,'dry');other=candidate(path.op,current,obs)
            if other is not None and other[0]<=Fraction(cap) and Fraction(at)+other[0]<Fraction(tc):
                terminal(path,obs,*other,tc)
                continue
            desired=min(ordinary_cap,tc-at,safe*float(other[0]) if other else ordinary_cap)
            finish=_ordinary_program_endpoint(at,tc,min(tc,at+desired),ordinary_cap,
                Fraction(safe)*other[0] if other else None)
            segment=normal(path.op,current,at,finish,ordinary_cap,phase='dry')
            extend(path,segment)
            if segment.status!='completed':raise _Failure(segment.status,segment.reason)
        first=path.packet_frames[0]
        path.event,path.event_state,path.event_observation=first.event,first.state,first.observation
        path.event_pressure_snapshot=path.packet_snapshots[0]

"""+s[pos:]
s=s.replace('            if choice is not None and event_cell is not None and choice[1]!=event_cell:', '            if not ordered and choice is not None and event_cell is not None and choice[1]!=event_cell:')
s=s.replace('                    continue_after_event(path,tc)\n','                    if ordered:continue_packet(path,tc,cap,ordinary_cap,safe)\n                    else:continue_after_event(path,tc)\n',1)
s=s.replace('    def comparison(a,b,tc):','    def single_comparison(a,b,tc):',1)
pos=s.index('    def commit(path):')
s=s[:pos]+"""    def comparison(a,b,tc):
        if not ordered:return single_comparison(a,b,tc)
        if (tuple(f.event.cell_index for f in a.packet_frames)!=tuple(f.event.cell_index for f in b.packet_frames)
                or a.op.interfaces!=b.op.interfaces):
            raise _Failure('unsupported','ordered_packet_refinement_order_or_modes_changed')
        results=[]
        for index,(left,right) in enumerate(zip(a.packet_frames,b.packet_frames)):
            aa=replace(a,event=left.event,event_state=left.state,event_observation=left.observation,
                       event_pressure_snapshot=a.packet_snapshots[index])
            bb=replace(b,event=right.event,event_state=right.state,event_observation=right.observation,
                       event_pressure_snapshot=b.packet_snapshots[index])
            results.append(single_comparison(aa,bb,tc))
        if not results:raise _Failure('unsupported','empty_ordered_packet')
        diffs=tuple(max(row[1][i] for row in results) for i in range(len(results[0][1])))
        details=dict(results[0][2]);details['ordered_packet_comparisons']=tuple(row[2] for row in results)
        return all(row[0] for row in results),diffs,_freeze_diagnostic(details)

"""+s[pos:]
s=s.replace('        event=path.event\n        cn=', "        event=path.event\n        packet_events=tuple(f.event for f in path.packet_frames) if ordered else (() if event is None else (event,))\n        panel_events={id(e.terminal_panel):e for e in packet_events}\n        if len(panel_events)!=len(packet_events):raise DepletionIntegrationError('duplicate_packet_terminal_panel')\n        cn=",1)
s=s.replace('            after=path.states[j+1]\n            before=path.states[j]\n','            event=panel_events.get(id(step))\n            after=path.states[j+1]\n            before=path.states[j]\n',1)
s=s.replace("        if event is not None:\n            events.append(event)\n            if event.correction is not None:corrections.append(event.correction)\n", "        for event in packet_events:\n            events.append(event)\n            if event.correction is not None:corrections.append(event.correction)\n        if ordered and path.packet_frames:committed_packets.append(tuple(path.packet_frames))\n",1)
# Sync annotated accepted aggregate diagnostic into first packet frame only; every frame compared.
needle='                                commit(path);break\n'
s=s.replace(needle,"                                if ordered:\n                                    path.packet_frames[0]=replace(path.packet_frames[0],event=path.event)\n"+needle)
# Explicit marker and result subclass. Default constructor exactly unchanged.
s=s.replace('    return DepletionResult(status,reason,tuple(times)', '    result=DepletionResult(status,reason,tuple(times)',1)
s += "\n    if ordered:\n        return OrderedPacketResult(**{f.name:getattr(result,f.name) for f in fields(DepletionResult)},packets=tuple(committed_packets))\n    return result\n"
# fields imported already?
s=s.replace('from dataclasses import dataclass, field, replace','from dataclasses import dataclass, field, fields, replace')
p.write_text(s)
