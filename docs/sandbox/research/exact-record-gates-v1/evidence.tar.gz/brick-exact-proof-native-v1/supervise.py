from pathlib import Path
import importlib.util,sys,json,hashlib
root=Path(__file__).parent
source=Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/research-process-supervisor/supervisor.py')
assert hashlib.sha256(source.read_bytes()).hexdigest()=='939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1'
spec=importlib.util.spec_from_file_location('supervisor',source)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
inputs=[root/'run.py',root/'PLAN.md',root/'supervise.py',root/'preflight.json',source,Path('/private/tmp/brick-exact-record-proof-audit-v1/exact_terminal_proof_audit.py')]
inputs.extend(Path('/private/tmp/brick-exact-record-native-v1/attempt01')/name for name in ('case.json','exact-run-record.json','initial.json','event-policy.json','integration-policy.json','runtime-before.json'))
inputs.extend(p for p in Path('/private/tmp/brick-free-native-events-v1/attempt01/water').rglob('*') if p.is_file())
r=m.run_attempt(root/'supervised01',['/private/tmp/brick-water-backend-probe/venv/bin/python',str(root/'run.py')],cwd='/private/tmp',input_paths=inputs,timeout_s=45,cleanup_grace_s=.1)
print(json.dumps(r,indent=2))
assert r['returncode']==0
