# Actual rebuilt-host terminal proof audit

One authorized execution, no trajectory integration. The unchanged supervisor939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1 enforced the registered45-second limit. Actual command `/private/tmp/brick-water-backend-probe/venv/bin/python /private/tmp/brick-exact-proof-native-v1/supervise.py` returned exit0 in about2.03seconds. No retry occurred.

Runner SHA c07be694647217e242dbc7d6add3d0cc85de030be2d827313cfceedae46e335a; reviewed proof module SHA ff991e946c72953c1e8a844cfc7c42165cd52b94ddeded9bb43ef2d49fc2ef7b. Host rebuilding plus read-audit took1.72754seconds; proof call took0.61268seconds. Both committed terminals were checked, with two candidate roots and one no-root exclusion. Predictor/full terminal states and quadrature, original cumulative writeback, actual mode/source binding and all three observation geometries passed the module's numerical checks.

Original78 runtime and actual79 runtime are preserved separately. All original78 hashes and all nonmodule metadata match exactly. The only added module is exact_record_audit.py SHA fb8e9a235592ad3e225fab538cb3425fdf9d6af5acf0bed30056fe786bc057a6. Only after proving that narrow read-audit compatibility was the original runtime passed to the original record's binding. Actual79 before/after is unchanged. Candidate, runner, original records, policies, case and water inputs have matching before/after hashes. This does not grant a general runtime-upgrade exception for continuation.

See attempt01/proof-result.json, report.json, runtime-compatibility.json, both original/actual runtime files and inputs-before/after.json; supervised01 retains the parent status/stdout/stderr and input checks.

The result proves this committed-terminal numerical-evidence gate against an actual rebuilt host. It does not evaluate a new trajectory or repeat the original77-second integration. Full original-prefix auditing, six-gate comparison auditing, cumulative resource auditing and continuation admission remain distinct gates; this report is not resume authority, a full-RHS validation or material qualification.
