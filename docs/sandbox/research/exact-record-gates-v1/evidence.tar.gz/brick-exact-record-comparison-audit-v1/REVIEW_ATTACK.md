# Reproduced blocking original-coarse bypass

Source reviewed: 8993399d64693b81fa7d32dd4efc5c80c8cfacbabf021ea50bafc88dad6fc5b6.

Pure instrumented record from test_exact_record_comparison_audit.prepared was modified only as follows: first refinement status changed from coarse_reference to invented_coarse_status; every refinement approach_cap_s doubled using canonical Fraction pairs. Original external policy remained unchanged.

read_exact_run accepted the structurally typed record. audit_exact_comparisons returned success: committed_packets=1, comparisons=3, pressure_certificates=0, saved_endpoint_calls=0; modified record SHA d4e1af184df321303164e66b17297a2d20650d96e3585db4723cf5ccbec97b8b.

HIGH: original coarse controls are only checked inside a branch selected by the untrusted status label. Final committed group selection never requires g[0] to actually be a level-zero terminal coarse_reference, so original approach control binding can be bypassed while relative halving still holds. Require an explicit valid original coarse anchor for each committed group and validate the allowed refinement sequence/status contract before consuming its comparisons. Failed/uncommitted diagnostic records must retain their own honest partial treatment.

No EOS, repository/source changes or new physical fixture was used. This is a saved-record validation bypass. Do not approve this snapshot until repaired and regression-tested.
