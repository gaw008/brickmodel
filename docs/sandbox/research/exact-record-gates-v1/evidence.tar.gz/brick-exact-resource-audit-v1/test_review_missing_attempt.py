"""Saved refinement frame cannot outlive its erased cost-bearing attempt."""
import json
import pytest
from test_exact_record import make
from sludge_sandbox.exact_resource_audit import audit_exact_resources, ResourceAuditError


def test_retained_refinement_terminal_requires_recorded_attempt(monkeypatch):
    raw, _, run = make(monkeypatch)
    data = json.loads(raw)
    result = data['result']['fields']
    removed = result['terminal_attempts']['sequence'].pop(0)['fields']
    ref = result['refinements']['sequence'][0]['fields']
    assert ref['path']['fields']['frames']['sequence'][0]['fields']['terminal']['fields'] == removed
    costs = removed['costs']['fields']
    for outer, inner in (('predictor_attempts','predictor_panel_attempts'),
                         ('terminal_attempts','terminal_panel_attempts'),
                         ('terminal_panels','terminal_panels')):
        result['costs']['mapping'][outer] -= costs[inner]
        ref['costs']['mapping'][outer] -= costs[inner]
    with pytest.raises(ResourceAuditError):
        audit_exact_resources(json.dumps(data).encode(), original_policy=run.initial_policy)
