"""Independent saved-object completion telemetry attack; no EOS."""
import json
import pytest
from test_exact_record import make
from sludge_sandbox.exact_resource_audit import audit_exact_resources, ResourceAuditError


def test_materialized_terminal_panel_cannot_lose_its_charge(monkeypatch):
    raw, _, run = make(monkeypatch)
    data = json.loads(raw)
    result = data['result']['fields']
    attempt = result['terminal_attempts']['sequence'][0]['fields']
    assert attempt['terminal_panel'] is not None
    assert attempt['costs']['fields']['terminal_panels'] == 1
    # The first actual terminal belongs to the first refinement in this fixture.
    ref = result['refinements']['sequence'][0]['fields']
    assert ref['path']['fields']['frames']['sequence'][0]['fields']['terminal']['fields']['terminal_panel'] == attempt['terminal_panel']
    for key in ('terminal_panel_attempts', 'terminal_panels'):
        attempt['costs']['fields'][key] -= 1
    for key in ('terminal_attempts', 'terminal_panels'):
        result['costs']['mapping'][key] -= 1
        ref['costs']['mapping'][key] -= 1
    with pytest.raises(ResourceAuditError):
        audit_exact_resources(json.dumps(data).encode(), original_policy=run.initial_policy)
