from pathlib import Path
import hashlib,json,time
from exact_resource_audit import audit_exact_resources
from sludge_sandbox.integration import IntegrationPolicy
from sludge_sandbox.verification_case import encode
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent
prior=Path('/private/tmp/brick-exact-record-native-v1/attempt01')
paths=[prior/'exact-run-record.json',prior/'integration-policy.json',root/'exact_resource_audit.py',Path(__file__)]
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
assert before[str(paths[0])]=='ac03be011f4f1b3dd47e12647f523e223797dcd53031d9dbd1b96d9e2f67af52'
assert before[str(paths[1])]=='a82ef632f6caab8993f71b9246958ce1dcdbfaded12a2d136a88b860de801f95'
assert before[str(paths[2])]=='c1bfaabb1a3325b26a40cf3fa925e9abaf18aa10278823690cbec5a317285ce0'
runtime=runtime_identity();started=time.monotonic()
policy=IntegrationPolicy(**json.loads(paths[1].read_bytes()))
audit=audit_exact_resources(paths[0].read_bytes(),original_policy=policy)
assert audit.charged_panels==79 and audit.remaining_panels==433
assert audit.cumulative_counters['ordinary_panels']==71 and audit.cumulative_counters['terminal_attempts']==8
assert audit.remaining_rejections==100 and audit.terminal_calls==8 and audit.resume_authorized is False
assert runtime_identity()==runtime
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==before[str(p)] for p in paths)
result={'status':'passed','elapsed_s':time.monotonic()-started,'qualification':'Read-only saved original resource consistency; no host build, EOS, integration, continuation, or independent historical wall reconstruction.','inputs':before,'actual_auditor_runtime':runtime,'resource_audit':encode(audit)}
(root/'actual-saved-resource-result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':result['status'],'elapsed_s':result['elapsed_s'],'charged':audit.charged_panels,'remaining':audit.remaining_panels}))
