# Exact continuation resource contract — bounded design review

The current record is sufficient to prevent automatic budget renewal in a controlled continuation API: carry its validated cumulative counters and active execution elapsed time forward, and charge all further work against the original policies. It is not sufficient to independently reconstruct every discarded ordinary trial or historical wall second. Those are different claims; a full RHS journal is not required to implement no-reset continuation.

This report is read-only. No EOS, trajectory, source edit or new audit implementation was run. References below are current source contracts, not a declaration that resume is already implemented or authorized. Existing PartialExactAudit explicitly denies resume, and its other missing numerical gates remain separate work.

## Existing budget semantics that must remain unchanged

`exact_depletion_integration.py:127-138` initializes eleven counters and defines the charged panel count as:

`ordinary_panels + stage_replans + terminal_attempts`.

Here `terminal_attempts` means terminal-panel construction attempts, not simply the number of calls to execute_exact_terminal. A terminal call can fail before that stage and charge zero panels. Predictors, ordinary trial counts and RHS/pressure endpoint counts are separate diagnostics, not additional panel charges. Do not replace this formula with accepted global steps, all ordinary trials, predictor counts or all terminal call records.

The original guards are charged panels >= maximum_steps; ordinary_rejected >= maximum_rejections; elapsed active driver time >= maximum_wall_seconds. Existing observation guards run before and after physical calls. `remaining_policy` supplies subordinate ordinary/terminal calls with original remaining panel/rejection/wall allowances. Ordinary accepted panels, including speculative refinement paths later discarded, are charged; accepted global prefix length alone is insufficient.

`exact_integration.py` returns attempted_trials, rejected_trials, evaluations and elapsed_seconds, but the outer driver currently retains only their cumulative contribution, not a separate record for every ordinary call. Its accepted_step limit is distinct from attempted trials. There is no original RHS or pressure-endpoint evaluation cap; adding one would be a new policy, not an audit of the old contract.

## What can be checked from current saved evidence

| Quantity | Executable saved-data check | Limitation |
|---|---|---|
| Terminal panel attempts/completions and predictor attempts | Sum each entry of the top-level terminal_attempts sequence once using its TerminalCosts; require exact equality to corresponding outer totals. | Packet/refinement frames reference these attempts again; never sum the copies as new work. List length is not panel-attempt count. |
| Terminal returned observations | For each attempt, evaluation_completed equals observation count; attempted >= completed. Check nonnegative integer cost fields and panel/predictor completion <= attempts. Sum terminal evaluation contributions as lower bounds on global host counters. | A failed callback can have no observation. Saved count is evidence for the attempted call, not a reconstructed RHS output. |
| Refinement costs | Check complete counter schema/types and componentwise nonnegative deltas. Sum disjoint terminal/independent/failed refinement records as lower bounds on global totals. These are consecutive deltas in the source control flow. | They do not include ordinary progress and selector observations outside refinements. Do not add terminal costs to these deltas: they overlap. |
| Ordinary accepted work in retained paths | Count path ledgers minus actual frame terminal ledgers for each separately executed refinement path; compare against that refinement's ordinary_panels. Retained successful paths supply exact ordinary counts; interrupted paths may require a lower bound when capture stops early. Count committed ordinary steps outside packets separately, avoiding committed/refinement duplication. | There is no universally complete independent ordinary-call journal for failure paths or discarded trial stages. |
| Pressure endpoints | Reuse the pressure comparison audit to count actual endpoint evidence once per executed comparison and compare to outer attempted/completed totals. Retained evidence supplies lower bounds on failed runs; a completed run can require equality where all comparisons have records. | An endpoint failure before a completed certificate can leave attempted cost with no certificate; do not require certificate count equality for every failed/cancelled run. |
| Overall counters | Original charged-panel formula; nonnegative strict integers; completed <= attempted; ordinary_panels + ordinary_rejected <= ordinary_trials; totals >= non-overlapping or separately computed evidence lower bounds. | Existing codec does only some of these checks. This table is proposed additional validation, not current codec coverage. |
| Wall time | Require finite nonnegative outer elapsed_seconds; preserve its exact represented value. Per-terminal elapsed values must be finite nonnegative; their sequential sum is an approximate diagnostic lower bound on outer elapsed. | Monotonic timer readings and wrapper overhead were not journaled. Do not invent an exact equality by summing nested times, or make floating rounding of clock reads a physical failure. |

The global elapsed field already includes ordinary, terminal, comparison and audit/driver time within the integration call. Adding nested elapsed values would double-charge it. Original build_case initialization, record encoding and offline audit are outside this driver timer; paused human time is also not active integration time. Preserve that definition rather than silently expanding it.

## Minimal continuation boundary

Use a separate explicit checked-continuation interface, with the original record hash and original initial state/interval/policies. Do not implement resume as `integrate_exact_depletion(last_state, current_operator, start=last_time, ...)` with empty costs/totals.

1. Reparse immutable record bytes; validate external original case/operator/runtime bindings and all required numerical acceptance gates. Consume the returned checked object, not replaceable fields of a caller-created frozen dataclass. A resource check alone cannot upgrade PartialExactAudit to resumable status.
2. Initially admit only an interior cancelled prefix with the original end time unchanged. Completed runs need no resume; resource-exhausted records receive an immediate structured resource result unless an explicit new run is requested. Source/domain/numerical failures should not be silently resumed under unchanged inputs.
3. Seed the new execution with the complete original accepted history, operator modes and correction totals; seed all eleven counters from the prior record and `elapsed_before` from its outer elapsed_seconds. Restart speculative refinement work if necessary, but retain all its previously charged cost. It is acceptable to recompute speculative work if it spends only the remaining allowance.
4. Store the original policy unchanged as result provenance. Compute budget usage from original counters plus current additions. Before any new physical callback, enforce `elapsed_before + current_active_elapsed >= original_wall`, the existing charged panel formula and global rejections. If already exhausted, return without an EOS callback; never construct an invalid subpolicy with zero/negative remaining allowance.
5. Pass only remaining allowances to subordinate integrators. Avoid double seeding: either global counters include prior usage and guards use them directly, or add seed+delta exactly once. Return cumulative costs and cumulative elapsed, not only continuation-local values. Keep continuation-local telemetry separately if useful.
6. Merge original accepted prefix exactly once and continue original-initial conservation budgets; do not reset correction totals or numerical budgets. A second continuation consumes the cumulative result from the first, not the original checkpoint again.

For binary64 elapsed accumulation, a minimal conservative implementation can keep the cumulative sum internally as Fraction of the recorded elapsed and current represented duration, compare to Fraction(original maximum_wall_seconds), then round outward once for the saved cumulative telemetry. This avoids a downward-rounded sum granting a tiny extra budget over repeated continuations. It does not turn timer readings into exact physical time and does not require reconstructing earlier wall seconds.

## Trust boundary and whether a new journal is necessary

Current source/case binding proves which model is claimed, not that externally editable elapsed_seconds is historically authentic. A person can lower otherwise-consistent counters or wall telemetry and recompute an unsigned JSON hash. No amount of current prefix physics can recover omitted wall time. Therefore the no-reset guarantee is relative to an authoritative saved record from the run store, whose parent hash the service resolves itself; do not accept caller-provided replacement counters as authority. Existing immutable bytes plus server-owned stored run history are enough for ordinary accidental-reset prevention. Cryptographic signing is only necessary if untrusted record import is required to authenticate historical usage.

A new full RHS journal is NOT a prerequisite for controlled resume. Minimum service metadata, if absent, is a continuation parent record SHA plus an atomically stored generation/claim so concurrent resume requests cannot both spend the same parent allowance within one logical run. Exact replay or explicit branches must be identified as separate runs, not silently merged budget histories. This is coordination metadata, not new physical telemetry.

Only if independent reconstruction of every ordinary discarded-cost contribution becomes a required claim, add a compact ordinary-call summary journal: call ID, start/end exact times, return status, attempted/rejected/accepted counts, and entry/exit cumulative counters; retain that summary even on cancellation/failure. Such summaries still attest wall time rather than prove it from numerical states. Existing records should retain their honest source-bound-telemetry qualification instead of being declared permanently unusable.

## Concrete no-EOS negative controls for implementation

- Cancel after a charged ordinary panel; resume with the same original tiny panel cap. Count callbacks and prove only the original remaining panels can be spent. A wrapper that resets costs must fail this test.
- Produce a cancellation during an uncommitted refinement after terminal work. Ensure the returned accepted prefix omits speculative frames but its terminal/ordinary costs remain nonzero; resume must subtract those costs too. Counting only committed steps must fail.
- Seed a structurally valid cancelled record at its exact charged-panel limit and separately at its rejection limit; assert zero new physical callbacks and the original resource reason. Do not loosen original constructors to manufacture invalid policies.
- Use an injected monotonic clock in a pure manufactured fixture: first segment consumes most of the wall allowance; a continuation exhausts the remaining duration after a known callback. A timer reset would incorrectly allow further callbacks. Test repeated cancellation/resume sums and outward representation too.
- Cancel a terminal callback before terminal panel construction: preserve RHS attempt count but do not invent a terminal-panel charge. Conversely an actual terminal-panel attempt must remain charged even if the candidate never commits.
- Replace a record wrapper's public cost fields while keeping its canonical bytes; continuation must consume the reparsed bytes. Alter the stored cost bytes and require authoritative parent-hash mismatch; neither attack should grant fresh budget.
- Change maximum_steps/maximum_rejections/wall or original end in a resume request; refuse before callbacks. Test two successive resumes for exact prefix concatenation, no duplicated prior counters and no reset of correction totals.
- Trigger two simultaneous resume claims against the same parent generation at the service layer; only one may become that logical run's next continuation. This test is unnecessary for a purely in-process single-owner API but necessary before service concurrency admission.

Conclusion: preserve authoritative cumulative telemetry, reconstruct the portions actually recorded, enforce remaining original allowances before work, and label the unprovable portions honestly. This yields an implementable no-budget-reset contract without inventing missing history or relaxing numerical policy semantics.

## Read-only verifier additions: old 78-module record under a current 79-module package

A new read-only audit module must not force a repeat of the original 77-second trajectory when every original execution module and dependency is unchanged. It also must not be falsely described as the original 78-module runtime.

The minimal explicit compatibility preflight for audit reading is:

- Collect the actual current runtime independently. Require every old module key to remain present with the exact old hash; missing or changed modules fail. Require catalogs, versions, Python and platform fields to match the old runtime, since those are the actual recorded non-module fields.
- Require the module-set difference to equal an explicit allowlist of reviewed verifier-only additions, each pinned to its actual expected hash (for the immediate 78-to-79 case, exact_record_audit.py only). Do not permit arbitrary extras, replacement package paths or numerical model changes under a generic subset check.
- Preserve both complete identities separately as record_runtime and current_auditor_runtime, with the compatibility rule/version and approved addition hashes. Recheck the current runtime after the audit. If installation loading paths are relevant, keep the installed module byte-match evidence as well; the runtime report alone should not disguise a different imported provider.
- Only after this comparison passes, supply the already-verified original runtime to validate_binding to match the historical record's claimed identity. Continue building the actual original operator and checking its live source/provider identity independently. Passing old JSON without the current-runtime comparison is not this procedure.

This is read compatibility, not execution equivalence across arbitrary versions. It does not authorize cross-version continuation, reinterpret a historical execution as having 79 modules, or turn the new verifier into an original recorded dependency. A future resume boundary must separately decide and explicitly audit any compatibility transition; the current read-only audit can proceed now without repeating the trajectory.
