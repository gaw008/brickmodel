"""One actual host rebuild and pure saved comparison audit; no trajectory."""
from pathlib import Path
from dataclasses import replace
import hashlib,json,time,traceback,importlib.util,sys
import sludge_sandbox
from sludge_sandbox.verification_case import build_case,read_case,encode
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.run_service import runtime_identity
from sludge_sandbox.exact_record import read_exact_run
ROOT=Path(__file__).parent
PRIOR=Path('/private/tmp/brick-exact-record-native-v1/attempt01')
CANDIDATE=Path('/private/tmp/brick-exact-record-comparison-audit-v1/exact_record_comparison_audit.py')
EXPECTED_CANDIDATE='1cef63c34c9cf77c51a62078df0b696dae2c33096140b079f8b0d8c79b988368'
ADDED_HASH='fb8e9a235592ad3e225fab538cb3425fdf9d6af5acf0bed30056fe786bc057a6'
WATER=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')
OUT=ROOT/'attempt01';OUT.mkdir(exist_ok=False)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
started=time.monotonic()
names=('case.json','exact-run-record.json','initial.json','event-policy.json','integration-policy.json','runtime-before.json')
paths=[PRIOR/n for n in names]+[CANDIDATE,Path(__file__),ROOT/'PLAN.md',ROOT/'supervise.py',ROOT/'preflight.json']+[p for p in WATER.rglob('*') if p.is_file()]
inputs={str(p):digest(p) for p in paths};save('inputs-before.json',inputs)
before=runtime_identity();save('runtime-actual79-before.json',before)
original=json.loads((PRIOR/'runtime-before.json').read_text());save('runtime-original78.json',original)
report={'status':'started','qualification':'Actual host rebuild and saved-record six-gate comparison audit. No integration, full RHS re-evaluation, root/fullpanel/resource certification or resume.'}
try:
    assert str(Path(sludge_sandbox.__file__).resolve()).startswith('/private/tmp/brick-water-backend-probe/venv/')
    assert digest(CANDIDATE)==EXPECTED_CANDIDATE
    assert len(original['modules'])==78 and len(before['modules'])==79
    assert {k:v for k,v in before.items() if k!='modules'}=={k:v for k,v in original.items() if k!='modules'}
    assert all(before['modules'].get(k)==v for k,v in original['modules'].items())
    added=set(before['modules'])-set(original['modules'])
    assert added=={'exact_record_audit.py'} and before['modules']['exact_record_audit.py']==ADDED_HASH
    save('runtime-compatibility.json',{'verified':True,'original_module_count':78,'actual_module_count':79,
        'unchanged_original_modules':78,'nonmodule_metadata_equal':True,'only_added_module':{'exact_record_audit.py':ADDED_HASH},
        'scope':'Explicit read-audit compatibility only. Original78 identity passed to original record binding after this check; actual79 retained distinctly.'})
    spec=importlib.util.spec_from_file_location('research_comparison_audit',CANDIDATE)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    built=build_case(read_case(PRIOR/'case.json'),WATER)
    assert encode(built.initial)==json.loads((PRIOR/'initial.json').read_text())
    policy=replace(built.depletion_policy,ordered_event_policy='ordered_affine_packet_v1')
    assert encode(policy)==json.loads((PRIOR/'event-policy.json').read_text())
    assert encode(built.policy)==json.loads((PRIOR/'integration-policy.json').read_text())
    op=ExactFreeWaterTransfer(built.operator);start=ExactEventTime.from_float(built.start_s);end=ExactEventTime.from_float(built.end_s)
    audit_start=time.monotonic()
    result=module.audit_exact_comparisons(read_exact_run((PRIOR/'exact-run-record.json').read_bytes()),op,
        original_initial=built.initial,start=start,end=end,integration_policy=built.policy,
        event_policy=policy,case_sha256=digest(PRIOR/'case.json'),runtime_identity=original)
    save('comparison-result.json',encode(result))
    assert result.record_sha256==digest(PRIOR/'exact-run-record.json') and result.committed_packets==1
    assert result.comparisons==3 and result.pressure_certificates>0 and not result.resume_authorized
    report.update(status='passed',audit_elapsed_s=time.monotonic()-audit_start,committed_packets=result.committed_packets,
        comparisons=result.comparisons,pressure_certificates=result.pressure_certificates,saved_endpoint_calls=result.saved_endpoint_calls,
        scope=result.scope,missing_gates=result.missing_gates)

except BaseException:report.update(status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-actual79-after.json',after);assert before==after
        final={str(p):digest(p) for p in paths};save('inputs-after.json',final);assert inputs==final
    except BaseException:report.update(status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_s=time.monotonic()-started,actual_modules=len(before['modules']),original_modules=len(original['modules']),
        inputs=inputs,runner_sha256=inputs[str(Path(__file__))],candidate_sha256=inputs[str(CANDIDATE)])
    save('report.json',report)
assert report['status']=='passed',report
