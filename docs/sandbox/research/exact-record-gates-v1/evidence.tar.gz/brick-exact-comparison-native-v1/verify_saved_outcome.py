"""Data-only diagnosis of the preserved failed runner; never reruns the audit/EOS."""
from pathlib import Path
import hashlib,json
root=Path(__file__).parent;d=root/'attempt01';prior=Path('/private/tmp/brick-exact-record-native-v1')
def read(p):return json.loads(p.read_text())
result=read(d/'comparison-result.json');report=read(d/'report.json');reference=read(prior/'comparison-audit.json')
strict=read(prior/'attempt01/exact-run-record.json')['result']['fields']
packets=len(strict['packets']['sequence'])
refinements=len(strict['refinements']['sequence']);assert refinements==8==reference['total_refinements']
comparisons=sum(bool(ref['fields']['comparison']) for ref in strict['refinements']['sequence'])
assert report['status']=='failed' and 'result.committed_packets==1' in report['traceback']
assert read(d/'runtime-actual79-before.json')==read(d/'runtime-actual79-after.json')
assert read(d/'inputs-before.json')==read(d/'inputs-after.json')
assert result['record_sha256']==hashlib.sha256((prior/'attempt01/exact-run-record.json').read_bytes()).hexdigest()
assert result['committed_packets']==packets==reference['committed_packets_checked']==2
assert result['comparisons']==comparisons==reference['comparison_records_checked']==6
assert result['pressure_certificates']==reference['pure_pressure_certificates_checked']==24
assert result['saved_endpoint_calls']==reference['saved_pressure_endpoint_calls']==24
assert not result['resume_authorized']
output={'saved_function_result_verified':True,'original_runner_status':'failed','reason':'incorrect postcondition expected one packet/three comparisons; actual frozen record contains two/six',
'packets':packets,'refinements':refinements,'comparisons':comparisons,'pressure_certificates':24,'endpoint_calls':24,'runtime_and_inputs_unchanged':True,
'qualification':'Data-only post-run verification of actual saved successful function return; original supervised attempt remains failed. No rerun, no new trajectory, no resume authority.'}
(d/'saved-outcome-verification.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output))
