import importlib.util
from pathlib import Path
import sys
spec=importlib.util.spec_from_file_location('sludge_sandbox.exact_terminal_proof_audit',Path(__file__).with_name('exact_terminal_proof_audit.py'))
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
