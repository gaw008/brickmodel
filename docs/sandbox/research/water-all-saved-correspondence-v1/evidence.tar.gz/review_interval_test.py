"""Independent pure arithmetic/jet probes; does not evaluate a water EOS."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import unittest
from interval_eos import Interval, Jet, I


class IntervalReview(unittest.TestCase):
    def encloses(self, interval, value):
        self.assertLessEqual(F(interval.lo), F(value))
        self.assertGreaterEqual(F(interval.hi), F(value))

    def test_directed_arithmetic_against_exact_rational_corners(self):
        with localcontext() as context:
            context.prec = 9
            for a,b,c,d in (('-1.0123456789','2.3456789012','-4.123456789','-.3123456789'),
                            ('.00000000123','.00000000987','3.456789123','9.123456789')):
                left, right = Interval(D(a),D(b)), Interval(D(c),D(d))
                for x in (D(a),D(b)):
                    for y in (D(c),D(d)):
                        self.encloses(left+right,F(x)+F(y))
                        self.encloses(left*right,F(x)*F(y))
                        self.encloses(left/right,F(x)/F(y))

    def test_exp_ln_enclose_high_precision_values(self):
        values = [D('-12.3456789'),D('0.00000012345'),D('8.7654321')]
        for value in values:
            with localcontext() as context:
                context.prec=100
                e=value.exp()
                positive=abs(value)+D('.5')
                logarithm=positive.ln()
            with localcontext() as context:
                context.prec=12
                self.encloses(I(value).exp(),e)
                self.encloses(I(positive).ln(),logarithm)

    def test_jet_polynomial_derivatives_exact(self):
        with localcontext() as context:
            context.prec=10
            d=Jet(Interval(D('1.23456789'),D('1.33456789')),I(1),I(0))
            p=3*d**4-2*d**2+7*d-1
            for s in ('1.23456789','1.3','1.33456789'):
                x=F(D(s))
                self.encloses(p.value,3*x**4-2*x*x+7*x-1)
                self.encloses(p.first,12*x**3-4*x+7)
                self.encloses(p.second,36*x*x-4)

    def test_jet_gaussian_against_analytic_derivatives(self):
        with localcontext() as context:
            context.prec=20
            x=Jet(Interval(D('1.1'),D('1.2')),I(1),I(0))
            output=(-(x-1)**2*3).exp()
        for s in ('1.1','1.15','1.2'):
            with localcontext() as context:
                context.prec=100
                z=D(s)-1
                e=(-3*z*z).exp()
                self.encloses(output.value,e)
                self.encloses(output.first,-6*z*e)
                self.encloses(output.second,(36*z*z-6)*e)

    def test_fractional_power_and_domain_refusal(self):
        with localcontext() as context:
            context.prec=20
            x=Jet(Interval(D('1.1'),D('1.2')),I(1),I(0))
            output=x**D('1.5')
        for s in ('1.1','1.2'):
            with localcontext() as context:
                context.prec=100
                z=D(s);v=(z.ln()*D('1.5')).exp()
                self.encloses(output.value,v)
                self.encloses(output.first,D('1.5')*v/z)
                self.encloses(output.second,D('.75')*v/z**2)
        with self.assertRaises(ValueError):
            Interval(D(-1),D(1)).reciprocal()
        with self.assertRaises(ValueError):
            Interval(D(0),D(1)).ln()


if __name__ == '__main__':
    unittest.main()
