# Independent density tube review — initial revision required

## Repaired freeze — APPROVE for local mathematical tube evidence

Final source 30bf0a3aeab845c6512b8f74ade733de647db47457cd4ac2204fa47587c63a40 / test4a851df4744e8bde09b71ed2837355db207031be921010d05b88447e6754d76b was independently reread and executed: **13 passed in 0.02 s**, in independent-fixed01.log/XML. The original mutable-binding negative test now fails closed before its derivative can run. All initial and subsequent binding reads require a nonempty exact tuple of nonempty, trimmed exact strings; no mutable reference can rewrite the saved identity. Later invalid or changed binding remains a failure with the original immutable before value retained. Original failure evidence remains below and in the saved RED artifacts.

Full-temperature derivative boxes, exact midpoint subdivisions, strict positive leaves, contiguous full density coverage and original box/wall limits are unchanged. Callback attempts/completions, evaluated-but-unaccepted boxes, failed callbacks and pending coverage are retained. Independent mixed-depth coverage and interior-temperature-negative controls passed. No unresolved HIGH/CRITICAL finding remains for the explicit generic/pinned mathematical contracts. No actual water/native EOS was evaluated; this does not establish stable phase or native numerical correspondence.

## Preserved original finding

Initial source e85f577c0327b6463b07813336631b42ca08481dd389c6d0fc4be12d69b1aa2c.

[HIGH] Mutable binding can rewrite the saved pre-call identity
File: density_tube.py:60
Issue: prove_generic stores before=binding() without validating immutable content. A callback returning the same list may mutate that list inside derivative(); before and after then both contain the changed values, and the routine returns proved=True. This was actually reproduced; review-mutable-binding-red.json preserves the initial input and false-positive output. Independent pytest records show one failed source-mutation negative test and two passed coverage/temperature tests.
Fix: Require an immutable tuple of immutable string identity atoms at the initial and every subsequent binding read, or otherwise freeze/validate the full binding value without sharing mutable references. Do not alter positivity, coverage, box or wall thresholds.

The pinned wrapper currently returns a tuple and does not directly expose the reproduced list case. Nevertheless, the public generic result claims source-before/source-after evidence; this false-positive must be removed before approval of that interface. No actual EOS or native call was made. All edits are independent temporary review artifacts.

Other checks so far: every derivative callback receives the whole temperature interval; successful leaves are strictly positive and exact sorted endpoint adjacency proves complete density coverage. Independent mixed-depth leaves conserve exact total span; an interval negative in interior temperature cannot be replaced by positive endpoint samples and fails at its box budget. Final review follows the repaired freeze.
