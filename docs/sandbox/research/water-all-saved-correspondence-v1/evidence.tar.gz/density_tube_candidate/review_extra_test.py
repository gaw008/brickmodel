"""Independent synthetic tube probes, no water EOS calls."""
from decimal import Decimal as D
from fractions import Fraction as F
from density_tube import prove_generic,eos


def run(derivative, binding=lambda:('source','implementation'), maximum_boxes=15):
    return prove_generic(eos.Interval(D(2),D(3)),eos.Interval(D(2),D(4)),
                         derivative=derivative,binding=binding,reducing_density=D(1),
                         reducing_temperature=D(10),maximum_boxes=maximum_boxes,
                         maximum_wall_seconds=1.)


def test_mutable_source_binding_cannot_rewrite_before_and_pass():
    current=['original-source','original-implementation']
    def derivative(t,r):
        current[0]='changed-source'
        return eos.I(1)
    try:
        result=run(derivative,binding=lambda:current)
    except ValueError:
        return
    assert not result.proved


def test_full_temperature_uncertainty_is_not_replaced_with_endpoint_samples():
    # d(T)=(T-2.5)^2-.1: both T endpoints positive, interior negative.
    def derivative(t,r):
        assert t==eos.Interval(D(2),D(3))
        return eos.Interval(D('-.1'),D('.15'))
    result=run(derivative,maximum_boxes=7)
    assert not result.proved and not result.leaves and result.pending
    assert result.evaluations_attempted==result.evaluations_completed==7
    assert 'box_budget' in result.reason


def test_mixed_depth_leaves_have_exact_nonoverlapping_full_cover():
    def derivative(t,r):
        if r.hi<=D(3) or r.hi-r.lo<=D('.25'):
            return eos.I(1)
        return eos.Interval(D(-1),D(2))
    result=run(derivative)
    assert result.proved and not result.pending
    assert len(result.leaves)==5
    assert sum((F(x.hi)-F(x.lo) for x in result.leaves),F())==2
    assert all(a.hi==b.lo for a,b in zip(result.leaves,result.leaves[1:]))
    assert all(v.derivative.lo>0 for v in result.visits if v.decision=='positive')
