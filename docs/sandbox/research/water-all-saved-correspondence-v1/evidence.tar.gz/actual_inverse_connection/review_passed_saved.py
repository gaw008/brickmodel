"""Saved successful inverse-T proof, exact rational algebra only; no EOS."""
from pathlib import Path
from fractions import Fraction as F
from collections import deque
from itertools import product
import hashlib,json
R=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def iv(x):return F(x['lo']),F(x['hi'])
def pt(x):return x,x
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
    v=[x*y for x in a for y in b];return min(v),max(v)
def isum(xs):
    s=pt(F())
    for x in xs:s=add(s,x)
    return s
def enclosed(saved,exact):
    a,b=iv(saved);assert a<=exact[0]<=exact[1]<=b
r=read(R/'result02.json');old=read(R/'result01.json');freeze=read(R/'FREEZE02.json')
assert r['freeze']==freeze and r['source_after']==freeze['files']=={p:sha(Path(p)) for p in freeze['files']}
assert r['status']=='proved_local_connection' and r['elapsed_seconds']<15
for key in ('step','cell','exact_epsilon_fraction','saved_epsilon_fraction','inverse','temperature','auxiliary_seed','newton'):
    assert r[key]==old[key],key
assert (r['step'],r['cell'])==(8,1)
a=r['coexistence'];k=a['krawczyk'];m=r['mechanical'];tube=r['tube'];args=r['mechanical_inputs']
assert r['temperature']==a['domain']['temperature']==a['center']['temperature']==m['temperature']==tube['temperature']==args['temperature']
saved=read(R.parent/'saved-endpoint-result02.json')['records'][15]
assert args==saved['inputs']
assert k['center']==r['newton'][-1]['center'] and k['preconditioner']==r['newton'][-1]['matrix']
assert k['jacobian']==a['domain']['jacobian'] and k['center_residual']==a['center']['residual']
assert a['source_sha256']==freeze['files'][str(R.parent/'heos-water.json')]
X=list(map(iv,k['box']));c=list(map(F,k['center']));C=[list(map(F,row)) for row in k['preconditioner']];J=[[iv(v) for v in row] for row in k['jacobian']];f=list(map(iv,k['center_residual']));w=list(map(F,k['weights']))
assert w==[F('4e-6'),F('.001')] and C[0][0]*C[1][1]-C[0][1]*C[1][0]!=0
for i in range(2):enclosed(k['box'][i],(c[i]-w[i],c[i]+w[i]))
A=[[sub(pt(F(int(i==j))),isum(mul(pt(C[i][q]),J[q][j]) for q in range(2))) for j in range(2)] for i in range(2)]
image=[add(sub(pt(c[i]),isum(mul(pt(C[i][j]),f[j]) for j in range(2))),isum(mul(A[i][j],sub(X[j],pt(c[j]))) for j in range(2))) for i in range(2)]
for s,e in zip(k['image'],image):enclosed(s,e)
norm=max(sum(max(abs(lo),abs(hi))*w[j]/w[i] for j,(lo,hi) in enumerate(row)) for i,row in enumerate(A))
assert norm<=F(k['contraction_upper'])<1
for i in range(2):
    lo,hi=iv(k['image'][i]);margins=(lo-X[i][0],X[i][1]-hi)
    assert all(0<F(s)<=e for s,e in zip(k['strict_margins'][i],margins))
assert k['proved'] and a['proved'] and all(iv(v)[0]>0 for v in a['domain']['stability'])
pressures=list(map(iv,a['domain']['pressure']))
assert iv(a['pressure'])==(max(p[0] for p in pressures),min(p[1] for p in pressures))
assert iv(m['lower_residual'])[1]<0<iv(m['upper_residual'])[0]
assert iv(m['liquid_pressure_derivative'])[0]>0 and iv(m['total_residual_derivative'])[0]>0
corners=[]
for t,v,rho,scale,nl,ng,rg in product(*(iv(args[key]) for key in ('temperature','effective_available_volume','liquid_molar_density','liquid_volume_scale','liquid_mol','gas_mol','gas_constant'))):
    vg=v-nl*scale/rho;assert vg>0;corners.append(ng*rg*t/vg)
enclosed(m['pressure'],(min(corners),max(corners)))
liquid=iv(a['domain']['density'][0]);rho=iv(args['liquid_molar_density'])
assert liquid[1]<rho[0] and iv(tube['density'])==(liquid[0],rho[1])
queue=deque([iv(tube['density'])]);positive=[]
for visit in tube['visits']:
    box=queue.popleft();assert iv(visit['density'])==box
    lo,hi=iv(visit['derivative'])
    if visit['decision']=='positive':assert lo>0;positive.append(box)
    else:
        assert visit['decision']=='split' and lo<=0<hi
        mid=sum(box)/2;queue.extend([(mid,box[1]),(box[0],mid)])
leaves=list(map(iv,tube['leaves']))
assert not queue and not tube['pending'] and leaves==sorted(positive)
assert leaves[0][0]==liquid[0] and leaves[-1][1]==rho[1]
assert all(a[1]==b[0] for a,b in zip(leaves,leaves[1:]))
assert tube['proved'] and tube['evaluations_attempted']==tube['evaluations_completed']==len(tube['visits'])==31
assert tube['elapsed_seconds']<=tube['maximum_wall_seconds']<=15 and tube['maximum_boxes']==256
assert tube['source_before']==tube['source_after']==[a['source_sha256'],freeze['files'][str(R.parent/'interval_eos.py')]]
ambiguity=max(F(.01),F(2e-8)*iv(a['pressure'])[1])
assert F(r['ambiguity_upper_pa'])>=ambiguity
gap=iv(m['pressure'])[0]-iv(a['pressure'])[1]-F(r['ambiguity_upper_pa'])
assert 0<F(r['pressure_separation_lower_pa'])<=gap
assert not r['global_phase_admission'] and not r['native_error_admission']
assert r['inverse_energy_contract']=='conditional_on_original_manufactured_envelope_and_minimum_heat_capacity'
out={'status':'PASS','result_sha256':sha(R/'result02.json'),'old_failed_result_sha256':sha(R/'result01.json'),'full_original_T_and_inverse_unchanged':True,'exact_K_and_weighted_norm_enclosed':True,'positive_exact_cover_leaves':len(leaves),'tube_evaluations':31,'pressure_gap_lower':r['pressure_separation_lower_pa'],'whole_elapsed_seconds':r['elapsed_seconds'],'EOS_calls':0,'qualification':'Conditional local branch connection for one saved full inverse interval, no global/native-wide certificate'}
with (R/'review_passed_result02.json').open('x') as stream:stream.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
