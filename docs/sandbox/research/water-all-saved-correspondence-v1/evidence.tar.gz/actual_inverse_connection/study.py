"""Largest saved inverse interval: one preregistered local coexistence/tube box."""
from pathlib import Path
from decimal import Decimal as D,localcontext
from fractions import Fraction as F
from dataclasses import asdict
import hashlib,json,sys,time
ROOT=Path(__file__).parent;BASE=ROOT.parent
sys.path[:0]=[str(BASE),str(BASE/'coexistence_candidate'),str(BASE/'density_tube_candidate'),str(BASE/'coexistence_study')]
from interval_eos import I,Interval,residual
from coexistence import evaluate_box,enclose_coexistence
from density_tube import prove_density_tube
from coupled_rectangle import enclose_local_root
from study_weighted import sha
# The earlier numerical seed helpers are loaded explicitly to avoid this file's name.
import importlib.util
_spec=importlib.util.spec_from_file_location('original_coexistence_seed',BASE/'coexistence_study/study.py')
_helpers=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_helpers)

def read(p):return json.loads(p.read_bytes())
def iv(v):return Interval(D(v['lo']),D(v['hi']))

def main():
    begun=time.monotonic();freeze=read(ROOT/'FREEZE.json')
    paths={Path(p):h for p,h in freeze['files'].items()}
    result={'status':'started','freeze':freeze,'qualification':'conditional_local_mathematical_connection_over_saved_inverse_interval_not_global_or_native_admission','newton':[]}
    def guard():
        if time.monotonic()-begun>15:raise TimeoutError('whole_study_cooperative_15s_budget')
        if any(sha(p)!=h for p,h in paths.items()):raise ValueError('frozen_source_changed')
    try:
        guard();run=read(BASE/'saved-fine/run-result.json')
        ranked=[(F(o['inverse']['temperature_error_bound_k']),s,c) for s,obs in enumerate(run['observations'],1) for c,o in enumerate(obs['cells'])]
        eps,step,cell=max(ranked);assert (step,cell)==(8,1)
        inv=run['observations'][step-1]['cells'][cell]['inverse'];p=inv['point']
        exact_eps=(abs(F(p['total_internal_energy_j'])-F(inv['target_energy_j']))+F(p['energy_error_j']))/F(p['minimum_heat_capacity_j_k'])
        assert eps>=exact_eps and F(inv['target_energy_j'])==F(run['states'][step][cell]['internal_energy_j'])
        result.update(step=step,cell=cell,exact_epsilon_fraction=str(exact_eps),saved_epsilon_fraction=str(eps),inverse=inv)
        source=BASE/'heos-water.json';source_sha=freeze['files'][str(source)];raw=read(source)[0];e=raw['EOS'][0]
        saved=read(BASE/'saved-endpoint-result02.json')['records'][15]
        assert (saved['step'],saved['cell'])==(step,cell)
        with localcontext() as ctx:
            ctx.prec=60
            temp=I(p['fluid']['mechanical']['temperature_k']);error=I(inv['temperature_error_bound_k'])
            t=Interval((temp-error).lo,(temp+error).hi)
            assert t==iv(saved['inputs']['temperature'])
            lo,hi=map(D,inv['final_temperature_bracket_k']);assert lo<=t.lo<=t.hi<=hi
            result['temperature']=asdict(t)
            center=_helpers.seed(raw,float(temp.lo));result['auxiliary_seed']=center
            kw=dict(reducing_density=e['STATES']['reducing']['rhomolar'],reducing_temperature=e['STATES']['reducing']['T'],gas_constant=e['gas_constant'],jet=lambda d,tau:residual(d,tau,e['alphar']))
            for i in range(12):
                guard();v=evaluate_box(temp,tuple(I(x) for x in center),**kw);matrix=_helpers.inverse_matrix(v.jacobian)
                result['newton'].append({'center':center,'residual':asdict(v),'matrix':matrix})
                f=tuple(_helpers.midpoint(x) for x in v.residual)
                if max(abs(x) for x in f)<D('1e-30'):break
                center=tuple(center[j]-sum((matrix[j][k]*f[k] for k in range(2)),D(0)) for j in range(2))
            else:raise ValueError('seed_refinement_not_converged')
            weights=(D('1e-6'),D('1e-3'))
            box=tuple(Interval((I(x)-I(r)).lo,(I(x)+I(r)).hi) for x,r in zip(center,weights))
            guard();coex=enclose_coexistence(source,source_sha,t,box,center,matrix,precision=60,weights=weights)
            result['coexistence']=asdict(coex)
            if not coex.proved:raise ValueError('preregistered_single_coexistence_box_unresolved')
            args={k:iv(v) if isinstance(v,dict) else v for k,v in saved['inputs'].items()}
            guard();mechanical=enclose_local_root(source,source_sha,**args);result['mechanical']=asdict(mechanical);result['mechanical_inputs']=saved['inputs']
            liquid=iv(result['coexistence']['domain']['density'][0]);density=iv(saved['inputs']['liquid_molar_density'])
            assert liquid.hi<density.lo
            fullrho=Interval(liquid.lo,density.hi)
            guard();tube=prove_density_tube(source,source_sha,t,fullrho,precision=60,maximum_boxes=256,maximum_wall_seconds=max(.001,15-(time.monotonic()-begun)))
            result['tube']=asdict(tube)
            saturation=iv(result['coexistence']['pressure'])
            ambiguity=max(D(.01),(I(2e-8)*I(saturation.hi)).hi)
            gap=(I(mechanical.pressure.lo)-I(saturation.hi)-I(ambiguity)).lo
            result.update(ambiguity_upper_pa=ambiguity,pressure_separation_lower_pa=gap)
            guard();result['source_after']={str(p):sha(p) for p in paths}
            result['status']='proved_local_connection' if tube.proved and gap>0 else 'unresolved_connection'
            result['inverse_energy_contract']='conditional_on_original_manufactured_envelope_and_minimum_heat_capacity'
            result['global_phase_admission']=False;result['native_error_admission']=False
    except Exception as exc:result.update(status='failed',exception=type(exc).__name__,reason=str(exc))
    result['elapsed_seconds']=time.monotonic()-begun
    with (ROOT/'result01.json').open('x') as f:f.write(json.dumps(result,default=str,indent=2)+'\n')
    print(result['status'],result['elapsed_seconds'],result.get('reason'))
    if result['status']!='proved_local_connection':raise SystemExit(1)
if __name__=='__main__':main()
