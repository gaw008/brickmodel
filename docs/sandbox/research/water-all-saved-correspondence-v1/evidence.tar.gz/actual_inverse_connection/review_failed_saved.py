"""Exact saved Krawczyk failure audit; no numerical model imports."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
R=Path(__file__).parent
def iv(x):return F(x['lo']),F(x['hi'])
def point(x):return x,x
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
    values=[x*y for x in a for y in b];return min(values),max(values)
def isum(xs):
    out=point(F())
    for x in xs:out=add(out,x)
    return out
def encloses(saved,exact):
    lo,hi=iv(saved);assert lo<=exact[0]<=exact[1]<=hi
r=json.loads((R/'result01.json').read_bytes());a=r['coexistence'];k=a['krawczyk']
for path,expected in r['freeze']['files'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected,path
assert r['status']=='failed' and r['reason']=='preregistered_single_coexistence_box_unresolved'
assert 'mechanical' not in r and 'tube' not in r
assert 0<r['elapsed_seconds']<15
assert r['temperature']==a['domain']['temperature']==a['center']['temperature']
assert k['center']==r['newton'][-1]['center'] and k['preconditioner']==r['newton'][-1]['matrix']
assert k['jacobian']==a['domain']['jacobian'] and k['center_residual']==a['center']['residual']
X=list(map(iv,k['box']));c=list(map(F,k['center']));C=[list(map(F,row)) for row in k['preconditioner']]
J=[[iv(v) for v in row] for row in k['jacobian']];f=list(map(iv,k['center_residual']));w=list(map(F,k['weights']))
assert w==[F('1e-6'),F('.001')]
assert C[0][0]*C[1][1]-C[0][1]*C[1][0]!=0
for i in range(2):encloses(k['box'][i],(c[i]-w[i],c[i]+w[i]))
A=[[sub(point(F(int(i==j))),isum(mul(point(C[i][q]),J[q][j]) for q in range(2))) for j in range(2)] for i in range(2)]
image=[add(sub(point(c[i]),isum(mul(point(C[i][j]),f[j]) for j in range(2))),isum(mul(A[i][j],sub(X[j],point(c[j]))) for j in range(2))) for i in range(2)]
for saved,exact in zip(k['image'],image):encloses(saved,exact)
norm=max(sum(max(abs(lo),abs(hi))*w[j]/w[i] for j,(lo,hi) in enumerate(row)) for i,row in enumerate(A))
assert norm<=F(k['contraction_upper'])<1
strict=[]
for i in range(2):
    lo,hi=iv(k['image'][i]);margins=(lo-X[i][0],X[i][1]-hi)
    for saved,exact in zip(k['strict_margins'][i],margins):assert F(saved)<=exact
    strict.extend(margins)
assert strict[0]<0 and strict[1]<0 and not k['proved'] and not a['proved']
assert image[0][0]<X[0][0] and image[0][1]>X[0][1]
pressures=list(map(iv,a['domain']['pressure']))
assert iv(a['pressure'])==(max(p[0] for p in pressures),min(p[1] for p in pressures))
assert all(iv(v)[0]>0 for v in a['domain']['stability'])
out={'status':'PASS_CORRECT_FAILURE','result_sha256':hashlib.sha256((R/'result01.json').read_bytes()).hexdigest(),'elapsed_seconds':r['elapsed_seconds'],'contraction_upper':k['contraction_upper'],'liquid_strict_margins':k['strict_margins'][0],'exact_image_itself_exceeds_box':True,'EOS_calls':0,'next_box_scope':'4e-6/.001 is a new numerical candidate, not threshold relaxation; must recompute full-box proof'}
with (R/'review_failed_result01.json').open('x') as stream:stream.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
