"""Read-only preflight algebra; no model imports or EOS evaluation."""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json

ROOT = Path(__file__).parent
BASE = ROOT.parent
def read(p):
    return json.loads(p.read_bytes())
def bounds(value):
    return F(value['lo']), F(value['hi'])
def encloses(value, lo, hi):
    a,b = bounds(value)
    assert a <= lo <= hi <= b

freeze = read(ROOT/'FREEZE.json')
for path, expected in freeze['files'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
run = read(BASE/'saved-fine/run-result.json')
ranked = sorted((F(cell['inverse']['temperature_error_bound_k']),step,index)
    for step,obs in enumerate(run['observations'],1) for index,cell in enumerate(obs['cells']))
epsilon,step,cell = ranked[-1]
assert (step,cell) == (8,1) and ranked[-2][0] < epsilon
inv = run['observations'][step-1]['cells'][cell]['inverse']
point = inv['point']; state = run['states'][step][cell]
capacity = F(point['minimum_heat_capacity_j_k'])
assert capacity > 0 and F(point['energy_error_j']) >= 0
exact = (abs(F(point['total_internal_energy_j'])-F(inv['target_energy_j']))+F(point['energy_error_j']))/capacity
assert epsilon >= exact > 0
assert F(inv['target_energy_j']) == F(state['internal_energy_j'])
record = read(BASE/'saved-endpoint-result02.json')['records'][15]
assert (record['step'],record['cell']) == (step,cell)
a = record['inputs']; temp = F(point['fluid']['mechanical']['temperature_k'])
encloses(a['temperature'], temp-epsilon, temp+epsilon)
lo,hi = map(F,inv['final_temperature_bracket_k'])
assert lo <= bounds(a['temperature'])[0] <= bounds(a['temperature'])[1] <= hi
assert F(295) <= lo < hi <= F(310)
provider = read(BASE/'saved-fine/water-provider.json')
desc = json.loads(dict(provider['implementation'][2])['canonical_descriptor'])['real_fluid']
assert desc['runtime']['fluid_sha256'] == freeze['files'][str(BASE/'heos-water.json')]
scale = F(float.fromhex(desc['public_mass_hex']))/F(float.fromhex(desc['native_mass_hex']))
encloses(a['liquid_volume_scale'],scale,scale)
nl = F(state['liquid_water_mol']); ng = sum(map(F,state['gas_amounts_mol']))
encloses(a['liquid_mol'],nl,nl); encloses(a['gas_mol'],ng,ng)
seed = nl*scale/F(point['fluid']['mechanical']['liquid_volume_m3'])
encloses(a['liquid_molar_density'],seed-F('.2'),seed+F('.2'))
storage = read(BASE/'saved-fine/storage-inputs.json')
volume = F(storage['bulk_volume_m3'])-sum(F(m)*F(s['volume_m3_kg']) for m,s in zip(state['solid_mass_kg'],storage['solids'],strict=True))
err = F(storage['bulk_volume_error_m3'])+nl*F(storage['fluid_template']['envelope']['liquid_v_error_m3_mol'])
encloses(a['effective_available_volume'],volume-err,volume+err)
assert freeze['log_density_radii'] == ['1e-6','1e-3']
assert freeze['maximum_newton_iterations'] == 12 and freeze['maximum_tube_boxes'] == 256
assert freeze['whole_study_cooperative_seconds'] == 15 and freeze['single_T_box_no_subdivision']
out = {'status':'APPROVE_SINGLE_RUN','selected_step':step,'selected_cell':cell,'ranked_count':len(ranked),'saved_epsilon_fraction':str(epsilon),'exact_epsilon_fraction':str(exact),'temperature':a['temperature'],'public_native_scale':str(scale),'hashes_current_match':True,'eos_calls':0,'qualification':'Preflight only; convergence and connection not yet evaluated'}
with (ROOT/'review_preflight01.json').open('x') as stream:
    stream.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
