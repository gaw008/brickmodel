"""Read-only interval analysis of all saved fine endpoints; no native calls."""
from pathlib import Path
from dataclasses import asdict
from decimal import Decimal as D, localcontext
import hashlib
import json
import time
from coupled_rectangle import enclose_local_root
from interval_eos import Interval, I

ROOT=Path(__file__).parent
INPUT=ROOT/'saved-fine'


def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    start=time.monotonic()
    source=ROOT/'heos-water.json'
    run=read(INPUT/'run-result.json');storage=read(INPUT/'storage-inputs.json')
    provider=read(INPUT/'water-provider.json')
    descriptor=json.loads(dict(provider['implementation'][2])['canonical_descriptor'])['real_fluid']
    assert sha(source)==descriptor['runtime']['fluid_sha256']
    assert run['status']=='completed' and len(run['observations'])==8
    fixed={p.name:sha(p) for p in INPUT.iterdir() if p.is_file()}
    records=[];failure=None
    for index,(states,observation) in enumerate(zip(run['states'][1:],run['observations'],strict=True),1):
        for cell,(state,obs) in enumerate(zip(states,observation['cells'],strict=True)):
            entry={'step':index,'cell':cell};records.append(entry)
            try:
                if time.monotonic()-start>10:raise TimeoutError('ten_second_saved_study_budget')
                inverse=obs['inverse'];point=inverse['point'];mechanical=point['fluid']['mechanical']
                with localcontext() as ctx:
                    ctx.prec=60
                    scale=I(float.fromhex(descriptor['public_mass_hex']))/I(float.fromhex(descriptor['native_mass_hex']))
                    temperature=I(mechanical['temperature_k']);eps=I(inverse['temperature_error_bound_k'])
                    trange=Interval((temperature-eps).lo,(temperature+eps).hi)
                    assert D(storage['temperature_domain_k'][0])<=trange.lo<=trange.hi<=D(storage['temperature_domain_k'][1])
                    nl=I(state['liquid_water_mol'])
                    native_seed=nl*scale/I(mechanical['liquid_volume_m3'])
                    density=Interval((native_seed-I(D('.2'))).lo,(native_seed+I(D('.2'))).hi)
                    available=I(storage['bulk_volume_m3'])
                    for mass,solid in zip(state['solid_mass_kg'],storage['solids'],strict=True):
                        available=available-I(mass)*I(solid['volume_m3_kg'])
                    volume_error=I(storage['bulk_volume_error_m3'])+nl*I(storage['fluid_template']['envelope']['liquid_v_error_m3_mol'])
                    effective=Interval((available-volume_error).lo,(available+volume_error).hi)
                    kwargs=dict(temperature=trange,liquid_molar_density=density,effective_available_volume=effective,
                        liquid_mol=nl,gas_mol=sum((I(x) for x in state['gas_amounts_mol']),I(0)),
                        gas_constant=I(mechanical['gas_constant_j_mol_k']),liquid_volume_scale=scale,precision=60)
                    entry['inputs']={k:asdict(v) if type(v) is Interval else v for k,v in kwargs.items()}
                    out=enclose_local_root(source,sha(source),**kwargs)
                    nominal=D(point['fluid']['mechanical']['pressure_pa'])
                    entry['rectangle']=asdict(out)
                    entry['nominal_pressure_inside']=out.pressure.lo<=nominal<=out.pressure.hi
                    entry['original_fixed_temperature_pressure_error_pa']=D(point['pressure_error_pa'])
                    # Conservative sum, no shared-error subtraction.
                    radius=max(abs(nominal-out.pressure.lo),abs(nominal-out.pressure.hi))+D(point['pressure_error_pa'])
                    entry['combined_pressure_radius_pa']=radius
                    assert entry['nominal_pressure_inside']
                    entry['status']='passed_local_rectangle'
            except Exception as exc:
                entry['status']='failed';entry['exception']=type(exc).__name__;entry['reason']=str(exc)
                failure=entry['reason'];break
        if failure:break
    assert fixed=={p.name:sha(p) for p in INPUT.iterdir() if p.is_file()}
    result={'status':'failed' if failure else 'completed','failure':failure,'records':records,
        'input_sha256':fixed,'source_sha256':sha(source),'script_sha256':sha(Path(__file__)),
        'implementation_sha256':{n:sha(ROOT/n) for n in ('interval_eos.py','coupled_rectangle.py')},
        'elapsed_seconds':time.monotonic()-start,'budget_seconds':10,
        'qualification':'Saved 16 endpoints; local mathematical roots conditional on original manufactured liquid-volume envelope. Not stable-phase admission, native rounding certification, fresh native trajectory, or material uncertainty.'}
    (ROOT/'saved-endpoint-result01.json').write_text(json.dumps(result,default=str,indent=2)+'\n')
    print(result['status'],len(records),result['elapsed_seconds'],failure)
    if failure:raise SystemExit(1)


if __name__=='__main__':main()
