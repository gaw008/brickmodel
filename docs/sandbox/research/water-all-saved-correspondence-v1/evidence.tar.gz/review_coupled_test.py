"""Independent analytic root checks; no water EOS or native calls."""
from decimal import Decimal as D
from fractions import Fraction as F
from unittest.mock import patch
import unittest
from coupled_rectangle import enclose_local_root, Interval, I


def parameters():
    return dict(temperature=Interval(D(1),D('1.1')),
                liquid_molar_density=Interval(D('.8'),D(2)),
                effective_available_volume=Interval(D(2),D('2.1')),
                liquid_mol=1,gas_mol=1,gas_constant=1,liquid_volume_scale=1)


def analytic_pressure(source, digest, temperature, density, *, precision):
    # Artificial p_liquid=rho, with exact derivative one.
    if temperature.lo<=0 or density.lo<=0:
        raise ValueError('positive_T_rho_required')
    return density,I(1)


class CoupledReview(unittest.TestCase):
    def call(self, **changes):
        args=parameters();args.update(changes)
        return enclose_local_root('synthetic-not-a-file','synthetic',**args)

    @patch('coupled_rectangle.pressure_interval',analytic_pressure)
    def test_exact_analytic_root_at_parameter_corners(self):
        result=self.call()
        self.assertLess(result.lower_residual.hi,0)
        self.assertGreater(result.upper_residual.lo,0)
        for temperature in (F(1),F(11,10)):
            for volume in (F(2),F(21,10)):
                # rho = (T+Nl)/V for this separately derived artificial EOS.
                rho=(temperature+1)/volume
                self.assertLessEqual(F(result.liquid_molar_density.lo),rho)
                self.assertGreaterEqual(F(result.liquid_molar_density.hi),rho)
                self.assertLessEqual(F(result.pressure.lo),rho)
                self.assertGreaterEqual(F(result.pressure.hi),rho)
                derivative=1+temperature/(rho*rho*(volume-1/rho)**2)
                self.assertLessEqual(F(result.total_residual_derivative.lo),derivative)
                self.assertGreaterEqual(F(result.total_residual_derivative.hi),derivative)

    @patch('coupled_rectangle.pressure_interval',analytic_pressure)
    def test_face_sign_and_positive_volume_rejections(self):
        with self.assertRaisesRegex(ValueError,'uniform_root_face'):
            self.call(liquid_molar_density=Interval(D(3),D(4)))
        with self.assertRaisesRegex(ValueError,'gas_volume_not_positive'):
            self.call(effective_available_volume=Interval(D('.1'),D('.2')))
        with self.assertRaisesRegex(ValueError,'nonzero_density'):
            self.call(liquid_molar_density=I(1))

    @patch('coupled_rectangle.pressure_interval',analytic_pressure)
    def test_strict_input_admission(self):
        for field in ('liquid_mol','gas_mol','gas_constant','liquid_volume_scale'):
            for value in (0,-1,True):
                with self.assertRaises((ValueError,TypeError)):
                    self.call(**{field:value})
        with self.assertRaises(TypeError):
            self.call(temperature=1)
        with self.assertRaises(ValueError):
            self.call(temperature=Interval(D(-1),D(1)))
        with self.assertRaises(ValueError):
            self.call(precision=True)

    def test_unresolved_density_derivative_never_certifies(self):
        def ambiguous(source,digest,temperature,density,*,precision):
            return density,Interval(D(-1),D(1))
        with patch('coupled_rectangle.pressure_interval',ambiguous):
            with self.assertRaisesRegex(ValueError,'positive_compliance'):
                self.call()

    @patch('coupled_rectangle.pressure_interval',analytic_pressure)
    def test_uncertain_nonunit_mass_scale_encloses_each_true_root(self):
        result=self.call(liquid_volume_scale=Interval(D('.5'),D('.6')),
                         liquid_molar_density=Interval(D('.6'),D('1.5')))
        for t in (F(1),F(11,10)):
            for volume in (F(2),F(21,10)):
                for scale in (F(1,2),F(3,5)):
                    rho=(t+scale)/volume
                    derivative=1+t*scale/(rho*rho*(volume-scale/rho)**2)
                    self.assertLessEqual(F(result.pressure.lo),rho)
                    self.assertGreaterEqual(F(result.pressure.hi),rho)
                    self.assertLessEqual(F(result.total_residual_derivative.lo),derivative)
                    self.assertGreaterEqual(F(result.total_residual_derivative.hi),derivative)


if __name__=='__main__':
    unittest.main()
