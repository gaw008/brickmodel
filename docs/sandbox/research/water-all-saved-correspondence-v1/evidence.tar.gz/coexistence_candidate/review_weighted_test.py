"""Independent weighted-norm algebra probes; no EOS evaluation."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from dataclasses import asdict
from pathlib import Path
import importlib.util,sys
import pytest
from coexistence import I,Interval,krawczyk


def arguments(jac):
    return ((Interval(D(-10),D(10)),Interval(D(-1),D(1))),
            (D(0),D(0)),((D(1),D(0)),(D(0),D(1))), (I(0),I(0)),jac)


def test_default_none_preserves_every_old_evidence_field():
    name='independent_old_coexistence'
    spec=importlib.util.spec_from_file_location(name,Path(__file__).parent/'before-weighted-norm/coexistence.py')
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    try:
        spec.loader.exec_module(module)
        args=arguments(((I(1),I(-2)),(I(D('-.1')),I(1))))
        old=asdict(module.krawczyk(*args));new=asdict(krawczyk(*args))
        for key in ('weights','unweighted_contraction_upper','norm_name'):new.pop(key)
        assert new==old
    finally:
        sys.modules.pop(name,None)


@pytest.mark.parametrize('ratio',['.01','.1','.5','1','2','10','100'])
def test_signed_unit_spectral_radius_cannot_pass_any_positive_scaling(ratio):
    # Defect A=[[0,-2],[.5,0]], with complex eigenvalues +/-i.
    jac=((I(1),I(2)),(I(D('-.5')),I(1)))
    with localcontext() as context:
        context.prec=8
        result=krawczyk(*arguments(jac),weights=(D(ratio),D(1)))
    exact=max(F(2)/F(D(ratio)),F(1,2)*F(D(ratio)))
    assert F(result.contraction_upper)>=exact>=1
    assert not result.proved


def test_weighting_changes_only_norm_and_not_krawczyk_geometry():
    args=arguments(((I(1),I(-2)),(I(D('-.1')),I(1))))
    plain=krawczyk(*args)
    weighted=krawczyk(*args,weights=(D(3),D(1)))
    assert plain.image==weighted.image and plain.strict_margins==weighted.strict_margins
    assert weighted.unweighted_contraction_upper==plain.contraction_upper
    exact=max(F(2,3),F(3,10))
    assert F(weighted.contraction_upper)>=exact
    assert weighted.contraction_upper<1
