"""Independent pure parametric Krawczyk probes; no water wrapper calls."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import pytest
from coexistence import Interval, I, krawczyk


def test_nonlinear_parameter_curve_is_enclosed_for_entire_parameter_interval():
    # F(x,y;t)=(x*x-t,y-2*t), t in [.99,1.01].
    box=(Interval(D('.9'),D('1.1')),Interval(D('1.9'),D('2.1')))
    center=(D(1),D(2));matrix=((D('.5'),D(0)),(D(0),D(1)))
    f=(Interval(D('-.01'),D('.01')),Interval(D('-.02'),D('.02')))
    jac=((Interval(D('1.8'),D('2.2')),I(0)),(I(0),I(1)))
    result=krawczyk(box,center,matrix,f,jac)
    assert result.proved and result.contraction_upper < 1
    for t in (D('.99'),D(1),D('1.01')):
        with localcontext() as context:
            context.prec=100
            roots=(t.sqrt(),2*t)
        for image,value in zip(result.image,roots):
            assert F(image.lo)<=F(value)<=F(image.hi)


def test_parameter_uncertainty_cannot_be_replaced_by_center_residual_zero():
    box=(Interval(D('-1'),D(1)),)*2
    center=(D(0),D(0));matrix=((D(1),D(0)),(D(0),D(1)))
    jac=((I(1),I(0)),(I(0),I(1)))
    # F(x,y;t)=(x-t,y), t in [-2,2], no single box contains all roots.
    result=krawczyk(box,center,matrix,(Interval(D(-2),D(2)),I(0)),jac)
    assert not result.proved
    assert result.contraction_upper==0
    assert result.strict_margins[0][0]<0 and result.strict_margins[0][1]<0


def test_exact_singular_and_boundary_center_refuse():
    box=(Interval(D(-1),D(1)),)*2
    jac=((I(1),I(0)),(I(0),I(1)))
    # Long-decimal exactly dependent rows must not be made invertible by float.
    a=D('1.123456789012345678901234567890123456789')
    with pytest.raises(ValueError,match='nonsingular'):
        krawczyk(box,(D(0),D(0)),((a,D(1)),(a,D(1))),(I(0),I(0)),jac)
    with pytest.raises(ValueError,match='strict_point_center'):
        krawczyk(box,(D(1),D(0)),((D(1),D(0)),(D(0),D(1))),(I(0),I(0)),jac)
