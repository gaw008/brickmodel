"""Saved-data exact arithmetic audit only; never recomputes a water root."""
from pathlib import Path
from decimal import Decimal as D
from fractions import Fraction as F
import hashlib,json
ROOT=Path(__file__).parent
INPUT=ROOT/'saved-fine'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bounds(row):return F(D(row['lo'])),F(D(row['hi']))
def contains(row,low,high=None):
 a,b=bounds(row);assert a<=low<=(low if high is None else high)<=b
result=read(ROOT/'saved-endpoint-result02.json')
run=read(INPUT/'run-result.json');storage=read(INPUT/'storage-inputs.json');provider=read(INPUT/'water-provider.json')
desc=json.loads(dict(provider['implementation'][2])['canonical_descriptor'])['real_fluid']
assert result['status']=='completed' and result['failure'] is None
assert 0<=result['elapsed_seconds']<=result['budget_seconds']==10
assert result['input_sha256']=={p.name:sha(p) for p in INPUT.iterdir() if p.is_file()}
assert result['source_sha256']==sha(ROOT/'heos-water.json')==desc['runtime']['fluid_sha256']
assert result['implementation_sha256']=={n:sha(ROOT/n) for n in result['implementation_sha256']}
assert result['script_sha256']==sha(ROOT/'saved_endpoint_study.py')
assert {(r['step'],r['cell']) for r in result['records']}=={(step,cell) for step in range(1,9) for cell in range(2)}
assert len(result['records'])==16
scale=F(float.fromhex(desc['public_mass_hex']))/F(float.fromhex(desc['native_mass_hex']))
assert scale!=1
rows=[]
for record in result['records']:
 step,cell=record['step'],record['cell'];state=run['states'][step][cell]
 inv=run['observations'][step-1]['cells'][cell]['inverse'];point=inv['point'];mech=point['fluid']['mechanical'];i=record['inputs']
 assert record['status']=='passed_local_rectangle'
 t,e=F(mech['temperature_k']),F(inv['temperature_error_bound_k'])
 contains(i['temperature'],t-e,t+e)
 nl=F(state['liquid_water_mol']);contains(i['liquid_mol'],nl);contains(i['liquid_volume_scale'],scale)
 contains(i['gas_mol'],sum(map(F,state['gas_amounts_mol']),F()))
 contains(i['gas_constant'],F(mech['gas_constant_j_mol_k']))
 seed=nl*scale/F(mech['liquid_volume_m3']);contains(i['liquid_molar_density'],seed-F(1,5),seed+F(1,5))
 available=F(storage['bulk_volume_m3'])-sum((F(m)*F(s['volume_m3_kg']) for m,s in zip(state['solid_mass_kg'],storage['solids'],strict=True)),F())
 error=F(storage['bulk_volume_error_m3'])+nl*F(storage['fluid_template']['envelope']['liquid_v_error_m3_mol'])
 contains(i['effective_available_volume'],available-error,available+error)
 rectangle=record['rectangle'];assert bounds(rectangle['lower_residual'])[1]<0<bounds(rectangle['upper_residual'])[0]
 assert bounds(rectangle['liquid_pressure_derivative'])[0]>0 and bounds(rectangle['total_residual_derivative'])[0]>0
 lo,hi=bounds(rectangle['pressure']);p=F(mech['pressure_pa']);assert lo<=p<=hi
 fixed=F(D(record['original_fixed_temperature_pressure_error_pa']));assert fixed==F(point['pressure_error_pa'])
 exact=max(abs(p-lo),abs(p-hi))+fixed;saved=F(D(record['combined_pressure_radius_pa']));assert saved>=exact
 rows.append({'step':step,'cell':cell,'radius_not_understated':True,'radius_surplus':str(saved-exact)})
out={'status':'passed','records':rows,'result_sha256':sha(ROOT/'saved-endpoint-result02.json'),'script_sha256':sha(Path(__file__)),'native_EOS_calls':0,'mathematical_root_recomputations':0}
(ROOT/'review-saved-scale02.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',len(rows),'exact input/scale/radius/hash checks')
