"""Independent Fraction audit of saved native-output mathematics, no EOS."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
R=Path(__file__).parent;B=R.parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def iv(v):return F(v['lo']),F(v['hi'])
def encloses(v,lo,hi):
    a,b=iv(v);assert a<=lo<=hi<=b
r=read(R/'attempt02/result.json');report=read(R/'attempt02/report.json');inputs=read(R/'attempt02/inputs.json')
freeze=read(R/'FREEZE.json');expected=freeze['sha256']
assert expected==report['runtime_after']=={p:sha(Path(p)) for p in expected}
assert report['inputs_unchanged'] and report['status']=='passed_saved_output_math_only'
assert r['source_before']==r['source_after']==list(expected.values())
q=r['query'];t,p,rhom,mp,mn,nl,vhost,decl=map(F,q)
run=read(B/'saved-fine/run-result.json');state=run['states'][8][1];cell=run['observations'][7]['cells'][1]
inv=cell['inverse'];mech=inv['point']['fluid']['mechanical'];water=cell['equilibrium']['liquid']['state'];storage=read(B/'saved-fine/storage-inputs.json')
assert inputs['query']==q==[water['temperature_k'],water['pressure_pa'],water['density_kg_m3'],inputs['descriptor']['public_mass_hex'] and float.fromhex(inputs['descriptor']['public_mass_hex']),float.fromhex(inputs['descriptor']['native_mass_hex']),state['liquid_water_mol'],mech['liquid_volume_m3'],storage['fluid_template']['envelope']['liquid_v_error_m3_mol']]
assert dict(zip(('O2','N2','H2O'),state['gas_amounts_mol'],strict=True))==mech['gas_inventory_mol']
assert inv['target_energy_j']==state['internal_energy_j'] and water['temperature_k']==mech['temperature_k'] and water['pressure_pa']==mech['liquid_pressure_pa']
host=read(R/'HOST_EXPRESSION.json');assert sha(Path(host['path']))==host['sha256']
assert Path(host['path']).read_text().splitlines()[127:133]==host['lines_128_133']
assert q[6]==(q[5]*q[3])/q[2]
m=r['metrics'];rn=rhom/mn;scale=mp/mn
encloses(m['native_density'],rn,rn);encloses(m['volume_scale'],scale,scale)
box=iv(r['density_box']);assert box[0]<=rn-F('.2')<rn+F('.2')<=box[1]
assert r['attempted']==r['completed']==len(r['visits'])==4 and not r['pending']
assert len(r['accepted_leaves'])==1 and r['accepted_leaves'][0][0]==r['density_box']
assert r['visits'][3]['density']==r['density_box'] and r['accepted_leaves'][0][1]==r['visits'][3]['derivative']
for j,key in enumerate(('lower_residual','upper_residual','observed_residual')):
    lo,hi=iv(r['visits'][j]['pressure']);encloses(m[key],lo-p,hi-p)
assert iv(m['lower_residual'])[1]<0<iv(m['upper_residual'])[0]
slope=F(m['minimum_slope']);assert slope==iv(r['visits'][3]['derivative'])[0]>0
residual=max(map(abs,iv(m['observed_residual'])))
assert F(m['density_error_bound'])>=residual/slope
assert F(m['native_volume_error_bound'])>=scale*F(m['density_error_bound'])/(box[0]*rn)
roundoff=vhost-nl*mp/rhom
assert F(m['host_volume_roundoff_exact'])==roundoff
encloses(m['host_per_mol_roundoff'],roundoff/nl,roundoff/nl)
assert F(m['combined_volume_error_bound'])>=F(m['native_volume_error_bound'])+max(map(abs,iv(m['host_per_mol_roundoff'])))
assert F(m['combined_volume_error_bound'])<=decl and iv(m['original_declaration'])==(decl,decl)
assert r['elapsed_seconds']<=r['maximum_wall_seconds']<=15 and report['elapsed_seconds']<15
assert r['status']=='passed_observed_query'
old=read(R/'attempt01/report.json');assert old['status']=='failed' and not (R/'attempt01/result.json').exists()
out={'status':'PASS','result_sha256':sha(R/'attempt02/result.json'),'original_attempt_failed':True,'fixed_query_source_matches':True,'exact_fraction_bounds_pass':True,'combined_bound':m['combined_volume_error_bound'],'original_declaration':q[-1],'evaluations':4,'whole_elapsed_seconds':report['elapsed_seconds'],'EOS_calls':0}
with (R/'review_saved01.json').open('x') as stream:stream.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
