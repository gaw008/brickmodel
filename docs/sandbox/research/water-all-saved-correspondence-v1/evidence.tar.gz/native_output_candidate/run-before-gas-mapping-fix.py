"""One preselected saved query; mathematical EOS only, never native flash."""
from pathlib import Path
from decimal import Decimal as D,localcontext
from dataclasses import asdict,is_dataclass
import sys,json,hashlib,time,traceback
BASE=Path(__file__).resolve().parent.parent;HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from interval_eos import I,Interval,pressure_interval
from native_output import analyze

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def encode(v):
    if is_dataclass(v):return {k:encode(x) for k,x in asdict(v).items()}
    if isinstance(v,D):return str(v)
    if isinstance(v,dict):return {k:encode(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [encode(x) for x in v]
    return v


def main():
    outdir=HERE/'attempt01';outdir.mkdir(exist_ok=False)
    freeze=load(HERE/'FREEZE.json');paths=[Path(p) for p in freeze['sha256']]
    frozen=freeze['sha256'];begun=time.monotonic();report={'status':'started','freeze':freeze,'selection':{'step':8,'cell':1}};result=None
    try:
        assert all(sha(p)==frozen[str(p)] for p in paths)
        r=load(BASE/'saved-fine/run-result.json');provider=load(BASE/'saved-fine/water-provider.json');storage=load(BASE/'saved-fine/storage-inputs.json')
        state=r['states'][8][1];c=r['observations'][7]['cells'][1];inv=c['inverse'];m=inv['point']['fluid']['mechanical'];w=c['equilibrium']['liquid']['state']
        implementation=dict(provider['implementation'][2]);assert w['implementation']==implementation
        descriptor=json.loads(implementation['canonical_descriptor'])['real_fluid']
        reference={k:float.fromhex(v[1]) if isinstance(v,list) and v and v[0]=='float' else v for k,v in provider['source'][1][2]}
        assert w['reference']==reference
        assert provider['concrete_type']==['sludge_sandbox.water_heos','HEOSWaterProperties']
        assert w['phase']=='liquid' and w['temperature_k']==m['temperature_k'] and w['pressure_pa']==m['liquid_pressure_pa']
        assert state['liquid_water_mol']==m['liquid_inventory_mol'] and sum(state['gas_amounts_mol'])==m['gas_inventory_mol']
        assert state['internal_energy_j']==inv['target_energy_j']
        source=BASE/'heos-water.json';source_sha=sha(source);assert source_sha==descriptor['runtime']['fluid_sha256']
        assert sha(BASE/'interval_eos.py')=='28bcfac0829a4d7cf55a58a71a5ddf9383687872808525841f3f1395a90cedc0'
        mp=float.fromhex(descriptor['public_mass_hex']);mn=float.fromhex(descriptor['native_mass_hex'])
        assert mp==w['reference']['molar_mass_kg_mol']
        eos=load(source)[0]['EOS'][0];assert mn==eos['molar_mass'] and w['reference']['native_molar_gas_constant_j_mol_k']==eos['gas_constant']
        q=(w['temperature_k'],w['pressure_pa'],w['density_kg_m3'],mp,mn,state['liquid_water_mol'],m['liquid_volume_m3'],storage['fluid_template']['envelope']['liquid_v_error_m3_mol'])
        with localcontext() as ctx:
            ctx.prec=60
            rn=I(q[2])/I(mn);box=Interval((rn-I(D('.2'))).lo,(rn+I(D('.2'))).hi)
            assert D(0)<D(q[0])<D(eos['STATES']['reducing']['T']) and box.lo>D(eos['STATES']['reducing']['rhomolar'])
        inputs=dict(query=q,density_box=box,saved_state=state,inverse=inv,native_liquid=w,descriptor=descriptor)
        (outdir/'inputs.json').write_text(json.dumps(encode(inputs),indent=2)+'\n')
        binding=lambda:tuple(sha(p) for p in paths)
        def pressure(t,r):return pressure_interval(source,source_sha,t,r,precision=60)
        remaining=15.-(time.monotonic()-begun)
        assert remaining>0
        result=analyze(q,box,pressure=pressure,binding=binding,maximum_boxes=256,maximum_wall_seconds=remaining)
        (outdir/'result.json').write_text(json.dumps(encode(result),indent=2)+'\n')
        assert result['status']=='passed_observed_query',result['reason']
        report['status']='passed_saved_output_math_only'
    except Exception as exc:report.update(status='failed',error=repr(exc),traceback=traceback.format_exc())
    finally:
        report['runtime_after']={str(p):sha(p) for p in paths};report['inputs_unchanged']=report['runtime_after']==frozen
        report['elapsed_seconds']=time.monotonic()-begun
        if not report['inputs_unchanged'] or report['elapsed_seconds']>15:report['status']='failed'
        report['qualification']='observed step8/cell1 fixed-query mathematical discrepancy only; no native execution, full inverse T, phase/material admission'
        (outdir/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['status']=='passed_saved_output_math_only' else 1
if __name__=='__main__':raise SystemExit(main())
