"""Independent synthetic tests; no EOS invocation."""
from decimal import Decimal as D
from fractions import Fraction as F
import pytest
from interval_eos import I,Interval
from native_output import analyze

@pytest.mark.parametrize('rho',[9.99999,10.00001])
def test_nonunit_public_native_scale_both_residual_signs(rho):
    mp,mn,nl=.021,.02,.03
    rhom=rho*mn
    q=(300.,20.,rhom,mp,mn,nl,(nl*mp)/rhom,1e-5)
    r=analyze(q,Interval(D(9),D(11)),pressure=lambda t,r:(2*r,I(2)),binding=lambda:('independent-linear',))
    assert r['status']=='passed_observed_query'
    root_public_volume=F(mp)/F(mn)/10
    exact_native_volume=F(mp)/F(rhom)
    assert abs(exact_native_volume-root_public_volume)<=F(r['metrics']['native_volume_error_bound'])
    assert abs(F(q[6])/F(nl)-root_public_volume)<=F(r['metrics']['combined_volume_error_bound'])
    assert F(r['metrics']['host_volume_roundoff_exact'])==F(q[6])-F(nl)*exact_native_volume

def test_mutable_binding_never_admitted():
    q=(300.,20.,.2,.02,.02,.03,.003,1e-5)
    with pytest.raises(ValueError,match='immutable_binding'):
        analyze(q,Interval(D(9),D(11)),pressure=lambda t,r:(2*r,I(2)),binding=lambda:['mutable'])
