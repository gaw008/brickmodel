"""Independent saved-field and Fraction preflight; no EOS imports."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,ast
R=Path(__file__).parent;B=R.parent;P=Path('/private/tmp/brick-mass-wet-transport-native-v1/fine')
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def iv(v):return F(v['lo']),F(v['hi'])
def enclosed(v,lo,hi):
    a,b=iv(v);assert a<=lo<=hi<=b
freeze=read(R/'FREEZE.json');assert all(sha(Path(p))==h for p,h in freeze['files'].items())
ast.parse((R/'run.py').read_text())
run=read(B/'saved-fine/run-result.json');pair=read(P/'pair-inputs.json');provider=read(B/'saved-fine/water-provider.json');prior=read(B/'saved-endpoint-result02.json')['records']
assert sha(P/'run-result.json')==sha(B/'saved-fine/run-result.json')
assert run['status']=='completed' and len(run['states'])==9 and len(run['observations'])==8 and len(prior)==16
implementation=dict(provider['implementation'][2]);desc=json.loads(implementation['canonical_descriptor'])['real_fluid']
reference={k:float.fromhex(v[1]) if isinstance(v,list) and v and v[0]=='float' else v for k,v in provider['source'][1][2]}
mp=F(float.fromhex(desc['public_mass_hex']));mn=F(float.fromhex(desc['native_mass_hex']));scale=mp/mn
assert desc['runtime']['fluid_sha256']==sha(B/'heos-water.json')
checked=[]
for step in range(1,9):
    assert len(run['observations'][step-1]['cells'])==2 and len(run['states'][step])==2
    for cell in range(2):
        state=run['states'][step][cell];obs=run['observations'][step-1]['cells'][cell];inv=obs['inverse'];point=inv['point'];m=point['fluid']['mechanical'];w=obs['equilibrium']['liquid']['state'];s=pair['storages'][cell];ip=pair['inverse_policies'][cell]
        assert state['energy_model_identity']==s['_identity']==point['model_identity']
        assert s['fluid_template']['mechanical']['water']==provider
        assert w['implementation']==implementation and w['reference']==reference and w['phase']=='liquid'
        assert w['temperature_k']==m['temperature_k'] and w['pressure_pa']==m['liquid_pressure_pa']
        assert state['liquid_water_mol']==m['liquid_inventory_mol']
        assert dict(zip(('O2','N2','H2O'),state['gas_amounts_mol'],strict=True))==m['gas_inventory_mol']
        assert inv['target_energy_j']==state['internal_energy_j']
        E=abs(F(point['total_internal_energy_j'])-F(inv['target_energy_j']))+F(point['energy_error_j']);cp=F(point['minimum_heat_capacity_j_k']);eps=F(inv['temperature_error_bound_k'])
        assert cp>0 and F(point['energy_error_j'])>=0 and E/cp<=eps<=F(ip['temperature_tolerance_k']) and E<=F(ip['energy_tolerance_j'])
        a=prior[(step-1)*2+cell];assert (a['step'],a['cell'])==(step,cell);a=a['inputs']
        T=F(m['temperature_k']);enclosed(a['temperature'],T-eps,T+eps)
        blo,bhi=map(F,inv['final_temperature_bracket_k']);tlo,thi=iv(a['temperature'])
        assert blo<=tlo<=thi<=bhi and F(s['temperature_domain_k'][0])<=tlo<=thi<=F(s['temperature_domain_k'][1])
        nl=F(state['liquid_water_mol']);ng=sum(map(F,state['gas_amounts_mol']))
        enclosed(a['liquid_mol'],nl,nl);enclosed(a['gas_mol'],ng,ng);enclosed(a['liquid_volume_scale'],scale,scale)
        rho=nl*scale/F(m['liquid_volume_m3']);enclosed(a['liquid_molar_density'],rho-F('.2'),rho+F('.2'))
        volume=F(s['bulk_volume_m3'])-sum(F(mass)*F(solid['volume_m3_kg']) for mass,solid in zip(state['solid_mass_kg'],s['solids'],strict=True))
        err=F(s['bulk_volume_error_m3'])+nl*F(s['fluid_template']['envelope']['liquid_v_error_m3_mol']);enclosed(a['effective_available_volume'],volume-err,volume+err)
        assert m['liquid_volume_m3']==(state['liquid_water_mol']*float(mp))/w['density_kg_m3']
        checked.append([step,cell])
assert checked==freeze['sequence'] and len(checked)==16
assert freeze['whole_wall_seconds']==60 and freeze['external_watchdog_seconds']==70 and freeze['coex_log_radii']==['4e-6','1e-3']
out={'status':'APPROVE_ONE_BOUNDED_RUN','source_sha256':sha(R/'run.py'),'all_saved_associations_verified':checked,'all_original_inverse_policies_pass':True,'exact_fraction_input_enclosures_pass':True,'frozen_sources_match':True,'EOS_calls':0,'scope':'Preflight only; actual proof outcomes not predicted'}
with (R/'review_preflight01.json').open('x') as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
