"""Fixed 16 saved endpoints; no native calls, no trajectory or phase admission."""
from pathlib import Path
from decimal import Decimal as D,localcontext
from fractions import Fraction as F
from dataclasses import asdict,is_dataclass
import hashlib,json,sys,time,os,traceback,importlib.util
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
sys.path[:0]=[str(BASE),str(BASE/'coexistence_candidate'),str(BASE/'density_tube_candidate'),str(BASE/'native_output_candidate')]
from interval_eos import I,Interval,residual,pressure_interval
from coexistence import evaluate_box,enclose_coexistence
from density_tube import prove_density_tube
from coupled_rectangle import enclose_local_root
from native_output import analyze
spec=importlib.util.spec_from_file_location('frozen_seed_helpers',BASE/'coexistence_study/study.py')
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
PARENT=Path('/private/tmp/brick-mass-wet-transport-native-v1/fine')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def encode(v):
    if is_dataclass(v):return encode(asdict(v))
    if isinstance(v,D):return str(v)
    if isinstance(v,dict):return {k:encode(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [encode(x) for x in v]
    return v

def save(path,value):
    temporary=path.with_suffix('.partial');temporary.write_text(json.dumps(encode(value),indent=2)+'\n');os.replace(temporary,path)

def iv(v):return Interval(D(v['lo']),D(v['hi']))


def main():
    output=HERE/'attempt01';output.mkdir(exist_ok=False)
    frozen=read(HERE/'FREEZE.json');paths={Path(k):v for k,v in frozen['files'].items()};begun=time.monotonic()
    summary={'status':'started','freeze':frozen,'records':[],'qualification':'independent_saved_endpoint_certificates_only; original_material_and_minimum_Cp_conditional; no_time_continuity_global_phase_native_universal_or_stage_admission'}
    def guard():
        if time.monotonic()-begun>=60:raise TimeoutError('whole_study_60s')
        if any(sha(p)!=v for p,v in paths.items()):raise ValueError('frozen_inputs_changed')
    def remaining():guard();return 60.-(time.monotonic()-begun)
    current=None
    try:
        guard();run=read(BASE/'saved-fine/run-result.json');pair=read(PARENT/'pair-inputs.json');provider=read(BASE/'saved-fine/water-provider.json')
        assert sha(PARENT/'run-result.json')==sha(BASE/'saved-fine/run-result.json')
        assert run['status']=='completed' and len(run['observations'])==8 and len(run['states'])==9
        implementation=dict(provider['implementation'][2]);descriptor=json.loads(implementation['canonical_descriptor'])['real_fluid']
        reference={k:float.fromhex(v[1]) if isinstance(v,list) and v and v[0]=='float' else v for k,v in provider['source'][1][2]}
        source=BASE/'heos-water.json';source_sha=sha(source);assert source_sha==descriptor['runtime']['fluid_sha256']
        assert provider['concrete_type']==['sludge_sandbox.water_heos','HEOSWaterProperties']
        data=read(source)[0];e=data['EOS'][0];mp=float.fromhex(descriptor['public_mass_hex']);mn=float.fromhex(descriptor['native_mass_hex'])
        assert mn==e['molar_mass'] and mp==reference['molar_mass_kg_mol'] and reference['native_molar_gas_constant_j_mol_k']==e['gas_constant']
        prior=read(BASE/'saved-endpoint-result02.json')['records'];assert len(prior)==16
        with localcontext() as ctx:
            ctx.prec=60
            for step in range(1,9):
                for cell in range(2):
                    guard();entry={'step':step,'cell':cell,'status':'started','newton':[]};summary['records'].append(entry);current=output/f'endpoint-{step:02}-{cell}.json'
                    save(current,entry);save(output/'summary.json',summary)
                    state=run['states'][step][cell];obs=run['observations'][step-1]['cells'][cell];inv=obs['inverse'];point=inv['point'];m=point['fluid']['mechanical'];w=obs['equilibrium']['liquid']['state'];storage=pair['storages'][cell];ip=pair['inverse_policies'][cell]
                    assert state['energy_model_identity']==storage['_identity']==point['model_identity']
                    assert storage['fluid_template']['mechanical']['water']==provider
                    assert w['implementation']==implementation and w['reference']==reference and w['phase']=='liquid'
                    assert w['temperature_k']==m['temperature_k'] and w['pressure_pa']==m['liquid_pressure_pa']
                    assert state['liquid_water_mol']==m['liquid_inventory_mol'] and dict(zip(('O2','N2','H2O'),state['gas_amounts_mol'],strict=True))==m['gas_inventory_mol']
                    assert inv['target_energy_j']==state['internal_energy_j']
                    energy_error=abs(F(point['total_internal_energy_j'])-F(inv['target_energy_j']))+F(point['energy_error_j']);eps=F(inv['temperature_error_bound_k'])
                    assert F(point['minimum_heat_capacity_j_k'])>0 and F(point['energy_error_j'])>=0 and eps>=energy_error/F(point['minimum_heat_capacity_j_k'])
                    assert energy_error<=F(ip['energy_tolerance_j']) and eps<=F(ip['temperature_tolerance_k'])
                    temp=I(m['temperature_k']);error=I(inv['temperature_error_bound_k']);t=Interval((temp-error).lo,(temp+error).hi)
                    assert D(storage['temperature_domain_k'][0])<=t.lo<=t.hi<=D(storage['temperature_domain_k'][1])
                    lo,hi=map(D,inv['final_temperature_bracket_k']);assert lo<=t.lo<=t.hi<=hi
                    nl=I(state['liquid_water_mol']);scale=I(mp)/I(mn);seedrho=nl*scale/I(m['liquid_volume_m3']);density=Interval((seedrho-I(D('.2'))).lo,(seedrho+I(D('.2'))).hi)
                    available=I(storage['bulk_volume_m3'])
                    for mass,solid in zip(state['solid_mass_kg'],storage['solids'],strict=True):available=available-I(mass)*I(solid['volume_m3_kg'])
                    ve=I(storage['bulk_volume_error_m3'])+nl*I(storage['fluid_template']['envelope']['liquid_v_error_m3_mol'])
                    args=dict(temperature=t,liquid_molar_density=density,effective_available_volume=Interval((available-ve).lo,(available+ve).hi),liquid_mol=nl,gas_mol=sum((I(v) for v in state['gas_amounts_mol']),I(0)),gas_constant=I(m['gas_constant_j_mol_k']),liquid_volume_scale=scale,precision=60)
                    previous=prior[(step-1)*2+cell];assert (previous['step'],previous['cell'])==(step,cell)
                    assert encode(args)==previous['inputs']
                    entry.update(original_state=state,inverse=inv,native_query=w,mechanical_inputs=args,exact_energy_error=str(energy_error),saved_eps=str(eps));save(current,entry)
                    center=helpers.seed(data,float(temp.lo));kw=dict(reducing_density=e['STATES']['reducing']['rhomolar'],reducing_temperature=e['STATES']['reducing']['T'],gas_constant=e['gas_constant'],jet=lambda d,tau:residual(d,tau,e['alphar']))
                    for iteration in range(12):
                        guard();v=evaluate_box(temp,tuple(I(x) for x in center),**kw);matrix=helpers.inverse_matrix(v.jacobian);f=tuple(helpers.midpoint(x) for x in v.residual)
                        entry['newton'].append({'center':center,'residual':v,'matrix':matrix});save(current,entry)
                        if max(abs(x) for x in f)<D('1e-30'):break
                        center=tuple(center[j]-sum((matrix[j][k]*f[k] for k in range(2)),D(0)) for j in range(2))
                    else:raise ValueError('bounded_seed_not_converged')
                    weights=(D('4e-6'),D('1e-3'));box=tuple(Interval((I(x)-I(r)).lo,(I(x)+I(r)).hi) for x,r in zip(center,weights))
                    guard();coex=enclose_coexistence(source,source_sha,t,box,center,matrix,precision=60,weights=weights);entry['coexistence']=coex;save(current,entry)
                    assert coex.proved,'fixed_coexistence_box_unresolved'
                    guard();mechanical=enclose_local_root(source,source_sha,**args);entry['mechanical']=mechanical;save(current,entry)
                    assert coex.domain.density[0].hi<density.lo
                    tube=prove_density_tube(source,source_sha,t,Interval(coex.domain.density[0].lo,density.hi),precision=60,maximum_boxes=256,maximum_wall_seconds=remaining());entry['tube']=tube;save(current,entry)
                    ambiguity=max(D(.01),(I(2e-8)*I(coex.pressure.hi)).hi);gap=(I(mechanical.pressure.lo)-I(coex.pressure.hi)-I(ambiguity)).lo
                    entry.update(ambiguity_upper=ambiguity,pressure_separation_lower=gap);assert tube.proved and gap>0
                    q=(w['temperature_k'],w['pressure_pa'],w['density_kg_m3'],mp,mn,state['liquid_water_mol'],m['liquid_volume_m3'],storage['fluid_template']['envelope']['liquid_v_error_m3_mol'])
                    rn=I(q[2])/I(mn);querybox=Interval((rn-I(D('.2'))).lo,(rn+I(D('.2'))).hi)
                    query=analyze(q,querybox,pressure=lambda tt,rr:pressure_interval(source,source_sha,tt,rr,precision=60),binding=lambda:tuple(sha(p) for p in paths),maximum_boxes=256,maximum_wall_seconds=remaining());entry['observed_output']=query;save(current,entry)
                    assert query['status']=='passed_observed_query',query['reason']
                    radius=(I(max((I(m['pressure_pa'])-mechanical.pressure).lo.copy_abs(),(I(m['pressure_pa'])-mechanical.pressure).hi.copy_abs()))+I(point['pressure_error_pa'])).hi
                    entry.update(status='passed_independent_saved_endpoint',pressure_radius=radius,original_fixed_T_error=point['pressure_error_pa'],global_phase_admission=False,native_universal_error_admission=False)
                    guard();save(current,entry);save(output/'summary.json',summary)
        summary['status']='completed_16_independent_endpoints'
    except Exception as exc:
        summary.update(status='failed',reason=repr(exc),traceback=traceback.format_exc())
        if current is not None:entry.update(status='failed',reason=repr(exc));save(current,entry)
    finally:
        summary['elapsed_seconds']=time.monotonic()-begun;summary['source_after']={str(p):sha(p) for p in paths};summary['inputs_unchanged']=summary['source_after']==frozen['files']
        if not summary['inputs_unchanged'] or summary['elapsed_seconds']>60:summary['status']='failed'
        save(output/'summary.json',summary)
    return 0 if summary['status']=='completed_16_independent_endpoints' else 1
if __name__=='__main__':raise SystemExit(main())
