"""All 16 saved endpoints: exact Fraction checks only, no EOS imports."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from collections import deque
import hashlib,json
R=Path(__file__).parent;B=R.parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def iv(x):return F(x['lo']),F(x['hi'])
def pt(x):return x,x
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
    values=[x*y for x in a for y in b];return min(values),max(values)
def isum(xs):
    s=pt(F())
    for x in xs:s=add(s,x)
    return s
def enclosed(saved,exact):
    a,b=iv(saved);assert a<=exact[0]<=exact[1]<=b
summary=read(R/'attempt01/summary.json');freeze=read(R/'FREEZE.json');watch=read(R/'supervisor-result01.json')
assert summary['freeze']==freeze and summary['inputs_unchanged']
assert summary['source_after']==freeze['files']=={p:sha(Path(p)) for p in freeze['files']}
assert watch['returncode']==0 and not watch['external_timeout'] and watch['runner_unchanged']
assert watch['freeze_sha256']==sha(R/'FREEZE.json') and watch['supervisor_sha256']==sha(R/'supervise.py')
assert watch['runner_sha256']==sha(R/'run.py')
assert summary['elapsed_seconds']<60 and watch['elapsed_seconds']<watch['external_limit_seconds']==70
assert summary['status']=='completed_16_independent_endpoints'
assert [[e['step'],e['cell']] for e in summary['records']]==freeze['sequence']==[[s,c] for s in range(1,9) for c in range(2)]
assert len(list((R/'attempt01').glob('endpoint-*.json')))==16
run=read(B/'saved-fine/run-result.json');prior=read(B/'saved-endpoint-result02.json')['records'];pair=read(Path('/private/tmp/brick-mass-wet-transport-native-v1/fine/pair-inputs.json'))
provider=read(B/'saved-fine/water-provider.json');impl=dict(provider['implementation'][2]);desc=json.loads(impl['canonical_descriptor'])['real_fluid'];scale=F(float.fromhex(desc['public_mass_hex']))/F(float.fromhex(desc['native_mass_hex']))
assert desc['runtime']['fluid_sha256']==sha(B/'heos-water.json')
checks=[]
for index,entry in enumerate(summary['records']):
    step,cell=entry['step'],entry['cell'];path=R/f'attempt01/endpoint-{step:02}-{cell}.json'
    assert read(path)==entry and entry['status']=='passed_independent_saved_endpoint'
    state=run['states'][step][cell];obs=run['observations'][step-1]['cells'][cell];inv=obs['inverse'];point=inv['point'];mechanical0=point['fluid']['mechanical'];storage=pair['storages'][cell];policy=pair['inverse_policies'][cell]
    assert entry['original_state']==state and entry['inverse']==inv and entry['native_query']==obs['equilibrium']['liquid']['state']
    assert state['energy_model_identity']==storage['_identity']==point['model_identity'] and state['internal_energy_j']==inv['target_energy_j']
    E=abs(F(point['total_internal_energy_j'])-F(inv['target_energy_j']))+F(point['energy_error_j']);eps=F(inv['temperature_error_bound_k']);cp=F(point['minimum_heat_capacity_j_k'])
    assert E==F(entry['exact_energy_error'])<=F(policy['energy_tolerance_j']) and cp>0 and E/cp<=eps==F(entry['saved_eps'])<=F(policy['temperature_tolerance_k'])
    args=entry['mechanical_inputs'];a=entry['coexistence'];k=a['krawczyk'];m=entry['mechanical'];tube=entry['tube']
    assert args==prior[index]['inputs'] and (prior[index]['step'],prior[index]['cell'])==(step,cell)
    T=F(mechanical0['temperature_k']);enclosed(args['temperature'],(T-eps,T+eps));blo,bhi=map(F,inv['final_temperature_bracket_k']);tlo,thi=iv(args['temperature'])
    assert blo<=tlo<=thi<=bhi and F(storage['temperature_domain_k'][0])<=tlo<=thi<=F(storage['temperature_domain_k'][1])
    assert args['temperature']==a['domain']['temperature']==a['center']['temperature']==m['temperature']==tube['temperature']
    assert a['source_sha256']==sha(B/'heos-water.json') and a['precision']==60
    assert k['center']==entry['newton'][-1]['center'] and k['preconditioner']==entry['newton'][-1]['matrix'] and len(entry['newton'])<=12
    assert k['jacobian']==a['domain']['jacobian'] and k['center_residual']==a['center']['residual']
    X=list(map(iv,k['box']));c=list(map(F,k['center']));C=[list(map(F,row)) for row in k['preconditioner']];J=[[iv(v) for v in row] for row in k['jacobian']];f=list(map(iv,k['center_residual']));w=list(map(F,k['weights']))
    assert w==[F('4e-6'),F('.001')] and C[0][0]*C[1][1]-C[0][1]*C[1][0]!=0
    for i in range(2):enclosed(k['box'][i],(c[i]-w[i],c[i]+w[i]))
    A=[[sub(pt(F(int(i==j))),isum(mul(pt(C[i][q]),J[q][j]) for q in range(2))) for j in range(2)] for i in range(2)]
    image=[add(sub(pt(c[i]),isum(mul(pt(C[i][j]),f[j]) for j in range(2))),isum(mul(A[i][j],sub(X[j],pt(c[j]))) for j in range(2))) for i in range(2)]
    for s,e in zip(k['image'],image):enclosed(s,e)
    norm=max(sum(max(abs(lo),abs(hi))*w[j]/w[i] for j,(lo,hi) in enumerate(row)) for i,row in enumerate(A))
    assert norm<=F(k['contraction_upper'])<1
    for i in range(2):
        lo,hi=iv(k['image'][i]);assert all(0<F(s)<=e for s,e in zip(k['strict_margins'][i],(lo-X[i][0],X[i][1]-hi)))
    assert k['proved'] and a['proved'] and all(iv(v)[0]>0 for v in a['domain']['stability'])
    pp=list(map(iv,a['domain']['pressure']));assert iv(a['pressure'])==(max(x[0] for x in pp),min(x[1] for x in pp))
    assert iv(m['lower_residual'])[1]<0<iv(m['upper_residual'])[0] and iv(m['liquid_pressure_derivative'])[0]>0 and iv(m['total_residual_derivative'])[0]>0
    corners=[]
    for t,v,rho,s,nl,ng,rg in product(*(iv(args[key]) for key in ('temperature','effective_available_volume','liquid_molar_density','liquid_volume_scale','liquid_mol','gas_mol','gas_constant'))):
        vg=v-nl*s/rho;assert vg>0;corners.append(ng*rg*t/vg)
    enclosed(m['pressure'],(min(corners),max(corners)))
    liquid=iv(a['domain']['density'][0]);rho=iv(args['liquid_molar_density']);assert liquid[1]<rho[0] and iv(tube['density'])==(liquid[0],rho[1])
    queue=deque([iv(tube['density'])]);positive=[]
    for visit in tube['visits']:
        box=queue.popleft();assert iv(visit['density'])==box
        lo,hi=iv(visit['derivative'])
        if visit['decision']=='positive':assert lo>0;positive.append(box)
        else:
            assert visit['decision']=='split' and lo<=0<hi
            mid=sum(box)/2;queue.extend([(mid,box[1]),(box[0],mid)])
    leaves=list(map(iv,tube['leaves']));assert not queue and not tube['pending'] and leaves==sorted(positive)
    assert leaves[0][0]==liquid[0] and leaves[-1][1]==rho[1] and all(x[1]==y[0] for x,y in zip(leaves,leaves[1:]))
    assert tube['proved'] and tube['evaluations_attempted']==tube['evaluations_completed']==len(tube['visits'])<=tube['maximum_boxes']==256
    assert tube['elapsed_seconds']<=tube['maximum_wall_seconds']<=60
    assert tube['source_before']==tube['source_after']==[a['source_sha256'],sha(B/'interval_eos.py')]
    ambiguity=max(F(.01),F(2e-8)*iv(a['pressure'])[1]);assert F(entry['ambiguity_upper'])>=ambiguity
    gap=iv(m['pressure'])[0]-iv(a['pressure'])[1]-F(entry['ambiguity_upper']);assert 0<F(entry['pressure_separation_lower'])<=gap
    query=entry['observed_output'];metrics=query['metrics'];q=query['query'];t,p,rhom,mp,mn,nl,vhost,decl=map(F,q)
    water=entry['native_query'];assert q==[water['temperature_k'],water['pressure_pa'],water['density_kg_m3'],float.fromhex(desc['public_mass_hex']),float.fromhex(desc['native_mass_hex']),state['liquid_water_mol'],mechanical0['liquid_volume_m3'],storage['fluid_template']['envelope']['liquid_v_error_m3_mol']]
    assert query['status']=='passed_observed_query' and query['source_before']==query['source_after']==list(freeze['files'].values())
    assert query['elapsed_seconds']<=query['maximum_wall_seconds']<=60
    assert query['attempted']==query['completed']==len(query['visits'])<=query['maximum_boxes']==256 and not query['pending']
    rn=rhom/mn;enclosed(metrics['native_density'],(rn,rn));enclosed(metrics['volume_scale'],(scale,scale));box=iv(query['density_box']);assert box[0]<=rn-F('.2')<rn+F('.2')<=box[1]
    assert len(query['accepted_leaves'])==1 and query['accepted_leaves'][0][0]==query['density_box'] and query['visits'][3]['density']==query['density_box']
    assert query['accepted_leaves'][0][1]==query['visits'][3]['derivative']
    for j,key in enumerate(('lower_residual','upper_residual','observed_residual')):
        lo,hi=iv(query['visits'][j]['pressure']);enclosed(metrics[key],(lo-p,hi-p))
    assert iv(metrics['lower_residual'])[1]<0<iv(metrics['upper_residual'])[0]
    slope=F(metrics['minimum_slope']);assert slope==iv(query['visits'][3]['derivative'])[0]>0
    assert F(metrics['density_error_bound'])>=max(map(abs,iv(metrics['observed_residual'])))/slope
    assert F(metrics['native_volume_error_bound'])>=scale*F(metrics['density_error_bound'])/(box[0]*rn)
    assert q[6]==(q[5]*q[3])/q[2]
    roundoff=vhost-nl*mp/rhom;assert F(metrics['host_volume_roundoff_exact'])==roundoff;enclosed(metrics['host_per_mol_roundoff'],(roundoff/nl,roundoff/nl))
    assert F(metrics['combined_volume_error_bound'])>=F(metrics['native_volume_error_bound'])+max(map(abs,iv(metrics['host_per_mol_roundoff'])))
    assert F(metrics['combined_volume_error_bound'])<=decl and iv(metrics['original_declaration'])==(decl,decl)
    fixed=F(point['pressure_error_pa']);assert F(entry['original_fixed_T_error'])==fixed
    exact_radius=max(abs(F(mechanical0['pressure_pa'])-x) for x in iv(m['pressure']))+fixed
    assert F(entry['pressure_radius'])>=exact_radius
    assert not entry['global_phase_admission'] and not entry['native_universal_error_admission']
    checks.append({'step':step,'cell':cell,'status':'PASS','endpoint_sha256':sha(path),'weighted_norm':k['contraction_upper'],'tube_visits':len(tube['visits']),'tube_leaves':len(leaves),'observed_evaluations':query['attempted'],'combined_volume_error_bound':metrics['combined_volume_error_bound'],'pressure_radius':entry['pressure_radius'],'gap_lower':entry['pressure_separation_lower']})
out={'status':'PASS_ALL_16','records':checks,'summary_sha256':sha(R/'attempt01/summary.json'),'supervisor_sha256':sha(R/'supervisor-result01.json'),'whole_elapsed_seconds':summary['elapsed_seconds'],'external_elapsed_seconds':watch['elapsed_seconds'],'EOS_calls':0,'scope':'Independent saved endpoint certificates only; conditional original envelopes, no time continuity or global/native-universal admission'}
with (R/'review_saved_all01.json').open('x') as f:f.write(json.dumps(out,indent=2)+'\n')
print('PASS all',len(checks),'saved endpoints; exact bounds and source/time gates verified; EOS calls 0')
