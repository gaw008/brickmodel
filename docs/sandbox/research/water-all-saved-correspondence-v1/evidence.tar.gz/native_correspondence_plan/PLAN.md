# Saved-endpoint mathematical/native correspondence: next executable boundary

Read-only assessment. No EOS/flash, installation, repository edits, new literature lookup, or new physical constants. Inputs inspected: phase-admission/NEXT_INTERFACE.md; reviewed interval/coexistence/tube/coupled modules; saved-endpoint-result02.json and saved-fine run/provider/storage records; production mass_wet_storage.invert, mass_wet_exact_stage.pressure_radius and _heos_kernel._snapshot. This is a concrete next interface, not completed admission.

## Existing evidence and exact gaps

The connected-tube result covers a declared [299.9999999,300.0000001] K interval near the initial 300 K point. It is not any saved endpoint's inverse interval. The 16 saved endpoints already have local coupled mechanical rectangles over their actual saved T±epsilon intervals; epsilon ranges about 9.6746e-8 to 5.7113e-7 K. Their saved conservative pressure radii, including original fixed-T error, range about .0014883 to .0032686 Pa. These are existing derived numbers, not improved bounds or a comparison gate pass.

For every endpoint the following must be recomputed/bound individually:

1. Exact state/layout/source/policy match. Tie saved step/cell and target U to its inverse result, full material/reference/volume/error declaration, actual provider class plus implementation descriptor, all water source assets, native coefficient JSON and code hashes. Do not treat names or source IDs as sufficient. Only explicitly permitted verifier additions may differ from a historical runtime; retain old and current identities separately.
2. Actual inverse interval. Reconstruct epsilon from (abs(U_point-U_target)+energy_error)/minimum_heat_capacity with exact binary64 Fractions and outward conversion; check the saved epsilon covers this value and both original inverse tolerances. Check T±epsilon lies in the original domain and any justified final bracket. A returned scalar minimum heat capacity is not by itself a proof of a uniform physical lower bound throughout this interval. Keep its original provider/envelope qualification; do not strengthen that assumption silently. Global U/Cp/native error validation remains separate.
3. Coexistence covering the entire actual T interval. Existing tiny initial box cannot substitute. Prove candidate boxes on exact closed T subdivisions; union must exactly cover the requested T interval. Within each subdivision require full parameter K inclusion/contraction, positive Dl,Dv and ordered density branches. At adjacent T joins, prove common branch identity by a validated unique common box or another explicit uniqueness enclosure; mere numeric proximity is insufficient. A source-linked local coexistence branch still is not a global phase theorem.
4. Monotone liquid tube for each subdivision. Its density interval must contain the entire certified saturation-liquid box AND entire coupled mechanical density box. Validate all accepted derivative leaves, exact coverage, original source/T membership and costs. Apply pressure lower > saturation upper + max(.01 Pa,2e-8*saturation upper) using the original binary64 ambiguity constants and outward arithmetic. Do not compare only nominal pressure or endpoints of the tube.
5. Actual native output correspondence. The saved equilibrium.liquid.state DOES contain actual density_kg_m3, pressure_pa, temperature_k, phase and implementation/reference fields. For the first inspected endpoint its T and P equal mechanical.temperature_k and liquid_pressure_pa exactly. Require this equality for each endpoint before using it as the corresponding query. It is a separately recorded actual provider call, not proof of every unrecorded inverse trial. No new native run is needed to analyze these saved queries.

## Computable output checks without pretending native arithmetic is exact

Let rho_native = saved density_kg_m3 / M_native, enclosing division of exact binary64 inputs. Do not use M_public or mixed-gas R here. Independently evaluate the pinned mathematical EOS pressure interval at saved exact T and rho_native. Subtract the saved query pressure interval to get residual enclosure R. On a certified monotone interval containing the mathematical query-pressure root and rho_native, |rho_native-rho_root| <= maxabs(R)/inf(dpEOS/drho). First establish root existence (opposite pressure residual faces) for this query pressure, not merely an assumed nearby root. If rho_native is not inside the existing connected tube, extend and reprove the tube; never extrapolate its slope bound.

Convert density displacement into a public molar-volume error through interval v_public=(M_public/M_native)/rho_native; either directly compare certified volumes or use the reciprocal Lipschitz bound with proven positive lower density. Compare this numerical discrepancy, plus explicit host rounding, with the original declared liquid_v_error. If it exceeds the declaration, return unavailable; do not enlarge the declaration or charge it to material uncertainty after seeing the result.

The existing study seed Nl*scale/Vliquid is a useful numerical suggestion, but is not the independently saved native density. Verify Vliquid against Nl*M_public/density_kg_m3 with its actual rounding convention; pressure query may differ from mixture pressure by saved mechanical residual. Retain each term separately. _snapshot's public-R residual checks and self-reported pressure_eos_residual are diagnostics, not independent accuracy certificates; the mathematical residual must use native EOS R and source coordinates.

This approach certifies discrepancy of the observed binary64 output from the pinned mathematical EOS at a saved query; it does not require proving every internal floating-point instruction. It also does not generalize one saved output to every native call. A future live adapter can perform this bounded a-posteriori check per actual output and fail closed; caching requires full source/query/domain identity and actual certificate coverage.

## Proposed result/API

`check_saved_wet_pressure_correspondence(original_state, inverse, saved_native_liquid_state, original_storage_inputs, provider_identity, source_manifest, numerical_budget) -> WetPressureCorrespondenceAttempt`

Return immutable full inputs/hash references and separate fields:
- original_inverse_interval_checked; inverse_energy_contract_classification
- local_mechanical_root_proved; coexistence_cover_proved; local_liquid_branch_connected
- native_query_and_identity_matched; observed_native_density_residual_enclosed; observed_native_volume_within_original_declaration
- pressure_interval; original_fixed_T_pressure_error; conservative_pressure_radius
- error_envelope_classification; global_stable_phase_evidence; eligible_for_requested_consumer
- every failed/subdivided box, exact cover maps, residual/derivative bounds, attempted/completed mathematical calls and cumulative wall.

Do not consume an externally supplied `stable=true`. Either revalidate the typed mathematical proof against actual inputs or regenerate it. The current global_stable_phase_evidence remains unresolved unless the application explicitly adopts a separately justified physical branch assumption; it must never become true merely because local monotonicity holds. No automatic ordinary-wet stage admission in this research interface.

Pressure radius must conservatively enclose full inverse T and original volume uncertainty, and add the existing fixed-T error. Native/output rounding may be shown covered by the original declared volume budget, with explicit audit, or require additional allowance and therefore refuse under the present contract. Do not subtract overlapping errors without a separate correlation proof. Material uncertainty is not assigned zero: present results stay conditional_on_original_manufactured_envelope. Measured material/EOS uncertainty and stable-phase evidence are distinct missing inputs.

## Minimal next numerical study, no new trajectory

First saved-data case: choose deterministically the endpoint with maximum saved inverse epsilon (before any attempt), not a successful narrow example. Preserve its original full T interval and all budgets. Start with one coex box over that interval; allow at most 32 exact T subdivisions, original per-box precision60, maximum256 density-tube visits per T leaf, cumulative60s mathematical wall with external70s watchdog. These are numerical work limits only. Ancillary/Newton seeds remain suggestions; freeze them and all input/code hashes before evaluating. Abort with complete partial evidence on any budget/source/branch uncertainty, without dropping failing intervals. This bounded study should test whether the largest actual interval is practically certifiable; it does not need 295–310 K global coverage to diagnose this endpoint.

Independently recompute the observed native point residual/volume discrepancy at that endpoint using saved liquid.state. No native flash/reintegration. Compare against the original declaration and retain every failing metric. If successful, prepare a separately preregistered all16 saved-endpoint study with identical scientific conditions and explicit aggregate budget; do not claim success from the first point alone. Only after full input/branch/numerical contracts and consumer qualification are settled should pressure_radius gain a new explicit interface.

The present minimum implementable advance is this per-output a-posteriori mathematical correspondence and actual-inverse-interval branch cover. It is more precise than requiring a universal proof of the entire native executable, while preserving every original error/source boundary.
