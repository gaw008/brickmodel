"""Exact saved Krawczyk algebra audit, with no EOS evaluation."""
from pathlib import Path
from decimal import Decimal as D
from fractions import Fraction as F
import hashlib,json
ROOT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def val(x):return F(D(x))
def iv(x):return val(x['lo']),val(x['hi'])
def point(x):return x,x
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
 v=[x*y for x in a for y in b];return min(v),max(v)
def isum(items):
 s=point(F())
 for i in items:s=add(s,i)
 return s
def encloses(saved,exact):
 a,b=iv(saved);assert a<=exact[0]<=exact[1]<=b
r=read(ROOT/'result01.json');frozen=read(ROOT/'RUN_FREEZE.json')
assert r['status']=='completed_cases' and r['frozen_sha256']==frozen
archived={p:(Path(p).parent/'before-weighted-norm'/Path(p).name if p.endswith('/coexistence_candidate/coexistence.py') else Path(p)) for p in frozen}
assert frozen=={p:sha(path) for p,path in archived.items()}
assert 0<=r['elapsed_seconds']<r['budget_seconds']==15
assert len(r['newton'])==5 and len(r['cases'])==len(r['preregistered_cases'])==6
center=r['newton'][-1]['center'];matrix=r['newton'][-1]['matrix'];checks=[]
for index,(case,registered) in enumerate(zip(r['cases'],r['preregistered_cases'],strict=True)):
 assert (case['T_radius'],case['log_rho_liquid_radius'],case['log_rho_vapor_radius'])==tuple(registered)
 out=case['result'];k=out['krawczyk'];assert k['center']==center and k['preconditioner']==matrix
 assert k['center_residual']==out['center']['residual'] and k['jacobian']==out['domain']['jacobian']
 assert out['domain']['temperature']==out['center']['temperature']
 tr=val(case['T_radius']);encloses(out['domain']['temperature'],(F(300)-tr,F(300)+tr))
 X=list(map(iv,k['box']));c=list(map(val,k['center']));C=[list(map(val,row)) for row in matrix];J=[[iv(x) for x in row] for row in k['jacobian']];f=list(map(iv,k['center_residual']))
 assert C[0][0]*C[1][1]-C[0][1]*C[1][0]!=0
 for i,rad in enumerate(registered[1:]):
  radius=val(rad);encloses(k['box'][i],(c[i]-radius,c[i]+radius));assert X[i][0]<c[i]<X[i][1]
 defect=[[sub(point(F(int(i==j))),isum(mul(point(C[i][q]),J[q][j]) for q in range(2))) for j in range(2)] for i in range(2)]
 image=[add(sub(point(c[i]),isum(mul(point(C[i][j]),f[j]) for j in range(2))),isum(mul(defect[i][j],sub(X[j],point(c[j]))) for j in range(2))) for i in range(2)]
 for saved,computed in zip(k['image'],image):encloses(saved,computed)
 norm=max(sum(max(abs(a),abs(b)) for a,b in row) for row in defect);assert val(k['contraction_upper'])>=norm
 margins=[]
 for i in range(2):
  lower,upper=iv(k['image'][i]);exact=(lower-X[i][0],X[i][1]-upper)
  saved=tuple(map(val,k['strict_margins'][i]));assert saved[0]<=exact[0] and saved[1]<=exact[1];margins.extend(saved)
 kproved=all(x>0 for x in margins) and val(k['contraction_upper'])<1;assert kproved==k['proved']
 pressures=list(map(iv,out['domain']['pressure']));plo=max(x[0] for x in pressures);phi=min(x[1] for x in pressures)
 assert (out['pressure'] is None)==(plo>phi)
 if plo<=phi:assert iv(out['pressure'])==(plo,phi)
 stable=all(iv(d)[0]>0 for d in out['domain']['stability'])
 proved=kproved and stable and plo<=phi and plo>0;assert proved==out['proved']
 checks.append({'index':index,'proved':proved,'strict_inclusion':all(x>0 for x in margins),'contraction_below_one':val(k['contraction_upper'])<1,'exact_saved_algebra_enclosed':True})
assert sum(x['proved'] for x in checks)==r['proved_cases']==3
output={'status':'passed','cases':checks,'actual_elapsed_seconds':r['elapsed_seconds'],'result_sha256':sha(ROOT/'result01.json'),'review_script_sha256':sha(Path(__file__)),'reviewed_source_path_mapping':{p:str(path) for p,path in archived.items()},'EOS_calls':0}
(ROOT/'independent-saved-review01.json').write_text(json.dumps(output,indent=2)+'\n')
print('PASS',len(checks),'cases',sum(x['proved'] for x in checks),'proved; all exact saved Krawczyk/hash gates consistent')
