"""Saved weighted proof audit; no EOS or Krawczyk implementation calls."""
from pathlib import Path
from decimal import Decimal as D
from fractions import Fraction as F
import hashlib,json
ROOT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def val(x):return F(D(x))
def iv(x):return val(x['lo']),val(x['hi'])
def point(x):return x,x
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
 v=[x*y for x in a for y in b];return min(v),max(v)
def isum(xs):
 s=point(F())
 for x in xs:s=add(s,x)
 return s
r=read(ROOT/'result02-weighted.json');old=read(ROOT/'result01.json');freeze=read(ROOT/'RUN02_FREEZE.json')
assert r['status']=='completed_cases' and r['frozen_sha256']==freeze=={p:sha(Path(p)) for p in freeze}
assert r['parent_sha256']==sha(ROOT/'result01.json')
assert 0<=r['elapsed_seconds']<r['budget_seconds']==15
assert len(r['cases'])==len(old['cases'])==6
checks=[]
for n,(case,previous) in enumerate(zip(r['cases'],old['cases'],strict=True)):
 a,b=case['result'],previous['result'];k=a['krawczyk'];pk=b['krawczyk']
 assert case['T_radius']==previous['T_radius'] and case['original_proved']==b['proved']
 w=tuple(map(val,case['weights']));assert w==tuple(map(val,(previous['log_rho_liquid_radius'],previous['log_rho_vapor_radius'])))
 assert tuple(map(val,k['weights']))==w and all(x>0 for x in w) and k['norm_name']=='weighted_infinity'
 assert a['source_sha256']==b['source_sha256'] and a['precision']==b['precision']==60
 assert a['domain']==b['domain'] and a['center']==b['center'] and a['pressure']==b['pressure']
 for key in ('box','center','preconditioner','center_residual','jacobian','image','strict_margins'):
  assert k[key]==pk[key]
 C=[list(map(val,row)) for row in k['preconditioner']];J=[[iv(x) for x in row] for row in k['jacobian']]
 defect=[[sub(point(F(int(i==j))),isum(mul(point(C[i][q]),J[q][j]) for q in range(2))) for j in range(2)] for i in range(2)]
 norm=max(sum(max(abs(lo),abs(hi))*w[j]/w[i] for j,(lo,hi) in enumerate(row)) for i,row in enumerate(defect))
 assert val(k['contraction_upper'])>=norm
 assert k['unweighted_contraction_upper']==pk['contraction_upper']
 strict=all(val(m)>0 for row in k['strict_margins'] for m in row)
 kproved=strict and val(k['contraction_upper'])<1;assert k['proved']==kproved
 stable=all(iv(x)[0]>0 for x in a['domain']['stability']);p=a['pressure'];proved=kproved and stable and p is not None and iv(p)[0]>0
 assert a['proved']==proved
 checks.append({'index':n,'original_proved':b['proved'],'weighted_proved':proved,'strict_inclusion':strict,'weighted_norm':k['contraction_upper'],'unchanged_physical_and_K_geometry':True,'exact_norm_enclosed':True})
assert sum(x['weighted_proved'] for x in checks)==r['proved_cases']==5
assert sum(x['original_proved'] for x in checks)==old['proved_cases']==3
assert checks[0]['strict_inclusion'] is False and checks[0]['weighted_proved'] is False
assert checks[1]['weighted_proved'] is True and checks[1]['original_proved'] is False
out={'status':'passed','records':checks,'elapsed_seconds':r['elapsed_seconds'],'result_sha256':sha(ROOT/'result02-weighted.json'),'parent_sha256':r['parent_sha256'],'review_script_sha256':sha(Path(__file__)),'EOS_calls':0}
(ROOT/'independent-saved-weighted02.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS 6 cases, 5 proved / 1 unresolved, original geometry preserved, exact weighted bounds verified')
