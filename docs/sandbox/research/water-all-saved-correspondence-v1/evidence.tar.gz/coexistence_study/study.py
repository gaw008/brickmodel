"""Bounded pinned-IAPWS mathematical coexistence experiment; no native flash."""
from pathlib import Path
from decimal import Decimal as D, localcontext
from dataclasses import asdict
import hashlib,json,math,sys,time

ROOT=Path(__file__).parent
BASE=ROOT.parent
sys.path[:0]=[str(BASE),str(BASE/'coexistence_candidate')]
from interval_eos import I,Interval,residual
from coexistence import evaluate_box,enclose_coexistence

SOURCE_SHA='a10a0da6c55e623cccc1f56a70cb348c772d8fc1710a6a142b459abb0dec4586'
CASES=(('1e-7','1e-7','1e-4'),('1e-7','1e-6','1e-3'),
       ('1e-8','1e-7','1e-4'),('1e-8','1e-6','1e-3'),
       ('1e-9','1e-8','1e-5'),('1e-9','1e-7','1e-4'))


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def midpoint(x):return (x.lo+x.hi)/2


def inverse_matrix(jac):
    a,b=map(midpoint,jac[0]);c,d=map(midpoint,jac[1]);det=a*d-b*c
    if det==0:raise ValueError('numerical_center_jacobian_singular')
    return ((d/det,-b/det),(-c/det,a/det))


def seed(raw,t):
    out=[]
    for name,kind in (('rhoL','rhoLnoexp'),('rhoV','rhoV')):
        a=raw['ANCILLARIES'][name]
        assert a['type']==kind and a['Tmin']<=t<=a['Tmax']
        theta=1-t/a['T_r']
        total=math.fsum(n*theta**power for n,power in zip(a['n'],a['t'],strict=True))
        rho=a['reducing_value']*(1+total if name=='rhoL' else math.exp(a['T_r']/t*total))
        out.append(D(rho).ln())
    return tuple(out)


def main():
    begun=time.monotonic();source=BASE/'heos-water.json'
    assert sha(source)==SOURCE_SHA
    files=(source,BASE/'interval_eos.py',BASE/'coexistence_candidate/coexistence.py',Path(__file__))
    frozen={str(p):sha(p) for p in files};raw=json.loads(source.read_bytes())[0];e=raw['EOS'][0]
    result={'status':'started','qualification':'mathematical_local_coexistence_boxes_not_native_or_global_phase_certificate',
        'frozen_sha256':frozen,'temperature_center_k':300,'budget_seconds':15,'maximum_newton_iterations':12,
        'newton_stopping_residual':'1e-30 (seed refinement only, not admission)',
        'preregistered_cases':CASES,'newton':[],'cases':[]}
    def guard():
        if time.monotonic()-begun>15:raise TimeoutError('fifteen_second_math_study_budget')
        assert frozen=={str(p):sha(p) for p in files}
    try:
        with localcontext() as ctx:
            ctx.prec=60
            center=seed(raw,300.);result['auxiliary_seed']=center
            kw=dict(reducing_density=e['STATES']['reducing']['rhomolar'],
                reducing_temperature=e['STATES']['reducing']['T'],gas_constant=e['gas_constant'],
                jet=lambda delta,tau:residual(delta,tau,e['alphar']))
            for iteration in range(12):
                guard();v=evaluate_box(I(300),tuple(I(x) for x in center),**kw)
                c=inverse_matrix(v.jacobian)
                result['newton'].append({'iteration':iteration,'center':center,'residual':asdict(v),'matrix':c})
                if max(abs(midpoint(f)) for f in v.residual)<D('1e-30'):break
                f=tuple(midpoint(x) for x in v.residual)
                center=tuple(center[i]-sum((c[i][j]*f[j] for j in range(2)),D(0)) for i in range(2))
            else:raise ValueError('point_seed_not_converged_within_preregistered_iterations')
            for tradius,lradius,vradius in CASES:
                guard();t=Interval((I(300)-I(D(tradius))).lo,(I(300)+I(D(tradius))).hi)
                box=tuple(Interval((I(x)-I(D(radius))).lo,(I(x)+I(D(radius))).hi)
                    for x,radius in zip(center,(lradius,vradius),strict=True))
                case={'T_radius':tradius,'log_rho_liquid_radius':lradius,'log_rho_vapor_radius':vradius};result['cases'].append(case)
                try:
                    proof=enclose_coexistence(source,SOURCE_SHA,t,box,center,c,precision=60)
                    case['result']=asdict(proof)
                except Exception as exc:
                    case['exception']=type(exc).__name__;case['reason']=str(exc)
            guard();result['status']='completed_cases'
    except Exception as exc:
        result['status']='failed';result['exception']=type(exc).__name__;result['reason']=str(exc)
    result['elapsed_seconds']=time.monotonic()-begun
    result['proved_cases']=sum(case.get('result',{}).get('proved',False) for case in result['cases'])
    with (ROOT/'result01.json').open('x') as output:output.write(json.dumps(result,default=str,indent=2)+'\n')
    print(result['status'],result['proved_cases'],result['elapsed_seconds'],result.get('reason'))
    if result['status']!='completed_cases':raise SystemExit(1)


if __name__=='__main__':main()
