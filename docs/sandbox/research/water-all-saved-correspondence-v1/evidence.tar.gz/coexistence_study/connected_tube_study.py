"""Link one saved coexistence box to an actual-source local mechanical box."""
from pathlib import Path
from decimal import Decimal as D,localcontext
from dataclasses import asdict
import hashlib,json,sys,time

ROOT=Path(__file__).parent;BASE=ROOT.parent
sys.path[:0]=[str(BASE),str(BASE/'density_tube_candidate')]
from interval_eos import I,Interval
from coupled_rectangle import enclose_local_root
from density_tube import prove_density_tube


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def interval(v):return Interval(D(v['lo']),D(v['hi']))


def main():
    begun=time.monotonic();source=BASE/'heos-water.json'
    paths=(source,BASE/'interval_eos.py',BASE/'coupled_rectangle.py',BASE/'density_tube_candidate/density_tube.py',
           ROOT/'result02-weighted.json',BASE/'saved-initial.json',BASE/'saved-fine/storage-inputs.json',
           BASE/'saved-initial-forward.json',BASE/'saved-fine/water-provider.json',Path(__file__))
    frozen={str(p):sha(p) for p in paths}
    state=read(BASE/'saved-initial.json')[0];storage=read(BASE/'saved-fine/storage-inputs.json')
    provider=read(BASE/'saved-fine/water-provider.json')
    descriptor=json.loads(dict(provider['implementation'][2])['canonical_descriptor'])['real_fluid']
    assert sha(source)==descriptor['runtime']['fluid_sha256']
    parent=read(ROOT/'result02-weighted.json');case=parent['cases'][1]['result']
    assert case['proved'] and case['source_sha256']==sha(source)
    out={'status':'started','frozen_sha256':frozen,'coexistence_parent_sha256':sha(ROOT/'result02-weighted.json'),
         'coexistence_case_index':1,'maximum_tube_boxes':256,'tube_wall_budget_seconds':15.,
         'qualification':'Connected to selected local mathematical coexistence branch; no global stable-phase or native-error admission',
         'temperature_interval_role':'Declared study interval around saved 300K forward state, not a substituted U-inverse uncertainty bound'}
    try:
        with localcontext() as ctx:
            ctx.prec=60
            t=interval(case['domain']['temperature'])
            assert t==Interval(D('299.9999999'),D('300.0000001'))
            scale=I(float.fromhex(descriptor['public_mass_hex']))/I(float.fromhex(descriptor['native_mass_hex']))
            nl=I(state['liquid_water_mol']);initial=read(BASE/'saved-initial-forward.json')
            mech=initial['fluid']['mechanical']
            seed=nl*scale/I(mech['liquid_volume_m3'])
            rho=Interval((seed-I(D('.2'))).lo,(seed+I(D('.2'))).hi)
            volume=I(storage['bulk_volume_m3'])
            for m,s in zip(state['solid_mass_kg'],storage['solids'],strict=True):volume=volume-I(m)*I(s['volume_m3_kg'])
            ve=I(storage['bulk_volume_error_m3'])+nl*I(storage['fluid_template']['envelope']['liquid_v_error_m3_mol'])
            effective=Interval((volume-ve).lo,(volume+ve).hi)
            args=dict(temperature=t,liquid_molar_density=rho,effective_available_volume=effective,liquid_mol=nl,
                gas_mol=sum((I(x) for x in state['gas_amounts_mol']),I(0)),gas_constant=I(mech['gas_constant_j_mol_k']),
                liquid_volume_scale=scale,precision=60)
            out['mechanical_inputs']={k:asdict(v) if type(v) is Interval else v for k,v in args.items()}
            local=enclose_local_root(source,frozen[str(source)],**args);out['mechanical']=asdict(local)
            saturation=interval(case['pressure']);liquid=interval(case['domain']['density'][0])
            assert local.temperature==t and liquid.hi<rho.lo
            tube_density=Interval(liquid.lo,rho.hi)
            tube=prove_density_tube(source,frozen[str(source)],t,tube_density,precision=60,maximum_boxes=256,maximum_wall_seconds=15.)
            out['tube']=asdict(tube)
            # Preserve the actual original HEOS saturation ambiguity rule.
            ambiguity=max(D(.01),(I(2e-8)*I(saturation.hi)).hi)
            gap=(I(local.pressure.lo)-I(saturation.hi)-I(ambiguity)).lo
            out['saturation_pressure']=asdict(saturation);out['ambiguity_upper_pa']=ambiguity
            out['pressure_separation_lower_pa']=gap
            assert frozen=={str(p):sha(p) for p in paths}
            out['proved_connected_local_branch']=tube.proved and gap>0
            out['status']='proved_local_connection' if out['proved_connected_local_branch'] else 'unresolved_connection'
            out['error_envelope_classification']=storage['fluid_template']['envelope']['method']
            out['global_phase_admission']=False;out['native_error_admission']=False
    except Exception as exc:
        out['status']='failed';out['exception']=type(exc).__name__;out['reason']=str(exc)
    out['elapsed_seconds']=time.monotonic()-begun
    with (ROOT/'connected-tube-result01.json').open('x') as f:f.write(json.dumps(out,default=str,indent=2)+'\n')
    print(out['status'],out['elapsed_seconds'],out.get('reason'))
    if out['status']!='proved_local_connection':raise SystemExit(1)


if __name__=='__main__':main()
