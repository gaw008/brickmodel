"""Same six saved boxes, explicit coordinate weights, separate proof run."""
from pathlib import Path
from dataclasses import asdict
from decimal import Decimal as D,localcontext
import hashlib,json,sys,time

ROOT=Path(__file__).parent;BASE=ROOT.parent
sys.path[:0]=[str(BASE),str(BASE/'coexistence_candidate')]
from interval_eos import I,Interval
from coexistence import enclose_coexistence


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    start=time.monotonic();source=BASE/'heos-water.json';parent=ROOT/'result01.json'
    frozen={str(p):sha(p) for p in (source,parent,Path(__file__),BASE/'interval_eos.py',BASE/'coexistence_candidate/coexistence.py')}
    old=json.loads(parent.read_bytes());assert old['status']=='completed_cases' and len(old['cases'])==6
    assert sha(source)=='a10a0da6c55e623cccc1f56a70cb348c772d8fc1710a6a142b459abb0dec4586'
    assert sha(BASE/'coexistence_candidate/coexistence.py')=='8f93a72e1b9fff1c6c27cc85ef8a24bbed478224ed28263b5e0e4fefb26278af'
    center=tuple(map(D,old['newton'][-1]['center']))
    matrix=tuple(tuple(map(D,row)) for row in old['newton'][-1]['matrix'])
    result={'status':'started','frozen_sha256':frozen,'parent_sha256':sha(parent),'cases':[],
        'budget_seconds':15,'qualification':'Same mathematical boxes; weighted coordinate norm, not new native or global phase admission'}
    try:
        with localcontext() as ctx:
            ctx.prec=60
            for case in old['cases']:
                if time.monotonic()-start>15:raise TimeoutError('fifteen_second_weighted_study_budget')
                assert frozen=={p:sha(Path(p)) for p in frozen}
                weights=(D(case['log_rho_liquid_radius']),D(case['log_rho_vapor_radius']))
                temperature=Interval((I(300)-I(D(case['T_radius']))).lo,(I(300)+I(D(case['T_radius']))).hi)
                box=tuple(Interval((I(x)-I(w)).lo,(I(x)+I(w)).hi) for x,w in zip(center,weights))
                new={'T_radius':case['T_radius'],'weights':weights,'original_proved':case['result']['proved']}
                result['cases'].append(new)
                proof=enclose_coexistence(source,frozen[str(source)],temperature,box,center,matrix,precision=60,weights=weights)
                new['result']=asdict(proof)
                # The physical rectangle and Krawczyk image have not changed.
                assert json.loads(json.dumps(asdict(proof.krawczyk),default=str))['image']==case['result']['krawczyk']['image']
                assert json.loads(json.dumps(asdict(proof.krawczyk),default=str))['strict_margins']==case['result']['krawczyk']['strict_margins']
            assert frozen=={p:sha(Path(p)) for p in frozen}
            result['status']='completed_cases'
    except Exception as exc:
        result['status']='failed';result['exception']=type(exc).__name__;result['reason']=str(exc)
    result['elapsed_seconds']=time.monotonic()-start
    result['proved_cases']=sum(c.get('result',{}).get('proved',False) for c in result['cases'])
    with (ROOT/'result02-weighted.json').open('x') as out:out.write(json.dumps(result,default=str,indent=2)+'\n')
    print(result['status'],result['proved_cases'],result['elapsed_seconds'],result.get('reason'))
    if result['status']!='completed_cases':raise SystemExit(1)


if __name__=='__main__':main()
