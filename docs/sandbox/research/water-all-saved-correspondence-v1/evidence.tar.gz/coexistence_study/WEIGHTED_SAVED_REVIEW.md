# Independent saved study02 weighted proof review — PASS

Read actual study_weighted.py and the complete result02-weighted.json. All five RUN02_FREEZE source/input hashes match their current bytes; parent_sha256 matches preserved result01.json. Recorded elapsed time is 0.6738914160232525 s, below the unchanged 15-second budget. All six original boxes are retained with five proved and one unresolved result.

Independent review_weighted_saved.py reconstructs each weighted norm bound from saved C/J using exact Fraction interval algebra, with no EOS or Krawczyk implementation calls. For every case, it confirms strictly positive weights equal the original logarithmic-density half-widths; same source and precision; literal equality of the full physical domain, parameter-wide center evaluation, pressure interval, box, point center, preconditioner, residual, Jacobian, Krawczyk image and strict margins to study01; unchanged unweighted norm evidence; and an outward upper bound on max_i sum_j |(I-CJ)_ij|*w_j/w_i.

Each saved flag agrees with strict image containment, the still-strict norm<1 threshold, positive stability intervals and positive nonempty common-pressure intersection. Case 1 remains unresolved because image inclusion fails. Case 2 changes from unresolved to proved through the legitimate weighted norm without changing its geometry or the threshold. The original study01 remains three proved/three unresolved.

Results, exact norm values and output/parent/script hashes are recorded in independent-saved-weighted02.json. This is a saved mathematical-evidence audit; it does not expand the narrow temperature boxes to a full domain certificate or establish global saturation, stable-phase connection or native correspondence.
