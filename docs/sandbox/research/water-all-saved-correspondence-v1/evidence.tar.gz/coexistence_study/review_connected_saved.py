"""Saved-data-only exact Fraction audit; imports no model or EOS module."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from collections import deque
import hashlib
import json

ROOT = Path(__file__).parent
BASE = ROOT.parent
def read(path):
    return json.loads(path.read_bytes())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def iv(value):
    return F(value['lo']), F(value['hi'])
def encloses(saved, values):
    lo, hi = iv(saved)
    assert lo <= min(values) <= max(values) <= hi

r = read(ROOT/'connected-tube-result01.json')
for name, expected in r['frozen_sha256'].items():
    assert sha(Path(name)) == expected, name
for name, expected in read(ROOT/'RUN03_FREEZE.json')['files'].items():
    assert sha(Path(name)) == expected, name
parent = read(ROOT/'result02-weighted.json')
case = parent['cases'][r['coexistence_case_index']]['result']
assert case['proved'] and r['coexistence_case_index'] == 1
assert case['source_sha256'] == r['frozen_sha256'][str(BASE/'heos-water.json')]
provider = read(BASE/'saved-fine/water-provider.json')
desc = json.loads(dict(provider['implementation'][2])['canonical_descriptor'])['real_fluid']
assert desc['runtime']['fluid_sha256'] == case['source_sha256']
state = read(BASE/'saved-initial.json')[0]
storage = read(BASE/'saved-fine/storage-inputs.json')
forward = read(BASE/'saved-initial-forward.json')['fluid']['mechanical']
a = r['mechanical_inputs']; m = r['mechanical']; tube = r['tube']
scale = F(float.fromhex(desc['public_mass_hex'])) / F(float.fromhex(desc['native_mass_hex']))
assert scale != 1
encloses(a['liquid_volume_scale'], [scale])
nl = F(state['liquid_water_mol']); ng = sum(map(F, state['gas_amounts_mol']))
assert iv(a['liquid_mol']) == (nl, nl)
assert iv(a['gas_mol']) == (ng, ng)
rg = F(forward['gas_constant_j_mol_k'])
assert iv(a['gas_constant']) == (rg, rg)
seed = nl*scale/F(forward['liquid_volume_m3'])
encloses(a['liquid_molar_density'], [seed-F('0.2'), seed+F('0.2')])
volume = F(storage['bulk_volume_m3']) - sum(F(x)*F(s['volume_m3_kg']) for x,s in zip(state['solid_mass_kg'], storage['solids'], strict=True))
error = F(storage['bulk_volume_error_m3']) + nl*F(storage['fluid_template']['envelope']['liquid_v_error_m3_mol'])
encloses(a['effective_available_volume'], [volume-error, volume+error])
assert a['temperature'] == m['temperature'] == tube['temperature'] == case['domain']['temperature']
assert iv(a['temperature']) == (F('299.9999999'), F('300.0000001'))
for key in ('temperature', 'liquid_molar_density', 'effective_available_volume'):
    assert a[key] == m[key]
corners = []
for t,v,rho,s in product(iv(a['temperature']), iv(a['effective_available_volume']), iv(a['liquid_molar_density']), iv(a['liquid_volume_scale'])):
    gas_volume = v - nl*s/rho
    assert gas_volume > 0
    corners.append(ng*rg*t/gas_volume)
encloses(m['pressure'], corners)
assert iv(m['lower_residual'])[1] < 0 < iv(m['upper_residual'])[0]
assert iv(m['liquid_pressure_derivative'])[0] > 0
assert iv(m['total_residual_derivative'])[0] > 0
liquid = iv(case['domain']['density'][0]); rho = iv(a['liquid_molar_density'])
assert liquid[1] < rho[0]
assert iv(tube['density']) == (liquid[0], rho[1])
queue = deque([iv(tube['density'])]); positive = []
for visit in tube['visits']:
    box = queue.popleft()
    assert iv(visit['density']) == box
    dlo, dhi = iv(visit['derivative'])
    if visit['decision'] == 'positive':
        assert dlo > 0
        positive.append(box)
    else:
        assert visit['decision'] == 'split' and dlo <= 0 < dhi
        mid = sum(box)/2
        queue.extend([(mid, box[1]), (box[0], mid)])
assert not queue and not tube['pending']
leaves = list(map(iv, tube['leaves']))
assert leaves == sorted(positive)
assert leaves[0][0] == liquid[0] and leaves[-1][1] == rho[1]
assert all(left[1] == right[0] for left, right in zip(leaves, leaves[1:]))
assert tube['evaluations_attempted'] == tube['evaluations_completed'] == len(tube['visits']) == 31
assert tube['maximum_boxes'] == r['maximum_tube_boxes'] == 256
assert tube['elapsed_seconds'] < tube['maximum_wall_seconds'] == r['tube_wall_budget_seconds'] == 15
assert tube['source_before'] == tube['source_after'] == [case['source_sha256'], r['frozen_sha256'][str(BASE/'interval_eos.py')]]
assert r['saturation_pressure'] == case['pressure']
ambiguity = max(F(.01), F(2e-8)*iv(case['pressure'])[1])
assert F(r['ambiguity_upper_pa']) >= ambiguity
exact_gap = iv(m['pressure'])[0] - iv(case['pressure'])[1] - F(r['ambiguity_upper_pa'])
assert 0 < F(r['pressure_separation_lower_pa']) <= exact_gap
assert tube['proved'] and r['proved_connected_local_branch'] and r['status'] == 'proved_local_connection'
assert not r['global_phase_admission'] and not r['native_error_admission']
assert r['error_envelope_classification'] == storage['fluid_template']['envelope']['method'] == 'manufactured-explicit-error-envelope'
out = {'status':'PASS', 'result_sha256':sha(ROOT/'connected-tube-result01.json'), 'source_hashes_current_match':True, 'visits':31, 'exact_cover_positive_leaves':len(leaves), 'saved_gap_is_outward_lower_bound':True, 'scale_exact_fraction':str(scale), 'tube_elapsed_seconds':tube['elapsed_seconds'], 'study_elapsed_seconds':r['elapsed_seconds'], 'eos_calls':0, 'scope':'Saved exact algebra and source audit; conditional local branch connection only'}
with (ROOT/'review_connected_result01.json').open('x') as stream:
    stream.write(json.dumps(out, indent=2)+'\n')
print(json.dumps(out, indent=2))
