"""Exact rational arithmetic examples; no kernel imports, native calls or data fits."""
from fractions import Fraction as F
import json
from pathlib import Path

def main():
    d=F(1,10**12);na=F(2);nb=na-F(1,10**10)
    constant_errors=[abs((na-nb)*theta) for theta in (-d,d)]
    shared_bound=abs(na-nb)*d
    assert max(constant_errors)==shared_bound
    independent_worst=(na+nb)*d
    assert independent_worst>shared_bound
    # The same per-state envelope alone admits opposite endpoint errors at
    # arbitrarily close but unequal temperatures. A single deterministic
    # function can interpolate these values; provider identity doesn't forbid it.
    dt=F(1,10**8);vl_error=F(1,10**16);nl=F(1,10**6)
    volume_jump=2*nl*vl_error
    assert volume_jump>0
    assert volume_jump==nl*(vl_error-(-vl_error))
    # A genuinely certified derivative bound supplies the missing inequality.
    L=F(1,10**8);vmax=F(2,10**5);dna=F(1,10**12)
    liquid_pair=dna*vmax+nl*L*dt
    gas_compliance=F(1,1000)*F(8314,1000)*F(295)/F(42000)**2
    result={'classification':'manufactured_exact_arithmetic_thoughtcases_not_water_evidence',
        'shared_constant_solid_error_volume_bound_m3':str(shared_bound),
        'independent_solid_error_volume_bound_m3':str(independent_worst),
        'unconstrained_liquid_error_jump_m3':str(volume_jump),
        'chosen_hypothetical_liquid_L_m3_mol_k':str(L),
        'conditional_liquid_pair_volume_bound_m3':str(liquid_pair),
        'conditional_gas_compliance_lower_m3_pa':str(gas_compliance),
        'conditional_liquid_contribution_pa':str(liquid_pair/gas_compliance),
        'status':'passed','native_eos_calls':0}
    Path(__file__).with_name('thoughtcases-result.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
