# Independent mathematical and provider-contract design review

Inspected DESIGN.md SHA256 042bf741a958a7fefa39bda52e46a5357c0b562b58a7e17a07c2b25622781585 and actual current_solid_storage.py, solid_fluid_storage.py, rigid_storage.py and incompressible_solid.py. Read-only, no EOS or native execution.

Verdict: APPROVE the final reported-temperature mathematical design, conditional on the explicit prerequisites below. This is not approval of an actual wet provider certificate or event adoption; those implementations and evidence are outstanding.

## Root-difference proof

For every admissible shared parameter realization theta, B's true nominal-temperature root must belong to IB and both roots must belong to I. If -FA'(p;theta)>=C>0 throughout the segment between the roots, monotonicity gives C*abs(pA-pB)<=abs(FA(pB;theta)-FB(pB;theta)). A uniform interval enclosure of FA-FB over IB and all admitted theta therefore gives the stated bound. The gas contribution GA*R*TA/pU^2 suffices for A when GA,R,TA are positive and liquid compliance is nonnegative on all of I. The symmetric minimum of A/B gas compliances is conservative, not necessary. Swapped orientations can independently be bounded and their minimum taken.

This proof needs no claim that residuals vanish at the reported floating-point pressure. Residual, numerical volume, and represented-geometry errors must already be retained in the root enclosures and in the intended closure definition. Root IB cannot be a mere numerical-forward bracket that excludes declared parameter uncertainty. The existing independently certified pressure_error fields, including the solid/current-volume enlargement, must be used; constructing P +/- error must itself round outward. A narrowed bracket must remain valid for every retained parameter realization, not merely the nominal equation.

The arbitrary-pivot counterexample is correct. Differences at one pivot cannot replace the supremum over the root interval absent another derivative/modulus proof. The final algorithm avoids that error. Pressure intervals, endpoint liquid bounds and all signed algebra require outward arithmetic; gas coefficient sign determines reciprocal interval ordering. Preserve signed nominal solid/geometry/gas contributions in interval addition before taking maximum absolute endpoint. Early absolute values remain safe but can destroy useful cancellation.

## Correlation and provider prerequisites

The actual IncompressibleSolidPhase returns constant nominal molar volume but only declares a magnitude for volume error. Its type, identity property and source IDs do not prove that the unknown error is one shared state-independent offset. Likewise CurrentSolidStorage transports a template bulk-volume bound using J and records known representation discrepancies, but does not by itself establish a shared physical reference-volume-error model. Thus the final design correctly requires a new explicit, immutable and source-bound uncertainty contract; inferring correlation from current class identity alone would be a HIGH blocker for implementation/adoption.

The contract must identify the same actual constant parameter and its error interpretation, reference cell/grid/geometry, represented parameter values, complete provider content and source evidence. Two otherwise identical providers with an unrestricted state-dependent discrepancy do not satisfy it. Existing extra errors remain independent unless separately proved. If existing declarations are unstructured approximation errors, relabeling them as shared constants is a change of uncertainty semantics, even if JSON numbers are unchanged. Such narrowing needs explicit evidence and qualification, or the paired method must return unavailable. The thoughtcase showing opposite endpoint errors is essential.

For known deterministic geometry discrepancies, reconstruct the signed exact difference of the actual represented closure and intended reference geometry, including intermediate volume/subtraction rounding. Do not merely subtract two nonnegative error magnitudes and treat that as a signed correction. Unknown additional volume discrepancies still add their bounds. An implementation must state which closure its exact nominal volume represents so no representation correction is omitted or counted twice.

## Wet endpoint route and output interpretation

At each reported temperature, stable pressure monotonicity plus retained absolute endpoint volume errors encloses the true nominal-temperature liquid volume throughout IB. Four endpoint calls per fully wet cell pair are sufficient for this basic construction, provided the same true-law monotonicity/point-error contract applies throughout IB and the original domain guards remain. Point derivative samples alone do not certify this condition. It may be retained as the same explicitly conditional stability assumption used in the old enclosure; it must not become a newly claimed independent water theorem.

The resulting pressure comparison is conditional on the reported temperatures. Keeping the separate existing temperature gate with both inverse errors preserves the currently documented split-gate semantics. It is not a pressure uncertainty tube over unknown inverse temperatures. The full T/P uncertainty objective remains open and must remain visible in results/provenance.

No inference that this method meets 1e-4 Pa follows from this design. Broad liquid intervals can still dominate. Actual validation must retain all four compared cell pairs across event/common states, original pressure and other five gates, true B-root interval evidence and resource costs. A last-accepted-state probe is a legitimate preliminary check but cannot substitute for the unavailable rejected event/common pair inputs or satisfy event adoption gates. No gate relaxation, extra temporal refinement, or shrinking declared parameter errors is justified by this review.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass for conditional design |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE conditional design. Correlation-provider proof, actual wet candidate review and four-pair evidence remain mandatory before event adoption.
