# Independent saved paired-pressure probe review

APPROVE the bounded conditional point-probe interpretation. No EOS or production kernel/audit was imported or rerun by this reviewer. audit_probe.py SHA256 dcd045f58bd47f39a153626ec84e877f093943e5da8c974c61c253f5d9e5159b ran successfully using standard-library Fraction arithmetic. It reconstructs all four saved certificates independently; it does not establish actual root containment or liquid stability anew.

Both scripts evaluate two represented states at the old last accepted time, not an event trajectory. The original probe changes the two total energies by opposite nextafter directions; both decoded nominal pressure differences are zero, so that result alone is not nonzero-signal evidence. The separately retained conservative-neighbor probe shifts exactly 2^-40 mol liquid to vapor in each cell. Independent input checks confirm exact binary-rational water-mole conservation, unchanged other inventories, total energy, mechanical stretches and energy identity. This is a manufactured nearby state, not a physical integrated phase-transfer step.

For conservative neighbors, both reported nominal differences are 3.601599019020796e-5 Pa. Independent interval reconstruction gives 3.7279046257925916e-5 and 3.740555804444724e-5 Pa, matching the saved outward certificate bounds and passing the unchanged 1e-4 Pa point comparison. The original zero-nominal-difference pair gives bounds 4.124228079370948e-10 and 4.043132300170347e-10 Pa. Each cell pair retains four actual endpoint outputs and endpoint_evaluations=4. No-contract paths retain unavailable; explicit boxes are recorded separately.

The independent script checks runtime before/after equality, every current module byte hash against recorded hashes, original pre-existing module identity, original last state/time, registered case SHA, exact input-record certificate SHA, consistent pair/source identifiers, box-to-kernel parameter equality, actual inventories and Jacobians, endpoint temperature/pressure/phase and shared reference/implementation, endpoint mass/density volume conversion and unchanged declared liquid error plus division rounding. It separately reconstructs signed gas/solid/geometry residual intervals, correlated reference/solid allowances, additive independent allowances, joint-interval compliance, independent root-interval distance cap and outward final bound. All comparisons pass. This verifies saved certificate arithmetic and content consistency; complete operator digest generation and original root admissibility remain backed by the reviewed host and runtime, not independently reconstructed physical proofs here.

Portable test deltas are import-only: pure/host tests now import production modules; PreparedPair.certify test imports the real production pure kernel instead of an isolated sys.modules overlay. Test behavior/assertions are otherwise preserved. Source candidates correspond to reviewed pure e40f376f4cacf60efb05aac16a488913534f640074558937d252e49ca2e3118f and host bcf0613816fb339d2b45ee21f4374d1289399292652adfffc94799103962edc6.

The result applies only to the explicit NEW manufactured shared-constant parameter-box contract at reported nominal temperatures. It does not retroactively satisfy the old failed experiment, certify a full pressure tube over inverse-temperature uncertainty, cover actual event/common comparison states, or adopt paired pressure into event acceptance. Those limitations are preserved in the saved probe qualifications. No blocking issue found for this limited claim.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE bounded conditional saved-point evidence; full event and material validation remain outstanding.
