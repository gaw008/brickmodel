from pathlib import Path
from dataclasses import replace
from fractions import Fraction
import json,time,math
from sludge_sandbox.verification_case import read_case,build_case,encode
from sludge_sandbox.event_record import state
from sludge_sandbox.run_service import runtime_identity
from sludge_sandbox.paired_pressure_host import prepare_paired_pressure,declare_manufactured_constant_box,PairedPressureUnavailable
r=Path('/private/tmp/brick-paired-pressure-native-v1/conservative-neighbor');previous=Path('/private/tmp/brick-free-native-events-v1');started=time.monotonic()
def save(name,value):(r/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
old=json.loads((previous/'attempt01/result.json').read_text());before=runtime_identity();save('runtime-before.json',before)
assert all(before['modules'][name]==digest for name,digest in old['runtime_before']['modules'].items())
built=build_case(read_case(previous/'case.json'),previous/'attempt01/water');a=state(old['integration']['states'][-1]);n=a.amounts_mol.copy();li=built.operator.liquid_index;vi=built.operator.water_vapor_index
for cell in range(2):
 n[cell,li]-=2**-40;n[cell,vi]+=2**-40
 assert Fraction(float(n[cell,li]))+Fraction(float(n[cell,vi]))==Fraction(float(a.amounts_mol[cell,li]))+Fraction(float(a.amounts_mol[cell,vi]))
b=replace(a,amounts_mol=n);t=old['integration']['times_s'][-1]
save('inputs.json',{'a':encode(a),'b':encode(b),'time_s':t,'source_case_sha256':built.case.sha256,'classification':'manufactured_arithmetic_neighbor_not_new_trajectory'})
oa=built.operator.evaluate(a,t).base_evaluation;ob=built.operator.evaluate(b,t).base_evaluation
rows=[]
for i in range(2):
 seen=[];ia=oa.total_inverses[i];ib=ob.total_inverses[i]
 unavailable=prepare_paired_pressure(built.operator,a,ia,b,ib,cell_index=i,endpoint_observer=seen.append)
 assert type(unavailable) is PairedPressureUnavailable and not seen
 box=declare_manufactured_constant_box(built.operator.base_model.point_storages[i])
 prepared=prepare_paired_pressure(built.operator,a,ia,b,ib,cell_index=i,shared_constant_parameters=box,endpoint_observer=seen.append)
 certificate=prepared.certify()
 save('pair-'+str(i)+'.json',{'unavailable':encode(unavailable),'new_conditional_contract':encode(box),'prepared':encode(prepared),'endpoints':encode(seen),'certificate':certificate.to_record()})
 rows.append({'cell':i,'endpoint_evaluations':prepared.endpoint_evaluations,'bound_pa':certificate.bound_pa,'original_independent_bound_pa':float(certificate.independent_bound_pa),'nominal_pressure_difference_pa':abs(ia.state.thermal_state.mechanical.pressure_pa-ib.state.thermal_state.mechanical.pressure_pa),'gate_pa':1e-4,'gate_passed':certificate.bound_pa<=1e-4})
 save('summary.json',{'status':'recorded','rows':rows,'elapsed_seconds':time.monotonic()-started})
 assert len(seen)==prepared.endpoint_evaluations==4
 assert 0<=certificate.bound_pa<=float(certificate.independent_bound_pa)
 assert certificate.bound_pa<=1e-4
 assert rows[-1]['nominal_pressure_difference_pa']>0
assert before==runtime_identity();save('runtime-after.json',runtime_identity())
save('summary.json',{'status':'passed_conditional_single_pair_probe','rows':rows,'elapsed_seconds':time.monotonic()-started,'original_failed_event_status':'unchanged_failed','event_integration':'not_adopted'})
print((r/'summary.json').read_text())
