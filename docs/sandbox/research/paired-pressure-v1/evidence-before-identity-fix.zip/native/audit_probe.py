"""Independent saved-data arithmetic only; no production or EOS imports."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,math
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')
OLD=Path('/private/tmp/brick-free-native-events-v1')
def read(p):return json.loads(p.read_text())
def q(x):
 if isinstance(x,dict):
  assert set(x)=={'numerator','denominator'} and type(x['numerator']) is int and type(x['denominator']) is int and x['denominator']>0
  return F(x['numerator'],x['denominator'])
 assert type(x) in (int,float) and math.isfinite(x)
 return F(x)
def iv(x):return tuple(map(q,x))
def sha(b):return hashlib.sha256(b).hexdigest()
def run():
 old=read(OLD/'attempt01/result.json'); rows=[]
 for folder in (ROOT,ROOT/'conservative-neighbor'):
  before=read(folder/'runtime-before.json');assert before==read(folder/'runtime-after.json')
  for name,digest in old['runtime_before']['modules'].items():assert before['modules'][name]==digest
  for name,digest in before['modules'].items():assert sha((REPO/'src/sludge_sandbox'/name).read_bytes())==digest
  data=read(folder/'inputs.json');assert data['a']==old['integration']['states'][-1] and data['time_s']==old['integration']['times_s'][-1]
  assert data['source_case_sha256']==sha((OLD/'case.json').read_bytes())
  astate,bstate=data['a'],data['b'];assert astate['mechanical_stretches']==bstate['mechanical_stretches'] and astate['energy_model_identity']==bstate['energy_model_identity']
  if folder.name=='conservative-neighbor':
   assert astate['internal_energy_j']==bstate['internal_energy_j']
   for aa,bb in zip(astate['amounts_mol'],bstate['amounts_mol']):
    assert q(bb[2])-q(aa[2])==F(1,2**40) and q(bb[3])-q(aa[3])==-F(1,2**40)
    assert all(aa[j]==bb[j] for j in (0,1,4)) and q(bb[2])+q(bb[3])==q(aa[2])+q(aa[3])
  else:
   assert astate['amounts_mol']==bstate['amounts_mol']
   assert bstate['internal_energy_j']==[math.nextafter(astate['internal_energy_j'][0],math.inf),math.nextafter(astate['internal_energy_j'][1],-math.inf)]
  summary=read(folder/'summary.json');assert summary['original_failed_event_status']=='unchanged_failed' and summary['event_integration']=='not_adopted'
  for i in range(2):
   saved=read(folder/f'pair-{i}.json');p=saved['prepared'];c=saved['certificate'];inp=c['input_record_json'];a,b,s=inp['a'],inp['b'],inp['shared']
   assert sha(json.dumps(inp,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==c['input_sha256']
   assert all(p[k]==v for k,v in inp.items())
   assert c['source_identity']==a['source_identity']==b['source_identity']==s['source_identity']==p['source_identity']
   assert s['contract']=='manufactured_shared_constant_volume_parameters_v1' and not c['temperature_uncertainty_included'] and not c['material_qualified']
   box=saved['new_conditional_contract'];assert box['schema']==s['contract']
   for key in ('species','solid_volume_m3_mol','solid_error_m3_mol','reference_volume_m3','reference_error_m3'):assert box[key]==s[key]
   assert saved['unavailable']['reason']=='explicit_shared_constant_parameter_box_not_declared'
   assert p['endpoint_evaluations']==len(saved['endpoints'])==4
   for label,st,raw in [('a',a,astate),('b',b,bstate)]:
    n=raw['amounts_mol'][i];assert q(st['gas_mol'])==q(n[2])+q(n[4]) and q(st['liquid_mol'])==q(n[3]) and iv(st['solid_mol'])==(q(n[0]),q(n[1]))
    stretch=raw['mechanical_stretches'];assert q(st['jacobian'])==q(stretch[i])*q(stretch[-1])**2
   common=iv(b['root_interval_pa']);joint=(min(q(a['root_interval_pa'][0]),common[0]),max(q(a['root_interval_pa'][1]),common[1]))
   liquid=[]
   for offset,st,label in [(0,a,'liquid_a'),(2,b,'liquid_b')]:
    ep=inp[label];assert iv(ep['pressure_interval_pa'])==common
    for j,key in [(0,'lower'),(1,'upper')]:
     actual=saved['endpoints'][offset+j]
     assert actual['reference']==saved['endpoints'][0]['reference'] and actual['implementation']==saved['endpoints'][0]['implementation']
     assert actual['phase']=='liquid' and q(actual['temperature_k'])==q(st['temperature_k']) and q(actual['pressure_pa'])==common[j]
     exact=q(actual['reference']['molar_mass_kg_mol'])/q(actual['density_kg_m3']);represented=F(float(exact))
     assert q(ep[f'volume_at_{key}_m3_mol'])==represented
     declared=q(read(OLD/'case.json')['numerics']['envelope']['liquid_v_error_m3_mol'])
     assert q(ep[f'error_at_{key}_m3_mol'])==declared+abs(represented-exact)
    liquid.append((q(st['liquid_mol'])*(q(ep['volume_at_upper_m3_mol'])-q(ep['error_at_upper_m3_mol'])),q(st['liquid_mol'])*(q(ep['volume_at_lower_m3_mol'])+q(ep['error_at_lower_m3_mol']))))
   gasnum=q(inp['gas_constant_j_mol_k'])*(q(a['gas_mol'])*q(a['temperature_k'])-q(b['gas_mol'])*q(b['temperature_k']))
   gas=sorted((gasnum/common[0],gasnum/common[1]));dn=[x-y for x,y in zip(iv(a['solid_mol']),iv(b['solid_mol']))]
   nominal=sum((n*v for n,v in zip(dn,iv(s['solid_volume_m3_mol']))),F())+q(b['bulk_volume_m3'])-q(a['bulk_volume_m3'])
   error=sum((abs(n)*e for n,e in zip(dn,iv(s['solid_error_m3_mol']))),F())+abs(q(a['jacobian'])-q(b['jacobian']))*q(s['reference_error_m3'])+q(a['independent_volume_error_m3'])+q(b['independent_volume_error_m3'])
   residual=(liquid[0][0]-liquid[1][1]+gas[0]+nominal-error,liquid[0][1]-liquid[1][0]+gas[1]+nominal+error)
   compliance=min(q(a['gas_mol'])*q(a['temperature_k']),q(b['gas_mol'])*q(b['temperature_k']))*q(inp['gas_constant_j_mol_k'])/joint[1]**2
   pair=max(map(abs,residual))/compliance;independent=max(abs(q(a['root_interval_pa'][0])-common[1]),abs(q(a['root_interval_pa'][1])-common[0]));bound=min(pair,independent)
   assert residual==iv(c['residual_interval_m3']) and compliance==q(c['compliance_lower']) and pair==q(c['pair_bound_pa']) and independent==q(c['independent_bound_pa']) and bound==q(c['exact_bound_pa'])
   assert q(c['bound_pa'])>=bound and q(c['bound_pa'])-bound<=q(math.ulp(c['bound_pa'])) and c['bound_pa']<=1e-4
   row=summary['rows'][i];assert row['bound_pa']==c['bound_pa'] and row['gate_passed']
   rows.append({'probe':folder.name,'cell':i,'bound_pa':c['bound_pa'],'nominal_difference_pa':row['nominal_pressure_difference_pa'],'arithmetic':'passed'})
 return rows
if __name__=='__main__':print(json.dumps(run(),indent=2))
