"""No EOS: adapter refusal plus exact volume accounting helpers, not wet validation."""
from fractions import Fraction as F
from pathlib import Path
from types import SimpleNamespace as NS
import importlib.util
import sys
import math
import pytest

spec=importlib.util.spec_from_file_location('paired_pressure_host_candidate',Path(__file__).with_name('paired_pressure_host.py'))
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)


def test_generic_contract_unavailable_without_provider_or_water_calls():
 def forbidden(*args):raise AssertionError('water called')
 result=m.prepare_paired_pressure(None,None,None,None,None,cell_index=0,endpoint_observer=forbidden)
 assert isinstance(result,m.PairedPressureUnavailable)
 assert result.original_pressure_errors_pa is None
 assert result.qualification=='original_independent_point_certificate_unchanged'

@pytest.mark.parametrize('untyped',[True,{},'manufactured_shared_constant_volume_parameters_v1'])
def test_untyped_correlation_claim_refused(untyped):
 with pytest.raises(m.PairedPressureHostError,match='typed_shared'):
  m.prepare_paired_pressure(None,None,None,None,None,cell_index=0,shared_constant_parameters=untyped)


def test_typed_box_does_not_admit_arbitrary_provider():
 box=m.SharedConstantParameterBox('fake',('A',),(F(1),),(F(0),),F(1),F(0))
 with pytest.raises(m.PairedPressureHostError,match='direct_actual'):
  m.prepare_paired_pressure(None,None,None,None,None,cell_index=0,shared_constant_parameters=box)

@pytest.mark.parametrize('p,e',[(F(100000),F(1,10**10)),(F(100000),F(0)),(F(1),F(1,3))])
def test_root_endpoints_outward_preserve_full_original_interval(p,e):
 lo,hi=m._outward_root(p,e,(F(1,10),F(200000)))
 assert lo<=p-e<=p+e<=hi
 assert lo==F(float(lo)) and hi==F(float(hi))
 assert p-e-lo<=F(math.ulp(float(lo)))
 assert hi-p-e<=F(math.ulp(float(hi)))


def test_outward_root_must_stay_in_original_domain():
 with pytest.raises(m.PairedPressureHostError,match='outside_domain'):
  m._outward_root(F(1),F(1,3),(F(2,3),F(4,3)))


def volume_fixture(extra):
 # Explicit algebra helper fixture, not a fabricated material/water provider.
 ref=NS(reference_area_m2=.01,half_thickness_m=.02,cells=2)
 v0=F(.01)*F(.02)/2
 point=NS(skeleton=NS(reference=ref),template=NS(bulk_volume_m3=float(v0),bulk_volume_error_m3=1e-18),
          error_bounds=NS(additional_bulk_volume_error_m3=extra))
 j=F(.97)*F(.99)**2;volume=float(j*v0)
 shared=F(1e-18)+abs(F(float(v0))-v0)
 raw=j*shared+abs(F(volume)-j*v0)+F(extra)
 upper=float(raw)
 if F(upper)<raw:upper=math.nextafter(upper,math.inf)
 current=NS(bulk_volume_m3=volume,bulk_volume_error_m3=upper,solid_phases={'A':NS(molar_volume_m3_mol=2e-5)})
 return point,current,{'A':2.},j


def test_additional_error_never_enters_shared_cancelled_reference_error():
 base=m._volume_terms(*volume_fixture(0.))
 changed=m._volume_terms(*volume_fixture(1e-12))
 assert base[:3]==changed[:3]
 assert changed[3]>=F(1e-12)
 # Outward rounding may differ, so exact difference need not equal added input.
 assert abs((changed[3]-base[3])-F(1e-12))<=F(math.ulp(1e-12))


def test_underreported_prepared_bulk_error_refused():
 point,current,solids,j=volume_fixture(1e-12);current.bulk_volume_error_m3=0.
 with pytest.raises(m.PairedPressureHostError,match='bulk_error_mismatch'):
  m._volume_terms(point,current,solids,j)


def test_prepared_pair_matches_frozen_pure_kernel_api(monkeypatch):
 path=Path('/private/tmp/brick-paired-pressure-candidate/paired_pressure.py')
 spec=importlib.util.spec_from_file_location('sludge_sandbox.paired_pressure',path)
 kernel=importlib.util.module_from_spec(spec);monkeypatch.setitem(sys.modules,spec.name,kernel);spec.loader.exec_module(kernel)
 identity='a'*64
 state=kernel.PressureState(identity,F(300),F(1),F(0),(F(1),),F(10),F(1),F(0),(F(33),F(34)))
 shared=kernel.SharedVolumes(identity,('A',),(F(1),),(F(1,1000),),F(10),F(1,1000))
 pair=m.PreparedPair(state,state,shared,None,None,F(1),(F(1),F(100)),(F(290),F(310)),0,
                     (F(1,2),F(1,2)),(F(1,1000),F(1,1000)),identity)
 certificate=pair.certify()
 assert certificate.exact_bound_pa==0
 assert pair.endpoint_evaluations==0
 assert pair.original_temperature_errors_k==(F(1,1000),F(1,1000))
 assert certificate.to_record()['temperature_uncertainty_included'] is False
