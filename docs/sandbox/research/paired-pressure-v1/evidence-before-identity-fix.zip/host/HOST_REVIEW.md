# Independent host-adapter review

Reviewed frozen paired_pressure_host.py SHA256 89c86b42689d24c4e01586d1eebeb19615e5e57785fad20ce6565f8a1611167f, test_paired_pressure_host.py and actual provider state/type contracts. Author attempt02 reports 11 passed helper/refusal tests. Reviewer did not run tests or EOS. A full positive native host execution is still outstanding and is an explicit prerequisite to stronger claims.

Default None returns unavailable with original point errors, requiring no endpoint calls. Opt-in is a separate typed manufactured parameter-box hypothesis, equality-bound to the actual point digest, phases, reference and unchanged declared magnitudes. It is not inferred from source IDs or claimed to prove correlation of the original generic pointwise uncertainty. The exact reacting CurrentSolidStorage/FreeSolidSlab/WaterPhaseTransfer admission prevents a generic supplied provider from being mislabeled as the actual host.

_point binds original energy target/model identity, complete represented state inventories, all normals/common tangent, actual reconstructed storage and skeleton, cell identity and domains. Existing pressure uncertainty is retained and outward-rounded to representable endpoint pressures without clipping. Current bulk discrepancy, additional errors, available-volume rounding and outward-bound enlargement remain independent. Nominal bulk-volume signs match FA-FB. Both inverse-temperature errors remain separately recorded; this is explicitly a nominal-temperature certificate, not an inverse-temperature pressure tube.

Endpoint calls now use bound water.state_tp(..., phase='liquid'). Actual WaterState inherits reference, implementation and molar_mass_kg_mol; its phase, density, temperature and pressure fields match extraction. The current HEOS wrapper returns this exact WaterState with the requested liquid phase and its hybrid implementation/reference. Full operator digest and typed box are checked again after endpoints. The earlier public water_call could supply arbitrary matching-metadata WaterState values and was a blocking evidence-path risk; frozen code removes it. The optional observer return is ignored and cannot replace the supplied state. No alternate source response is admitted through that API.

Liquid intervals use the original numerical volume allowance plus represented division discrepancy. Pressure monotonicity remains the same conditional stable-liquid assumption underlying the original point enclosure, not a newly proved water-domain theorem. Full actual wet probe is necessary to check runtime compatibility and behavior; helper tests alone do not establish it. Zero liquid skips source calls and independent additional bounds are not correlated away.

No blocking defect found for this isolated explicit manufactured-hypothesis adapter. Approval permits the separately bounded actual pair probe, not adopting the method into event acceptance. The old failed record remains failed. Every event/common cell comparison, original gates, complete serialized paired evidence and fallback handling remain future integration obligations.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE for the stated conditional candidate scope, not event adoption or material qualification.

## Final backend-binding revision

Final approved host SHA256 bcf0613816fb339d2b45ee21f4374d1289399292652adfffc94799103962edc6. Read-only verification confirms the final water-content predicate additionally requires identical concrete provider types and identical implementation objects/descriptors between actual thermal water and chemical water, alongside existing content digest equality. This closes the backend distinction not represented by the water digest alone. The source-bound actual endpoint implementation and final complete operator/box checks remain. Author attempt04 reports 12 no-EOS tests including an actual pure-kernel PreparedPair.certify interface call; this is still not a positive native host execution. APPROVE this final hash under the same conditional scope above.
