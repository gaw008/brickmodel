# Independent pure-kernel review

Reviewed frozen paired_pressure.py SHA256 e40f376f4cacf60efb05aac16a488913534f640074558937d252e49ca2e3118f and complete test_paired_pressure.py. Author tests02 reports 19 passed; reviewer read tests and did not rerun or call EOS.

The exact Fraction interval implementation matches the approved reported-temperature proof. B's complete supplied root interval is the sole evaluation interval; the joint A/B root enclosure sets the conservative gas compliance. It preserves signed gas, nominal solid and actual bulk-volume differences before taking the residual absolute maximum. Shared errors use actual inventory/J differences, while independent volume errors and liquid endpoint errors add. The independent interval-separation bound remains an independently valid cap. Outward conversion rejects nonrepresentable positive results rather than underreporting them. Input digest includes all state/box/endpoint/domain inputs; source identities must agree and data containers are frozen with exact Fraction leaves.

Root containment, stable-liquid monotonicity and the manufactured shared-constant parameter semantics are explicitly provider preconditions, not established by this algebra kernel. SharedVolumes only accepts the new manufactured contract; this must never be treated as proof that generic original pointwise errors correlate. The adapter remains responsible for genuine evidence and original-source binding. No numerical gate is in the kernel or altered by it.

Tests use independent rational closure bisection for analytic wet corner roots, unequal inventories/temperatures/geometry, nonzero shared errors and independent extra errors. They also retain wet equal-input uncertainty, independently signed liquid shifts, arbitrary-pivot refusal, source/domain/type/geometry guards and exact dry zero behavior. These are algebra/guard tests, not actual water certification. The geometry discrepancy is retained conservatively as an independent allowance even with the signed nominal bulk-volume difference; this can overestimate the bound but is not an omitted-error issue.

No blocking defect found in the reviewed scope. Passing the actual unchanged pressure gate remains unproved until actual host pairs are evaluated and every prerequisite is met.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE for the stated conditional candidate scope, not event adoption or material qualification.
