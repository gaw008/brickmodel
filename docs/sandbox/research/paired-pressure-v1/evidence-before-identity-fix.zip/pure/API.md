# Frozen pure paired-pressure API

Module: `/private/tmp/brick-paired-pressure-candidate/paired_pressure.py`; eventual import `sludge_sandbox.paired_pressure`. No EOS imports or calls. All numeric input fields MUST have exact type fractions.Fraction (use Fraction(actual_float), not decimal text reconstruction). All arrays are tuples. Source identities are identical lower-case SHA256 strings binding actual provider/reference/constant-parameter box. Explicit adapter admission is required: merely constructing these data does not prove source qualification or root containment.

```python
@dataclass(frozen=True)
class PressureState:
    source_identity: str
    temperature_k: Fraction
    gas_mol: Fraction
    liquid_mol: Fraction
    solid_mol: tuple[Fraction, ...]
    bulk_volume_m3: Fraction
    jacobian: Fraction
    independent_volume_error_m3: Fraction
    root_interval_pa: tuple[Fraction, Fraction]

@dataclass(frozen=True)
class SharedVolumes:
    source_identity: str
    species: tuple[str, ...]
    solid_volume_m3_mol: tuple[Fraction, ...]
    solid_error_m3_mol: tuple[Fraction, ...]
    reference_volume_m3: Fraction
    reference_error_m3: Fraction
    contract: str = 'manufactured_shared_constant_volume_parameters_v1'

@dataclass(frozen=True)
class LiquidEndpoints:
    source_identity: str
    temperature_k: Fraction
    pressure_interval_pa: tuple[Fraction, Fraction]
    volume_at_lower_m3_mol: Fraction
    volume_at_upper_m3_mol: Fraction
    error_at_lower_m3_mol: Fraction
    error_at_upper_m3_mol: Fraction
    qualification: str = 'stable_liquid_pressure_monotone_reported_temperature_v1'

def certify_paired_pressure(a, b, shared, *,
    gas_constant_j_mol_k: Fraction,
    pressure_domain_pa: tuple[Fraction, Fraction],
    temperature_domain_k: tuple[Fraction, Fraction],
    liquid_a: LiquidEndpoints | None,
    liquid_b: LiquidEndpoints | None,
) -> PairedPressureCertificate: ...
```

Endpoints for BOTH liquids must use exactly `b.root_interval_pa`. The adapter may outward-round B interval to representable native P endpoints before creating the PressureState and LiquidEndpoints; both must describe that same complete certified interval. Zero liquid requires None and no fake evaluation. Nonzero liquid requires actual endpoints with retained absolute errors. The joint A/B interval defines gas compliance. No arbitrary pivot argument exists.

`bulk_volume_m3` is actual current nominal storage volume; `jacobian*reference_volume_m3` discrepancy MUST be included in independent_volume_error_m3. Shared reference/solid errors are correlated constants only under the explicit manufactured parameter-box interpretation. Unstructured additional errors add independently. Original provider point errors are not changed. All available-volume positivity and declared T/P domains remain checked.

Result frozen fields: bound_pa (finite upward float), exact_bound_pa (Fraction minimum), pair_bound_pa (Fraction before minimum), independent_bound_pa (Fraction cross-root-interval bound), compliance_lower (Fraction m3/Pa), residual_interval_m3, common_pressure_interval_pa, joint_pressure_interval_pa, decomposition (tuple of named signed Fraction interval terms), source_identity, input_record_json (immutable canonical JSON bytes), input_sha256, qualification. `.to_record()` returns detached JSON-friendly record, all Fractions as exact numerator/denominator objects, material_qualified=false and temperature_uncertainty_included=false.

Errors raise PairedPressureError(ValueError) before output, including source/domain/shape mismatches, absent wet endpoints, unsupported shared/error contract, absent positive gas compliance, and nonzero underflow/overflow at outward float boundary. The adapter retains default-unavailable semantics and decides fallback to original independent comparison; the pure kernel never reclassifies an unknown provider contract automatically.

The certificate is conditioned on reported temperatures and pre-certified root containment/stable liquid pressure monotonicity. Original independent T gate stays unchanged. This is not a combined T/P uncertainty tube or real-material admission.
