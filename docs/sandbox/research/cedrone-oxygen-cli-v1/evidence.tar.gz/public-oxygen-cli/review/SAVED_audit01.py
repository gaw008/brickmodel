"""Bounded saved CLI audit: JSON/Fraction and saved profile only, no model imports."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json, math, pstats, xml.etree.ElementTree as ET
W=Path('/private/tmp/sludge-tp-equilibrium-v1'); D=W/'public-oxygen-cli'; O=D/'native01'; C=O/'calculation'; ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
def hook(d): return F(d['numerator'],d['denominator']) if set(d)=={'numerator','denominator'} and all(type(x)is int for x in d.values()) else d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def sha(p):return sha256(p.read_bytes()).hexdigest()
def wire(v):
 if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
 if isinstance(v,dict):return {k:wire(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [wire(x) for x in v]
 return v
checks=[]
def check(k,v):checks.append({'name':k,'passed':bool(v)})
I=read(C/'INPUT.json');R=read(C/'RESULT.json');A=read(C/'OBSERVABLES.json');S=read(C/'STATUS.json');P=read(O/'STATUS.json');M=read(O/'supervision/metadata.json');Q=read(O/'supervision/status.json')
B=W/'finite-oxygen-execution/native01/point01';old=read(B/'RESULT.json');oldi=read(B/'INPUT.json');olda=read(B/'OBSERVABLES.json')
E=['C','H','O','N','S'];source_path=ROOT/'data/sandbox/research/cedrone2024-element-pool-v1/printed-pool.json';source=read(source_path);d=I['derivation'];weights={e:F(I['element_reads'][e]['weight_kg_kmol']) for e in E};m={e:F(source['printed_values'][e]['printed_wt_percent'])/100 for e in E};b0=[1000*m[e]/weights[e] for e in E];demand=b0[0]+b0[1]/4+b0[4]-b0[2]/2;o2=demand/4;n2=F(79,21)*o2;delta=[F(),F(),2*o2,2*n2,F()];b=[x+y for x,y in zip(b0,delta)];added=sum((weights[e]*delta[j]/1000 for j,e in enumerate(E)),F());Min=F('.704')+added
check('pinned_printed_source_and_frozen_document',sha(source_path)==d['source_sha256']=='92feba43d25479d99a2607466fb902841d0afcffc5b1108ca2ff74a42145f7fd' and d['source_document']==source and sum(m.values(),F())==F('.704') and d['nominal_CHONS_kg']==m)
check('actual_element_reads_and_exact_same_phase_weights',I['runtime']['cantera_version']=='3.2.0' and list(I['element_reads'])==E and all(I['element_reads'][e]['symbol']==e and type(I['element_reads'][e]['weight_kg_kmol'])is float and I['element_reads'][e]['weight_kg_kmol']>0 for e in E) and d['exact_represented_atomic_weights']==weights and all({e:F(R[s]['loaded_definition']['gas_atomic_weights_kg_kmol'][e]) for e in E}==weights for s in ['initial','final']) and d['atomic_weights_binding_checked'] is False and A['atomic_weights_binding_checked'] is True)
check('independent_original_pool_finite_addition_and_full_mass',I['lambda']==d['lambda']==F(1,4) and d['base_element_mol']==b0 and d['reference_O2_demand_mol']==demand and d['added_O2_mol']==o2 and d['added_N2_mol']==n2 and d['element_increment_mol']==delta and d['total_element_mol']==b and d['added_O2_mass_kg']==2*o2*weights['O']/1000 and d['added_N2_mass_kg']==2*n2*weights['N']/1000 and d['added_gas_mass_kg']==added and d['model_input_mass_kg']==Min and d['original_reported_sample_basis_kg']==1)
check('complete_request_policy_same_as_original_case',R['request']==d['pool']==old['request']==oldi['pool'] and R['request']['element_mol']==b and R['request']['temperature_k']==I['temperature_k']==800 and R['request']['pressure_pa']==I['pressure_pa']==100000 and I['policy']==R['policy']==old['policy'] and I['seed_variant']==R['seed']['variant']=='element_basis')
changes=[];leaf_count=[0]
def compare(x,y,path=''):
 if type(x)is not type(y):changes.append({'path':path,'kind':'type','new':str(type(x)),'old':str(type(y))});return
 if isinstance(x,dict):
  for k in sorted(set(x)|set(y)):
   if k not in x or k not in y:changes.append({'path':path+'/'+k,'kind':'new_only' if k not in y else 'old_only'})
   else:compare(x[k],y[k],path+'/'+k)
 elif isinstance(x,list):
  if len(x)!=len(y):changes.append({'path':path,'kind':'length'})
  else:
   for j,(a,c) in enumerate(zip(x,y)):compare(a,c,path+'/'+str(j))
 else:
  leaf_count[0]+=1
  if (x.hex()!=y.hex() if type(x)is float else x!=y):changes.append({'path':path,'kind':'value','new':x,'old':y})
compare(R,old)
allowed={'/elapsed_seconds','/initial/construction_timings_s','/final/construction_timings_s','/provider_identity/construction_input_representation','/provider_identity/yaml_serializer','/provider_identity/yaml_serializer_settings','/provider_identity/yaml_serializer_version'}
check('entire_TP_result_same_except_seven_explicit_metadata_paths',{v['path'] for v in changes}==allowed and len(changes)==7)
check('all_original_module_gates_and_source_qualification',R['status']=='completed' and R['reason'] is None and R['failure'] is None and R['actual_source_properties_checked'] is True and all(v is True for v in R['diagnostics']['checks'].values()) and not R['material_qualified'] and not R['training_eligible'])
loaded=R['final']['loaded_definition'];names=[x['name'] for x in loaded['species']];atoms=[[F(x['composition'].get(e,0)) for e in E] for x in loaded['species']];ref_path=W/'source-reference/REFERENCE.json';ref=read(ref_path);props=[];inventories={}
check('independent_reference_identity_species',sha(ref_path)=='388caee3d17027f64a4ced9bef56d3bb50760daaf28bf4e5d29d928e70c3047d' and names==[v['species'] for v in ref['records']] and len(names)==19)
for label in ['initial','final']:
 s=R[label];n=[F(x)*1000 for x in s['amounts_kmol']];out=[sum((ni*row[j] for ni,row in zip(n,atoms)),F()) for j in range(5)];res=[x-y for x,y in zip(out,b)];inventories[label]=(n,out,res)
 check(label+'_actual_inventory_TP_original_element_gates',len(n)==19 and all(math.isfinite(x) and x>=0 for x in s['amounts_kmol']) and s['temperature_k']==800 and s['pressure_pa']==100000 and all(abs(r)<=F(1,10**10)*(1+abs(be)) for r,be in zip(res,b)))
 for j,record in enumerate(ref['records']):
  p=next(x for x in record['points'] if x['temperature_k']==800)
  for key,rkey,uset in [('standard_cp_j_mol_k','cp_over_R',False),('standard_h_j_mol','h_over_RT',True),('standard_s_j_mol_k','s_over_R',False),('standard_g_j_mol','g_over_RT',True)]:
   expected=float(p['binary64_coefficients'][rkey]['decimal_90_digits']);value=s[key][j]/(s['gas_constant_j_mol_k']*(800 if uset else 1));error=value-expected;limit=2e-10+5e-12*abs(expected);props.append({'state':label,'species':names[j],'property':rkey,'difference':error,'original_tolerance':limit,'passed':math.isfinite(error) and abs(error)<=limit})
check('152_independent_NASA_original_tolerances',len(props)==152 and all(v['passed'] for v in props))
n,out,res=inventories['final'];diag=R['diagnostics'];ng=sum(n[:18],F());masses=[ni*sum((a*weights[e] for a,e in zip(row,E)),F())/1000 for ni,row in zip(n,atoms)];Mout=sum(masses,F());massres=Mout-Min;weighted=sum((weights[e]*r/1000 for e,r in zip(E,res)),F());tri=sum((weights[e]*abs(r)/1000 for e,r in zip(E,res)),F());bound=sum((weights[e]*F(1,10**10)*(1+abs(be))/1000 for e,be in zip(E,b)),F())
check('exact_inventory_diagnostics',n==diag['amounts_mol'] and out==diag['elements_mol'] and res==diag['element_residual_mol'])
check('19_absolute_species_mol_mass_gas_fractions',len(A['species'])==19 and all(v=={'name':names[j],'amount_mol':n[j],'model_mass_kg':masses[j],'gas_mole_fraction':n[j]/ng if j<18 else None} for j,v in enumerate(A['species'])))
check('mass_identity_original_bound_and_basis',A['model_input_mass_kg']==Min and A['model_output_mass_kg']==Mout and A['mass_audit']=={'residual_kg':massres,'weighted_element_residual_kg':weighted,'actual_residual_triangle_bound_kg':tri,'original_element_tolerance_bound_kg':bound} and massres==weighted and abs(weighted)<=tri<=bound and A['element_residual_mol']==dict(zip(E,res)))
check('carbon_and_gas_readouts_no_normalization',A['graphite_carbon_mol']==n[18] and A['graphite_carbon_mass_kg']==masses[18] and A['graphite_carbon_fraction']==n[18]/b0[0] and A['gas_total_mol']==ng)
check('observables_physical_readouts_equal_old',all(A[k]==olda[k] for k in A if k not in {'atomic_weights_binding_checked','basis','qualification'}))
rt=F(R['final']['gas_constant_j_mol_k']*800);Bsum=sum(out,F());G=diag['gibbs_j'];oldG=old['diagnostics']['gibbs_j'];species_limits=[F(1,10**8)+F(1,10**7)*max(abs(x),abs(y)) for x,y in zip(n,old['diagnostics']['amounts_mol'])]
check('unchanged_nominal_comparison_and_G_gates',all(abs(x-y)<=lim for x,y,lim in zip(n,old['diagnostics']['amounts_mol'],species_limits)) and abs(G-oldG)<=rt*sum(b,F())/10**7 and -F(1,10**10)<=diag['scaled_gap_out']<=F(1,10**7) and G<=diag['seed_gibbs_j']+rt*Bsum/10**7 and max(map(abs,diag['active_residuals_over_RT']))<=1e-7)
check('explicit_new_serializer_identity',R['provider_identity']['construction_input_representation']=='ruamel_block_yaml_full_derived_v1' and R['provider_identity']['yaml_serializer']=='ruamel.yaml' and R['provider_identity']['yaml_serializer_version']=='0.19.1' and R['provider_identity']['yaml_serializer_settings']=={'type':'safe','pure':True,'flow_style':False,'sort_mapping_keys':False})
pack=ROOT/'data/sandbox/research/tp-equilibrium-v1';check('physical_source_files_and_model_current_bound',sha(pack/'model.json')==R['provenance']['model_sha256']=='2a0b23f987a0ce4a930ffc9a6a9c682e982676eaa79cfa1af9a4cf40cdad8cfd' and all(sha(pack/f)==h for f,h in R['provenance']['model']['files'].items()))
ident=I['runtime']['code_identity'];expected={'cedrone_oxygen':'c85971c9e03351e86dbe84fde16daadceda106b49e6a6f32ae83a5cc220fc882','tp_equilibrium':'c7b5914070fa55cd0dbf0e0c18230b7b708ddcdbcd57ff80009c00798e184376'}
check('two_actual_runtime_code_files_match_review_and_current_source',set(ident)==set(expected) and all(v['sha256']==expected[k]==sha(Path(v['path']))==sha(ROOT/f'src/sludge_sandbox/{k}.py') and Path(v['path']).stat().st_size==v['bytes'] for k,v in ident.items()) and S['runtime_code_unchanged'] is True)
install=read(D/'INSTALL_IDENTITY01.json');installed=Path(install['installed_root']);check('188_installed_package_files_181_modules_identity',install['all_equal'] and install['package_files']==len(install['rows'])==188 and install['python_modules']==sum(x['file'].endswith('.py') for x in install['rows'])==181 and all(x['equal'] and x['source_sha256']==x['installed_sha256']==sha(ROOT/'src/sludge_sandbox'/x['file'])==sha(installed/x['file']) for x in install['rows']))
suites=list(ET.parse(D/'INSTALLED_TESTS01.xml').getroot().iter('testsuite'));testcases=list(ET.parse(D/'INSTALLED_TESTS01.xml').getroot().iter('testcase'));check('34_installed_tests_including10_publicCLI_cases',sum(int(s.get('tests')) for s in suites)==34 and all(int(s.get(k,'0'))==0 for s in suites for k in ['failures','errors','skipped']) and sum('test_cedrone_oxygen' in t.get('classname','') for t in testcases)==10)
check('four_supervised_inputs_before_after_and_current',len(M['inputs_before'])==4 and set(M['inputs_before'])==set(Q['inputs_after']) and Q['inputs_unchanged'] and all(v['sha256']==Q['inputs_after'][p]==sha(Path(p)) and v['bytes']==Path(p).stat().st_size for p,v in M['inputs_before'].items()))
check('one_fixed_isolated_public_worker',M['command']==[str(W/'runtime/bin/python'),'-I',str(ROOT/'examples/sandbox/run_cedrone_oxygen.py'),'--worker','--source-root',str(ROOT),'--output-dir',str(C),'--lambda','1/4'] and P['status']==S['status']=='completed' and S['new_solve_attempts']==1 and S['attempt_count_final'] and S['result_saved'] and S['atomic_weights_binding_checked'] and R['provider_calls_attempted']==R['provider_calls_completed']==3)
check('original_budgets_terminal_exit_and_reaping',R['elapsed_seconds']<=R['policy']['maximum_elapsed_s']==S['module_budget_s']==P['module_budget_s']==10 and S['elapsed_seconds']<=S['worker_budget_s']==P['worker_budget_s']==30 and M['timeout_s']==P['supervisor_budget_s']==40 and M['cleanup_grace_s']==P['cleanup_grace_s']==5 and Q['elapsed_s']<40 and Q['status']=='complete' and Q['returncode']==P['worker_returncode']==0 and Q['cleanup']['leader_reaped'] and Q['cleanup']['signal_errors']==[])
check('retained_unknown_and_unqualified',not A['qualification']['material_qualified'] and not A['qualification']['training_eligible'] and 'strict dry basis' in A['qualification']['unknown'] and 'char yield' in A['qualification']['not_inferred'] and not P['material_qualified'] and not P['training_eligible'])
timing=R['initial']['construction_timings_s'];check('same_completed_stage_timings_in_initial_final',timing==R['final']['construction_timings_s'] and set(timing)=={'serialize','gas_solution','graphite_solution','mixture_and_initial_state'} and all(math.isfinite(x) and 0<=x<R['elapsed_seconds'] for x in timing.values()))
prof=pstats.Stats(str(B/'first_solve.prof'));prepare=[v[3] for k,v in prof.stats.items() if k[2]=='prepare' and k[0].endswith('tp_equilibrium.py')];check('one_old_prepare_profile_read_only',len(prepare)==1)
oldreview=W/'finite-oxygen-execution/review/SAVED_AUDIT01.json';check('old_passive_acceptance_record_preserved',sha(oldreview)=='345eae935fad6f45ddc2ba31bb4b534a0e79bc0f0b4ce6dc54354c98a5de4779' and read(oldreview)['verdict']=='PASS')
files=[C/f'{s}.json' for s in ['INPUT','RESULT','OBSERVABLES','STATUS']]+[O/'STATUS.json',O/'supervision/metadata.json',O/'supervision/status.json',B/'INPUT.json',B/'RESULT.json',B/'OBSERVABLES.json',D/'NATIVE_PLAN.md',D/'INSTALL_IDENTITY01.json',D/'INSTALLED_TESTS01.xml',ref_path]
result={'verdict':'PASS' if all(v['passed'] for v in checks) else 'FAIL','checks':checks,'full_TP_result_scalar_comparisons':leaf_count[0],'all_result_differences':changes,'new_property_comparisons':props,'max_standard_property_abs_difference':max(abs(p['difference']) for p in props),'numbers':{'mass_input_kg':float(Min),'mass_residual_kg':float(massres),'original_mass_bound_kg':float(bound),'graphite_carbon_kg':float(masses[18]),'scaled_gap':float(diag['scaled_gap_out']),'new_module_elapsed_s':R['elapsed_seconds'],'old_profiled_module_elapsed_s':old['elapsed_seconds'],'worker_elapsed_s':S['elapsed_seconds'],'supervisor_elapsed_s':Q['elapsed_s'],'construction_timings_s':timing,'old_profile_prepare_s':prepare[0]},'files_sha256':{str(p):sha(p) for p in files},'new_EOS_Element_equilibrium_calls':0,'performance_claim':'no clear improvement; unlike profiling and single samples preclude speedup qualification','scientific_qualification':'conditional TP only; no material or char yield qualification'}
with (D/'review/SAVED_AUDIT01.json').open('x') as f:json.dump(wire(result),f,indent=2,allow_nan=False);f.write('\n')
print(result['verdict'],len(checks),'groups',len(props),'NASA properties',leaf_count[0],'TP result scalars');print('failed',[x['name'] for x in checks if not x['passed']]);print(json.dumps(result['numbers'],indent=2));raise SystemExit(0 if result['verdict']=='PASS' else 1)
