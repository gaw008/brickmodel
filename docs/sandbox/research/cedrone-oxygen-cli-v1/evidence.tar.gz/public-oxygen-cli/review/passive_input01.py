"""One saved-input correspondence check; no Element/phase/equilibrium calls."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

from sludge_sandbox.cedrone_oxygen import derive_cedrone_oxygen_pool
from sludge_sandbox.tp_equilibrium import TPPolicy

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK = Path('/private/tmp/sludge-tp-equilibrium-v1')

def rational(d):
    if set(d) == {'numerator', 'denominator'} and all(type(v) is int for v in d.values()):
        return F(d['numerator'], d['denominator'])
    return d

def normalized(v):
    if isinstance(v, dict) or hasattr(v, 'items'):
        return {k: normalized(x) for k, x in v.items()}
    if isinstance(v, (tuple, list)):
        return [normalized(x) for x in v]
    return v

saved_path = WORK/'finite-oxygen-execution/native01/point01/INPUT.json'
saved = json.loads(saved_path.read_text(), object_hook=rational)
weights = {k: float(v) for k, v in saved['case']['actual_atomic_weights'].items()}
inputs = derive_cedrone_oxygen_pool(ROOT, F(1, 4), weights)
definition = inputs.definition()
fields = ['lambda', 'reference_O2_demand_mol', 'base_element_mol', 'element_increment_mol',
          'added_O2_mol', 'added_N2_mol', 'added_O2_mass_kg', 'added_N2_mass_kg',
          'added_gas_mass_kg', 'total_element_mol', 'model_input_mass_kg', 'original_reported_sample_basis_kg']
checks = {
    'all_12_exact_input_fields_equal_saved_same_lambda': all(normalized(definition[k]) == saved['case'][k] for k in fields),
    'complete_pool_equal_saved_same_lambda': normalized(inputs.pool.__dict__) == saved['pool'],
    'policy_equal_saved_original': normalized(TPPolicy().definition()) == saved['policy'],
    'atomic_weights_exact_saved_binary64': dict(definition['exact_represented_atomic_weights']) == saved['case']['actual_atomic_weights'],
    'binding_pending_before_actual_phase': definition['atomic_weights_binding_checked'] is False,
}
with patch.object(Path, 'read_bytes', side_effect=AssertionError('definition must not read source again')):
    checks['definition_same_frozen_values_without_io'] = inputs.definition() is definition
try:
    definition['atomic_weights_kg_kmol']['C'] = 0
except TypeError:
    checks['nested_definition_is_readonly'] = True
else:
    checks['nested_definition_is_readonly'] = False
checks['no_cantera_import_or_native'] = not any(k == 'cantera' or k.startswith('cantera.') for k in sys.modules)
record = {'checks': checks, 'all_pass': all(checks.values()),
          'baseline_input_sha256': hashlib.sha256(saved_path.read_bytes()).hexdigest(),
          'source_sha256': {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in (
              'src/sludge_sandbox/cedrone_oxygen.py', 'examples/sandbox/run_cedrone_oxygen.py',
              'tests/sandbox/test_cedrone_oxygen.py', 'src/sludge_sandbox/tp_equilibrium.py')},
          'new_EOS_or_Element_or_equilibrium_calls': 0,
          'scope': 'pure derive using previously saved A, not actual new Element-to-phase verification'}
with (WORK/'public-oxygen-cli/review/PASSIVE_INPUT01.json').open('x') as out:
    json.dump(record, out, indent=2); out.write('\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['all_pass'] else 1)
