# Cedrone 有限加氧用户入口：作者候选 01

只新增以下三个正式文件，未修改 core、依赖/lock、文档或旧试验：

- `src/sludge_sandbox/cedrone_oxygen.py`：161 行，源表→精确有限加料→同次相原子量/19 物种质量账。
- `examples/sandbox/run_cedrone_oxygen.py`：207 行，默认既有 supervisor 父入口及一个定时 worker；数据根可指定，执行代码从示例自身定位。
- `tests/sandbox/test_cedrone_oxygen.py`：9 个有限行为用例，无真实 Element、phase、EOS 或平衡。

API：`derive_cedrone_oxygen_pool(source_root, lambda_value, atomic_weights)` 返回 `CedroneOxygenInput`。`.pool` 是原 TPPool；`.definition()` 只返回 derive 一次生成的深只读值记录，不做 IO、hash 或重算。`check_cedrone_oxygen_result(result, inputs)` 在实际返回已保存后，核明确 Cantera 版本、model SHA、原 policy 和同次 initial/final 的实际原子量，返回只读 19 项输出与 Fraction 质量账。允许 provider identity 新增字段，不依赖任何旧 baseline 或 scratch 证据。

建议 ROOT 的唯一新物性 smoke 使用已安装新候选环境：

```sh
/path/to/python examples/sandbox/run_cedrone_oxygen.py \
  --source-root /path/to/brickmodel \
  --output-dir /path/to/new-public-oxygen-smoke \
  --lambda 1/4
```

`--lambda` 只收 `0`、`1/4`、`1`，每次只调用所选一点；不预求基线、不预热、不 profile、不 fallback。常量与已通过的有限氧案例相同：800 K、100000 Pa、VCS、element_basis、原 1 kg 报告样本基准和相同 basis_id。worker 模块10 s/总30 s边界，父监督40 s+5 s清理；直接调用 `run_worker` 只有边界时限，不能承诺打断 in-flight native。

输出为父 STATUS、supervision 的现有证据，calculation 下 INPUT/独占 RESULT/OBSERVABLES/STATUS。先保存请求，再导入可选库；每个完成 Element symbol/weight 保留后检查时间。源码把 5 个实际返回 weight 精确表示为 Fraction 并留待同次相权重核验。一次 solve 返回后先写原 RESULT；首次写失败仍保留 `stage=solve_returned` 和 `new_solve_attempts=1`，不误标未调用或成功。最终/保存后超时改 resource_limit，已有结果保留；I/O 失败不许诺未落盘文件完整。

原 m=.704 kg；加气后总账 `.704+Madd`。灰/Cl/Br/打印缺口/残余水不重复补入，O和严格干基/矿物分配/材料误差保持 unknown。C(gr) 不是实测 char，输出不等于真实排放、炉热耗、动力学或完整烧砖模型；资格 false。

## 作者实际验证

- `author-tests/RED01.log/xml` 是首次作者环境没有 PYTHONPATH 的 collection 启动错误，保留，不当作行为 RED。
- `author-tests/RED02.log/xml` 是加入 `PYTHONPATH=src` 后新模块尚未实现的 collection RED，保留。
- `author-tests/GREEN01.log/xml` 实际为首个功能运行 **1 failed / 8 passed，0.14 s**，没有重写误名日志。返回超时状态正确保存，但因 Python TimeoutError 属于 OSError，被错误映射为 I/O 返回码2；按异常类型收窄该标记后修复。
- `author-tests/GREEN02.log/xml`：**9 passed，0.10 s**。覆盖三 λ 精确加料/质量；同版本但相 A 不同；源改变/坏输入；help/枚举/拒绝覆盖；一次调用与完整19输出；Element失败前缀；RESULT首写失败真实状态；返回后超时保留；父入口单次 -I worker 与40+5监督参数/代码位置。
- 基准 ID 改为旧 finite case 相同名称后，仅受影响原测试重跑：`BASIS_GREEN01.log/xml`，**1 passed / 8 deselected，0.09 s**。
- `STATIC01.log`：3文件 AST 通过，git diff --check 通过；ruff/mypy/pylint/black 不在作者环境，未安装新工具。

制造返回是解析 element_basis 库存及明确测试标记，不是平衡解。没有调用 Cantera、安装、提交或运行实际入口。新的 Element→同次相权重应用路径须由 ROOT 另行单次 smoke 验证，不能由旧案例/本测试自动继承。

冻结字节见 `AUTHOR_SHA01.json`；请独立 reviewer 核代码后再进入 ROOT 安装与唯一实际调用。作者保持候选冻结。

## 候选 02：只补调用计数终态及本次两个模型源码身份

输入/待调用 STATUS 增加 attempt_count_final=false，受控返回/异常结束后最终落盘才 true。原内存计数与唯一调用不改。worker 导入后从本次 model.__file__ 与 tp.__file__ 读取 SHA/bytes/path，写到 INPUT.runtime.code_identity；结束只复核同两个文件，改变时保留 RESULT/OBS 并使整体失败；不绑定旧 SHA 或扩大依赖清单。原失败单独保留，源码检查另列。

只在现有成功/首次写失败用例加断言，成功用例另参数化一个临时源码变化负控；没有修改/执行真实模型源码。IDENTITY_RED01.log/xml 实际 3 failed，0.12s：缺 finality 字段、源码变化仍 completed。IDENTITY_GREEN01.log/xml 实际 3 passed / 7 deselected，0.09s。原 candidate01/RED 均保留，没有其它测试重跑或 native。

src/sludge_sandbox/cedrone_oxygen.py: `c85971c9e03351e86dbe84fde16daadceda106b49e6a6f32ae83a5cc220fc882`

examples/sandbox/run_cedrone_oxygen.py: `b1713c05aa2cdfbabb772980ac69fa4df51b9ddbfdf44d183e39b2d4042eca4b`

tests/sandbox/test_cedrone_oxygen.py: `680c05af854dd06f510fa1baae21da94009ce8ac1e971a7372b2a6b082e04440`

