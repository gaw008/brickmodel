"""Additional actual-integrator no-EOS checks; reviewer-owned."""
from pathlib import Path
import json
import math
from fractions import Fraction
from sludge_sandbox.integration import ConservedState, Rates, IntegrationPolicy, DomainExit, integrate

def policy(**changes):
    args=dict(initial_step_s=.00125,maximum_step_s=.00125,minimum_step_s=1e-12,
              relative_tolerance=1e-7,amount_absolute_tolerance_mol=1e-10,
              energy_absolute_tolerance_j=1e-8,amount_scale_mol=.001,
              energy_scale_j=1.,maximum_steps=1000,maximum_rejections=100,
              maximum_wall_seconds=5)
    args.update(changes)
    return IntegrationPolicy(**args)

reports=[]
injected=[]
def domain_once(state,t):
    if t>.5025 and not injected:
        injected.append(t)
        raise DomainExit('review_once_after_accepted_carry')
    return Rates([[0.],[0.]],[0.,0.],[[0.]],[1.])
r=integrate(ConservedState([[1.]],[0.]),domain_once,start_s=.5,end_s=.51,policy=policy())
assert r.status=='completed' and r.rejected_trials==1
assert len(r.steps)==len(r.states)-1 and all(a<b for a,b in zip(r.times_s,r.times_s[1:]))
assert r.times_s[1]<injected[0]
assert abs(r.states[-1].internal_energy_j[0]-(.51-.5))<1e-14
assert abs(sum((Fraction(float(x.cell_work_j[0])) for x in r.steps),Fraction())-(Fraction(.51)-Fraction(.5)))<Fraction(1e-14)
reports.append(dict(case='DomainExit_after_accepted_steps',status=r.status,rejected=r.rejected_trials,steps=len(r.steps)))

def curved(state,t):
    return Rates([[0.],[0.]],[0.,0.],[[0.]],[1e8*max(0.,t-.5025)**2])
r=integrate(ConservedState([[1.]],[0.]),curved,start_s=.5,end_s=.51,policy=policy())
assert r.status=='completed' and r.rejected_trials>0
assert r.times_s[1]==.50125
expected=1e8*(.51-.5025)**3/3
quadrature_error=0.
for left,right in zip(r.times_s,r.times_s[1:]):
    if right<=.5025: continue
    assert left>=.5025
    midpoint=left+(right-left)/2
    quadrature_error+=1e8*((midpoint-left)**3+(right-midpoint)**3)/6
assert abs((r.states[-1].internal_energy_j[0]-expected)-quadrature_error)<1e-10
reports.append(dict(case='local_error_after_accepted_steps',status=r.status,rejected=r.rejected_trials,steps=len(r.steps),analytic_error_j=r.states[-1].internal_energy_j[0]-expected))

def zero(state,t): return Rates([[0.],[0.]],[0.,0.],[[0.]],[0.])
for start,end in [(0.,math.ulp(0.)),(1e16,1e16+2)]:
    width=end-start
    r=integrate(ConservedState([[1.]],[100.]),zero,start_s=start,end_s=end,
                policy=policy(initial_step_s=width,maximum_step_s=width,minimum_step_s=width))
    assert r.status=='numerical_failure' and not r.steps
    reports.append(dict(case='unresolvable_stage',start=start,status=r.status,reason=r.reason))

Path(__file__).with_name('reviewer-check-results.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))
