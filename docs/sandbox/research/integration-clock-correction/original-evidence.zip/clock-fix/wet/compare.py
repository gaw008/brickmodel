from pathlib import Path
import json,hashlib
p=Path(__file__).parent
a=json.loads((p/'active-result.json').read_text());b=json.loads((p/'disabled-result.json').read_text())
assert a['status']==b['status']=='passed'
for key in ['initial','policy','inverse_policy','layout','implementation','versions']:
    assert a[key]==b[key],key
assert a['run']['times_s'][0]==b['run']['times_s'][0]==.5
assert a['run']['times_s'][-1]==b['run']['times_s'][-1]==.51
initial=a['initial']['amounts_mol'][0];av=a['final_amounts_mol'][0];bv=b['final_amounts_mol'][0]
assert bv==initial and b['final_rate_mol_s']==0
assert av[1]>initial[1] and av[2]<initial[2]
delta=b['final_temperature_k']-a['final_temperature_k']
assert delta>=1e-4
out={'status':'passed','qualification':'same initial state/motion active-vs-disabled causal mechanism comparison; not independent trajectory accuracy oracle','temperature_difference_k':delta,'active_final_temperature_k':a['final_temperature_k'],'disabled_final_temperature_k':b['final_temperature_k'],'vapor_increase_mol':av[1]-initial[1],'liquid_decrease_mol':initial[2]-av[2],'same_initial_and_policies':True,'result_sha256':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['active-result.json','disabled-result.json']}}
(p/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
