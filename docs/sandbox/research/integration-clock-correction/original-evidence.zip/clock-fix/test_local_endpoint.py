from fractions import Fraction
from sludge_sandbox.integration import ConservedState,Rates,integrate
from test_integration import policy

def test_binary_interval_remainder_is_fully_integrated():
    def work(s,t):return Rates([[0.],[0.]],[0.,0.],[[0.]],[3.])
    r=integrate(ConservedState([[1.]],[0.]),work,start_s=.15,end_s=.2,
        policy=policy(initial_step_s=.01,maximum_step_s=.01,maximum_steps=5))
    assert r.status=='completed',(r.reason,r.times_s)
    assert r.times_s[-1]==.2 and len(r.steps)==5
    total=sum((Fraction(float(s.cell_work_j[0])) for s in r.steps),Fraction())
    assert abs(total-3*(Fraction(.2)-Fraction(.15)))<=Fraction(1e-15)
