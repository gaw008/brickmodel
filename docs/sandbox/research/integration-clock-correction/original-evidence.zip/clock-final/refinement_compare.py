from pathlib import Path
import json,hashlib
p=Path(__file__).parent
names=['active-result.json','fine-result.json','finer-result.json'];rows=[json.loads((p/n).read_text()) for n in names]
for d in rows:assert d['status']=='passed'
for d in rows[1:]:
    for key in ['initial','inverse_policy','layout','implementation','versions']:assert d[key]==rows[0][key]
    ap=dict(d['policy']);bp=dict(rows[0]['policy'])
    for k in ['initial_step_s','maximum_step_s']:ap.pop(k);bp.pop(k)
    assert ap==bp
for d in rows:assert d['run']['times_s'][0]==.5 and d['run']['times_s'][-1]==.51
pairs=[]
for a,b in zip(rows,rows[1:]):
    pairs.append({'amount_mol':[abs(x-y) for x,y in zip(a['final_amounts_mol'][0],b['final_amounts_mol'][0])],'energy_j':abs(a['final_energy_j'][0]-b['final_energy_j'][0]),'temperature_k':abs(a['final_temperature_k']-b['final_temperature_k']),'pressure_pa':abs(a['final_pressure_pa']-b['final_pressure_pa'])})
last=pairs[-1];assert max(last['amount_mol'])<=1e-10 and last['energy_j']<=1e-5 and last['temperature_k']<=1e-4 and last['pressure_pa']<=.2
out={'status':'passed','qualification':'three time-step endpoint comparison under registered gates; no independent true trajectory or exact convergence order claimed','successive_differences':pairs,'vapor_difference_ratio':pairs[0]['amount_mol'][1]/last['amount_mol'][1] if last['amount_mol'][1] else None,'actual_accepted_steps':[len(d['run']['steps']) for d in rows],'actual_times':[d['run']['times_s'] for d in rows],'result_sha256':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in names}}
(p/'refinement-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
