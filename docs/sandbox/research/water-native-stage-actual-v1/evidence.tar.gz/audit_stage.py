"""DRAFT independent saved-stage algebra auditor; never imports tested models.

Input: lossless data() JSON for NativePressureMixedTrialResult and CASE.json.
Schema must be rechecked against final session/stage freeze before execution.
This audits saved arithmetic and association, not EOS source truth.
"""
from pathlib import Path
from decimal import Decimal
from fractions import Fraction as F
import argparse
import hashlib
import json
import math


def decode(value):
    if isinstance(value,list):return [decode(x) for x in value]
    if not isinstance(value,dict):return value
    if set(value)=={'float_hex'}:return float.fromhex(value['float_hex'])
    if set(value)=={'decimal'}:return Decimal(value['decimal'])
    if set(value)=={'fraction'}:return F(*value['fraction'])
    if set(value)=={'bytes_hex'}:return bytes.fromhex(value['bytes_hex'])
    if set(value)=={'type','fields'}:return decode(value['fields'])
    return {k:decode(v) for k,v in value.items()}


def check(ok,reason):
    if not ok:raise ValueError(reason)


def time_of(value):return F(value['seconds'])


def amounts(states):
    out={}
    for i,s in enumerate(states):
        for j,v in enumerate(s['solid_mass_kg']):out['solid',i,j]=F(v)
        out['liquid',i,0]=F(s['liquid_water_mol'])
        for j,v in enumerate(s['gas_amounts_mol']):out['gas',i,j]=F(v)
    check(len(out)==12,'twelve_inventory_coordinates')
    return out


def raw_fluxes(rates):
    out={}
    check(len(rates['cells'])==2,'two_rate_cells')
    for i,cell in enumerate(rates['cells']):
        check(len(cell['solid_kg_s'])==2 and len(cell['reaction_gas_mol_s'])==3,'rate_layout')
        out.update({('solid',i,j):F(v) for j,v in enumerate(cell['solid_kg_s'])})
        out.update({('chemical_gas',i,j):F(v) for j,v in enumerate(cell['reaction_gas_mol_s'])})
        out['phase_water',i]=F(cell['phase_water_mol_s'])
    exchange=rates['exchange']['net_mol_s']
    check(set(exchange)=={'O2','N2','H2O'},'three_face_species')
    out.update({('face_species',j):F(exchange[name]) for j,name in enumerate(('O2','N2','H2O'))})
    out['heat',]=F(rates['conduction_w'])
    for family,field in [('diffusion_energy','diffusive_enthalpy_w'),('advection_energy','advective_enthalpy_w')]:
        check(len(rates[field])==3,'three_energy_components')
        out.update({(family,j):F(v) for j,v in enumerate(rates[field])})
    out['face_energy',]=F(rates['face_energy_w'])
    return out


def net_inventory(flux):
    out={}
    for i,sign in enumerate((-1,1)):
        for j in range(2):out['solid',i,j]=flux['solid',i,j]
        out['liquid',i,0]=-flux['phase_water',i]
        for j in range(3):out['gas',i,j]=flux['chemical_gas',i,j]+sign*flux['face_species',j]+(flux['phase_water',i] if j==2 else F())
    return out


def keyed(rows):
    out={tuple(k):v for k,v in rows}
    check(len(out)==len(rows),'duplicate_component_key')
    return out


def minimum(a,b,c,h):
    choices=[(a,F()),(a+b*h+c*h*h,h)]
    if c>0:
        vertex=-b/(2*c)
        if 0<vertex<h:choices.append((a+b*vertex+c*vertex*vertex,vertex))
    return min(choices)


def writeback(before,after,integrals):
    increments=net_inventory(integrals);old=amounts(before);new=amounts(after)
    for key,increment in increments.items():
        ideal=old[key]+increment
        check(ideal>=0,'negative_inventory_before_rounding')
        rounded=float(ideal)
        check(math.isfinite(rounded) and (ideal==0 or rounded>0),'invalid_or_underflowed_inventory')
        check(new[key]==F(rounded),'literal_inventory_writeback')
    for i,sign in enumerate((-1,1)):
        expected=float(F(before[i]['internal_energy_j'])+sign*integrals['face_energy',])
        check(after[i]['internal_energy_j']==expected,'literal_total_U_writeback')
        check(after[i]['energy_model_identity']==before[i]['energy_model_identity'],'writeback_model_identity')


def audit_trial(trial,policy):
    a,b=time_of(trial['start']),time_of(trial['end']);h=b-a
    check(h>0,'positive_trial_time');panel=trial['panel'];ledger=trial['ledger']
    first,middle,last=panel['start_sample'],panel['midpoint_sample'],trial['endpoint_sample']
    check(time_of(first['time'])==a and time_of(middle['time'])==a+h/2 and time_of(last['time'])==b,'actual_sample_times')
    check(first['state']==trial['initial_state'] and middle['state']==trial['predictor_state'] and last['state']==trial['endpoint_state'],'actual_sample_states')
    check(first['source_binding']==middle['source_binding']==last['source_binding']==panel['source_binding'],'sample_source_binding')
    check(first['interfaces']==middle['interfaces']==last['interfaces']==panel['interfaces'],'sample_modes')
    f0,fm=raw_fluxes(first['rates']),raw_fluxes(middle['rates'])
    predictor={k:F(float(v*h/2)) for k,v in f0.items()}
    writeback(trial['initial_state'],trial['predictor_state'],predictor)
    exact={k:v*h for k,v in fm.items()};represented={k:F(float(v)) for k,v in exact.items()}
    check(keyed(ledger['exact_integrals'])==exact,'independent_midpoint_integrals')
    check({k:F(v) for k,v in keyed(ledger['represented_integrals']).items()}==represented,'individual_integral_rounding')
    check(keyed(ledger['integral_roundoff'])=={k:represented[k]-v for k,v in exact.items()},'saved_integral_roundoff')
    check(time_of(ledger['start'])==a and time_of(ledger['end'])==b,'ledger_exact_time')
    coefficients={tuple(k):(F(x),F(slope)) for k,x,slope in panel['component_coefficients']}
    check(len(coefficients)==len(f0) and coefficients=={k:(v,2*(fm[k]-v)/h) for k,v in f0.items()},'independent_affine_coefficients')
    for key,(v,slope) in coefficients.items():check(v*h+slope*h*h/2==exact[key],'affine_integral_exact')
    initial=amounts(trial['initial_state']);d0,dm=net_inventory(f0),net_inventory(fm);polys=panel['inventories'];mins=panel['minimum_inventory']
    check(len(polys)==len(mins)==12,'complete_panel_minima')
    seen=set();lowest=[]
    for poly,saved in zip(polys,mins):
        key=(poly['family'],poly['cell'],poly['index']);check(key not in seen and key in initial,'panel_inventory_keys');seen.add(key)
        aa,bb,cc=initial[key],d0[key],(dm[key]-d0[key])/h
        check((poly['initial'],poly['linear'],poly['quadratic'])==(aa,bb,cc),'independent_inventory_polynomial')
        value,at=minimum(aa,bb,cc,h);check(saved==[*key,value,at],'full_polynomial_minimum')
        if key[0]=='liquid':
            if panel['interfaces'][key[1]]=='existing_liquid':check(value>0,'strict_wet_panel')
            else:check(aa==bb==cc==0,'identically_zero_dry_panel')
        else:check(value>=0,'nonnegative_full_panel')
        lowest.append((key,str(value),str(at)))
    writeback(trial['initial_state'],trial['endpoint_state'],represented)
    netex,netrep=net_inventory(exact),net_inventory(represented);before=initial;after=amounts(trial['endpoint_state'])
    for key in before:
        bound=F(policy['solid_mass_absolute_kg'] if key[0]=='solid' else policy['amount_absolute_mol'])
        check(max(abs(after[key]-before[key]-netex[key]),abs(after[key]-before[key]-netrep[key]))<=bound,'local_inventory_original_unit_gate')
    component=represented['face_energy',]-represented['heat',]-sum((represented['diffusion_energy',j]+represented['advection_energy',j] for j in range(3)),F())
    check(abs(component)<=F(policy['energy_absolute_j']),'face_energy_component_closure')
    for i,sign in enumerate((-1,1)):
        delta=F(trial['endpoint_state'][i]['internal_energy_j'])-F(trial['initial_state'][i]['internal_energy_j'])
        check(max(abs(delta-sign*exact['face_energy',]),abs(delta-sign*represented['face_energy',]))<=F(policy['energy_absolute_j']),'local_U_original_gate')
    return {'start':str(a),'end':str(b),'minima':lowest},exact,represented


def audit_original_prefixes(steps,integrals,initial,storage,source_case):
    """Independent raw saved accounting under original strict prefix gates."""
    gas_ids=storage['fluid_template']['mechanical']['gas_species_ids']
    check(gas_ids==source_case['gas_ids']==['O2','N2','H2O'],'original_gas_layout')
    masses=[F(storage['fluid_template']['gas_phases'][k]['molar_mass_kg_mol']) for k in gas_ids]
    network=storage['reference']['network'];components=network['components']
    check([c['component_id'] for c in components]==['A','B',*gas_ids],'original_component_layout')
    def exact(v):return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)
    def totals(states):
        elements=[F() for _ in network['elements']];mass=water=energy=F()
        for state in states:
            check(state['energy_model_identity']==storage['_identity'],'original_storage_binding')
            values=[*map(F,state['solid_mass_kg']),*(F(n)*m for n,m in zip(state['gas_amounts_mol'],masses,strict=True))]
            values[-1]+=F(state['liquid_water_mol'])*masses[-1]
            for v,c in zip(values,components,strict=True):
                check(len(c['element_mass_fractions'])==len(elements),'original_element_layout')
                for j,f in enumerate(c['element_mass_fractions']):elements[j]+=v*exact(f)
            mass+=sum(values,F());water+=F(state['liquid_water_mol'])+F(state['gas_amounts_mol'][2]);energy+=F(state['internal_energy_j'])
        return elements,mass,water,energy
    gates=source_case['prefix_gates'];maxima={k:F() for k in gates};base=totals(initial)
    for state,registered in zip(initial,source_case['initial_cells'],strict=True):
        for field in ('solid_mass_kg','liquid_water_mol','gas_amounts_mol'):check(state[field]==registered[field],'original_registered_inventory')
    def gate(name,value):
        value=abs(value);maxima[name]=max(maxima[name],value)
        check(value<F(gates[name]),'original_strict_prefix_gate:'+name)
    origin=amounts(initial)
    for indices in ((0,),(1,2)):
        sums={k:F() for k in origin};energies=[F(),F()]
        for index in indices:
            if index>=len(steps):continue
            row=steps[index]['endpoint_state'];el,m,w,u=totals(row)
            gate('global_elements_kg',max(abs(a-b) for a,b in zip(el,base[0],strict=True)))
            for name,value,start in [('global_mass_kg',m,base[1]),('global_water_mol',w,base[2]),('global_energy_j',u,base[3])]:gate(name,value-start)
            represented=integrals[index][1];net=net_inventory(represented);actual=amounts(row)
            for key in sums:
                sums[key]+=net[key]
                gate({'solid':'local_solid_kg','liquid':'local_liquid_mol','gas':'local_gas_mol'}[key[0]],actual[key]-origin[key]-sums[key])
            for i,sign in enumerate((-1,1)):
                energies[i]+=sign*represented['face_energy',]
                gate('local_energy_j',F(row[i]['internal_energy_j'])-F(initial[i]['internal_energy_j'])-energies[i])
                check(represented['chemical_gas',i,2]==0,'zero_water_chemical_source')
            gate('face_components_j',represented['face_energy',]-represented['heat',]-sum((represented['diffusion_energy',j]+represented['advection_energy',j] for j in range(3)),F()))
    return {'maxima':{k:str(v) for k,v in maxima.items()},'original_strict_gates':gates}


def audit_stage(stage,case,initial,storage,source_case):
    policy=case['stage_policy'];steps=stage['steps'];summaries=[];integrals=[]
    check(len(steps)<=3,'at_most_three_paths')
    check(stage['initial_state']==initial,'actual_initial_energy_binding')
    check(time_of(stage['start'])==F(*case['start_seconds_fraction']) and time_of(stage['end'])==F(*case['end_seconds_fraction']),'registered_exact_stage_time')
    check(decode(json.loads(stage['original_stage_policy_json']))==policy,'original_policy_bytes')
    check(decode(json.loads(stage['original_stage_inputs_json']))==[initial,stage['start'],stage['end'],policy],'original_input_bytes')
    if stage['status']=='accepted':
        check(len(steps)==len(stage['panels'])==3 and len(stage['samples'])==stage['evaluations_attempted']==stage['evaluations_completed']==9,'accepted_nine_actual_callbacks')
        check([s['role'] for s in stage['samples']]==[p+':'+r for p in ('full','half1','half2') for r in ('start','midpoint','endpoint')],'nine_actual_roles')
        for index,trial in enumerate(steps):
            check(stage['panels'][index]==trial['panel'],'three_saved_panel_binding')
            check(stage['samples'][3*index:3*index+3]==[trial['panel']['start_sample'],trial['panel']['midpoint_sample'],trial['endpoint_sample']],'nine_sample_trial_binding')
    for trial in steps:
        report,exact,represented=audit_trial(trial,policy);summaries.append(report);integrals.append((exact,represented))
    prefixes=audit_original_prefixes(steps,integrals,initial,storage,source_case)
    before,after=stage['pressure_session_before'],stage['pressure_session_after']
    check(before['original_configuration_json']==after['original_configuration_json'] and before['original_physics_json']==after['original_physics_json'] and before['source_before']==after['source_before'],'session_original_binding')
    check(after['attempts'][:len(before['attempts'])]==before['attempts'],'session_prior_attempts_preserved')
    queries=after['attempts'][len(before['attempts']):];radii={};seed_a=before['seed_attempted'];seed_c=before['seed_completed'];proof_a=before['proof_attempted'];proof_c=before['proof_completed']
    for query in queries:
        if query['seed'] is not None:seed_a+=query['seed']['attempted'];seed_c+=query['seed']['completed']
        if query['proof'] is not None:proof_a+=query['proof']['attempted_proof_operations'];proof_c+=query['proof']['completed_proof_operations']
        check((seed_a,seed_c,proof_a,proof_c)==(query['cumulative_seed_attempted'],query['cumulative_seed_completed'],query['cumulative_proof_attempted'],query['cumulative_proof_completed']),'cumulative_child_costs')
        ctx,states,rate,cell=decode(json.loads(query['context']))
        check(ctx['role'] in ('full','fine') and ctx['original_initial']==stage['initial_state'] and ctx['stage_start']==stage['start'] and ctx['stage_end']==stage['end'] and ctx['stage_policy']==policy,'query_original_context')
        check(ctx in stage['pressure_query_contexts'],'query_context_recorded')
        if len(steps)==3:
            sample=steps[0 if ctx['role']=='full' else 2]['endpoint_sample']
            check(states==sample['state'] and rate==sample['rates']['cells'][cell] and ctx['time']==sample['time'] and ctx['source_binding']==sample['source_binding'] and ctx['interfaces']==sample['interfaces'],'actual_endpoint_query_association')
        proof=query['proof']
        if query['status']=='proved_conditional_query':
            check(proof is not None and proof['status']=='proved_conditional_query' and query['pressure_radius_pa']==proof['pressure_radius_pa'],'actual_pressure_evidence_radius')
            raw=proof['original_query_json'];check(hashlib.sha256(raw).hexdigest()==proof['request_sha256']==query['request_sha256'],'original_request_hash')
            check(decode(json.loads(raw))==[states,rate,cell],'proof_actual_query_bytes')
            params=decode(json.loads(proof['parameters_json']));ops=proof['operations']
            check([o['name'] for o in ops]==['coexistence','coupled_mechanical_root','full_temperature_connected_density_tube','observed_native_query'] and all(o['status']=='completed' for o in ops),'all_four_proof_operations')
            inv=rate['inverse'];point=inv['point']['fluid']['mechanical'];t=F(point['temperature_k']);epsilon=F(inv['temperature_error_bound_k'])
            check(F(params['temperature']['lo'])<=t-epsilon<=t+epsilon<=F(params['temperature']['hi']),'full_original_inverse_temperature')
            check(F(params['nominal_pressure_pa'])==F(point['pressure_pa']) and F(params['inverse_error_saved'])==epsilon,'original_nominal_and_epsilon')
            mechanical=decode(json.loads(ops[1]['evidence_json']));nominal=F(rate['inverse']['point']['fluid']['mechanical']['pressure_pa']);fixed=F(rate['inverse']['point']['pressure_error_pa'])
            radius=max(abs(nominal-F(mechanical['pressure'][side])) for side in ('lo','hi'))+fixed
            check(radius==proof['pressure_radius_pa'] and fixed==F(params['original_fixed_T_error_pa']),'fresh_exact_pressure_radius')
            key=(ctx['role'],cell);check(key not in radii,'unique_endpoint_query');radii[key]=radius
    check((seed_a,seed_c,proof_a,proof_c)==(after['seed_attempted'],after['seed_completed'],after['proof_attempted'],after['proof_completed']),'final_session_costs')
    comparisons=None
    if len(steps)==3 and len(radii)==4:
        full,fine=steps[0]['endpoint_state'],steps[2]['endpoint_state']
        check(steps[0]['initial_state']==steps[1]['initial_state']==stage['initial_state'] and steps[2]['initial_state']==steps[1]['endpoint_state'],'independent_full_half_paths')
        check(steps[0]['start']==steps[1]['start']==stage['start'] and steps[0]['end']==steps[2]['end']==stage['end'] and steps[1]['end']==steps[2]['start'],'exact_three_path_clock')
        # Each path is accumulated from the common original state. Never add
        # the full step to the two-half path or reset at the second half.
        origin=amounts(stage['initial_state'])
        for indices in ((0,),(1,2)):
            sums={key:F() for key in origin};energy_sums=[F(),F()]
            for index in indices:
                increments=net_inventory(integrals[index][0])
                for key in sums:sums[key]+=increments[key]
                endpoint=amounts(steps[index]['endpoint_state'])
                for key in sums:
                    bound=F(policy['solid_mass_absolute_kg'] if key[0]=='solid' else policy['amount_absolute_mol'])
                    check(abs(endpoint[key]-origin[key]-sums[key])<=bound,'original_path_prefix_inventory_closure')
                for i,sign in enumerate((-1,1)):
                    energy_sums[i]+=sign*integrals[index][0]['face_energy',]
                    actual=F(steps[index]['endpoint_state'][i]['internal_energy_j'])-F(stage['initial_state'][i]['internal_energy_j'])
                    check(abs(actual-energy_sums[i])<=F(policy['energy_absolute_j']),'original_path_prefix_energy_closure')
        a,b=amounts(full),amounts(fine)
        mass=max(abs(a[k]-b[k]) for k in a if k[0]=='solid');mol=max(abs(a[k]-b[k]) for k in a if k[0]!='solid')
        energy=max(abs(F(x['internal_energy_j'])-F(y['internal_energy_j'])) for x,y in zip(full,fine));temp=pressure=F()
        for i in range(2):
            x=steps[0]['endpoint_sample']['rates']['cells'][i]['inverse'];y=steps[2]['endpoint_sample']['rates']['cells'][i]['inverse']
            xp,yp=x['point']['fluid']['mechanical'],y['point']['fluid']['mechanical']
            temp=max(temp,abs(F(xp['temperature_k'])-F(yp['temperature_k']))+F(x['temperature_error_bound_k'])+F(y['temperature_error_bound_k']))
            pressure=max(pressure,abs(F(xp['pressure_pa'])-F(yp['pressure_pa']))+radii['full',i]+radii['fine',i])
        clock=abs(time_of(steps[0]['end'])-time_of(steps[2]['end']))
        names=('solid_kg','amount_mol','energy_j','temperature_k','pressure_pa','time_s');values=(mass,mol,energy,temp,pressure,clock)
        check(dict(stage['comparisons'])==dict(zip(names,values)),'independently_recomputed_six_channels')
        bounds=[F(policy[k]) for k in ('solid_mass_absolute_kg','amount_absolute_mol','energy_absolute_j','temperature_absolute_k','pressure_absolute_pa','time_absolute_s')]
        passed=all(v<=b for v,b in zip(values,bounds));check((stage['status']=='accepted')==passed,'original_gate_acceptance')
        check(stage['candidate_state']==(fine if passed else None),'speculative_candidate_only')
        comparisons={n:{'value':str(v),'bound':str(b),'passes':v<=b} for n,v,b in zip(names,values,bounds)}
    else:check(stage['status']!='accepted' and stage['candidate_state'] is None,'incomplete_trial_cannot_accept')
    return {'status':'saved_arithmetic_consistent','stage_status':stage['status'],'audited_complete_steps':summaries,'original_global_and_local_prefixes':prefixes,'fresh_pressure_queries':len(queries),'proved_query_radii':len(radii),'six_comparisons':comparisons,'EOS_calls':0,'qualification':'Draft schema-dependent independent arithmetic audit, not physical or source admission'}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',type=Path,required=True);parser.add_argument('--case',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--initial',type=Path,required=True);parser.add_argument('--storage',type=Path,required=True);args=parser.parse_args()
    stage=decode(json.loads(args.stage.read_bytes()));case=json.loads(args.case.read_bytes());initial=decode(json.loads(args.initial.read_bytes()));storage=json.loads(args.storage.read_bytes());source_case=json.loads(Path(case['source_case']).read_bytes());result=audit_stage(stage,case,initial,storage,source_case)
    with args.output.open('x') as stream:stream.write(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
