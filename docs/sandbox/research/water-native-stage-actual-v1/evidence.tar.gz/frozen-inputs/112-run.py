"""Root-operated installed wet mass positive-liquid trajectory experiment. No EOS on import/prepare."""
from pathlib import Path
from fractions import Fraction as F
from dataclasses import fields,is_dataclass,replace
from collections.abc import Mapping
import argparse,hashlib,importlib.metadata,json,math,os,shutil,sys,sysconfig,time,traceback
HERE=Path(__file__).resolve().parent
REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WATER=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')
SUPERVISOR=REPO/'docs/sandbox/research/research-process-supervisor/supervisor.py'
SUPERVISOR_SHA='939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1'
FACTS=REPO/'data/sandbox/research/water-element-convention-v1'
CASE={'schema': 'manufactured_positive_liquid_mass_trajectory_v1', 'temperature_k': 300.0, 'bulk_volume_m3': 0.001, 'solid_mass_kg': [0.01, 0.0], 'liquid_water_mol': 0.02, 'gas_ids': ['O2', 'N2', 'H2O'], 'gas_amounts_mol': [0.2, 0.2, 0.001], 'temperature_domain_k': [295.0, 310.0], 'pressure_domain_pa': [10000.0, 10000000.0], 'solid_cp_j_kg_k': [1000.0, 1200.0], 'solid_volume_m3_kg': [0.001, 0.0005], 'dry_gas_cp_j_mol_k': [30.0, 29.0], 'reference_temperature_k': 300.0, 'reference_pressure_pa': 100000.0, 'reaction_mass_row': [-1, 2, -1, 0, 0], 'reaction_enthalpy_j_kg': -200000, 'inverse_policy': {'energy_tolerance_j': 1e-05, 'temperature_tolerance_k': 0.0001, 'maximum_iterations': 100}, 'pressure_policy': {'volume_tolerance_m3': 1e-12, 'pressure_tolerance_pa': 1e-05, 'maximum_iterations': 100}, 'envelope': {'liquid_u_error_j_mol': 1e-08, 'liquid_v_error_m3_mol': 1e-16, 'liquid_abs_du_dp_bound_j_mol_pa': 0.0001, 'gas_u_error_j_mol': 1e-09, 'gas_cv_lower_j_mol_k': 20.0}, 'qualification': 'Actual source-water positive-liquid two-cell segments with manufactured solid/kinetic/transport parameters. No depletion, adaptive convergence, spatial convergence or material admission.', 'initial_temperatures_k': [300.0, 305.0], 'initial_cells': [{'solid_mass_kg': [0.01, 0.0], 'liquid_water_mol': 0.02, 'gas_amounts_mol': [0.2, 0.2, 0.001]}, {'solid_mass_kg': [0.007, 0.002], 'liquid_water_mol': 0.02, 'gas_amounts_mol': [0.08, 0.25, 0.001]}], 'duration_s': 0.01, 'step_counts': {'coarse': 4, 'fine': 8}, 'maximum_wall_seconds': 150.0, 'external_wall_seconds': 180.0, 'face': {'area_m2': 0.01, 'half_widths_m': [0.05, 0.05], 'conductivities_w_m_k': [0.5, 0.7], 'diffusivities_m2_s': [1e-05, 2e-05, 1.5e-05], 'permeability_m2': 1e-13, 'viscosity_pa_s': 1.8e-05, 'source_ids': ['manufactured-wet-face']}, 'rate_constants_per_s': [0.2, 0.2], 'oxygen_references_mol': [0.2, 0.2], 'transfer_coefficients_mol_s_pa': [1e-08, 1e-08], 'coefficient_source_ids': ['manufactured-reaction-phase-coefficients'], 'prefix_gates': {'global_elements_kg': 2e-15, 'global_mass_kg': 2e-15, 'global_water_mol': 2e-15, 'global_energy_j': 2e-10, 'local_solid_kg': 1e-16, 'local_liquid_mol': 1e-15, 'local_gas_mol': 1e-15, 'local_energy_j': 1e-10, 'face_components_j': 1e-12}}
def require(ok,reason):
    if not ok:raise ValueError(reason)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def save(path,value):
    p=Path(path);raw=json.dumps(value,indent=2,allow_nan=False)+'\n';tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(raw);tmp.replace(p)
def hashes(root):
    d={}
    for p in sorted(Path(root).rglob('*')):
        require(not p.is_symlink(),'input_symlink')
        if p.is_file():d[p.relative_to(root).as_posix()]=sha(p)
    return d
def installed():
    require(not os.environ.get('PYTHONPATH'),'PYTHONPATH_forbidden')
    from sludge_sandbox.run_service import runtime_identity
    import sludge_sandbox.mass_wet_storage as wet
    package=Path(wet.__file__).resolve().parent
    require(package.is_relative_to(Path(sysconfig.get_paths()['purelib']).resolve()),'actual_installed_package_required')
    direct=importlib.metadata.distribution('sludge-vme').read_text('direct_url.json')
    require(not direct or json.loads(direct).get('dir_info',{}).get('editable') is not True,'editable_forbidden')
    runtime=runtime_identity();actual={p.name:sha(p) for p in package.glob('*.py')}
    source={p.name:sha(p) for p in (REPO/'src/sludge_sandbox').glob('*.py')}
    require(actual==source==runtime['modules'],'actual_installed_source_mismatch')
    return package,runtime,{'python':sys.executable,'package':str(package),'module_count':len(actual),'direct_url':None if direct is None else json.loads(direct)}
def prepare(expected_module_sha):
    package,runtime,environment=installed()
    require(sha(package/'mass_wet_transport.py')==expected_module_sha,'reviewed_wet_source_required')
    require(sha(SUPERVISOR)==SUPERVISOR_SHA,'reviewed_supervisor_required')
    inp=HERE/'inputs';inp.mkdir(exist_ok=False)
    require(read(HERE/'CASE.json')==CASE,'registered_CASE_file_mismatch');shutil.copyfile(HERE/'CASE.json',inp/'case.json')
    for src,dest in [(WATER,inp/'water'),(FACTS,inp/'water-element-convention')]:
        original=hashes(src);dest.mkdir()
        for name in original:
            target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/name,target)
        require(hashes(dest)==original,'copy_changed')
    require(len(hashes(inp/'water'))==16,'original_sixteen_water_assets_required')
    gas=REPO/'data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json'
    shutil.copyfile(gas,inp/'gas_molar_mass_facts.json')
    (inp/'implementation').mkdir()
    for p in package.glob('*.py'):shutil.copyfile(p,inp/'implementation'/p.name)
    frozen={'status':'FROZEN','schema':'wet_mass_trajectory_native_freeze_v1','runtime':runtime,'environment':environment,'files':hashes(inp),
            'original_water':hashes(WATER),'original_facts':hashes(FACTS),'original_gas_facts_sha256':sha(gas),'wet_module_sha256':expected_module_sha,
            'scripts':{n:sha(HERE/n) for n in ('run.py','supervise.py','PLAN.md','audit_prefix.py','CASE.json')},'supervisor_sha256':SUPERVISOR_SHA,'timeout_s':180.,'cleanup_grace_s':.1}
    save(HERE/'freeze.json',frozen)
    return {'status':'prepared_no_EOS','freeze_sha256':sha(HERE/'freeze.json'),'environment':environment}
def verify(expected):
    require(sha(HERE/'freeze.json')==expected,'authoritative_freeze_changed');f=read(HERE/'freeze.json')
    require(f['status']=='FROZEN','freeze_unfilled');require(hashes(HERE/'inputs')==f['files'],'frozen_inputs_changed')
    require(hashes(WATER)==f['original_water'] and hashes(FACTS)==f['original_facts'],'original_source_assets_changed')
    require(sha(REPO/'data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json')==f['original_gas_facts_sha256'],'original_gas_facts_changed')
    for n,d in f['scripts'].items():require(sha(HERE/n)==d,'runner_or_plan_changed')
    require(sha(SUPERVISOR)==f['supervisor_sha256']==SUPERVISOR_SHA,'supervisor_changed')
    _,runtime,environment=installed();require(runtime==f['runtime'],'execution_runtime_changed')
    require(read(HERE/'inputs/case.json')==CASE,'registered_point_changed')
    return f,runtime,environment

def capture(value):
    # Every numerical dataclass field is retained; providers are content descriptions.
    from sludge_sandbox.water_properties import is_water_provider
    from sludge_sandbox.deforming_solid_storage import _canonical
    from sludge_sandbox.verification_case import encode
    if is_water_provider(value):return {'concrete_type':[type(value).__module__,type(value).__qualname__],'source':_canonical(value),'implementation':_canonical(value.implementation)}
    if is_dataclass(value):return {f.name:capture(getattr(value,f.name)) for f in fields(value)}
    if isinstance(value,Mapping):return {str(k):capture(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [capture(v) for v in value]
    return encode(value)

def build_storage(out):
    from sludge_sandbox.water_properties import load_water_properties
    from sludge_sandbox.ideal_water_vapor import IdealWaterVapor
    from sludge_sandbox.phase_storage import IdealGasPhase,InversePolicy
    from sludge_sandbox.rigid_water_gas import RigidWaterGas,PressurePolicy
    from sludge_sandbox.rigid_storage import RigidStorage,DeclaredNumericalEnvelope
    from sludge_sandbox.thermochemistry import ShomateGas,ShomateSegment
    from sludge_sandbox.reaction_reference import Component,Reaction,Anchor,ReactionReferenceNetwork
    from sludge_sandbox.mass_storage_bridge import MassSolid
    from sludge_sandbox.mass_wet_storage import WaterElementConvention,WetMixedStorage
    inp=HERE/'inputs';case=read(inp/'case.json');save(out/'attempted-point.json',case)
    water_dir=inp/'water';manifest=water_dir/'heos-8.0.0-approved-manifest.json'
    water=load_water_properties(water_dir,backend='heos',backend_manifest=manifest)
    vapor=IdealWaterVapor(water_dir,backend='heos',backend_manifest=manifest)
    require(type(water) is type(vapor._water) and water.implementation==vapor._water.implementation and water.reference==vapor.reference,'actual_water_backend_binding')
    save(out/'water-provider.json',capture(water));save(out/'vapor-provider.json',capture(vapor))
    convention=WaterElementConvention.load(inp/'water-element-convention/facts.json')
    R=8.31446261815324;phases={};facts=read(inp/'gas_molar_mass_facts.json');by_id={r['species_id']:r for r in facts}
    for name,cp in zip(('O2','N2'),case['dry_gas_cp_j_mol_k']):
        row=by_id[name];curve=ShomateGas(name,(ShomateSegment((250.,600.),(cp,0.,0.,0.,0.,0.,0.,0.),0.,R,('manufactured-constant-cp',)),),'manufactured_test_fixture',('manufactured-constant-cp',))
        phases[name]=IdealGasPhase(curve,row['nominal_molar_mass_kg_mol'],0,(row['source_id'],row['cache_sha256']))
    phases['H2O']=IdealGasPhase(vapor,water.reference.molar_mass_kg_mol)
    names=tuple(case['gas_ids']);td=tuple(case['temperature_domain_k']);pd=tuple(case['pressure_domain_pa']);env=case['envelope']
    mechanical=RigidWaterGas(water,names,case['bulk_volume_m3'],pd,'planar_interface_no_capillary_pressure',PressurePolicy(**case['pressure_policy']))
    envelope=DeclaredNumericalEnvelope(td,pd,env['liquid_u_error_j_mol'],env['liquid_v_error_m3_mol'],env['liquid_abs_du_dp_bound_j_mol_pa'],{k:env['gas_u_error_j_mol'] for k in names},{k:env['gas_cv_lower_j_mol_k'] for k in names},'manufactured-explicit-error-envelope',('manufactured-envelope',))
    fluid=RigidStorage(mechanical,phases,envelope,True);els=('C','O','N','H')
    rows=(('A','solid',(1,0,0,0)),('B','solid',(F(1,2),F(1,2),0,0)),('O2','gas',(0,1,0,0)),('N2','gas',(0,0,1,0)),('H2O','gas',convention.fractions(els,water.reference.molar_mass_kg_mol)))
    components=tuple(Component(n,p,es,('manufactured-elements',) if n!='H2O' else ('ciaaw-2024-abridged-atomic-weights',convention.facts_sha256)) for n,p,es in rows)
    ref='nist_298.15K_element_standard_formation';tref=F(case['reference_temperature_k']);pref=F(case['reference_pressure_pa'])
    anchors=[Anchor('A',F(),ref,tref,pref,'solid',('manufactured-coordinate-A-zero',))]
    for n in names:anchors.append(Anchor(n,F(phases[n].evaluate(float(tref),float(pref)).enthalpy_j_mol)/F(phases[n].molar_mass_kg_mol),ref,tref,pref,'gas',('actual-bound-gas-reference',)))
    network=ReactionReferenceNetwork(els,components,(Reaction('artificial-oxidation',tuple(case['reaction_mass_row']),case['reaction_enthalpy_j_kg'],'kg_A_consumed',('manufactured-q',)),),tref,pref,'kg_of_declared_components',ref,'manufactured_test_fixture','exact-defined-nominal-parameters',('manufactured-network',),tuple(anchors))
    solids=tuple(MassSolid(n,cp,v,('manufactured-solid-'+n,)) for n,cp,v in zip(('A','B'),case['solid_cp_j_kg_k'],case['solid_volume_m3_kg']))
    storage=WetMixedStorage(fluid,solids,network.solve(),td,case['bulk_volume_m3'],convention)
    return storage

def experiment(out,attempt):
    from sludge_sandbox.mass_wet_transport import WetPair,WetFace,integrate_wet_pair
    from sludge_sandbox.phase_storage import InversePolicy
    from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
    from audit_prefix import audit
    case=read(HERE/'inputs/case.json');require(attempt in case['step_counts'],'registered_mesh_required')
    st=build_storage(out);save(out/'storage-inputs.json',capture(st))
    wd=HERE/'inputs/water'
    chemical=WaterChemicalPotential(wd,backend='heos',backend_manifest=wd/'heos-8.0.0-approved-manifest.json')
    face_values={k:tuple(v) if isinstance(v,list) else v for k,v in case['face'].items()}
    pair=WetPair((st,st),(InversePolicy(**case['inverse_policy']),)*2,chemical,tuple(case['rate_constants_per_s']),tuple(case['oxygen_references_mol']),tuple(case['transfer_coefficients_mol_s_pa']),tuple(case['coefficient_source_ids']),WetFace(**face_values))
    identity=pair.binding();save(out/'pair-inputs.json',capture(pair))
    initial=[];points=[]
    for i,(values,t) in enumerate(zip(case['initial_cells'],case['initial_temperatures_k'])):
        proto=st.state(tuple(values['solid_mass_kg']),values['liquid_water_mol'],tuple(values['gas_amounts_mol']),0.)
        save(out/('initial-prototype-'+str(i)+'.json'),capture(proto))
        point=st.evaluate(proto,t);points.append(point);save(out/('initial-forward-'+str(i)+'.json'),capture(point))
        initial.append(replace(proto,internal_energy_j=point.total_internal_energy_j))
    initial=tuple(initial);save(out/'initial.json',capture(initial))
    count=case['step_counts'][attempt]
    # Full returned failed prefix is saved before any acceptance assertion.
    result=integrate_wet_pair(pair,initial,duration_s=case['duration_s'],steps=count,maximum_wall_seconds=case['maximum_wall_seconds'])
    encoded=capture(result);save(out/'run-result.json',encoded)
    outcome={'core_status':result.status,'core_reason':result.reason,'accepted_steps':len(result.ledgers),'requested_steps':count,'evaluations_attempted':result.evaluations_attempted,'evaluations_completed':result.evaluations_completed,'integration_elapsed_seconds':result.elapsed_seconds,'pair_identity':identity}
    save(out/'outcome-before-gates.json',outcome)
    require(pair.binding()==identity,'pair_source_changed')
    checked=audit(encoded,capture(initial),capture(st),case,requested_steps=count)
    save(out/'prefix-audit.json',checked)
    require(result.status=='completed' and len(result.ledgers)==count,'registered_segment_not_completed')
    require(result.evaluations_attempted==result.evaluations_completed==3*count,'actual_three_stage_call_count')
    require(result.times_s[-1]==F(case['duration_s']),'registered_final_time')
    require(checked['accepted_prefixes']==count,'full_prefix_audit_required')
    if attempt=='fine':
        previous=read(HERE/'coarse/run-result.json');previous_initial=read(HERE/'coarse/initial.json')
        require(previous_initial==capture(initial),'same_original_initial_required')
        require(read(HERE/'coarse/runtime-before.json')==read(out/'runtime-before.json'),'same_execution_runtime_required')
        comparisons={}
        for i,(left,right) in enumerate(zip(previous['states'][-1],encoded['states'][-1])):
            comparisons[str(i)]={'solid_mass_kg':[abs(a-b) for a,b in zip(left['solid_mass_kg'],right['solid_mass_kg'])],
              'liquid_water_mol':abs(left['liquid_water_mol']-right['liquid_water_mol']),
              'gas_amounts_mol':[abs(a-b) for a,b in zip(left['gas_amounts_mol'],right['gas_amounts_mol'])],
              'internal_energy_j':abs(left['internal_energy_j']-right['internal_energy_j'])}
        save(out/'coarse-fine-descriptive.json',{'differences':comparisons,'qualification':'Descriptive time-mesh differences only; not an independent native RHS oracle, convergence order or spatial admission gate.'})
    return dict(outcome,status='passed',qualification=case['qualification'])

def verify_previous(expected):
    require(type(expected) is dict and expected,'external_parent_hashes_required')
    for name,digest in expected.items():require(sha(HERE/name)==digest,'prior_coarse_evidence_changed')
    status=read(HERE/'supervised-coarse/status.json')
    require(status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] is True,'coarse_process_not_terminal_reaped_success')
    require(read(HERE/'coarse/report.json')['status']=='passed','coarse_not_passed')

def run(expected,attempt,parent_hashes=None):
    require(attempt in ('coarse','fine'),'registered_attempt_name')
    out=HERE/attempt;out.mkdir(exist_ok=False);report={'status':'started'};save(out/'report.json',report);start=time.monotonic();before=None
    try:
        _,before,env=verify(expected);save(out/'runtime-before.json',before);save(out/'environment.json',env);save(out/'inputs-before.json',hashes(HERE/'inputs'))
        if attempt=='fine':verify_previous(parent_hashes);save(out/'parent-hashes.json',parent_hashes)
        report.update(experiment(out,attempt))
    except BaseException as exc:report.update(status='failed',error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
    finally:
        try:
            _,after,_=verify(expected);save(out/'runtime-after.json',after);save(out/'inputs-after.json',hashes(HERE/'inputs'));require(before is None or before==after,'runtime_changed')
            if attempt=='fine' and parent_hashes is not None:verify_previous(parent_hashes)
            report['runtime_unchanged']=True
        except BaseException as exc:report.update(status='failed',integrity_error=str(exc),integrity_traceback=traceback.format_exc())
        report.update(elapsed_s=time.monotonic()-start,runner_sha256=sha(__file__),freeze_sha256=expected);save(out/'report.json',report)
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True)
    prep=sub.add_parser('prepare');prep.add_argument('--module-sha256',required=True)
    exe=sub.add_parser('run');exe.add_argument('--freeze-sha256',required=True);exe.add_argument('--attempt',choices=('coarse','fine'),required=True);exe.add_argument('--parent-hashes-json')
    a=p.parse_args()
    if a.mode=='prepare':
        try:result=prepare(a.module_sha256)
        except BaseException as exc:save(HERE/'preparation-failure.json',{'error':str(exc),'traceback':traceback.format_exc()});raise
    else:result=run(a.freeze_sha256,a.attempt,None if a.parent_hashes_json is None else json.loads(a.parent_hashes_json))
    print(json.dumps(result,indent=2,allow_nan=False))
    if result['status']=='failed':raise SystemExit(1)
