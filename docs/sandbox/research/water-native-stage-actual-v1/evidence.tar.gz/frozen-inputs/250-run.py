"""One preregistered ordinary native full/fine trial; never a global commit."""
from pathlib import Path
from fractions import Fraction
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent


def main():
    begun = time.monotonic()
    output = HERE / 'attempt01'
    output.mkdir(exist_ok=False)
    freeze = json.loads((HERE / 'EXECUTION_FREEZE.json').read_bytes())
    case = json.loads((HERE / 'CASE.json').read_bytes())
    limits = case['resource_budget']
    summary = {'status': 'started', 'freeze': freeze, 'case': case,
               'qualification': 'conditional_source_water_original_manufactured_material_and_error_contracts',
               'native_internal_call_count': None, 'global_commit': False}
    session = None

    def sha(path):
        try:
            return hashlib.sha256(Path(path).read_bytes()).hexdigest()
        except OSError:
            return None

    def save(path, value):
        from sludge_sandbox.mass_wet_pressure_interval import data
        tmp = path.with_suffix('.partial')
        tmp.write_text(json.dumps(data(value), indent=2, allow_nan=False) + '\n')
        os.replace(tmp, path)

    def members():
        return {directory: sorted(str(p) for p in Path(directory).rglob(pattern) if p.is_file())
                for directory, pattern in freeze['directory_patterns'].items()}

    def guard():
        expected_package = Path(freeze['installed_package_root'])
        spec = importlib.util.find_spec('sludge_sandbox')
        if spec is None or spec.origin is None or Path(spec.origin).resolve() != expected_package / '__init__.py':
            raise ValueError('actual_import_path_not_frozen_installation')
        direct = json.loads(importlib.metadata.distribution('sludge-vme').read_text('direct_url.json'))
        if direct != freeze['direct_url'] or direct.get('dir_info', {}).get('editable', False):
            raise ValueError('actual_distribution_not_frozen_installation')
        for name, module in tuple(sys.modules.items()):
            if name == 'sludge_sandbox' or name.startswith('sludge_sandbox.'):
                filename = getattr(module, '__file__', None)
                if filename is None:
                    raise ValueError('loaded_module_without_frozen_source:' + name)
                actual = Path(filename).resolve()
                if not actual.is_relative_to(expected_package) or str(actual) not in freeze['files']:
                    raise ValueError('loaded_module_not_frozen_installation:' + name)
        if time.monotonic() - begun >= limits['whole_study_wall_seconds']:
            raise TimeoutError('original_whole_study_wall')
        if any(sha(path) != digest for path, digest in freeze['files'].items()):
            raise ValueError('frozen_source_changed')
        if members() != freeze['directory_members']:
            raise ValueError('frozen_directory_membership_changed')

    def remaining():
        guard()
        return limits['whole_study_wall_seconds'] - (time.monotonic() - begun)

    def cancel():
        guard()
        return False

    try:
        guard()
        from build_initial import build_initial
        from sludge_sandbox.exact_event_clock import ExactEventTime
        from sludge_sandbox.mass_wet_exact_stage import MixedStagePolicy, try_step_doubling
        from sludge_sandbox.mass_wet_pressure_interval import LiquidBranchModelPolicy
        from sludge_sandbox.mass_wet_pressure_seed import LiquidSeedPolicy
        from sludge_sandbox.mass_wet_pressure_session import PressureSession, PressureSessionBudget

        save(output / 'summary.json', summary)

        def initial_guard():
            guard()
            if time.monotonic() - begun >= limits['initialization_wall_seconds']:
                raise TimeoutError('initial_energy_construction_wall')

        pair, states = build_initial(output / 'initial', initial_guard)
        initial_guard()
        policy = MixedStagePolicy(**case['stage_policy'])
        branch = LiquidBranchModelPolicy(freeze['official_pdf'], freeze['coefficient_json'],
                                         pair.storages[0].water.implementation.sha256)
        session = PressureSession(pair, branch_policy=branch, seed_policy=LiquidSeedPolicy(),
            budget=PressureSessionBudget(limits['maximum_seed_evaluations'],
                limits['maximum_proof_operations'], limits['session_elapsed_wall_seconds'],
                limits['maximum_boxes_per_primitive']), caller_guard=guard,
            remaining_caller_wall=remaining)
        save(output / 'pressure-session-before.json', session.snapshot())
        result = try_step_doubling(pair, states,
            start=ExactEventTime(Fraction(*case['start_seconds_fraction'])),
            end=ExactEventTime(Fraction(*case['end_seconds_fraction'])), policy=policy,
            cancel=cancel, pressure_session=session)
        # Preserve the entire explicit opt-in subtype before checking acceptance.
        save(output / 'trial.json', result)
        after = session.snapshot()
        save(output / 'pressure-session-after.json', after)
        summary.update(status='stage_' + result.status, reason=result.reason,
            host_attempted=result.evaluations_attempted, host_completed=result.evaluations_completed,
            comparisons=result.comparisons, trial_elapsed_seconds=result.elapsed_seconds)
        guard()
        if result.status == 'accepted':
            initial_status = json.loads((output / 'initial/operation-status.json').read_bytes())
            initial_costs = initial_status['costs']
            if not (initial_costs['initial_forward_attempted'] == initial_costs['initial_forward_completed'] == 2
                    and initial_costs['host_attempted'] == initial_costs['host_completed'] == 0
                    and result.evaluations_attempted == result.evaluations_completed == 9
                    and len(result.samples) == 9 and len(result.steps) == len(result.panels) == 3
                    and len(after.attempts) == 4
                    and all(attempt.status == 'proved_conditional_query' for attempt in after.attempts)
                    and after.proof_attempted == after.proof_completed == 16 and after.cost_complete):
                raise ValueError('accepted_trial_does_not_match_preregistered_2_9_4_work')
    except Exception as exc:
        summary.update(status='failed', reason=type(exc).__name__ + ': ' + str(exc),
                       traceback=traceback.format_exc())
    finally:
        if session is not None:
            save(output / 'pressure-session-final.json', session.snapshot())
        summary['source_after'] = {p: sha(p) if Path(p).is_file() else None for p in freeze['files']}
        summary['directory_members_after'] = members()
        summary['inputs_unchanged'] = summary['source_after'] == freeze['files']
        summary['membership_unchanged'] = summary['directory_members_after'] == freeze['directory_members']
        summary['elapsed_seconds'] = time.monotonic() - begun
        if not summary['inputs_unchanged'] or not summary['membership_unchanged'] or summary['elapsed_seconds'] >= limits['whole_study_wall_seconds']:
            summary['status'] = 'failed'
        save(output / 'summary.json', summary)
    print(summary['status'], summary.get('reason'), summary['elapsed_seconds'])
    return 0 if summary['status'] == 'stage_accepted' else 1


if __name__ == '__main__':
    raise SystemExit(main())
