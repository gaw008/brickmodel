"""One invocation, external 130-second watchdog; preserves partial evidence."""
from pathlib import Path
import subprocess,os,signal,time,json,hashlib,sys
root=Path(__file__).resolve().parent
runner=root/'run.py';freeze=root/'EXECUTION_FREEZE.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads(freeze.read_text())['files'][str(runner)]
assert sha(runner)==expected
start=time.monotonic()
with (root/'supervised01.log').open('xb') as log:
    child=subprocess.Popen([sys.executable,str(runner)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    killed=False
    try:code=child.wait(timeout=130.)
    except subprocess.TimeoutExpired:
        killed=True
        try:os.killpg(child.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        code=child.wait()
record={'returncode':code,'external_timeout':killed,'external_limit_seconds':130.,'elapsed_seconds':time.monotonic()-start,'runner_sha256':expected,'runner_unchanged':sha(runner)==expected,'freeze_sha256':sha(freeze),'supervisor_sha256':sha(Path(__file__))}
with (root/'supervisor-result01.json').open('x') as f:json.dump(record,f,indent=2)
print(record)
raise SystemExit(code if not killed else 124)
