from pathlib import Path
p=Path('/private/tmp/brick-water-pressure-interval-v1/native_stage_study/audit_stage.py')
s=p.read_text()
insert='''def audit_original_prefixes(steps,integrals,initial,storage,source_case):
    """Independent raw saved accounting under original strict prefix gates."""
    gas_ids=storage['fluid_template']['mechanical']['gas_species_ids']
    check(gas_ids==source_case['gas_ids']==['O2','N2','H2O'],'original_gas_layout')
    masses=[F(storage['fluid_template']['gas_phases'][k]['molar_mass_kg_mol']) for k in gas_ids]
    network=storage['reference']['network'];components=network['components']
    check([c['component_id'] for c in components]==['A','B',*gas_ids],'original_component_layout')
    def exact(v):return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)
    def totals(states):
        elements=[F() for _ in network['elements']];mass=water=energy=F()
        for state in states:
            check(state['energy_model_identity']==storage['_identity'],'original_storage_binding')
            values=[*map(F,state['solid_mass_kg']),*(F(n)*m for n,m in zip(state['gas_amounts_mol'],masses,strict=True))]
            values[-1]+=F(state['liquid_water_mol'])*masses[-1]
            for v,c in zip(values,components,strict=True):
                check(len(c['element_mass_fractions'])==len(elements),'original_element_layout')
                for j,f in enumerate(c['element_mass_fractions']):elements[j]+=v*exact(f)
            mass+=sum(values,F());water+=F(state['liquid_water_mol'])+F(state['gas_amounts_mol'][2]);energy+=F(state['internal_energy_j'])
        return elements,mass,water,energy
    gates=source_case['prefix_gates'];maxima={k:F() for k in gates};base=totals(initial)
    for state,registered in zip(initial,source_case['initial_cells'],strict=True):
        for field in ('solid_mass_kg','liquid_water_mol','gas_amounts_mol'):check(state[field]==registered[field],'original_registered_inventory')
    def gate(name,value):
        value=abs(value);maxima[name]=max(maxima[name],value)
        check(value<F(gates[name]),'original_strict_prefix_gate:'+name)
    origin=amounts(initial)
    for indices in ((0,),(1,2)):
        sums={k:F() for k in origin};energies=[F(),F()]
        for index in indices:
            if index>=len(steps):continue
            row=steps[index]['endpoint_state'];el,m,w,u=totals(row)
            gate('global_elements_kg',max(abs(a-b) for a,b in zip(el,base[0],strict=True)))
            for name,value,start in [('global_mass_kg',m,base[1]),('global_water_mol',w,base[2]),('global_energy_j',u,base[3])]:gate(name,value-start)
            represented=integrals[index][1];net=net_inventory(represented);actual=amounts(row)
            for key in sums:
                sums[key]+=net[key]
                gate({'solid':'local_solid_kg','liquid':'local_liquid_mol','gas':'local_gas_mol'}[key[0]],actual[key]-origin[key]-sums[key])
            for i,sign in enumerate((-1,1)):
                energies[i]+=sign*represented['face_energy',]
                gate('local_energy_j',F(row[i]['internal_energy_j'])-F(initial[i]['internal_energy_j'])-energies[i])
                check(represented['chemical_gas',i,2]==0,'zero_water_chemical_source')
            gate('face_components_j',represented['face_energy',]-represented['heat',]-sum((represented['diffusion_energy',j]+represented['advection_energy',j] for j in range(3)),F()))
    return {'maxima':{k:str(v) for k,v in maxima.items()},'original_strict_gates':gates}


'''
s=s.replace('def audit_stage(stage,case):',insert+'def audit_stage(stage,case,initial,storage,source_case):')
s=s.replace("    check(len(steps)<=3,'at_most_three_paths')", """    check(len(steps)<=3,'at_most_three_paths')
    check(stage['initial_state']==initial,'actual_initial_energy_binding')
    check(time_of(stage['start'])==F(*case['start_seconds_fraction']) and time_of(stage['end'])==F(*case['end_seconds_fraction']),'registered_exact_stage_time')
    check(decode(json.loads(stage['original_stage_policy_json']))==policy,'original_policy_bytes')
    check(decode(json.loads(stage['original_stage_inputs_json']))==[initial,stage['start'],stage['end'],policy],'original_input_bytes')
    if stage['status']=='accepted':
        check(len(steps)==len(stage['panels'])==3 and len(stage['samples'])==stage['evaluations_attempted']==stage['evaluations_completed']==9,'accepted_nine_actual_callbacks')
        check([s['role'] for s in stage['samples']]==[p+':'+r for p in ('full','half1','half2') for r in ('start','midpoint','endpoint')],'nine_actual_roles')
        for index,trial in enumerate(steps):
            check(stage['panels'][index]==trial['panel'],'three_saved_panel_binding')
            check(stage['samples'][3*index:3*index+3]==[trial['panel']['start_sample'],trial['panel']['midpoint_sample'],trial['endpoint_sample']],'nine_sample_trial_binding')""")
s=s.replace("    before,after=stage['pressure_session_before']", "    prefixes=audit_original_prefixes(steps,integrals,initial,storage,source_case)\n    before,after=stage['pressure_session_before']")
s=s.replace("check(len(ops)==4 and all(o['status']=='completed' for o in ops),'all_four_proof_operations')", """check([o['name'] for o in ops]==['coexistence','coupled_mechanical_root','full_temperature_connected_density_tube','observed_native_query'] and all(o['status']=='completed' for o in ops),'all_four_proof_operations')
            inv=rate['inverse'];point=inv['point']['fluid']['mechanical'];t=F(point['temperature_k']);epsilon=F(inv['temperature_error_bound_k'])
            check(F(params['temperature']['lo'])<=t-epsilon<=t+epsilon<=F(params['temperature']['hi']),'full_original_inverse_temperature')
            check(F(params['nominal_pressure_pa'])==F(point['pressure_pa']) and F(params['epsilon'])==epsilon,'original_nominal_and_epsilon')""")
s=s.replace("'audited_complete_steps':summaries,", "'audited_complete_steps':summaries,'original_global_and_local_prefixes':prefixes,")
s=s.replace("parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()", "parser.add_argument('--output',type=Path,required=True);parser.add_argument('--initial',type=Path,required=True);parser.add_argument('--storage',type=Path,required=True);args=parser.parse_args()")
s=s.replace("result=audit_stage(stage,case)", "initial=decode(json.loads(args.initial.read_bytes()));storage=json.loads(args.storage.read_bytes());source_case=json.loads(Path(case['source_case']).read_bytes());result=audit_stage(stage,case,initial,storage,source_case)")
p.write_text(s)
