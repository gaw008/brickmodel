"""Pure synthetic arithmetic checks for independent auditor, no model imports."""
import importlib.util
from pathlib import Path
from fractions import Fraction as F
import copy
import pytest
spec=importlib.util.spec_from_file_location('independent_audit',Path(__file__).with_name('audit_stage.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)


def fixture():
    initial=[dict(solid_mass_kg=[1.,2.],liquid_water_mol=1.,gas_amounts_mol=[1.,1.,1.],internal_energy_j=10.,energy_model_identity='toy') for _ in range(2)]
    ids=['O2','N2','H2O']
    storage={'_identity':'toy','fluid_template':{'mechanical':{'gas_species_ids':ids},'gas_phases':{k:{'molar_mass_kg_mol':m} for k,m in zip(ids,[.032,.028,.018])}},'reference':{'network':{'elements':['nominal'],'components':[{'component_id':k,'element_mass_fractions':[{'numerator':1,'denominator':1}]} for k in ['A','B',*ids]]}}}
    gates={k:1e-12 for k in ['global_elements_kg','global_mass_kg','global_water_mol','global_energy_j','local_solid_kg','local_liquid_mol','local_gas_mol','local_energy_j','face_components_j']}
    case={'gas_ids':ids,'initial_cells':initial,'prefix_gates':gates}
    flux={('face_energy',):F(),('heat',):F()}
    for i in range(2):
        flux['phase_water',i]=F()
        for j in range(2):flux['solid',i,j]=F()
        for j in range(3):flux['chemical_gas',i,j]=F()
    for j in range(3):
        for name in ('face_species','diffusion_energy','advection_energy'):flux[name,j]=F()
    steps=[{'endpoint_state':copy.deepcopy(initial)} for _ in range(3)]
    return steps,[(flux,flux)]*3,initial,storage,case


def test_three_zero_flux_prefixes_separate_paths():
    result=a.audit_original_prefixes(*fixture())
    assert all(F(v)==0 for v in result['maxima'].values())


def test_second_half_water_change_cannot_hide_in_global_totals():
    steps,integrals,initial,storage,case=fixture()
    steps[2]['endpoint_state'][0]['liquid_water_mol']+=.001
    with pytest.raises(ValueError,match='original_strict_prefix_gate:global_'):
        a.audit_original_prefixes(steps,integrals,initial,storage,case)


def test_full_polynomial_interior_minimum():
    assert a.minimum(F(1),F(-4),F(3),F(1))==(F(-1,3),F(2,3))
