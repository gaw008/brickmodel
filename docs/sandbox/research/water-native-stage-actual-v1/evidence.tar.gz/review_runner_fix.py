"""Pure extracted-guard review: no imports of physics or native evaluation."""
from pathlib import Path
import ast,hashlib,json,types,tempfile
P=Path(__file__).resolve().parent
oldhash=json.loads((P/'runner-review01.json').read_text())['files']
s=(P/'run.py').read_text()
old=s.replace('import importlib.metadata\nimport importlib.util\n','').replace('import sys\n','')
old=old.replace('''        try:
            return hashlib.sha256(Path(path).read_bytes()).hexdigest()
        except OSError:
            return None''','''        return hashlib.sha256(Path(path).read_bytes()).hexdigest()''')
a=old.index("        expected_package = Path(freeze['installed_package_root'])")
b=old.index('        if time.monotonic() - begun',a)
old=old[:a]+old[b:]
old=old.replace("        after = session.snapshot()\n        save(output / 'pressure-session-after.json', after)","        save(output / 'pressure-session-after.json', session.snapshot())")
a=old.index("        if result.status == 'accepted':")
b=old.index('    except Exception as exc:',a)
old=old[:a]+old[b:]
assert hashlib.sha256(old.encode()).hexdigest()==oldhash['run.py']
prep=(P/'prepare.py').read_text().replace("               'installed_package_root': str(package),\n",'')
assert hashlib.sha256(prep.encode()).hexdigest()==oldhash['prepare.py']
for n,t in [('run.py',old),('prepare.py',prep)]:
 target=P/(n+'.before-import-binding')
 if target.exists():assert target.read_text()==t
 else:target.write_text(t)

def extract(text):
 tree=ast.parse(text);main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
 nodes=[x for x in main.body if isinstance(x,ast.FunctionDef) and x.name in ('sha','guard')]
 return compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'actual_runner_guard','exec')
results=[]
with tempfile.TemporaryDirectory() as td:
 root=Path(td).resolve(); package=root/'installed';package.mkdir(); init=package/'__init__.py';init.write_text('')
 direct={'dir_info':{'editable':False}}
 freeze={'installed_package_root':str(package),'direct_url':direct,'files':{str(init):hashlib.sha256(b'').hexdigest()},'directory_members':{}}
 for label,origin,modulefile,dist,remove,expected in [
 ('normal',init,init,direct,False,None),
 ('shadow_package',root/'shadow/__init__.py',init,direct,False,'actual_import_path_not_frozen_installation'),
 ('shadow_loaded_module',init,root/'shadow/module.py',direct,False,'loaded_module_not_frozen_installation'),
 ('changed_distribution',init,init,{'dir_info':{'editable':True}},False,'actual_distribution_not_frozen_installation'),
 ('missing_source',init,init,direct,True,'frozen_source_changed')]:
  init.write_text('')
  if remove:init.unlink()
  ns={'Path':Path,'hashlib':hashlib,'json':json,'freeze':freeze,'begun':0,'limits':{'whole_study_wall_seconds':120},'time':types.SimpleNamespace(monotonic=lambda:1),'members':lambda:{},'sys':types.SimpleNamespace(modules={'sludge_sandbox.x':types.SimpleNamespace(__file__=str(modulefile))}), 'importlib':types.SimpleNamespace(util=types.SimpleNamespace(find_spec=lambda _:types.SimpleNamespace(origin=str(origin))),metadata=types.SimpleNamespace(distribution=lambda _:types.SimpleNamespace(read_text=lambda _:json.dumps(dist))))}
  exec(extract(s),ns)
  reason=None
  try:ns['guard']()
  except ValueError as e:reason=str(e)
  assert (reason is None if expected is None else reason.startswith(expected)),(label,reason)
  results.append({'case':label,'observed':reason or 'accepted','expected':expected or 'accepted'})
  if label=='shadow_package':
   exec(extract(old),ns);ns['guard']()
   results.append({'case':'old_guard_shadow_package','observed':'accepted','qualification':'original HIGH reproduced with actual old guard and synthetic import context'})
out={'status':'passed','tests':results,'source_sha':{n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ('run.py','prepare.py')},'recovered_original_sha':oldhash,'native_calls':0,'scope':'actual extracted guard only; no run main/prepare/stage/session execution'}
(P/'runner-review-fix02.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
