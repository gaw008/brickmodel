from pathlib import Path
p=Path('/private/tmp/brick-water-pressure-interval-v1/native_stage_study/review_saved_native.py')
s=p.read_text();p.with_name('review_saved_native-before-energy-expansion.py').write_text(s)
insert='''    descriptor=json.loads(w['implementation']['canonical_descriptor'])['real_fluid']
    assert F(float.fromhex(descriptor['public_mass_hex']))==mp==F(w['reference']['molar_mass_kg_mol'])
    assert F(float.fromhex(descriptor['native_mass_hex']))==mn
    assert w['method_id']=='iapws95_real_fluid_helmholtz' and w['phase']=='liquid'
    assert descriptor['runtime']['fluid_sha256']=='512a3371b9d5881e46b4a6106835a8a6463857c88d8a8c389794f801314433b29'
'''
# Do not invent the coefficient hash: get it from the frozen coefficient bytes.
insert=insert.replace("'512a3371b9d5881e46b4a6106835a8a6463857c88d8a8c389794f801314433b29'", "sha(Path(freeze['coefficient_json']))")
s=s.replace("    assert m0['gas_inventory_mol']",insert+"    assert m0['gas_inventory_mol']")
more='''def fraction_saved(value):
    return F(value['numerator'],value['denominator']) if isinstance(value,dict) else F(value)

def check_all_sample_energy(trial,pair):
    reports=[]
    for sample in trial['samples']:
        for cell,(state,rate) in enumerate(zip(sample['state'],sample['rates']['cells'],strict=True)):
            inv=rate['inverse'];p=inv['point'];st=pair['storages'][cell];m=p['fluid']['mechanical']
            assert inv['target_energy_j']==state['internal_energy_j'] and p['model_identity']==state['energy_model_identity']==st['_identity']
            assert m['liquid_inventory_mol']==state['liquid_water_mol'] and m['gas_inventory_mol']==dict(zip(('O2','N2','H2O'),state['gas_amounts_mol'],strict=True))
            net=st['reference']['network'];tr=fraction_saved(net['reference_temperature_k']);pr=fraction_saved(net['reference_pressure_pa'])
            terms=[F(mass)*(fraction_saved(h)+F(solid['cp_j_kg_k'])*(F(m['temperature_k'])-tr)-pr*F(solid['volume_m3_kg'])) for mass,solid,h in zip(state['solid_mass_kg'],st['solids'],st['reference']['particular_h0_j_kg'],strict=True)]
            total=F(p['fluid']['internal_energy_j'])+sum(terms,F())
            assert p['total_internal_energy_j']==float(total) and p['solid_internal_energy_j']==list(map(float,terms))
            cp=F(p['fluid']['minimum_heat_capacity_j_k'])+sum((F(mass)*F(solid['cp_j_kg_k']) for mass,solid in zip(state['solid_mass_kg'],st['solids'],strict=True)),F())
            assert 0<F(p['minimum_heat_capacity_j_k'])<=cp
            error=F(p['fluid']['energy_error_bound_j'])+abs(F(p['total_internal_energy_j'])-total)+F(state['liquid_water_mol'])*F(st['fluid_template']['envelope']['liquid_abs_du_dp_bound_j_mol_pa'])*F(p['extra_pressure_error_pa'])
            assert F(p['extra_pressure_error_pa'])>=0 and F(p['energy_error_j'])>=error
            required=(abs(F(p['total_internal_energy_j'])-F(state['internal_energy_j']))+F(p['energy_error_j']))/F(p['minimum_heat_capacity_j_k'])
            assert required<=F(inv['temperature_error_bound_k'])
            reports.append({'role':sample['role'],'cell':cell,'required_epsilon':str(required),'saved_epsilon':str(F(inv['temperature_error_bound_k']))})
    assert len(reports)==18
    return reports

'''
s=s.replace("s=read(O/'summary.json')",more+"s=read(O/'summary.json')")
s=s.replace("reports=[audit_query(q,pair)","sample_energy=check_all_sample_energy(trial,pair)\nreports=[audit_query(q,pair)")
s=s.replace("'queries':reports,","'queries':reports,'all18_sample_cell_energy':sample_energy,")
s=s.replace("R/'review_saved_native01.json'","R/'review_saved_native02.json'")
p.write_text(s)
