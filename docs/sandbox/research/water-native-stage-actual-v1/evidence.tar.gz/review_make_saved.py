from pathlib import Path
old=Path('/private/tmp/brick-water-pressure-interval-v1/fresh_query/review_saved_fresh.py').read_text()
head=old[:old.index("s=read(O/'summary.json')")]
core=old[old.index("p=blob(e['parameters_json'])"):old.index("out={'status':'PASS'")]
core=core.replace("states[0]","states[cell]").replace("rates['cells'][0]","rates['cells'][cell]").replace("pair['storages'][0]","pair['storages'][cell]").replace("pair['inverse_policies'][0]","pair['inverse_policies'][cell]")
core=core.replace("seed=read(O/'seed-proposals.json');", "seed=query['seed'];")
core=core.replace("e['budget']['maximum_proof_operations']==4", "e['budget']['maximum_proof_operations']>=4").replace('<=20','<=90')
core=core.replace("seed['boxes']", "seed['boxes']")
body='''def audit_query(query,pair):
    context,states,rate,cell=blob(query['context'])
    rates={'cells':[None,None]};rates['cells'][cell]=rate
    e=query['proof']
    assert query['status']==e['status']=='proved_conditional_query' and query['failure_kind'] is None and e['failure_kind'] is None
    assert blob(e['original_query_json'])==[states,rate,cell]
    assert hashlib.sha256(e['original_query_json']).hexdigest()==query['request_sha256']==e['request_sha256']
'''+''.join('    '+line+'\n' for line in core.splitlines())+'''    return {'cell':cell,'role':context['role'],'request_sha256':e['request_sha256'],'K_norm_upper':str(k['contraction_upper']),'minimum_K_margin':str(min(map(F,sum(k['strict_margins'],[])))),'tube_visits':len(tube['visits']),'tube_leaves':len(leaves),'native_math_evaluations':qout['attempted'],'volume_error_bound':str(metrics['combined_volume_error_bound']),'original_volume_error':str(decl),'radius_exact':str(e['pressure_radius_pa']),'radius_pa':float(e['pressure_radius_pa']),'proof_elapsed_seconds':e['elapsed_seconds']}

s=read(O/'summary.json');freeze=read(R/'EXECUTION_FREEZE.json');watch=read(R/'supervisor-result01.json');trial=read(O/'trial.json')
assert s['freeze']==freeze and s['source_after']==freeze['files']=={p:sha(Path(p)) for p in freeze['files']}
assert len(freeze['files'])==252 and freeze['installed_python_module_count']==104
members={d:sorted(str(p) for p in Path(d).rglob(pattern) if p.is_file()) for d,pattern in freeze['directory_patterns'].items()}
assert members==freeze['directory_members']==s['directory_members_after']
assert s['status']=='stage_accepted' and s['inputs_unchanged'] and s['membership_unchanged']
assert watch['returncode']==0 and not watch['external_timeout'] and watch['runner_unchanged']
assert watch['runner_sha256']==sha(R/'run.py') and watch['freeze_sha256']==sha(R/'EXECUTION_FREEZE.json') and watch['supervisor_sha256']==sha(R/'supervise.py')
assert s['elapsed_seconds']<120 and watch['elapsed_seconds']<watch['external_limit_seconds']==130
initial=read(O/'initial/initial.json');pair=read(O/'initial/pair-inputs.json');case=read(R/'CASE.json');initialstatus=read(O/'initial/operation-status.json')
assert initialstatus['status']=='completed_initial_energy_construction' and initialstatus['elapsed_seconds']<30
assert initialstatus['costs']=={'initial_forward_attempted':2,'initial_forward_completed':2,'host_attempted':0,'host_completed':0,'native_internal_call_count':None}
for i,T in enumerate(case['initial_temperature_design_k']):
    point=read(O/f'initial/initial-forward-{i}.json');proto=read(O/f'initial/initial-prototype-{i}.json')
    assert point['fluid']['mechanical']['temperature_k']==T and initial[i]['internal_energy_j']==point['total_internal_energy_j']
    assert all(initial[i][k]==proto[k] for k in ('solid_mass_kg','liquid_water_mol','gas_amounts_mol','energy_model_identity'))
before=trial['pressure_session_before'];after=trial['pressure_session_after'];final=read(O/'pressure-session-final.json')
assert before['attempts']==[] and len(after['attempts'])==4
assert after['attempts']==final['attempts']==read(O/'pressure-session-after.json')['attempts']
for name in ('original_configuration_json','original_physics_json','source_before','started_monotonic_s'):
    assert before[name]==after[name]==final[name]
assert all(x['cost_complete'] and x['elapsed_seconds']<90 for x in (before,after,final))
assert after['seed_attempted']==after['seed_completed']==20 and after['proof_attempted']==after['proof_completed']==16
assert trial['evaluations_attempted']==trial['evaluations_completed']==9 and trial['elapsed_seconds']<90
reports=[audit_query(q,pair) for q in after['attempts']]
assert [(q['cell'],q['role']) for q in reports]==[(0,'full'),(0,'fine'),(1,'full'),(1,'fine')]
# Only the independently written frozen saved arithmetic auditor is imported.
# It imports no model or EOS; production comparison numbers are not its oracle.
import importlib.util
spec=importlib.util.spec_from_file_location('saved_independent_audit',R/'audit_stage.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
arithmetic=audit.audit_stage(trial,case,initial,read(O/'initial/storage-inputs.json'),read(Path(case['source_case'])))
assert arithmetic==read(O/'saved-audit01.json')
result={'status':'PASS','files':252,'installed_modules':104,'trial_sha256':sha(O/'trial.json'),'freeze_sha256':sha(R/'EXECUTION_FREEZE.json'),'host_evaluations':9,'seed_evaluations':20,'proof_operations':16,'queries':reports,'trial_elapsed_seconds':trial['elapsed_seconds'],'whole_elapsed_seconds':s['elapsed_seconds'],'external_elapsed_seconds':watch['elapsed_seconds'],'arithmetic':arithmetic,'review_native_calls':0,'qualification':'Independent Fraction reconstruction of saved algebra, complete four-query association and three-stage ledger paths. EOS primitive residual/derivative bounds are reviewed-implementation premises, not independently re-executed here. Original U/Cp/v and model branch remain conditional.'}
with (R/'review_saved_native01.json').open('x') as stream:stream.write(json.dumps(result,indent=2)+'\\n')
print(json.dumps(result,indent=2))
'''
p=Path('/private/tmp/brick-water-pressure-interval-v1/native_stage_study/review_saved_native.py');p.write_text(head+body)
