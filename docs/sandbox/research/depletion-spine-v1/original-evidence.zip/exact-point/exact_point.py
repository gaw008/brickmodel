"""One actual captured T/P call through unchanged installed public HEOS provider."""
from __future__ import annotations
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import sys
import time
import traceback
from typing import Any

from sludge_sandbox.water_properties import load_water_properties

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
DATA = ROOT/'data/sandbox/water'


def encode(value: Any) -> Any:
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float:
        return {'value': value if math.isfinite(value) else None, 'hex': value.hex(), 'repr': repr(value)}
    if isinstance(value, Mapping):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(item) for item in value]
    if is_dataclass(value):
        return {field.name: encode(getattr(value, field.name)) for field in fields(value)}
    raise TypeError('unexpected diagnostic value type: '+type(value).__name__)


def module_identity() -> dict[str, dict[str, str]]:
    result = {}
    for name, module in tuple(sys.modules.items()):
        path = getattr(module, '__file__', None)
        if name.startswith('sludge_sandbox') and path:
            path = Path(path).resolve()
            assert '/site-packages/sludge_sandbox/' in str(path), str(path)
            relative = str(path).split('/site-packages/', 1)[1]
            assert path.read_bytes() == (ROOT/'src'/relative).read_bytes(), name
            result[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    return result


def main() -> int:
    output = HERE/'exact-point-result.json'
    if output.exists():
        raise SystemExit('Preserve prior point evidence; use a new reviewed directory for another attempt')
    started = time.monotonic()
    result: dict[str, Any] = {'status': 'started', 'requested_public_state_calls': 0,
        'scope': 'fresh-provider exact-point diagnostic; not full-trajectory validation',
        'setup_native_call_count': 'not separately instrumented; unchanged source-qualified public constructor'}
    provider = None
    failed = True
    try:
        plan = json.loads((HERE/'PLAN.json').read_text())
        captured_bytes = (HERE/'captured-tp.json').read_bytes()
        assert hashlib.sha256(captured_bytes).hexdigest() == plan['captured_snapshot_sha256']
        captured = json.loads(captured_bytes)
        arguments = captured['arguments_and_loop_locals']
        t = float.fromhex(arguments['t']['hex'])
        p = float.fromhex(arguments['p']['hex'])
        phase = arguments['phase']
        assert t == arguments['t']['value'] and p == arguments['p']['value']
        assert phase in ('liquid', 'vapor')
        result.update(arguments={'temperature_k': encode(t), 'pressure_pa': encode(p), 'phase': phase},
            installed_before=module_identity(), versions={name: importlib.metadata.version(name)
                for name in ('numpy', 'scipy', 'iapws', 'CoolProp', 'sludge-vme')})
        provider = load_water_properties(DATA, backend='heos', backend_manifest=DATA/'heos-8.0.0-approved-manifest.json')
        result.update(implementation=json.loads(provider.implementation.canonical_json),
            source_asset_sha256=dict(provider.source_asset_sha256), reference=encode(provider.reference),
            numerical_limits=encode(provider.numerical_limits), kernel_identity=provider._kernel.identity)
        assert provider._kernel.identity == plan['original_kernel_identity']
        result['requested_public_state_calls'] = 1
        state = provider.state_tp(t, p, phase=phase)
        result.update(status='passed', state=encode(state))
        failed = False
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        if provider is not None:
            # Existing diagnostic snapshots only; no extra state evaluation.
            try:
                result['existing_tp_iterations'] = encode(provider._kernel.last_tp)
                result['existing_coexistence_iterations'] = encode(provider._kernel.last_coexistence)
            except BaseException as exc:
                result['diagnostic_read_error'] = {'type': type(exc).__name__, 'message': str(exc)}
                result['status'] = 'failed'
                failed = True
        try:
            result['installed_after'] = module_identity()
        except BaseException as exc:
            result['post_identity_error'] = {'type': type(exc).__name__, 'message': str(exc)}
            result['status'] = 'failed'
            failed = True
        result['elapsed_s'] = time.monotonic()-started
        temporary = output.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
        temporary.replace(output)
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
