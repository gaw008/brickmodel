# Independent exact-point result audit

Read saved exact-point-result.json, captured snapshot and supervisor before/after manifests; performed standard-library file hashing and exact JSON comparisons only. No EOS, model imports or rerun.

Result SHA256: `027bccf488a0c5100b77302b364ace8084cef9829204e7d89155729c0133e13a`.

Supervisor status is failed, child return code 1, elapsed 1.1899102500028675 seconds. Child records failed / WaterNumericalError / heos_tp_not_converged, elapsed 0.9478506250015926 seconds and exactly one requested public state call. Constructor native setup remains separately declared and uncounted.

All 105 supervisor input hashes match before/after and current bytes. Captured T=295 K, P=53692.54782795906 Pa, liquid phase and kernel identity exactly match the snapshot. T/P hex, repr and value fields all match. All eight complete iteration dictionaries exactly match the original coupled exception capture, including density, native/target pressure, h/u, slope and residual representations; dictionary key order is immaterial. Thus the same two-cycle reproduces under fresh-provider history and unchanged original eight-iteration/density-dependent residual gate.

Installed module identity evidence contains 4 modules before and 6 after; script assertions require each loaded module's installed bytes to match production, and supervisor hashes independently show no drift. The captured original file remains untouched. Failure is preserved as failure, not recast as a successful physical state. This establishes reproducibility of the exact numerical defect without proving any proposed correction or coupled trajectory acceptance.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: exact-point failure evidence is internally consistent and reproduces the captured eight-row cycle. Original numerical failure remains unresolved.
