# Exception-only diagnostic review

Read-only review of diagnostic.py, run_diagnostic.py, PLAN.json, the detailed preregistration, copied-input records, original v3 inputs and relevant HEOS state_tp implementation. Performed standard-library AST parsing and file hashing only; no imports, tests, EOS, replay or production changes.

Approved script SHA256:
- diagnostic.py: `d5f7e12c10fe59d4296e72ad3ed06216aff338101b081c589ef17154edba69c4`
- run_diagnostic.py: `210a6921d76e29852ee9805e84161f524d409c373df16966eb15e2086e491b62`

All four script hashes match PLAN. fixture.py, depletion.py and callback-result.json are exact byte copies of their original v3 inputs. The replay executes the copied depletion entry once using its unchanged fixture and policies; it does not rerun the callback or add a water warmup. Pre-imports load class definitions without constructing HEOSCandidate.

The global trace hook installs a local hook only for the exact installed state_tp code object. Line/opcode events are disabled; capture matches only WaterNumericalError with the exact original failure reason. At that exception the eight-row iteration list and saturation snapshots are already computed. Capturing instance data attributes, allowlisted frame locals and recognized dataclass fields introduces no flash, saturation, property-provider or state-reconstruction calls. Arbitrary locals are not dumped. The actual known structures contain model/source descriptors and physical values, with no credential-bearing inputs identified. Values are detached and float repr/hex preserved. In the original kernel the local rho may already contain the final post-iteration update; the captured iteration list correctly preserves the actual evaluated densities and residuals, so analysis must use each row rather than assume local rho was evaluated.

Snapshot output uses temporary write followed by same-directory atomic replace. Capture/I/O exceptions are caught without substituting a numerical state or masking the original failure. Summary restoration of tracing and argv is in finally. The child returns the original entry exit code; observing the expected diagnostic snapshot does not turn a failed physical trajectory into success. Summary capture status is distinct from physical completion. Supervisor additionally requires both complete status and zero return code.

Output guards prevent reuse of existing diagnostic/result evidence. The supervisor captures installed/source/test/water inputs, copied scripts, PLAN, detailed plan and callback evidence before/after under a 150 s external cap; original solver limits remain 120 s/500 steps. Tracing incurs Python overhead and this is correctly declared. No claim of identical wall time or guaranteed exception reproduction is made. Execution remains conditional on the live full suite terminating and root maintaining the frozen runtime.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE the reviewed bounded diagnostic replay after the stated execution condition. This approves observational instrumentation, not any physics fix or trajectory acceptance.
