"""Exception-only tracing of original installed v3 depletion replay, no fallback."""
from __future__ import annotations
from collections.abc import Mapping
from dataclasses import fields
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import runpy
import sys
import time
import traceback
from types import FrameType
from typing import Any
import numpy as np
from sludge_sandbox._heos_kernel import HEOSCandidate, Snapshot
from sludge_sandbox.water_properties import WaterNumericalError
from sludge_sandbox.integration import ConservedState
from sludge_sandbox.deforming_solid_storage import TotalEnergyTarget

HERE = Path(__file__).resolve().parent
TARGET_CODE = HEOSCandidate.state_tp.__code__
LOCAL_NAMES = ('time_s', 't', 'p', 'temperature_k', 'pressure_pa', 'phase', 'rho', 'iteration',
    'slope', 'residual', 'step', 'ps', 'liquid_mol', 'gas_mol', 'solid_mol', 'n', 'nl', 'ng',
    'target', 'target_energy_j', 'target_energy_error_bound_j', 'temperature_bracket_k',
    'bracket', 'lo', 'hi', 'mid', 'state', 'stage', 'current', 'initial', 'at', 'tau', 'cap',
    'available', 'exact_available', 'amounts', 'energy_binding')
CALLER_MODULES = frozenset(('_heos_kernel.py', 'water_heos.py', 'rigid_water_gas.py',
    'rigid_storage.py', 'solid_fluid_storage.py', 'deforming_solid_storage.py',
    'deforming_solid_heat.py', 'water_phase_transfer.py', 'depletion_integration.py', 'integration.py'))


def detached(value: Any) -> Any:
    """Read existing plain values only; never call a provider or arbitrary repr."""
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float:
        return {'value': value if math.isfinite(value) else None, 'repr': repr(value), 'hex': value.hex()}
    if isinstance(value, np.generic):
        return detached(value.item())
    if isinstance(value, Fraction):
        return {'numerator': value.numerator, 'denominator': value.denominator}
    if isinstance(value, np.ndarray):
        return {'shape': list(value.shape), 'values': detached(value.tolist())}
    if isinstance(value, Mapping):
        return {str(key): detached(item) for key, item in value.items() if type(key) in (str, int)}
    if isinstance(value, (tuple, list)):
        return [detached(item) for item in value]
    if type(value) in (ConservedState, TotalEnergyTarget, Snapshot):
        return {'type': type(value).__name__, 'fields': {field.name: detached(getattr(value, field.name))
                for field in fields(value)}}
    return {'not_captured_type': type(value).__name__}


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(payload, indent=2, allow_nan=False)+'\n')
    temporary.replace(path)


def capture(frame: FrameType, error: BaseException) -> dict[str, Any]:
    current = frame.f_locals
    kernel = current['self']
    # These are data attributes and already-computed snapshot dataclasses;
    # do not use native flash methods, last_tp properties, or EOS for logging.
    result = {'schema': 'heos_tp_exception_observation_v1',
        'qualification': 'instrumented full original replay; numerical failure remains failure',
        'exception': {'type': type(error).__name__, 'message': str(error)},
        'arguments_and_loop_locals': {key: detached(current[key]) for key in LOCAL_NAMES if key in current},
        'tp_iterations': detached(kernel.__dict__.get('_tp_iterations')),
        'coexistence_iterations': detached(kernel.__dict__.get('_coexistence')),
        'kernel_identity': kernel.__dict__.get('identity'),
        'kernel_descriptor_json': kernel.__dict__.get('descriptor_json'),
        'saturation_liquid': detached(current.get('liquid')),
        'saturation_vapor': detached(current.get('vapor')),
        'stack': traceback.format_stack(frame), 'caller_frames': []}
    caller = frame.f_back
    for _ in range(64):
        if caller is None:
            break
        filename = Path(caller.f_code.co_filename)
        if filename.name in CALLER_MODULES and '/site-packages/sludge_sandbox/' in str(filename):
            values = caller.f_locals
            record = {'file': str(filename), 'function': caller.f_code.co_name,
                      'line': caller.f_lineno, 'locals': {key: detached(values[key])
                      for key in LOCAL_NAMES if key in values}}
            if filename.name == 'water_heos.py' and 'self' in values:
                wrapper_fields = values['self'].__dict__
                descriptor = wrapper_fields.get('implementation')
                if descriptor is not None:
                    # Stored descriptor fields; no computed hash or water calls.
                    record['wrapper_implementation_fields'] = detached(descriptor.__dict__)
                record['source_asset_sha256'] = detached(wrapper_fields.get('source_asset_sha256'))
            result['caller_frames'].append(record)
        caller = caller.f_back
    return result


def main() -> int:
    if sys.gettrace() is not None:
        raise SystemExit('fresh process without existing trace required')
    if any((HERE/name).exists() for name in ('diagnostic-summary.json', 'tp-failure-snapshot.json', 'depletion-result-0.json')):
        raise SystemExit('diagnostic outputs already exist; preserve them and use a new reviewed attempt directory')
    if '/site-packages/sludge_sandbox/' not in TARGET_CODE.co_filename:
        raise SystemExit('installed HEOS code required')
    started = time.monotonic()
    summary: dict[str, Any] = {'status': 'started', 'snapshot_saved': False, 'matching_exception_events': 0,
        'instrumentation': 'sys.settrace; only HEOSCandidate.state_tp gets a local hook; line/opcode events disabled',
        'no_added_EOS_calls': True, 'tracing_overhead': 'present, not separately subtracted',
        'target_code_file': TARGET_CODE.co_filename,
        'target_code_file_sha256': hashlib.sha256(Path(TARGET_CODE.co_filename).read_bytes()).hexdigest(),
        'logging_errors': []}
    atomic_json(HERE/'diagnostic-summary.json', summary)

    def local_trace(frame: FrameType, event: str, arg: Any) -> Any:
        if event == 'exception':
            _, error, _ = arg
            if isinstance(error, WaterNumericalError) and str(error) == 'heos_tp_not_converged':
                summary['matching_exception_events'] += 1
                if not summary['snapshot_saved']:
                    try:
                        atomic_json(HERE/'tp-failure-snapshot.json', capture(frame, error))
                        summary['snapshot_saved'] = True
                    except BaseException as logging_error:
                        # Preserve original numerical exception, including when
                        # diagnostic I/O is unavailable; never return a fake state.
                        summary['logging_errors'].append({'type': type(logging_error).__name__, 'message': str(logging_error)})
        return local_trace

    def global_trace(frame: FrameType, event: str, arg: Any) -> Any:
        if event == 'call' and frame.f_code is TARGET_CODE:
            frame.f_trace_lines = False
            frame.f_trace_opcodes = False
            return local_trace
        return None

    exit_code = 1
    original_argv = sys.argv[:]
    try:
        sys.argv = [str(HERE/'depletion.py'), '--refinement', '0']
        sys.settrace(global_trace)
        try:
            runpy.run_path(str(HERE/'depletion.py'), run_name='__main__')
            exit_code = 0
        except SystemExit as exc:
            exit_code = exc.code if type(exc.code) is int else (0 if exc.code is None else 1)
    except BaseException as exc:
        summary['entry_exception'] = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
        exit_code = 1
    finally:
        sys.settrace(None)
        sys.argv = original_argv
        summary.update(status='diagnostic_capture_observed' if summary['snapshot_saved'] else 'target_exception_not_captured',
                       original_entry_exit_code=exit_code, elapsed_s=time.monotonic()-started)
        try:
            atomic_json(HERE/'diagnostic-summary.json', summary)
        except BaseException as exc:
            print('Diagnostic summary write failed: '+type(exc).__name__, file=sys.stderr)
    # Capturing an expected failure does not turn the original run into success.
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
