# Independent review of frozen T/P exception-capture replay

Verdict: APPROVE for one serial bounded diagnostic execution after fullsuite11689 is authoritatively terminal and the root's freeze/installed identity checks are satisfied. No script import, execution, EOS, test, probe or source edit performed by this reviewer. All Python files were AST parsed only.

Independently checked the four script hashes against PLAN:

- fixture.py `b85f1d55460b65b64ff4ecade268b9b2f2168a87271c472b3065ddb682f0c531`
- depletion.py `141a90056e70c21318cc2b72615150a0d78827b77992e0b4444c93695d9891f4`
- diagnostic.py `d5f7e12c10fe59d4296e72ad3ed06216aff338101b081c589ef17154edba69c4`
- run_diagnostic.py `210a6921d76e29852ee9805e84161f524d409c373df16966eb15e2086e491b62`

Actual fixture.py, depletion.py and callback-result.json copies are byte-identical to their original v3 files and match copied_input_records. PLAN's original failed-result SHA also matches the preserved actual v3 result. Callback is not run: its result is used only by the unchanged depletion script's initial-state check. No provider constructor/EOS is called by preload of the Python class code object itself.

The trace filter uses object identity with the loaded installed HEOSCandidate.state_tp.__code__, not a filename or method-name approximation. It gives a local hook only to that function, disables line/opcode events and captures only its exact heos_tp_not_converged WaterNumericalError. Original state_tp, its transaction, source/configuration guards, saturation solve and TP loop execute unchanged. There is no source/manifest/class-method patch and no backend fallback. Trace overhead is explicitly retained in wall time.

At the exception event, the actual frame still contains T/P/phase and loop locals. Capture copies existing _tp_iterations/_coexistence lists and already computed Snapshot objects directly, without calling native flash accessors, diagnostic properties or another EOS method. Float repr and hex are preserved; caller frames are limited to installed model modules and whitelisted locals, including actual ConservedState/TotalEnergyTarget values. This supplies the host-stage context and actual liquid pressure trial rather than guessing the failed T/P from the last accepted state.

Interpretation note: on eight-iteration exhaustion, frame local rho may already be the final Newton *updated* density, while the last _tp_iterations entry is the last actually evaluated density. Both are captured, so the eventual diagnosis must distinguish the unobserved next iterate from native EOS evidence. The script does not mislabel either field as a measured EOS state.

The capture is written atomically at the original exception and logging errors are recorded without replacing it. The original integration result and nonzero entry exit remain intact. sys.settrace and argv are restored in finally. Existing trace state or existing diagnostic outputs cause early rejection, protecting evidence. The target-file installed path/hash is recorded and unchanged fixture installed-before/after checks remain present; source/input hashes are also supervisor-recorded.

The supervisor uses the original interpreter, original test-helper PYTHONPATH, no source-PYTHONPATH override, the same 150 s external limit and the unchanged fixture's 120 s / 500-panel internal limits. It requires supervisor complete status AND child exit zero; an expected captured numerical failure is therefore still a failed child/attempt with separate diagnostic evidence. One attempt directory name cannot escape to a parent. Cleanup and input-change checks remain delegated to the same reviewed supervisor.

No new defect found in this bounded capture design. A successful snapshot is new diagnostic evidence only; it is not model convergence or a repaired trajectory. Root must inspect actual failure snapshot/result/summary and supervisor terminal cleanup before any next exact-state reproducer or numerical change.
