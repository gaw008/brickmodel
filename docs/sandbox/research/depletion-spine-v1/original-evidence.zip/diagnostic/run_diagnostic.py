"""Supervisor for one reviewed full v3 diagnostic replay; 150-second hard cap."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
HERE = Path(__file__).resolve().parent
PYTHON = Path('/private/tmp/brick-water-backend-probe/venv/bin/python')
PACKAGE = PYTHON.parent.parent/'lib/python3.12/site-packages/sludge_sandbox'


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('attempt')
    args = parser.parse_args()
    if Path(args.attempt).name != args.attempt or args.attempt in ('.', '..'):
        parser.error('attempt must be a new single directory name')
    supervisor = ROOT/'docs/sandbox/research/research-process-supervisor'
    sys.path.insert(0, str(supervisor))
    from supervisor import run_attempt
    paths = (list(PACKAGE.glob('*.py'))+list((ROOT/'src/sludge_sandbox').glob('*.py'))
        +list((ROOT/'tests/sandbox').glob('*.py'))+list((ROOT/'data/sandbox/water').rglob('*'))
        +list(HERE.glob('*.py'))+[HERE/'PLAN.json', HERE/'V3_TP_DIAGNOSTIC_PLAN.md',
          HERE/'copied-inputs.json', HERE/'callback-result.json', supervisor/'supervisor.py'])
    command = ['/usr/bin/env', f'PYTHONPATH={ROOT}/tests/sandbox', 'PYTHONDONTWRITEBYTECODE=1',
               str(PYTHON), str(HERE/'diagnostic.py')]
    result = run_attempt(HERE/args.attempt, command, cwd='/private/tmp',
                         input_paths=[path for path in paths if path.is_file()], timeout_s=150)
    print(json.dumps({key: result[key] for key in ('status', 'returncode', 'elapsed_s', 'cleanup')}, indent=2))
    return 0 if result['status'] == 'complete' and result['returncode'] == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
