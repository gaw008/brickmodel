import importlib.util
import sys
import pytest
import sludge_sandbox
name = 'sludge_sandbox.depletion_integration'
spec = importlib.util.spec_from_file_location(name, '/private/tmp/brick-depletion-spine-v1/candidate_depletion_integration.py')
module = importlib.util.module_from_spec(spec)
sys.modules[name] = module
spec.loader.exec_module(module)
setattr(sludge_sandbox, 'depletion_integration', module)
raise SystemExit(pytest.main(sys.argv[1:]))
