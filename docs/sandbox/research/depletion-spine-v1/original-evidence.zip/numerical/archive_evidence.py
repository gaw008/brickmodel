"""Archive bounded experiment bytes and readable XML copies after terminal runs."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/depletion-spine-v1')
source = Path('/private/tmp/brick-depletion-spine-v1')
wet = Path('/private/tmp/brick-reacting-wet-v3')
root.mkdir(parents=True, exist_ok=True)
entries = []
archive = root/'original-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for prefix, folder in [('numerical', source), ('wet-v3', wet), ('diagnostic', Path('/private/tmp/brick-reacting-wet-v3-diagnostic')), ('exact-point', Path('/private/tmp/brick-heos-tp-exact-v1'))]:
        for p in sorted(folder.rglob('*')):
            if not p.is_file() or '__pycache__' in p.parts or '.pytest_cache' in p.parts:
                continue
            name = prefix+'/'+p.relative_to(folder).as_posix()
            data = p.read_bytes()
            z.writestr(name, data)
            entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    for row in entries:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
for p in sorted(source.iterdir()):
    if p.suffix == '.md' or p.name.startswith('installed-') and p.suffix == '.json':
        shutil.copy2(p, root/p.name)
    elif p.suffix == '.xml':
        (root/p.name).write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines())+'\n')
(root/'manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'entries':entries,'readable_xml_transformation':'Strip trailing whitespace on each line and add one final newline; raw original bytes in ZIP.'},indent=2)+'\n')
print(f'{len(entries)} archived entries reread and verified')
