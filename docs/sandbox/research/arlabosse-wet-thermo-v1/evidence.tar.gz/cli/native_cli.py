"""One bounded acceptance of the installed public entry point."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
SCRATCH = Path('/private/tmp/arlabosse-wet-thermo-v1')
PYTHON = Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python')
OUTPUT = SCRATCH / 'cli/native01'
OUTPUT.mkdir(exist_ok=False)


def save(name, value):
    with (OUTPUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def identities():
    paths = [SCRATCH / 'native01/ACCEPTANCE.json',
             SCRATCH / 'native01/MODEL_DEFINITION.json',
             Path(__file__), SCRATCH / 'cli/NATIVE_CLI_PLAN.md']
    for directory in (ROOT / 'src/sludge_sandbox',
                      PYTHON.parent.parent / 'lib/python3.12/site-packages/sludge_sandbox'):
        paths.extend(p for p in directory.rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts and p.suffix != '.pyc')
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


before = identities()
save('INPUTS_BEFORE.json', before)
native = json.loads((SCRATCH / 'native01/ACCEPTANCE.json').read_bytes())
definition = json.loads((SCRATCH / 'native01/MODEL_DEFINITION.json').read_bytes())
point = next(r['state'] for r in native['derivatives']
             if r['temperature_k'] == 353.15)
target = native['stages'][-1]['target_enthalpy_j']
base = [str(PYTHON), '-I', '-m', 'sludge_sandbox', 'arlabosse-wet',
        '--assets-root', str(ROOT), '--water-data', str(ROOT / 'data/sandbox/water')]
cases = [
    ('point', ['--temperature-k', '353.15', '--moisture', '.55', '--trace']),
    ('inverse', ['--enthalpy-j', str(target), '--dry-mass-kg', '.1',
                 '--moisture', '.25', '--trace']),
    ('invalid', ['--temperature-k', '353.15', '--moisture', '.1']),
]
env = dict(os.environ)
env.pop('PYTHONPATH', None)
summary = []
try:
    for name, args in cases:
        start = time.monotonic()
        argv = base + args
        save(name + '-request.json', {'argv': argv, 'timeout_s': 15.0})
        try:
            run = subprocess.run(argv, cwd='/private/tmp', env=env,
                                 capture_output=True, timeout=15, check=False)
        except subprocess.TimeoutExpired as exc:
            (OUTPUT / (name + '-stdout.json')).write_bytes(exc.stdout or b'')
            (OUTPUT / (name + '-stderr.log')).write_bytes(exc.stderr or b'')
            raise
        (OUTPUT / (name + '-stdout.json')).write_bytes(run.stdout)
        (OUTPUT / (name + '-stderr.log')).write_bytes(run.stderr)
        row = {'case': name, 'returncode': run.returncode,
               'elapsed_s': time.monotonic() - start}
        summary.append(row)
        save(name + '-process.json', row)
        value = json.loads(run.stdout)
        if name == 'invalid':
            assert run.returncode != 0 and value['status'] == 'failed'
            assert value.get('reason') and 'result' not in value
            assert value['error_type'] == 'WetThermodynamicError'
            assert value['reason'] == 'outside_declared_domain_moisture'
            assert value['code'] is None
            continue
        assert run.returncode == 0
        assert value['trace'] == definition
        if name == 'point':
            assert value['result'] == point
        else:
            result = value['result']
            assert abs(result['state']['temperature_k'] - 323.15) <= 1e-6
            assert abs(result['residual_j']) <= result['residual_tolerance_j']
            assert result['target_enthalpy_j'] == target
            for key in ('material_qualified', 'training_eligible', 'full_firing_cycle'):
                assert result['state'][key] is False
    after = identities()
    save('INPUTS_AFTER.json', after)
    assert before == after
    save('ACCEPTANCE.json', {'status': 'passed', 'cases': summary,
                             'inputs_unchanged': True, 'input_count': len(before),
                             'material_qualified': False, 'full_firing_cycle': False})
except BaseException as exc:
    save('FAILURE.json', {'type': type(exc).__name__, 'message': str(exc),
                          'completed_processes': summary})
    raise
