# Installed CLI acceptance, registered after Python native01

Scope: one point query and one enthalpy inverse through the actual installed
`python -I -m sludge_sandbox` entry point; an invalid out-of-domain query must
return an explicit error. These are new property evaluations, not a repeated
three-stage trajectory or independent experimental validation.

Use the frozen package and same assets as native01, from /private/tmp with
PYTHONPATH removed. Each child has a 15 s wall limit. Save argv, exit code,
elapsed time, raw stdout/stderr before inspecting the result. No retry.

1. Point: T=353.15 K, W=.55, --trace. Its entire result must equal the saved
native01 derivative-state row for the same inputs (same implementation/runtime,
so exact JSON equality is appropriate). Trace must equal the saved definition.
2. Inverse: native01's cooling target total H, md=.1 kg, W=.25, --trace.
Use the public default numerical policy. Returned T must be within the existing
native01 1e-6 K comparison of 323.15 K, residual within its reported numerical
tolerance, and material/training/full-cycle flags false. Trace must equal the
same saved definition. This checks CLI routing, not a new material tolerance.
3. Point W=.1, T=353.15 K outside the declared W domain: nonzero exit, JSON
status failed and error text. No valid material result permitted.

Hash the original native result and model definition, source package and
installed package files before/after. All must remain unchanged. Preserve
partial evidence and failure if any assertion or timeout occurs.
