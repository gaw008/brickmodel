"""One controlled thermodynamic path, with an independent source-data heat oracle."""
from fractions import Fraction as F
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path
import time

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
SCRATCH = Path('/private/tmp/arlabosse-wet-thermo-v1')
WATER = ROOT/'data/sandbox/water'
T0 = 368.15
MD = .1


def integral(nodes, start, end):
    """Exact rational integral of the original nominal linear q interpolant."""
    a, b = F(str(start)), F(str(end))
    if b < a:
        return -integral(nodes, end, start)
    assert nodes[0][0] <= a <= b <= nodes[-1][0]
    total = F(0)
    for (x, y), (xx, yy) in zip(nodes, nodes[1:]):
        lo, hi = max(a, x), min(b, xx)
        if lo < hi:
            slope = (yy-y)/(xx-x)
            total += y*(hi-lo)+slope*((hi-x)**2-(lo-x)**2)/2
    return total


def interpolate(nodes, moisture):
    w = F(str(moisture))
    for (x, y), (xx, yy) in zip(nodes, nodes[1:]):
        if x <= w <= xx:
            return y+(yy-y)*(w-x)/(xx-x)
    raise ValueError('oracle_moisture_outside_source_hull')


def main():
    from sludge_sandbox.arlabosse_wet_thermo import ArlabosseWetThermodynamics
    from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
    from sludge_sandbox.run_service import runtime_identity

    output = SCRATCH/'native01'
    output.mkdir(exist_ok=False)
    begin = time.monotonic()
    result = {'status': 'in_progress', 'stages': [], 'calibration': [], 'derivatives': [],
              'oracle_water': []}

    def check(ok, name):
        if time.monotonic()-begin > 60:
            raise RuntimeError('original_internal_60_second_deadline_exceeded')
        if not ok:
            raise AssertionError(name)

    def save(name, value):
        with (output/name).open('x', encoding='utf-8') as stream:
            json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
            stream.write('\n')

    try:
        runtime_before = runtime_identity()
        save('RUNTIME_BEFORE.json', runtime_before)
        raw = (ROOT/'data/sandbox/research/arlabosse95/facts.json').read_bytes()
        check(hashlib.sha256(raw).hexdigest() == '543d55918db7df6d0cc0f695c5dceadbdebda82b83f4fdde206266bcd12f2f16', 'original_source_facts')
        facts = json.loads(raw)
        heat, activity = [], []
        for row in facts['observations']:
            if row['value'] is None:
                continue
            w = F(row['requested_moisture_kg_water_per_kg_dry_matter'])
            value = row['value']
            point = (w, F(int(value['numerator']), int(value['denominator'])))
            (heat if row['figure'] == 2 else activity).append(point)
        model = ArlabosseWetThermodynamics(ROOT, WATER)
        oracle_water = WaterChemicalPotential(WATER)
        mass = oracle_water.reference.molar_mass_kg_mol

        @lru_cache(maxsize=128)
        def water(t):
            pair = oracle_water.equilibrium_at_liquid_tp(t, 100000.)
            values = (pair.liquid.enthalpy_j_mol/mass,
                      pair.vapor.enthalpy_j_mol/mass,
                      pair.liquid.chemical_potential_j_mol/mass)
            result['oracle_water'].append({'temperature_k': t, 'liquid_pressure_pa': 100000.,
                'liquid_enthalpy_j_kg_water': values[0], 'vapor_enthalpy_j_kg_water': values[1],
                'liquid_chemical_potential_j_kg_water': values[2],
                'molar_mass_kg_mol': mass, 'source_ids': list(pair.source_ids),
                'pure_model_equilibrium_vapor_pressure_pa': pair.equilibrium_partial_pressure_pa})
            return values

        def dry_delta(a, b):
            a, b = F(str(a))-F('273.15'), F(str(b))-F('273.15')
            return 1434*(b-a)+F('3.29')*(b*b-a*a)/2

        def sensible(a, b, w):
            return float(F(str(MD))*(dry_delta(a, b)+F(str(w))*(F(water(b)[0])-F(water(a)[0]))))

        save('MODEL_DEFINITION.json', model.definition())

        def qualification(point):
            check(all(getattr(point, key) is False for key in
                      ('material_qualified', 'training_eligible', 'full_firing_cycle')),
                  'original_qualification_flags')
            check(all(getattr(point, key) is None for key in
                      ('interpolation_model_error', 'temperature_extension_model_error',
                       'water_reference_model_error', 'experimental_uncertainty')),
                  'unknown_model_and_experimental_errors')

        check(len(heat) == 6, 'six_original_heat_nodes')
        for w, aw in activity:
            if w < F('.15'):
                continue
            q = dict(heat).get(w)
            row = {'moisture': str(w), 'source_heat_is_unknown': q is None,
                   'source_activity': str(aw), 'source_heat': None if q is None else str(q),
                   'state': None}
            result['calibration'].append(row)
            p = model.evaluate(T0, float(w))
            row['state'] = p.to_record()
            row['activity_residual'] = p.activity-float(aw)
            row['heat_residual_j_kg_water'] = None if q is None else p.total_desorption_heat_j_kg_water-float(q)
            qualification(p)
            check(abs(row['activity_residual']) <= 1e-12, 'source_activity_reproduction')
            if q is not None:
                check(abs(row['heat_residual_j_kg_water']) <= 1e-6, 'source_heat_reproduction')

        initial = model.evaluate(333.15, .75)
        result['initial'] = initial.to_record()
        qualification(initial)
        initial_identity = math.fsum((initial.specific_enthalpy_j_kg_dry,
            -initial.specific_gibbs_j_kg_dry, -initial.temperature_k*initial.specific_entropy_j_kg_dry_k))
        result['initial_H_minus_G_TS_j_kg_dry'] = initial_identity
        check(abs(initial_identity) <= 1e-5, 'initial_H_G_TS')
        current_h = MD*initial.specific_enthalpy_j_kg_dry
        initial_h = current_h
        total_q = total_out = 0.
        q_dry = float(F(str(MD))*integral(heat, .25, .75))
        out_dry = MD*(.75-.25)*water(T0)[1]
        controls = [('heat', T0, .75, sensible(333.15, T0, .75), 0.),
                    ('dry_at95C', T0, .25, q_dry, out_dry),
                    ('cool', 323.15, .25, sensible(T0, 323.15, .25), 0.)]
        for name, expected_t, moisture, q, outgoing in controls:
            target = math.fsum((current_h, q, -outgoing))
            row = {'name': name, 'control_temperature_k': expected_t, 'moisture': moisture,
                   'starting_total_enthalpy_j': current_h, 'supply_heat_j': q,
                   'signed_outgoing_vapor_enthalpy_j': outgoing,
                   'target_enthalpy_j': target, 'inverse': None}
            result['stages'].append(row)
            solved = model.inverse_enthalpy(target, dry_mass_kg=MD, moisture=moisture,
                                            temperature_tolerance_k=1e-9, maximum_iterations=64)
            row['inverse'] = solved.to_record()
            state = solved.state
            qualification(state)
            recovered_h = MD*state.specific_enthalpy_j_kg_dry
            residual = math.fsum((recovered_h, -current_h, -q, outgoing))
            row.update(recovered_total_enthalpy_j=recovered_h, open_energy_residual_j=residual,
                       temperature_residual_k=state.temperature_k-expected_t)
            check(abs(state.temperature_k-expected_t) <= 1e-6, name+'_temperature')
            check(abs(residual) <= 1e-5 and abs(solved.residual_j) <= 1e-5, name+'_open_energy')
            identity = math.fsum((state.specific_enthalpy_j_kg_dry, -state.specific_gibbs_j_kg_dry,
                                  -state.temperature_k*state.specific_entropy_j_kg_dry_k))
            row['H_minus_G_TS_j_kg_dry'] = identity
            check(abs(identity) <= 1e-5, name+'_H_G_TS')
            current_h = target
            total_q = math.fsum((total_q, q))
            total_out = math.fsum((total_out, outgoing))
            print(json.dumps({'phase': name, 'temperature_k': state.temperature_k,
                'residual_j': residual, 'elapsed_seconds': time.monotonic()-begin}), flush=True)

        drying = model.isothermal_drying_heat(T0, .75, .25, dry_mass_kg=MD)
        result.update(drying=drying.to_record(), independent_source_q_heat_j=q_dry,
                      independent_signed_outgoing_enthalpy_j=out_dry)
        qualification(drying)
        check(abs(drying.heat_j-q_dry) <= 1e-5, 'independent_q_integral')
        check(abs(drying.vapor_carried_enthalpy_j-out_dry) <= 1e-5, 'signed_vapor_enthalpy')
        doubled = q_dry+MD*(.75-.25)*(water(T0)[1]-water(T0)[0])
        result.update(double_latent_control_heat_j=doubled,
                      double_latent_energy_residual_j=doubled-drying.material_enthalpy_change_j-drying.vapor_carried_enthalpy_j)
        check(abs(doubled-drying.material_enthalpy_change_j-drying.vapor_carried_enthalpy_j) > 1e-5,
              'double_latent_negative_control_must_fail')
        full_residual = math.fsum((recovered_h, -initial_h, -total_q, total_out))
        result.update(whole_path_energy_residual_j=full_residual, total_supply_heat_j=total_q,
                      total_signed_outgoing_enthalpy_j=total_out)
        check(abs(full_residual) <= 1e-5, 'whole_path_open_energy')

        for t, w in ((333.15, .35), (353.15, .55), (363.15, .75)):
            row = {'temperature_k': t, 'moisture': w,
                   'cp_delta_temperature_k': .01, 'mu_delta_temperature_k': .1}
            result['derivatives'].append(row)
            p = model.evaluate(t, w)
            row['state'] = p.to_record()
            qualification(p)
            hp = model.evaluate(t+.01, w).specific_enthalpy_j_kg_dry
            row['h_plus_j_kg_dry'] = hp
            hm = model.evaluate(t-.01, w).specific_enthalpy_j_kg_dry
            row['h_minus_j_kg_dry'] = hm
            cp_error = (hp-hm)/.02-p.heat_capacity_j_kg_dry_k
            row.update(cp_finite_difference_j_kg_dry_k=(hp-hm)/.02,
                       cp_difference_j_kg_dry_k=cp_error)
            check(abs(cp_error) <= 1e-4, 'independent_cp_derivative')
            mu = p.water_chemical_potential_j_kg_water-water(t)[2]
            row['mu_ex_j_kg_water'] = mu
            mup = model.evaluate(t+.1, w).water_chemical_potential_j_kg_water-water(t+.1)[2]
            row['mu_ex_plus_j_kg_water'] = mup
            mum = model.evaluate(t-.1, w).water_chemical_potential_j_kg_water-water(t-.1)[2]
            row['mu_ex_minus_j_kg_water'] = mum
            b0 = math.fsum((water(T0)[1], -water(T0)[0], -float(interpolate(heat, w))))
            mu_error = math.fsum((mu, -t*(mup-mum)/.2, -b0))
            row.update(oracle_b0_j_kg_water=b0,
                       mu_ex_temperature_derivative_j_kg_water_k=(mup-mum)/.2,
                       excess_identity_difference_j_kg_water=mu_error)
            check(abs(mu_error) <= 1e-4, 'independent_excess_gibbs_helmholtz')
        result.update(status='completed', elapsed_seconds=time.monotonic()-begin,
            whole_path_energy_residual_j=full_residual, drying=drying.to_record(),
            independent_source_q_heat_j=q_dry, double_latent_control_heat_j=doubled,
            initial=initial.to_record(), material_qualified=False, training_eligible=False,
            full_firing_cycle=False, physical_time_axis=False,
            reality_validation='construction_data_reproduction_not_holdout_prediction')
        check(result['elapsed_seconds'] < 60, 'original_60_second_limit')
        runtime_after = runtime_identity()
        save('RUNTIME_AFTER.json', runtime_after)
        check(runtime_after == runtime_before, 'runtime_identity_unchanged')
        save('ACCEPTANCE.json', result)
    except BaseException as exc:
        result.update(status='failed', exception_type=type(exc).__name__, reason=str(exc),
                      elapsed_seconds=time.monotonic()-begin)
        save('FAILURE.json', result)
        raise


if __name__ == '__main__':
    main()
