"""Bounded installed wet thermodynamics demonstration, one numbered attempt."""
import importlib.util
import json
from pathlib import Path
import sys

root = Path('/Users/wanggaoying/Desktop/brickmodel-github')
scratch = Path('/private/tmp/arlabosse-wet-thermo-v1')
python = Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python')
installed = python.parent.parent/'lib/python3.12/site-packages/sludge_sandbox'
supervisor = root/'docs/sandbox/research/research-process-supervisor/supervisor.py'
spec = importlib.util.spec_from_file_location('wet_thermodynamics_research_supervisor', supervisor)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
execution = Path(__file__).parent
inputs = {Path(__file__).resolve(), supervisor, execution/'native_driver.py',
          execution/'NATIVE_PLAN.md', scratch/'install/SOURCE_FREEZE.json'}
model = root/'data/sandbox/research/arlabosse-wet-thermo-v1/model.json'
inputs.add(model)
definition = json.loads(model.read_bytes())
for asset in definition['assets']:
    inputs.add(root/asset['path'])
for source in definition['upstream']:
    path = root/source['path']
    inputs.add(path)
    for asset in json.loads(path.read_bytes())['assets']:
        inputs.add(root/asset['path'])
for name in ('IAPWS95-2018.pdf', 'iapws-1.5.5-py3-none-any.whl', 'iapws-1.5.5-iapws95.py',
             'iapws-1.5.5-LICENSE', 'source_facts.json'):
    inputs.add(root/'data/sandbox/water'/name)
for directory in (root/'src/sludge_sandbox', installed, installed.parent/'iapws'):
    inputs.update(p for p in directory.rglob('*')
                  if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
result = module.run_attempt(scratch/'supervised-native01',
    ['/usr/bin/env', '-u', 'PYTHONPATH', str(python), '-I', str(execution/'native_driver.py')],
    cwd='/private/tmp', input_paths=sorted(inputs), timeout_s=80., cleanup_grace_s=5.)
print(json.dumps({k: v for k, v in result.items() if not k.startswith('inputs_')}, indent=2))
sys.exit(0 if result['status'] == 'complete' and result['returncode'] == 0 else 1)
