# Final bounded CLI harness review

**APPROVE** for native_cli.py SHA256 `36168acf0389920ce1b5252190812ace98c048c61cffef55fde3dda3cadf189e` and NATIVE_CLI_PLAN.md SHA256 `24538e487ee16c1f6d115fd1b16319e5188ecc3f43b1263bdc693a956fdc6166`.

The invalid case now matches the existing CLI error schema exactly: nonzero exit, status failed, reason outside_declared_domain_moisture, error_type WetThermodynamicError, code null, and no result. Both intermediate harness-field mistakes are closed without changing production or executing CLI property work.

The saved native point is T = 353.15 K, W = .55; its full JSON and model definition are valid same-package/runtime comparison references. The inverse uses native cooling target -394874.7645178071 J, md = .1 kg, W = .25, the public default inversion policy and the original 1e-6 K comparison to 323.15 K; it checks reported residual tolerance and retains all qualification flags false. This is CLI routing and repeatability, not independent reality validation.

The script uses fixed isolated module argv without shell interpolation, removes PYTHONPATH, applies a 15-second timeout to each of the three calls, stores original stdout/stderr before parsing, retains failure evidence, disallows output-directory reuse and has no retry. A timeout's partial stdout/stderr and exception are retained; completed-process rows are labelled as such. Original native result/definition and source/installed package hashes are compared before/after.

AST parsing passed. This was a bounded read-only review of code, plan and already saved native JSON. No real CLI subprocess, EOS call, native integration, installation, Git mutation or production edit was performed. FINAL_IDENTITY.json gives every reviewed digest; old review notes remain preserved.
