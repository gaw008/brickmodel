# Bounded installed-CLI harness review

Disposition: temporary BLOCK before execution.

[HIGH] Invalid-input acceptance asserts a nonexistent CLI error field
File: /private/tmp/arlabosse-wet-thermo-v1/cli/native_cli.py:78
Issue: The invalid branch requires `value.get('error')`; the actual CLI exception response has status, error_type, code and reason. A correct domain rejection therefore fails the harness after the preceding real property calls.
Fix: require the explicit moisture-domain reason (outside_declared_domain_moisture), the expected WetThermodynamicError type and absence of result, preserving nonzero-exit/status checks. This changes the harness to the existing API; do not change production error schema.

The selected native derivative row is exactly T=353.15 K/W=.55. The final cooling target is -394874.7645178071 J at dry mass .1 kg/W=.25 and reference T=323.15 K. Point exact-JSON comparison is appropriate for frozen same-runtime implementation; inverse comparison intentionally uses public default policy and the existing 1e-6 K gate rather than pretending to reproduce the prior stricter iteration policy. Original trace and raw output are retained; no retry or reality-validation claim is present. subprocess argv is a list, PYTHONPATH is removed and isolated module invocation is fixed.

Static reading and AST parsing only. No CLI subprocess, EOS, integration or production modification performed. INPUT_HASHES.json records reviewed original bytes. This temporary finding is a test-harness mismatch, not a wet-thermodynamics defect.
