# Error-schema follow-up

The initial nonexistent `error` assertion was removed, but the intermediate script now compares `value["code"]` to outside_declared_domain_moisture. WetThermodynamicError does not define a code attribute, so the unchanged CLI emits code:null and places the text in reason. Compare reason to the exact string; optionally assert code is None. Keep error_type WetThermodynamicError and the no-result check. No real CLI process was launched.

The original report's source line reference should be line72 (the invalid assertion), not line78; its substantive finding is unchanged.
