# Independent Python / conditional thermodynamics review

**APPROVE** for the exact inputs listed in FINAL_IDENTITY.json. No unresolved CRITICAL or HIGH issue found in the scoped implementation. Production source SHA256: `31e6dd7354ac704a8685fcf7e51f1c93a0a71960292ef84a93f96a5164217694`.

Scope: arlabosse_wet_thermo.py and its tests relative to baseline da59890; root CLI routing was also checked. The supplied thermodynamic design review and model.json were read. No production edits, real water backend construction, EOS evaluation, native trajectory, installation or Git mutation were performed.

## Mathematical and interface conclusions

- Dry-basis H/G/S and water-partial kg/mol conversions are consistent. The same water molar mass scales chemical potential; `G=H-TS`, `dH/dT=Cp`, `dG/dW=mu_water`, and partial-water enthalpy uses the excess `b0` once.
- ln(activity) and q use their distinct source-node sets. Analytic piecewise integration splits at the appropriate q knots; missing source q at W=.5/.6 stays null while interpolated model q is labelled separately. The reference moisture sets integration constants only.
- `q=L-b0` contains vaporization. The isothermal external heat, material enthalpy change and exiting-vapor enthalpy use one common reference. Negative vapor carried enthalpy from the shared formation reference is retained rather than forced positive.
- At T<=T0 the signs in activity readout bounds correctly select lower ln(aw) with upper q and vice versa. Heat bounds integrate the corresponding q bounds with positive removed-water orientation. These are binary64 propagation of source reading boxes, explicitly not total uncertainty or statistical confidence intervals; interpolation, temperature extension and water-reference model errors remain unknown.
- Inversion is conditioned on explicit positive dry mass and known W. Domain checks, iteration exhaustion, monotonic endpoint ordering, safeguarded proposals and diagnostic labels are present. The 8-ULP outside-endpoint allowance is explicitly reported and bounded; it is a numerical acceptance policy, not a proved physical error bound. Exact binary64 zero residual/endpoint labels must likewise not be interpreted as certified real-valued temperature error enclosures.
- Every public operation rechecks pinned source metadata/assets and water reference identity. Returned records are caller-owned copies: mutating one source-reading result or a trace does not affect later outputs. This is isolation, not a claim that nested dictionaries are deeply immutable.
- CLI makes evaluation and enthalpy inversion mutually exclusive and refuses missing or irrelevant dry-mass controls before model construction.

## Actual verification

`FINAL_TESTS.log/xml`: **69 passed in 0.22 seconds** (XML time .210), zero failures/errors/skips: 56 implementation manufactured tests, 4 CLI routing tests and 9 independent mathematical tests. All six reviewed source/test/definition/design files have identical hashes before and after the test run.

The independent tests use no production property backend. They check:

1. A nonuniform q curve integral against an exact Fraction quadratic antiderivative.
2. Four temperature/moisture readout-box extrema against independent 70-digit Decimal logarithm/exponential calculations.
3. Isothermal path subdivision, water mass basis and first-law closure.
4. Three-segment heat-driven H-to-T inversions using analytic external heat and vapor removal, without resetting energy reference.
5. Mutation isolation for returned source readings and continued null source q.
6. Provider exceptions propagating without a fabricated state.

`STATIC_CHECKS.json` records AST parsing and hash verification of the two upstream metadata files and the privately retained wet-Cp equation image referenced by model.json. The current model JSON matches its pinned code hash. This byte check is not a new reading of the literature image or an independent validation of its scientific interpretation. `git diff --check` passed. ruff/mypy/black/pylint are unavailable in the existing runtime; no successful lint/type check is claimed.

This approval covers the conditional fixed-pressure research implementation and manufactured mathematical checks. Actual-source EOS execution remains for the separately frozen root protocol. No wet-material experimental accuracy, drying-time prediction, pressure/volume dynamics, reaction model or full firing-cycle qualification is granted.
