# Arlabosse wet thermodynamics: finite CLI, provenance and native-plan review

Verdict: **APPROVE within the assigned static review scope**. No unresolved actionable finding. Baseline: `da5989092dd0726407e4f54294d094f75f69d1d4`.

The review covers the 25-line `arlabosse-wet` CLI addition, its four manufactured routing cases, the new model's public source/record boundary, and the preregistered native driver plus existing-supervisor wrapper. The mathematical derivation and detailed numerical/Python edge cases belong to the separate model review. I did not modify production, import or construct the wet model, evaluate EOS, launch a native process, rerun historical research, or rerun the old test suite.

## Findings resolved before final snapshot

1. The original driver checked `H-G-TS` at the three inverse endpoints but omitted the initial path endpoint promised by the plan. The final driver records and checks the initial state at the same `1e-5 J/kg dry` threshold.
2. The original driver checked calibration, stage and derivative thresholds before appending the corresponding record; failed points could lose their actual values. Successful derivative records also omitted the components needed to recompute their residuals. The final driver first appends an observation shell and saves returned/computed values before checking them. It retains each stage's starting total H, Q, signed Hout and target even if inversion fails; calibration source rationals and state; derivative state, H+/H−, Cp, excess potentials, b0, temperature increments and slopes; separate oracle-water h/g/reference/source values; and negative-control/full-path quantities. The original thresholds are unchanged.

## Evidence and accepted boundaries

- CLI uses mutually exclusive temperature versus **total enthalpy in J**. The inverse requires explicit **dry mass in kg** and known W in kg water/kg dry matter; temperature mode rejects a dry-mass argument before model construction. Both routes call the same model and preserve its conditional qualification. The routing tests use a manufactured model and do not constitute physical validation.
- Public operations recheck the pinned model, original dry and desorption sources, water source hashes/runtime identity, molar mass and gas constant. The source-boundary inspection found no public arbitrary-provider hook or silent replacement of missing original q readings.
- Read-only byte checks passed for the new metadata, all 16 declared direct/upstream asset entries, and the original desorption facts SHA. The supported source set has eight activity nodes and six readable heat nodes. Original q observations at W=.1/.5/.6 remain null; supported W=.5/.6 model outputs remain explicitly interpolation, with unknown model/experimental errors and material/training/full-cycle flags false.
- The native oracle integrates original rational q nodes with `Fraction`, uses the original dry-Cp polynomial and a separate water object under the same fixed 100000 Pa/reference convention. Each of the three stages forms `Hnext=Hprevious+Q-Hout` and calls the real inverse; its expected temperature is an assertion, not a substitute output. Signed shared-reference outgoing vapor enthalpy is retained. No second latent-heat term enters the real balance; the separately recorded double-latent control must fail the unchanged balance threshold.
- The final harness covers the registered calibration, all four endpoint identities, three derivative locations, per-stage/full-path energy, source-q integral and negative control. Its numerical thresholds, requested inverse tolerance/iteration count and 60 s internal / 80 s outer / 5 s cleanup-grace limits match the original plan. Centered stencils stay inside the declared domain.
- The wrapper selects the fixed installed interpreter, uses `-I` with `PYTHONPATH` unset outside the repository, and registers source/installed Python files, original upstream assets, the protocol/driver/supervisor, metadata and freeze record for before/after hashes. The existing supervisor converts otherwise successful execution to failure if declared inputs change and preserves timeout/cleanup status. Exclusive numbered attempt/output creation prevents overwrite. At this snapshot neither `native01` nor `supervised-native01` existed.

All five reviewed Python files compiled to code objects without execution; no new test/native success is claimed here. The original equation image was hash checked but not independently visually re-read by this reviewer. Installation/freeze and actual native numerical acceptance remain separate gates; this review does not establish measured wet-material validity or a complete firing cycle.

## Exact snapshot

See [FINAL_REVIEW.json](FINAL_REVIEW.json) for full paths, sizes, upstream asset hashes and read-only checks.

| File | SHA-256 |
|---|---|
| `src/sludge_sandbox/cli.py` | `41e305b7cc61e7a10407395e3580f675ca778e98d3fdf3e78cf2526d7f3da558` |
| `src/sludge_sandbox/arlabosse_wet_thermo.py` | `31e6dd7354ac704a8685fcf7e51f1c93a0a71960292ef84a93f96a5164217694` |
| `tests/sandbox/test_arlabosse_wet_cli.py` | `c272e264ba4945c63471dac346283c266199e4f832122ffa00d399ee9b02d02b` |
| `model.json` | `bfc82cb377158d83e0b7eb25289f34db467611f5de137fdfc24c76a1d162edaa` |
| `NATIVE_PLAN.md` | `25e726b4c17fa2291aeb5b251e45eaed8d6fbe0d1bd7bd70e0dfd1172ba54330` |
| `native_driver.py` | `561b844b0b155f3d49d2af327da70e6085e4e6423e87fa3440d8dd9ebdd3ec21` |
| `run_supervised_native01.py` | `9b649917430511cd6be0a61a1115b3a1597b293c3b959985662c0e872c092b12` |

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — no unresolved finding in the finite CLI/provenance/static-harness scope.
