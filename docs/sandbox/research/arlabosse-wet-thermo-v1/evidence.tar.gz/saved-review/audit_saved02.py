"""Read saved wet-thermodynamics evidence using stdlib only; no model/EOS import."""
import hashlib
import json
import math
from fractions import Fraction as F
from pathlib import Path
import sys
import time
from datetime import datetime, timezone

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
BASE = Path('/private/tmp/arlabosse-wet-thermo-v1')
OUT = BASE/'saved-review'
checks = []
metrics = {}
started = time.monotonic()

def check(name, okay, detail=None):
    row = {'name': name, 'passed': bool(okay)}
    if detail is not None:
        row['detail'] = detail
    checks.append(row)

def read(path):
    def reject(value):
        raise ValueError('nonfinite_JSON_constant:' + value)
    return json.loads(Path(path).read_bytes(), parse_constant=reject)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def rational(value):
    return F(int(value['numerator']), int(value['denominator']))

def near(name, actual, expected, limit):
    residual = actual-expected
    check(name, abs(residual) <= limit, {'residual': float(residual), 'limit': float(limit)})

def exact(name, actual, expected):
    check(name, actual == expected)

def lerp(nodes, x):
    for (lo, ylo), (hi, yhi) in zip(nodes, nodes[1:]):
        if lo <= x <= hi:
            return ((hi-x)*ylo+(x-lo)*yhi)/(hi-lo)
    raise ValueError('outside_original_q_hull')

def integrate(nodes, lo, hi):
    # Independent exact trapezoids split at original source knots.
    cuts = [lo]+[x for x, _ in nodes if lo < x < hi]+[hi]
    return sum(((b-a)*(lerp(nodes,a)+lerp(nodes,b))/2
                for a,b in zip(cuts,cuts[1:])), F())

def finite_tree(obj):
    if isinstance(obj, float):
        return math.isfinite(obj)
    if isinstance(obj, dict):
        return all(finite_tree(v) for v in obj.values())
    if isinstance(obj, list):
        return all(finite_tree(v) for v in obj)
    return True

def run():
    recorded_files = sorted(p for d in ('native01','supervised-native01')
                            for p in (BASE/d).iterdir() if p.is_file())
    before = {str(p):sha(p) for p in recorded_files}
    acceptance = read(BASE/'native01/ACCEPTANCE.json')
    definition = read(BASE/'native01/MODEL_DEFINITION.json')
    metadata = read(BASE/'supervised-native01/metadata.json')
    status = read(BASE/'supervised-native01/status.json')
    review = read(BASE/'code-review/FINAL_REVIEW.json')
    runtime = read(BASE/'native01/RUNTIME_BEFORE.json')
    exact('native_completed', acceptance['status'], 'completed')
    exact('outer_complete_exit_zero', (status['status'], status['returncode']), ('complete',0))
    check('leader_reaped_without_signal_errors', status['cleanup']['leader_reaped'] is True and status['cleanup']['signal_errors']==[])
    exact('containment_scope_not_overstated', status['cleanup']['scope'], 'original_process_group_only; escaped_sessions_not_contained')
    check('no_native_failure_record', not (BASE/'native01/FAILURE.json').exists())
    exact('original_outer_limit', metadata['timeout_s'],80.)
    exact('original_cleanup_grace', metadata['cleanup_grace_s'],5.)
    check('actual_elapsed_within_original_limits',0 < acceptance['elapsed_seconds'] < 60 and acceptance['elapsed_seconds'] <= status['elapsed_s'] < 80)
    exact('fixed_isolated_installed_command',metadata['command'], ['/usr/bin/env','-u','PYTHONPATH','/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python','-I',str(BASE/'execution/native_driver.py')])
    exact('outside_repository_cwd',metadata['cwd'],'/private/tmp')
    exact('saved_runtime_before_after_identical',runtime,read(BASE/'native01/RUNTIME_AFTER.json'))
    exact('saved_runtime_python', runtime['python'],'.'.join(map(str,sys.version_info[:3])))
    exact('saved_runtime_versions',runtime['versions'],{'sludge-vme':'0.1.0','numpy':'2.5.2','scipy':'1.18.1','iapws':'1.5.5','CoolProp':'8.0.0'})
    exact('input_path_sets_before_after',set(metadata['inputs_before']),set(status['inputs_after']))
    inputs = metadata['inputs_before']
    mismatches=[]
    for name, item in inputs.items():
        p=Path(name)
        if not p.is_file() or p.stat().st_size!=item['bytes'] or sha(p)!=item['sha256'] or status['inputs_after'][name]!=item['sha256']:
            mismatches.append(name)
    check('all_declared_inputs_match_before_after_and_current',not mismatches,{'entries':len(inputs),'mismatches':mismatches})
    exact('saved_unchanged_flag',status['inputs_unchanged'],True)
    for name, item in review['files'].items():
        exact('reviewed_snapshot:'+name,sha(name),item['sha256'])
        if '/tests/' not in name:
            exact('reviewed_input_in_native_manifest:'+name,inputs[name]['sha256'],item['sha256'])
    freeze = read(BASE/'install/SOURCE_FREEZE.json')
    install = read(BASE/'install/INSTALL_IDENTITY_BEFORE.json')
    installed=Path(install['installed_path'])
    exact('frozen_package_file_count',len(freeze),170)
    mismatches=[]
    for relative, expected in freeze.items():
        p=ROOT/relative
        ip=installed/Path(relative).relative_to('src/sludge_sandbox')
        if sha(p)!=expected or sha(ip)!=expected or inputs[str(p)]['sha256']!=expected or inputs[str(ip)]['sha256']!=expected:
            mismatches.append(relative)
    check('all_170_source_installed_and_freeze_entries_match',not mismatches,{'mismatches':mismatches})
    exact('install_rows_match_freeze', {r['path']:r['frozen_sha256'] for r in install['rows']},freeze)
    check('installed_identity_rows_consistent',all(r['frozen_sha256']==r['source_sha256']==r['installed_sha256'] for r in install['rows']))
    check('saved_runtime_module_catalog_hashes_match_frozen_installed', all(sha(installed/p)==h for p,h in runtime['modules'].items()) and all(sha(installed/'catalogs'/p)==h for p,h in runtime['catalogs'].items()))
    model_path=ROOT/'data/sandbox/research/arlabosse-wet-thermo-v1/model.json'
    model=read(model_path)
    exact('saved_model_definition_preserves_pinned_definition',{k:definition[k] for k in model},model)
    exact('saved_model_sha',definition['model_sha256'],sha(model_path))
    all_assets=model['upstream']+model['assets']
    all_assets += [a for s in model['upstream'] for a in read(ROOT/s['path'])['assets']]
    check('source_definition_all_asset_hashes_match', all(sha(ROOT/a['path'])==a['sha256']==inputs[str(ROOT/a['path'])]['sha256'] for a in all_assets),{'entries':len(all_assets)})
    check('water_source_assets_match',all(sha(ROOT/'data/sandbox/water'/p)==h for p,h in definition['water']['source_asset_sha256'].items()))
    fact_path=ROOT/'data/sandbox/research/arlabosse95/facts.json'
    exact('original_facts_hash',sha(fact_path),'543d55918db7df6d0cc0f695c5dceadbdebda82b83f4fdde206266bcd12f2f16')
    facts=read(fact_path)
    heat_rows={F(r['requested_moisture_kg_water_per_kg_dry_matter']):r for r in facts['observations'] if r['figure']==2}
    aw_rows={F(r['requested_moisture_kg_water_per_kg_dry_matter']):r for r in facts['observations'] if r['figure']==1 and F(r['requested_moisture_kg_water_per_kg_dry_matter'])>=F('.15')}
    heat=sorted((w,rational(r['value'])) for w,r in heat_rows.items() if r['value'] is not None)
    exact('six_original_q_nodes',len(heat),6)
    exact('eight_supported_original_activity_nodes',len(aw_rows),8)
    exact('three_original_q_nulls', {w for w,r in heat_rows.items() if r['value'] is None}, {F('.1'),F('.5'),F('.6')})
    exact('eight_saved_calibrations',len(acceptance['calibration']),8)
    exact('saved_calibration_moistures', {F(r['moisture']) for r in acceptance['calibration']},set(aw_rows))
    source_points={rational(p['moisture_kg_water_per_kg_dry_matter']):p for p in definition['source_point_records']}
    q_errors=[];aw_errors=[]
    for row in acceptance['calibration']:
        w=F(row['moisture']);state=row['state'];original_aw=rational(aw_rows[w]['value']);q=heat_rows[w]['value']
        exact('saved_aw_rational:'+str(w),F(row['source_activity']),original_aw)
        exact('saved_source_point:'+str(w),state['source_readings_at_moisture'],source_points[w])
        exact('source_activity_bounds:'+str(w),list(map(rational,source_points[w]['activity']['digitization_bounds'])),list(map(rational,aw_rows[w]['digitization_bounds'])))
        exact('calibration_at_95C:'+str(w),state['temperature_k'],368.15)
        aw_error=state['activity']-float(original_aw);aw_errors.append(abs(aw_error))
        exact('recorded_aw_residual:'+str(w),row['activity_residual'],aw_error)
        near('original_activity_threshold:'+str(w),state['activity'],float(original_aw),1e-12)
        exact('source_q_unknown_marker:'+str(w),row['source_heat_is_unknown'],q is None)
        if q is None:
            exact('null_original_q_retained:'+str(w),(row['source_heat'],source_points[w]['total_desorption_heat']['value']), (None,None))
        else:
            exact('source_q_rational:'+str(w),F(row['source_heat']),rational(q))
            exact('source_q_bounds:'+str(w),list(map(rational,source_points[w]['total_desorption_heat']['digitization_bounds'])),list(map(rational,heat_rows[w]['digitization_bounds'])))
            q_error=state['total_desorption_heat_j_kg_water']-float(rational(q));q_errors.append(abs(q_error))
            exact('recorded_q_residual:'+str(w),row['heat_residual_j_kg_water'],q_error)
            near('original_q_threshold:'+str(w),state['total_desorption_heat_j_kg_water'],float(rational(q)),1e-6)
    water={r['temperature_k']:r for r in acceptance['oracle_water']}
    exact('no_duplicate_oracle_water_temperature',len(water),len(acceptance['oracle_water']))
    check('oracle_water_same_pressure_mass_sources',all(r['liquid_pressure_pa']==100000. and r['molar_mass_kg_mol']==definition['water']['molar_mass_kg_mol'] and r['source_ids']==definition['water']['source_ids'] for r in water.values()))
    states=[acceptance['initial']]+[r['state'] for r in acceptance['calibration']]+[r['inverse']['state'] for r in acceptance['stages']]+[r['state'] for r in acceptance['derivatives']]
    for i,state in enumerate(states):
        label=str(i)
        check('saved_state_domain:'+label,308.15<=state['temperature_k']<=368.15 and .15<=state['moisture_kg_water_per_kg_dry']<=.8 and 0<state['activity']<=1 and state['liquid_mechanical_pressure_pa']==100000.)
        check('saved_state_stability:'+label,all(v is None or v>=0 for v in (state['composition_derivative_left_j_kg_water'],state['composition_derivative_right_j_kg_water'])))
        exact('saved_model_identity:'+label,(state['model_id'],state['model_sha256'],state['source_ids']),(model['model_id'],definition['model_sha256'],definition['source_ids']))
        exact('saved_pressure_product:'+label,state['model_equilibrium_vapor_pressure_pa'],state['pure_model_equilibrium_vapor_pressure_pa']*state['activity'])
        exact('saved_molar_mass_conversion:'+label,state['water_chemical_potential_j_mol'],state['water_chemical_potential_j_kg_water']*definition['water']['molar_mass_kg_mol'])
    for i,record in enumerate(states+[acceptance['drying']]):
        check('qualification_preserved:'+str(i),all(record[k] is False for k in ('material_qualified','training_eligible','full_firing_cycle')) and record['qualification']=='conditional_exploration_not_validated_wet_material')
        check('unknown_errors_preserved:'+str(i),all(record[k] is None for k in ('interpolation_model_error','temperature_extension_model_error','water_reference_model_error','experimental_uncertainty')))
    check('overall_qualification_and_no_physical_clock',all(acceptance[k] is False for k in ('material_qualified','training_eligible','full_firing_cycle','physical_time_axis')))
    exact('calibration_not_holdout',acceptance['reality_validation'],'construction_data_reproduction_not_holdout_prediction')
    check('all_saved_floats_finite',finite_tree(acceptance))
    exact('three_stages',[(r['name'],r['control_temperature_k'],r['moisture']) for r in acceptance['stages']],[('heat',368.15,.75),('dry_at95C',368.15,.25),('cool',323.15,.25)])
    md=F('0.1');md_float=.1
    q_exact=md*integrate(heat,F('.25'),F('.75'))
    metrics['exact_source_q_heat_j']=str(q_exact)
    near('independent_original_fraction_integral',F(acceptance['independent_source_q_heat_j']),q_exact,F('1e-5'))
    dry_source=read(ROOT/'data/sandbox/research/arlabosse2005/source.json')['caloric_relation']
    exact('original_dry_Cp_coefficients',(dry_source['intercept'],dry_source['slope_per_degC']),(1434,3.29))
    def dry_change(a,b):
        ca,cb=F(str(a))-F('273.15'),F(str(b))-F('273.15')
        return F(dry_source['intercept'])*(cb-ca)+F(str(dry_source['slope_per_degC']))*(cb**2-ca**2)/2
    def supplied(a,b,w):
        return md*(dry_change(a,b)+F(str(w))*(F(water[b]['liquid_enthalpy_j_kg_water'])-F(water[a]['liquid_enthalpy_j_kg_water'])))
    independent_q=[supplied(333.15,368.15,.75),q_exact,supplied(368.15,323.15,.25)]
    independent_out=[F(),md*F('.5')*F(water[368.15]['vapor_enthalpy_j_kg_water']),F()]
    exact('signed_outgoing_reference_is_negative',independent_out[1]<0,True)
    initial=acceptance['initial'];previous=md_float*initial['specific_enthalpy_j_kg_dry'];exact_initial=md*F(initial['specific_enthalpy_j_kg_dry'])
    stages=[];endpoint_errors=[]
    for i, state in enumerate([initial]+[r['inverse']['state'] for r in acceptance['stages']]):
        r=F(state['specific_enthalpy_j_kg_dry'])-F(state['specific_gibbs_j_kg_dry'])-F(state['temperature_k'])*F(state['specific_entropy_j_kg_dry_k'])
        endpoint_errors.append(abs(float(r)))
        near('exact_saved_endpoint_H_G_TS:'+str(i),r,F(),F('1e-5'))
        recorded=acceptance['initial_H_minus_G_TS_j_kg_dry'] if i==0 else acceptance['stages'][i-1]['H_minus_G_TS_j_kg_dry']
        exact('saved_binary64_H_G_TS:'+str(i),recorded,math.fsum((state['specific_enthalpy_j_kg_dry'],-state['specific_gibbs_j_kg_dry'],-state['temperature_k']*state['specific_entropy_j_kg_dry_k'])))
    for i,row in enumerate(acceptance['stages']):
        inv=row['inverse'];state=inv['state'];name=row['name']
        exact('stage_starts_from_prior_conserved_target:'+name,row['starting_total_enthalpy_j'],previous)
        near('independent_supplied_Q:'+name,F(row['supply_heat_j']),independent_q[i],F('1e-5'))
        near('independent_signed_Hout:'+name,F(row['signed_outgoing_vapor_enthalpy_j']),independent_out[i],F('1e-5'))
        target=math.fsum((previous,row['supply_heat_j'],-row['signed_outgoing_vapor_enthalpy_j']))
        exact('saved_conserved_target:'+name,row['target_enthalpy_j'],target)
        exact('inverse_bound_to_conserved_target_and_mass:'+name,(inv['target_enthalpy_j'],inv['dry_mass_kg']),(target,.1))
        exact('original_inverse_policy:'+name,(inv['temperature_tolerance_k'],inv['maximum_iterations']),(1e-9,64))
        check('inverse_iteration_count:'+name,0<=inv['iterations']<=64)
        recovered=md_float*state['specific_enthalpy_j_kg_dry'];residual=math.fsum((recovered,-previous,-row['supply_heat_j'],row['signed_outgoing_vapor_enthalpy_j']))
        exact('recorded_recovered_H:'+name,row['recovered_total_enthalpy_j'],recovered)
        exact('recorded_open_energy_residual:'+name,row['open_energy_residual_j'],residual)
        exact('recorded_inverse_residual:'+name,inv['residual_j'],math.fsum((recovered,-target)))
        exact('recorded_temperature_residual:'+name,row['temperature_residual_k'],state['temperature_k']-row['control_temperature_k'])
        near('temperature_original_limit:'+name,state['temperature_k'],row['control_temperature_k'],1e-6)
        check('inverse_residual_and_original_balance_limit:'+name,abs(residual)<=1e-5 and abs(inv['residual_j'])<=min(1e-5,inv['residual_tolerance_j']))
        lo,hi=inv['temperature_bracket_k']
        check('inverse_saved_bracket:'+name,308.15<=lo<=state['temperature_k']<=hi<=368.15 and hi-lo==inv['bracket_width_k'] and hi-lo<=1e-9)
        exact('no_endpoint_roundoff_allowance_used:'+name,(inv['endpoint_roundoff_allowance_j'],inv['target_outside_nominal_endpoint_range']),(0.,False))
        exact_residual=md*F(state['specific_enthalpy_j_kg_dry'])-F(previous)-independent_q[i]+independent_out[i]
        near('independent_exact_saved_stage_balance:'+name,exact_residual,F(),F('1e-5'))
        stages.append({'name':name,'temperature_k':state['temperature_k'],'temperature_error_k':row['temperature_residual_k'],'supply_heat_j':row['supply_heat_j'],'signed_outgoing_vapor_enthalpy_j':row['signed_outgoing_vapor_enthalpy_j'],'saved_binary64_balance_j':residual,'independent_fraction_balance_j':float(exact_residual),'iterations':inv['iterations']})
        previous=target
    final=acceptance['stages'][-1]['inverse']['state']
    whole_exact=md*F(final['specific_enthalpy_j_kg_dry'])-exact_initial-sum(independent_q)+sum(independent_out)
    near('independent_exact_full_path_balance',whole_exact,F(),F('1e-5'))
    total_q=total_out=0.
    for row in acceptance['stages']:
        total_q=math.fsum((total_q,row['supply_heat_j']))
        total_out=math.fsum((total_out,row['signed_outgoing_vapor_enthalpy_j']))
    exact('total_Q',acceptance['total_supply_heat_j'],total_q)
    exact('total_signed_Hout',acceptance['total_signed_outgoing_enthalpy_j'],total_out)
    exact('saved_full_path_balance',acceptance['whole_path_energy_residual_j'],math.fsum((md_float*final['specific_enthalpy_j_kg_dry'],-md_float*initial['specific_enthalpy_j_kg_dry'],-total_q,total_out)))
    drying=acceptance['drying']
    exact('drying_control_basis',(drying['temperature_k'],drying['start_moisture'],drying['end_moisture'],drying['dry_mass_kg'],drying['removed_water_kg']),(368.15,.75,.25,.1,.05))
    near('drying_Q_against_original_integral',F(drying['heat_j']),q_exact,F('1e-5'))
    near('drying_signed_Hout_against_saved_water_reference',F(drying['vapor_carried_enthalpy_j']),independent_out[1],F('1e-5'))
    near('drying_full_energy_identity',F(drying['heat_j'])-F(drying['vapor_carried_enthalpy_j'])-F(drying['material_enthalpy_change_j']),F(),F('1e-5'))
    double_latent=F(acceptance['independent_source_q_heat_j'])+md*F('.5')*(F(water[368.15]['vapor_enthalpy_j_kg_water'])-F(water[368.15]['liquid_enthalpy_j_kg_water']))
    near('double_latent_control_Q_recomputed',F(acceptance['double_latent_control_heat_j']),double_latent,F('1e-5'))
    negative=double_latent-F(drying['material_enthalpy_change_j'])-F(drying['vapor_carried_enthalpy_j'])
    check('double_latent_fails_same_original_balance_threshold',abs(negative)>F('1e-5'),{'residual_j':float(negative),'limit_j':1e-5})
    derivative_details=[]
    exact('three_registered_derivative_locations',[(r['temperature_k'],r['moisture']) for r in acceptance['derivatives']],[(333.15,.35),(353.15,.55),(363.15,.75)])
    for row in acceptance['derivatives']:
        t,w=row['temperature_k'],row['moisture'];state=row['state'];name=str((t,w))
        exact('original_derivative_increments:'+name,(row['cp_delta_temperature_k'],row['mu_delta_temperature_k']),(.01,.1))
        cp=(row['h_plus_j_kg_dry']-row['h_minus_j_kg_dry'])/.02
        exact('saved_Cp_finite_difference:'+name,row['cp_finite_difference_j_kg_dry_k'],cp)
        exact('saved_Cp_residual:'+name,row['cp_difference_j_kg_dry_k'],cp-state['heat_capacity_j_kg_dry_k'])
        cp_exact=(F(row['h_plus_j_kg_dry'])-F(row['h_minus_j_kg_dry']))/F('.02')-F(state['heat_capacity_j_kg_dry_k'])
        near('exact_saved_Cp_original_threshold:'+name,cp_exact,F(),F('1e-4'))
        exact('mu_ex_subtracts_same_saved_water_reference:'+name,row['mu_ex_j_kg_water'],state['water_chemical_potential_j_kg_water']-water[t]['liquid_chemical_potential_j_kg_water'])
        slope=(row['mu_ex_plus_j_kg_water']-row['mu_ex_minus_j_kg_water'])/.2
        exact('saved_mu_ex_slope:'+name,row['mu_ex_temperature_derivative_j_kg_water_k'],slope)
        b0=math.fsum((water[368.15]['vapor_enthalpy_j_kg_water'],-water[368.15]['liquid_enthalpy_j_kg_water'],-float(lerp(heat,F(str(w))))))
        exact('b0_from_original_q_and_shared_water:'+name,row['oracle_b0_j_kg_water'],b0)
        exact('saved_excess_identity_residual:'+name,row['excess_identity_difference_j_kg_water'],math.fsum((row['mu_ex_j_kg_water'],-t*(row['mu_ex_plus_j_kg_water']-row['mu_ex_minus_j_kg_water'])/.2,-b0)))
        mu_exact=F(row['mu_ex_j_kg_water'])-F(t)*(F(row['mu_ex_plus_j_kg_water'])-F(row['mu_ex_minus_j_kg_water']))/F('.2')-F(b0)
        near('exact_saved_mu_identity_original_threshold:'+name,mu_exact,F(),F('1e-4'))
        derivative_details.append({'temperature_k':t,'moisture':w,'cp_exact_residual_j_kg_dry_k':float(cp_exact),'mu_exact_residual_j_kg_water':float(mu_exact),'saved_cp_residual_j_kg_dry_k':row['cp_difference_j_kg_dry_k'],'saved_mu_residual_j_kg_water':row['excess_identity_difference_j_kg_water']})
    stdout=[json.loads(line) for line in (BASE/'supervised-native01/stdout.log').read_text().splitlines()]
    exact('three_actual_phase_stdout_records',[r['phase'] for r in stdout],[r['name'] for r in acceptance['stages']])
    check('stdout_matches_actual_states_and_residuals',all(s['temperature_k']==r['inverse']['state']['temperature_k'] and s['residual_j']==r['open_energy_residual_j'] and 0<=s['elapsed_seconds']<=acceptance['elapsed_seconds'] for s,r in zip(stdout,acceptance['stages'])))
    exact('stderr_empty',(BASE/'supervised-native01/stderr.log').read_bytes(),b'')
    exact('saved_native_files_unchanged_by_audit',{str(p):sha(p) for p in recorded_files},before)
    check('no_scientific_package_imports',not any(k.split('.')[0] in {'sludge_sandbox','iapws','CoolProp','numpy','scipy'} for k in sys.modules))
    metrics.update(driver_elapsed_seconds=acceptance['elapsed_seconds'],outer_elapsed_seconds=status['elapsed_s'],declared_inputs=len(inputs),frozen_package_files=len(freeze),oracle_water_queries=len(water),saved_state_records=len(states),stage_details=stages,whole_path_saved_residual_j=acceptance['whole_path_energy_residual_j'],whole_path_exact_residual_j=float(whole_exact),max_endpoint_exact_H_G_TS_j_kg_dry=max(endpoint_errors),max_activity_calibration_residual=max(aw_errors),max_q_calibration_residual_j_kg_water=max(q_errors),double_latent_control_exact_residual_j=float(negative),derivatives=derivative_details,reviewed_native_file_hashes=before)

try:
    run()
except BaseException as exc:
    check('audit_execution_completed',False,{'type':type(exc).__name__,'message':str(exc)})
result={'status':'PASS' if all(r['passed'] for r in checks) else 'FAIL','checks':len(checks),'failed_checks':[r for r in checks if not r['passed']],'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),'audit_elapsed_seconds':time.monotonic()-started,'scope':'Saved values and filesystem hashes only; stdlib, no EOS/property recomputation or new physical path.','metrics':metrics,'assertions':checks,'limitations':['Acceptance thresholds are numerical checks, not measured wet-material validation or uncertainty bounds.','The supplied water property values are audited for saved reference/source identity and arithmetic only; no independent EOS was evaluated.','The controlled path has no drying rate or physical time axis; all material/training/full-cycle flags remain false.','Process cleanup is saved supervisor evidence for the original process group, not escaped-session containment.']}
with (OUT/'SAVED_REVIEW02.json').open('x') as stream:
    json.dump(result,stream,ensure_ascii=False,indent=2,allow_nan=False)
    stream.write('\n')
print(json.dumps({k:result[k] for k in ('status','checks','failed_checks','audit_elapsed_seconds','metrics')},indent=2))
raise SystemExit(0 if result['status']=='PASS' else 1)
