# Saved native01 wet-thermodynamics audit

**PASS: 341 assertions, zero failed checks**, using saved JSON, original source rationals and filesystem byte hashes only. Final audit: [SAVED_REVIEW02.json](SAVED_REVIEW02.json), [audit_saved02.py](audit_saved02.py), [AUDIT02.log](AUDIT02.log). No scientific package was imported, no water EOS evaluated, and no physical path rerun. Only this saved-review directory was written.

The actual driver completed in **1.203729958041 s**; the outer supervisor completed with return code 0 and recorded the leader reaped in **6.319788124994 s**. The original limits remain 60 s internal, 80 s outer, and 5 s cleanup grace. Saved cleanup evidence covers the original process group; it does not certify escaped-session containment.

## Recomputed numerical acceptance

Original dry mass: 0.1 kg; W means kg water/kg dry matter. The source-q integral was independently recomputed as exact rational trapezoids split at original source knots: **7583900/63 J = 120379.36507937 J**. Heating/cooling supply was independently recomputed from the pinned original dry-Cp polynomial and saved separate-oracle liquid-water enthalpies in the shared reference. Signed outgoing vapor enthalpy was retained, including its negative value.

| Stage | Recovered T (K) | Q (J) | Signed Hout (J) | Exact saved balance (J) | Inverse iterations |
|---|---:|---:|---:|---:|---:|
| heat | 368.15 | 16925.396552805 | 0 | 0 | 0 |
| dry_at95C | 368.14999999956 | 120379.36507937 | -664607.97614238 | -1.2197073e-07 | 37 |
| cool | 323.14999999942 | -12243.446304444 | 0 | -1.5236437e-07 | 39 |

Each stage consumes the prior conserved total-H target and uses `Hnext = Hprevious + Q - Hout`. Its saved inverse target and dry mass match that target/basis. The two nontrivial inverses completed in 37 and 39 iterations; the first stage exactly matched the upper endpoint. All used the registered 1e-9 K requested tolerance and maximum 64 iterations; no endpoint roundoff allowance was used. The saved state brackets, residuals and inverse convergence fields were checked.

| Check | Independent recomputation | Original limit |
|---|---:|---:|
| Maximum absolute temperature error | 5.77472292207e-10 K | 1e-6 K |
| Maximum absolute per-stage energy residual | 1.52364373207e-07 J | 1e-5 J |
| Full-path energy residual | -1.52471549218e-07 J | absolute 1e-5 J |
| Maximum absolute H-G-TS across initial + all three endpoints | 1.40995015273e-09 J/kg dry | 1e-5 J/kg dry |
| Maximum dH/dT minus Cp residual from saved raw values | 3.46633896697e-07 J/(kg dry K) | 1e-4 J/(kg dry K) |
| Maximum excess-potential identity residual from saved raw values | 1.82492125517e-06 J/kg water | 1e-4 J/kg water |
| Eight activity / six heat calibration residuals | 0 / 0 in saved binary64 nominal values | 1e-12 / 1e-6 J/kg water |
| Double-latent negative-control energy residual | 114056.763879 J | must exceed 1e-5 J |

Exact Fraction arithmetic here treats the saved binary64 values as exact input numbers; it does not claim those numbers have no physical or numerical error. The saved driver's own full-path residual is -1.52402208187e-07 J. Its original binary64 expressions were also reproduced. Finite-difference increments remain 0.01 K for Cp and 0.1 K for the excess-potential identity at the three preregistered locations; no threshold or stencil was changed.

## Identity, provenance and retained limits

All **376 declared inputs** match their before/after and current SHA-256/size records. All **170 source/installed package files** match the freeze. Reviewed source/model/driver/protocol hashes match the earlier finite-review snapshot. Runtime before/after records are identical and their 163 module + 4 catalog hashes match the installed package. The saved command used the fixed installed interpreter with `-I`, `PYTHONPATH` unset and working directory `/private/tmp`.

The pinned metadata, 16 direct/upstream asset entries, water-source assets and original desorption facts match. The definition preserves the original source point values and digitization bounds. q observations at W=.1/.5/.6 are still null; W=.5/.6 model values are not reclassified as observations. Fifteen saved model state records and the drying result retain conditional qualification, unknown model/experimental errors, and false material/training/full-cycle flags. Recorded activity/domain/stability, pressure-product and molar-mass conversions pass. Eleven saved separate-oracle water query records use the same stated mass, pressure and source IDs.

All eight native/supervisor result files retained identical hashes through this audit. There is no native FAILURE.json in this successful attempt. The source-water h/g values were audited for saved reference identity and arithmetic only; they were not independently recomputed by an EOS. This verifies a controlled property/energy path and construction-data reproduction, not independent wet-material validation, drying time, transport, or a full firing cycle.

## Preserved audit-script failure

The first audit's `SAVED_REVIEW.json` and `AUDIT.log` remain **FAIL**, with four exact-equality mismatches caused by my audit script regrouping floating-point additions/multiplication/division. All independently recomputed Fraction thresholds already passed there. The native result did not fail. [AUDIT01_DIAGNOSIS.json](AUDIT01_DIAGNOSIS.json) records the actual discrepancies; [AUDIT02.diff](AUDIT02.diff) records the bounded correction. The revised audit matches the frozen driver's expression order for saved-field equality while retaining the independent exact checks and every original numerical threshold. No first-attempt file or physical result was overwritten.

## Saved CLI status observed separately

After finishing the independent native-path audit, I read the parent-produced `cli/native01/ACCEPTANCE.json` without running another CLI/EOS call. It records `passed`: point/inverse exited 0 in 0.417054041987285 / 0.5838600000133738 s, and the intentional invalid-input case exited 1 in 0.33013466699048877 s; 344 inputs are reported unchanged. Material/full-cycle flags remain false. This is an observation of the original saved CLI record, not an additional independent numerical audit; it is excluded from the 341 assertions above. Its exact snapshot is retained in [CLI_SAVED_STATUS.json](CLI_SAVED_STATUS.json).

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — the saved native01 result passes its original numerical and identity gates within the stated model limits.
