"""Execute repaired B2 numerical checks without promoting uncommitted evidence."""
from pathlib import Path
import json
import platform
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'material_dynamics_v2b2'
sys.path.insert(0, str(ROOT))

from audit import audit_exports
from diagnostics import compute
from exports import write_json, write_raw
from resources import Budget
from scenarios import expand_frozen_manifest
from solver import integrate
from verification import NumericalEvidence

default = ROOT / 'validation' / 'repair_default'
default.mkdir(parents=True)
budget = Budget(180, 180, 'integrate_default')
results = []
executions = []
for scenario in expand_frozen_manifest():
    before = time.monotonic()
    result = integrate(scenario, budget)
    results.append(result)
    executions.append(dict(scenario_id=scenario.id, steps=result.steps,
                           elapsed_seconds=time.monotonic()-before))
    budget.completed.append(scenario.id)
write_raw(default, results)
diagnostics = []
for result in results:
    diagnostic = compute(result.scenario, result)
    diagnostic.update(verification_scope='frozen_suite', numerical_validation='not_run')
    diagnostics.append(diagnostic)
write_json(default/'summary.json', {'scenarios':diagnostics})
budget.phase = 'audit_default'
audited = audit_exports(str(default.relative_to(ROOT)))
write_json(default/'audit.json', audited)
write_json(default/'resources.json', budget.snapshot('integrated'))
write_json(default/'executions.json', executions)
report = dict(python=sys.version, platform=platform.platform(),
              method='Direct numerical execution; no source/verification binding promotion',
              default_audit=audited, default_resources=budget.snapshot('integrated'))
if not audited['passed']:
    write_json(BASE/'numerical_report.json', report)
    raise SystemExit('Repaired default audit failed')

focused = ROOT/'validation'/'repair_focused'
focused.mkdir()
focused_budget = Budget(300, 300, 'focused_numerical')
runner = NumericalEvidence(focused, focused_budget)
try:
    runner.run()
finally:
    report.update(numerical_gates=runner.gates,
                  numerical_invocations=runner.calls + runner.b1_calls,
                  focused_resources=focused_budget.snapshot('finished'))
    write_json(BASE/'numerical_report.json', report)
print(json.dumps(dict(default_passed=audited['passed'], default_cases=len(results),
                      max_scaled_errors=audited['max_scaled_errors'],
                      default_seconds=report['default_resources']['elapsed_wall_seconds'],
                      focused_seconds=report['focused_resources']['elapsed_wall_seconds'],
                      numeric_gates={key:value['result'] for key,value in runner.gates.items()},
                      numeric_calls=runner.calls+runner.b1_calls), indent=2))
