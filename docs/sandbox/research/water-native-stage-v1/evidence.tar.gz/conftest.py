# Temporary overlay only; never apply to repo.
from pathlib import Path
import sys
import sludge_sandbox
HERE=Path(__file__).parent
sludge_sandbox.__path__.insert(0,str(HERE))
sludge_sandbox.__path__.insert(0,str(HERE.parent/'pressure_session_candidate'))
sys.path.insert(0,str(Path.cwd()/'tests/sandbox'))
