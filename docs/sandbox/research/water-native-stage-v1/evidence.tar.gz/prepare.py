from pathlib import Path
p=Path(__file__).parent
s=(p/'baseline_stage.py').read_text()
s=s.replace('fixture: ManufacturedConstantLiquidFixture | None) -> F:', 'fixture: ManufacturedConstantLiquidFixture | None, *, states=None, cell_rate=None,\n                    pressure_session=None, query_context=None, caller_guard=None,\n                    remaining_caller_wall=None) -> F:')
s=s.replace("    if nl:\n        require(type(fixture)","    if nl and pressure_session is not None:\n        require(fixture is None,'native_pressure_and_fixture_are_exclusive')\n        return _native_pressure_radius(pair,state,inverse,cell,states,cell_rate,pressure_session,query_context,caller_guard,remaining_caller_wall)\n    if nl:\n        require(type(fixture)",1)
insert='''@dataclass(frozen=True)
class NativePressureQueryContext:
    role: str
    time: T
    source_binding: str
    interfaces: tuple
    original_initial: tuple
    stage_start: T
    stage_end: T
    stage_policy: MixedStagePolicy


@dataclass(frozen=True, kw_only=True)
class NativePressureMixedTrialResult(MixedTrialResult):
    """Explicit unsupported-by-legacy-codec local trial with full proof history."""
    pressure_session_before: object
    pressure_session_after: object
    pressure_query_contexts: tuple
    native_schema: str = 'mixed_native_pressure_trial_v1'


def _native_pressure_radius(pair,state,inverse,cell,states,cell_rate,session,context,
                            caller_guard,remaining_caller_wall):
    from sludge_sandbox.mass_wet_pressure_session import PressureSession
    from sludge_sandbox.mass_wet_pressure_interval import encoded
    from sludge_sandbox.mass_wet_transport import WetCellRate
    require(type(session) is PressureSession,'explicit_pressure_session')
    require(type(cell) is int and cell in (0,1),'native_pressure_cell_index')
    require(type(states) is tuple and len(states)==2 and all(type(s) is WetMixedState for s in states), 'native_pressure_full_states')
    require(states[cell] is state and type(cell_rate) is WetCellRate and cell_rate.inverse is inverse,'native_pressure_actual_state_inverse')
    require(type(context) is NativePressureQueryContext,'explicit_native_pressure_context')
    require(context.role in ('full','fine') and type(context.time) is T and context.time==context.stage_end
            and type(context.stage_start) is T and context.stage_start<context.stage_end
            and type(context.stage_policy) is MixedStagePolicy,'native_pressure_comparison_time_role')
    require(context.source_binding==pair.binding() and context.interfaces==pair.interfaces,'native_pressure_comparison_source_modes')
    if caller_guard is not None:caller_guard()
    # Session retains the attempted query and all costs before status is checked.
    attempt=session.query(pair,states,cell_rate,cell,context=encoded((context,states,cell_rate,cell)),
                          caller_guard=caller_guard,remaining_caller_wall=remaining_caller_wall)
    if attempt.status!='proved_conditional_query':
        reason=attempt.reason or 'native_pressure_unresolved'
        error={'cancelled':InterruptedError,'resource_limit':TimeoutError,'domain_exit':DomainExit}.get(attempt.failure_kind,ValueError)
        raise error(reason)
    require(attempt.failure_kind is None and type(attempt.pressure_radius_pa) is F and attempt.pressure_radius_pa>=0,'proved_exact_native_pressure_radius')
    if caller_guard is not None:caller_guard()
    return attempt.pressure_radius_pa


'''
s=s.replace('def components(r: WetRates)',insert+'def components(r: WetRates)')
s=s.replace('constant_liquid_fixture: ManufacturedConstantLiquidFixture | None=None) -> MixedTrialResult:', 'constant_liquid_fixture: ManufacturedConstantLiquidFixture | None=None, pressure_session=None) -> MixedTrialResult:')
s=s.replace("    h=end.elapsed_since(start);origin=", "    session_before=None;pressure_contexts=[]\n    if pressure_session is not None:\n        from sludge_sandbox.mass_wet_pressure_session import PressureSession\n        require(type(pressure_session) is PressureSession,'explicit_pressure_session')\n        require(constant_liquid_fixture is None,'native_pressure_and_fixture_are_exclusive')\n        session_before=pressure_session.snapshot()\n    h=end.elapsed_since(start);origin=")
old="""            pressure=max(pressure,abs(exact(a.inverse.point.pressure_pa)-exact(b.inverse.point.pressure_pa))+pressure_radius(pair,full[i],a.inverse,i,constant_liquid_fixture)+pressure_radius(pair,fine[i],b.inverse,i,constant_liquid_fixture))"""
new="""            if pressure_session is None:
                pressure=max(pressure,abs(exact(a.inverse.point.pressure_pa)-exact(b.inverse.point.pressure_pa))+pressure_radius(pair,full[i],a.inverse,i,constant_liquid_fixture)+pressure_radius(pair,fine[i],b.inverse,i,constant_liquid_fixture))
            else:
                radii=[]
                for role,states,sample,rate in (('full',full,whole.endpoint_sample,a),('fine',fine,half2.endpoint_sample,b)):
                    require(sample.state is states and sample.rates.cells[i] is rate and sample.time==end,'native_pressure_actual_endpoint_sample')
                    context=NativePressureQueryContext(role,sample.time,sample.source_binding,sample.interfaces,initial,start,end,policy)
                    pressure_contexts.append(context)
                    radii.append(pressure_radius(pair,states[i],rate.inverse,i,None,states=states,cell_rate=rate,
                        pressure_session=pressure_session,query_context=context,caller_guard=guard,
                        remaining_caller_wall=lambda:float(policy.maximum_wall_seconds)-(time.monotonic()-origin)))
                pressure=max(pressure,abs(exact(a.inverse.point.pressure_pa)-exact(b.inverse.point.pressure_pa))+sum(radii,F()))"""
assert old in s;s=s.replace(old,new)
s=s.replace('    return MixedTrialResult(status,reason,initial,start,end,candidate,', '    result=MixedTrialResult(status,reason,initial,start,end,candidate,')
s += "\n    if pressure_session is None:return result\n    return NativePressureMixedTrialResult(**{f.name:getattr(result,f.name) for f in fields(MixedTrialResult)},\n        pressure_session_before=session_before,pressure_session_after=pressure_session.snapshot(),\n        pressure_query_contexts=tuple(pressure_contexts))\n"
(p/'mass_wet_exact_stage.py').write_text(s)
