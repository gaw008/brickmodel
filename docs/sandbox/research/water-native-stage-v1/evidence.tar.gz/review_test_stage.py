"""Independent native opt-in negatives; analytic host, no native certificate."""
from fractions import Fraction as F
import pytest
from test_mass_wet_native_stage import setup,session,run

@pytest.mark.parametrize('radius',[F(-1),0.0])
def test_unusable_radius_rejects_after_recording_query(monkeypatch,radius):
    pair,initial=setup(monkeypatch)
    s,calls=session(monkeypatch,pair,radius=radius)
    result=run(pair,initial,s)
    assert result.status=='failed' and result.candidate_state is None
    assert result.evaluations_completed==9 and len(calls)==1
    assert len(result.pressure_session_after.attempts)==1
