from pathlib import Path
import sys,importlib.util,json,dataclasses
from fractions import Fraction as F
from pytest import MonkeyPatch
import sludge_sandbox
P=Path(__file__).parent
sludge_sandbox.__path__.insert(0,str(P));sys.path.insert(0,str(Path.cwd()/'tests/sandbox'))
from test_mass_wet_exact_stage import setup,fixture,policy
from sludge_sandbox import mass_wet_exact_stage as new
from sludge_sandbox.exact_event_clock import ExactEventTime as T
spec=importlib.util.spec_from_file_location('baseline_stage',P/'baseline_stage.py');old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
def norm(x):
 if dataclasses.is_dataclass(x):return {'type':type(x).__name__,'fields':{f.name:norm(getattr(x,f.name)) for f in dataclasses.fields(x) if f.name!='elapsed_seconds'}}
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return tuple(norm(v) for v in x)
 return x
with MonkeyPatch.context() as mp:
 pair,initial=setup(mp);results=[]
 for usefixture in (False,True):
  out=[]
  for module in (old,new):
   declaration=module.ManufacturedConstantLiquidFixture.capture(pair,volume_m3_mol=F(1.8e-5)) if usefixture else None
   pol=module.MixedStagePolicy(**dataclasses.asdict(policy()))
   out.append(module.try_step_doubling(pair,initial,start=T(F()),end=T(F(1,1000)),policy=pol,constant_liquid_fixture=declaration))
  assert norm(out[0])==norm(out[1]);results.append({'fixture':usefixture,'status':out[0].status,'full_nonwall_value_equal':True,'callbacks':out[0].evaluations_completed})
(P/'default-parity.json').write_text(json.dumps(results,indent=2)+'\n')
