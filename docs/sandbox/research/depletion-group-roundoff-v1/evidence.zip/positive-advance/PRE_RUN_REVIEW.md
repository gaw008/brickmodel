Root review: approved bounded execution. Reuses exact prior 4-cell case bytes,
rebuilds and compares entire initial conserved state, preserves physical fields
and original error tolerances. Changes only ordinary segment cap/duration and
resource ceilings. Uses actual operator evaluation for RK stages. Saves raw
integration result before checking completion. Runtime identity verified both
ends. Root supervisor imposes 60 seconds for build + all callbacks combined.
No candidate selection result is a preregistered success requirement: a tie
remaining is valid diagnostic evidence. Does not call the depletion integrator
or prove physical event-free evolution. No native run performed in this review.
