"""One ordinary RK segment: numerical positive stages, not event-free proof."""
import argparse
from dataclasses import replace
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import time
import traceback

HERE=Path(__file__).resolve().parent
PRIOR=Path('/private/tmp/brick-four-cell-candidate-probe-v1/attempt01')
WATER=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')


def save(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)


def require(ok,message):
    if not ok:raise AssertionError(message)


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def exact(value):return {'numerator':value.numerator,'denominator':value.denominator}


def selection(state,actual,operator,gate):
    li=operator.liquid_index;rates=actual.rates;rates.derivatives(state)
    options=[];unsupported=[]
    for i,mode in enumerate(operator.interfaces):
        n=F(float(state.amounts_mol[i,li]))
        net=F(float(rates.face_species_mol_s[i,li]))-F(float(rates.face_species_mol_s[i+1,li]))+F(float(rates.reaction_species_mol_s[i,li]))
        if mode=='existing_liquid' and n>0 and net<0:
            if actual.cell_transfers[i].rate_mol_s<=0:unsupported.append(i)
            options.append((n/-net,i,n,net))
    options.sort();gap=options[1][0]-options[0][0] if len(options)>1 else None
    return {'options':[{'cell':i,'time_ratio_s':exact(t),'time_ratio_float_s':float(t),
        'liquid_mol':exact(n),'net_liquid_mol_s':exact(net)} for t,i,n,net in options],
        'first_gap_s':None if gap is None else exact(gap),'original_gate_s':exact(gate),
        'unsupported_nonpositive_evaporation_cells':unsupported,
        'outcome':'unsupported_nonpositive_evaporation' if unsupported else
            'simultaneous_events_not_separated' if gap is not None and gap<=gate else
            'candidate_selectable' if options else 'no_candidate',
        'scope':'Instantaneous represented rate ratios, not physical root enclosures.'}


def observation(actual,encode):
    base=actual.base_evaluation
    return {'rates':encode(actual.rates),'cell_transfers':encode(actual.cell_transfers),
        'geometry':encode(base.geometry),'free':encode(base.free),
        'inverses':[{'target':encode(inv.target),'thermal_state':encode(inv.state.thermal_state),
            'skeleton_state':encode(inv.state.skeleton_state),'total_energy_j':inv.state.total_energy_j,
            'temperature_error_bound_k':inv.temperature_error_bound_k,
            'total_energy_residual_j':inv.total_energy_residual_j} for inv in base.total_inverses]}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    output=parser.parse_args().output;output.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();report={'status':'started','callback_attempts':0,'callback_completed':0,
        'callback_counts':{},'external_wall_limit_seconds':60,'script_sha256':sha(Path(__file__)),
        'qualification':'Ordinary numerical positive-stage advance only; no true event-free proof or depletion integration.'}
    save(output/'result.json',report)
    try:
        from sludge_sandbox.run_service import runtime_identity
        from sludge_sandbox.verification_case import read_case,build_case,encode
        from sludge_sandbox.integration import integrate
        report['runtime_before']=runtime_identity()
        require(len(report['runtime_before']['modules'])==66,'registered 66-module installed runtime')
        original=(PRIOR/'case.json').read_bytes();report['prior_case_sha256']=sha(PRIOR/'case.json')
        # Preserve exact case bytes and identity from the prior actual four-cell probe.
        (output/'case.json').write_bytes(original)
        definition=read_case(output/'case.json');case=definition.payload
        require(case['grid']['cells']==4 and case['grid']['parent_cells']==2,'prior four-cell case')
        built=build_case(definition,WATER);operator=built.operator;initial=built.initial
        require(len(initial.amounts_mol)==4 and len(initial.mechanical_stretches)==5,'four-cell mechanical state')
        save(output/'initial.json',encode(initial));save(output/'original-policy.json',encode(built.policy))
        require(encode(initial)==json.loads((PRIOR/'initial.json').read_text()),'exact prior initial state')
        cap=min(2**-14,built.policy.maximum_step_s)
        end=float(F(built.start_s)+F(2**-14))
        policy=replace(built.policy,initial_step_s=min(built.policy.initial_step_s,cap),
                       maximum_step_s=cap,maximum_steps=16,maximum_wall_seconds=40.)
        save(output/'actual-policy.json',encode(policy))
        report.update(start_s=built.start_s,end_s=end,case_sha256=definition.sha256)
        def evaluate(state,at,phase):
            counts=report['callback_counts'].setdefault(phase,{'attempts':0,'completed':0})
            counts['attempts']+=1;report['callback_attempts']+=1;save(output/'result.json',report)
            value=operator.evaluate(state,at)
            counts['completed']+=1;report['callback_completed']+=1;save(output/'result.json',report)
            return value
        first=evaluate(initial,built.start_s,'initial')
        save(output/'initial-observation.json',observation(first,encode))
        gate=F(case['numerics']['depletion']['time_absolute_s']);require(gate==F(1e-8),'original clock gate')
        save(output/'initial-selection.json',selection(initial,first,operator,gate))
        run=integrate(initial,lambda state,at:evaluate(state,at,'integration').rates,
                      start_s=built.start_s,end_s=end,policy=policy)
        save(output/'integration.json',encode(run))
        save(output/'final.json',encode(run.states[-1]))
        report.update(integration_status=run.status,integration_reason=run.reason,
                      accepted_steps=len(run.steps),final_time_s=run.times_s[-1])
        save(output/'result.json',report)
        require(run.status=='completed' and run.times_s[-1]==end,'ordinary segment completed')
        li=operator.liquid_index
        require(all(float(row[li])>0 for state in run.states for row in state.amounts_mol),'accepted liquid remains positive')
        final=evaluate(run.states[-1],run.times_s[-1],'final')
        save(output/'final-observation.json',observation(final,encode))
        save(output/'final-selection.json',selection(run.states[-1],final,operator,gate))
        report['status']='completed_probe'
    except BaseException as exc:
        report.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
    finally:
        try:
            from sludge_sandbox.run_service import runtime_identity
            report['runtime_after']=runtime_identity()
            require(report['runtime_before']==report['runtime_after'],'runtime changed')
            require((PRIOR/'case.json').read_bytes()==original==(output/'case.json').read_bytes(),'case bytes changed')
        except BaseException:
            report['integrity_error']=traceback.format_exc();report['status']='failed'
        report['elapsed_seconds']=time.monotonic()-started;save(output/'result.json',report)
    require(report['status']=='completed_probe',report.get('reason','probe failed'))


if __name__=='__main__':main()
