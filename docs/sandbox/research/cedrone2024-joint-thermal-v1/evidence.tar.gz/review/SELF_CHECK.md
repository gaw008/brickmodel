# Extraction self-check only

- Final script actually executed after the hue correction and same-bytes image decoding change: 12 targets, 11 readable, DSC575C unknown. No fitting, integration or EOS.
- Final script parses with Python ast. ruff, mypy, pylint and black were not on PATH; no installations attempted.
- Every asset recorded by source/SOURCE.json matched its byte count and SHA at the final read.
- The first actual color-screen output is preserved. Its original script/protocol were reconstructed from the edits, and both content hashes exactly match those embedded by that actual run. This is historical reconstruction, not a newly claimed old execution.
- Original embedded TG/DSC images were actually viewed; reported nominal pixel locations were checked against the curves. This is the extractor author's self-check, not the pending ROOT independent review.
