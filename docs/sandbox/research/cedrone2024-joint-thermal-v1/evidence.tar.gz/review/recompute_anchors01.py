"""One non-EOS extraction replay into a NEW review artifact; never run main()."""
from pathlib import Path
from fractions import Fraction as F
import csv,hashlib,importlib.util,json
from io import BytesIO
from PIL import Image, __version__ as pillow_version
W=Path('/private/tmp/cedrone2024-joint-thermal-v1')
OUT=W/'review'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
script=W/'extraction/extract_anchors.py'
spec=importlib.util.spec_from_file_location('reviewed_anchor_definitions',script)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=json.loads((W/'extraction/ANCHORS.json').read_text())
original_sha=sha(W/'extraction/ANCHORS.json')
results=[];axes={};checks={}
for panel,cfg in m.PANELS.items():
    p=W/'source'/cfg['file'];raw=p.read_bytes()
    checks[panel+'_image_identity']=hashlib.sha256(raw).hexdigest()==cfg['sha256']
    with Image.open(BytesIO(raw)) as opened:image=opened.convert('RGB')
    checks[panel+'_native_size']=image.size==cfg['size']
    xc=m.calibration(cfg['x_labels']);yc=m.calibration(cfg['y_labels'])
    checks[panel+'_all_vertex_constraints']=all(F(center)-2<=a*F(value)+b<=F(center)+2 for labels,vertices in ((cfg['x_labels'],xc),(cfg['y_labels'],yc)) for a,b in vertices for value,center in labels)
    checks[panel+'_orientation']=all(a>0 for a,b in xc) and all(a<0 for a,b in yc)
    axes[panel]={'x_labels':cfg['x_labels'],'y_labels':cfg['y_labels'],
        'x_affine_vertices':[[str(a),str(b)] for a,b in xc],
        'y_affine_vertices':[[str(a),str(b)] for a,b in yc],
        'nominal_x':[str(v) for v in m.nominal(xc)],'nominal_y':[str(v) for v in m.nominal(yc)],
        'native_image':cfg['file'],'native_image_sha256':cfg['sha256']}
    results.extend(m.read_anchor(panel,cfg,image,xc,yc,target) for target in cfg['targets'])
payload={'kind':'twelve_conditional_raster_anchor_readings_not_experimental_error',
    'script_sha256':sha(script),'protocol_sha256':sha(W/'PROTOCOL.md'),'Pillow_version':pillow_version,
    'pixel_coordinates':'zero-based centers in native embedded image; x right, y down',
    'analyst_label_center_half_width_px':str(m.LABEL_RADIUS),'analyst_curve_extent_padding_px':str(m.CURVE_RADIUS),
    'axes':axes,'readings':results}
# Normalizing tuples through JSON matches the actual saved representation.
payload=json.loads(json.dumps(payload))
checks['whole_recomputed_payload_matches']=payload==original
with (OUT/'ANCHORS_RECOMPUTED01.json').open('x') as f:json.dump(payload,f,ensure_ascii=False,indent=2);f.write('\n')
checks['original_anchor_bytes_preserved']=sha(W/'extraction/ANCHORS.json')==original_sha
checks['12_targets_11_readable_1_unknown']=len(results)==12 and sum(x['status']=='readable' for x in results)==11 and [(x['panel'],x['target_temperature_C']) for x in results if x['status']=='unknown']==[('DSC',575)]
checks['no_experimental_error_claim']=all(x['experimental_uncertainty'] is None for x in results)
checks['exact_envelope_and_nominal']=all(F(x['analyst_read_envelope_fraction'][0])<=F(x['nominal_value_fraction'])<=F(x['analyst_read_envelope_fraction'][1]) and x['nominal_value']==float(F(x['nominal_value_fraction'])) for x in results if x['status']=='readable')
checks['825_not_joint']=all(x['joint_TG_DSC_temperature_overlap']==(50<=x['target_temperature_C']<=600) for x in results)
rows=list(csv.DictReader((W/'extraction/ANCHORS.csv').open()))
checks['csv_all_12_match']=len(rows)==len(results) and all(c['panel']==r['panel'] and int(c['target_temperature_C'])==r['target_temperature_C'] and c['status']==r['status'] and c['unit']==r['value_unit'] and (r['status']=='unknown' or (float(c['nominal_value'])==r['nominal_value'] and F(c['analyst_lower_fraction'])==F(r['analyst_read_envelope_fraction'][0]) and F(c['analyst_upper_fraction'])==F(r['analyst_read_envelope_fraction'][1]))) for c,r in zip(rows,results))
source=json.loads((W/'source/SOURCE.json').read_text())
checks['all_declared_source_assets']=all((W/p).stat().st_size==v['bytes'] and sha(W/p)==v['sha256'] for p,v in source['assets'].items())
checks['initial_screen_history_bound']=all(sha(W/f'extraction/{file}')==json.loads((W/'extraction/INITIAL_COLOR_SCREEN.json').read_text())[key] for file,key in [('initial_color_screen_extractor.py','script_sha256'),('INITIAL_PROTOCOL.md','protocol_sha256')])
failed=[k for k,v in checks.items() if not v]
result={'status':'PASS' if not failed else 'FAIL','checks':checks,'failed':failed,'scope':'static math/visual review and exactly one deterministic extraction replay; no curve integration, fitting, EOS or expanded search','replay_is_not_independent_experimental_validation':True,'source_method_notes':'Original PDF pp4 and8-9 read: separate TG/DSC aliquots and flows, residual moisture, original per-sample units; no dry-basis conversion.','script_sha256':sha(script),'review_script_sha256':sha(Path(__file__)),'original_anchor_sha256':original_sha,'new_recomputed_sha256':sha(OUT/'ANCHORS_RECOMPUTED01.json')}
with (OUT/'CHECK01.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failed':failed},ensure_ascii=False))
raise SystemExit(bool(failed))
