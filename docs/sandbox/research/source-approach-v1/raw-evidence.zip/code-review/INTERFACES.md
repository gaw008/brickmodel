# Source positive approach: bounded interface review

Baseline `ee0ed24`. Read-only production review; no native EOS, installation or production edit. This report identifies existing interfaces and freezes two bounded probes, rather than approving code that is still being implemented.

## Reuse and guard requirements

1. `source_prefix_trial.evaluate_source_prefix_trial` saves actual `initial` and `euler_midpoint` captures before building the full prefix. A negative full-interval polynomial minimum raises `source_prefix_negative_inventory_minimum` with `trial.prefix is None`. After `trial.check()`, require these two exact roles/times, successful evaluations and original bindings, then rebuild `build_source_panel` using the captures and the original operator/energy/fixed-mass identities. A cancelled, exhausted, invalid predictor or failed midpoint must not be treated as permission to continue. Exact-zero boundary may instead retain a `numerical_boundary` prefix.
2. `order_source_panel_roots` considers every one of the 4N liquid/gas inventories. Zero initial remains unsupported; unresolved ordering remains unresolved. Its effective budget accepts 1..256, while `DepletionPolicy.maximum_refinements` only has a lower bound. Any effective 256 cap must be explicit while retaining the complete original policy.
3. Root ordering can finish at level zero with a selected root whose lower bracket is zero; a single-root case demonstrates this. Use `refine_first_root` under the remaining declared budget and retain its returned bracket evidence before multiplying a positive lower bound by the exact represented `safe_inventory_fraction`. Point roots need no refinement. `safe_inventory_fraction` must remain the original value in (0, 0.5), not an invented replacement.
4. Reuse `source_endpoint_comparison._copy_policy` and `_policy_binding`: the original strict record codec reconstructs and binds the complete nested `DepletionPolicy`, including optional pressure/ordered/nested-approach fields. Binding just the fraction and refinements would omit user constraints.
5. `ExactSourceColumn.breakpoints(start,end)` delegates to the real programmed column; its returned times are exact interior knots. Clip a proposed interval to the first relevant knot and original allowed horizon/step bound. The existing trial refuses an interior knot before any evaluation. A knot at the selected endpoint is permitted. Preserve original `IntegrationPolicy`, including minimum step; `integrate_exact` refuses a clipped interval below that minimum rather than loosening it. Exact semantic times must not be converted to display floats.
6. A fresh `evaluate_source_prefix_trial` at the selected endpoint must build its own initial/Euler midpoint/terminal/reference evaluations. The old midpoint belongs to the old interval and cannot be relabeled. One wrapper call may make 11 actual source callbacks in the uncomplicated case. Its returned failure and callback records must remain visible; successful root interpolation alone is not a successful new trial. Original endpoint comparison and conditional pressure checks do not authorize an event.

## Reproducible actual source fixture

`probe_actual_liquid_root.py` reuses `test_source_liquid_column.setup(monkeypatch,count=1)`, whose liquid response is an explicit manufactured seam. It initializes the actual storage with liquid `1e-6 mol`, gas `(.125,.25,1e-12) mol`, and U from `storage.evaluate(state,325.)`; no adapter or evaluated record is fabricated.

Initial evaporation is `7.997816447578959e-08 mol/s`. The exact research duration is `(3/2)*F(N)/F(phase) = 14167099448608935/755372406563809 s` (18.755119098214227 s). The original two-callback trial has a valid midpoint with liquid `2.4999999999999994e-7 mol` and fails only the full-prefix minimum. Its reconstructed order selects `('liquid',0,0)` at level zero with lower=0. One further refinement and fraction 1/4 yield 2.3443898872767783 s. One new trial succeeds with 11 callbacks and direct D=`8.546299150598493e-06`.

`ACTUAL_FIXTURE_RESULT.json` records all policy fields and counts: 1 research initial adapter evaluation + 2 failed-trial evaluations + 11 selected-trial evaluations = 14. Initial-state energy setup also performs two storage forward evaluations (one inside the existing setup and one for the new inventory). All use the manufactured liquid seam; native EOS calls are zero. This probe did not construct a DepletionPolicy; 1/4 is an explicit probe parameter. The new production interface must copy and bind the real policy.

The original successful probe was not instrumented with a wall timer; its total elapsed time is honestly recorded as null, not reconstructed from asynchronous shell yields. It was not rerun merely to obtain timing. Attempt 01, which retained the existing larger vapor inventory and therefore condensed instead of evaporating, is preserved as the actual failed fixture search.

## Frozen native no-root case

`probe_saved_no_roots.py` verifies the original `7c0907af...` input and fixed decoder hashes, decodes only the original first/midpoint records, rechecks their saved bindings, and reconstructs the panel. Seven physical entry points are forbidden. All 12 inventory polynomials are excluded from roots on [0,1/16384 s]; status is `no_roots`, with zero source evaluations or provider constructions. Recorded elapsed time is 0.1698362500173971 s.

This permits checking the ordinary proposal path: unchanged interval when it obeys the original bounds, no selected root, no event time and no event admission. It does not establish execution of a new approach trial. If a proposal API only accepts a live SourcePrefixTrial, do not manufacture its adapter for this replay; use the existing lower-level saved-panel/order interface and label that narrower coverage. The existing saved trial's numerical success remains earlier evidence.

`PROBE_FREEZE.json` pins the scripts, retained outcomes and metadata. No fixed-h rerun or new real-water EOS was performed.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — existing interfaces and bounded fixture are suitable for the proposed stage. New implementation remains subject to its own final code review.
