from dataclasses import replace
from fractions import Fraction as F
from pathlib import Path
import sys, json
sys.path[:0]=[str(Path.cwd()/'src'),str(Path.cwd()/'tests/sandbox')]
import pytest
from test_source_liquid_column import setup
from test_source_prefix_trial import POLICY
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.source_prefix_trial import evaluate_source_prefix_trial
from sludge_sandbox.source_net_panel import SavedSourceSample,build_source_panel
from sludge_sandbox.source_net_roots import order_source_panel_roots,refine_first_root

with pytest.MonkeyPatch.context() as mp:
    column,states=setup(mp,count=1)
    storage=column.storages[0]
    state=storage.state(1e-6,states[0].gas_amounts_mol,0.)
    state=replace(state,internal_energy_j=storage.evaluate(state,325.).total_internal_energy_j)
    adapter=ExactSourceColumn(column);initial=adapter.pack((state,))
    first=adapter.evaluate(initial,T(F()))
    dn,_=first.rates.derivatives(initial)
    assert dn[0,0]<0
    h=F(3,2)*F(float(initial.amounts_mol[0,0]))/-F(float(dn[0,0]))
    policy=replace(POLICY,initial_step_s=float(h),maximum_step_s=float(h),minimum_step_s=2**-30)
    trial=evaluate_source_prefix_trial(adapter,initial,start=T(F()),end=T(h),integration_policy=policy,maximum_callbacks=16)
    trial.check()
    assert len(trial.captures)==2 and trial.prefix is None
    assert all(c.failure is None and c.binding is not None for c in trial.captures)
    first,middle=trial.captures
    panel=build_source_panel(SavedSourceSample(first.state,first.evaluation,first.role),SavedSourceSample(middle.state,middle.evaluation,middle.role),trial.end,operator_identity=trial.operator_identity,energy_identity=trial.energy_identity,fixed_dry_mass_kg=trial.fixed_dry_mass_kg)
    order=order_source_panel_roots(panel,maximum_refinements=32);order.check()
    assert order.order.earliest_labels==(('liquid',0,0),)
    root=next(r for r in order.order.roots if r.polynomial.family=='liquid')
    original_lower=root.lower
    while root.lower<=0:
        root=refine_first_root(root)
    selected=F(1,4)*root.lower
    second=evaluate_source_prefix_trial(adapter,initial,start=T(F()),end=T(selected),integration_policy=policy,maximum_callbacks=16)
    second.check()
    assert second.status=='validated_positive_numerical_trial',second.reason
    print(json.dumps(dict(scope='actual_source_adapter_with_existing_manufactured_water_fixture_no_native_EOS',liquid_initial=1e-6,phase_initial=-float(dn[0,0]),duration=str(h),duration_s=float(h),original_status=trial.status,original_reason=trial.reason,original_callbacks=len(trial.captures),midpoint_liquid=float(middle.state.amounts_mol[0,0]),root_status=order.order.status,root_order_level=order.order.refinement_level,original_root_lower=str(original_lower),root_refinements=root.refinements,selected_s=float(selected),selected_callbacks=len(second.captures),selected_status=second.status,selected_discrepancy=second.discrepancy),indent=2))
