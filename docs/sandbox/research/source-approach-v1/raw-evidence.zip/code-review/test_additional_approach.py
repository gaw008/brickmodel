from dataclasses import replace
import pytest
from test_source_approach import actual as original_fixture
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.integration import DomainExit
from sludge_sandbox.source_prefix_trial import evaluate_source_prefix_trial
from sludge_sandbox.source_approach import propose_source_approach,evaluate_source_approach,SourceApproachAssessmentError

@pytest.fixture(scope='module')
def actual():
    generator=original_fixture.__wrapped__()
    value=next(generator)
    try:yield value
    finally:generator.close()

def test_recovered_reference_rejection_stays_usable(actual,monkeypatch):
    seed,policy=actual;proposal=propose_source_approach(seed,event_policy=policy)
    original=ExactSourceColumn.evaluate;calls=[]
    def observe(self,state,when):
        calls.append(when)
        if len(calls)==6:raise DomainExit('one_recoverable_reference_attempt')
        return original(self,state,when)
    monkeypatch.setattr(ExactSourceColumn,'evaluate',observe)
    result=evaluate_source_approach(proposal,maximum_callbacks=32)
    assert result.status=='validated_positive_numerical_approach',result.reason
    assert len(calls)==result.new_evaluations==20
    assert result.trial.reference.rejected_trials==1
    assert result.trial.captures[5].failure_kind=='DomainExit'
    result.check()

def test_original_integration_policy_mutation_retains_actual_completed_trial(actual,monkeypatch):
    seed,policy=actual;proposal=propose_source_approach(seed,event_policy=policy)
    original=ExactSourceColumn.evaluate;calls=[];saved=seed.policy.maximum_wall_seconds
    def mutate(self,state,when):
        calls.append(when)
        if len(calls)==1:object.__setattr__(seed.policy,'maximum_wall_seconds',saved+1)
        return original(self,state,when)
    monkeypatch.setattr(ExactSourceColumn,'evaluate',mutate)
    try:
        with pytest.raises(SourceApproachAssessmentError) as caught:
            evaluate_source_approach(proposal,maximum_callbacks=16)
        error=caught.value
        assert error.stage=='result_check'
        assert error.trial.status=='validated_positive_numerical_trial'
        assert len(error.trial.captures)==len(calls)==11
        assert error.comparison is not None and error.pressure is not None
        assert 'trial_original_policy_binding' in str(error.__cause__)
        error.trial.check()
    finally:object.__setattr__(seed.policy,'maximum_wall_seconds',saved)

def test_cancelled_seed_with_two_retained_valid_samples_cannot_restart(actual,monkeypatch):
    seed,policy=actual;original=ExactSourceColumn.evaluate;calls=[]
    def observe(self,state,when):
        calls.append(when)
        return original(self,state,when)
    monkeypatch.setattr(ExactSourceColumn,'evaluate',observe)
    stopped=evaluate_source_prefix_trial(seed.adapter,seed.initial,start=seed.start,end=seed.end,
        integration_policy=seed.policy,maximum_callbacks=16,cancel=lambda:len(calls)>=2)
    assert stopped.status=='cancelled' and len(stopped.captures)==2
    assert all(c.evaluation is not None and c.binding is not None for c in stopped.captures)
    before=len(calls);proposal=propose_source_approach(stopped,event_policy=policy)
    result=evaluate_source_approach(proposal,maximum_callbacks=16)
    assert result.status=='not_evaluated' and result.new_evaluations==0 and len(calls)==before
    assert proposal.status=='stopped_seed_requires_explicit_restart'
    result.check()
