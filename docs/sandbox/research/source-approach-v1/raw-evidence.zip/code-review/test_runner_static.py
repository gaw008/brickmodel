from dataclasses import replace
from fractions import Fraction as F
from pathlib import Path
import ast,hashlib,importlib.util,json,signal
import pytest
from sludge_sandbox._heos_kernel import HEOSCandidate
from sludge_sandbox.integration import IntegrationPolicy
from sludge_sandbox.depletion_roundoff import DepletionRoundoffPolicy
from sludge_sandbox.depletion_integration import DepletionPolicy
from sludge_sandbox.source_endpoint_comparison import _copy_policy,_policy_binding
from test_depletion_integration import policies
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
RUNNER=Path('/private/tmp/brick-source-approach-v1/root/run_native.py')

def imported(path):
    spec=importlib.util.spec_from_file_location('review_'+path.parent.name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def test_passive_import_and_policy_field_equivalence(monkeypatch):
    monkeypatch.setattr(HEOSCandidate,'__init__',lambda *a,**kw:pytest.fail('import requested native constructor'))
    module=imported(RUNNER)
    for name,expected in module.HELPERS.items():
        p=ROOT/'docs/sandbox/research'/name
        assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
        imported(p)
    calls={n.func.id:n for n in ast.walk(ast.parse(RUNNER.read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('IntegrationPolicy','DepletionRoundoffPolicy','DepletionPolicy')}
    env=dict(F=F,horizon=F(1,1024),IntegrationPolicy=IntegrationPolicy,DepletionRoundoffPolicy=DepletionRoundoffPolicy,DepletionPolicy=DepletionPolicy)
    for name in ('IntegrationPolicy','DepletionRoundoffPolicy','DepletionPolicy'):
        value=eval(compile(ast.Expression(calls[name]),str(RUNNER),'eval'),env)
        env[{'IntegrationPolicy':'policy','DepletionRoundoffPolicy':'rounding','DepletionPolicy':'event'}[name]]=value
    assert env['rounding']==policies()[1].roundoff_policy
    assert env['event']==replace(policies()[1],maximum_refinements=32)
    assert _policy_binding(_copy_policy(env['event']))==_policy_binding(env['event'])
    assert env['policy']==IntegrationPolicy(1/1024,1/1024,2**-30,1e-8,1e-7,1e-3,1.,1e5,4,4,180.)
    assert module.CALLBACK_CAP==16 and module.TOTAL_CALLBACK_CAP==33 and module.OUTER_SECONDS==210.

@pytest.mark.parametrize("timeout",[False,True])
def test_second_provider_failure_keeps_first_completed_constructor(monkeypatch,timeout):
    import sludge_sandbox.water_properties as water
    import sludge_sandbox.ideal_water_vapor as vapor
    started=[];finished=[]
    def constructor(self,*a,**kw):
        started.append(self)
        if len(started)==2:
            if timeout:signal.getsignal(signal.SIGALRM)(signal.SIGALRM,None)
            raise RuntimeError('injected_second_constructor_failure')
        finished.append(self)
    def loader(directory,*,backend,backend_manifest):
        assert backend=='heos'
        return HEOSCandidate(backend_manifest,directory)
    monkeypatch.setattr(HEOSCandidate,'__init__',constructor)
    monkeypatch.setattr(water,'load_water_properties',loader)
    monkeypatch.setattr(vapor,'load_water_properties',loader)
    out=Path('/private/tmp/brick-source-approach-v1/code-review')/('runner-constructor-timeout.json' if timeout else 'runner-constructor-failure.json')
    module=imported(RUNNER)
    assert module.run(ROOT,out)==1
    result=json.loads(out.read_text())
    assert result['status']==('resource_limit' if timeout else 'failed')
    assert result['exception_type']==('TimeoutError' if timeout else 'RuntimeError')
    assert result['exception']==('outer_210s_budget_exceeded' if timeout else 'injected_second_constructor_failure')
    assert len(started)==2 and len(finished)==1 and not result['captures']
    assert result['backend_constructors_started']==2
    assert result['backend_constructors_completed']==result['constructor_reference_anchor_checks']==1
    assert result['initial_energy_evaluations_attempted']==0
