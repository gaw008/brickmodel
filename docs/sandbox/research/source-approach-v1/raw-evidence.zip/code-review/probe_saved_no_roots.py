from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
import sys,importlib.util,hashlib,json,time
repo=Path.cwd();sys.path.insert(0,str(repo/'src'))
t0=time.monotonic()
path=repo/'docs/sandbox/research/source-net-panel-v1/replay_native.py'
assert hashlib.sha256(path.read_bytes()).hexdigest()=='0b7b12500a0ad2bcce7ae69c4d539efe86b839212072a28d9ff23b8d92e94df1'
spec=importlib.util.spec_from_file_location('frozen_decoder',path);d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
raw=(repo/'docs/sandbox/research/source-prefix-trial-v1/native-result.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='7c0907af104450ffc42cf142e3e3aebefaf21c597eb6806f09b7bdbe6d6d3505'
trial=json.loads(raw)['trial'];cs=[x['fields'] for x in trial['captures'][:2]]
assert [c['role'] for c in cs]==['initial','euler_midpoint']
assert all(c['failure'] is None and c['binding'] is not None for c in cs)
from sludge_sandbox.source_net_panel import SavedSourceSample,build_source_panel
from sludge_sandbox.source_net_roots import order_source_panel_roots
with ExitStack() as stack:
    for cls,name in ((d.ExactSourceColumn,'evaluate'),(d.SourceWetStorage,'invert'),(d.SourceWetStorage,'evaluate'),(d.RigidStorage,'evaluate_at_temperature'),(d.WaterProperties,'state_tp'),(d.HEOSWaterProperties,'state_tp'),(d.WaterChemicalPotential,'equilibrium_at_liquid_tp')):
        stack.enter_context(patch.object(cls,name,d.reject_physics))
    samples=tuple(SavedSourceSample(d.decode(c['state']),d.decode(c['evaluation']),c['role']) for c in cs)
    panel=build_source_panel(*samples,d.decode(trial['end']),operator_identity=d.decode(trial['operator_identity']),energy_identity=d.decode(trial['energy_identity']),fixed_dry_mass_kg=d.decode(trial['fixed_dry_mass_kg']))
    assert panel.sample_bindings[:2]==tuple(c['binding'] for c in cs)
    order=order_source_panel_roots(panel,maximum_refinements=32);order.check()
    assert order.order.status=='no_roots' and len(order.order.exclusions)==12 and not order.order.roots
    print(json.dumps(dict(status='saved_panel_no_roots',inventories=12,root_count=0,start=str(order.start.seconds),upper=str(order.upper.seconds),source_evaluations=0,constructors=0,elapsed_seconds=time.monotonic()-t0,scope='ordinary_planning_only_no_new_trial_no_event_advance'),indent=2))
