# Premature identity-check invocation

The first check_install.py invocation was made before installed pytest session91364 had
written installed.xml. It exited1 with FileNotFoundError for that file after checking
package bytes. This was orchestration error, not a test/package failure. No installation
or tests were restarted. After session91364 terminal0 and its actual XML/log reported
135 passed76.62s, the same identity check was invoked again and saved separately.
