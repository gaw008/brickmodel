"""Independent saved approach audit using stdlib and prior independent algebra."""
from fractions import Fraction as F
from pathlib import Path
import runpy,json,hashlib,time,math
OUT=Path(__file__).parent;P=Path('/private/tmp/brick-source-approach-v1/root/native-result.json')
HLP=Path('/private/tmp/brick-source-prefix-trial-v1/physics/native-review/audit.py')
m=runpy.run_path(str(HLP));dec=m['decode'];euler=m['euler'];heun=m['heun'];norm=m['normalized'];flat=m['flat'];fsum=m['fsum'];ck0=m['ck']
count=0
def ck(x,label):
 global count
 count+=1
 if not x:raise AssertionError(label)
def val(p,t):return p['initial']+p['linear']*t+p['quadratic']*t*t
def minimum(p,H):
 ts=[F(),H]
 if p['quadratic']>0 and 0 < -p['linear']/(2*p['quadratic']) < H:ts.append(-p['linear']/(2*p['quadratic']))
 return min((val(p,t),t) for t in ts)
start=time.monotonic();sha=hashlib.sha256(P.read_bytes()).hexdigest();ck(sha=='6f6c32330f9bd3159186705345fbe35bce0729e592f006611c9707082f068ca2','native hash')
r=dec(json.loads(P.read_text()));seed=r['seed'];proposal=r['proposal'];trial=r['trial'];initial=r['initial'];caps=r['captures'];choice=proposal['choice'];order=choice['order'];panel=proposal['roots']['panel'];H=r['horizon'];h=trial['end']['seconds']
ck(r['status']=='completed' and len(caps)==14,'completed actual14')
ck(r['constructor_reference_anchor_checks']==4 and r['initial_energy_evaluations_attempted']==1,'declared construct/initialU counts')
ck(r['wall_seconds']<r['outer_seconds']==210 and trial['elapsed_seconds']<trial['policy']['maximum_wall_seconds']==180,'wall resources')
ck(caps[0]['phase']=='initial_rate_probe' and caps[0]['packed_input']==initial,'separate actual initial phase probe')
phase=caps[0]['evaluation']['source_evaluation']['cells'][0]['phase']['phase_water_mol_s'];ck(phase==r['initial_phase_water_mol_s'] and H==F(3,2)*F(initial['amounts_mol'][0][0])/F(phase),'actual chosen H')
for actual,stored in zip(caps[1:],seed['captures']+trial['captures']):
 ck(actual['packed_input']==stored['state'] and actual['time']==stored['time'] and actual['evaluation']==stored['evaluation'],'outer actual capture match')
 ev=stored['evaluation'];ck(ev['time']==stored['time'] and ev['operator_identity']==seed['operator_identity']==trial['operator_identity'],'operator time identity');ck(ev['source_states'][0]['solid_mass_kg']==[.2] and ev['material_qualified'] is False,'fixed mass/unqualified')
ck(seed['status']=='numerical_failure' and seed['reason']=='source_prefix_negative_inventory_minimum' and seed['prefix'] is None and len(seed['captures'])==2,'original seed failure retained')
ck(seed['predictor']==euler(initial,seed['captures'][0],H/2)==seed['captures'][1]['state'],'actual seed Euler predictor')
ck(panel['first']['state']==initial and panel['interior']['state']==seed['predictor'] and panel['first']['evaluation']==seed['captures'][0]['evaluation'] and panel['interior']['evaluation']==seed['captures'][1]['evaluation'],'root panel actual observations')
# Derive four polynomials from raw common rates, not saved coefficients.
a,b=(x['evaluation']['rates'] for x in seed['captures'])
for j,p in enumerate(order['polynomials']):
 def rate(r):return F(r['face_species_mol_s'][0][j])-F(r['face_species_mol_s'][1][j])+F(r['reaction_species_mol_s'][0][j])
 ra,rb=rate(a),rate(b)
 ck((p['family'],p['cell'],p['index'])==('liquid' if j==0 else 'gas',0,j),'all4 labels')
 ck((p['initial'],p['linear'],p['quadratic'])==(F(initial['amounts_mol'][0][j]),ra,(rb-ra)/H),'raw source quadratic')
ck(len(order['polynomials'])==4 and order['complete'] and order['status']=='ordered' and order['earliest_labels']==[['liquid',0,0]],'all competitor order')
p=order['polynomials'][0];ck(val(p,F())>0 and val(p,H)<0 and p['linear']+2*p['quadratic']*H<0,'unique descending liquid root on span')
for q,excluded in zip(order['polynomials'][1:],order['exclusions']):
 mn,at=minimum(q,H);ck(excluded['polynomial']==q and mn==excluded['minimum']>0 and at==excluded['minimum_time'],'gas no-root certificate')
lo,hi=F(),H;rounds=0
while lo<=0:
 mid=(lo+hi)/2
 if val(p,mid)>0:lo=mid
 else:hi=mid
 rounds+=1
sel=choice['selected_root'];ck(sel['lower']==lo and sel['upper']==hi and choice['additional_refinement_rounds']==rounds,'independent selected bisection')
ck(order['refinement_level']==0 and rounds+order['refinement_level']<=order['maximum_refinements']==min(256,proposal['event_policy']['maximum_refinements']),'shared budget')
desired=min(F(proposal['event_policy']['safe_inventory_fraction'])*lo,F(seed['policy']['maximum_step_s']),H);d=float(desired)
if F(d)>desired:d=math.nextafter(d,-math.inf)
ck(choice['desired_duration_s']==desired and choice['duration_s']==h==F(d) and F(seed['policy']['minimum_step_s'])<=h<lo,'downward safe interval original caps')
for q,row in zip(order['polynomials'],choice['minima']):
 mn,at=minimum(q,h);ck(row==[q['family'],q['cell'],q['index'],mn,at] and mn>0,'all proposal minima')
ck(trial['initial']==initial and trial['policy']==seed['policy'] and trial['status']=='validated_positive_numerical_trial','fresh same original controls')
new=trial['captures'];ck(len(new)==11 and new[1]['time']['seconds']==h/2!=H/2 and new[1]['state']==euler(initial,new[0],h/2),'fresh actual midpoint')
ck(new[2]['state']==trial['prefix']['raw_state'] and new[2]['time']['seconds']==h,'actual new endpoint')
# N1 closed prefix: exact phase opposite, no face exchange or U source.
pref=trial['prefix'];midrates=new[1]['evaluation']['rates'];phaseI=h*F(midrates['reaction_species_mol_s'][0][3]);rn=[-float(phaseI),0.,0.,float(phaseI)]
ck(pref['ledger']['reaction_species_mol']==[rn] and all(v==0 for v in flat(pref['ledger']['face_species_mol'])+pref['ledger']['face_energy_j']),'prefix paired phase/closed faces')
for j in range(4):
 before=F(initial['amounts_mol'][0][j]);exact=(-phaseI if j==0 else phaseI if j==3 else F());actual=F(pref['raw_state']['amounts_mol'][0][j]);ck(actual==F(float(before+F(rn[j]))) and actual-before-exact==pref['full_residual_mol'][j],'prefix state and full residual')
ck(pref['raw_state']['internal_energy_j']==initial['internal_energy_j'],'prefix closed U')
# Independently reconstruct actual one-step reference from all8 callbacks.
ref=trial['reference'];rc=new[3:];ck(len(rc)==8 and ref['status']=='completed' and ref['rejected_trials']==0 and len(ref['steps'])==1,'actual reference structure')
ck(rc[0]['state']==initial and rc[0]['time']['seconds']==0,'ref initial check')
full,_=heun(initial,rc[1],rc[2],h);half,left=heun(initial,rc[3],rc[4],h/2);ck(rc[5]['state']==half,'ref half input');fine,right=heun(half,rc[5],rc[6],h/2)
ck(rc[7]['state']==fine==ref['states'][-1] and rc[7]['time']['seconds']==h,'ref actual accepted endpoint')
fields=[[fsum(x,y) for x,y in zip(a,b)] for a,b in zip(left,right)];ledger=ref['steps'][0]
for key,expected in zip(m['LEDGER'],fields):ck(flat(ledger[key])==expected,'reference both rounding levels ledger')
referror=norm(fine,full,trial['policy'])/3;ck(referror<=1,'original ref estimator');D=norm(pref['raw_state'],fine,trial['policy']);ck(D==trial['discrepancy']<=1,'direct D no/3')
water=lambda s:F(s['amounts_mol'][0][0])+F(s['amounts_mol'][0][3]);ck(fine['internal_energy_j']==initial['internal_energy_j'],'reference closed U');waterres=water(fine)-water(initial);ck(abs(waterres)<=2*F(trial['policy']['amount_absolute_tolerance_mol']),'reference total water represented residual')
# Independent original per-cell N/U/T/reported-P gates from actual two endpoints.
comp=r['comparison'];diff=comp['differences'];event=comp['event_policy'];A=new[2];B=new[-1]
nd=[abs(F(x)-F(y)) for x,y in zip(A['state']['amounts_mol'][0],B['state']['amounts_mol'][0])];ud=abs(F(A['state']['internal_energy_j'][0])-F(B['state']['internal_energy_j'][0]));tp=[]
for c in (A,B):
 inv=c['evaluation']['source_evaluation']['cells'][0]['inverse'];point=inv['point'];mech=point['fluid']['mechanical'];tp.append(list(map(F,(mech['temperature_k'],inv['temperature_error_bound_k'],mech['pressure_pa'],point['pressure_error_pa']))))
x,y=tp;tb=abs(x[0]-y[0])+x[1]+y[1];pb=abs(x[2]-y[2])+x[3]+y[3]
ck(diff['amount_differences_mol']==[nd] and diff['energy_differences_j']==[ud] and diff['temperature_bounds_k']==[tb] and diff['reported_pressure_bounds_pa']==[pb],'actual endpoint differences')
gates=[max(nd)<=F(event['amount_absolute_mol']),ud<=F(event['energy_absolute_j']),tb<=F(event['temperature_absolute_k']),pb<=F(event['pressure_absolute_pa'])];ck(comp['gates']==gates==[True,True,True,False],'original per-quantity gates')
radii=[]
for endpoint,c in zip(r['pressure']['endpoint_bounds'][0],(A,B)):
 inv=c['evaluation']['source_evaluation']['cells'][0]['inverse'];point=inv['point'];mech=point['fluid']['mechanical'];env=point['fluid']['envelope'];co=endpoint['continuation']
 nl=F(c['state']['amounts_mol'][0][0]);ng=sum(map(F,c['state']['amounts_mol'][0][1:]),F());R=F(mech['gas_constant_j_mol_k']);bu=F(env['liquid_abs_du_dp_bound_j_mol_pa']);T=F(mech['temperature_k']);et=F(inv['temperature_error_bound_k']);P0=F(mech['pressure_pa']);ep=F(point['pressure_error_pa'])
 ck(co['inputs']==[nl,ng,R,bu,T,et,P0,ep],'conditional pressure actual inputs')
 tmin,tmax=co['temperature_domain_k'];pmin,pmax=co['pressure_domain_pa'];L=pmax/tmin*(1+nl*bu*pmax/(ng*R*tmin));globalrad=ep+L*et;L2=(P0+globalrad)/(T-et)*(1+nl*bu*(P0+globalrad)/(ng*R*(T-et)));rad=ep+L2*et
 ck(co['global_slope_pa_k']==L and co['global_radius_pa']==globalrad and co['radius_pa']==rad and co['slope_pa_k']==L2 and pmin<P0-globalrad<P0+globalrad<pmax,'independent conditional pressure continuation');radii.append(rad)
ck(abs(tp[0][2]-tp[1][2])+sum(radii,F())==r['pressure']['maximum_conditional_bound_pa'],'independent conditional pair bound')
ck(comp['event_time_gate']=='not_evaluated' and comp['full_inverse_pressure_gate']=='unresolved','event and source-pressure scopes')
for j in range(4):
 delta=F(ledger['face_species_mol'][0][j])-F(ledger['face_species_mol'][1][j])+F(ledger['reaction_species_mol'][0][j]);res=F(fine['amounts_mol'][0][j])-F(initial['amounts_mol'][0][j])-delta
 ck(abs(res)<=F(trial['policy']['amount_absolute_tolerance_mol']),'original per-species reference ledger gate')
ck(ledger['reaction_species_mol'][0][0]==-ledger['reaction_species_mol'][0][3],'reference phase pair cancels')
ck(r['pressure']['conditional_gate'] is False and r['pressure']['maximum_conditional_bound_pa']>F(event['pressure_absolute_pa']),'conditional P fails original gate')
ck(r['event_admitted'] is r['material_qualified'] is comp['event_admitted'] is r['pressure']['event_admitted'] is r['pressure']['source_certified'] is False,'no event/material/source certification')
result={'status':'passed','checks':count,'elapsed_s':time.monotonic()-start,'native_sha256':sha,'H_s':float(H),'h_s':float(h),'seed_liquid_initial':initial['amounts_mol'][0][0],'new_liquid_terminal':pref['raw_state']['amounts_mol'][0][0],'new_source_callbacks':len(new),'all_source_callbacks':len(caps),'ref_error':referror,'direct_D':D,'N_difference_max':float(max(nd)),'U_difference':float(ud),'T_bound_K':float(tb),'reported_P_bound_Pa':float(pb),'conditional_P_bound_Pa':float(r['pressure']['maximum_conditional_bound_pa']),'reference_water_residual_mol':float(waterres),'gates':gates,'scope':'Saved N1 closed phase-transfer approach only; no liquid drainage, new EOS or event admission','independent_helper_sha256':hashlib.sha256(HLP.read_bytes()).hexdigest()}
OUT.joinpath('saved-audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
