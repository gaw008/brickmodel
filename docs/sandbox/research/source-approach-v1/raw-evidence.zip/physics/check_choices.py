"""Independent exact cases and budget reconstruction; no EOS."""
from fractions import Fraction as F
from dataclasses import replace
from pathlib import Path
import math,json,hashlib,time,signal
from sludge_sandbox.mass_wet_exact_stage import InventoryPolynomial
from sludge_sandbox.source_net_roots import order_inventory_roots
from sludge_sandbox.source_approach import choose_positive_approach
SOURCE=Path('src/sludge_sandbox/source_approach.py');OUT=Path(__file__).parent;sha=lambda:hashlib.sha256(SOURCE.read_bytes()).hexdigest();before=sha();count=0
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('independent10s')));signal.alarm(10)
def ck(v,label):
 global count
 count+=1
 if not v:raise AssertionError(label)
def pol(n,r=0,q=0,i=0,j=0):return InventoryPolynomial('liquid' if j==0 else 'gas',i,j,F(n),F(r),F(q))
def all12(changes):return tuple(changes.get((i,j),pol(2,0,0,i,j)) for i in range(3) for j in range(4))
def check(changes,status,*,budget=32,H=F(1),f=F(1,4),minimum=F(1,2**30),maximum=None):
 order=order_inventory_roots(all12(changes),H,maximum_refinements=budget)
 out=choose_positive_approach(order,safe_fraction=f,minimum_step_s=minimum,maximum_step_s=H if maximum is None else maximum,horizon_s=H)
 ck(out.status==status,'status '+status);out.check();ck(len(out.order.polynomials)==12,'all12 competitors');ck(out.order.refinement_level+out.additional_refinement_rounds<=budget,'shared budget')
 if status=='positive_numerical_proposal':
  desired=min(f*out.selected_root.lower,out.maximum_step_s,H);expected=float(desired)
  if F(expected)>desired:expected=math.nextafter(expected,-math.inf)
  ck(out.desired_duration_s==desired and out.duration_s==F(expected),'independent downward binary duration')
  for p,row in zip(out.order.polynomials,out.minima):
   pts=[F(),out.duration_s]
   if p.quadratic>0 and 0<-p.linear/(2*p.quadratic)<out.duration_s:pts.append(-p.linear/(2*p.quadratic))
   v,t=min((p.initial+p.linear*x+p.quadratic*x*x,x) for x in pts)
   ck(row==(p.family,p.cell,p.index,v,t) and v>0,'independent all12 minima')
 return out
start=time.monotonic()
check({},'no_roots_use_ordinary_integrator')
liquid=pol(1,-2)
x=check({(0,0):liquid},'positive_numerical_proposal');ck(x.selected_root.lower==F(1,2) and x.duration_s==F(1,8),'factored linear exact proposal')
check({(0,0):liquid,(2,1):pol(1,-4,i=2,j=1)},'gas_first')
check({(0,0):liquid,(2,1):pol(2,-4,i=2,j=1)},'competing_first_roots')
check({(0,0):pol(1,-2,1)},'tangent_not_depletion')
check({(1,3):pol(0,1,i=1,j=3)},'unsupported_zero_initial')
check({(0,0):liquid},'approach_below_original_minimum_step',minimum=F(1,4))
check({(0,0):liquid},'positive_numerical_proposal',minimum=F(1,8))
check({(0,0):pol(3,-8,4)},'positive_numerical_proposal',H=F(3,2))
check({(0,0):pol(1,1,-2)},'positive_numerical_proposal',H=F(2))
# Independent exact branch-bisection history determines total rounds.
ps={(0,0):pol(F(1,10000),-1,1),(0,1):pol(F(3,16),-1,1,j=1)}
x=check(ps,'positive_root_lower_bound_unresolved',budget=3)
ck(x.order.refinement_level==2 and x.additional_refinement_rounds==1 and x.selected_root.lower==0 and x.selected_root.upper==F(1,16),'budget reset counterexample')
y=check(ps,'positive_numerical_proposal',budget=16)
lo,hi=F(),F(1,2);rounds=0
while lo==0:
 mid=(lo+hi)/2;v=F(1,10000)-mid+mid*mid
 if v>0:lo=mid
 else:hi=mid
 rounds+=1
ck(y.selected_root.lower==lo and y.selected_root.upper==hi,'independent bisection first positive lower')
ck(y.order.refinement_level+y.additional_refinement_rounds==rounds,'same pooled rounds')
for bad in (replace(y,duration_s=F(1)),replace(y,additional_refinement_rounds=0),replace(y,minima=())):
 try:bad.check()
 except ValueError:ck(True,'tamper rejected')
 else:raise AssertionError('tamper accepted')
ck(sha()==before,'frozen during check')
result={'status':'passed','checks':count,'elapsed_s':time.monotonic()-start,'source_sha256':before,'shared_budget_counterexample':{'ordering':x.order.refinement_level,'additional':x.additional_refinement_rounds,'remaining_lower':str(x.selected_root.lower)},'positive_lower_total_rounds':rounds,'scope':'Independent exact manufactured polynomial choices and retained arithmetic; no EOS or new actual-host trial; no event/material certification'}
(OUT/'CHOICES_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));signal.alarm(0)
