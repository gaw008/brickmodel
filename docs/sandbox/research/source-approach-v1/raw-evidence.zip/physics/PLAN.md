# Independent bounded verification once API is ready

Budget <=10 s pure arithmetic/retained-sample checks, no EOS. Preserve failures and never relax thresholds.

Exact factored manufactured polynomials embedded in a complete N3/12-label panel: unique liquid crossing1/2 (all other roots later/absent), convex dip/recovery with returning root atH, concave initial gain, tangent atH/interior, earlier gas1/4, exact liquid/gas tie, all-positive no-root and any zero-initial competitor. Expected first roots, positivity and proposal h are exact Fractions from factors, not tested isolator output. Actual source sample fixture may supply metadata only and is explicitly manufactured.

A budget-decision case must require both ordering refinement and extra selected-lower refinement or otherwise expose budget reset; additionally a unique quadratic whose lower remains0 after the entire small allowed budget must return unresolved, not refine with a reset256 budget. Validate effective cap for requested>256 and smaller caller cap, original order record retained, original earliest bracket branch/history and separate lower-positive refinement history.

Domain decisions: f*lower exactly at original minimum passes if other guards pass; smaller fails without upward adjustment; interior knot produces explicit stop/refusal; exact huge absolute origin leaves relative target unchanged. Original prefix may be negative while two actual saved observations remain valid; missing midpoint must reject. Every proposed h receives independent all12 minima checks, followed by exactly one separately identifiable actual new trial if explicitly authorized by the interface. Source negative/failed trial cannot be relabeled validated.

If a cheap actual host run is necessary, parent must supply the bounded interface/callback budget; no HEOS here. Otherwise keep pure proposal validation separate from provider's actual source-host execution tests. This audit does not construct a replacement integrator.
