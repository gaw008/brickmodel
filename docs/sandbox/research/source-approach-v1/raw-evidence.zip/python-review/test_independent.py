"""Bounded source-approach evidence checks with existing manufactured inputs."""
from dataclasses import replace
from fractions import Fraction as F
from types import SimpleNamespace

import pytest

from test_source_approach import actual, choice
from test_source_net_roots import poly
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.source_approach import (
    SourceApproachAssessmentError, propose_source_approach, evaluate_source_approach,
)


@pytest.fixture(scope='module')
def executed(actual):
    seed, policy = actual
    proposal = propose_source_approach(seed, event_policy=policy)
    result = evaluate_source_approach(proposal, maximum_callbacks=16)
    assert result.status == 'validated_positive_numerical_approach', result.reason
    return result


def test_completed_record_rechecks_without_new_source(executed, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError('saved approach check evaluated new source')
    monkeypatch.setattr(ExactSourceColumn, 'evaluate', forbidden)
    executed.check()
    assert executed.event_admitted is executed.material_qualified is False


def test_success_cannot_replace_real_root_proposal_with_duck_typed_noop(executed):
    proposal = executed.proposal
    fake = SimpleNamespace(**vars(proposal))
    fake.check = lambda: None
    fake.roots = None
    fake.choice = None
    changed = replace(executed, proposal=fake)
    with pytest.raises(ValueError):
        changed.check()


def test_unexecuted_record_also_requires_actual_proposal(actual):
    seed, _ = actual
    proposal = propose_source_approach(seed, event_policy=None)
    result = evaluate_source_approach(proposal, maximum_callbacks=16)
    fake = SimpleNamespace(**vars(proposal), check=lambda: None)
    with pytest.raises(ValueError):
        replace(result, proposal=fake).check()


def test_proposal_complete_nested_policy_cannot_be_replaced(executed):
    proposal = executed.proposal
    changed = replace(proposal.event_policy,
                      roundoff_policy=replace(proposal.event_policy.roundoff_policy,
                                              storage_absolute_mol=1.))
    with pytest.raises(ValueError):
        replace(proposal, event_policy=changed).check()


@pytest.mark.parametrize('field,value', [('new_evaluations', True), ('maximum_callbacks', True),
                                        ('material_qualified', True), ('event_admitted', True)])
def test_result_control_and_qualification_mutations_are_rejected(executed, field, value):
    with pytest.raises(ValueError):
        replace(executed, **{field: value}).check()


def test_downward_binary64_choice_does_not_cross_exact_desired():
    out = choice((poly(1, -1),), safe_fraction=F(1, 10))
    assert out.desired_duration_s == F(1, 10)
    assert 0 < out.duration_s <= F(1, 10) < F(float(F(1, 10)))
    out.check()


def test_subnormal_candidate_cannot_relax_original_minimum():
    out = choice((poly(F(1, 2**1074), -1),), minimum_step_s=F(1, 2**1074))
    assert out.status == 'approach_below_original_minimum_step'
    assert out.desired_duration_s > 0 and out.duration_s == F()
    out.check()


def test_unexpected_actual_source_exception_retains_failed_attempt(actual, monkeypatch):
    seed, policy = actual
    proposal = propose_source_approach(seed, event_policy=policy)
    original = ExactSourceColumn.evaluate
    calls = []
    def fail_second(self, state, when):
        calls.append((state, when))
        if len(calls) == 2:
            raise RuntimeError('independent_source_failure')
        return original(self, state, when)
    monkeypatch.setattr(ExactSourceColumn, 'evaluate', fail_second)
    out = evaluate_source_approach(proposal, maximum_callbacks=16)
    assert out.status == 'numerical_failure' and out.new_evaluations == len(calls) == 2
    assert out.comparison is out.pressure is None
    assert out.trial.captures[0].evaluation is not None
    failed = out.trial.captures[1]
    assert failed.evaluation is None and failed.failure_kind == 'UnexpectedException'
    assert failed.failure == 'RuntimeError:independent_source_failure'
    out.check()


def test_callback_adapter_identity_change_retains_trial_on_final_check(actual, monkeypatch):
    seed, policy = actual
    proposal = propose_source_approach(seed, event_policy=policy)
    original = ExactSourceColumn.evaluate
    saved_identity = seed.adapter._identity
    calls = []
    def mutate_after_first(self, state, when):
        calls.append((state, when))
        value = original(self, state, when)
        if len(calls) == 1:
            object.__setattr__(self, '_identity', ('changed-by-independent-callback',))
        return value
    monkeypatch.setattr(ExactSourceColumn, 'evaluate', mutate_after_first)
    try:
        with pytest.raises(SourceApproachAssessmentError) as caught:
            evaluate_source_approach(proposal, maximum_callbacks=16)
    finally:
        object.__setattr__(seed.adapter, '_identity', saved_identity)
    error = caught.value
    assert error.stage == 'result_check' and error.__cause__ is not None
    assert error.trial.status == 'numerical_failure'
    assert len(error.trial.captures) == len(calls) == 1
    assert error.trial.captures[0].evaluation is not None
    assert error.trial.captures[0].failure is not None
    assert error.comparison is error.pressure is None
    error.trial.check()
