import json
import os
from pathlib import Path
import signal
import sys
import time

import pytest
import supervisor


def run(tmp_path, code, **kw):
    return supervisor.run_attempt(tmp_path/'attempt', [sys.executable,'-c',code], cwd=tmp_path, **kw)


def test_success_logs_hashes_and_terminal(tmp_path):
    source=tmp_path/'input.txt'; source.write_text('source')
    result=run(tmp_path,"import sys; print('output'); print('error channel',file=sys.stderr)",input_paths=[source])
    assert result['status']=='complete' and result['returncode']==0 and result['inputs_unchanged']
    assert (tmp_path/'attempt/stdout.log').read_text()=='output\n'
    assert (tmp_path/'attempt/stderr.log').read_text()=='error channel\n'
    assert json.loads((tmp_path/'attempt/status.json').read_text())==result
    assert len(json.loads((tmp_path/'attempt/metadata.json').read_text())['inputs_before'][str(source)]['sha256'])==64


def test_nonzero_and_spawn_failure(tmp_path):
    result=run(tmp_path,"raise SystemExit(7)")
    assert result['status']=='failed' and result['returncode']==7
    result=supervisor.run_attempt(tmp_path/'missing',['/nonexistent/research-command'],cwd=tmp_path)
    assert result['status']=='failed' and 'FileNotFoundError' in result['error']


def test_timeout_ignoring_term_and_child_holding_pipe(tmp_path):
    code="""import subprocess,sys,signal,time
signal.signal(signal.SIGTERM,signal.SIG_IGN)
child=subprocess.Popen([sys.executable,'-c','import signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); time.sleep(10)'], stdout=subprocess.PIPE)
print(child.pid,flush=True)
time.sleep(10)
"""
    started=time.monotonic()
    result=run(tmp_path,code,timeout_s=.2,cleanup_grace_s=.05)
    assert result['status']=='timed_out' and result['returncode']==-signal.SIGKILL
    assert result['cleanup']['leader_reaped'] and time.monotonic()-started<2
    # Inspect descendant without blocking on an inherited pipe. A killed orphan
    # may briefly be a zombie, so an existing PID alone is not proof of running.
    child=int((tmp_path/'attempt/stdout.log').read_text())
    deadline=time.monotonic()+.5
    while True:
        try:
            os.kill(child,0)
        except ProcessLookupError:
            break
        assert time.monotonic()<deadline, 'descendant not reaped within observation budget'
        time.sleep(.01)


def test_collision_preserves_prior_success(tmp_path):
    run(tmp_path,'pass')
    before=(tmp_path/'attempt/status.json').read_bytes()
    with pytest.raises(FileExistsError):run(tmp_path,'raise SystemExit(1)')
    assert (tmp_path/'attempt/status.json').read_bytes()==before


def test_atomic_running_to_terminal_and_no_partial_json(tmp_path,monkeypatch):
    observed=[]; original=os.replace
    def replace(src,dst):
        if Path(dst).name=='status.json':
            new=json.loads(Path(src).read_text()); old=json.loads(Path(dst).read_text()) if Path(dst).exists() else None
            observed.append((old,new))
        original(src,dst)
    monkeypatch.setattr(supervisor.os,'replace',replace)
    run(tmp_path,'pass')
    assert observed[0][0] is None and observed[0][1]['status']=='running'
    assert observed[1][0]['status']=='running' and observed[1][1]['status']=='complete'
    assert not list((tmp_path/'attempt').glob('*.tmp'))


def test_input_mutation_cannot_publish_success(tmp_path):
    source=tmp_path/'input';source.write_text('before')
    result=run(tmp_path,"from pathlib import Path; Path('input').write_text('after')",input_paths=[source])
    assert result['status']=='failed' and result['error']=='declared_inputs_changed'


@pytest.mark.parametrize('value',[True,0,-1,float('nan'),float('inf')])
def test_invalid_budget_does_not_create_attempt(tmp_path,value):
    with pytest.raises(ValueError):run(tmp_path,'pass',timeout_s=value)
    assert not (tmp_path/'attempt').exists()


def test_terminal_atomic_write_failure_leaves_running_not_false_success(tmp_path,monkeypatch):
    original=os.replace
    def replace(src,dst):
        if Path(dst).name=='status.json' and json.loads(Path(src).read_text())['status']=='complete':
            raise OSError('injected storage failure')
        original(src,dst)
    monkeypatch.setattr(supervisor.os,'replace',replace)
    with pytest.raises(OSError,match='injected storage failure'):run(tmp_path,'pass')
    assert json.loads((tmp_path/'attempt/status.json').read_text())['status']=='running'
    assert json.loads((tmp_path/'attempt/status.json.tmp').read_text())['status']=='complete'
    # Consumers must read only status.json, never a pending .tmp or child file.
