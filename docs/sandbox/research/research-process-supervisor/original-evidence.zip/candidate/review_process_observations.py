"""Retained source of the independent no-EOS observation already executed.

Execution used this body via stdin from the runner directory; saving it here
does not imply a second execution. The original output is retained separately.
"""
import importlib.util
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

spec = importlib.util.spec_from_file_location('supervisor', Path('supervisor.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
base = Path(tempfile.mkdtemp(prefix='independent-supervisor-', dir='/private/tmp'))
code = "import subprocess,sys; p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(8)']); print(p.pid,flush=True)"
r = mod.run_attempt(base/'leader-exit', [sys.executable, '-c', code], cwd=base, cleanup_grace_s=.1)
child = int((base/'leader-exit/stdout.log').read_text())
time.sleep(.05)
try:
    os.kill(child, 0)
    alive = True
except ProcessLookupError:
    alive = False
print('leader exits with descendant:', r['status'], 'descendant alive after cleanup:', alive)
script = "import sys; sys.path.insert(0,'/private/tmp/brick-water-backend-runner'); import supervisor; supervisor.run_attempt(sys.argv[1],[sys.executable,'-c','import os,time; print(os.getpid(),flush=True); time.sleep(8)'],cwd=sys.argv[2],timeout_s=7)"
parent = subprocess.Popen([sys.executable, '-c', script, str(base/'parent-term'), str(base)])
child = None
try:
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline:
        log = base/'parent-term/stdout.log'
        if log.exists() and log.read_text().strip():
            child = int(log.read_text())
            break
        time.sleep(.01)
    assert child is not None
    parent.terminate()
    parent.wait(timeout=1)
    try:
        os.kill(child, 0)
        alive = True
    except ProcessLookupError:
        alive = False
    print('supervisor TERM:', parent.returncode, 'child alive:', alive,
          'status:', json.loads((base/'parent-term/status.json').read_text())['status'])
finally:
    if child:
        try:
            os.killpg(child, signal.SIGKILL)
        except ProcessLookupError:
            pass
    if parent.poll() is None:
        parent.kill()
        parent.wait(timeout=1)
print('independent observation dir:', base)
