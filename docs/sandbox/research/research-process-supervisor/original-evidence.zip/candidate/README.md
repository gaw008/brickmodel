# Isolated external research supervisor

Implementation step 1 only; no EOS imports, adapter seam or repository changes. `supervisor.run_attempt(attempt_dir, argv, cwd=..., input_paths=..., timeout_s=..., cleanup_grace_s=...)` creates one new attempt directory exclusively. Parent directory must already exist. A caller should generate an unpredictable unique attempt name; collision raises before touching old data. Commands use argument sequences, never shell=True.

Metadata records argv/cwd, input-content hashes, file sizes, source identity and requested time/cleanup budgets. Input paths relative to cwd are resolved before launch. This is an observation of declared inputs, not a filesystem snapshot: concurrent changes and undeclared dependencies are outside the identity contract. Before/after hash mismatch prevents complete status. Child executable/dependencies must be included among declared inputs if required by an experiment's traceability contract.

Status is initially running, then complete (exit 0 plus unchanged inputs), failed (nonzero, spawn/cleanup failure or changed inputs), or timed_out. Each JSON update is flushed, fsynced and replaced atomically. Consumers must read only terminal status.json of that exact attempt, never a .tmp, a child-owned result, or a previous directory. Complete means process execution completed, not that scientific assertions passed unless the child's exit contract enforces them. Filesystem failure or abrupt supervisor death can leave running; this is incomplete, never success. The injected atomic-write failure test demonstrates that property. Directory fsync/power-loss durability is not claimed.

The child starts a new POSIX session. stdout/stderr go to files, avoiding unbounded communicate/pipe drains when descendants retain descriptors. Timeout uses the parent subprocess wait deadline; afterwards cleanup sends TERM to the original group, polls for at most the grace interval, sends KILL, and waits at most another grace interval for the leader. Cleanup is also applied on ordinary completion to stop surviving children in that group. Returned cleanup diagnostics state whether the leader was reaped. The supervisor does not claim a hard kernel deadline or full descendant containment: process creation/OS scheduling/uninterruptible kernel work can delay control, and descendants deliberately creating another session can escape this process group. This is a trusted research runner, not a hostile-process sandbox. File output has no disk-size quota in this bounded step.

## Actual validation

Repo Python executed only this directory's pytest file. Final 12 tests passed in under one second (exact output in tests.log/XML); aggregate test invocations remained under 10 seconds. Coverage: success and both logs, native argv launch, nonzero return, missing executable, timeout with TERM-ignoring leader and descendant retaining a PIPE, actual KILL/reaping observation, collision preserving prior status bytes, atomic running-to-complete transitions, injected terminal storage failure, input mutation, invalid finite/bool/positive budget checks. Tests never import or run an EOS.

Initial 1 failed / 10 passed: sandbox blocked a ps command used only to observe descendant status. Preserved attempt01-failure.log/XML. Observation now uses bounded os.kill(pid, 0) polling and passed on macOS; no claim that this validates escaped-process containment. Later added atomic terminal-write-failure coverage. No benchmark was rerun, and the original water probe was untouched.

Independent parent code review is pending. Source/tests are frozen for that review; artifacts are bound in manifest.json.

## Pending TERM fix

Root's isolated update requires the main Python thread, temporarily handles SIGTERM,
and restores the previous handler on exit. A TERM during child creation is deferred
until a cleanup handle exists; no blocked TERM mask is inherited by the child.
TERM during cleanup is deferred until group escalation finishes. Repeated TERM is
ignored during termination. SIGKILL, OS failure and deliberately escaped sessions
remain outside this guarantee. Arguments and child logs are retained verbatim;
callers must exclude credentials and other secrets. Updated code is pending
independent regression review; original failure and pre-fix source are preserved.
