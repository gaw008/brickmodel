"""Independent no-EOS regressions for supervisor cancellation ownership."""
import json
import os
import signal
import subprocess
import sys
import threading

import pytest
import supervisor


@pytest.mark.parametrize('when', ['before_spawn', 'after_spawn'])
def test_launch_term_has_cleanup_owner_and_restores_handler(tmp_path, monkeypatch, when):
    original = subprocess.Popen
    processes = []
    previous = signal.getsignal(signal.SIGTERM)

    def launch(*args, **kwargs):
        if when == 'before_spawn':
            os.kill(os.getpid(), signal.SIGTERM)
        process = original(*args, **kwargs)
        processes.append(process)
        if when == 'after_spawn':
            os.kill(os.getpid(), signal.SIGTERM)
        return process

    monkeypatch.setattr(supervisor.subprocess, 'Popen', launch)
    try:
        with pytest.raises(supervisor.SupervisorTerminated):
            supervisor.run_attempt(tmp_path/'launch',
                                   [sys.executable, '-c', 'import time; time.sleep(5)'],
                                   cwd=tmp_path, timeout_s=.5, cleanup_grace_s=.05)
        status = json.loads((tmp_path/'launch/status.json').read_text())
        assert status['status'] == 'failed'
        assert status['cleanup']['leader_reaped']
        assert all(p.poll() is not None for p in processes)
        assert signal.getsignal(signal.SIGTERM) == previous
    finally:
        for process in processes:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=1)


def test_first_term_during_cleanup_finishes_cleanup(tmp_path, monkeypatch):
    original = supervisor._cleanup
    observed = []

    def cleanup(process, grace):
        observed.append(process)
        os.kill(os.getpid(), signal.SIGTERM)
        return original(process, grace)

    monkeypatch.setattr(supervisor, '_cleanup', cleanup)
    previous = signal.getsignal(signal.SIGTERM)
    try:
        try:
            result = supervisor.run_attempt(tmp_path/'cleanup',
                                            [sys.executable, '-c', 'import time; time.sleep(5)'],
                                            cwd=tmp_path, timeout_s=.02, cleanup_grace_s=.05)
        except supervisor.SupervisorTerminated:
            result = json.loads((tmp_path/'cleanup/status.json').read_text())
        assert observed and all(p.poll() is not None for p in observed)
        assert result['cleanup']['leader_reaped']
        assert result['status'] in ('failed', 'timed_out')
        assert signal.getsignal(signal.SIGTERM) == previous
    finally:
        for process in observed:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=1)


def test_handler_restored_on_validation_failure(tmp_path):
    previous = signal.getsignal(signal.SIGTERM)

    def caller_handler(signum, frame):
        raise AssertionError('caller handler must not run during supervision')

    signal.signal(signal.SIGTERM, caller_handler)
    try:
        with pytest.raises(ValueError):
            supervisor.run_attempt(tmp_path/'invalid', ['unused'], cwd=tmp_path, timeout_s=0)
        assert signal.getsignal(signal.SIGTERM) is caller_handler
    finally:
        signal.signal(signal.SIGTERM, previous)


def test_worker_thread_rejects_before_creating_attempt(tmp_path):
    failures = []

    def worker():
        try:
            supervisor.run_attempt(tmp_path/'thread', [sys.executable, '-c', 'pass'], cwd=tmp_path)
        except ValueError as exc:
            failures.append(str(exc))

    thread = threading.Thread(target=worker)
    thread.start()
    thread.join(timeout=1)
    assert not thread.is_alive()
    assert failures and 'main thread' in failures[0]
    assert not (tmp_path/'thread').exists()
