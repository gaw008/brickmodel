"""Root-supervised numerical-strategy point probe; no profiling or child process."""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import time
import traceback

SOURCE=Path('/private/tmp/brick-paired-service-lifecycle-v1/replay')
STRATEGY='guarded_liquid_endpoint_interpolation_v1'


def save(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)


def require(ok,message):
    if not ok:raise AssertionError(message)


def selected(value,encode):
    return {'rates':encode(value.rates),'geometry':encode(value.geometry),'free':encode(value.free),
        'inverses':[{'target':encode(inv.target),'thermal_state':encode(inv.state.thermal_state),
            'skeleton_state':encode(inv.state.skeleton_state),'total_energy_j':inv.state.total_energy_j,
            'energy_error_bound_j':inv.state.energy_error_bound_j,
            'total_energy_residual_j':inv.total_energy_residual_j,
            'subtraction_roundoff_j':inv.subtraction_roundoff_j,
            'temperature_error_bound_k':inv.temperature_error_bound_k} for inv in value.total_inverses]}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    output=parser.parse_args().output;output.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();report={'status':'started','calls':[],
        'qualification':'Explicit numerical-strategy point comparison, not continuation or trajectory/material validation.',
        'external_wall_limit_seconds':40,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    save(output/'result.json',report)
    try:
        from sludge_sandbox.run_service import read_run,runtime_identity
        from sludge_sandbox.verification_case import read_case,build_case,encode
        from sludge_sandbox.integration import ConservedState
        saved,manifest=read_run(SOURCE)
        report['runtime_before']=runtime_identity();report['saved_runtime']=saved['runtime_before']
        report['parent_manifest_sha256']=hashlib.sha256((SOURCE/'manifest.json').read_bytes()).hexdigest()
        baseline=json.loads((SOURCE/'case.json').read_bytes());variant=copy.deepcopy(baseline)
        require('strategy' not in baseline['numerics']['pressure_policy'],'original default strategy required')
        variant['numerics']['pressure_policy']['strategy']=STRATEGY
        stripped=copy.deepcopy(variant);del stripped['numerics']['pressure_policy']['strategy']
        require(stripped==baseline,'only numerical strategy may change')
        save(output/'baseline-case.json',baseline);save(output/'strategy-case.json',variant)
        builds=[]
        for name in ('baseline','strategy'):
            before=time.monotonic();built=build_case(read_case(output/(name+'-case.json')),SOURCE/'water')
            builds.append(built);save(output/(name+'-initial.json'),encode(built.initial))
            report[name+'_build_seconds']=time.monotonic()-before
        a,b=builds
        for expected,built in zip((None,STRATEGY),builds):
            actual_policies=[point.template.fluid_template.mechanical.policy for point in built.operator.base_model.point_storages]
            require(all(policy.strategy==expected for policy in actual_policies),'actual constructed strategy policy')
            report['baseline_policies' if expected is None else 'strategy_policies']=encode(actual_policies)
        save(output/'result.json',report)
        for key in ('amounts_mol','internal_energy_j','mechanical_stretches'):
            require(encode(getattr(a.initial,key))==encode(getattr(b.initial,key)),'initial exact equality: '+key)
            require(encode(getattr(a.initial,key))==saved['integration']['states'][0][key],'original initial equality: '+key)
        require(a.start_s==b.start_s and a.end_s==b.end_s and encode(a.policy)==encode(b.policy),'same domain/integration policy')
        raw=saved['integration']['states'][1];at=saved['integration']['times_s'][1]
        report['original_accepted_state']=raw;report['time_s']=at
        report['identity_rebinding']='Same accepted N/E/stretch arrays, explicit new model identity per numerical strategy; not checkpoint resume.'
        require(saved['integration']['times_s'][0]<at<saved['integration']['times_s'][-1],'interior original accepted state')
        results=[]
        for name,built in zip(('baseline','strategy'),builds):
            host=built.operator.base_model
            state=ConservedState(raw['amounts_mol'],raw['internal_energy_j'],built.initial.energy_model_identity,
                                 mechanical_stretches=raw['mechanical_stretches'])
            require(all(row[host.inventory_layout.liquid_index]>0 for row in state.amounts_mol),'same wet state')
            host._check_state(state)
            save(output/(name+'-input.json'),encode(state))
            call={'strategy':name,'status':'started','profiled':False};report['calls'].append(call)
            save(output/'result.json',report);wall=time.monotonic();cpu=time.process_time()
            try:actual=host.evaluate(state,at)
            finally:
                call.update(wall_seconds=time.monotonic()-wall,cpu_seconds=time.process_time()-cpu)
                save(output/'result.json',report)
            value=selected(actual,encode);save(output/(name+'-output.json'),value)
            results.append(value);call['status']='returned_and_saved'
            save(output/'result.json',report)
        comparisons=[]
        pressure_policy=baseline['numerics']['pressure_policy']
        for i,(left,right) in enumerate(zip(results[0]['inverses'],results[1]['inverses'])):
            la,lb=left['thermal_state'],right['thermal_state'];ma,mb=la['mechanical'],lb['mechanical']
            comparisons.append({'cell':i,'temperature_difference_k':abs(ma['temperature_k']-mb['temperature_k']),
                'temperature_bound_k':left['temperature_error_bound_k']+right['temperature_error_bound_k'],
                'pressure_difference_pa':abs(ma['pressure_pa']-mb['pressure_pa']),
                'pressure_bound_pa':la['pressure_error_bound_pa']+lb['pressure_error_bound_pa'],
                'final_root_iterations':[ma['iterations'],mb['iterations']],
                'strategy_final_root_ledger_rows':len(mb.get('pressure_trial_ledger',[])),
                'count_scope':'Final returned cell roots only; does not count intermediate thermal inverse/native calls.'})
        report['comparisons']=comparisons;save(output/'result.json',report)
        for left,right,c in zip(results[0]['inverses'],results[1]['inverses'],comparisons):
            la,lb=left['thermal_state'],right['thermal_state'];ma,mb=la['mechanical'],lb['mechanical']
            require(la['energy_scope']==lb['energy_scope'],'thermal energy scope unchanged')
            require(ma['source_ids']==mb['source_ids'] and ma['source_asset_sha256']==mb['source_asset_sha256'],'source identity unchanged')
            require(ma['pressure_bracket_pa']==mb['pressure_bracket_pa'],'original physical pressure domain')
            require(c['temperature_difference_k']<=c['temperature_bound_k'],'temperature original bounds')
            require(c['pressure_difference_pa']<=c['pressure_bound_pa'],'pressure original independent bounds')
            for inv,m in ((left,ma),(right,mb)):
                bracket=m['final_numerical_pressure_bracket_pa']
                require(bracket[1]-bracket[0]<=pressure_policy['pressure_absolute_pa'],'original bracket width')
                require(abs(m['volume_residual_m3'])<=pressure_policy['volume_absolute_m3'],'original volume residual')
                require(abs(m['pressure_residual_pa'])<=pressure_policy['pressure_absolute_pa'],'original pressure residual')
                require(m['gas_volume_m3']>0,'positive gas volume')
                require(m['volume_resolution_m3']<=pressure_policy['volume_absolute_m3'] and m['pressure_resolution_pa']<=pressure_policy['pressure_absolute_pa'],'original representability gates')
                import math
                require(abs(math.fsum(m['partial_pressures_pa'].values())-m['pressure_pa'])<=pressure_policy['pressure_absolute_pa'],'original partial pressure sum')
        report['status']='passed'
    except BaseException as exc:
        chain=[];seen=set();pending=[exc]
        while pending:
            error=pending.pop()
            if id(error) in seen:continue
            seen.add(id(error))
            row={'type':type(error).__name__,'message':str(error)}
            if hasattr(error,'pressure_trial_ledger'):
                row['pressure_trial_ledger']=encode(error.pressure_trial_ledger)
            chain.append(row)
            pending.extend(link for link in (error.__cause__,error.__context__) if link is not None)
        save(output/'exception-chain.json',chain)
        report.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
    finally:
        try:
            from sludge_sandbox.run_service import runtime_identity,read_run
            report['runtime_after']=runtime_identity();read_run(SOURCE)
            require(report.get('runtime_before')==report['runtime_after'],'runtime changed')
            require(hashlib.sha256((SOURCE/'manifest.json').read_bytes()).hexdigest()==report['parent_manifest_sha256'],'parent changed')
        except BaseException:report['integrity_error']=traceback.format_exc();report['status']='failed'
        report['wall_seconds']=time.monotonic()-started;save(output/'result.json',report)
    require(report['status']=='passed',report.get('reason','probe failed'))


if __name__=='__main__':main()
