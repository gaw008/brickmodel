# Independent numerical-strategy point-probe review

APPROVE scoped run.py SHA256 94f6029c6bea8e46b7535da9ea0e1333bdf98670ab1510166e4cc016cc46b342. Read-only; no EOS, probe execution or repository edits.

The runner reads the sealed original replay, preserves its manifest identity, and creates two case copies differing only by the explicit numerical strategy field. It constructs both actual models and verifies the per-cell actual PressurePolicy strategies. Both initial N/E/stretch states must match each other exactly and match the recorded original initial arrays. Domain and integration policy equality are required. It then selects the same original interior accepted wet state for both calls, with identical N/E/stretch arrays and explicit per-model energy identity rebinding. This is correctly labeled as a point comparison under new identities, not a checkpoint continuation.

There are at most two explicit host.evaluate calls after normal construction, one per strategy. The external 40-second bound must be supplied by root; construction and native calls themselves are not interrupted internally. Both actual inputs and full selected outputs are atomically saved before parity/bound assertions. The selected diagnostics use existing returned fields, not an extra EOS call. Original pressure bracket width, volume/pressure residual, representability, positive gas-volume and partial-pressure-sum gates remain unchanged. Temperature and pressure differences are compared against the retained independent output-error sums. This is numerical comparison evidence, not a new physical error certificate or full trajectory test.

Final-root iteration and ledger counts are accurately qualified as final returned cell roots only, excluding intermediate thermal inverse and native calls. The script does not infer total TP calls from these counts. Timings are for two different strategy calls in a fixed order and can include history effects; they alone do not justify a full-event speedup claim.

Exceptions preserve traceback plus both cause/context chains and any attached pressure-trial ledgers, so nested failed pressure attempts remain inspectable when outer wrappers preserve the exception chain. Successful outputs are saved before subsequent gate failure. Final checks revalidate the sealed parent and unchanged manifest SHA, and require runtime stability within the attempt. Historical runtime is recorded rather than asserted identical to the new numerical implementation.

No blocking issue found. Actual initial equality or gate assertions may still fail under native evaluation; such a failure must remain evidence rather than prompting silent input or threshold changes. Approval is of the bounded probe, not of an unexecuted solver speedup or material claim.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE bounded explicit-strategy comparison probe.
