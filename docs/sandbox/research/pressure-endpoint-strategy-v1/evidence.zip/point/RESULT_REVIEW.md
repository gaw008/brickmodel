# Saved point result review

APPROVE for the bounded single-point comparison. No EOS or production model code was executed by this reviewer. Independent standard-library JSON/Fraction arithmetic checks on both raw outputs passed.

Inspected SHA256:
- baseline-output.json: 38b51cb9a815b1bf28e2940294637370da1f6987d67e5cd626c06109ccba879d
- strategy-output.json: 0fbeba8b40f7b83893994725f1ad5d2859877aa407eb8ed20677bd977d7e4e64
- result.json: 35bb8563e2fa52a06ca9fd13e4cd3276b6cf262801205ce9344064a229191ecb

Both cells contain two evaluated initial endpoints, two actual evaluated endpoint proposals, and one fresh evaluated finishing midpoint. Recomputed every saved residual from represented liquid volume plus rounded NgRT/P minus available pore volume using Fraction. Checked every proposal/finish before bracket and endpoint residual pair against the previous state, monotone residual containment, sign-selected endpoint replacement, exact after bracket, and final bracket/residual binding. Final widths are 4.3796972022391856e-6 and 4.313907993491739e-6 Pa, below unchanged 1e-5 Pa. Final roots report 3 iterations and 5 rows each; baseline reports 38 iterations each. Baseline has no opt-in trial ledger, so no claim to reconstruct its unsaved intermediate trials.

For all four final roots, checked original volume/pressure residual and resolution gates, positive gas volume, partial-pressure sum, and independently recomputed pressure residual. T and P differences fall inside the sums of the saved independent error bounds. This audits recorded arithmetic, not an independent native EOS or domain-wide error-certificate proof.

All 65 recorded current module hashes match repository bytes; runtime before equals after. Baseline/strategy cases differ only by explicit strategy; initial numeric arrays match between builds, and both accepted-state inputs exactly match the saved original N/E/stretch arrays. Model identities are explicitly rebound, not resumed. Both strategies retain identical water source IDs and asset hashes. Manufactured solid/envelope qualifications remain explicit.

Observed unprofiled calls are 0.800052542 s then 0.133750667 s in this one ordered sample. History/cache and ordering remain possible confounders. Counts describe only final returned roots, not intermediate inverse/native calls. This establishes neither full-event speedup nor material/trajectory validation.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — scoped saved-data result and arithmetic only.
