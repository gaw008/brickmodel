# Independent pressure strategy solver and schema review

APPROVE scoped implementation, subject to actual native validation before performance/scientific claims. Read-only review; no EOS, source edits or test reruns.

Inspected rigid_water_gas.py SHA256 e9607adfc6bbdb16a502b5892286220707534e8564f724ab957d698f8b07b287; verification_case.py SHA256 adbbd0e931689dc2c1697132575923d85c177dc762e656c93d54c9f21b45af1b; test_pressure_endpoint_interpolation.py SHA256 c877dc49eb316417de4c13f022c38ccf92e92e0a07bacbef6e9101bc4ca5ae28; test_pressure_case_strategy.py SHA256 ba685b84bfc43680ea893555f0afb9ea515ce34b44944ec21030aedfd7e9c75a.

The strategy only proposes candidate pressures from the current endpoint liquid-volume values. Directed nextafter is not accepted as a proof or as an unevaluated root bound. Every proposed interior point calls the actual liquid provider, checks the evaluated residual lies between current endpoint residuals, and updates the bracket by its actual sign with the matching liquid-volume value. At most two proposals occur before a midpoint is forced unless the bracket has already halved. Proposal and fallback trials share maximum_iterations; initial endpoints retain their original two-call semantics. Precision/residual checks and the narrow-bracket requirement are preserved. Exact numerical endpoint and dry analytic branches retain original behavior. No local derivative sample is promoted to a global monotonicity theorem.

The optional default None path retains the actual original bisection sequence and omits the new public policy/ledger fields from encode. Raw dataclass/model identities can still change with this source/schema revision; default numerical/codec compatibility is not old source-byte identity. Successful opt-in solves retain immutable trial ledgers. Provider failures and subsequent solver errors propagate with attempted ledger evidence; there is no silent retry after nonmonotonic or provider failure. The module exposes exception ledgers but does not guarantee that all outer wrappers serialize them. Final thermal states expose their final pressure solve, not every discarded inverse trial; this limitation is already disclosed.

Case schema adds only an explicitly present strategy key and accepts only the exact guarded_liquid_endpoint_interpolation_v1 string. All other numerical fields retain original positive/integer checks and exact-key validation. The real builder forwards strategy explicitly; old absent strategy maps to None without rewriting case bytes. Configuration tests reject unknown/implicit values and retain unchanged default shape.

Analytic tests use independently evaluated Decimal quadratic roots for monotone liquid laws, inspect every actual bracket transition and provider call count, verify constant-liquid improvement, iteration cap, failed trial retention, nonmonotonic refusal, pure-gas fast path and original midpoint order/default field omission. These test the algorithm and guards using explicitly analytic providers, not actual water. Read green03.xml: 15 tests, zero failures/errors/skips, 0.050 seconds. Combined schema/regression XML: 66 tests, zero failures/errors/skips, 0.393 seconds. Earlier failing test attempts are retained; the documented default-sequence test correction did not alter the production gate.

A nonblocking comment says finish uses a fresh midpoint, but the second proposal can itself finish if the first proposal already made the bracket narrow. The actual correctness requirement is a fresh evaluated interior candidate with all finish gates; code satisfies that. Author was notified to clarify wording without numerical changes.

No blocking issue found in this scope. Native before/after roots, numerical bounds, source identity and measured call/runtime evidence are still required. No real material, full-event speedup or spatial-convergence claim follows yet.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE explicit strategy implementation pending separately planned native evidence.
