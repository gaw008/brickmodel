"""Data-only accepted-prefix audit; standard library, no production imports/EOS.

Derived from the reviewed brick-free-native-events-v1/audit.py Fraction ledger
method. Does not re-certify paired endpoint observations or source manifests.
The fixed 2e-8 J global targets are retained, not inferred from observed results.
Run only after the parent confirms the native process is terminal.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math
import sys

def check(ok, message):
    if not ok:
        raise AssertionError(message)


def number(value):
    check(type(value) in (int, float) and math.isfinite(value), 'finite numeric required')
    return F(value)


def exact(value):
    check(type(value) is dict and set(value) == {'numerator', 'denominator'}, 'fraction shape')
    check(type(value['numerator']) is int and type(value['denominator']) is int and value['denominator'] > 0, 'fraction integers')
    return F(value['numerator'], value['denominator'])


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            check(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    return json.loads(path.read_text(), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def audit(directory, report):
    case=read(directory/'case.json')
    record=read(directory/'depletion_result.json')
    report.update(status=record['status'],final_time_s=record['times_s'][-1],
                  requested_end_s=case['numerics']['end_s'],events=len(record['events']),prefixes=[])
    check(record['schema']=='sandbox_depletion_result_v2','explicit paired event schema')
    policy=case['numerics']['integration'];ep=case['numerics']['depletion'];rp=ep['roundoff_policy']
    check(ep.get('pressure_comparison') is not None,'explicit paired policy')
    for field,total in (('panels','attempted_steps'),('rejections','rejected_trials'),('evaluations','evaluations')):
        check(type(record[total]) is int and record[total]>=0,'nonnegative resource total')
        check(all(type(v[field]) is int and v[field]>=0 for v in record['phase_costs'].values()),'nonnegative phase resource')
        check(sum(v[field] for v in record['phase_costs'].values())==record[total],'phase cost sum')
    check(record['attempted_steps']<=policy['maximum_steps'] and record['rejected_trials']<=policy['maximum_rejections'],'original resource budgets')
    cost=record['phase_costs']['comparison']
    check(type(cost['endpoint_attempts']) is int and type(cost['endpoint_completed']) is int and 0<=cost['endpoint_completed']<=cost['endpoint_attempts'],'endpoint cost order')
    report['endpoint_costs']={key:cost[key] for key in ('endpoint_attempts','endpoint_completed')}
    states, times, steps = record['states'], record['times_s'], record['steps']
    check(record['attempted_steps']>=len(steps), 'accepted panel resource lower bound')
    check(len(states) == len(times) == len(steps) + 1, 'history lengths')
    check(times[0] == case['numerics']['start_s'], 'original start')
    cells = len(states[0]['amounts_mol']); columns = len(states[0]['amounts_mol'][0])
    factor=cells//case['grid']['parent_cells']
    expected_rows=[[v/factor for v in case['initial']['parent_amounts_mol'][0 if case['profile']=='uniform' else i//factor]] for i in range(cells)]
    normals=[case['mechanics']['initial_parent_normal_stretches'][0 if case['profile']=='uniform' else i//factor] for i in range(cells)]
    check(states[0]['amounts_mol']==expected_rows and states[0]['mechanical_stretches']==normals+[case['mechanics']['initial_tangential_stretch']], 'declared initial inventory/mechanics')
    li = case['initial']['species_order'].index('H2O_liquid'); vi = case['initial']['species_order'].index('H2O')
    nt = number(policy['amount_absolute_tolerance_mol']); et = number(policy['energy_absolute_tolerance_j']); st = number(policy['stretch_absolute_tolerance'])
    cn = [[F() for _ in range(columns)] for _ in range(cells)]; ce = [F()] * cells
    cs = [F()] * (cells + 1); cx = cs.copy(); cr = cs.copy(); component = [F()] * cells
    signed = absolute = correction_sum = F(); correction_count = 0
    maxima = {key: F() for key in ('amount', 'energy', 'stretch', 'component')}
    modes = list(record['original_interfaces']); event_steps = {}; actual_corrections = []
    last_event = -math.inf
    constraint_by_cell=[F()]*cells; body_total=boundary_total=constraint_absolute_sum=F()
    global_maximum=F(); global_worst_index=0
    def volume(state):
        n=state['mechanical_stretches'];v0=number(case['grid']['half_thickness_m'])*number(case['grid']['reference_face_area_m2'])/cells
        return v0*number(n[-1])**2*sum(map(number,n[:-1]),F())
    limits = [number(ep[k]) for k in ('time_absolute_s','amount_absolute_mol','energy_absolute_j','temperature_absolute_k','pressure_absolute_pa')] + [st]
    event_fields = ('event_time_difference_s','common_amount_difference_mol','common_energy_difference_j','common_temperature_difference_k','common_pressure_difference_pa','stretch_difference')
    for ev in record['events']:
        cell = ev['cell_index']; check(type(cell) is int and 0 <= cell < cells, 'event cell')
        check(ev['time_s'] > last_event and modes[cell] == 'existing_liquid', 'event ordering/modes')
        last_event = ev['time_s']; modes[cell] = 'depleted_no_nucleation'
        matches = [i for i, ledger in enumerate(steps) if ledger == ev['terminal_panel'] and ledger['end_s'] == ev['time_s']]
        check(len(matches) == 1 and matches[0] not in event_steps, 'unique terminal ledger')
        index = matches[0]; event_steps[index] = ev
        check(states[index + 1]['amounts_mol'][cell][li] == 0, 'event exact zero')
        check(all(0 <= number(ev[k]) <= limit for k, limit in zip(event_fields, limits)), 'six event gates')
        refs = record['refinements']
        matches = [j for j, r in enumerate(refs) if r['status'] == 'comparison_pass' and r['event_time_s'] == ev['time_s'] and r['common_time_s'] == ev['common_time_s']]
        check(bool(matches), 'event refinement missing'); j = matches[-1]
        check(j > 0 and refs[j-1]['status'] == 'comparison_pass' and refs[j-1]['level'] + 1 == refs[j]['level'], 'two consecutive passes')
        check(refs[j-1]['event_time_s'] == ev['previous_time_s'], 'previous event binding')
        check(refs[j-1]['start_s'] == refs[j]['start_s'] and refs[j-1]['common_time_s'] == refs[j]['common_time_s'], 'same refinement root')
        check(j+1 < len(refs), 'independent pass missing'); fine = refs[j+1]
        check(fine['status'] == 'independent_approach_pass' and fine['approach_role'] == 'independent_halved_controls', 'independent pass')
        check(all(fine[key]==refs[j][key] for key in ('start_s','common_time_s','level')), 'independent same root/horizon/level')
        check(fine['approach_cap_s'] == refs[j]['approach_cap_s']/2 and fine['approach_safe_inventory_fraction'] == refs[j]['approach_safe_inventory_fraction']/2, 'halved controls')
        check(fine['comparison_details']['approach_grid_a_s'] != fine['comparison_details']['approach_grid_b_s'], 'distinct approach grids')
        combined = [max(number(a), number(b)) for a,b in zip(refs[j]['differences'], fine['differences'])]
        check(len(combined) == 6 and combined == [number(ev[k]) for k in event_fields], 'aggregate six differences')
        if ev['correction'] is not None: actual_corrections.append(ev['correction'])
    check(modes == record['final_interfaces'] and actual_corrections == record['corrections'], 'final modes/correction list')
    active = list(record['original_interfaces'])
    for k, ledger in enumerate(steps):
        before, after = states[k:k+2]
        check(ledger['start_s'] == times[k] and ledger['end_s'] == times[k+1] and times[k+1] > times[k], 'step clock')
        for state in (before, after):
            check(state['energy_model_identity'] == states[0]['energy_model_identity'], 'energy identity')
            check(len(state['mechanical_stretches']) == cells+1 and all(number(x)>0 for x in state['mechanical_stretches']), 'mechanical state')
            check(len(state['amounts_mol']) == cells and all(len(row)==columns and all(number(x)>=0 for x in row) for row in state['amounts_mol']), 'inventory shape/domain')
        dn = [[number(ledger['face_species_mol'][i][j])-number(ledger['face_species_mol'][i+1][j])+number(ledger['reaction_species_mol'][i][j]) for j in range(columns)] for i in range(cells)]
        du = [number(ledger['face_energy_j'][i])-number(ledger['face_energy_j'][i+1])+number(ledger['cell_work_j'][i]) for i in range(cells)]
        ev = event_steps.get(k); cor = ev['correction'] if ev else None
        if ev:
            cell = ev['cell_index']; raw = [[float(number(before['amounts_mol'][i][j])+dn[i][j]) for j in range(columns)] for i in range(cells)]
            expected = [row.copy() for row in raw]
            proof=ev['terminal_evidence'];clock=proof['clock']
            check(clock['time_absolute_s']==ep['time_absolute_s'], 'original affine clock time gate')
            check(clock['start_s']==times[k] and clock['end_s']==times[k+1], 'terminal clock ledger binding')
            h=number(clock['end_s'])-number(clock['start_s'])
            hm=number(clock['midpoint_s'])-number(clock['start_s'])
            check(0<hm<h, 'terminal affine midpoint')
            first=proof['initial_observation'];middle=proof['midpoint_observation']
            for observation,key in ((first,'liquid_rates_start_mol_s'),(middle,'liquid_rates_mid_mol_s')):
                rates=observation['rates']
                actual=[rates['face_species_mol_s'][cell][li],
                        -rates['face_species_mol_s'][cell+1][li],
                        rates['reaction_species_mol_s'][cell][li]]
                check(actual==clock[key], 'affine clock actual liquid rate samples')
            initial_evap=number(first['evaporation_mol_s'][cell])
            slope=(number(middle['evaporation_mol_s'][cell])-initial_evap)/hm
            cuts=[F(),h]
            if slope and 0<-initial_evap/slope<h: cuts.insert(1,-initial_evap/slope)
            gross=sum((initial_evap*(right-left)+slope*(right*right-left*left)/2
                       for left,right in zip(cuts,cuts[1:])
                       if initial_evap+slope*(left+right)/2>0),F())
            downward=float(gross)
            if number(downward)>gross: downward=math.nextafter(downward,-math.inf)
            check(ev['positive_evaporated_mol']==downward,'independent positive evaporation integral')
            check([float(number(before['internal_energy_j'][i])+du[i]) for i in range(cells)] == after['internal_energy_j'], 'terminal raw energy')
            check([float(number(x)+number(d)) for x,d in zip(before['mechanical_stretches'],ledger['stretch_increment'])] == after['mechanical_stretches'], 'terminal raw stretches')
            if cor:
                check((cor['cell_index'],cor['liquid_index'],cor['vapor_index']) == (cell,li,vi), 'correction indices')
                delta = number(raw[cell][li]); vapor = number(raw[cell][vi]); target = float(vapor+delta); residual = number(target)-vapor-delta
                check(delta>0 and raw[cell][li] == cor['liquid_before_mol'] and raw[cell][vi] == cor['vapor_before_mol'] and target == cor['vapor_after_mol'], 'raw correction binding')
                check(exact(cor['ideal_liquid_increment_mol']) == -delta and exact(cor['ideal_vapor_increment_mol']) == delta, 'paired ideal correction')
                check(exact(cor['actual_vapor_increment_mol']) == number(target)-vapor and exact(cor['vapor_storage_roundoff_mol']) == residual, 'vapor storage rounding')
                terms = [ledger['face_species_mol'][cell][li],-ledger['face_species_mol'][cell+1][li],ledger['reaction_species_mol'][cell][li]]
                local_limit = 4*sum((F(math.ulp(float(v))) for v in [before['amounts_mol'][cell][li],*terms,raw[cell][li]]),F())
                check(exact(cor['local_correction_limit_mol'])==local_limit, 'independent local ULP limit')
                check(exact(cor['panel_liquid_roundoff_mol'])==delta-number(before['amounts_mol'][cell][li])-sum(map(number,terms),F()), 'panel liquid rounding')
                clock = ev['terminal_evidence']['clock']; check(cor['clock_evidence']==clock, 'correction clock evidence')
                h = number(clock['end_s'])-number(clock['start_s']); hm=number(clock['midpoint_s'])-number(clock['start_s'])
                check(clock['start_s']==times[k] and clock['end_s']==times[k+1] and hm>0 and h>hm, 'affine clock interval')
                a=sum(map(number,clock['liquid_rates_start_mol_s']),F()); b=(sum(map(number,clock['liquid_rates_mid_mol_s']),F())-a)/(2*hm)
                inventory=number(before['amounts_mol'][cell][li]); residual_clock=inventory+h*a+h*h*b
                next_h=number(math.nextafter(clock['end_s'],math.inf))-number(clock['start_s'])
                check(residual_clock>=0 and inventory+next_h*a+next_h*next_h*b<0, 'adjacent downward affine clock root')
                bound=min(number(ep['time_absolute_s']),next_h-h)
                check(a<0 and a+2*b*next_h<0 and inventory+(h+bound)*a+(h+bound)**2*b<=0, 'clock monotonicity/time gate')
                check(exact(cor['numerical_clock_inventory_residual_mol'])==residual_clock, 'independent clock inventory residual')
                represented=number(target); neighbor=math.nextafter(target,math.inf if vapor+delta>represented else -math.inf)
                half=abs(number(neighbor)-represented)/2
                check(exact(cor['half_neighbor_spacing_mol'])==half and abs(residual)<=half, 'neighbor half ULP rounding')
                check(delta <= number(rp['correction_absolute_mol']) and delta <= number(ev['positive_evaporated_mol'])*number(rp['correction_fraction_evaporated']), 'local correction budgets')
                check(cor['positive_evaporated_mol']==ev['positive_evaporated_mol'], 'correction evaporation diagnostic')
                check(delta <= exact(cor['local_correction_limit_mol']) + exact(cor['numerical_clock_inventory_residual_mol']), 'local ULP plus clock allowance')
                signed += residual; absolute += abs(residual); correction_sum += delta; correction_count += 1
                for prefix, value in (('',abs(residual)),('cumulative_',absolute)):
                    check(value <= number(rp[prefix+'storage_absolute_mol']) and 2*value <= number(rp[prefix+'element_absolute_mol']) and value*number(rp['molar_mass_kg_mol']) <= number(rp[prefix+'mass_absolute_kg']), 'roundoff budgets')
                check(correction_sum <= number(rp['cumulative_correction_absolute_mol']), 'cumulative correction budget')
                expected[cell][li] = 0.; expected[cell][vi] = target
                dn[cell][li] -= delta; dn[cell][vi] += number(target)-vapor
            else: check(raw[cell][li] == 0, 'null correction requires exact raw zero')
            check(expected == after['amounts_mol'], 'full terminal raw/writeback endpoint')
            active[cell] = 'depleted_no_nucleation'
        for i in range(cells):
            if active[i] == 'depleted_no_nucleation': check(after['amounts_mol'][i][li] == 0, 'depleted mode remains zero')
            for j in range(columns):
                cn[i][j] += dn[i][j]
                errors = [abs(number(after['amounts_mol'][i][j])-number(before['amounts_mol'][i][j])-dn[i][j]), abs(number(after['amounts_mol'][i][j])-number(states[0]['amounts_mol'][i][j])-cn[i][j])]
                maxima['amount'] = max(maxima['amount'],*errors); check(max(errors)<=nt, 'amount prefix tolerance')
            ce[i] += du[i]
            errors = [abs(number(after['internal_energy_j'][i])-number(before['internal_energy_j'][i])-du[i]),abs(number(after['internal_energy_j'][i])-number(states[0]['internal_energy_j'][i])-ce[i])]
            maxima['energy'] = max(maxima['energy'],*errors); check(max(errors)<=et, 'energy prefix tolerance')
        components = ledger['cell_work_components_j']; check(set(components)=={'external_traction','mechanical_constraint','body'}, 'free work schema')
        boundary_total+=number(ledger['face_energy_j'][0])-number(ledger['face_energy_j'][-1])
        body_total+=sum(map(number,components['body']),F())
        constraint_absolute_sum+=abs(sum(map(number,components['mechanical_constraint']),F()))
        for i in range(cells):
            constraint_by_cell[i]+=number(components['mechanical_constraint'][i])
            residual = number(ledger['cell_work_j'][i])-sum((number(v[i]) for v in components.values()),F())
            check(residual == exact(ledger['component_sum_residual_j'][i]), 'component residual')
            component[i] += abs(residual); maxima['component'] = max(maxima['component'],component[i]); check(component[i]<=et, 'component cumulative budget')
        for i in range(cells+1):
            v = number(ledger['stretch_increment'][i]); q = exact(ledger['stretch_quadrature_roundoff'][i]); cs[i]+=v; cx[i]+=v-q; cr[i]+=abs(q)
            local = number(after['mechanical_stretches'][i])-number(before['mechanical_stretches'][i]); total = number(after['mechanical_stretches'][i])-number(states[0]['mechanical_stretches'][i])
            error = max(abs(local-v),abs(local-v+q),abs(total-cs[i]),abs(total-cx[i]),cr[i]); maxima['stretch']=max(maxima['stretch'],error); check(error<=st,'mechanical prefix tolerance')
        delta_energy=sum((number(a)-number(b) for a,b in zip(after['internal_energy_j'],states[0]['internal_energy_j'])),F())
        global_balance=delta_energy+number(case['mechanics']['external_pressure_pa'])*(volume(after)-volume(states[0]))-boundary_total-body_total
        if abs(global_balance)>global_maximum:global_maximum=abs(global_balance);global_worst_index=k+1
        water_errors=[abs(sum((number(after['amounts_mol'][i][j])-number(states[0]['amounts_mol'][i][j])-cn[i][j] for j in (li,vi)),F())) for i in range(cells)]
        check(max(water_errors)<=2*nt, 'combined water prefix ledger')
        report['prefixes'].append({'index':k+1,'time_s':times[k+1],
            'global_energy_residual_j':str(global_balance),
            'cumulative_absolute_constraint_sum_j':str(constraint_absolute_sum),
            'water_ledger_errors_mol':[str(v) for v in water_errors],
            'maxima':{name:str(value) for name,value in maxima.items()}})
        report['global_prefix_diagnostics']={'maximum_absolute_pressure_work_residual_j':str(global_maximum),'worst_state_index':global_worst_index,'cumulative_absolute_constraint_sum_j':str(constraint_absolute_sum),'constraint_worst_state_index':k+1,'registered_target_j':str(number(2e-8))}
    check([exact(v) for v in record['cumulative_amounts_mol']] == [v for row in cn for v in row], 'stored N totals')
    check([exact(v) for v in record['cumulative_energy_j']] == ce, 'stored E totals')
    check([exact(v) for v in record['cumulative_absolute_component_residual_j']] == component, 'stored component totals')
    totals = record['roundoff_totals']; check(totals['policy']==rp, 'roundoff original policy')
    check(F(totals['signed_storage_roundoff_mol'])==signed and F(totals['absolute_storage_roundoff_mol'])==absolute and F(totals['numerical_phase_correction_mol'])==correction_sum and totals['events']==correction_count,'stored correction totals')
    report.update(prefix_arithmetic='passed',steps=len(steps),events=len(record['events']),corrections=correction_count,maxima={k:{'exact':str(v),'float':float(v)} for k,v in maxima.items()},final_interfaces=record['final_interfaces'])
    delta_energy=sum((number(a)-number(b) for a,b in zip(states[-1]['internal_energy_j'],states[0]['internal_energy_j'])),F())
    balance=delta_energy+number(case['mechanics']['external_pressure_pa'])*(volume(states[-1])-volume(states[0]))-boundary_total-body_total
    target=number(2e-8)
    report['global_diagnostics']={'constraint_work_by_cell_j':[str(v) for v in constraint_by_cell], 'constraint_work_sum_j':str(sum(constraint_by_cell,F())), 'cumulative_absolute_crosscell_constraint_sum_j':str(constraint_absolute_sum), 'energy_plus_external_pressure_volume_minus_boundary_body_j':str(balance), 'registered_target_j':str(target), 'scope':'Fixed pre-result target 2e-8 J, unchanged from prior attempt; nonlinear p*deltaV quadrature difference includes truncation and is not a theorem of local ledger bounds.'}
    check(global_maximum<=target, 'registered global pressure-volume work target across all accepted prefixes')
    check(constraint_absolute_sum<=target, 'registered cumulative constraint cancellation target')
    check(record['status']=='completed' and times[-1]==case['numerics']['end_s'],'completed fixed horizon')
    check(number(record['elapsed_seconds'])<=number(policy['maximum_wall_seconds']),'completed wall budget')
    check(len(record['events'])>=1 and any(ev['time_s']<times[-1] for ev in record['events']),'event and continuation after event')
    report['acceptance']='passed'


def main():
    if len(sys.argv)!=2: raise SystemExit('usage: audit_prefix.py TERMINAL_RUN_DIRECTORY')
    directory=Path(sys.argv[1]).resolve()
    output=Path(__file__).resolve().parent/(directory.name+'-prefix-audit.json')
    check(output.parent!=directory,'audit output must not alter sealed run directory')
    report={'acceptance':'failed','qualification':'Saved accepted-prefix conservation arithmetic only; no endpoint re-certification, physical convergence or material validation.',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'input_sha256':{name:hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in ('case.json','depletion_result.json')}}
    try:
        audit(directory,report)
    except Exception as exc:
        report['failure']={'type':type(exc).__name__,'message':str(exc)}
    output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    check(report['acceptance']=='passed',str(report.get('failure')))


if __name__=='__main__':main()
