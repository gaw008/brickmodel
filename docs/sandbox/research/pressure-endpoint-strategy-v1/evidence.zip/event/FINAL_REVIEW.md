# Final saved event result review

APPROVE for this bounded manufactured event experiment. Read-only saved-data review; no EOS and no repeat execution of the independent prefix audit.

Process exited 0 without timeout after 67.896227417 s; integration reports 65.847477750 s. Actual raw record is completed with 30 accepted steps, 592 evaluations, 70 attempted panels, no rejected trials, and 24 attempted/completed paired endpoint calls. The original full interval [0.5, 0.50032] is retained. Events occur in cell 1 at 0.5002686445571594 and cell 0 at 0.5002848875613792; their common times are 0.5002772893672673 and 0.5002925481563298. Both final liquids are exactly zero, both modes are depleted_no_nucleation, and integration continues beyond both events.

Compared saved new case with the original repository case: only case ID and explicit numerical pressure strategy differ. All six saved comparison vectors (four successive comparisons and two independent-approach comparisons) satisfy the unchanged time/amount/energy/temperature/pressure/stretch gates of 1e-8 s, 1e-11 mol, 1e-7 J, 1e-5 K, 1e-4 Pa, and 1e-9. All six dimensions are retained; numerical acceleration did not substitute for the conditional paired-pressure model declaration or weaken those gates.

Raw depletion_result.json equals result.integration. Service and runner before/after runtime identities agree, and all 65 recorded current module SHA256 values independently match repository bytes. Runner reports read_run verification of 94 sealed artifacts. The previously reviewed audit script is byte-identical SHA256 287bc351617df55f534978648010c781128603a7dfe2d4480cef08af91135245, and its captured input hashes match actual case.json (9d930a6c6d60cf328e5abe2e61dc6a5f9f0cf06d9453827b84d0f0b56e5746f4) and depletion_result.json (bedbc34dd92537f6055a69a6c45e3249ae4d0b4512bb4aa4174199ba5a492903).

The retained independent audit reports all 30 prefixes passed, including per-cell amount/energy/stretch ledgers, correction gross/clock/writeback accounting, and cumulative constraint work. Re-reading its exact Fraction diagnostics gives maximum absolute global pressure-work residual 9.992741043332392e-11 J at prefix 24 and cumulative absolute cross-cell constraint sum 2.13932170860941e-20 J at prefix 30. Both retain the preregistered 2e-8 J target. This audit is saved arithmetic; it is not an independent endpoint EOS recertification or physical convergence certificate.

This run is substantially shorter than the previously retained baseline event run, but one ordered experiment is not a general performance guarantee. Matching evaluation/panel counts do not count every native EOS call. The manufactured shared-constant pressure assumption remains explicit and conditional at reported temperatures; the original generic error contract and failed earlier experiment are not retroactively validated. No real-material admission, spatial convergence, complete firing cycle, or overall Goal completion follows from this result.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — bounded recorded experiment and stated audit scope only.
