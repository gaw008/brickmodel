"""Passive saved JSON/Fraction audit only. No application or EOS imports."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,math,traceback
import xml.etree.ElementTree as ET

W=Path('/private/tmp/arlabosse-equilibrium-transport-v1')
OUT=W/'saved-review'
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
PKG=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
checks={}; extra={}; metrics={}
def hook(d):
    if set(d)=={'numerator','denominator'} and all(type(v) is int for v in d.values()):
        return F(d['numerator'],d['denominator'])
    return d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def water(states):return sum((F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]) for s in states),F())
def energy(states):return sum((F(s['internal_energy_j']) for s in states),F())
def mech(p):return p['fluid']['mechanical']
def temp(p):return mech(p)['temperature_k']
def moisture(f):return f.get('moisture_mol',F())
def fee(row):
    e=sum(map(abs,row['roundoff']['energy_j']),F())
    n=sum(map(abs,row['roundoff']['liquid_mol']),F())+sum((abs(v) for g in row['roundoff']['gas_mol'] for v in g),F())
    for f in row['faces']:
        e+=sum((abs(f.get(k,F())) for k in ('energy_decomposition_roundoff_j','moisture_enthalpy_projection_j','vapor_enthalpy_projection_j','heat_projection_j')),F())
        n+=abs(f.get('moisture_molar_projection_mol',F()))+abs(f.get('vapor_molar_projection_mol',F()))
    return e,n
def enc(v):
    if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
    raise TypeError(type(v).__name__)
try:
    a=read(W/'native01/INITIAL.json'); z=read(W/'native01/INITIALIZATION.json'); r=read(W/'native01/RUN_1.json')
    accepted=read(W/'native01/ACCEPTANCE.json'); inp=read(W/'native01/INPUTS.json')
    metadata=read(W/'supervised-native01/metadata.json'); status=read(W/'supervised-native01/status.json')
    checks.update(completed=r['status']=='completed',one_step=len(r['ledgers'])==1,
        physical_clock=r['times_s'][-1]==F(1),clock_starts_zero=r['times_s'][0]==0,
        complete_time_state_shape=len(r['times_s'])==len(r['states'])==2,
        complete_endpoint_observation_shape=len(r['observations'])==1,
        initialization_continuity=r['states'][0]==z['states'],raw_initialization_continuity=z['raw_states']==a['states'],
        complete_two_cell_shape=len(a['states'])==len(z['states'])==2 and all(len(x)==2 for x in r['states']),
        energy_budget=r['energy_roundoff_used_j']<=F(1e-8),inventory_budget=r['inventory_roundoff_used_mol']<=F(1e-12),
        material_not_qualified=r['material_qualified'] is False)
    rows=[z['ledger'],*r['ledgers']]; pairs=[(a['states'],z['states']),*zip(r['states'],r['states'][1:])]
    allowances=[];tbounds=[];mus=[];pres=[];local=[]
    for k,(row,(old,new)) in enumerate(zip(rows,pairs)):
        key=f'ledger_{k}_'; f=row['faces'];err=row['roundoff'];fl=row['flashes']
        dn=sum(err['liquid_mol'],F())+sum((g[2] for g in err['gas_mol']),F());du=sum(err['energy_j'],F())
        checks[key+'complete_shape']=(len(f)==3 and len(fl)==len(row['fixed_composition_rates']['cells'])==len(row['cells'])==2
            and len(row['exact_total_water_targets'])==len(row['exact_energy_targets'])==len(row['phase_water_mol'])==2
            and len(err['liquid_mol'])==len(err['gas_mol'])==len(err['energy_j'])==2 and all(len(g)==3 for g in err['gas_mol']))
        checks[key+'global_water']=water(new)-water(old)==f[0]['gas_mol'][2]-f[-1]['gas_mol'][2]+dn
        checks[key+'global_energy']=energy(new)-energy(old)==f[0]['energy_j']-f[-1]['energy_j']+du
        checks[key+'declared_balance_residuals']=row['water_balance_residual_mol']==row['energy_balance_residual_j']==0
        checks[key+'separate_heat_enthalpy_balance']=energy(new)-energy(old)==row['boundary_heat_j']-row['boundary_enthalpy_j']-row['boundary_energy_decomposition_j']+du
        fe,fn=fee(row)
        checks[key+'energy_cost_from_actual_components']=row['step_energy_roundoff_j']==fe
        checks[key+'inventory_cost_from_actual_components']=row['step_inventory_roundoff_mol']==fn
        extra[key+'boundary_fields']=row['boundary_water_mol']==f[-1]['gas_mol'][2] and row['boundary_heat_j']==-f[-1]['conduction_j'] and row['boundary_enthalpy_j']==sum(f[-1]['diffusive_enthalpy_j']+f[-1]['advective_enthalpy_j'],F()) and row['boundary_energy_decomposition_j']==f[-1]['energy_decomposition_roundoff_j']
        extra[key+'disabled_gas_and_carriers']=all(g==0 for face in f for g in face['gas_mol'][:2]) and all(face['gas_mol'][2]==0 for face in f[:-1])
        extra[key+'zero_phase_coefficients_observed']=all(c['phase']['phase_water_mol_s']==0 for c in row['fixed_composition_rates']['cells'])
        for i,(s,t,c,cell,v) in enumerate(zip(old,new,fl,row['fixed_composition_rates']['cells'],row['cells'])):
            tag=key+f'cell_{i}_'; inv=cell['inverse'];p=inv['point']; m=mech(p);phase=cell['phase'];eq=phase['equilibrium'];vap=v['actual_vapor']
            nc=F(s['liquid_water_mol'])+moisture(f[i])-moisture(f[i+1]);nv=F(s['gas_amounts_mol'][2])+f[i]['gas_mol'][2]-f[i+1]['gas_mol'][2]
            nt=nc+nv;u=F(s['internal_energy_j'])+f[i]['energy_j']-f[i+1]['energy_j'];j=nc-c['exact_liquid_mol']
            checks[tag+'targets_from_old_state_and_faces']=row['exact_total_water_targets'][i]==nt and row['exact_energy_targets'][i]==u
            checks[tag+'same_phase_integral']=row['phase_water_mol'][i]==j
            checks[tag+'nonnegative']=t['liquid_water_mol']>=0 and min(t['gas_amounts_mol'])>=0
            checks[tag+'carrier']=s['gas_amounts_mol'][:2]==t['gas_amounts_mol'][:2]
            checks[tag+'same_flash_state']=t==c['state']
            checks[tag+'exact_requested_total']=c['exact_liquid_mol']+c['exact_vapor_mol']==nt
            checks[tag+'two_water_projections']=c['liquid_projection_error_mol']==err['liquid_mol'][i] and c['vapor_projection_error_mol']==err['gas_mol'][i][2]
            checks[tag+'energy_projection_once']=row['target_energy_projection_j'][i]==err['energy_j'][i]
            checks[tag+'full_U_target']=t['internal_energy_j']==float(u)
            checks[tag+'equilibrium_certificate_unknown']=c['certified_temperature_error_bound_k'] is None
            checks[tag+'actual_inventory_binding']=m['liquid_inventory_mol']==t['liquid_water_mol'] and [m['gas_inventory_mol'][g] for g in ('O2','N2','H2O')]==t['gas_amounts_mol']
            ur=F(p['total_internal_energy_j'])-F(t['internal_energy_j']); allowance=abs(ur)+F(p['energy_error_j']);bound=F(inv['temperature_error_bound_k'])
            checks[tag+'actual_U_residual_binding']=inv['target_energy_j']==t['internal_energy_j'] and inv['energy_residual_j']==ur
            checks[tag+'full_U_allowance']=allowance<=F(1e-5)
            checks[tag+'conditional_T_certificate']=0<=bound<=F(1e-8)
            checks[tag+'conditional_T_bound_arithmetic']=allowance/F(p['minimum_heat_capacity_j_k'])<=bound
            checks[tag+'temperature_domain']=325<=temp(p)<=338
            checks[tag+'complete_pressure_domain']=90000<=F(m['pressure_pa'])-F(p['pressure_error_pa'])<=F(m['pressure_pa'])+F(p['pressure_error_pa'])<=110000
            checks[tag+'source_identity']=p['model_identity']==a['provenance']['base']['cells'][i]['model_identity']
            checks[tag+'chemical_point_binding']=v['fixed_composition_inverse']==inv and v['phase']==phase
            mu=math.fsum((eq['pure_equilibrium']['liquid']['chemical_potential_j_mol'],p['excess']['mu_ex_j_mol'],-vap['chemical_potential_j_mol']))
            dp=F(eq['equilibrium_partial_pressure_pa'])-F(phase['water_partial_pressure_pa'])
            checks[tag+'actual_mu_residual']=v['actual_chemical_residual_j_mol'] is not None and abs(v['actual_chemical_residual_j_mol'])<=1e-5
            checks[tag+'actual_vapor_point_binding']=vap['temperature_k']==temp(p) and vap['partial_pressure_pa']==phase['water_partial_pressure_pa']
            checks[tag+'full_mu_from_saved_actual_values']=mu==v['actual_chemical_residual_j_mol']
            checks[tag+'actual_peq_pv_residual']=v['equilibrium_pressure_residual_pa']==dp and abs(dp)<=F(1e-5)
            checks[tag+'no_equilibrium_certificate_upgrade']=v['certified_equilibrium_temperature_bound_k'] is None and v['equilibrium_composition_energy_error_j'] is None
            signed=(F(t['liquid_water_mol'])-(nc-j),F(t['gas_amounts_mol'][2])-(nv+j),F(t['internal_energy_j'])-u)
            extra[tag+'independent_single_projection']=(signed==(err['liquid_mol'][i],err['gas_mol'][i][2],err['energy_j'][i]) and signed[:2]==(F(t['liquid_water_mol'])-c['exact_liquid_mol'],F(t['gas_amounts_mol'][2])-c['exact_vapor_mol']))
            extra[tag+'actual_pv_activity']=phase['water_partial_pressure_pa']==float(F(t['gas_amounts_mol'][2])*F(m['gas_constant_j_mol_k'])*F(temp(p))/F(m['gas_volume_m3'])) and eq['equilibrium_partial_pressure_pa']==float(F(eq['pure_equilibrium']['equilibrium_partial_pressure_pa'])*F(p['excess']['activity']))
            base_u=float(F(p['fluid']['internal_energy_j'])+F(p['solid_internal_energy_j']))
            extra[tag+'full_U_reconstruction']=p['total_internal_energy_j']==float(F(base_u)+p['excess_internal_energy_j'])
            extra[tag+'W_and_reference']=0<=p['excess']['moisture_kg_water_per_kg_dry']<=F(.15) and vap['entropy_reference']==eq['pure_equilibrium']['liquid']['entropy_reference']
            extra[tag+'flash_policy_and_unknown']=c['policy']==z['flash_policies'][i] and c['counts']['provider_calls']<=500 and c['material_qualified'] is False and c['training_eligible'] is False and c['equilibrium_composition_energy_error_j'] is None and c['nominal_chemical_numerical_error_j_mol'] is None
            allowances.append(allowance);tbounds.append(bound);mus.append(mu);pres.append(dp)
            local.append({'ledger':k,'cell':i,'signed_projection':signed,'J_mol':j,'new_Nt_mol':F(t['liquid_water_mol'])+F(t['gas_amounts_mol'][2])})
    checks['initial_energy_cost']=z['energy_roundoff_used_j']==z['ledger']['step_energy_roundoff_j']
    checks['initial_inventory_cost']=z['inventory_roundoff_used_mol']==z['ledger']['step_inventory_roundoff_mol']
    checks['energy_cost_inherited_once']=r['energy_roundoff_used_j']==z['energy_roundoff_used_j']+sum((x['step_energy_roundoff_j'] for x in r['ledgers']),F())
    checks['inventory_cost_inherited_once']=r['inventory_roundoff_used_mol']==z['inventory_roundoff_used_mol']+sum((x['step_inventory_roundoff_mol'] for x in r['ledgers']),F())
    checks['inputs_unchanged']=all(sha(Path(p))==s for p,s in inp['inputs'].items())
    checks['driver_wall']=accepted['driver_seconds']<=80
    extra['exact_original_gate_set']=set(checks)==set(accepted['checks']) and len(checks)==128
    extra['original_saved_all_true']=accepted['passed'] is True and all(accepted['checks'].values())
    extra['embedded_initialization_and_endpoint']=r['initialization']==z and r['observations'][0]==r['ledgers'][0]['fixed_composition_rates'] and r['ledgers'][0]['origin_rates']['cells']==z['rates']['cells']
    extra['zero_prior_and_initialization_time']=z['prior_energy_roundoff_j']==z['prior_inventory_roundoff_mol']==0 and z['ledger']['duration_s']==0 and z['status']=='completed' and z['reason'] is None
    extra['raw_case']=a['states'][0]['gas_amounts_mol']==[.0000714,.0002686,1e-6] and a['states'][1]['gas_amounts_mol']==[.0000672,.0002528,1e-6] and [s['liquid_water_mol'] for s in a['states']]==[0.,.06] and [temp(p) for p in a['points']]==[330.,333.] and all(s['solid_mass_kg']==[.01] for s in a['states'])
    extra['construction_prefix']=all(read(W/'native01'/f'CONSTRUCTION_{j:02d}.json')=={'states':a['states'][:j],'points':a['points'][:j]} for j in (1,2))
    extra['resource_status']=0<=z['elapsed_seconds']<=40 and 0<=r['elapsed_seconds']<=40 and status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] is True and status['cleanup']['signal_errors']==[] and status['elapsed_s']<=105 and metadata['timeout_s']==100 and metadata['cleanup_grace_s']==5
    extra['no_failed_prefix_or_qualification_upgrade']=r['reason'] is None and r['failed_trial'] is None and z['failed_trial'] is None and all(x['training_eligible'] is False and x['material_qualified'] is False and x['certified_equilibrium_temperature_bound_k'] is None for x in (r,z)) and r['numerical_policy']['order']==1
    before={p:v['sha256'] for p,v in metadata['inputs_before'].items()};after=status['inputs_after']
    extra['all_supervised_inputs_unchanged']=status['inputs_unchanged'] is True and before==after
    extra['current_frozen_input_bytes']=all(sha(Path(p))==v['sha256'] and Path(p).stat().st_size==v['bytes'] for p,v in metadata['inputs_before'].items())
    freeze=read(W/'install/IDENTITY01.json')
    extra['186_source_installed_files']=len(freeze['members'])==freeze['package_files']==186 and freeze['python_modules']==179 and all(sha(ROOT/'src/sludge_sandbox'/n)==s==sha(PKG/n) for n,s in freeze['members'].items())
    extra['input_coverage']=all(str(p) in before for p in (W/'native_driver.py',W/'native_case.py',W/'implementation/equilibrium_transport.py',W/'NATIVE_PLAN01.md',ROOT/'src/sludge_sandbox/equilibrium_transport.py',PKG/'equilibrium_transport.py',ROOT/'data/sandbox/water/IAPWS95-2018.pdf',ROOT/'runs/sandbox/source-cache/makela2016/makela2016-accepted.pdf',ROOT/'runs/sandbox/source-cache/septien2020/fecal2019-original.xml'))
    extra['module_final_review_identity']=sha(PKG/'equilibrium_transport.py')=='f26eebf51c59988fce1f0b12d1f14c3cffa97e368e9f5525b9810f1a980aff07' and sha(W/'native_driver.py')=='1a4f6bc0ba8abd8d54917cee62e9ce960d7891da2ae401695d3139a9760eb5e5'
    suite=ET.parse(W/'install/INSTALLED_TESTS01.xml').getroot().find('testsuite')
    extra['installed_test_record']=int(suite.attrib['tests'])==12 and all(int(suite.attrib[k])==0 for k in ('errors','failures','skipped'))
    row=r['ledgers'][0];h=row['duration_s'];flow=row['origin_rates'];components=[]
    for f,q in zip(row['faces'],flow['faces']):
        ok=f['energy_j']==h*F(q['energy_w']) and f['conduction_j']==h*F(q['conduction_w']) and f['gas_mol']==[h*F(x) for x in q['gas_mol_s']] and f['diffusive_enthalpy_j']==[h*F(x) for x in q['diffusive_enthalpy_w']] and f['advective_enthalpy_j']==[h*F(x) for x in q['advective_enthalpy_w']]
        decomp=f['energy_j']-f['conduction_j']-sum(f['diffusive_enthalpy_j']+f['advective_enthalpy_j'],F())-f.get('moisture_enthalpy_j',F())
        ok=ok and f['energy_decomposition_roundoff_j']==decomp
        if 'moisture_mol' in f:
            ex=q['moisture_witness']['exchange']
            ok=ok and f['moisture_mol']==h*F(ex['molar_flow_mol_s']) and f['moisture_enthalpy_j']==h*F(ex['carried_energy_w']) and f['moisture_molar_projection_mol']==f['moisture_mol']-h*ex['exact_molar_flow_mol_s'] and f['moisture_enthalpy_projection_j']==f['moisture_enthalpy_j']-h*ex['exact_carried_energy_w']
        if 'vapor_molar_projection_mol' in f:
            ok=ok and f['vapor_molar_projection_mol']==f['gas_mol'][2]-h*q['exact_water_mol_s'] and f['vapor_enthalpy_projection_j']==f['diffusive_enthalpy_j'][2]-h*q['exact_carried_energy_w'] and f['heat_projection_j']==-f['conduction_j']-h*q['exact_heat_into_cell_w']
        components.append(ok)
    extra['same_origin_face_integrals_and_fees']=all(components)
    total_dn=sum((sum(x['roundoff']['liquid_mol'],F())+sum((g[2] for g in x['roundoff']['gas_mol']),F()) for x in rows),F());total_du=sum((sum(x['roundoff']['energy_j'],F()) for x in rows),F())
    extra['raw_to_final_cumulative_water_energy']=water(r['states'][-1])-water(a['states'])==-row['boundary_water_mol']+total_dn and energy(r['states'][-1])-energy(a['states'])==-row['faces'][-1]['energy_j']+total_du
    obs=read(W/'native01/OBSERVABLES.json')
    extra['saved_observables']=obs['final_temperature_k']==[temp(c['inverse']['point']) for c in r['observations'][-1]['cells']] and obs['final_pressure_pa']==[mech(c['inverse']['point'])['pressure_pa'] for c in r['observations'][-1]['cells']] and obs['outward_water_mol']==row['boundary_water_mol'] and obs['internal_energy_change_j']==energy(r['states'][-1])-energy(r['states'][0])
    metrics={'original_checks':len(checks),'additional_grouped_checks':len(extra),'input_count':len(before),'source_installed_files':186,'actual_top_level_calls':{'initialization':[z['evaluations_attempted'],z['evaluations_completed']],'integration':[r['evaluations_attempted'],r['evaluations_completed']]},'seconds':{'initialization':z['elapsed_seconds'],'integration':r['elapsed_seconds'],'driver':accepted['driver_seconds'],'supervisor':status['elapsed_s']},'emitted_water_mol':row['boundary_water_mol'],'initial_equilibrated_outer_vapor_mol':z['states'][-1]['gas_amounts_mol'][2],'emitted_over_initial_equilibrated_outer_vapor':float(row['boundary_water_mol']/F(z['states'][-1]['gas_amounts_mol'][2])),'Hout_J':row['boundary_enthalpy_j'],'Qin_J':row['boundary_heat_j'],'decomposition_J':row['boundary_energy_decomposition_j'],'delta_U_J':energy(r['states'][-1])-energy(r['states'][0]),'final_temperature_K':obs['final_temperature_k'],'final_pressure_Pa':obs['final_pressure_pa'],'maximum_U_allowance_J':float(max(allowances)),'maximum_fixed_composition_T_bound_K':float(max(tbounds)),'actual_full_mu_residuals_J_mol':mus,'actual_peq_pv_residuals_Pa':pres,'energy_fee_J':r['energy_roundoff_used_j'],'inventory_fee_mol':r['inventory_roundoff_used_mol'],'local_saved_arithmetic':local}
except Exception:
    extra['audit_exception']=False
    metrics['exception']=traceback.format_exc()
failed=[k for k,v in {**checks,**extra}.items() if not v]
result={'status':'PASS' if not failed else 'FAIL','failed':failed,'checks':checks,'additional':extra,'metrics':metrics,'limitations':['pure saved arithmetic; no EOS or model execution','one first-order 1 s macrostep only; no temporal/spatial convergence','fixed-composition temperature bounds exclude equilibrium-composition/log errors','materials/training unqualified; virtual LTE and selective boundary assumptions retained'],'script_sha256':sha(Path(__file__)),'saved_input_sha256':{n:sha(W/'native01'/n) for n in ('INITIAL.json','INITIALIZATION.json','RUN_1.json','ACCEPTANCE.json','INPUTS.json')}}
with (OUT/'SAVED_REVIEW01.json').open('x') as f:json.dump(result,f,default=enc,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':result['status'],'original_checks':len(checks),'additional_checks':len(extra),'failed':failed,'exception':metrics.get('exception')},ensure_ascii=False))
raise SystemExit(bool(failed))
