"""Bounded manufactured initialization-accounting test; no EOS.

The author's fixture supplies explicit mocked source/provider responses.
Only the new initialization/integration accounting path is exercised.
"""
from dataclasses import replace
from fractions import Fraction as F

from test_equilibrium_transport import setup, initialize
import equilibrium_transport as module


def test_modified_initialization_cannot_erase_accepted_prior_fees(setup):
    init = initialize(setup, prior_energy_roundoff_j=F(1,10**10),
                      prior_inventory_roundoff_mol=F(1,10**14))
    assert init.status == 'completed', init.reason
    original = module.integrate_equilibrium_transport(
        setup.column, init, duration_s=.1, steps=1,
        energy_roundoff_budget_j=1e-12, inventory_roundoff_budget_mol=1e-12)
    assert original.status == 'failed' and 'roundoff_budget' in original.reason
    assert not original.ledgers
    modified = replace(init, energy_roundoff_used_j=F(), inventory_roundoff_used_mol=F())
    try:
        result = module.integrate_equilibrium_transport(
            setup.column, modified, duration_s=.1, steps=1,
            energy_roundoff_budget_j=1e-12, inventory_roundoff_budget_mol=1e-12)
    except ValueError:
        return
    assert result.status != 'completed', (
        'an inconsistent initialization erased prior accepted charges and allowed '
        f'a lower budget; used={result.energy_roundoff_used_j}')
    assert not result.ledgers
