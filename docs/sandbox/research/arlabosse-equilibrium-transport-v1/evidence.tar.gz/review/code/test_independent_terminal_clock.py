"""Synthetic clock around real new-host control flow; mocked providers only."""
from test_equilibrium_transport import setup
import equilibrium_transport as module


def test_initialization_terminal_elapsed_cannot_exceed_its_completed_budget(setup, monkeypatch):
    original = module._config
    calls = 0
    terminal_reads = 0
    terminal = False

    def config(*args):
        nonlocal calls, terminal
        result = original(*args)
        calls += 1
        if calls == 2:
            terminal = True
        return result

    def clock():
        nonlocal terminal_reads
        if not terminal:
            return 0.
        terminal_reads += 1
        return 0. if terminal_reads == 1 else 2.

    monkeypatch.setattr(module, '_config', config)
    monkeypatch.setattr(module.time, 'monotonic', clock)
    result = module.initialize_equilibrium(setup.column, setup.states, setup.policies,
                                          maximum_wall_seconds=1.)
    assert not (result.status == 'completed' and result.elapsed_seconds > 1.), (
        f'status={result.status}, elapsed={result.elapsed_seconds}, budget=1.0')
