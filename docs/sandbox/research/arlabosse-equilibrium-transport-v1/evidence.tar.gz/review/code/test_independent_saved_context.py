"""Only the callback/context boundary and driver's passive encoder; no EOS."""
import ast
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from fractions import Fraction as F
import json
import math
from pathlib import Path

from test_equilibrium_transport import setup
import equilibrium_transport as module


def test_completed_flash_context_can_be_saved_without_live_providers(setup):
    # Extract only the pure encoder function; never execute the native driver.
    script = Path('/private/tmp/arlabosse-equilibrium-transport-v1/native_driver.py')
    parsed = ast.parse(script.read_text())
    function = next(n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == 'encode')
    env = {'F': F, 'is_dataclass': is_dataclass, 'fields': fields,
           'FlashFailure': module.FlashFailure, 'Mapping': Mapping, 'math': math}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(script), 'exec'), env)
    object.__setattr__(setup.column.base.chemical, 'method_id', 'manufactured:chemical-method')
    runner = module._Runner(setup.column, setup.policies, 1., 1e-8, 1e-12,
                            None, F(), F())
    runner.trial = module.EquilibriumTrial('callback_context', setup.states)
    returned = object()
    actual = runner.call('flash', lambda *args: returned,
                         setup.column.storages[0], setup.column.base.chemical,
                         F(1,100), (.001,.003), 1., setup.policies[0])
    assert actual is returned
    # The raw returned object is deliberately not encoded: it is a seam sentinel.
    # A saved context must contain metadata/arguments, not the live source graph.
    encoded = env['encode'](runner.trial.last_completed_provider_context)
    json.dumps(encoded, allow_nan=False)
