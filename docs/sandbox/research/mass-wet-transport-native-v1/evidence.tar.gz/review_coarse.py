"""Independent coarse saved evidence checks. No imports of model or frozen audit."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
H=Path(__file__).parent;A=H/'coarse'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def f(v):return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)
def tree(p):
 result={}
 for q in p.rglob('*'):
  assert not q.is_symlink()
  if q.is_file():result[q.relative_to(p).as_posix()]=sha(q)
 return result
freeze=read(H/'freeze.json');runtime=read(A/'runtime-before.json');case=read(H/'inputs/case.json');report=read(A/'report.json')
assert sha(H/'freeze.json')==report['freeze_sha256']=='3f144deee3eb0cbbf9f8aac4c1b3a0aff380dbe3d8e37b376f310dd991c3856c'
assert runtime==read(A/'runtime-after.json')==freeze['runtime'] and len(runtime['modules'])==90
assert tree(H/'inputs')==freeze['files']==read(A/'inputs-before.json')==read(A/'inputs-after.json')
for n,d in freeze['scripts'].items():assert sha(H/n)==d
assert case==read(H/'CASE.json')
env=read(A/'environment.json');assert {p.name:sha(p) for p in Path(env['package']).glob('*.py')}==runtime['modules']
r=read(A/'run-result.json');initial=read(A/'initial.json');storage=read(A/'storage-inputs.json');pair=read(A/'pair-inputs.json');water=read(A/'water-provider.json');vapor=read(A/'vapor-provider.json')
assert pair['storages']==[storage,storage] and pair['_identity']==report['pair_identity']
assert pair['chemical']['water']==pair['chemical']['vapor']['_water']==water==vapor['_water']==storage['fluid_template']['mechanical']['water']
assert pair['chemical']['vapor']['reference']==vapor['reference']
for k in ('rate_constants_per_s','oxygen_references_mol','transfer_coefficients_mol_s_pa','coefficient_source_ids','face'):assert pair[k]==case[k]
assert pair['inverse_policies']==[case['inverse_policy']]*2
assert r['states'][0]==initial and len(r['states'])==len(r['times_s'])==5 and len(r['ledgers'])==len(r['observations'])==4
assert r['status']=='completed' and r['reason'] is None and r['evaluations_attempted']==r['evaluations_completed']==12
assert r['elapsed_seconds']<=case['maximum_wall_seconds']==150.
for i,s in enumerate(initial):
 values=case['initial_cells'][i];p=read(A/('initial-forward-'+str(i)+'.json'));proto=read(A/('initial-prototype-'+str(i)+'.json'))
 assert all(s[k]==v for k,v in values.items()) and s==dict(proto,internal_energy_j=p['total_internal_energy_j'])
 assert p['fluid']['mechanical']['temperature_k']==case['initial_temperatures_k'][i]
 assert p['model_identity']==s['energy_model_identity']==storage['_identity']
 # Initial total energy is its actual fluid U plus exact kg-reference terms.
 terms=sum((F(m)*(f(h)+F(cp)*(F(case['initial_temperatures_k'][i])-F(case['reference_temperature_k']))-F(case['reference_pressure_pa'])*F(v)) for m,h,cp,v in zip(s['solid_mass_kg'],storage['reference']['particular_h0_j_kg'],case['solid_cp_j_kg_k'],case['solid_volume_m3_kg'])),F())
 assert float(F(p['fluid']['internal_energy_j'])+terms)==p['total_internal_energy_j']
masses=[F(storage['fluid_template']['gas_phases'][k]['molar_mass_kg_mol']) for k in case['gas_ids']]
def total(rows):
 C=O=N=Hy=mass=water=U=F()
 for s in rows:
  ma,mb=map(F,s['solid_mass_kg']);no,nn,nw=map(F,s['gas_amounts_mol']);nl=F(s['liquid_water_mol']);mw=(nl+nw)*masses[2]
  assert min(ma,mb,no,nn,nw)>=0 and nl>0
  C+=ma+mb/2;O+=mb/2+no*masses[0]+mw*F(5333,6005);N+=nn*masses[1];Hy+=mw*F(672,6005)
  mass+=ma+mb+no*masses[0]+nn*masses[1]+mw;water+=nl+nw;U+=F(s['internal_energy_j'])
 return [C,O,N,Hy],mass,water,U
original=total(initial);mx={k:F() for k in case['prefix_gates']};worst={k:0 for k in mx};ss=[[F(),F()] for _ in initial];gs=[[F(),F(),F()] for _ in initial];ls=[F(),F()];es=[F(),F()]
def gate(key,value,index):
 value=abs(value)
 if value>mx[key]:mx[key]=value;worst[key]=index
 assert value<F(case['prefix_gates'][key]),(key,index,value)
for index,(rows,l,obs) in enumerate(zip(r['states'][1:],r['ledgers'],r['observations']),1):
 assert f(l['duration_s'])==F(.01)/4 and f(r['times_s'][index])==F(.01)*index/4
 el,m,w,u=total(rows);gate('global_elements_kg',max(abs(a-b) for a,b in zip(el,original[0])),index)
 for k,a,b in [('global_mass_kg',m,original[1]),('global_water_mol',w,original[2]),('global_energy_j',u,original[3])]:gate(k,a-b,index)
 gate('face_components_j',F(l['face_energy_j'])-F(l['conduction_j'])-sum(map(F,l['diffusive_enthalpy_j']),F())-sum(map(F,l['advective_enthalpy_j']),F()),index)
 assert obs['conduction_w']!=0 and any(v!=0 for v in obs['exchange']['advective_mol_s'].values()) and any(v!=0 for v in obs['exchange']['diffusive_mol_s'].values())
 for i,sign in enumerate((-1,1)):
  s=rows[i];prev=r['states'][index-1][i];cell=obs['cells'][i];inv=cell['inverse'];p=inv['point'];mech=p['fluid']['mechanical']
  assert p['model_identity']==s['energy_model_identity']==storage['_identity']
  assert inv['target_energy_j']==s['internal_energy_j'] and mech['liquid_inventory_mol']==s['liquid_water_mol'] and mech['gas_inventory_mol']==dict(zip(case['gas_ids'],s['gas_amounts_mol']))
  assert abs(F(p['total_internal_energy_j'])-F(s['internal_energy_j']))+F(p['energy_error_j'])<=F(case['inverse_policy']['energy_tolerance_j'])
  assert inv['temperature_error_bound_k']<=case['inverse_policy']['temperature_tolerance_k'] and case['temperature_domain_k'][0]<=mech['temperature_k']<=case['temperature_domain_k'][1]
  assert cell['extent_kg_s']>0 and cell['phase_water_mol_s']>0 and cell['entropy_production_w_k']>=0 and l['chemical_gas_mol'][i][2]==0
  ls[i]-=F(l['phase_water_mol'][i]);es[i]+=sign*F(l['face_energy_j'])
  gate('local_liquid_mol',F(s['liquid_water_mol'])-F(initial[i]['liquid_water_mol'])-ls[i],index);gate('local_energy_j',F(s['internal_energy_j'])-F(initial[i]['internal_energy_j'])-es[i],index)
  assert s['liquid_water_mol']==float(F(prev['liquid_water_mol'])-F(l['phase_water_mol'][i])) and s['internal_energy_j']==float(F(prev['internal_energy_j'])+sign*F(l['face_energy_j']))
  for j in range(2):
   ss[i][j]+=F(l['solid_kg'][i][j]);gate('local_solid_kg',F(s['solid_mass_kg'][j])-F(initial[i]['solid_mass_kg'][j])-ss[i][j],index)
   assert s['solid_mass_kg'][j]==float(F(prev['solid_mass_kg'][j])+F(l['solid_kg'][i][j]))
  for j in range(3):
   d=F(l['chemical_gas_mol'][i][j])+sign*F(l['face_mol'][j])+(F(l['phase_water_mol'][i]) if j==2 else F())
   gs[i][j]+=d;gate('local_gas_mol',F(s['gas_amounts_mol'][j])-F(initial[i]['gas_amounts_mol'][j])-gs[i][j],index)
   assert s['gas_amounts_mol'][j]==float(F(prev['gas_amounts_mol'][j])+d)
assert f(r['times_s'][-1])==F(case['duration_s'])
saved=read(A/'prefix-audit.json')
for k,v in mx.items():assert v==f(saved['maxima'][k]) and worst[k]==saved['worst_prefix_index'][k]
supervised=read(H/'supervised-coarse/status.json');assert supervised['returncode']==0 and supervised['status']=='complete' and supervised['cleanup']['leader_reaped'] and supervised['inputs_unchanged']
out={'status':'passed_independent_saved_coarse_review','freeze_sha256':sha(H/'freeze.json'),'run_sha256':sha(A/'run-result.json'),'prefixes':4,'evaluations':12,'runtime_modules':90,'maxima_exact':{k:{'numerator':v.numerator,'denominator':v.denominator} for k,v in mx.items()},'maxima_float':{k:float(v) for k,v in mx.items()},'worst_prefix_index':worst,'integration_elapsed_seconds':r['elapsed_seconds'],'runner_elapsed_seconds':report['elapsed_s'],'supervisor_elapsed_seconds':supervised['elapsed_s'],'qualification':'Saved initial/endpoint/source and all-prefix Fraction accounting; no fresh EOS or unsaved midpoint reconstruction; fine remains unrun.'}
(H/'independent-coarse-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
