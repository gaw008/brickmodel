# Independent coarse native result review

APPROVE coarse evidence and proceeding to the already registered fine phase, with no changes to the 180 s outer / 150 s inner budgets. The independent review_coarse.py ran using only standard-library JSON/Fraction/hash operations, without calling the frozen audit_prefix.py, importing the model, querying EOS or changing frozen files. independent-coarse-review.json/log retain exact maxima, worst indices and input hash.

Verified complete frozen-input membership, script/CASE identity and freeze 3f144deee3eb0cbbf9f8aac4c1b3a0aff380dbe3d8e37b376f310dd991c3856c. Saved runtime before/after and all 90 actual installed Python module bytes agree. Pair/storage/liquid/ideal-vapor/chemical provider descriptions agree; all registered kinetic/phase/face and inverse parameters match CASE. Both initial kg/Nl/Ng arrays and 300/305 K forward initialization are bound to the saved initial states, including independent reconstruction of their total U from actual fluid U plus kg-solid reference/Cp/p_ref*v terms.

Full coarse run 8352231506580cead726a41e25442c5de77d8ebbcb64e5a2f8e496f85b0e4d18 has 5 states, 4 complete ledgers/endpoint observations, exact .01 s duration, 12 attempted and 12 completed host evaluations. Every accepted prefix was independently recomputed relative to the original two states. Element accounting uses explicitly derived A/B/O2/N2/H2O mass shares, rather than trusting the generic saved element-total report. Each represented kg/liquid/gas/U update, chemical-water zero, shared face signs and phase conversion were checked. Endpoint inverse target/inventories/identity and original inverse energy-plus-error and temperature bounds pass. Both cells retain positive liquid and show positive reaction and evaporation with nonnegative entropy diagnostics; diffusion, Darcy and conduction are nonzero.

All nine original prefix gates pass and every maximum/worst index exactly matches the separately saved runner audit. Max global element residual 1.7076184216646695e-18 kg, mass 1.440789256035237e-18 kg, total water 3.686287386450715e-18 mol; global U residual is exactly zero for each represented prefix. Max local energy residual 2.530198273120732e-13 J and face component residual 8.405277342193873e-17 J. These do not justify loosening the registered thresholds or treating the source envelope as certified physical uncertainty.

Actual supervisor completed, returncode0, leader_reaped true and unchanged inputs. Timings are distinct: integration64.53569666697877 s; child runner65.84029304099386 s; supervisor66.07039470798918 s. Fine remains a new, separately supervised 8-step run at unchanged inputs/limits; extrapolating runtime is not a guarantee of success.

Scope remains saved initial/endpoint association and all-prefix accounting. No fresh EOS or unsaved midpoint RHS reconstruction was performed. This is a positive-liquid manufactured-parameter trajectory, not wet-to-dry events, spatial convergence or real-material admission. Fine must pass independently; coarse approval does not pre-approve its eventual result.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE bounded coarse result and proceeding under the existing fine plan.
