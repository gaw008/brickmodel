"""Synthetic saved-data and stdlib utilities only; no model import/EOS."""
import importlib.util,json,copy,tempfile,unittest
from pathlib import Path
from fractions import Fraction as F
H=Path(__file__).parent
spec=importlib.util.spec_from_file_location('wet_native_runner',H/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from audit_prefix import audit
class Utilities(unittest.TestCase):
 def test_case_matches_file_and_original_gates(self):
  self.assertEqual(m.CASE,json.loads((H/'CASE.json').read_text()))
  self.assertEqual(m.CASE['step_counts'],{'coarse':4,'fine':8});self.assertEqual(m.CASE['maximum_wall_seconds'],150.)
  self.assertEqual(m.CASE['inverse_policy']['energy_tolerance_j'],1e-5);self.assertEqual(m.CASE['pressure_domain_pa'],[1e4,1e7])
 def test_failed_json_write_preserves_original(self):
  with tempfile.TemporaryDirectory() as name:
   p=Path(name)/'out';m.save(p,{'first':1})
   with self.assertRaises(ValueError):m.save(p,{'bad':float('inf')})
   self.assertEqual(m.read(p),{'first':1})
 def example(self):
  # Zero-flux synthetic ledger tests audit wiring, not physical host behavior.
  case=copy.deepcopy(m.CASE);ident='a'*64
  states=[dict(s,internal_energy_j=1000.,energy_model_identity=ident) for s in case['initial_cells']]
  gases=case['gas_ids'];components=[{'component_id':n,'element_mass_fractions':[1,0] if n=='A' else [0,1]} for n in ['A','B',*gases]]
  storage={'_identity':ident,'fluid_template':{'mechanical':{'gas_species_ids':gases},'gas_phases':{k:{'molar_mass_kg_mol':.02} for k in gases}},'reference':{'network':{'elements':['X','Y'],'components':components}}}
  ledger={'duration_s':{'numerator':F(.01).numerator,'denominator':F(.01).denominator},'solid_kg':[[0.,0.]]*2,'chemical_gas_mol':[[0.,0.,0.]]*2,'phase_water_mol':[0.,0.],'face_mol':[0.,0.,0.],'conduction_j':0.,'diffusive_enthalpy_j':[0.,0.,0.],'advective_enthalpy_j':[0.,0.,0.],'face_energy_j':0.}
  cells=[{'entropy_production_w_k':0.,'inverse':{'target_energy_j':s['internal_energy_j'],'point':{'model_identity':ident,'fluid':{'mechanical':{'liquid_inventory_mol':s['liquid_water_mol'],'gas_inventory_mol':dict(zip(gases,s['gas_amounts_mol']))}}}}} for s in states]
  run={'status':'completed','states':[states,copy.deepcopy(states)],'times_s':[0,ledger['duration_s']],'ledgers':[ledger],'observations':[{'cells':cells}]}
  return run,states,storage,case
 def test_synthetic_prefix_shapes_and_values(self):
  args=self.example();out=audit(*args,requested_steps=1);self.assertEqual(out['accepted_prefixes'],1)
  args[0]['states'][1][0]['internal_energy_j']+=1.
  with self.assertRaises(ValueError):audit(*args,requested_steps=1)
 def test_changed_initial_and_missing_water_source_rejected(self):
  args=self.example();args[3]['initial_cells'][0]['liquid_water_mol']=.03
  with self.assertRaises(ValueError):audit(*args,requested_steps=1)
  args=self.example();args[0]['ledgers'][0]['chemical_gas_mol'][0][2]=1e-20
  with self.assertRaises(ValueError):audit(*args,requested_steps=1)
if __name__=='__main__':unittest.main()
