# Actual HEOS positive-liquid mixed transport: fixed prospective plan

This is the B positive-liquid stage, not wet-to-dry event support. Root alone installs/prepares/executes after independent review. No native calls, package installation or preparation have occurred while these scripts are authored. A's original unstable 1000 Pa attempt remains failed; the present constructor preserves successful v2's stable 10000..10000000 Pa domain and 295..310 K range.

## Fixed physical and numerical inputs

CASE.json is authoritative and also literal-checked in run.py. Original manufactured solid A/B Cp1000/1200 J/(kg K), volume.001/.0005 m3/kg, reference300 K/100000 Pa, reaction(-1,2,-1,0,0) with -200000 J/kg extent, O2/N2 Cp30/29 and actual source-bound ideal-water caloric remain. Water chemical coefficient is zero. Each cell bulk volume is.001m3. Initial temperatures300/305 K; solids(.01,0)/(.007,.002)kg; liquid.02 mol each; O2/N2/H2O(.2,.2,.001)/(.08,.25,.001)mol. Initial U is independently initialized by each actual storage forward at its registered temperature, then all stages evolve U rather than prescribed T.

Both inverse policies retain v2 1e-5J/1e-4K/max100. Pressure policy remains1e-12m3/1e-5Pa/max100. Original numerical envelope remains liquid U1e-8J/mol, v1e-16m3/mol, |du/dp|1e-4J/(mol Pa), gas U1e-9J/mol and Cv lower20J/(mol K). Those declarations are not certified water/model accuracy bounds.

B source/test coefficients retained: reaction rates(.2,.2)/s, O2 references(.2,.2)mol, phase coefficients(1e-8,1e-8)mol/(s Pa). Shared face area.01m2, half widths(.05,.05)m, conductivities(.5,.7), explicit three diffusivities(1e-5,2e-5,1.5e-5)m2/s, permeability1e-13m2 and viscosity1.8e-5Pa s. These are manufactured parameters, not fitted sludge data. Actual WaterChemicalPotential uses the same HEOS source/type/implementation/reference as liquid and IdealWaterVapor; no analytic-liquid seam or synthetic chemical tag.

## Two separately supervised meshes

Coarse: duration.01s,4 fixed midpoint steps. Fine: same original state/duration,8 steps. Each separate process has an inner150s integration wall budget and external180s watchdog with.1s cleanup. Inner checks cannot interrupt native calls; external process supervision is essential. Outer time includes provider initialization and output/audit overhead. Budget estimate uses earlier actual wet forward/inverse costs and two-cell/three-stage scaling; it is not a completion prediction or permission to extend limits.

Run coarse first. Fine requires coarse terminal return0, reaped leader and passed report; its full parent files plus supervisor status are externally hash-bound and checked before/after fine. No automatic next phase/retry, source or installation changes between meshes. Any failure or temperature-domain exit is saved under the original input. Root must diagnose a separately registered correction before retrying; do not tune rates, inventories or gates inside this experiment.

## Frozen files and evidence

Prepare after root applies and installs the independently reviewed B. Runtime verifies every actual installed module against repository and runtime metadata (expected new count90, recorded actual count, no fictitious old/new identity). Only installed package imports with PYTHONPATH absent; no temporary candidate overlay. Copy original16 approved water assets, all source-bound CIAAW convention files, tracked gas-mass facts, all installed modules and fixed CASE; hash full membership. Freeze script/audit/PLAN/CASE and pinned research supervisor, plus runtime versions and original/copy source hashes. Recheck before/after each mesh. External full-source assets must be excluded from distributable archives; preserve identity instead.

Raw outputs include full source-bound storage and pair, both initial prototypes and forward points, original states, complete WetRun with every kg/Nl/Ng/U state, exact time, ledger, endpoint inverse/phase/face observation, attempted/completed host counts and inner time. These host counts are not an independent native EOS-call journal. Save returned raw run and core failure outcome BEFORE audit/completion assertions. Later integrity failure is distinct from original failure. Forced termination can prevent a final JSON; the supervisor's retained status remains authoritative.

## Original prefix gates, no endpoint cancellation

The independent standard-library Fraction audit uses every accepted prefix relative to the original state. B's existing gates are unchanged: global element mass2e-15kg, total mass2e-15kg, total water2e-15mol, totalU2e-10J; local solid1e-16kg, liquid/gas1e-15mol, U1e-10J; face energy component sum1e-12J. It verifies each represented update, phase liquid−/gas-water+ once, no chemical water source, shared face−/+ once, endpoint inverse target/inventory association, and nonnegative entropy-production diagnostics. Explicit positive liquid is required at all saved states; no clipping or artificial replenishment.

All requested steps and exact final duration plus attempted=completed=3*steps are required for success. A failed run's retained prefix may pass arithmetic but must remain a failed/incomplete experiment. Audit is saved-ledger consistency, not a reconstruction of unsaved midpoint RHS or independent fresh EOS evaluation. Native B source gates remain active. Endpoint coarse/fine differences are saved descriptively without claiming independent-oracle agreement, temporal order, spatial convergence or material qualification. Completing this plan still does not supply dry modes, depletion events or a firing cycle.

## Root commands after approval/install

Use /private/tmp/brick-water-backend-probe/venv/bin/python, PYTHONPATH unset:

```
python run.py prepare --module-sha256 <approved mass_wet_transport.py hash>
python supervise.py --attempt coarse --freeze-sha256 <actual freeze hash>
python supervise.py --attempt fine --freeze-sha256 <same freeze hash>
```
