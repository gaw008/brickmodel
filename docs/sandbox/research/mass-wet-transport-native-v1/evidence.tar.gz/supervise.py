"""Root launches one registered mesh only, after independent review/freeze."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
SOURCE=Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/research-process-supervisor/supervisor.py')
EXPECTED='939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1'
PYTHON='/private/tmp/brick-water-backend-probe/venv/bin/python'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--freeze-sha256',required=True);p.add_argument('--attempt',choices=('coarse','fine'),required=True);a=p.parse_args()
    if sha(SOURCE)!=EXPECTED or sha(HERE/'freeze.json')!=a.freeze_sha256:raise ValueError('authoritative_freeze_or_supervisor_changed')
    frozen=json.loads((HERE/'freeze.json').read_bytes())
    if frozen['status']!='FROZEN' or frozen['timeout_s']!=180. or frozen['cleanup_grace_s']!=.1:raise ValueError('registered_supervision_required')
    for n,d in frozen['scripts'].items():
        if sha(HERE/n)!=d:raise ValueError('reviewed_script_changed')
    cmd=[PYTHON,str(HERE/'run.py'),'run','--freeze-sha256',a.freeze_sha256,'--attempt',a.attempt]
    inputs=[SOURCE,HERE/'freeze.json']+[HERE/n for n in frozen['scripts']]+[HERE/'inputs'/n for n in frozen['files']]
    if a.attempt=='fine':
        # Freeze the complete prior evidence, not just its success label.
        parent={p.relative_to(HERE).as_posix():sha(p) for p in (HERE/'coarse').rglob('*') if p.is_file()}
        status=HERE/'supervised-coarse/status.json';parent[status.relative_to(HERE).as_posix()]=sha(status)
        s=json.loads(status.read_bytes())
        if s['status']!='complete' or s['returncode']!=0 or s['cleanup']['leader_reaped'] is not True:raise ValueError('coarse_not_successfully_terminal')
        cmd+=['--parent-hashes-json',json.dumps(parent,sort_keys=True)];inputs.extend(HERE/n for n in parent)
    spec=importlib.util.spec_from_file_location('reviewed_wet_trajectory_supervisor',SOURCE);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    result=m.run_attempt(HERE/('supervised-'+a.attempt),cmd,cwd='/private/tmp',input_paths=inputs,timeout_s=180.,cleanup_grace_s=.1)
    print(json.dumps(result,indent=2))
    if result['returncode']!=0:raise SystemExit(1)
