"""Saved Fraction accounting only, no model imports or EOS; failed scope explicit."""
from fractions import Fraction as F

def fraction(value):
    return F(value['numerator'],value['denominator']) if isinstance(value,dict) else F(value)
def require(ok,reason):
    if not ok:raise ValueError(reason)
def audit(run,initial,storage,case,*,requested_steps):
    states=run['states'];ledgers=run['ledgers'];observations=run['observations'];times=run['times_s']
    require(len(states)==len(times)==len(ledgers)+1 and len(observations)==len(ledgers),'complete_prefix_lengths')
    require(states[0]==initial and len(initial)==2,'original_initial_binding')
    require(len(ledgers)<=requested_steps and fraction(times[0])==0,'registered_prefix')
    for s,v in zip(initial,case['initial_cells']):
        require(s['solid_mass_kg']==v['solid_mass_kg'] and s['liquid_water_mol']==v['liquid_water_mol'] and s['gas_amounts_mol']==v['gas_amounts_mol'],'registered_initial_inventories')
    model=storage['_identity'];gas_ids=storage['fluid_template']['mechanical']['gas_species_ids'];require(gas_ids==case['gas_ids']==['O2','N2','H2O'],'full_gas_layout')
    masses=[F(storage['fluid_template']['gas_phases'][k]['molar_mass_kg_mol']) for k in gas_ids]
    components=storage['reference']['network']['components'];elements=storage['reference']['network']['elements']
    require(len(components)==5 and [c['component_id'] for c in components]==['A','B',*gas_ids],'reference_layout')
    def totals(rows):
        elemental=[F() for _ in elements];mass=water=energy=F()
        for s in rows:
            require(s['energy_model_identity']==model and len(s['solid_mass_kg'])==2 and len(s['gas_amounts_mol'])==3,'state_binding_shape')
            values=[*map(F,s['solid_mass_kg']),*(F(n)*m for n,m in zip(s['gas_amounts_mol'],masses))]
            require(s['liquid_water_mol']>0 and all(v>=0 for v in values),'positive_inventory_required')
            values[-1]+=F(s['liquid_water_mol'])*masses[-1]
            for value,c in zip(values,components):
                require(len(c['element_mass_fractions'])==len(elements),'element_shape')
                for j,f in enumerate(c['element_mass_fractions']):elemental[j]+=value*fraction(f)
            mass+=sum(values,F());water+=F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]);energy+=F(s['internal_energy_j'])
        return elemental,mass,water,energy
    original=totals(initial);gates=case['prefix_gates'];maxima={k:F() for k in gates};worst={k:0 for k in gates}
    cs=[[F(),F()] for _ in range(2)];cg=[[F(),F(),F()] for _ in range(2)];cl=[F(),F()];ce=[F(),F()]
    def check(name,value,index):
        value=abs(value)
        if value>maxima[name]:maxima[name]=value;worst[name]=index
        require(value<F(gates[name]),'original_prefix_gate:'+name+':'+str(index))
    for index,(row,obs,l) in enumerate(zip(states[1:],observations,ledgers),1):
        require(fraction(l['duration_s'])==F(case['duration_s'])/requested_steps and fraction(times[index])==index*fraction(l['duration_s']),'exact_mesh_binding')
        el,m,w,e=totals(row)
        check('global_elements_kg',max(abs(a-b) for a,b in zip(el,original[0])),index)
        for key,a,b in [('global_mass_kg',m,original[1]),('global_water_mol',w,original[2]),('global_energy_j',e,original[3])]:check(key,a-b,index)
        require(len(l['solid_kg'])==len(l['chemical_gas_mol'])==len(l['phase_water_mol'])==2 and len(l['face_mol'])==len(l['diffusive_enthalpy_j'])==len(l['advective_enthalpy_j'])==3,'ledger_full_shape')
        require(len(obs['cells'])==2,'observation_shape')
        check('face_components_j',F(l['face_energy_j'])-F(l['conduction_j'])-sum(map(F,l['diffusive_enthalpy_j']),F())-sum(map(F,l['advective_enthalpy_j']),F()),index)
        for i,sign in enumerate((-1,1)):
            require(len(l['solid_kg'][i])==2 and len(l['chemical_gas_mol'][i])==3 and l['chemical_gas_mol'][i][2]==0,'no_water_chemical_source')
            prev=states[index-1][i];s=row[i];rate=obs['cells'][i];point=rate['inverse']['point']
            require(point['model_identity']==model and rate['inverse']['target_energy_j']==s['internal_energy_j'],'endpoint_inverse_binding')
            require(point['fluid']['mechanical']['liquid_inventory_mol']==s['liquid_water_mol'] and point['fluid']['mechanical']['gas_inventory_mol']==dict(zip(gas_ids,s['gas_amounts_mol'])),'endpoint_fluid_inventory_binding')
            require(rate['entropy_production_w_k'] is not None and rate['entropy_production_w_k']>=0,'original_entropy_direction')
            cl[i]-=F(l['phase_water_mol'][i]);ce[i]+=sign*F(l['face_energy_j'])
            check('local_liquid_mol',F(s['liquid_water_mol'])-F(initial[i]['liquid_water_mol'])-cl[i],index)
            check('local_energy_j',F(s['internal_energy_j'])-F(initial[i]['internal_energy_j'])-ce[i],index)
            require(s['liquid_water_mol']==float(F(prev['liquid_water_mol'])-F(l['phase_water_mol'][i])),'represented_liquid_update')
            require(s['internal_energy_j']==float(F(prev['internal_energy_j'])+sign*F(l['face_energy_j'])),'represented_energy_update')
            for j in range(2):
                cs[i][j]+=F(l['solid_kg'][i][j]);check('local_solid_kg',F(s['solid_mass_kg'][j])-F(initial[i]['solid_mass_kg'][j])-cs[i][j],index)
                require(s['solid_mass_kg'][j]==float(F(prev['solid_mass_kg'][j])+F(l['solid_kg'][i][j])),'represented_solid_update')
            for j in range(3):
                delta=F(l['chemical_gas_mol'][i][j])+sign*F(l['face_mol'][j])+(F(l['phase_water_mol'][i]) if j==2 else F())
                cg[i][j]+=delta;check('local_gas_mol',F(s['gas_amounts_mol'][j])-F(initial[i]['gas_amounts_mol'][j])-cg[i][j],index)
                require(s['gas_amounts_mol'][j]==float(F(prev['gas_amounts_mol'][j])+delta),'represented_gas_update')
    return {'status':'passed_saved_prefix_accounting','accepted_prefixes':len(ledgers),'core_status':run['status'],
        'maxima':{k:{'numerator':v.numerator,'denominator':v.denominator} for k,v in maxima.items()},'worst_prefix_index':worst,'original_gates':gates,
        'scope':'Saved kg/mol/U/source/face arithmetic and endpoint observation association only. No independent native EOS/RHS or midpoint quadrature reconstruction; partial failed prefix is not a completed trajectory.'}
