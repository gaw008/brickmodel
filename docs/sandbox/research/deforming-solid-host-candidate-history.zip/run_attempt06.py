"""Single approved 150s bounded dry scan; no source edits or EOS."""
from pathlib import Path
import os,subprocess,json,time
r=Path(__file__).resolve().parent
repo=Path('/Users/wanggaoying/Desktop/brickmodel-github')
env=dict(os.environ,PYTHONPATH=f'{r}/candidate:{repo}/tests/sandbox',BRICK_FINE_SCAN='1')
cmd=[str(repo/'.venv/bin/python'),'-m','pytest',str(r/'tests'),'-q','-k','dry_compression',
     '-o','junit_logging=system-out',f'--junitxml={r}/attempt06.xml']
start=time.monotonic()
with (r/'attempt06.log').open('w') as output:
    try:
        run=subprocess.run(cmd,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=150)
        result={'status':'finished','returncode':run.returncode}
    except subprocess.TimeoutExpired:
        result={'status':'resource_limit','reason':'whole_scan_150_seconds'}
result.update(elapsed_s=time.monotonic()-start,command=cmd)
(r/'attempt06-status.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
