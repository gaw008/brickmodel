# Independent mass-reference code and algebra review

Scope: frozen `reaction_reference.py` SHA256 `f05873a0bf02236c7a92257fa553afc17a89fd2581c72385c45b1de5090cf1ef` and test `c72b41472b50168430b53c008673669aee4184b0aaa8d340985b12f6e302bd7d`, PLAN and the prior energy-reference assessment. No repository edits, installed-source changes or EOS. This is a nominal algebra helper, not a live material provider.

No blocking finding within that scope. Independently ran the original suite: **11 passed in 0.01 s**. Added reviewer-owned `test_review_algebra.py`: **2 passed in 0.12 s**, with 100 deterministic exact rational systems of 2–6 components, independent substitution of particular/nullspace/cycle vectors, reaction-column permutations, all-unknown heat inputs, and an inconsistent scaled cycle changed by only 1/10^30. No failed reviewer test or changed production gate was hidden.

## Mathematics and validation

The component-by-reaction matrix convention is consistent: each known reaction is a row of the system B-transpose h = q, while transposing these rows before the homogeneous solve produces reaction-cycle vectors. RREF performs exact elimination and rejects inconsistent zero-coefficient rows; free-column unit coordinates plus negative pivot coefficients give the full homogeneous basis. Independent tests verify B-transpose h = q, B-transpose g = 0 and B c = 0 directly from supplied columns rather than reusing the solver. Rank plus nullity equals component count. The identified linear-output test is the correct annihilator condition on the complete remaining nullspace.

Each column separately checks total mass and every declared element. Complete nonnegative component element fractions sum exactly to one. Missing reaction heats contribute no zero equations; unknown output directions refuse, while dependent heat directions can be determined from known constraints. Non-unit extent scaling, including dependent cycles, is respected. Known-cycle consistency is checked before anchor consistency. Anchors append coordinate equations under the common declared reference; unequal reference-convention labels refuse. Element/mass gauge shifts preserve reaction heat; underdetermined directions beyond conserved-element gauges remain exposed rather than represented as measured enthalpies.

Constructor numeric inputs accept only exact int/Fraction, excluding bool, float, NaN and strings; vectors/entries are immutable tuples with strict lengths, unique component/reaction names and required source declarations. Reference temperature/pressure must be positive. No molar mass, fabricated component heat, latent heat, source power, thermo inversion or EOS is introduced. The free-zero particular vector is explicitly a coordinate representation, and returned material qualification is false.

## Deliberate limits

This does not propagate experimental uncertainty or certify consistency of uncertainty intervals: it solves supplied nominal rational constraints exactly and retains a textual uncertainty declaration. Small nominal cycle disagreement can therefore refuse even when measurement intervals overlap; that is a scope boundary, not evidence that the physical measurements are incompatible. Source IDs, phase labels, extent definitions and common reference state are caller declarations, not verified publication/content bindings. The solution must remain associated with its originating network to retain Tref/pref, phase/basis and uncertainty context; its source-ID union alone is not an independently transferable material/audit certificate. Public solution objects are data containers, not admission capabilities.

There is no temperature validity interval/Cp/volume/entropy/kinetics model here. It does not authorize use of this nominal network as a physical provider, or prove transport and sensible-energy gauge invariance. Those require the separate source bridge and full energy/flow implementation described in PLAN. Current molar/NIST provider guards remain unchanged. Future integration must not add the same reaction enthalpy both to stored energy and as an external heat source.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — exact nominal mass-reference algebra and manufactured tests only; no material qualification or provider admission.

## Final anchor-state revision

Independently hashed and reviewed final source `1a043d63d2cdb794979846ac5d2d1318c08836c4683ec4b46482179afa817c71` and test `47bd1b7a3721c52e0d77af4148d4a5fae4fd5a8bc83c6512b121d0078e0fd9fc`. Prior approved f058 source/tests and this report's original findings remain retained.

The only source delta requires each anchor's positive exact reference temperature/pressure and explicit phase, and checks exact equality to the network reference state and the named component's phase. It correctly prevents silently treating an anchor measured at another temperature, pressure or phase as the network's reference enthalpy. Actual conversion remains unsupported and must be supplied by an external evidenced bridge. The RREF, cycle/nullspace, balance, uncertainty and source-declaration semantics are unchanged. Existing anchor fixtures gained their actual declared reference fields; the three new negative controls independently mismatch T, p and phase without altering old numerical expectations.

Independent final pure run: **16 passed in 0.12 s** (14 author cases plus 2 reviewer algebra checks), retained in `review-anchor-tests.log`. No EOS, repository or installed-source modification.

## Final Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — final 1a043d63 nominal algebra with explicit anchor-state binding; all earlier material/provider limitations remain.

## Final complete-network provenance delta

Read-only final source hash `525116769f7b26e28ae2410ad7a9994fcaf351ae06e70075fa6a62c6d5a0c318`, formal-import test `efbf0109cafe11e36038341cf2ffc00ed0b83a88fd284817652244038890f594`. Compared against `before-network-context.py`: only a required ReferenceSolution.network field and passing the originating immutable network at solve return were added. This resolves the earlier output-context limitation by retaining ordered component/reaction/anchor source mappings, unknown heats, phase/basis, reference state and uncertainty. There is no network-to-solution back-reference/cycle, and the constructors' tuple/frozen children preserve normal immutability. Source declarations still are not verified bibliographic authority.

Read both new tests: exact originating-object identity, anchor/source retention, unknown-output rejection and attempted nested mutation. Read actual `tests04-context-green.log` (16 passed in 0.01 s); previous RED and source snapshot retained. No numerical solver/gate change or production admission expansion. Formal import adaptation changes no test assertion.

Final disposition: APPROVE at 52511676; zero open CRITICAL/HIGH/MEDIUM/LOW findings within the nominal algebra scope. The retained full network enables traceable consumption, but it is not itself an authenticated material or numerical-audit certificate.

Final application check requested by root: actual repository source/test hashes equal the reviewed 52511676/efbf0109 bytes exactly. Independently executed the temporary overlay's 16 formal-import tests plus the two reviewer algebra checks: **18 passed in 0.12 s**, retained in `review-context-tests.log`. The overlay loads the candidate under its formal package identity; no installed package or repository file was modified. Approval remains unchanged.
