"""Manufactured installed API example; values are not sludge measurements."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import sludge_sandbox.reaction_reference as m
from sludge_sandbox.verification_case import encode
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent
assert '/private/tmp/brick-water-backend-probe/venv/' in str(Path(m.__file__).resolve())
assert hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()=='525116769f7b26e28ae2410ad7a9994fcaf351ae06e70075fa6a62c6d5a0c318'
sources=('manufactured:reference-example-v1',)
network=m.ReactionReferenceNetwork(elements=('X',),components=tuple(m.Component(x,'manufactured_solid',(F(1),),sources) for x in ('A','B','C')),reactions=(m.Reaction('AB',(-1,1,0),-10,'kg A consumed',sources),m.Reaction('BC',(0,-1,1),-20,'kg B consumed',sources),m.Reaction('AC',(-1,0,1),None,'kg A consumed',('unknown:AC-not-measured',))),reference_temperature_k=F(300),reference_pressure_pa=F(100000),inventory_basis='kg_of_declared_components',reference_convention='manufactured-common-reference',input_classification='manufactured_test_fixture',uncertainty_statement='Exact manufactured example; no empirical uncertainty asserted',source_ids=sources)
sol=network.solve(required_outputs=((-1,0,1),))
value=sol.identified_value((-1,0,1));assert value==F(-10)+F(-20)==-30
assert sol.network is network and network.reactions[2].enthalpy_j_per_kg_extent is None
try:sol.identified_value((1,0,0))
except m.ReactionReferenceError as exc:unknown_reason=str(exc)
else:raise AssertionError('Unidentified component enthalpy was guessed')
assert unknown_reason=='unknown_required_output' and sol.material_qualified is False
result={'qualification':'manufactured_exact_algebra_example_not_material_measurement_or_thermal_simulation','network':encode(sol.network),'identified_AC_J_per_kg_extent':encode(value),'direct_reference_sum_J_per_kg_extent':-10-20,'unidentified_A_h0_reason':unknown_reason,'coordinate_convention':sol.coordinate_convention,'remaining_nullspace_dimension':len(sol.nullspace_h0_j_kg),'material_qualified':sol.material_qualified,'actual_runtime':runtime_identity(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root/'actual-installed-example.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print('Installed nominal reference example passed; unknown component enthalpy refused; no EOS.')
