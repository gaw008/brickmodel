import importlib.util
import sys
from pathlib import Path
import sludge_sandbox
name='sludge_sandbox.reaction_reference'
spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name('reaction_reference.py'))
module=importlib.util.module_from_spec(spec);sys.modules[name]=module
setattr(sludge_sandbox,'reaction_reference',module)
spec.loader.exec_module(module)
