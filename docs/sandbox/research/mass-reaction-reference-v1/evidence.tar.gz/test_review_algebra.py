"""Independent manufactured algebra checks; no physical-data qualification."""
from fractions import Fraction as F
from dataclasses import replace
import random
import pytest
from reaction_reference import Component, Reaction, ReactionReferenceNetwork, ReactionReferenceError

S=('manufactured:independent-review',)

def make(columns, heats):
    n=len(columns[0])
    return ReactionReferenceNetwork(('X',),tuple(Component(str(i),'test',(1,),S) for i in range(n)),
        tuple(Reaction(str(i),tuple(b),q,'declared kg extent',S) for i,(b,q) in enumerate(zip(columns,heats))),
        F(300),F(100000),'kg_of_declared_components','test','manufactured_test_fixture','exact artificial inputs',S)

def test_many_exact_systems_and_cycle_witnesses():
    rng=random.Random(724)
    for n in range(2,7):
        for _ in range(20):
            columns=[]
            for j in range(n+2):
                a=[F(rng.randint(-7,7),rng.randint(1,7)) for k in range(n-1)]
                a.append(-sum(a))
                if not any(a):a[0],a[-1]=F(-1),F(1)
                columns.append(tuple(a))
            h=tuple(F(rng.randint(-20,20),rng.randint(1,5)) for k in range(n))
            heats=tuple(sum(bi*hi for bi,hi in zip(b,h)) for b in columns)
            net=make(columns,heats);sol=net.solve()
            for b,q in zip(columns,heats):
                assert sum(bi*hi for bi,hi in zip(b,sol.particular_h0_j_kg))==q
                assert sol.identified_value(b)==q
                for g in sol.nullspace_h0_j_kg:assert sum(bi*gi for bi,gi in zip(b,g))==0
            for c in sol.reaction_cycle_basis:
                assert all(sum(cj*b[k] for cj,b in zip(c,columns))==0 for k in range(n))
                assert sum(cj*q for cj,q in zip(c,heats))==0
            assert len(sol.pivots)+len(sol.nullspace_h0_j_kg)==n
            permutation=list(range(n+2));rng.shuffle(permutation)
            reordered=make([columns[i] for i in permutation],[heats[i] for i in permutation]).solve()
            for b,q in zip(columns,heats):assert reordered.identified_value(b)==q

def test_all_unknown_and_scaled_cycle_negative_control():
    net=make([(-1,1,0),(0,-1,1)],[None,None]);sol=net.solve()
    assert len(sol.nullspace_h0_j_kg)==3 and sol.known_reaction_ids==()
    with pytest.raises(ReactionReferenceError,match='unknown_required_output'):sol.identified_value((-1,1,0))
    cycle=make([(-1,1,0),(0,-2,2),(-3,0,3)],[-7,-22,-54])
    cycle.solve()
    bad=replace(cycle,reactions=cycle.reactions[:2]+(replace(cycle.reactions[2],enthalpy_j_per_kg_extent=F(-54)+F(1,10**30)),))
    with pytest.raises(ReactionReferenceError,match='inconsistent_reaction_cycle'):bad.solve()
