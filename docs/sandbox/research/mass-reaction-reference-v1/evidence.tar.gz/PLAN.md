# Mass-basis reference network: bounded numerical bridge

Implements Route A from `/private/tmp/brick-material-energy-reference-v1/REPORT.md`. No new external physical claims or property values are introduced. All tests use manufactured exact rational inputs. Existing molar providers, EOS, kinetics, thermodynamic inversion and live application admission are unchanged.

`ReactionReferenceNetwork` requires ordered elements and components, complete element mass fractions per one kg component, phase labels, ordered reaction mass-change columns (kg component / kg of explicitly named extent), product-minus-reactant reaction heats (J/kg extent, or explicit unknown), a common Tref/pref/reference convention, inventory basis, source IDs and an uncertainty statement. No uncertain value is silently made exact: arithmetic treats the supplied nominal rationals exactly, while measurement uncertainty remains outside this helper. Input classification is manufactured or externally sourced but unqualified. Source IDs are declarations, not verified bibliographic authority.

For every column, check total mass balance and each element balance exactly. The supplied reaction constraints are `B^T h0=q`. Exact rational RREF first identifies closed cycles of the known reaction columns; inconsistent cycle heats refuse. Common-reference anchors add independent equations; inconsistent anchors and unbridged reference names refuse. Missing reaction heat is not replaced by zero. A requested linear output must be orthogonal to every remaining nullspace direction, or raises `unknown_required_output`.

The solution exposes an explicitly named coordinate choice (free coordinates zero), the full residual nullspace and exact cycle basis. This coordinate vector is not a measurement of each component enthalpy. Anchors may remove freedoms but retain declared source and uncertainty limitations. Legitimate nullspace shifts preserve all supplied reaction heats; mass/element gauge shifts are independently tested. Only this reference algebra is implemented: no claim of Cp, temperature inversion, chemical equilibrium, reaction kinetics, plant prediction or material qualification.

## Files

- `reaction_reference.py`: pure standard-library candidate, no package import/EOS.
- `test_reaction_reference.py`: manufactured conservation, anchor, gauge, cycle, unknown and strict-input tests.
- `tests01.log`: 11 passed in 0.02 s.

There is deliberately no automatic heat source: the reference energy change is a state-coordinate difference. A future total-energy host must incorporate the same offsets in stored energy and transported enthalpy, and must not add the same reaction heat again as external power. Transport and sensible-energy gauge invariance are not claimed tested by this isolated algebra.

## Anchor state binding revision

External anchors now require their own explicit Tref, pref and phase as well as reference convention/source IDs. The network refuses temperature, pressure, phase or convention mismatch; no automatic physical reference conversion is invented. Three negative controls were added; prior candidate/test bytes are retained as `before-anchor-state*.py`.

Frozen source: 1a043d63d2cdb794979846ac5d2d1318c08836c4683ec4b46482179afa817c71.
Frozen test: 47bd1b7a3721c52e0d77af4148d4a5fae4fd5a8bc83c6512b121d0078e0fd9fc.
`tests02.log`: 14 passed in 0.02 s. No scientific numerical input changed.

## Self-contained solution provenance

`ReferenceSolution.network` now retains the exact original immutable `ReactionReferenceNetwork` object. It therefore carries all ordered per-component/reaction/anchor source mappings, phase/basis/reference-state declarations, explicit unknown reaction heats and uncertainty statements. No separate source-context lookup or hash framework is needed. The plain `identified_value` remains an exact nominal constraint result, not a measurement or material certificate.

Actual failure-first evidence: `tests03-context-red.log` had two missing-network failures and fourteen passes. Final `tests04-context-green.log`: **16 passed in 0.01 s**. Tests exercise frozen network/entry attributes, immutable source tuples, unknown heat retention, anchor identity and the nominal qualification.

Final source SHA256: 525116769f7b26e28ae2410ad7a9994fcaf351ae06e70075fa6a62c6d5a0c318.
Final test SHA256: efbf0109cafe11e36038341cf2ffc00ed0b83a88fd284817652244038890f594.

Application paths are exactly `src/sludge_sandbox/reaction_reference.py` and `tests/sandbox/test_reaction_reference.py`. Test imports are formal `sludge_sandbox.reaction_reference`; temporary `conftest.py` provides only candidate loading and is not an application artifact. Prior source/test bytes and all logs are retained. No repository source, installed package, physical inputs or EOS were changed.
