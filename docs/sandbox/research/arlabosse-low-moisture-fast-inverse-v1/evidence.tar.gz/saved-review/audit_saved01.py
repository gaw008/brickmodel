"""Bounded passive comparison of saved native records, without application imports."""
from fractions import Fraction as F
from pathlib import Path
import copy
import hashlib
import json
import time
import traceback
import xml.etree.ElementTree as ET
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
OLD=Path('/private/tmp/arlabosse-low-moisture-v1')
WORK=Path('/private/tmp/arlabosse-low-moisture-fast-inverse-v1')
OUT=WORK/'saved-review';CHECKS=[];INPUTS={};SUMMARY={};START=time.monotonic()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def hook(d):
    return F(d['numerator'],d['denominator']) if set(d)=={'numerator','denominator'} and all(type(x)is int for x in d.values()) else d
def read(p):
    INPUTS[str(p)]=sha(p);return json.loads(Path(p).read_bytes(),object_hook=hook)
def check(n,v):CHECKS.append({'id':n,'passed':bool(v)})
def T(p):return p['fluid']['mechanical']['temperature_k']
def P(p):return p['fluid']['mechanical']['pressure_pa']
def total(states,k):
    if k=='U':return sum((F(s['internal_energy_j']) for s in states),F())
    if k=='water':return sum((F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]) for s in states),F())
    if k=='Nc':return sum((F(s['liquid_water_mol']) for s in states),F())
    return sum((F(s['gas_amounts_mol'][k]) for s in states),F())
def serialize(x):
    if isinstance(x,F):return {'numerator':x.numerator,'denominator':x.denominator}
    raise TypeError(type(x).__name__)
try:
    old_case=(OLD/'native_case.py').read_text();new_case=(WORK/'native_case.py').read_text()
    normalized=new_case.replace('from sludge_sandbox.low_moisture_fast_inverse import NUMERICAL_POLICY_ID\n','').replace(", inverse_strategy=NUMERICAL_POLICY_ID)",")")
    check('case_only_strategy_import_selection',normalized==old_case)
    old_driver=(OLD/'native_driver.py').read_text();new_driver=(WORK/'native_driver.py').read_text()
    check('driver_only_work_path',new_driver.replace(str(WORK),str(OLD))==old_driver)
    for path in (OLD/'native_case.py',WORK/'native_case.py',OLD/'native_driver.py',WORK/'native_driver.py',WORK/'compare_saved.py'):
        INPUTS[str(path)]=sha(path)
    comp=read(WORK/'SAVED_COMPARISON.json')
    initial=[read(d/'native01/INITIAL.json') for d in (OLD,WORK)]
    runs=[read(d/'native01/RUN.json') for d in (OLD,WORK)]
    accepted=[read(d/'native01/ACCEPTANCE.json') for d in (OLD,WORK)]
    check('identical_physical_initial_and_source_nodes',all(initial[0][k]==initial[1][k] for k in ('states','points','actual_source_nodes')))
    p0,p1=copy.deepcopy(initial[0]['provenance']),copy.deepcopy(initial[1]['provenance'])
    ids=[(p.pop('model_identity'),p['base'].pop('model_identity')) for p in (p0,p1)]
    strategy=p1['base'].pop('inverse_strategy')
    check('only_declared_strategy_provenance_change',p0==p1 and ids[0][0]!=ids[1][0] and ids[0][1]!=ids[1][1] and
        strategy['id']=='LOW_MOISTURE_FULL_U_SAFEGUARDED_NEWTON_BISECTION_V1')
    check('original_232_gates_unchanged_green',len(accepted[0]['checks'])==len(accepted[1]['checks'])==comp['original_gate_count']==232 and
        accepted[0]['checks']==accepted[1]['checks'] and all(c['passed'] is True for c in accepted[1]['checks']) and all(a['passed'] is True for a in accepted))
    check('fixed_budget_count_and_time',all(r['status']=='completed' and r['reason'] is None and len(r['ledgers'])==2 and len(r['observations'])==2 and
        r['times_s']==[F(),F(.05)/2,F(.05)] and r['evaluations_attempted']==r['evaluations_completed']==6 and
        r['energy_roundoff_budget_j']==1e-8 and r['inventory_roundoff_budget_mol']==1e-12 for r in runs))
    metrics=[]
    for rid,run in enumerate(runs):
        inverses=[]
        for step,(ledger,end) in enumerate(zip(run['ledgers'],run['observations'])):
            for stage,states,rates in (('predictor',run['states'][step],ledger['predictor_rates']),
                ('middle',ledger['midpoint_states'],ledger['midpoint_rates']),('end',run['states'][step+1],end)):
                for cell,(state,c) in enumerate(zip(states,rates['cells'])):
                    inv=c['inverse'];p=inv['point'];m=p['fluid']['mechanical'];residual=F(p['total_internal_energy_j'])-F(state['internal_energy_j'])
                    allowance=abs(residual)+F(p['energy_error_j']);bound=F(inv['temperature_error_bound_k']);cv=F(p['minimum_heat_capacity_j_k'])
                    check(f'run{rid}/{step}/{stage}/{cell}/inverse_full_U_T',inv['target_energy_j']==state['internal_energy_j'] and inv['energy_residual_j']==residual and
                        0<=allowance<=F(1e-5) and 0<cv and allowance/cv<=bound<=F(1e-6) and
                        inv['final_temperature_bracket_k'][0]<=T(p)<=inv['final_temperature_bracket_k'][1] and
                        type(inv['iterations'])is int and 0<=inv['iterations']<=100)
                    check(f'run{rid}/{step}/{stage}/{cell}/state_source_pressure',m['liquid_inventory_mol']==state['liquid_water_mol'] and
                        [m['gas_inventory_mol'][g] for g in ('O2','N2','H2O')]==state['gas_amounts_mol'] and
                        p['model_identity']==state['energy_model_identity'] and 325<=T(p)<=338 and
                        90000<=F(P(p))-F(p['pressure_error_pa']) and F(P(p))+F(p['pressure_error_pa'])<=110000 and
                        p['excess_internal_energy_j']==F(.01)*p['excess']['h_ex_j_kg_dry'])
                    inverses.append(inv)
        metric={'maximum_U_residual_plus_error_j':max(float(abs(i['energy_residual_j'])+F(i['point']['energy_error_j'])) for i in inverses),
            'maximum_temperature_bound_k':max(i['temperature_error_bound_k'] for i in inverses),
            'total_candidate_iterations':sum(i['iterations'] for i in inverses),'inferred_evaluate_count':sum(i['iterations']+2 for i in inverses),
            'count_scope':'inferred from returned iterations plus endpoint calls, not independently instrumented','inverse_count':len(inverses)}
        check(f'run{rid}/saved_inverse_metrics',len(inverses)==12 and metric==comp['inverse_metrics_old_new'][rid]);metrics.append(metric)
    deltas=[]
    for i,(s,t) in enumerate(zip(runs[0]['states'][-1],runs[1]['states'][-1])):
        deltas.append({'cell':i,'delta_U_j':t['internal_energy_j']-s['internal_energy_j'],'delta_Nc_mol':t['liquid_water_mol']-s['liquid_water_mol'],
            'delta_Nv_mol':t['gas_amounts_mol'][2]-s['gas_amounts_mol'][2],
            'delta_T_k':T(runs[1]['observations'][-1]['cells'][i]['inverse']['point'])-T(runs[0]['observations'][-1]['cells'][i]['inverse']['point'])})
    check('final_differences_retained_not_identical_trajectory',deltas==comp['final_differences_new_minus_old'] and any(d['delta_T_k']!=0 for d in deltas) and runs[0]['states'][-1]!=runs[1]['states'][-1])
    check('measured_wall_comparison',comp['old_integrator_seconds']==accepted[0]['integrator_seconds']==runs[0]['elapsed_seconds'] and
        comp['new_integrator_seconds']==accepted[1]['integrator_seconds']==runs[1]['elapsed_seconds'] and
        comp['old_over_new_wall_ratio']==runs[0]['elapsed_seconds']/runs[1]['elapsed_seconds'])
    run=runs[1];ecost=ncost=F();prefix={k:F() for k in ('U','water','Nc',0,1,2)}
    for i,l in enumerate(run['ledgers']):
        old,new=run['states'][i:i+2]
        for stage,states_after,faces,phase,error in (
            ('predictor',l['midpoint_states'],l['predictor_faces'],l['predictor_phase_water_mol'],l['predictor_roundoff']),
            ('accepted',new,l['faces'],l['phase_water_mol'],l['roundoff'])):
            flags=[]
            for cell,(s,t) in enumerate(zip(old,states_after)):
                left,right=faces[cell:cell+2]
                flags.extend([F(t['internal_energy_j'])-F(s['internal_energy_j'])==left['energy_j']-right['energy_j']+error['energy_j'][cell],
                    F(t['liquid_water_mol'])-F(s['liquid_water_mol'])==left.get('moisture_mol',F())-right.get('moisture_mol',F())-phase[cell]+error['liquid_mol'][cell]])
                flags.extend(F(t['gas_amounts_mol'][g])-F(s['gas_amounts_mol'][g])==left['gas_mol'][g]-right['gas_mol'][g]+(phase[cell] if g==2 else 0)+error['gas_mol'][cell][g] for g in range(3))
            check(f'new_step{i}/{stage}/each_cell_U_Nc_gas',all(flags))
            ecost+=sum(map(abs,error['energy_j']),F())
            ncost+=sum(map(abs,error['liquid_mol']),F())+sum((sum(map(abs,r),F()) for r in error['gas_mol']),F())
            for f in faces:
                ecost+=abs(f['energy_decomposition_roundoff_j'])+abs(f.get('moisture_enthalpy_projection_j',F()))+abs(f.get('vapor_enthalpy_projection_j',F()))+abs(f.get('heat_projection_j',F()))
                ncost+=abs(f.get('moisture_molar_projection_mol',F()))+abs(f.get('vapor_molar_projection_mol',F()))
            check(f'new_step{i}/{stage}/decomposition',all(f['energy_j']==f['conduction_j']+sum(f['diffusive_enthalpy_j'],F())+
                sum(f['advective_enthalpy_j'],F())+f.get('moisture_enthalpy_j',F())+f['energy_decomposition_roundoff_j'] for f in faces))
        f=l['faces'][-1];e=l['roundoff'];phase=l['phase_water_mol']
        changes={'U':-f['energy_j']+sum(e['energy_j'],F()),'Nc':-sum(phase,F())+sum(e['liquid_mol'],F())}
        changes.update({g:-f['gas_mol'][g]+(sum(phase,F()) if g==2 else F())+sum((r[g] for r in e['gas_mol']),F()) for g in range(3)})
        changes['water']=changes['Nc']+changes[2]
        for k,v in changes.items():prefix[k]+=v
        check(f'new_step{i}/global_and_prefix_all_species_U',all(total(new,k)-total(old,k)==v and total(new,k)-total(run['states'][0],k)==prefix[k] for k,v in changes.items()))
    check('new_complete_saved_fee_sum',ecost==run['energy_roundoff_used_j']<=F(1e-8) and ncost==run['inventory_roundoff_used_mol']<=F(1e-12))
    meta=read(WORK/'supervised-native01/metadata.json');status=read(WORK/'supervised-native01/status.json')
    oldmeta=read(OLD/'supervised-native01/metadata.json')
    before={p:v['sha256'] for p,v in meta['inputs_before'].items()}
    check('supervisor_normalized_input_hashes',len(before)==2782 and before==status['inputs_after'] and status['inputs_unchanged'] is True)
    check('supervisor_terminal_and_budgets',status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] is True and
        status['cleanup']['signal_errors']==[] and meta['timeout_s']==100. and meta['cleanup_grace_s']==5. and status['elapsed_s']<105. and
        runs[1]['elapsed_seconds']<=accepted[1]['driver_seconds']<80. and runs[1]['elapsed_seconds']<60.)
    oldbefore={p:v['sha256'] for p,v in oldmeta['inputs_before'].items()}
    differing=[p for p in before.keys()&oldbefore.keys() if before[p]!=oldbefore[p]]
    check('same_shared_physics_dependencies',sorted(differing)==sorted([str(ROOT/'src/sludge_sandbox/source_wet_column.py'),
        '/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox/source_wet_column.py']))
    freeze=read(WORK/'install/SOURCE_FREEZE.json')['files'];records=[read(WORK/'install'/n) for n in ('BEFORE_TESTS.json','AFTER_TESTS.json','AFTER_NATIVE.json')]
    check('frozen_before_after_tests_native',records[0]==records[1]==records[2] and records[0]['passed'] is True and records[0]['source']==records[0]['installed']==records[0]['frozen']==freeze and len(freeze)==182 and sum(n.endswith('.py') for n in freeze)==175)
    installed=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
    check('frozen_current_supervised_package_identity',all(sha(ROOT/'src/sludge_sandbox'/n)==sha(installed/n)==digest==before[str(ROOT/'src/sludge_sandbox'/n)]==before[str(installed/n)] for n,digest in freeze.items()))
    check('reviewed_solver_and_host_bytes',freeze['low_moisture_fast_inverse.py']=='56fb7df8aee1ed868611916fce503a1fc2535da61691264685dd15dd94bb0fc8' and freeze['source_wet_column.py']=='010948959810ef51a3a6509e687d52c2c3de787f72687e061ae154273e1eb07f')
    xml=WORK/'install/INSTALLED_TESTS01.xml';INPUTS[str(xml)]=sha(xml);suite=ET.parse(xml).getroot().find('testsuite')
    check('installed_23_tests_saved_green',suite.get('tests')=='23' and all(suite.get(n)=='0' for n in ('failures','errors','skipped')))
    check('comparison_all_checks_and_qualification',comp['passed'] is True and all(c['passed'] is True for c in comp['checks']) and
        comp['material_qualified'] is False and comp['spatial_temporal_convergence_demonstrated'] is False and
        all(r['material_qualified'] is False for r in runs))
    SUMMARY={'original_gate_count':232,'inverse_count_each':12,'comparison_original_checks':len(comp['checks']),
        'old_new_inverse_metrics':metrics,'old_integrator_s':runs[0]['elapsed_seconds'],'new_integrator_s':runs[1]['elapsed_seconds'],
        'old_over_new_wall_ratio':comp['old_over_new_wall_ratio'],'new_driver_s':accepted[1]['driver_seconds'],'new_supervisor_s':status['elapsed_s'],
        'new_energy_roundoff_j':ecost,'new_inventory_roundoff_mol':ncost,'final_differences':deltas,
        'source_installed_files':len(freeze),'modules':175,'supervised_inputs':len(before),'installed_tests':dict(suite.attrib),
        'boundary_outflow_mol':accepted[1]['total_water_outflow_mol']}
except BaseException as exc:
    CHECKS.append({'id':'audit_exception','passed':False,'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
finally:
    record={'passed':all(c['passed'] for c in CHECKS),'checks':CHECKS,'summary':SUMMARY,'input_sha256':INPUTS,'elapsed_s':time.monotonic()-START,
        'audit_sha256':sha(__file__),'scope':'Passive single-case comparison, full-U/T/state certificates and minimal shared ledgers; no EOS/replay or general performance/convergence claim.'}
    with (OUT/'SAVED_REVIEW01.json').open('x') as f:json.dump(record,f,indent=2,default=serialize);f.write('\n')
    print(json.dumps({'passed':record['passed'],'checks':len(CHECKS),'failed':[c for c in CHECKS if not c['passed']], 'summary':SUMMARY},default=serialize))
    if not record['passed']:raise SystemExit(1)
