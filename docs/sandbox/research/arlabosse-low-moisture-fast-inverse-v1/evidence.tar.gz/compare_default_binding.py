from dataclasses import fields, replace
import importlib.util
import json
from pathlib import Path
import sys
import pytest
import sludge_sandbox.source_wet_column as current
from test_low_moisture_column import setup
work=Path('/private/tmp/arlabosse-low-moisture-fast-inverse-v1')
name='sludge_sandbox._baseline_source_wet_column'
spec=importlib.util.spec_from_file_location(name,work/'baseline_source_wet_column.py')
baseline=importlib.util.module_from_spec(spec);sys.modules[name]=baseline;spec.loader.exec_module(baseline)
with pytest.MonkeyPatch.context() as patch:
    column,states=setup(patch)
    old=baseline.LowMoistureSorptionColumn(**{f.name:getattr(column,f.name) for f in fields(baseline.LowMoistureSorptionColumn) if f.init})
    out={'passed':old.model_identity==column.model_identity and old.provenance()==column.provenance(), 'previous_identity':old.model_identity,'default_identity':column.model_identity,'old_provenance_equal':old.provenance()==column.provenance(), 'baseline_commit':'cfd291c','scope':'manufactured same storage objects; no inverse or EOS performance run'}
    (work/'DEFAULT_COMPATIBILITY.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out);assert out['passed']
