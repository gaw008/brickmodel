# Explicit low-moisture safeguarded inverse draft

This directory is scratch-only. No existing inverse, production storage, source facts, Column selection, installation, native run or current frozen evidence was changed. There are no real water-EOS calls in these tests. ROOT must explicitly choose and bind the new strategy before any later production use; this module cannot select itself.

`invert_low_moisture_safeguarded(storage,state,policy)` requires the exact `LowMoistureSorptionStorage` and `InversePolicy` types and returns the existing `SourceWetInverse` record. `NUMERICAL_POLICY_ID` is `LOW_MOISTURE_FULL_U_SAFEGUARDED_NEWTON_BISECTION_V1`. `strategy_definition()` exposes a fresh machine-readable numerical-policy record. No physical coefficients are introduced.

The solver always evaluates both original temperature endpoints with the unchanged storage implementation. It retains the exact original inward support test `Ulo+error_lo <= target <= Uhi-error_hi`, including both endpoint pressure checks. It never subtracts or drops the sorption energy offset from the original full-U target. Additional explicit point guards reject unknown, negative or nonfinite energy bounds/Cv and pressure envelopes, without inventing default values.

The initial proposal is the nominal endpoint secant. Each later fast proposal is `T-residual/closed_Cv` from an actually evaluated point. An out-of-bracket, overflowed or endpoint-rounded proposal is replaced by a midpoint; no provider error is swallowed. Every third candidate is forced to the midpoint, limiting possible slow bracket contraction under an unhelpful Newton derivative. Each nonaccepted result must have a resolved sign `abs(residual)>error`, then updates only its corresponding bracket endpoint. The original representable-temperature gate and maximum candidate-iteration limit remain active.

The acceptance condition is unchanged: `abs(full_U_residual)+energy_error <= energy_tolerance`, and the outward-rounded ratio of that allowance to the original minimum Cv must fit the original temperature tolerance. Both endpoints may be checked for acceptance only after both original support gates pass. Such a result uses `iterations=0`; otherwise `iterations` counts candidate evaluations, with exactly two initial endpoint evaluations in addition. The returned bracket is the then-current full-U bracket, not a substitute for the residual/Cv error bound.

Tests use exact actual storage classes and the existing manufactured fluid seam. Caloric callback tests insert explicitly manufactured linear/quadratic positive-Cv energy functions while retaining the real low-W excess addition, including the dry reference offset. These are algorithm tests, not source-material validation. Tests also cover near-domain endpoints and original endpoint rejection, large/unknown errors, zero/invalid Cv, pressure-envelope failure, unrepresentable candidate fallback, deliberately poor derivative forcing bisection, exact type gates and iteration exhaustion.

Evidence preserved:

- `RED01.log/xml`: tests were written before the module; collection failed because the new module did not exist. No historical numerical defect is claimed from this initial RED.
- `GREEN01.log/xml`: 16 manufactured tests passed in 14.52 s.
- `CALL_COUNTS.json`: all actually requested trial temperatures and counts for the three same-policy comparisons below.
- `SHA01.json`: frozen draft module/test/count-record SHA-256 and sizes. Both Python files parsed successfully with AST.

| Manufactured case | Existing full-U bisection evaluate calls | New explicit strategy evaluate calls |
|---|---:|---:|
| Linear positive condensed inventory | 31 | 3 |
| Quadratic positive-Cv energy curve | 33 | 7 |
| Linear energy, zero condensed inventory | 30 | 3 |

Counts include endpoints and exclude the one prior call used to manufacture each target. Both results in each comparison passed the same original acceptance test. These counts are not native EOS timings, a speed guarantee, or long-duration/convergence evidence. The current production inverse is unchanged. Independent review and explicit host integration remain ROOT's next steps.
