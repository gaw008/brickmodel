# Explicit fast-inverse Column integration — independent bounded review

**APPROVE**, no unresolved findings. Reviewed the complete current diff, surrounding admission/evaluation/provenance and controlled-boundary dispatch, three new host tests, and the migrated solver-test diff. No production edit, application import, author-test rerun, EOS, installation or native execution was performed.

## Findings and evidence

- `inverse_strategy` is keyword-only on the exact `LowMoistureSorptionColumn`. Its default is the original `full_U_bisection_v1`. The existing exact host/storage type gate runs first; plain `SourceWetColumn`, original `ArlabosseSorptionColumn`, mixed storage types and derived hosts do not acquire the new route.
- Binding admits only the original strategy and the explicitly named new ID. An opted-in column binds the complete numerical strategy definition; a default column adds no new digest content or provenance field. Content is rechecked before inverse evaluation and after the resulting column evaluation, so changing the selector or bound strategy definition cannot silently alter an existing column's accepted behavior.
- Dispatch changes only the inverse call. It passes the same storage object, original state/full-U target and original `InversePolicy` into the reviewed solver. The solver's actual bytes are unchanged from the reviewed scratch SHA; both original endpoints, pressure/support gates, error accounting, representability and iteration limits remain as reviewed. No wrapper target subtraction or tolerance adjustment is introduced.
- `ControlledVaporColumn` still binds and evaluates its exact low-W base; opting into the new solver changes the base/wrapper numerical identity while leaving state energy identity, shared faces, predictor/middle witnesses, signed water/U balances and fee accounting unchanged. Old exact/programmed admission is not broadened.
- The migrated solver tests change only the module import and move call-count output into a pytest temporary directory. Their test logic is unchanged. New host tests cover explicit/default dispatch, unsupported/mutated selector rejection and controlled-boundary water/U conservation. ROOT owns their active execution and the same-object old/default-binding comparison; this report does not claim those running checks as complete.

`STATIC_CHECK01.json/log`: **11 passive checks passed**. AST comparisons confirm `_integrals`, `_advance`, `integrate_source_column`, ordinary face/rate/run records and the original Arlabosse subclass are unchanged. Removing precisely the two new selector-admission/opt-in identity branches leaves the default binding AST identical to the frozen baseline. Keyword-only/default settings and byte-identical solver migration are also checked. These are static checks, not dynamic test or native evidence.

The new strategy is separately identified. This review does not claim measured native acceleration, independent EOS certification, material qualification, training eligibility, convergence or completion of the entire Goal.

## Subject SHA-256

- `src/sludge_sandbox/source_wet_column.py`: `010948959810ef51a3a6509e687d52c2c3de787f72687e061ae154273e1eb07f`
- `src/sludge_sandbox/low_moisture_fast_inverse.py`: `56fb7df8aee1ed868611916fce503a1fc2535da61691264685dd15dd94bb0fc8`
- `src/sludge_sandbox/controlled_vapor_column.py`: `a336458669e067a3939775f34677c4168bc8a0dbcde1865ba8506adf9ce6ef5a`
- `tests/sandbox/test_low_moisture_inverse_column.py`: `efd9b068da006346fa7f0a333e8e723c56511daade63d2600b1ebd142f4e4443`
- `tests/sandbox/test_low_moisture_fast_inverse.py`: `5e22fa02736c47b21f6d8eb5cba8e5273725d1e16862f0778a4ab866bcf492de`
- Frozen baseline Column: `94880a68d8f0108a3e488cf514fdd45ea9c5cf275fb14ecd080dbd8f14e8a000`

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE** for the explicit host integration; pending runtime checks remain separate evidence.
