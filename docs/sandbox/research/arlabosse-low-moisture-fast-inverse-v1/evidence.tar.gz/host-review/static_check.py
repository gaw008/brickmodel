"""Read-only AST/byte comparisons; no application import, solve or tests."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK=Path('/private/tmp/arlabosse-low-moisture-fast-inverse-v1')
OUT=WORK/'host-review'
old=ast.parse((WORK/'baseline_source_wet_column.py').read_text())
new=ast.parse((ROOT/'src/sludge_sandbox/source_wet_column.py').read_text())
checks=[]
def check(name,ok):checks.append({'id':name,'passed':bool(ok)})
def node(tree,name):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
def same(a,b):return ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
for name in ('_integrals','_advance','integrate_source_column'):
    check(name+'_unchanged',same(node(old,name),node(new,name)))
for name in ('ColumnFaceRate','SourceColumnRates','SourceColumnRun','ArlabosseSorptionColumn'):
    check(name+'_unchanged',same(node(old,name),node(new,name)))
oldclass=node(old,'SourceWetColumn');newclass=node(new,'SourceWetColumn')
binding=node(newclass,'binding')
removed=[]
kept=[]
for statement in binding.body:
    if isinstance(statement,ast.If) and any(isinstance(x,ast.Attribute) and x.attr=='inverse_strategy' for x in ast.walk(statement)):
        removed.append(statement)
    else:kept.append(statement)
check('only_two_explicit_low_strategy_binding_additions',len(removed)==2)
binding.body=kept
check('remaining_default_binding_AST_identical',same(node(oldclass,'binding'),binding))
klass=node(new,'LowMoistureSorptionColumn')
field=next(n for n in klass.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='inverse_strategy')
keywords={k.arg:ast.literal_eval(k.value) for k in field.value.keywords}
check('strategy_is_keyword_only_old_default',keywords=={'default':'full_U_bisection_v1','kw_only':True})
current=ROOT/'src/sludge_sandbox/low_moisture_fast_inverse.py'
check('migrated_algorithm_exact_reviewed_bytes',current.read_bytes()==(WORK/'low_moisture_fast_inverse.py').read_bytes() and hashlib.sha256(current.read_bytes()).hexdigest()=='56fb7df8aee1ed868611916fce503a1fc2535da61691264685dd15dd94bb0fc8')
files=['src/sludge_sandbox/source_wet_column.py','src/sludge_sandbox/low_moisture_fast_inverse.py','src/sludge_sandbox/controlled_vapor_column.py',
       'tests/sandbox/test_low_moisture_inverse_column.py','tests/sandbox/test_low_moisture_fast_inverse.py']
result={'passed':all(x['passed'] for x in checks),'checks':checks,'subject_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files},
        'baseline_sha256':hashlib.sha256((WORK/'baseline_source_wet_column.py').read_bytes()).hexdigest(),
        'application_imports':False,'EOS_or_native_calls':False,'author_tests_rerun':False}
(OUT/'STATIC_CHECK01.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert result['passed']
