"""Compare two saved runs without importing a solver or evaluating EOS."""
from fractions import Fraction as F
from pathlib import Path
import json

OLD=Path('/private/tmp/arlabosse-low-moisture-v1/native01')
WORK=Path('/private/tmp/arlabosse-low-moisture-fast-inverse-v1')
NEW=WORK/'native01'
def load(root,name): return json.loads((root/name).read_bytes())
def fraction(value):
    return F(value['numerator'],value['denominator']) if isinstance(value,dict) else F(value)
a,b=load(OLD,'INITIAL.json'),load(NEW,'INITIAL.json')
x,y=load(OLD,'RUN.json'),load(NEW,'RUN.json')
old,new=load(OLD,'ACCEPTANCE.json'),load(NEW,'ACCEPTANCE.json')
checks=[]
def check(name,value):checks.append({'id':name,'passed':bool(value)})
for name in ('states','points','actual_source_nodes'):
    check('same_initial_'+name,a[name]==b[name])
pa,pb=a['provenance'],b['provenance']
for p in (pa,pb):
    p.pop('model_identity');p['base'].pop('model_identity')
strategy=pb['base'].pop('inverse_strategy')
check('only_declared_strategy_provenance_changed',pa==pb)
check('selected_strategy',strategy['id']=='LOW_MOISTURE_FULL_U_SAFEGUARDED_NEWTON_BISECTION_V1')
check('same_original_gate_ids',[v['id'] for v in old['checks']]==[v['id'] for v in new['checks']])
check('original_gates_still_pass',old['passed'] and new['passed'] and all(v['passed'] for v in new['checks']))
for name in ('times_s','energy_roundoff_budget_j','inventory_roundoff_budget_mol','evaluations_attempted','evaluations_completed'):
    check('same_'+name,x[name]==y[name])
metrics=[]
for run in (x,y):
    inverses=[]
    for ledger,last in zip(run['ledgers'],run['observations']):
        for rates in (ledger['predictor_rates'],ledger['midpoint_rates'],last):
            inverses.extend(cell['inverse'] for cell in rates['cells'])
    for i,inv in enumerate(inverses):
        allowance=abs(fraction(inv['energy_residual_j']))+fraction(inv['point']['energy_error_j'])
        check(f'run{len(metrics)}_inverse{i}_original_U_gate',allowance<=F(1e-5))
        check(f'run{len(metrics)}_inverse{i}_original_T_gate',inv['temperature_error_bound_k']<=1e-6)
    metrics.append({'maximum_U_residual_plus_error_j':max(float(abs(fraction(i['energy_residual_j']))+fraction(i['point']['energy_error_j'])) for i in inverses),
        'maximum_temperature_bound_k':max(i['temperature_error_bound_k'] for i in inverses),
        'total_candidate_iterations':sum(i['iterations'] for i in inverses),
        'inferred_evaluate_count':sum(2+i['iterations'] for i in inverses),
        'count_scope':'inferred from returned iterations plus endpoint calls, not independently instrumented',
        'inverse_count':len(inverses)})
changes=[]
for i,(s,t) in enumerate(zip(x['states'][-1],y['states'][-1])):
    changes.append({'cell':i,'delta_U_j':t['internal_energy_j']-s['internal_energy_j'],
        'delta_Nc_mol':t['liquid_water_mol']-s['liquid_water_mol'],
        'delta_Nv_mol':t['gas_amounts_mol'][2]-s['gas_amounts_mol'][2],
        'delta_T_k':y['observations'][-1]['cells'][i]['inverse']['point']['fluid']['mechanical']['temperature_k']-x['observations'][-1]['cells'][i]['inverse']['point']['fluid']['mechanical']['temperature_k']})
meta=load(WORK/'supervised-native01','metadata.json')
status=load(WORK/'supervised-native01','status.json')
check('supervisor_inputs_unchanged',{k:v['sha256'] for k,v in meta['inputs_before'].items()}==status['inputs_after'] and status['inputs_unchanged'])
check('supervisor_completed_reaped',status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'])
result={'passed':all(c['passed'] for c in checks),'checks':checks,'original_gate_count':len(old['checks']),
    'old_integrator_seconds':old['integrator_seconds'],'new_integrator_seconds':new['integrator_seconds'],
    'old_over_new_wall_ratio':old['integrator_seconds']/new['integrator_seconds'],
    'inverse_metrics_old_new':metrics,'final_differences_new_minus_old':changes,
    'material_qualified':False,'spatial_temporal_convergence_demonstrated':False,
    'performance_scope':'single fixed native case; no general speed or equal-budget convergence guarantee'}
(WORK/'SAVED_COMPARISON.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2));assert result['passed']
