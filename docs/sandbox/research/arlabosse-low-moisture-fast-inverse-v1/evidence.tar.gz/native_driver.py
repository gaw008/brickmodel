"""One reviewed source-backed low-water run; no duplicate EOS validation path."""
from fractions import Fraction as F
from pathlib import Path
import importlib.util
import json
import time
import traceback

from sludge_sandbox.source_wet_column import integrate_source_column

WORK=Path('/private/tmp/arlabosse-low-moisture-fast-inverse-v1')
spec=importlib.util.spec_from_file_location('low_case',WORK/'native_case.py')
case=importlib.util.module_from_spec(spec)
spec.loader.exec_module(case)
OUT=WORK/'native01'
OUT.mkdir(exist_ok=False)
start=time.monotonic()

def save(name,data):
    (OUT/name).write_text(json.dumps(case.serialize(data),indent=2,allow_nan=False)+'\n')

checks=[]
def check(name,value):
    checks.append({'id':name,'passed':bool(value)})

try:
    column,initial,points=case.make_case(lambda p:save('CONSTRUCTION_PREFIX.json',p))
    base=column.base
    save('INITIAL.json',{'states':initial,'points':points,'provenance':column.provenance(),
        'actual_source_nodes':{'m':base.storages[0].wet._m,'q':base.storages[0].wet._q,
            'L95':base.storages[0].wet._latent_reference,'M':base.storages[0].wet._mass,
            'R':base.chemical.gas_constant_j_mol_k}})
    run=integrate_source_column(column,initial,duration_s=.05,steps=2,
        maximum_wall_seconds=60.,energy_roundoff_budget_j=1e-8,inventory_roundoff_budget_mol=1e-12)
    save('RUN.json',run)
    check('complete',run.status=='completed' and run.reason is None)
    check('counts',len(run.states)==3 and len(run.ledgers)==2 and len(run.observations)==2 and
          run.evaluations_attempted==run.evaluations_completed==6)
    check('clock',run.times_s==(F(),F(.05)/2,F(.05)))
    check('identity',run.model_identity==column.model_identity)
    check('energy_budget',run.energy_roundoff_used_j<=F(1e-8))
    check('inventory_budget',run.inventory_roundoff_used_mol<=F(1e-12))
    check('no_material_claim',run.material_qualified is False)
    check('initial_true_dry',initial[0].liquid_water_mol==0 and
        points[0].fluid.mechanical.liquid_pressure_pa is None and
        points[0].fluid.mechanical.liquid_volume_m3==0 and
        points[0].excess_internal_energy_j!=0 and points[0].excess.mu_ex_j_mol is None)
    u=lambda states:sum((F(s.internal_energy_j) for s in states),F())
    water=lambda states:sum((F(s.liquid_water_mol)+F(s.gas_amounts_mol[2]) for s in states),F())
    cumulative_u=cumulative_water=F()
    total_outflow=F()
    def decoded_checks(prefix,states,rates):
        for i,(state,cell,storage,policy) in enumerate(zip(states,rates.cells,base.storages,base.inverse_policies)):
            key=prefix+f'_cell{i}'
            inv=cell.inverse
            point=inv.point
            ex=point.excess
            eq=cell.phase.equilibrium
            require_w=F(state.liquid_water_mol)*F(storage.wet._mass)/F(storage.dry_mass_kg)
            check(key+'_actual_Nc',point.fluid.mechanical.liquid_inventory_mol==state.liquid_water_mol)
            check(key+'_actual_gas',point.fluid.mechanical.gas_inventory_mol==dict(zip(base.gas_ids,state.gas_amounts_mol)))
            check(key+'_actual_target',inv.target_energy_j==state.internal_energy_j and
                inv.energy_residual_j==F(point.total_internal_energy_j)-F(state.internal_energy_j))
            check(key+'_inverse_U',abs(inv.energy_residual_j)+F(point.energy_error_j)<=F(policy.energy_tolerance_j))
            check(key+'_inverse_T',inv.temperature_error_bound_k<=policy.temperature_tolerance_k)
            check(key+'_T_domain',325<=point.temperature_k<=338)
            check(key+'_P_domain',90000<=point.pressure_pa-point.pressure_error_pa and
                point.pressure_pa+point.pressure_error_pa<=110000)
            check(key+'_W',ex.moisture_kg_water_per_kg_dry==require_w and 0<=require_w<F(.15))
            check(key+'_retained_excess_U',point.excess_internal_energy_j==F(storage.dry_mass_kg)*ex.h_ex_j_kg_dry)
            check(key+'_F_identity',point.excess_helmholtz_energy_j==point.excess_internal_energy_j-
                F(point.temperature_k)*point.excess_entropy_j_k)
            check(key+'_actual_liquid_reference',eq.pure_equilibrium.liquid.state.temperature_k==point.temperature_k and
                eq.pure_equilibrium.liquid.state.pressure_pa==point.pressure_pa)
            check(key+'_activity',0<eq.activity<=1 and eq.equilibrium_partial_pressure_pa==
                float(F(eq.activity)*F(eq.pure_equilibrium.equilibrium_partial_pressure_pa)))
            check(key+'_mu',eq.chemical_potential_residual_j_mol is not None and abs(eq.chemical_potential_residual_j_mol)<=1e-7)
            check(key+'_phase_entropy',cell.phase.entropy_production_w_k is not None and cell.phase.entropy_production_w_k>=0)
            check(key+'_nonnegative',state.liquid_water_mol>=0 and all(v>=0 for v in state.gas_amounts_mol))
            check(key+'_false_flags',not point.material_qualified and not point.training_eligible)
    for j,(old,new,ledger,rates) in enumerate(zip(run.states,run.states[1:],run.ledgers,run.observations)):
        key=f'step{j}'
        if j==0:
            check('initial_phase_limit_preserved',ledger.predictor_rates.cells[0].phase.entropy_state=='positive_infinite_boundary_limit')
            check('initial_transport_limit_preserved',ledger.predictor_rates.faces[1].moisture_witness.exchange.entropy_state=='positive_infinite_boundary_limit')
        for stage,stage_rates,stage_faces,dt in (
            ('predictor',ledger.predictor_rates,ledger.predictor_faces,ledger.duration_s/2),
            ('accepted',ledger.midpoint_rates,ledger.faces,ledger.duration_s)):
            observation=stage_rates.boundary
            outer_rate=stage_rates.faces[-1]
            outer_integral=stage_faces[-1]
            expected_n=F(column.control.transfer_coefficient_mol_s_pa)*(F(observation.cell_vapor_pressure_pa)-F(column.control.vapor_pressure_pa))
            expected_h=expected_n*F(observation.common_vapor_enthalpy_j_mol)
            expected_q=F(column.control.heat_conductance_w_k)*(F(column.control.heat_bath_temperature_k)-F(observation.cell_temperature_k))
            check(key+'_'+stage+'_boundary_context',observation.cell_temperature_k==stage_rates.cells[-1].inverse.point.temperature_k and
                observation.cell_vapor_pressure_pa==stage_rates.cells[-1].phase.water_partial_pressure_pa)
            check(key+'_'+stage+'_boundary_nH',outer_rate.exact_water_mol_s==expected_n and outer_rate.exact_carried_energy_w==expected_h)
            check(key+'_'+stage+'_boundary_Q',outer_rate.exact_heat_into_cell_w==expected_q)
            check(key+'_'+stage+'_boundary_n_projection',outer_integral.vapor_molar_projection_mol==outer_integral.gas_mol[2]-dt*expected_n)
            check(key+'_'+stage+'_boundary_H_projection',outer_integral.vapor_enthalpy_projection_j==outer_integral.diffusive_enthalpy_j[2]-dt*expected_h)
            check(key+'_'+stage+'_boundary_Q_projection',outer_integral.heat_projection_j==-outer_integral.conduction_j-dt*expected_q)
            check(key+'_'+stage+'_stored_faces',all(f.energy_j==dt*F(r.energy_w) for f,r in zip(stage_faces,stage_rates.faces)))
        left,interior,outer=ledger.faces
        check(key+'_center_closed',left.energy_j==0 and all(v==0 for v in left.gas_mol))
        check(key+'_internal_gas_disabled',interior.gas_mol==(F(),F(),F()))
        check(key+'_active_heat',interior.conduction_j!=0)
        check(key+'_active_internal_water',interior.moisture_mol<0 and interior.moisture_enthalpy_j!=0)
        check(key+'_bound_runtime',interior.moisture_witness.source_state_binding_verified)
        check(key+'_actual_midpoint_states',ledger.midpoint_rates.closed_rates.model_identity==base.model_identity)
        check(key+'_midpoint_nH',interior.moisture_mol==ledger.duration_s*F(interior.moisture_witness.exchange.molar_flow_mol_s) and
            interior.moisture_enthalpy_j==ledger.duration_s*F(interior.moisture_witness.exchange.carried_energy_w))
        check(key+'_positive_outflow',outer.gas_mol[2]>0 and outer.gas_mol[:2]==(F(),F()))
        check(key+'_boundary_heat',ledger.boundary.heat_into_cell_w>0)
        check(key+'_vacuum_entropy',ledger.boundary.vapor_entropy_w_k is None and
            ledger.boundary.vapor_entropy_state=='positive_infinite_vacuum_limit')
        check(key+'_heat_entropy',ledger.boundary.heat_entropy_w_k>=0)
        for i,(before,after) in enumerate(zip(old,new)):
            lf,rf=ledger.faces[i:i+2]
            check(key+f'_cell{i}_U',F(after.internal_energy_j)-F(before.internal_energy_j)==
                lf.energy_j-rf.energy_j+ledger.roundoff.energy_j[i])
            check(key+f'_cell{i}_Nc',F(after.liquid_water_mol)-F(before.liquid_water_mol)==
                getattr(lf,'moisture_mol',F())-getattr(rf,'moisture_mol',F())-
                ledger.phase_water_mol[i]+ledger.roundoff.liquid_mol[i])
            for k in range(3):
                check(key+f'_cell{i}_gas{k}',F(after.gas_amounts_mol[k])-F(before.gas_amounts_mol[k])==
                    lf.gas_mol[k]-rf.gas_mol[k]+(ledger.phase_water_mol[i] if k==2 else F())+
                    ledger.roundoff.gas_mol[i][k])
        for face in ledger.faces:
            check(key+f'_face{face.face_id}_energy_decomposition',face.energy_j==face.conduction_j+
                sum(face.diffusive_enthalpy_j,F())+sum(face.advective_enthalpy_j,F())+
                getattr(face,'moisture_enthalpy_j',F())+face.energy_decomposition_roundoff_j)
        eu=-outer.energy_j+sum(ledger.roundoff.energy_j,F())
        ew=-outer.gas_mol[2]+sum(ledger.roundoff.liquid_mol,F())+sum((r[2] for r in ledger.roundoff.gas_mol),F())
        cumulative_u+=eu
        cumulative_water+=ew
        total_outflow+=outer.gas_mol[2]
        check(key+'_global_U',u(new)-u(old)==eu)
        check(key+'_global_water',water(new)-water(old)==ew)
        check(key+'_prefix_U',u(new)-u(initial)==cumulative_u)
        check(key+'_prefix_water',water(new)-water(initial)==cumulative_water)
        for k in range(2):
            check(key+f'_inert{k}',tuple(s.gas_amounts_mol[k] for s in new)==tuple(s.gas_amounts_mol[k] for s in initial))
        decoded_checks(key+'_middle',ledger.midpoint_states,ledger.midpoint_rates)
        decoded_checks(key+'_end',new,rates)
    check('rewetted_dry_cell',run.states[-1][0].liquid_water_mol>0)
    check('total_water_removed',total_outflow>0 and water(run.states[-1])<water(initial))
    if run.observations:
        for i,(p,c) in enumerate(zip(points,run.observations[-1].cells)):
            check(f'cell{i}_resolved_temperature_change',abs(c.inverse.point.temperature_k-p.temperature_k)>
                c.inverse.temperature_error_bound_k+1e-6)
    check('integrator_wall',run.elapsed_seconds<60.)
    check('driver_wall',time.monotonic()-start<80.)
    report={'passed':all(c['passed'] for c in checks),'checks':checks,
        'integrator_seconds':run.elapsed_seconds,'driver_seconds':time.monotonic()-start,
        'total_water_outflow_mol':total_outflow,
        'final_temperatures_k':[c.inverse.point.temperature_k for c in run.observations[-1].cells] if run.observations else [],
        'material_qualified':False,'spatial_temporal_convergence_demonstrated':False}
    save('ACCEPTANCE.json',report)
    print(json.dumps(case.serialize(report)))
    assert report['passed'],'low_water_native_acceptance_failed'
except BaseException as exc:
    save('FAILURE.json',{'type':type(exc).__name__,'message':str(exc),'elapsed_seconds':time.monotonic()-start,
        'traceback':traceback.format_exc()})
    raise
