# Safeguarded low-moisture inverse draft — bounded independent review

**APPROVE**, no unresolved findings in the scratch draft. Read the whole implementation and author tests, the original full-U bisection, `InversePolicy`, and the existing inverse-result contract. No implementation was imported or executed, no author tests were rerun, no EOS was called, and no production/installation/native selection changed.

## Static result

- Full-U target remains the original exact binary64 state U; the source excess, including the dry reference offset, is never subtracted. Both original temperature endpoints are evaluated through unchanged storage and independently checked for source identity, finite bounded U/Cv and the whole pressure envelope. The inward support inequality is unchanged and precedes endpoint acceptance.
- Exact storage/policy type gates and `replace(policy)` revalidation reject invalid or mutated policy values, including maximum iterations zero or boolean, before endpoint evaluation. A valid endpoint return may report zero **candidate** iterations only after the two required endpoint calls; it does not admit a zero-iteration policy.
- Every returned result uses `abs(full-U residual)+energy_error`; the minimum-Cv ratio is rounded outward and must satisfy the original temperature tolerance as well as the original energy tolerance. Unknown/negative/nonfinite errors, nonpositive capacity, minimum Cv larger than local Cv, or invalid pressure bounds fail rather than receiving a fallback bound.
- Endpoint secant and local-Cv Newton values are proposals only. They must round to a strictly interior finite binary64 temperature. Unusable proposals fall back to a rational midpoint, and every third candidate is forced to a midpoint. The algorithm does not swallow provider errors. A nonaccepted result updates its bracket only after `abs(residual)>energy_error` proves its sign. The existing representable-bracket and maximum-iteration failure gates remain active.
- The nominal endpoint energies are used only for the first proposal; subsequent interval sign updates are unaffected by not recomputing a new secant. The loop cannot acquire extra hidden evaluate calls: two endpoint evaluations plus one per attempted candidate. Successful return rechecks the state; the final bracket describes the current search interval while temperature accuracy comes from the unchanged residual/Cv criterion.
- Returning the existing `SourceWetInverse` is compatible with its fields, but future host use must explicitly choose and bind `NUMERICAL_POLICY_ID`. The scratch function does not replace the production inverse on import or alter the current frozen native path.

## Saved evidence inspected, not rerun

`SHA01.json` matches current module, tests and call-record bytes. `GREEN01.xml` records 16 author manufactured tests, zero failures/errors/skips. Passive record checks verify every listed call count equals the temperature-list length and candidate iterations plus two endpoints; all saved new candidates lie inside the evolving interval and the available forced-third candidate equals its midpoint.

The saved examples contain call reductions **31 → 3**, **33 → 7**, and **30 → 3** for two manufactured caloric curves and dry/positive condensed states. These are callback counts, not actual EOS timings or general speed guarantees. The passive check uses the named monotone manufactured target-temperature cases only; it does not recreate source U, EOS, or acceptance certificates.

This code review preserves the inherited thermodynamic/minimum-Cv assumptions. It does not independently certify those physical bounds, material correspondence, native performance, temporal convergence, or the full firing cycle.

## Subject SHA-256

- `low_moisture_fast_inverse.py`: `56fb7df8aee1ed868611916fce503a1fc2535da61691264685dd15dd94bb0fc8`
- `test_low_moisture_fast_inverse.py`: `2fc511c8158e5c6cd11ad4e46b2cead7c30a11544ad26114e9c63441a8ee4f41`
- `CALL_COUNTS.json`: `799fd529466c4fc3a451e7db609052fa0a6cb7e2ca769d320201aba55d9fb96a`

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE** for the separately identified scratch numerical strategy.
