"""Algorithm-only manufactured exact quadratic callbacks: no source/EOS certification.

Exact storage/result classes retain the candidate/gate code path, while storage
check/evaluate are explicit test seams; no physical providers are constructed.
"""
from fractions import Fraction as F
from types import SimpleNamespace as NS
import math
import pytest
import low_moisture_fast_inverse as fast
from sludge_sandbox.arlabosse_low_moisture_storage import LowMoistureSorptionStorage,LowMoistureSorptionPoint
from sludge_sandbox.phase_storage import InversePolicy
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential


@pytest.fixture
def quadratic(monkeypatch):
    def forbidden(*args,**kwargs):
        raise AssertionError('independent_inverse_math_forbids_EOS')
    monkeypatch.setattr(WaterProperties,'__init__',forbidden)
    monkeypatch.setattr(WaterProperties,'_solve',forbidden)
    monkeypatch.setattr(WaterChemicalPotential,'__init__',forbidden)
    storage=object.__new__(LowMoistureSorptionStorage)
    for name,value in {'base':NS(temperature_domain_k=(310.,350.)),
        'pressure_domain_pa':(90000.,110000.),'_identity':'manufactured:inverse-math'}.items():
        object.__setattr__(storage,name,value)
    controls={'calls':[],'bad_high':False,'offset':F(-1000000)}
    def exact(t):return controls['offset']+(F(t)-300)**2
    def evaluate(self,state,t):
        controls['calls'].append(t)
        value=exact(t);u=float(value)
        return LowMoistureSorptionPoint(fluid=NS(mechanical=NS(temperature_k=t,pressure_pa=100000.)),
            total_internal_energy_j=u,solid_internal_energy_j=F(),available_pore_volume_m3=.001,
            available_volume_error_m3=0.,global_pressure_error_pa=0.,extra_pressure_error_pa=0.,
            pressure_error_pa=20000. if controls['bad_high'] and t==350. else 0.,
            energy_error_j=float(abs(F(u)-value)),closed_heat_capacity_j_k=2*(t-300),
            minimum_heat_capacity_j_k=20.,model_identity=self._identity,
            source_ids=('manufactured:exact-quadratic-caloric',),excess=NS(branch='manufactured-dry-offset'),
            excess_internal_energy_j=controls['offset'],excess_entropy_j_k=F(),
            excess_helmholtz_energy_j=controls['offset'])
    def check(self,state):
        assert self is storage and state.liquid_water_mol==0.
    monkeypatch.setattr(LowMoistureSorptionStorage,'evaluate',evaluate)
    monkeypatch.setattr(LowMoistureSorptionStorage,'check',check)
    def state(t):return NS(internal_energy_j=float(exact(t)),liquid_water_mol=0.)
    return storage,controls,state


@pytest.mark.parametrize('endpoint',[310.,350.])
def test_valid_endpoint_zero_candidates_still_evaluates_both_endpoints(quadratic,endpoint):
    storage,c,state=quadratic
    target=state(endpoint)
    result=fast.invert_low_moisture_safeguarded(storage,target,InversePolicy(1e-9,1e-9,1))
    assert c['calls']==[310.,350.]
    assert result.iterations==0 and result.point.temperature_k==endpoint
    assert result.target_energy_j==target.internal_energy_j<0
    assert result.point.excess_internal_energy_j==c['offset']!=0
    assert result.energy_residual_j==0 and result.temperature_error_bound_k==0


def test_valid_low_endpoint_cannot_bypass_bad_high_endpoint_envelope(quadratic):
    storage,c,state=quadratic
    c['bad_high']=True
    with pytest.raises(ValueError,match='pressure_domain_exit'):
        fast.invert_low_moisture_safeguarded(storage,state(310.),InversePolicy(1e-9,1e-9,1))
    assert c['calls']==[310.,350.]


def test_same_budget_is_not_a_guarantee_of_bisection_success(quadratic):
    storage,c,state=quadratic
    target=state(335.)
    policy=InversePolicy(1e-9,1e-9,3)
    old=storage.invert(target,policy)
    assert old.iterations==3 and old.point.temperature_k==335.
    assert len(c['calls'])==old.iterations+2==5
    c['calls'].clear()
    with pytest.raises(ValueError,match='iteration_limit'):
        fast.invert_low_moisture_safeguarded(storage,target,policy)
    calls=c['calls']
    assert len(calls)==5
    lo,hi=310.,350.
    for i,t in enumerate(calls[2:],1):
        assert lo<t<hi
        before=F(hi)-F(lo)
        if i%3==0:
            assert t==float((F(lo)+F(hi))/2)
        if t>335.:hi=t
        else:lo=t
        if i%3==0:
            assert F(hi)-F(lo)<=before/2+F(math.ulp(t))/2
