"""Passive merged review of failed flash01 and successful nominal flash02."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math

WORK=Path('/private/tmp/arlabosse-equilibrium-flash-v1')
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
OUT=WORK/'saved-review'
def hook(d):
    return F(d['numerator'],d['denominator']) if set(d)=={'numerator','denominator'} and all(type(v) is int for v in d.values()) else d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[];summaries=[];snapshots=[]
def check(name,value):checks.append({'id':name,'passed':bool(value)})

for number,carrier in ((1,[.0000714,.0002686]),(2,[.0000672,.0002528])):
    key=f'case{number}';folder=WORK/f'native{number:02d}'
    initial=read(folder/'INITIAL.json');state=initial['state'];ip=initial['point'];provenance=initial['storage_provenance']
    record=read(folder/('FAILURE.json' if number==1 else 'RESULT.json'));inputs=read(folder/'INPUTS.json')
    nt=F(state['liquid_water_mol'])+F(state['gas_amounts_mol'][2]);target=F(state['internal_energy_j'])
    check(key+'_declared_initial_and_full_target',state['solid_mass_kg']==[.01] and state['liquid_water_mol']==.06 and state['gas_amounts_mol']==carrier+[1e-6] and ip['fluid']['mechanical']['temperature_k']==333. and state['internal_energy_j']==ip['total_internal_energy_j'] and ip['available_pore_volume_m3']==1e-5 and provenance['temperature_domain_k']==[325.,338.] and provenance['pressure_domain_pa']==[90000.,110000.])
    trials=record['trials'];counts=record['counts'];kinds=Counter(t['kind'] for t in trials)
    point_count=0;max_projection=F();max_g_pressure=0.;last_storage=None
    for i,trial in enumerate(trials):
        p=trial['point']
        if p is None:continue
        point_count+=1;m=p['fluid']['mechanical'];nc=F(m['liquid_inventory_mol']);gas=m['gas_inventory_mol'];nv=F(gas['H2O']);t=m['temperature_k'];ex=p['excess']
        residual=F(p['total_internal_energy_j'])-target
        projection=nc+nv-nt;max_projection=max(max_projection,abs(projection))
        reconstructed=float(F(float(F(p['fluid']['internal_energy_j'])+F(p['solid_internal_energy_j'])))+p['excess_internal_energy_j'])
        ok=(p['model_identity']==state['energy_model_identity']==provenance['model_identity'] and p['source_ids']==ip['source_ids'] and t==trial['temperature_k'] and nc==trial['liquid_mol'] and nc>=0 and nv>=0 and [gas['O2'],gas['N2']]==carrier and gas['H2O']==float(nt-nc) and abs(projection)<=F(1e-12))
        ok &= reconstructed==p['total_internal_energy_j'] and p['energy_error_j']>=0 and p['minimum_heat_capacity_j_k']>0 and 325<=t<=338 and F(90000)<=F(m['pressure_pa'])-F(p['pressure_error_pa'])<=F(m['pressure_pa'])+F(p['pressure_error_pa'])<=F(110000)
        mass=F(ip['excess']['moisture_kg_water_per_kg_dry'])*F(.01)/F(.06)
        ok &= ex['moisture_kg_water_per_kg_dry']==nc*mass/F(.01)<=F(.15) and p['excess_internal_energy_j']==F(.01)*ex['h_ex_j_kg_dry'] and p['material_qualified'] is False and p['training_eligible'] is False
        if trial['kind']=='storage':last_storage=p
        else:
            ok &= trial['kind']=='chemical_and_energy' and last_storage==p and trial['energy_residual_j']==residual
            pv=float(nv*F(m['gas_constant_j_mol_k'])*F(t)/F(m['gas_volume_m3']));peq=F(pv)+trial['pressure_residual_pa']
            mu=m['gas_constant_j_mol_k']*t*(math.log(float(peq))-math.log(pv))
            max_g_pressure=max(max_g_pressure,abs(mu-trial['chemical_residual_j_mol']))
            ok &= abs(mu-trial['chemical_residual_j_mol'])<=1e-7
        check(f'{key}_trial{i}_actual_state_U_source_domain',ok)
    check(key+'_provider_counts_correspond_to_complete_records',kinds['storage']==kinds['chemical_and_energy']==counts['storage_evaluations']==counts['pure_equilibrium_evaluations']==counts['vapor_evaluations'] and kinds['pressure_prefilter']==counts['equilibrium_temperature_evaluations'] and counts['liquid_boundary_evaluations']==2*counts['equilibrium_temperature_evaluations'] and counts['provider_calls']==sum(counts[k] for k in ('storage_evaluations','liquid_boundary_evaluations','pure_equilibrium_evaluations','vapor_evaluations')) and counts['provider_calls']<=500)
    meta=read(WORK/f'supervised-native{number:02d}/metadata.json');status=read(WORK/f'supervised-native{number:02d}/status.json')
    before={p:v['sha256'] if isinstance(v,dict) else v for p,v in meta['inputs_before'].items()};snapshots.append(before)
    check(key+'_supervised_terminal_inputs_and_original_resources',before==status['inputs_after'] and status['inputs_unchanged'] is True and status['cleanup']['leader_reaped'] is True and status['returncode']==(1 if number==1 else 0) and status['status']==('failed' if number==1 else 'complete') and meta['timeout_s']==60 and meta['cleanup_grace_s']==5 and status['elapsed_s']<65 and '-I' in meta['command'] and len(before)==(2596 if number==1 else 2597))
    check(key+'_tracked_scratch_and_policy_unchanged',all(before[p]==value==sha(Path(p)) for p,value in inputs['inputs'].items()) and inputs['policy']['maximum_provider_calls']==500 and inputs['policy']['maximum_elapsed_s']==50 and inputs['policy']['composition_tolerance_mol']==1e-11 and inputs['policy']['energy_tolerance_j']==1e-5 and inputs['policy']['nominal_temperature_width_tolerance_k']==1e-6)
    if number==1:
        excluded=[(t['temperature_k'],t['reason']) for t in trials if t['kind']=='excluded_temperature']
        check('case1_original_failure_preserved',record['error_type']=='FlashFailure' and record['reason']=='flash_temperature_bracket_not_found_within_scan_budget' and excluded==[(t,'flash_composition_no_sign_bracket') for t in (331.5,334.75,338.)] and counts['equilibrium_temperature_evaluations']==5 and record['inputs_unchanged'] is True and record['material_qualified'] is False and not (folder/'RESULT.json').exists() and not (folder/'ACCEPTANCE.json').exists())
        last=record['last_completed_provider_result'];context=record['last_completed_provider_context']
        check('case1_last_returned_provider_is_recorded',context==['vapor_evaluations',[last['temperature_k'],last['partial_pressure_pa']]] and last['temperature_k']==338. and math.fsum([last['enthalpy_j_mol'],-last['temperature_k']*last['entropy_j_mol_k']])==last['chemical_potential_j_mol'])
        runtime=record['runtime_seconds']
    else:
        r=record;p=r['point'];s=r['state'];m=p['fluid']['mechanical'];acceptance=read(folder/'ACCEPTANCE.json');runtime=acceptance['runtime_seconds']
        actual_res=F(p['total_internal_energy_j'])-target;allowance=abs(actual_res)+F(p['energy_error_j']);lo,hi=r['nominal_temperature_bracket_k'];xl,xh=r['composition_bracket_mol']
        reconstructed_checks={'original_target_energy_retained':s['internal_energy_j']==state['internal_energy_j'],'target_residual_correct':r['energy_residual_j']==actual_res,'full_U_residual_plus_point_error':allowance<=F(1e-5),'nominal_T_bracket_width':F(hi)-F(lo)<=F(1e-6),'candidate_in_T_bracket':lo<=m['temperature_k']<=hi,'original_T_domain':325<=m['temperature_k']<=338,'full_pressure_interval':F(90000)<=F(m['pressure_pa'])-F(p['pressure_error_pa'])<=F(m['pressure_pa'])+F(p['pressure_error_pa'])<=F(110000),'low_water_domain':0<=F(s['liquid_water_mol'])*mass/F(.01)<=F(.15),'exact_requested_total_water':r['exact_liquid_mol']+r['exact_vapor_mol']==nt,'saved_water_projection':F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2])-nt==r['water_projection_residual_mol'],'inventory_budget':abs(r['liquid_projection_error_mol'])+abs(r['vapor_projection_error_mol'])<=F(1e-12),'carrier_unchanged':s['gas_amounts_mol'][:2]==carrier,'equilibrium_pressure_residual':abs(r['equilibrium_pressure_residual_pa'])<=F(1e-5),'chemical_residual':r['chemical_potential_residual_j_mol'] is not None and abs(r['chemical_potential_residual_j_mol'])<=1e-5,'no_certificate_upgrade':r['certified_temperature_error_bound_k'] is None and r['equilibrium_composition_energy_error_j'] is None,'no_material_upgrade':not r['material_qualified'] and not r['training_eligible'],'driver_wall_limit':runtime<=60,'inputs_unchanged':all(sha(Path(p))==value for p,value in inputs['inputs'].items())}
        check('case2_all_18_acceptance_gates_recomputed',len(reconstructed_checks)==18 and reconstructed_checks==acceptance['checks'] and all(reconstructed_checks.values()) and acceptance['passed'] is True)
        chemical=[t for t in trials if t['kind']=='chemical_and_energy']
        valid=xl<=F(s['liquid_water_mol'])<=xh and xh-xl<=F(1e-11)
        for t,sign in ((lo,-1),(hi,1)):
            valid &= any(v['temperature_k']==t and abs(v['chemical_residual_j_mol'])<=1e-5 and abs(v['pressure_residual_pa'])<=F(1e-5) and sign*v['energy_residual_j']>F(v['point']['energy_error_j']) for v in chemical)
        for x,sign in ((xl,-1),(xh,1)):
            valid &= any(v['temperature_k']==m['temperature_k'] and v['liquid_mol']==x and sign*v['chemical_residual_j_mol']>=0 for v in chemical)
        check('case2_both_nominal_brackets_have_actual_sign_samples',valid)
        check('case2_candidate_and_exact_projection_match_trial',any(v['point']==p and v['energy_residual_j']==actual_res and v['chemical_residual_j_mol']==r['chemical_potential_residual_j_mol'] and v['pressure_residual_pa']==r['equilibrium_pressure_residual_pa'] for v in chemical) and F(s['liquid_water_mol'])-r['exact_liquid_mol']==r['liquid_projection_error_mol'] and F(s['gas_amounts_mol'][2])-r['exact_vapor_mol']==r['vapor_projection_error_mol'] and r['water_projection_residual_mol']==r['liquid_projection_error_mol']+r['vapor_projection_error_mol'] and r['equilibrium_pressure_residual_pa']==F(r['equilibrium_partial_pressure_pa'])-F(r['water_partial_pressure_pa']) and r['nominal_chemical_numerical_error_j_mol'] is None)
        final={'T_k':m['temperature_k'],'P_pa':m['pressure_pa'],'P_error_pa':p['pressure_error_pa'],'Nc_mol':s['liquid_water_mol'],'Nv_mol':s['gas_amounts_mol'][2],'full_U_allowance_j':float(allowance),'U_residual_j':float(actual_res),'T_bracket_width_k':float(F(hi)-F(lo)),'x_bracket_width_mol':float(xh-xl),'water_projection_mol':float(r['water_projection_residual_mol']),'peq_minus_pv_pa':float(r['equilibrium_pressure_residual_pa']),'mu_j_mol':r['chemical_potential_residual_j_mol']}
    check(key+'_saved_driver_runtime_within_limit',runtime<60)
    summaries.append({'case':number,'provider_calls':counts['provider_calls'],'storage_calls':counts['storage_evaluations'],'equilibrium_temperature_calls':counts['equilibrium_temperature_evaluations'],'point_records_checked':point_count,'maximum_total_water_projection_mol':float(max_projection),'maximum_nominal_mu_pressure_difference_j_mol':max_g_pressure,'driver_seconds':runtime,'supervisor_seconds':status['elapsed_s'],'tracked_inputs':len(before)})

plan2=read(WORK/'NATIVE_PLAN02.json');common=set(snapshots[0])&set(snapshots[1])
check('case2_new_plan_preserves_case1_and_execution_bytes',sha(WORK/'native01/FAILURE.json')==plan2['original_failure_preserved']['sha256'] and all(snapshots[0][p]==snapshots[1][p] for p in common) and set(snapshots[1])-set(snapshots[0])=={str(WORK/'NATIVE_PLAN02.json')})
check('same_storage_source_domains_with_new_initial_energy',read(WORK/'native01/INITIAL.json')['storage_provenance']==read(WORK/'native02/INITIAL.json')['storage_provenance'] and read(WORK/'native01/INITIAL.json')['state']['internal_energy_j']!=read(WORK/'native02/INITIAL.json')['state']['internal_energy_j'])
check('production_migration_byte_exact',sha(ROOT/'src/sludge_sandbox/low_moisture_equilibrium.py')==sha(WORK/'implementation/low_moisture_equilibrium.py')=='26f329aeb9203986701e1c43dffde48394516f5234eda6324f22a3cfd34f5ded')
check('test_migration_only_package_import',(WORK/'implementation/test_low_moisture_equilibrium.py').read_text().replace('import low_moisture_equilibrium as module','import sludge_sandbox.low_moisture_equilibrium as module')==(ROOT/'tests/sandbox/test_low_moisture_equilibrium.py').read_text())
output={'passed':all(x['passed'] for x in checks),'checks':checks,'cases':summaries,'final_candidate':final,'scope':'Pure saved arithmetic and byte comparison; no EOS, app import, native or test execution. Case01 failure preserved; case02 is a distinct declared carrier scenario; all temperature/equilibrium conclusions remain nominal.'}
with (OUT/'SAVED_REVIEW01.json').open('x') as f:json.dump(output,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'passed':output['passed'],'check_count':len(checks),'failures':[x['id'] for x in checks if not x['passed']],'cases':summaries,'final_candidate':final},indent=2))
raise SystemExit(0 if output['passed'] else 1)
