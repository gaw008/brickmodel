"""UNEXECUTED single-cell construction for parent review and one bounded run.

Same source storage, volume/error, species, and full-U reference as the previous
long-probe wet cell. This file builds no column, transport, boundary, or phase K.
An external driver owns isolation, SHA freeze, 60 s deadline, and raw output.
"""
from dataclasses import replace
from fractions import Fraction as F
import json
from pathlib import Path

from sludge_sandbox.arlabosse_caloric import ArlabosseDryCaloric
from sludge_sandbox.arlabosse_wet_thermo import ArlabosseWetThermodynamics
from sludge_sandbox.arlabosse_low_moisture import ArlabosseLowMoisture
from sludge_sandbox.arlabosse_low_moisture_storage import LowMoistureSorptionStorage
from sludge_sandbox.source_mass_caloric import ArlabosseMassCaloric, ReactionDisabled
from sludge_sandbox.source_wet_storage import SourceWetStorage, ManufacturedFixedFluidVolume
from sludge_sandbox.mass_wet_storage import WaterElementConvention
from sludge_sandbox.rigid_storage import RigidStorage, DeclaredNumericalEnvelope
from sludge_sandbox.rigid_water_gas import RigidWaterGas, PressurePolicy
from sludge_sandbox.phase_storage import IdealGasPhase, InversePolicy
from sludge_sandbox.thermochemistry import load_thermochemistry

from low_moisture_equilibrium import FlashPolicy, flash


def native_policy() -> FlashPolicy:
    return FlashPolicy(InversePolicy(1e-5, 1e-6, 40), (325., 338.), 1.,
        1e-11, 1e-12, 1e-5, 1e-5, 4, 40, 500, 50.)


def make_cell(root: Path, *, carrier_mol: tuple[float, float] = (.0000714, .0002686)) -> tuple:
    """Exactly one original storage evaluation at Nc=.06, Nv=1e-6, T=333 K."""
    ids = ('O2', 'N2', 'H2O')
    fixture_id = 'manufactured:arlabosse-low-water-long-n2-v1'
    wet = ArlabosseWetThermodynamics(root, root/'data/sandbox/water')
    chemical = wet._chemical
    water, vapor = chemical.water, chemical.vapor
    rows = {row['species_id']: row for row in json.loads(
        (root/'data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json').read_bytes())}
    thermo = load_thermochemistry(root/'data/sandbox/thermochemistry/nist_gases_v1.json')
    phases = {key: IdealGasPhase(thermo.species(key), rows[key]['nominal_molar_mass_kg_mol'],
        0, (rows[key]['source_id'], rows[key]['cache_sha256'])) for key in ids[:2]}
    phases['H2O'] = IdealGasPhase(vapor, vapor.molar_mass_kg_mol)
    mechanical = RigidWaterGas(water, ids, 1e-5, (80000., 120000.),
        'planar_interface_no_capillary_pressure', PressurePolicy(1e-12, .1, 100,
        strategy='guarded_liquid_endpoint_interpolation_v1'))
    envelope = DeclaredNumericalEnvelope((325., 338.), (80000., 120000.),
        1e-8, 1e-16, 1e-4, {k: 1e-7 for k in ids}, {k: 20. for k in ids},
        'explicit_conditional_numerical_test_envelope_not_independent_eos_certificate', (fixture_id,))
    caloric = ArlabosseMassCaloric(ArlabosseDryCaloric(
        root/'data/sandbox/research/arlabosse2005/source.json', root), F('313.15'))
    chemistry = ReactionDisabled((caloric.component_id,), ids,
        'Fixed-composition source-sorption integration; reactions unsupported')
    volume = ManufacturedFixedFluidVolume(1e-5, 1e-12,
        'Manufactured fixed available liquid-plus-gas volume, not measured brick porosity')
    elements = WaterElementConvention.load(root/'data/sandbox/research/water-element-convention-v1/facts.json')
    base = SourceWetStorage(caloric, .01, RigidStorage(mechanical, phases, envelope),
        volume, (325., 338.), chemistry, elements)
    storage = LowMoistureSorptionStorage(base, wet, (90000., 110000.),
        excess=ArlabosseLowMoisture(wet))
    if type(carrier_mol) is not tuple or len(carrier_mol) != 2:
        raise ValueError('explicit_O2_N2_carrier_tuple')
    state = storage.state(.06, (*carrier_mol, .000001), 0.)
    point = storage.evaluate(state, 333.)
    state = replace(state, internal_energy_j=point.total_internal_energy_j)
    return storage, chemical, state, point


def run_one(root: Path, *, carrier_mol: tuple[float, float] = (.0000714, .0002686)) -> tuple:
    """Driver must preserve a FlashFailure rather than retrying or changing P."""
    storage, chemical, state, initial_point = make_cell(root, carrier_mol=carrier_mol)
    total = F(state.liquid_water_mol)+F(state.gas_amounts_mol[2])
    result = flash(storage, chemical, total, state.gas_amounts_mol[:2],
                   state.internal_energy_j, native_policy())
    return state, initial_point, result
