"""Five saved nominal diagnostic samples only: no application import or EOS."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math

WORK=Path('/private/tmp/arlabosse-equilibrium-flash-v1')
OUT=WORK/'consistency-review'
BASE=Path('/private/tmp/arlabosse-low-moisture-implicit-v1/long-probe/native01/INITIAL.json')
def hook(d):
    return F(d['numerator'],d['denominator']) if set(d)=={'numerator','denominator'} and all(type(v) is int for v in d.values()) else d
def read(p):return json.loads(p.read_text(),object_hook=hook)
d=read(WORK/'consistency01.json');plan=read(WORK/'CONSISTENCY_PLAN.json');base=read(BASE)
c,tm,tp,xm,xp=d['observations'];nt=F(base['states'][1]['liquid_water_mol'])+F(base['states'][1]['gas_amounts_mol'][2])
checks=[]
def check(name,value):checks.append({'id':name,'passed':bool(value)})
check('final_plan_and_fixed_tolerances',d['plan']==plan and plan['condensed_delta_mol']==1e-7 and plan['temperature_delta_k']==.01 and plan['relative_diagnostic_tolerance']==1e-4 and plan['absolute_Ux_diagnostic_tolerance_j_mol']==1.)
check('recorded_five_point_stencil',[(r['T'],r['Nc']) for r in d['observations']]==[(333.,.06),(332.99,.06),(333.01,.06),(333.,.06-1e-7),(333.,.06+1e-7)])
check('exact_total_water_and_positive_projected_inventories',all(F(r['Nc'])+F(r['Nv'])-nt==r['water_projection_residual_mol']==0 and r['Nv']==float(nt-F(r['Nc'])) and r['Nc']>0 and r['Nv']>0 for r in d['observations']))
p=base['points'][1];m=p['fluid']['mechanical']
check('center_matches_previous_actual_long_case',c['U']==p['total_internal_energy_j'] and c['Cv']==p['closed_heat_capacity_j_k'] and c['P']==m['pressure_pa'] and c['U_error']==p['energy_error_j'] and c['P_error']==p['pressure_error_pa'] and c['source_ids']==p['source_ids'])
check('common_source_and_original_state_domain',all(r['source_ids']==c['source_ids'] and 325<=r['T']<=338 and F(90000)<=F(r['P'])-F(r['P_error']) and F(r['P'])+F(r['P_error'])<=F(110000) and 0<F(r['Nc'])*F(base['actual_source_nodes']['M'])/F(.01)<=F(.15) for r in d['observations']))
ux=(xp['U']-xm['U'])/(xp['Nc']-xm['Nc']);gt=(tp['g']-tm['g'])/(tp['T']-tm['T']);ut=(tp['U']-tm['U'])/(tp['T']-tm['T']);rhs=c['g']-c['T']*gt
check('saved_Ux_gT_and_residual_arithmetic',ux==d['U_x_j_mol'] and rhs==d['g_minus_T_gT_j_mol'] and ux-rhs==d['U_x_identity_residual_j_mol'])
check('saved_fixed_composition_Cv_arithmetic',ut==d['U_T_j_k'] and c['Cv']==d['closed_Cv_j_k'] and (ut-c['Cv'])/c['Cv']==d['Cv_relative_residual'])
threshold=max(plan['absolute_Ux_diagnostic_tolerance_j_mol'],plan['relative_diagnostic_tolerance']*abs(rhs))
check('original_nominal_diagnostic_gates',d['checks']=={'U_x_identity':abs(ux-rhs)<=threshold,'fixed_composition_Cv':abs(ut-c['Cv'])<=1e-4*abs(c['Cv'])} and all(d['checks'].values()))
R=base['actual_source_nodes']['R'];g_errors=[r['g']-R*r['T']*(math.log(r['peq'])-math.log(r['pv'])) for r in d['observations']]
check('nominal_g_agrees_with_saved_phase_pressure_drive',max(map(abs,g_errors))<=1e-7)
check('runtime_and_explicit_scope',d['runtime_seconds']<plan['wall_limit_s']==60 and d['material_qualified'] is False and d['global_thermodynamic_certificate'] is False)
du=F(xp['Nc'])-F(xm['Nc']);dt=F(tp['T'])-F(tm['T'])
check('unused_initial_dx_would_leave_inventory_domain',nt-F(.06+1e-5)<0)
summary={'U_x_j_mol':ux,'g_minus_T_gT_j_mol':rhs,'identity_residual_j_mol':ux-rhs,'nominal_Ux_tolerance_j_mol':threshold,'U_T_j_k':ut,'closed_Cv_j_k':c['Cv'],'Cv_relative_residual':d['Cv_relative_residual'],'U_only_uncertainty_in_x_difference_j_mol':float((F(xp['U_error'])+F(xm['U_error']))/du),'U_only_uncertainty_in_T_difference_j_k':float((F(tp['U_error'])+F(tm['U_error']))/dt),'maximum_nominal_pressure_drive_disagreement_j_mol':max(map(abs,g_errors)),'total_water_exact':[str(nt.numerator),str(nt.denominator)],'projection_residuals_all_exact_zero':True,'g_and_truncation_error_bound':None,'runtime_seconds':d['runtime_seconds']}
paths=[WORK/'check_consistency.py',WORK/'CONSISTENCY_PLAN.json',WORK/'consistency01.json',BASE]
result={'passed':all(c['passed'] for c in checks),'checks':checks,'summary':summary,'read_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'limitations':['Final plan overwrote initial dx registration; no immutable original revision survives.','Five nominal samples are not a global thermodynamic or equilibrium-flash temperature certificate.']}
with (OUT/'SAVED_REVIEW01.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'passed':result['passed'],'checks':len(checks),'failures':[c['id'] for c in checks if not c['passed']],'summary':summary},indent=2))
raise SystemExit(0 if result['passed'] else 1)
