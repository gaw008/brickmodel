"""Small independent manufactured-provider probes; no actual water calls."""
from dataclasses import replace
from fractions import Fraction as F
from types import SimpleNamespace

import pytest

from test_low_moisture_equilibrium import analytic, solve
import low_moisture_equilibrium as module
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential


def test_elapsed_failure_keeps_last_returned_provider_object(analytic, monkeypatch):
    clock = [0.]
    returned = []
    original = WaterChemicalPotential.liquid_tp
    monkeypatch.setattr(module, 'time', SimpleNamespace(monotonic=lambda: clock[0]))

    def slow_liquid(self, t, p):
        out = original(self, t, p)
        returned.append(out)
        clock[0] = 2.
        return out

    monkeypatch.setattr(WaterChemicalPotential, 'liquid_tp', slow_liquid)
    with pytest.raises(module.FlashFailure, match='flash_elapsed_budget') as exc:
        solve(analytic, policy=replace(analytic.policy, maximum_elapsed_s=1.))
    assert exc.value.counts['provider_calls'] == 1
    assert exc.value.counts['liquid_boundary_evaluations'] == 1
    assert len(returned) == 1
    assert getattr(exc.value, 'last_completed_provider_result', None) is returned[0]


def test_nominal_bracket_endpoints_have_actual_saved_sign_observations(analytic):
    out = solve(analytic)
    lo, hi = out.nominal_temperature_bracket_k
    xl, xr = out.composition_bracket_mol
    assert lo <= out.point.temperature_k <= hi
    assert F(hi)-F(lo) <= F(analytic.policy.inverse_policy.temperature_tolerance_k)
    assert xl <= F(out.state.liquid_water_mol) <= xr
    assert xr-xl <= F(analytic.policy.composition_tolerance_mol)
    chemical = [t for t in out.trials if t.kind == 'chemical_and_energy']
    for temperature, sign in ((lo,-1),(hi,1)):
        candidates = [t for t in chemical if t.temperature_k == temperature and
                      t.chemical_residual_j_mol is not None and
                      abs(t.chemical_residual_j_mol) <= analytic.policy.chemical_tolerance_j_mol and
                      abs(t.pressure_residual_pa) <= F(analytic.policy.equilibrium_pressure_tolerance_pa)]
        assert any(t.energy_residual_j*sign > F(t.point.energy_error_j) for t in candidates)
    for x, sign in ((xl,-1),(xr,1)):
        assert any(t.temperature_k == out.point.temperature_k and t.liquid_mol == x and
                   t.chemical_residual_j_mol*sign >= 0 for t in chemical)
    assert out.certified_temperature_error_bound_k is None
    assert out.equilibrium_composition_energy_error_j is None
