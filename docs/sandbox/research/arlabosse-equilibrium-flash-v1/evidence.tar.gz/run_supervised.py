"""Use the existing process-group supervisor for one numbered flash attempt."""
import importlib.util,json,sys
from pathlib import Path
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK=Path(__file__).resolve().parent
PYTHON=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python')
INSTALLED=PYTHON.parent.parent/'lib/python3.12/site-packages/sludge_sandbox'
SUPERVISOR=ROOT/'docs/sandbox/research/research-process-supervisor/supervisor.py'
spec=importlib.util.spec_from_file_location('flash_supervisor',SUPERVISOR)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
number=int(sys.argv[1])
inputs={Path(__file__),WORK/'native_driver.py',WORK/'NATIVE_PLAN01.json',WORK/'NATIVE_PLAN01_CLARIFICATION.json',WORK/'implementation/low_moisture_equilibrium.py',WORK/'implementation/native_one_cell.py',SUPERVISOR,PYTHON.resolve(),PYTHON.parent.parent/'pyvenv.cfg'}
if number==2:inputs.add(WORK/'NATIVE_PLAN02.json')
wet=ROOT/'data/sandbox/research/arlabosse-wet-thermo-v1/model.json';inputs.add(wet)
definition=json.loads(wet.read_bytes());inputs.update(ROOT/a['path'] for a in definition['assets'])
for item in definition['upstream']:
 path=ROOT/item['path'];inputs.add(path);inputs.update(ROOT/a['path'] for a in json.loads(path.read_bytes())['assets'])
for name in ('IAPWS95-2018.pdf','iapws-1.5.5-py3-none-any.whl','iapws-1.5.5-iapws95.py','iapws-1.5.5-LICENSE','source_facts.json'):inputs.add(ROOT/'data/sandbox/water'/name)
for name in ('data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json','data/sandbox/research/water-element-convention-v1/facts.json','data/sandbox/research/water-element-convention-v1/source-excerpt.txt','data/sandbox/thermochemistry/nist_gases_v1.json','data/sandbox/research/arlabosse-low-moisture-v1/model.json'):inputs.add(ROOT/name)
inputs.update(ROOT/row['cache_path'] for row in json.loads((ROOT/'data/sandbox/research/mass-storage-bridge-v1/gas_molar_mass_facts.json').read_bytes()))
for directory in (INSTALLED,INSTALLED.parent/'iapws',INSTALLED.parent/'numpy',INSTALLED.parent/'scipy'):
 inputs.update(p for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
for distribution in ('numpy','scipy','iapws'):
 metadata=tuple(INSTALLED.parent.glob(distribution+'-*.dist-info'))
 if len(metadata)!=1:raise ValueError('ambiguous_numerical_metadata')
 inputs.update(p for p in metadata[0].rglob('*') if p.is_file())
result=m.run_attempt(WORK/f'supervised-native{number:02d}',
 ['/usr/bin/env','-u','PYTHONPATH',str(PYTHON),'-I',str(WORK/'native_driver.py'),str(number)],
 cwd='/private/tmp',input_paths=sorted(inputs),timeout_s=60.,cleanup_grace_s=5.)
print(json.dumps({k:v for k,v in result.items() if not k.startswith('inputs_')},indent=2))
sys.exit(0 if result['status']=='complete' and result['returncode']==0 else 1)
