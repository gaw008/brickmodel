"""Single source flash attempt; raw failure and completed providers are retained."""
from collections.abc import Mapping
from dataclasses import fields,is_dataclass
from fractions import Fraction as F
import hashlib,json,math,sys,time
from pathlib import Path

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'implementation'))
from native_one_cell import make_cell,native_policy
from low_moisture_equilibrium import flash,FlashFailure
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
START=time.monotonic()

def encode(value):
 if isinstance(value,F):return {'numerator':value.numerator,'denominator':value.denominator}
 if is_dataclass(value):return {f.name:encode(getattr(value,f.name)) for f in fields(value)}
 if isinstance(value,Mapping):return {str(k):encode(v) for k,v in value.items()}
 if isinstance(value,(tuple,list)):return [encode(v) for v in value]
 if value is None or isinstance(value,(str,int,bool)):return value
 if isinstance(value,float):
  if not math.isfinite(value):raise ValueError('nonfinite_saved_value')
  return value
 raise TypeError('unsupported_saved_type:'+type(value).__name__)

def save(path,value):
 path.write_text(json.dumps(encode(value),ensure_ascii=False,indent=2,allow_nan=False)+'\n')

number=int(sys.argv[1]);out=BASE/f'native{number:02d}'
out.mkdir(exist_ok=False)
inputs=[BASE/'native_driver.py',BASE/'NATIVE_PLAN01.json',BASE/'NATIVE_PLAN01_CLARIFICATION.json',BASE/'implementation/low_moisture_equilibrium.py',BASE/'implementation/native_one_cell.py']
if number==2:inputs.append(BASE/'NATIVE_PLAN02.json')
freeze={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
save(out/'INPUTS.json',{'inputs':freeze,'policy':native_policy().definition(),'python':sys.executable})
try:
 if number==1:storage,chemical,state,point=make_cell(ROOT)
 elif number==2:storage,chemical,state,point=make_cell(ROOT,carrier_mol=(.0000672,.0002528))
 else:raise ValueError('only_preregistered_case_numbers')
 save(out/'INITIAL.json',{'state':state,'point':point,'storage_provenance':storage.provenance()})
 total=F(state.liquid_water_mol)+F(state.gas_amounts_mol[2])
 result=flash(storage,chemical,total,state.gas_amounts_mol[:2],state.internal_energy_j,native_policy())
 save(out/'RESULT.json',result)
 checks={
  'original_target_energy_retained':result.state.internal_energy_j==state.internal_energy_j,
  'target_residual_correct':result.energy_residual_j==F(result.point.total_internal_energy_j)-F(state.internal_energy_j),
  'full_U_residual_plus_point_error':abs(result.energy_residual_j)+F(result.point.energy_error_j)<=F(1e-5),
  'nominal_T_bracket_width':F(result.nominal_temperature_bracket_k[1])-F(result.nominal_temperature_bracket_k[0])<=F(1e-6),
  'candidate_in_T_bracket':result.nominal_temperature_bracket_k[0]<=result.point.temperature_k<=result.nominal_temperature_bracket_k[1],
  'original_T_domain':325<=result.point.temperature_k<=338,
  'full_pressure_interval':90000<=F(result.point.pressure_pa)-F(result.point.pressure_error_pa)<=F(result.point.pressure_pa)+F(result.point.pressure_error_pa)<=110000,
  'low_water_domain':0<=F(result.state.liquid_water_mol)*F(storage.wet._mass)/F(storage.dry_mass_kg)<=F(.15),
  'exact_requested_total_water':result.exact_liquid_mol+result.exact_vapor_mol==total,
  'saved_water_projection':F(result.state.liquid_water_mol)+F(result.state.gas_amounts_mol[2])-total==result.water_projection_residual_mol,
  'inventory_budget':abs(result.liquid_projection_error_mol)+abs(result.vapor_projection_error_mol)<=F(1e-12),
  'carrier_unchanged':result.state.gas_amounts_mol[:2]==state.gas_amounts_mol[:2],
  'equilibrium_pressure_residual':abs(result.equilibrium_pressure_residual_pa)<=F(1e-5),
  'chemical_residual':result.chemical_potential_residual_j_mol is not None and abs(result.chemical_potential_residual_j_mol)<=1e-5,
  'no_certificate_upgrade':result.certified_temperature_error_bound_k is None and result.equilibrium_composition_energy_error_j is None,
  'no_material_upgrade':not result.material_qualified and not result.training_eligible,
  'driver_wall_limit':time.monotonic()-START<=60,
  'inputs_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in freeze.items())}
 save(out/'ACCEPTANCE.json',{'passed':all(checks.values()),'checks':checks,'runtime_seconds':time.monotonic()-START,'qualification':result.qualification})
 print(json.dumps({'case':number,'passed':all(checks.values()),'T':result.point.temperature_k,'P':result.point.pressure_pa,'Nc':result.state.liquid_water_mol,'Nv':result.state.gas_amounts_mol[2],'U_residual':float(result.energy_residual_j),'peq_minus_pv':float(result.equilibrium_pressure_residual_pa),'chemical_residual':result.chemical_potential_residual_j_mol,'counts':dict(result.counts),'seconds':time.monotonic()-START}))
 if not all(checks.values()):raise SystemExit(2)
except Exception as error:
 record={'error_type':type(error).__name__,'reason':str(error),'runtime_seconds':time.monotonic()-START,'inputs_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in freeze.items()),'material_qualified':False}
 if isinstance(error,FlashFailure):
  record.update(trials=error.trials,counts=error.counts,last_completed_provider_result=getattr(error,'last_completed_provider_result',None),last_completed_provider_context=getattr(error,'last_completed_provider_context',None))
 save(out/'FAILURE.json',record)
 print(json.dumps({k:v for k,v in record.items() if k not in ('trials','last_completed_provider_result','last_completed_provider_context')}))
 raise
