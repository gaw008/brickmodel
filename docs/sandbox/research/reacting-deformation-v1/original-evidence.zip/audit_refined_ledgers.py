from pathlib import Path
from fractions import Fraction as F
import json,math,hashlib
root=Path('/private/tmp/brick-reacting-deformation-v1'); d=json.loads((root/'trajectory-refined-results.json').read_text())
def rat(v):return F(v['numerator'],v['denominator'])
assert d['status']=='passed' and d['inputs_unchanged'] and d['inputs_before']==d['inputs_after']
drift=[]
for p,h in d['inputs_before'].items():
 if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h:drift.append(p)
R=8.31446261815324; C=10+.01*(30-R); reports=[]
for c in d['cases']:
 run=c['run']; states=run['states']; obs=c['observations']; times=run['times_s']; steps=run['steps']; assert run['status']=='completed';assert len(states)==len(obs)==len(times)==len(steps)+1; assert times[0]==0 and times[-1]==.125
 work=F(); absres=F(); ma={k:0. for k in ['carbon','mass_kg','energy_prefix','energy_local','amount_local','extent','temperature','pressure','analytic_storage_delta','power_formula']}
 for i,(s,o,t) in enumerate(zip(states,obs,times)):
  assert o['t']==t; assert s['energy_model_identity']==states[0]['energy_model_identity']; n=s['amounts_mol'][0]; nb,ng,nl,na=n;assert ng==.01 and nl==0
  carbon=abs(F(na)+F(nb)-2);ma['carbon']=max(ma['carbon'],float(carbon));ma['mass_kg']=max(ma['mass_kg'],float(carbon*F(.012)))
  refa=2*math.exp(-.1*t); ma['extent']=max(ma['extent'],abs(na-refa)); assert o['reference']['A_mol']==refa
  lam=1 if c['constant'] else 1-.1*t*t*(3-2*t); ldot=0 if c['constant'] else -.6*t*(1-t)
  e0=1.4e-4*(1000/2+2*400/3)*math.log(lam)**2;q=1+10*nb
  pore=1.4e-4*lam-na*2e-5-nb*1e-5
  assert abs(pore-o['pore_volume_m3'])<1e-18
  assert abs(na*2e-5+nb*1e-5-o['solid_volume_m3'])<1e-18
  tt=o['temperature_k']; pp=o['pressure_pa'];rt=o['reference']['temperature_k']; rp=.01*R*rt/(1.4e-4*lam-refa*2e-5-(2-refa)*1e-5)
  assert abs(rp-o['reference']['pressure_pa'])<1e-8
  ma['temperature']=max(ma['temperature'],abs(tt-rt));ma['pressure']=max(ma['pressure'],abs(pp-rp))
  power=o['power_components'];assert set(power)=={'body','dissipation','bulk_pressure','elastic_deformation','interface_deformation'}
  for k in ['body','dissipation','interface_deformation']:assert power[k]==[0.]
  expected_power={'bulk_pressure':-pp*1.4e-4*ldot,'elastic_deformation':q*1.4e-4*(1000+4*400/3)*math.log(lam)*ldot/lam}
  for k,v in expected_power.items():ma['power_formula']=max(ma['power_formula'],abs(power[k][0]-v))
  # Independent total-storage difference, nominal fixture terms, with inventory roundoff.
  delta=C*(tt-300)-4*nb+q*(e0+.3)-.3
  ma['analytic_storage_delta']=max(ma['analytic_storage_delta'],abs(delta-(s['internal_energy_j'][0]-states[0]['internal_energy_j'][0])))
  if i:
   st=steps[i-1];old=states[i-1];assert st['start_s']==times[i-1] and st['end_s']==t and t>times[i-1];assert t-times[i-1]<=c['step_cap_s']+1e-16
   assert all(v==0 for row in st['face_species_mol'] for v in row);assert st['face_energy_j']==[0.,0.]
   source=st['reaction_species_mol'][0];assert F(source[0])+F(source[3])==0 and source[1]==source[2]==0
   for j in range(4):ma['amount_local']=max(ma['amount_local'],float(abs(F(n[j])-F(old['amounts_mol'][0][j])-F(source[j]))))
   w=F(st['cell_work_j'][0]);work+=w;parts=st['cell_work_components_j'];assert set(parts)==set(power)
   residual=w-sum((F(v[0]) for v in parts.values()),F());assert residual==rat(st['component_sum_residual_j'][0]);absres+=abs(residual)
   assert set(st['component_quadrature_roundoff_j'])==set(power)
   for v in st['component_quadrature_roundoff_j'].values():rat(v[0])
   for k in ['body','dissipation','interface_deformation']:assert parts[k]==[0.]
   if c['constant']:assert w==0 and all(v==[0.] for v in parts.values())
   ma['energy_local']=max(ma['energy_local'],float(abs(F(s['internal_energy_j'][0])-F(old['internal_energy_j'][0])-w)))
  ma['energy_prefix']=max(ma['energy_prefix'],float(abs(F(s['internal_energy_j'][0])-F(states[0]['internal_energy_j'][0])-work)))
 assert absres==rat(run['cumulative_absolute_component_residual_j'][0])
 assert ma['carbon']<=1e-10 and ma['extent']<=1e-9 and ma['energy_prefix']<=1e-6 and ma['temperature']<=2e-5 and ma['pressure']<=1
 assert ma['analytic_storage_delta']<1e-6 and ma['power_formula']<1e-9
 reports.append({'constant':c['constant'],'cap_s':c['step_cap_s'],'accepted':len(steps),'rejected':run['rejected_trials'],'min_dt':min(b-a for a,b in zip(times,times[1:])),'max_dt':max(b-a for a,b in zip(times,times[1:])),'maxima':ma,'cumulative_component_absolute_residual_j':float(absres)})
a,b=d['cases'][-2:]; sa,sb=a['run']['states'][-1],b['run']['states'][-1];oa,ob=a['observations'][-1],b['observations'][-1]
diff={'amounts_mol':[abs(x-y) for x,y in zip(sa['amounts_mol'][0],sb['amounts_mol'][0])],'energy_j':abs(sa['internal_energy_j'][0]-sb['internal_energy_j'][0]),'temperature_k':abs(oa['temperature_k']-ob['temperature_k']),'pressure_pa':abs(oa['pressure_pa']-ob['pressure_pa'])}
endpoint_gates={'amounts':max(diff['amounts_mol'])<=1e-9,'energy':diff['energy_j']<=1e-6,'temperature':diff['temperature_k']<=2e-5,'pressure':diff['pressure_pa']<=1}
out={'result':'pass' if all(endpoint_gates.values()) else 'endpoint_refinement_failed','endpoint_gates':endpoint_gates,'cases':reports,'finest_endpoint_differences':diff,'current_hash_drift':drift,'trajectory_sha256':hashlib.sha256((root/'trajectory-refined-results.json').read_bytes()).hexdigest(),'limitation':'No EOS or ODE solve rerun; stored reference temperature values audited through formula derivation and recorded comparisons, not independently recomputed by a second integration. Stage RHS snapshots absent: individual component quadrature roundoff rational values are structurally read but cannot be independently reconstructed from accepted endpoints alone.'}
(root/'independent-refined-ledger-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
