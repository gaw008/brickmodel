from pathlib import Path
from dataclasses import fields,is_dataclass
from collections.abc import Mapping
from fractions import Fraction as F
import json,hashlib,math,time
import numpy as np
from scipy.integrate import solve_ivp
from test_reacting_deforming_solid_heat import reacting_host,initial,scalar_temperature
from test_rigid_storage import DATA,R
from sludge_sandbox.water_properties import load_water_properties
from sludge_sandbox.integration import IntegrationPolicy,integrate

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github');HERE=Path(__file__).resolve().parent
paths=sorted((ROOT/'src/sludge_sandbox').glob('*.py'))+[ROOT/'tests/sandbox/test_reacting_deforming_solid_heat.py',HERE/'PLAN.md',Path(__file__)]
def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
def serial(x):
    if isinstance(x,F):return {'numerator':x.numerator,'denominator':x.denominator}
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    if isinstance(x,Mapping):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [serial(v) for v in x]
    if is_dataclass(x):return {f.name:serial(getattr(x,f.name)) for f in fields(x)}
    return x
before=hashes();water=load_water_properties(DATA)
def forbidden(*a,**k):raise AssertionError('dry native water EOS forbidden')
type(water).state_tp=forbidden
report={'classification':'manufactured_test_fixture','inputs_before':before,'cases':[],'status':'running'}
try:
 for constant,step in [(True,1/128),(False,1/64),(False,1/128),(False,1/256)]:
    start_clock=time.monotonic();op=reacting_host(water,constant=constant);s0=initial(op);end=1/8
    policy=IntegrationPolicy(initial_step_s=step,maximum_step_s=step,minimum_step_s=1e-10,relative_tolerance=1e-7,amount_absolute_tolerance_mol=1e-10,energy_absolute_tolerance_j=1e-6,amount_scale_mol=1.,energy_scale_j=1.,maximum_steps=100,maximum_rejections=20,maximum_wall_seconds=40)
    run=integrate(s0,op,start_s=0.,end_s=end,policy=policy)
    case={'constant':constant,'step_cap_s':step,'policy':serial(policy),'run':serial(run),'observations':[]};report['cases'].append(case)
    assert run.status=='completed',run.reason
    oracle=solve_ivp(lambda t,y:scalar_temperature(t,y,constant=constant),(0.,end),[300.],method='DOP853',rtol=1e-11,atol=1e-11,dense_output=True);assert oracle.success
    errors={k:0. for k in ('carbon_mol','extent_mol','temperature_k','pressure_pa','prefix_energy_j')};work=F()
    for i,(t,state) in enumerate(zip(run.times_s,run.states)):
        out=op.evaluate(state,t);th=out.storage_states[0];sk=out.total_inverses[0].state.skeleton_state;row=state.amounts_mol[0]
        ref_n=2*math.exp(-.1*t);ref_t=float(oracle.sol(t)[0]);lam=1 if constant else 1-.1*t*t*(3-2*t);ref_v=1.4e-4*lam-ref_n*2e-5-(2-ref_n)*1e-5;ref_p=.01*R*ref_t/ref_v
        if i:work+=F(float(run.steps[i-1].cell_work_j[0]))
        er={'carbon_mol':float(abs(F(float(row[0]))+F(float(row[3]))-2)), 'extent_mol':abs(float(row[3])-ref_n),'temperature_k':abs(th.mechanical.temperature_k-ref_t),'pressure_pa':abs(th.mechanical.pressure_pa-ref_p),'prefix_energy_j':float(abs(F(float(state.internal_energy_j[0]))-F(float(s0.internal_energy_j[0]))-work))}
        for k,v in er.items():errors[k]=max(errors[k],v)
        case['observations'].append({'t':t,'temperature_k':th.mechanical.temperature_k,'pressure_pa':th.mechanical.pressure_pa,'solid_volume_m3':th.solid_volume_m3,'pore_volume_m3':th.available_pore_volume_m3,'skeleton':serial(sk),'power_components':serial(out.rates.cell_power_components_w),'reference':{'A_mol':ref_n,'temperature_k':ref_t,'pressure_pa':ref_p},'errors':er})
    case['max_errors']=errors;case['elapsed_s']=time.monotonic()-start_clock
    assert errors['carbon_mol']<=1e-10 and errors['extent_mol']<=1e-9 and errors['prefix_energy_j']<=1e-6 and errors['temperature_k']<=2e-5 and errors['pressure_pa']<=1
    print(json.dumps({'constant':constant,'step':step,'steps':len(run.steps),'errors':errors,'elapsed_s':case['elapsed_s']}),flush=True)
 report['status']='passed'
except Exception as exc:
 report['status']='failed';report['exception']={'type':type(exc).__name__,'message':str(exc)};raise
finally:
 report['inputs_after']=hashes();report['inputs_unchanged']=report['inputs_after']==before
 (HERE/'trajectory-results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
