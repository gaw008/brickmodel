# Preregistered actual paired pressure and optional event run

Preparation only. Root owns the only native execution and external watchdog. No native process was launched during script preparation.

Source input: /private/tmp/brick-free-native-events-v1/case.json and attempt01/water. The script saves the original input and SHA, then changes only case_id suffix, depletion schema to sandbox_depletion_policy_v2, and explicit pressure_comparison declaration. Every physical input, original integration policy, start/end, six gates and roundoff policy is retained. Pressure threshold remains 1e-4 Pa. Integration wall budget remains the original 800 seconds; outer event watchdog is 840 seconds including setup/probe. Short-probe watchdog is 40 seconds. Root must hold/reap the actual child; this script is not a watchdog.

Every invocation requires a fresh --output directory. Failure JSON and completed partial artifacts are retained; root watchdog must save terminal status/stdout/stderr even on hard kill. Do not rerun over an earlier attempt. Script catches failures, writes traceback and final runtime identity, and exits nonzero. A hard kill may leave started status plus previously atomically saved artifacts, not completed success.

Short probe: build actual current case with installed code, create neighbor by moving 2^-40 mol liquid to vapor in every cell, retain total-energy and full mechanical vector exactly. Save actual represented states (floating transfer is not presumed exact beyond these saved bytes). Evaluate both actual free base hosts, use their actual total inverses in complete all-cell pressure helper; save actual inverse observations, pair exact records, native endpoint samples and attempted/completed counts before pressure assertions. Production record audit is an arithmetic/source-binding check, not an independent physics oracle.

Optional --event: only after short pair passed, integrate original initial state over the complete original start/end with unchanged policies except explicit new pressure contract. Serialize full encode_depletion_result before audit/status assertion, including failure histories. Production audit and event status remain separate report fields. No service or replay relabeling. Root can apply a saved-data independent ledger audit separately; this script does not claim one.

Runtime policy: record actual runtime before and after each invocation, water file hashes, and old runtime for visible comparison. Implementation changes from the old failed attempt are expected; no equality assertion against old code. Equality within the new invocation and water immutability are required. Source-qualified water remains the old exact files. The new shared error family is explicitly manufactured; it neither certifies generic point-error correlation nor inverse T tubes/material qualification.

Commands (root must wrap with external owned watchdog and installed interpreter/environment):

    <installed-python> /private/tmp/brick-paired-event-native-v1/probe.py --output /private/tmp/brick-paired-event-native-v1/point-attempt01
    <installed-python> /private/tmp/brick-paired-event-native-v1/probe.py --event --output /private/tmp/brick-paired-event-native-v1/event-attempt01

40-second cap for the first command, 840 seconds for the second. No source-tree PYTHONPATH, test fixture imports, package install, solver change, tolerance widening or source error reduction. Event internal 800 seconds excludes the preceding setup/pair work, which is still within the 840-second outer process scope.

Static validation: ast.parse only; no imports or execution. Review required before root native launch.
