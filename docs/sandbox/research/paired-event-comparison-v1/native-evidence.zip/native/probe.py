"""Explicit native experiment entry point. Run only under root-owned watchdog."""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import time
import traceback
from typing import Any

OLD = Path('/private/tmp/brick-free-native-events-v1')
HERE = Path(__file__).resolve().parent


def save(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    temporary.replace(path)


def hashes(directory: Path) -> dict[str, str]:
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.iterdir()) if p.is_file()}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--event', action='store_true')
    parser.add_argument('--output', type=Path, required=True, help='Fresh attempt directory')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    report: dict[str, Any] = {'status': 'started', 'event_requested': args.event,
        'qualification': 'Manufactured shared-constant reported-T comparison; production audit is binding/arithmetic validation, not independent physical proof.',
        'material_qualified': False, 'temperature_uncertainty_included': False}
    save(args.output/'result.json', report)
    exit_code = 1
    try:
        from sludge_sandbox.verification_case import read_case, build_case, encode
        from sludge_sandbox.run_service import runtime_identity
        from sludge_sandbox.pressure_comparison import SCHEMA, compare_pressure_pair, audit_pressure_comparison, pressure_comparison_binding
        from sludge_sandbox.integration import ConservedState
        original_bytes = (OLD/'case.json').read_bytes()
        original = json.loads(original_bytes)
        case = json.loads(original_bytes)
        case['case_id'] += '-paired-pressure-v1'
        case['numerics']['depletion']['schema'] = 'sandbox_depletion_policy_v2'
        case['numerics']['depletion']['pressure_comparison'] = {
            'schema': SCHEMA, 'constant_box_declaration': 'all_actual_declared_constant_volume_errors_are_shared'}
        save(args.output/'case.json', case)
        report['original_case_sha256'] = hashlib.sha256(original_bytes).hexdigest()
        report['original_case'] = original
        report['runtime_before'] = runtime_identity()
        report['old_runtime'] = json.loads((OLD/'runtime-before.json').read_text())
        report['runtime_changed_since_old_attempt'] = report['runtime_before'] != report['old_runtime']
        report['water_before'] = hashes(OLD/'attempt01/water')
        save(args.output/'result.json', report)
        built = build_case(read_case(args.output/'case.json'), OLD/'attempt01/water')
        operator = built.operator
        state_a = built.initial
        row = state_a.amounts_mol.copy()
        liquid = operator.base_model.inventory_layout.liquid_index
        vapor = operator.species_order.index('H2O')
        for cell in range(len(row)):
            row[cell, liquid] -= 2.0**-40
            row[cell, vapor] += 2.0**-40
            assert F(float(row[cell,liquid]))+F(float(row[cell,vapor]))==F(float(state_a.amounts_mol[cell,liquid]))+F(float(state_a.amounts_mol[cell,vapor]))
        state_b = ConservedState(row, state_a.internal_energy_j,
            energy_model_identity=state_a.energy_model_identity,
            mechanical_stretches=state_a.mechanical_stretches)
        report['states'] = [encode(state_a), encode(state_b)]
        report['integration_policy'] = encode(built.policy)
        report['depletion_policy'] = built.depletion_policy.pressure_comparison.to_record()
        report['unchanged_depletion_settings'] = case['numerics']['depletion']
        save(args.output/'result.json', report)
        # The point inverse supplies observations without a redundant full phase
        # callback; no stored host/provider graph is serialized.
        evaluations = [operator.base_model.evaluate(s, built.start_s) for s in (state_a, state_b)]
        report['point_inverses'] = [[{'temperature_k': inv.state.thermal_state.mechanical.temperature_k,
            'pressure_pa': inv.state.thermal_state.mechanical.pressure_pa,
            'temperature_error_k': inv.temperature_error_bound_k,
            'pressure_error_pa': inv.state.thermal_state.pressure_error_bound_pa,
            'target': encode(inv.target), 'geometry': encode(inv.state.deformation)}
            for inv in ev.total_inverses] for ev in evaluations]
        save(args.output/'result.json', report)
        counters = {'attempted': 0, 'completed': 0}
        def before() -> None:
            counters['attempted'] += 1
            save(args.output/'endpoint-progress.json', counters)
        def after(actual: Any) -> None:
            counters['completed'] += 1
            save(args.output/'endpoint-progress.json', counters)
        pair = compare_pressure_pair(operator, state_a, evaluations[0].total_inverses,
            operator, state_b, evaluations[1].total_inverses,
            policy=built.depletion_policy.pressure_comparison, before_endpoint=before, after_endpoint=after)
        save(args.output/'pair.json', pair.to_record())
        report['pair_bound_pa'] = pair.bound_pa
        report['pressure_gate_pa'] = built.depletion_policy.pressure_absolute_pa
        report['endpoint_counts'] = counters
        save(args.output/'result.json', report)
        binding = pressure_comparison_binding(operator)
        audit_pressure_comparison(pair.to_record(), policy=built.depletion_policy.pressure_comparison,
            state_a=state_a, state_b=state_b, bindings_a=binding, bindings_b=binding)
        report['production_pair_audit'] = 'passed_not_independent_physics_proof'
        save(args.output/'result.json', report)
        assert counters=={'attempted':8,'completed':8}
        assert report['pressure_gate_pa'] == 1e-4
        assert pair.bound_pa <= report['pressure_gate_pa']
        if args.event:
            from sludge_sandbox.depletion_integration import integrate_depletion
            from sludge_sandbox.event_record import encode_depletion_result, audit_depletion_record
            run = integrate_depletion(built.initial, operator, start_s=built.start_s, end_s=built.end_s,
                integration_policy=built.policy, event_policy=built.depletion_policy)
            record = encode_depletion_result(run, original_interfaces=operator.interfaces)
            save(args.output/'depletion_result.json', record)
            report.update(event_status=run.status, event_reason=run.reason)
            save(args.output/'result.json', report)
            audit_depletion_record(record, built.initial, built.policy, built.depletion_policy, operator.interfaces,
                operator=run.operator, start_s=built.start_s, end_s=built.end_s)
            report['production_event_audit'] = 'passed_not_independent_physics_proof'
            save(args.output/'result.json', report)
            assert run.status == 'completed', run.reason
        report['status'] = 'completed'
        exit_code = 0
    except BaseException as exc:
        report.update(status='failed', exception_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        try:
            from sludge_sandbox.run_service import runtime_identity
            report['runtime_after'] = runtime_identity()
            report['water_after'] = hashes(OLD/'attempt01/water')
            if report.get('runtime_before') != report['runtime_after'] or report.get('water_before') != report['water_after']:
                report['integrity_failure'] = 'runtime_or_water_changed_within_attempt'
                report['status'] = 'failed'
                exit_code = 1
        except BaseException:
            report['final_identity_error'] = traceback.format_exc()
            report['status'] = 'failed'
            exit_code = 1
        report['elapsed_seconds'] = time.monotonic() - started
        save(args.output/'result.json', report)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
