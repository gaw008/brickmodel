# Independent prefix-auditor review

APPROVE final audit_prefix.py SHA256 287bc351617df55f534978648010c781128603a7dfe2d4480cef08af91135245. Reviewed original full script and final gross-evaporation patch against retained audit_prefix-before-gross.py. Read-only; did not read live run outputs, execute the audit, run EOS or modify source/tests.

The script imports only standard-library modules and consumes v2 saved JSON. Strict numeric helpers exclude bool/nonfinite values; duplicate keys and nonfinite JSON constants are refused. It checks original inventory/mechanical initialization, accepted-panel resource lower bound, phase totals, endpoint attempt/completion ordering, history clocks and the actual event-to-terminal-ledger association. It does not treat production status as proof of conservation.

For every accepted panel, independent Fraction arithmetic reconstructs face inflow minus outflow plus reaction for each species, face energy plus cell work, local and original-initial cumulative residuals, mechanical represented/exact/quadrature-roundoff cumulative residuals, and free-work component sums. Event writebacks are reconstructed from the full raw represented N/E/stretch update; null correction requires exact raw zero. Non-null liquid-to-vapor writeback signs, represented vapor remainder, local ULP allowance, adjacent affine clock residual, half-neighbor rounding and local/cumulative correction/storage/element/mass budgets are checked. Corrected increments are included in all subsequent cumulative inventories.

The final patch closes the identified independent correction-fraction gap. Every event, including one without a correction, now binds clock start/end/time gate and liquid rate triples to the actual recorded initial/midpoint observations. It reconstructs the affine evaporation rate, splits at any interior zero, integrates only positive portions exactly and rounds the result downward before matching positive_evaporated_mol. The correction-fraction denominator therefore no longer relies merely on two matching saved diagnostic fields. This remains verification of recorded affine samples, not an independent EOS-rate proof.

At every accepted prefix, the global balance is total-energy change + external pressure times actual volume change - cumulative external boundary energy - body work. Internal faces cancel by orientation. The volume uses current normals and common tangent; mechanical constraint work is independently accumulated by cell and as a monotone cumulative absolute cross-cell sum. Maximum absolute global pressure-work residual and worst prefix are retained. Both global targets remain the original fixed 2e-8 J, including nonlinear quadrature truncation; no target is chosen from results. Stored cumulative N/E/component/correction totals must also match.

Acceptance separately requires completed status at the exact original end, original wall budget, at least one event and continuation after an event. Failed native runs can retain a passed prefix_arithmetic result while acceptance remains failed. If arithmetic fails earlier, the script retains a failure and collected prefix evidence. Output is outside the sealed run directory and includes input/script hashes.

Scope limitations are explicit: it does not independently validate source manifests or paired native endpoint observations, and it verifies recorded event comparison differences/gates rather than re-proving pressure-certificate physical premises. It does not re-solve temperatures, establish material validity or complete convergence. Root must run only after the sole native process is confirmed terminal; this review is approval of the auditor, not of the experiment.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 unresolved | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE final data-only prefix auditor under the stated scope.
