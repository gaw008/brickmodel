# Final short-probe and service-admission review

APPROVE short probe after the missing Fraction import was corrected. Reviewed probe.py SHA256 4d48720620adf0ea917ce0f44517e0ab88ce03f3eda090e01370d30a1994e435, PLAN.md, run_service.py one-line v1/v2 admission diff and the two corresponding test cases. Read-only, no EOS or probe execution.

Service _event_cancelled now accepts either version of the cancelled event record shape. It still requires event integration kind, cancelled status/reason and a nonempty accepted prefix. _run_event subsequently checks original policies, actual initial states, reconstructs the operator and runs full audit_depletion_record/restore_result before continuation. Thus schema admission is not audit bypass. New tests accurately label their scope as shape admission only.

The probe copies original case data and changes only case_id, depletion schema and the explicit manufactured shared-constant declaration. It preserves physical values, integration settings, start/end, event gates and correction policy. Derived boxes come from actual construction under the new case/source identity. The nearby state shifts represented liquid to vapor and now asserts exact Fraction water conservation per cell, retaining energy and all mechanical stretches. Actual base evaluations supply inverses to the whole two-cell helper. It saves the full pair record and counts before assertions, requires eight attempts and completions and the unchanged 1e-4 Pa bound.

Default invocation without --event does not call integrate_depletion. The separate optional event branch is not launched or certified by this review. The script relies on root's external watchdog; PLAN retains 40 seconds for the short probe and 800-second internal/840-second external budgets for a future event invocation. All outputs use a fresh directory and atomic saves. Runtime/water identity are compared before/after; expected differences from the old code are disclosed rather than silently treated as identical.

Found and fixed during review: exact-water assertion initially used F without an import, which would have failed after construction. Final inspected version includes from fractions import Fraction as F. No remaining blocking issue found for the short probe. This is conditional reported-temperature/manufactured-box validation, not independent physics proof, event completion, or material admission.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 unresolved | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE final short probe and schema-admission delta.
