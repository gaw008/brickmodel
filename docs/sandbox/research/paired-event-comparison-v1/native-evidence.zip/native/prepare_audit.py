from pathlib import Path
old=Path('/private/tmp/brick-free-native-events-v1/audit.py').read_text()
helpers=old[old.index('def check('):old.index('def audit(')]
body=old[old.index('    states, times, steps ='):old.index("    check(result['status']==record['status']=='completed'")]
body=body.replace("    check(result['initial_snapshot']['state']==states[0], 'initial snapshot state')\n",'')
body=body.replace("    target=cells*et", "    target=number(2e-8)")
body=body.replace("'registered_target_j':str(cells*et)","'registered_target_j':str(number(2e-8))")
body=body.replace("Pre-result verification target equals sum of original per-cell absolute energy budgets;", "Fixed pre-result target 2e-8 J, unchanged from prior attempt;")
# Save every fully checked prefix and an independent combined-water ledger error.
needle="        report['global_prefix_diagnostics']="
pos=body.index(needle)
addition="""        water_errors=[abs(sum((number(after['amounts_mol'][i][j])-number(states[0]['amounts_mol'][i][j])-cn[i][j] for j in (li,vi)),F())) for i in range(cells)]
        check(max(water_errors)<=2*nt, 'combined water prefix ledger')
        report['prefixes'].append({'index':k+1,'time_s':times[k+1],
            'global_energy_residual_j':str(global_balance),
            'cumulative_absolute_constraint_sum_j':str(constraint_absolute_sum),
            'water_ledger_errors_mol':[str(v) for v in water_errors],
            'maxima':{name:str(value) for name,value in maxima.items()}})
"""
body=body[:pos]+addition+body[pos:]
header='''"""Data-only accepted-prefix audit; standard library, no production imports/EOS.

Derived from the reviewed brick-free-native-events-v1/audit.py Fraction ledger
method. Does not re-certify paired endpoint observations or source manifests.
The fixed 2e-8 J global targets are retained, not inferred from observed results.
Run only after the parent confirms the native process is terminal.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math
import sys

'''
start='''def audit(directory, report):
    case=read(directory/'case.json')
    record=read(directory/'depletion_result.json')
    report.update(status=record['status'],final_time_s=record['times_s'][-1],
                  requested_end_s=case['numerics']['end_s'],events=len(record['events']),prefixes=[])
    check(record['schema']=='sandbox_depletion_result_v2','explicit paired event schema')
    policy=case['numerics']['integration'];ep=case['numerics']['depletion'];rp=ep['roundoff_policy']
    check(ep.get('pressure_comparison') is not None,'explicit paired policy')
    for field,total in (('panels','attempted_steps'),('rejections','rejected_trials'),('evaluations','evaluations')):
        check(type(record[total]) is int and record[total]>=0,'nonnegative resource total')
        check(all(type(v[field]) is int and v[field]>=0 for v in record['phase_costs'].values()),'nonnegative phase resource')
        check(sum(v[field] for v in record['phase_costs'].values())==record[total],'phase cost sum')
    check(record['attempted_steps']<=policy['maximum_steps'] and record['rejected_trials']<=policy['maximum_rejections'],'original resource budgets')
    cost=record['phase_costs']['comparison']
    check(type(cost['endpoint_attempts']) is int and type(cost['endpoint_completed']) is int and 0<=cost['endpoint_completed']<=cost['endpoint_attempts'],'endpoint cost order')
    report['endpoint_costs']={key:cost[key] for key in ('endpoint_attempts','endpoint_completed')}
'''
finish='''    check(record['status']=='completed' and times[-1]==case['numerics']['end_s'],'completed fixed horizon')
    check(number(record['elapsed_seconds'])<=number(policy['maximum_wall_seconds']),'completed wall budget')
    check(len(record['events'])>=1 and any(ev['time_s']<times[-1] for ev in record['events']),'event and continuation after event')
    report['acceptance']='passed'


def main():
    if len(sys.argv)!=2: raise SystemExit('usage: audit_prefix.py TERMINAL_RUN_DIRECTORY')
    directory=Path(sys.argv[1]).resolve()
    output=Path(__file__).resolve().parent/(directory.name+'-prefix-audit.json')
    check(output.parent!=directory,'audit output must not alter sealed run directory')
    report={'acceptance':'failed','qualification':'Saved accepted-prefix conservation arithmetic only; no endpoint re-certification, physical convergence or material validation.',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'input_sha256':{name:hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in ('case.json','depletion_result.json')}}
    try:
        audit(directory,report)
    except Exception as exc:
        report['failure']={'type':type(exc).__name__,'message':str(exc)}
    output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\\n')
    check(report['acceptance']=='passed',str(report.get('failure')))


if __name__=='__main__':main()
'''
Path('/private/tmp/brick-paired-event-native-v1/audit_prefix.py').write_text(header+helpers+start+body+finish)
