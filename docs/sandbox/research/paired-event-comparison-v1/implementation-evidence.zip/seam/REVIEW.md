# Independent depletion comparison seam review

APPROVE the scoped integration plumbing, conditional on separate helper and record-module review. Read-only review of current depletion_integration.py diff and test_paired_depletion_seam.py, including surrounding observation, continuation, comparison and commit/error paths. No EOS, source edits or reruns.

Inspected source SHA256 790de3f8d1a2ee7445c828c303687f181fae6ecb0a156eed066835b83e81018d and test SHA256 e94a0e74fb054f66d301198918a923e18aa3acede7d2c7196317536cdaf0fe4a.

The policy is optional and exact-type checked only when supplied. The default None path does not import/use the comparison helper, capture inverses, add endpoint counters or replace the original pressure metric. Serialized event policy gains the optional None field; continuation comparison normalizes the absent legacy field to None, without admitting a changed non-None policy. Complete saved accounting is still restored from the audited continuation; correctness of auditing the new counter shape/policy remains the record worker's separate responsibility.

Opt-in host admission and cell count occur before stepping. Observation captures actual operator, immutable ConservedState and actual total inverses from that same successful evaluation, after existing complete numerical checks and guard. Event snapshots refer to the terminal zero-liquid state with its actual mode-updated operator; common snapshots are freshly evaluated at the common horizon. Event and common pairs are independently passed to the helper and both results retained alongside the old independent metric. The selected pressure maximum alone replaces pressure comparison; the other gates and required repeated/independent approach comparisons remain.

Before each actual endpoint attempt, guard runs and the attempt count increments. Completion count increments after successful return, then guard runs again. Failed endpoint work is therefore retained as attempted cost; cancellation after completion retains the completed count. Neither error commits the speculative event/path, and outer error handling returns the prior accepted state/operator prefix with global costs. The surrounding nested/affine precommit guard and source binding remain. Pure comparison preparation/serialization errors propagate through existing failed-result handling; helper exception classes must continue to derive from the caught structured families.

Tests are explicitly control-flow stand-ins: native admission and paired calculation are replaced, while actual integrator paths exercise state/inverse snapshot association, distinct event times/common times, eight calls per event/common comparison, counter shapes, failed second endpoint, cancelled second completion and default old pressure behavior. These do not certify the real helper, water enclosure, or serialized paired evidence. XML read directly: attempt01 retains 1 failure among 4 tests; attempt02 contains 33 tests, zero failures/errors/skips, 5.540 seconds.

No blocking issue found in this scoped plumbing. Full helper binding/fallback, paired record arithmetic and resume validation require the separately scheduled reviews before adopting the combined path. Native event acceptance remains unproved.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE scoped seam; not an approval of unfinished helper/record integration or native event success.
