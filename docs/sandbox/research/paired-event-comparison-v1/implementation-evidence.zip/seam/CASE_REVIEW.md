# Independent v2 case declaration review

APPROVE the scoped case-policy and legacy-normalization changes. Read-only, no EOS or test reruns.

Inspected verification_case.py SHA256 95e243c67e3e3026edc6a1f5bc5aaf964c15c1444d89c372cf129d07b4000bb9; depletion_integration.py SHA256 aae6791ea09ac6aff37b99c5e89b5079e57710fb9a4bafca6dbba5a6e6779db3 (optional-field serialization/continuation normalization only in this additional review); test_paired_event_case.py SHA256 eaea53e67ea93fd9a35be8815cbafa3d094845ecd1ead42842dc2f0723103095.

The v2 case embeds an explicit fixed schema plus manufactured shared-constant-volume declaration, not a point digest. Its case SHA is therefore finalized before constructing the source-bound operator. Complete typed boxes are then derived from that actual operator and retained in the resulting policy; they are not written back into the case bytes. This removes the case-SHA/point-digest self-reference without removing actual parameter/source binding.

Validation accepts the exact declaration only and uses validation_only=True to construct/discard a numerical policy with no operator-dependent box. Ordinary callers cannot build a v2 execution policy without an actual operator. build_case first obtains the actual operator, derives boxes, checks actual water mass and compares the derived boxes against the independent actual binding before _forward. Thus the validation-only placeholder is not used for simulation. Wrong/extra/implicit declarations are rejected; v1 still excludes the new declaration field entirely.

The metadata omission is targeted to fields explicitly marked omit_when_none. Only the new DepletionPolicy.pressure_comparison field currently opts in, preserving old default encoded policy shape. Continuation validation normalizes both old missing and current explicit None to the same comparison representation; non-None typed policy content remains compared exactly. It does not accept a changed conditional policy under a legacy record.

Tests cover unchanged v1 admission, v2 no-operator refusal, validation-only behavior, malformed/implicit schema/declaration variants and mismatched derived boxes failing before a forbidden forward call. These are admission tests, not positive native construction evidence. Existing attempt04 XML records 86 tests with zero failures/errors/skips in 5.294 seconds; attempt03 also remains preserved.

No blocking issue found. The explicit declaration introduces the separately qualified new manufactured parameter-box interpretation; it must remain visible in provenance and cannot retrospectively change the old failed case's uncertainty contract. Actual full event validation remains outside this case review.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE scoped v2 case declaration and legacy policy encoding.
