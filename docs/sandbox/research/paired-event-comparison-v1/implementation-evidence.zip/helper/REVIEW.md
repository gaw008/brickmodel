# Independent pressure-comparison helper review

APPROVE final helper scope after two review fixes. Source SHA256 052815ce1e06fad5f353a9de793e539d21db70d8f2c9529b5dd7a058f65b6fcf; tests SHA256 1299b2bf18428e3b9f6513308b5cde0313b80a8e694346a02ba1dc7ef26be714. Read-only; no EOS, native probe or test rerun.

The helper requires an explicit typed policy and actual direct free-water hosts, binds both base closures and ordered actual cell boxes, and checks both operators again after endpoint work. Different interface modes can be recorded separately while sharing the same pressure closure; both actual state inventories are validated by host preparation. Source descriptors include operator content and actual water implementation. Default integration remains outside this opt-in path.

The auditor binds state inventories and complete geometry, exact source parameter boxes/domains, nominal reported temperatures, outward pressure-root intervals, current represented volumes, independent additional errors and all deterministic rounding allowances. It recomputes available-volume rounding and outward bulk-error enlargement rather than trusting the saved independent error magnitude. Endpoint samples must have the real WaterState dataclass field shape, match bound reference/implementation and endpoint T/P, and supply strictly finite positive numeric T/P/density excluding booleans/strings. Liquid volume and unchanged declared volume error plus division rounding are reconstructed before replaying the pure certificate. Exact certificate equality and total/per-cell completed costs are checked.

Found and resolved HIGH: original auditor read sample['molar_mass_kg_mol'], a computed property omitted by encode(WaterState). This would reject every actual wet helper record. Final code reads the already source-bound reference's molar mass. Tests now generate the actual WaterState encoding instead of a handwritten incompatible sample. Also resolved malformed-number acceptance: Fraction previously accepted numeric strings and booleans in sample density; final checks reject those, NaN and zero. Author tests06 XML contains 17 passing tests, no failures/errors/skips.

Reviewed the root's additional early integration check: policy.cell_boxes must equal the actual no-EOS binding boxes before stepping; the new refusal test changes the declared reference box and expects the specific original_box_binding error. This preserves None behavior and rejects a wrong conditional policy before trajectory work.

Trust boundary: this is a saved-data arithmetic/source-binding auditor, not independent EOS recertification. Reported T/P and point-error values are saved observations, not recomputed from total energy here. Event-record integration must bind them to retained event/common observation diagnostics and bind actual states to committed history; these cross-module checks are separate from this helper approval. The current record worker has been notified. No claim that source IDs alone prove sampled physical values is made by this module. The new manufactured constant-parameter semantics and reported-temperature qualification remain explicit; the old failed event is not repaired retrospectively.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 unresolved | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE final helper and narrow early-binding addition. Actual helper probe and complete event-record review remain necessary before end-to-end claims.
