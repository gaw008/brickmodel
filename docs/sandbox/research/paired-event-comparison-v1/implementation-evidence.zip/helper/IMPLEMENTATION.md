# Pressure comparison helper

Owned files: src/sludge_sandbox/pressure_comparison.py and tests/sandbox/test_pressure_comparison.py only. No integration/auditor/host modifications.

Public API:
- PressureComparisonPolicy(cell_boxes: tuple[SharedConstantParameterBox,...], schema=SCHEMA); to_record(); restore_pressure_comparison_policy(data).
- pressure_comparison_binding(actual WaterPhaseTransfer) returns no-EOS external binding: separate whole operator and base closure digests, interfaces, inventory layout, complete boxes, reference geometry/additional errors, source/domain/R/liquid error and water reference/implementation.
- compare_pressure_pair(op_a,state_a,inverses_a,op_b,state_b,inverses_b,*,policy,before_endpoint=None,after_endpoint=None) -> frozen PressureComparisonResult(bound_pa, record_json), to_record(). after_endpoint receives actual WaterState.
- audit_pressure_comparison(record,*,policy,state_a,state_b,bindings_a,bindings_b) -> bound float. External state and bindings must be caller-verified; self-contained JSON arithmetic is not proof of native EOS truth.

Two actual operators may have different interfaces, but their actual base closure digests must be identical. Every box must match actual cell position. No unsupported host fallback. Original scalar independent bound remains verbatim cross-cell max nominal + max error A + max error B. Record full states, both operator bindings, reported T/P and original errors, exact kernel records and actual endpoint samples, cost, and selected max bound. No timestamp is invented: event/common outer caller owns times.

Audit reconstructs geometry from full normal vector and one tangent, inventory by explicit layout, source box, nominal bulk/preparation error/available rounding, root endpoints from retained reported pressure±error, water endpoint volume and absolute envelope errors. It recomputes the exact kernel certificate and complete-cell maximum. Caller/event auditor must bind recorded T/P/errors to outer original observations and times, and compare speculative-state difference arrays to the original refinement evidence. Does not certify inverse T tubes or actual material.

Verification: tests01 through tests04 retained. Each 12 passed; latest .13s. These tests are exact manufactured wet arithmetic records, semantic tampering, policy codec and explicit host refusal. They do not instantiate a real wet provider or independently exercise positive actual-host native endpoint calls. Root owns next integration/review/native work. No EOS or installation performed.

Review revisions: preserved before-sample-review.py. WaterState's computed mass property is not serialized; auditor now reads the already bound reference mass. Tests now encode actual WaterState/WaterReference dataclasses rather than a handwritten sample shape. Enforce exact WaterState field membership and positive finite numeric T/P/density, rejecting bool/string. Latest tests06: 17 passed .17s; still no native EOS. Final current module SHA 052815ce1e06fad5f353a9de793e539d21db70d8f2c9529b5dd7a058f65b6fcf.
