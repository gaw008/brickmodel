# Independent paired event-record review

APPROVE scoped record integration. Reviewed event_record.py SHA256 cb0c7ab3d9e0b9ad41ed03a4d0651af769c695eb1acf98cd7d7fc56f04617161 and test_paired_event_record.py SHA256 b785885a9dac8b83dd44ca5ff65ae9ed94a002f1275bc18cc2da0ea3d083aeac, surrounding original refinement/commit auditing, and the actual helper output shape. No EOS, tests rerun or source edits.

V2 is selected by opt-in endpoint cost fields even before a first comparison. Audit requires schema/policy agreement and original actual cell-box binding, so an empty refinement history cannot bypass the new policy identity. Default records retain v1. Restored non-None policies pass through strict typed reconstruction and then the complete audit; missing/explicit None legacy policy forms remain supported.

Per-phase and per-refinement schemas permit the new counters only for the opted-in comparison phase. Every endpoint counter is an integer excluding bool, nonnegative and completed <= attempted. Sum of retained refinement endpoint work cannot exceed cumulative totals. Each recorded event/common pair supplies a lower bound on completed work within its refinement; unrecorded failed comparison work can legitimately make global totals larger. Existing evaluation/panel/rejection totals remain separate and checked; this is not a claim that endpoint calls are ordinary rate evaluations.

The actual helper returns states, per-cell certificates, reported observations, error arrays, bindings and aggregate costs in the shape used here. Both interface-mode vectors are rebuilt against actual positive/zero liquid inventories and actual source-bound operators. Full elementwise amount/energy/stretch differences must match existing diagnostics. Both per-cell temperature and pressure error arrays bind exactly to retained observation arrays; reported temperature/pressure maximum nominal differences bind to the original scalar differences. The old independent formula is retained and checked; the new selected value is the maximum of event/common helper bounds. Helper replay validates each certificate and source/domain/geometry/error inputs.

Successive refinement pairs must reuse the preceding B state as the next A state at both event/common locations. The independent approach must start its comparison from the preceding chosen branch. For every committed event, the chosen B state at both event and common clocks must exactly equal committed history, preventing a certificate for a different candidate from authorizing that commit. Existing two-pass/independent-refinement and aggregate-event checks remain unchanged.

Trust boundary remains explicit: the retained diagnostics store maximum nominal observation differences, not an independent full EOS evaluation at all saved temperatures/pressures. This audit binds to those retained diagnostics and source descriptors; it does not re-solve energy-to-temperature or prove native endpoint samples from first principles. The tests explicitly identify synthetic operator bindings while invoking the real pure certificate auditor. This limitation is consistent with the helper's saved-data scope, not a new physical certification claim.

Read green03.xml: 51 tests, zero failures/errors/skips, 1.390 seconds. New tests cover v2 before comparison, endpoint ordering/totals, actual certificate replay, tampered event/common/state/error/mode/cost bindings, committed state mismatch, legacy missing/None restoration, and typed full-audit dispatch. check_legacy.py compares old/new encoders on the same actual manufactured result; retained legacy-parity.json records 29,705 identical canonical bytes and v1 schema. This supports default encoder compatibility without native physics claims.

No blocking issue found for the reviewed record integration. Actual helper/native event execution remains a separate validation step. The original failed case and full inverse-temperature pressure uncertainty gap remain unchanged.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE scoped v2 records and legacy restoration.
