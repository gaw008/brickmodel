Implemented opt-in sandbox_depletion_result_v2 in event_record.py. The legacy default result keeps v1 and exact encoder bytes on a shared actual manufactured run (check_legacy.py, legacy-parity.json).

The audit restores the typed comparison policy, binds its boxes to the actual operator even before any comparison, and checks endpoint attempted/completed counters globally and per refinement. Complete event/common pair records are audited with the pure paired-pressure verifier using actual operator bindings, full inventory/energy/stretch difference arrays, original per-cell inverse error arrays, and nominal observation differences. Consecutive refinement reuse, independent-approach reference states, and chosen committed event/common states are bound to the original history. Other diagnostic fields retain the prior strict numeric scanner.

RED: 7 initial cases failed before implementation (red01.xml). GREEN: 51 tests passed (green03.xml), comprising 22 new paired-record cases plus existing record and continuation checks. No native EOS or install was run. Ruff/mypy/black command executables were unavailable.

Limits: synthetic binding fixtures test data auditing with real pure certificate arithmetic; they do not demonstrate a native opt-in depletion run. The recorded reported temperatures and pressures are bound to saved diagnostics, not independently re-solved from conserved energy. This remains the explicit manufactured shared-parameter and reported-temperature conditional contract, not material validation.

Candidate source SHA256 cb0c7ab3d9e0b9ad41ed03a4d0651af769c695eb1acf98cd7d7fc56f04617161.
Candidate test SHA256 b785885a9dac8b83dd44ca5ff65ae9ed94a002f1275bc18cc2da0ea3d083aeac.
Independent review requested; pending review findings.
