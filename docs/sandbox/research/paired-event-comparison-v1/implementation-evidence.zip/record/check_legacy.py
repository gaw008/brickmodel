"""Compare both encoders on one actual manufactured result, no EOS."""
import importlib.util,json,sys
from pathlib import Path
from test_event_record import run
from sludge_sandbox import event_record as current
path=Path('/private/tmp/brick-pressure-event-record-v1')
spec=importlib.util.spec_from_file_location('sludge_sandbox.legacy_event_encoder',path/'before.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
result,*_=run()
a=old.canonical(old.encode_depletion_result(result,original_interfaces=('existing_liquid',)))
b=current.canonical(current.encode_depletion_result(result,original_interfaces=('existing_liquid',)))
assert a==b
(path/'legacy-parity.json').write_text(json.dumps({'same_actual_result_encoder_bytes_equal':True,'bytes':len(a),'schema':'sandbox_depletion_result_v1'}))
