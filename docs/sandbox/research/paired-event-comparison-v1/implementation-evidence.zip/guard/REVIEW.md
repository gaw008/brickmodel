# Independent before-endpoint guard review

APPROVE. Read-only scoped review of source.patch, the complete affected endpoint path and test sentinel refactor/additions. No EOS calls, test reruns or repository edits.

Verified source SHA256 e1240ee5c5d88669922759ae13cd1993b28d31f5cab1fc71c3256f0dc223f993 and test SHA256 995a141833888a10eebd11a01b85ebae7b4bf80b1859c214a5ec235acb8ef66a.

The new optional keyword callback executes after endpoint representability validation and immediately before each water.state_tp invocation. Its exception propagates and prevents that invocation. A water exception also propagates before the completion observer, so caller-maintained attempt/completion counters can distinguish an attempted failed call from a successful return. With before_endpoint=None the original execution path remains. The callback is skipped on the unavailable contract path and zero-liquid fast path because no endpoint is attempted there. Actual state source/type checks and post-observer/final implementation guards remain in place. No pressure arithmetic, uncertainty or physical gate is changed.

The extracted no-EOS sentinel preserves the original three final-observer identity cases and their exact four-call assertion. New cases independently verify: pre-call exception produces zero water/completion calls; second water exception yields two attempts and one completion; normal execution gives precisely before/water/after repeated four times and four reported completed endpoint evaluations. Exceptions are not swallowed or converted to apparent valid certificates. This demonstrates hook behavior, not the resource-policy decisions of future callers or native physics.

Read original XML: red.xml has 3 failures in the 3 new tests; green.xml has 18 tests, 0 failures, 0 errors, 0 skipped, 0.133 seconds. Hashes match the frozen author version. No blocking issue found in this scoped change.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE scoped guard callback and tests.
