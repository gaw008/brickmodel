"""Reconstruct the entire saved failed terminal panel with exact event time."""
from pathlib import Path
from fractions import Fraction as F
import importlib.util,sys,json,math,hashlib
import numpy as np
for name,folder in [('exact_terminal_panel','brick-exact-terminal-panel-v1'),('exact_root_order','brick-exact-root-order-v1')]:
    p=Path('/private/tmp')/folder/(name+'.py')
    spec=importlib.util.spec_from_file_location('sludge_sandbox.'+name,p)
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
from sludge_sandbox.exact_terminal_panel import build_exact_affine_panel
from sludge_sandbox.exact_root_order import order_exact_affine_roots,verify_exact_root_order
from sludge_sandbox.exact_affine_depletion import exact_depletion_writeback
from sludge_sandbox.depletion_roundoff import DepletionRoundoffPolicy,DepletionRoundoffTotals
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.integration import ConservedState,Rates,IntegrationPolicy
from sludge_sandbox.verification_case import encode
root=Path(__file__).parent
native=Path('/private/tmp/brick-four-cell-ordered-failure-evidence-v1/attempt01')
source=native/'core-result.json'
whole=json.loads(source.read_text())
d=whole['result']['refinements'][0]['comparison_details']['writeback_failure']
def decode(v):
    if isinstance(v,list):return tuple(decode(x) for x in v)
    if isinstance(v,dict):
        if set(v)=={'numerator','denominator'}:return F(v['numerator'],v['denominator'])
        return {k:decode(x) for k,x in v.items()}
    return v
state=ConservedState(**decode(d['initial_state']))
def rates(observation):
    values=dict(observation['rates']);values.pop('component_sum_residual_w')
    return Rates(**values)
a=rates(d['initial_observation']);b=rates(d['midpoint_observation'])
p=DepletionRoundoffPolicy(**d['roundoff_policy'])
ip=IntegrationPolicy(**json.loads((native/'original-integration-policy.json').read_text()))
li,vi=d['liquid_index'],d['vapor_index']
clock=d['clock'];start=T.from_float(clock['start_s']);mid=T.from_float(clock['midpoint_s'])
upper=T.from_float(math.nextafter(clock['end_s'],math.inf))
binding=('saved-native-sha256:'+hashlib.sha256(source.read_bytes()).hexdigest(),)
wet=tuple(i for i,row in enumerate(state.amounts_mol) if row[li]>0)
kw=dict(start=start,midpoint=mid,upper=upper,liquid_index=li,wet_cells=wet,
 evaporation_start_mol_s=tuple(d['initial_observation']['evaporation_mol_s']),
 evaporation_mid_mol_s=tuple(d['midpoint_observation']['evaporation_mol_s']),
 source_binding=binding,time_absolute_s=clock['time_absolute_s'],policy=p)
order=order_exact_affine_roots(state,a,b,**kw)
verify_exact_root_order(order,state,a,b,**kw)
cell=order.selected_cell
assert cell==d['cell_index']
e=next(x.evidence for x in order.candidates if x.cell_index==cell)
assert mid<e.lower
panel=build_exact_affine_panel(state,a,b,start=start,midpoint=mid,end=e.lower,
 policy=ip,liquid_index=li,selected_cell=cell,wet_cells=wet,source_binding=binding)
l=panel.ledger
terms=(float(l.face_species_mol[cell,li]),-float(l.face_species_mol[cell+1,li]),float(l.reaction_species_mol[cell,li]))
assert terms==e.signed_terms_mol
v=decode(d['totals_before']);v.pop('policy');totals=DepletionRoundoffTotals(p,**v)
after,correction,newtotals=exact_depletion_writeback(panel.raw_state,cell_index=cell,liquid_index=li,vapor_index=vi,
 panel_liquid_start_mol=float(state.amounts_mol[cell,li]),panel_liquid_terms_mol=terms,
 positive_evaporated_mol=e.positive_evaporated_mol,policy=p,totals=totals,clock_evidence=e)
# Independent complete ledger reconstruction from represented components.
max_n=F();max_e=F()
for i,j in np.ndindex(state.amounts_mol.shape):
 expected=F(float(state.amounts_mol[i,j]))+F(float(l.face_species_mol[i,j]))-F(float(l.face_species_mol[i+1,j]))+F(float(l.reaction_species_mol[i,j]))
 residual=abs(F(float(panel.raw_state.amounts_mol[i,j]))-expected);max_n=max(max_n,residual)
 assert residual<=F(ip.amount_absolute_tolerance_mol)
 if (i,j) not in ((cell,li),(cell,vi)):
  assert after.amounts_mol[i,j]==panel.raw_state.amounts_mol[i,j]
for i in range(len(state.internal_energy_j)):
 expected=F(float(state.internal_energy_j[i]))+F(float(l.face_energy_j[i]))-F(float(l.face_energy_j[i+1]))+F(float(l.cell_work_j[i]))
 residual=abs(F(float(panel.raw_state.internal_energy_j[i]))-expected);max_e=max(max_e,residual)
 assert residual<=F(ip.energy_absolute_tolerance_j)
assert np.array_equal(after.internal_energy_j,panel.raw_state.internal_energy_j)
assert np.array_equal(after.mechanical_stretches,panel.raw_state.mechanical_stretches)
assert after.amounts_mol[cell,li]==0
result={'status':'passed','qualification':'Full saved affine panel replay only; no new RHS evaluation or accepted coupled event',
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'order':order,'panel':panel,
 'after_writeback':after,'correction':correction,'totals_before':totals,'totals_after':newtotals,
 'maximum_ledger_amount_residual_mol':max_n,'maximum_ledger_energy_residual_j':max_e}
(root/'result.json').write_text(json.dumps(encode(result),indent=2,allow_nan=False)+'\n')
print('complete saved panel passed, selected',cell,'excluded',[x.cell_index for x in order.exclusions], 'levels',order.refinement_level)
