"""Actual mixed-mode endpoint observation after saved-panel numerical writeback."""
from pathlib import Path
from fractions import Fraction
from dataclasses import fields,is_dataclass
from collections.abc import Mapping
import json,hashlib,time,traceback
from sludge_sandbox.verification_case import read_case,build_case,encode
from sludge_sandbox.integration import ConservedState
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.water_properties import is_water_provider
from sludge_sandbox.deforming_solid_storage import _canonical
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent
out=root/'native01';out.mkdir(exist_ok=False)
prior=Path('/private/tmp/brick-four-cell-ordered-failure-evidence-v1/attempt01')
def save(name,x):(out/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def decode(v):
    if isinstance(v,list):return tuple(decode(x) for x in v)
    if isinstance(v,dict):
        if set(v)=={'numerator','denominator'}:return Fraction(v['numerator'],v['denominator'])
        return {k:decode(x) for k,x in v.items()}
    return v
def capture(v):
    if is_water_provider(v):return {'type':[type(v).__module__,type(v).__qualname__],'source':_canonical(v),'implementation':_canonical(v.implementation)}
    if is_dataclass(v):return {f.name:capture(getattr(v,f.name)) for f in fields(v)}
    if isinstance(v,Mapping):return {str(k):capture(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [capture(x) for x in v]
    return encode(v)
started=time.monotonic();before=runtime_identity();save('runtime-before.json',before)
casebytes=(prior/'case.json').read_bytes();(out/'case.json').write_bytes(casebytes)
replaybytes=(root/'result.json').read_bytes()
report={'status':'started','qualification':'Actual mixed-mode endpoint from saved affine samples. No accepted event packet or new integrated trajectory.'}
try:
    replay=json.loads(replaybytes)
    assert replay['status']=='passed' and replay['runtime']==before
    assert replay['source_sha256']==hashlib.sha256((prior/'core-result.json').read_bytes()).hexdigest()
    built=build_case(read_case(out/'case.json'),Path('/private/tmp/brick-free-native-events-v1/attempt01/water'))
    assert encode(built.initial)==json.loads((prior/'initial.json').read_text())
    state=ConservedState(**decode(replay['after_writeback']))
    assert state.energy_model_identity==built.initial.energy_model_identity
    li=built.operator.liquid_index
    dry=tuple(i for i,row in enumerate(state.amounts_mol) if row[li]==0)
    assert dry==(2,3)
    operator=ExactFreeWaterTransfer(built.operator).with_depleted_cells(state,dry)
    assert operator.operator.interfaces==('existing_liquid','existing_liquid','depleted_no_nucleation','depleted_no_nucleation')
    t=ExactEventTime(decode(replay['panel']['ledger']['end_s']['seconds']))
    save('state.json',encode(state));save('exact-time.json',t.to_record())
    identity=operator.operator_identity
    observation=operator.evaluate(state,t)
    assert identity==operator.operator_identity
    observation.rates.derivatives(state)
    assert encode(state)==replay['after_writeback']
    save('state.json',encode(state));save('observation.json',capture(observation))
    save('exact-time.json',t.to_record())
    report.update(status='passed',dry_cells=list(dry),operator_identity=encode(identity))
except BaseException:
    report.update(status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-after.json',after)
        assert before==after
        assert casebytes==(prior/'case.json').read_bytes()==(out/'case.json').read_bytes()
        assert replaybytes==(root/'result.json').read_bytes()
    except BaseException:report.update(status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_s=time.monotonic()-started,modules=len(before['modules']),
        replay_sha256=hashlib.sha256(replaybytes).hexdigest(),runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    save('report.json',report)
assert report['status']=='passed',report
