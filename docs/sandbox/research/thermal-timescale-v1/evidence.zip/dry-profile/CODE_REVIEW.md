# Dry host profile review

APPROVE for the scoped profile. run.py SHA256 6b7e3c076523f75159db7a6d746d61a5901c53b015c90023beb61979a0515b95; PLAN.md SHA256 21f30499f6d518570c881fe34465698e434ae0f828a69ed37a31d7faa182e7d1. Read-only diff against the reviewed wet-host profile and inspection of the saved pilot snapshot; no EOS.

Changes select the actual pilot final state at index -1 and require its time equal final_snapshot.time_s, exact identity equality with the rebuilt model, and zero liquid in every cell. Current runtime must exactly equal the saved runtime; the previous historical run_service exception is removed. Saved final_snapshot contains base_rates at time .51 as required by the new exact comparison. Each selected output is saved before comparison with those rates. Existing full selected-output comparison, profile evidence, separate serialization timing, exact parent hashes and before/after runtime guards remain intact.

At most two base-host evaluations occur after one build, first profiled and second unprofiled under the root-owned 40 s external watchdog. Builder cost is separate and can include native calculations. Base-host timing omits the phase wrapper, event comparison and orchestration costs. First/second timing is confounded by profiling and execution history. This is dry-state unit-cost evidence only, not guaranteed long-time duration or convergence. Failure of exact output parity must be retained and diagnosed without weakening the gate.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — scoped script and plan only.
