# Dry profile result review

APPROVE for the bounded saved sample. Process exited 0 without timeout in 1.409652208 s. Build took 1.015054542 s; the two actual host calls took 0.043683833 s profiled and 0.017185833 s unprofiled. Serialization/profile-output times are separately recorded.

Independently read both actual selected-output JSON files: they are exactly equal and their rates equal the saved pilot final_snapshot.base_rates. The captured time is .51 s, selected state is the actual final dry state, runtime before/after agree and module differences are empty. Reviewed script hash remains 6b7e3c076523f75159db7a6d746d61a5901c53b015c90023beb61979a0515b95. No EOS or profile rerun.

This establishes output parity and this dry base-host sample cost. Profile overhead and execution history confound the difference between calls. Build cost, phase wrapper, event comparisons and full integration are outside the host timing; no guaranteed long-time duration, speedup factor, convergence or material claim follows.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — bounded recorded sample only.
