# Fine time-control review

APPROVE for the registered time control. No EOS or source edits.

Hashes: run.py0110daafc4ac67d940c35f8b5392e7f7e33dd400e4665926408b5c2f3c11aa1d; PLAN.md3dffdc30da5c624d91fbb88de52664c5727fdff1f0442ac108840164f2755693; caseb87ef88f0cf9f805fe2747d4b385acac25d7213580bac575e7cf6e10e489387c.

Independent complete JSON comparison verifies only case_id, refinement0->1 and maximum_steps512->1024 change. Actual builder divides ordinary initial/maximum steps by2**refinement, producing2^-15/2^-10; other numerical tolerances, physical case, endpoint1.125, conditional source/error declarations,800 s wall and nested event controls remain unchanged. Runner diff retains original sealing/raw/runtime/input guards and two-event full-endpoint requirement.

At the fine cap, roughly640 dry continuation panels plus event attempts already exceed512. The1024 allowance is a counted resource budget, not a relaxed scientific gate. Nominal170 s and threefold510 s are conditional estimates below800, not guarantees; actual errors/domain/budget guards remain authoritative and root owns840 s watchdog.

Plan correctly requires unchanged prefix audit, distinct actual accepted grids, and all-cell N/E/T/P/stretch/event-time comparison. Raw differences, inverse bounds and integration tolerance scales must be reported separately; differences below inverse bounds cannot demonstrate an observed convergence order. Nested event controls are not independently halved. Two ordinary grids alone do not establish asymptotic temporal order or spatial convergence. No blocking issue within the declared scope.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — scoped plan/case/runner only.
