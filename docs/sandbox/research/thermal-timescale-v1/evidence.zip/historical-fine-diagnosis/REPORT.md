# Initial refined-cell event separation, from actual saved observations

Read-only, no EOS or source edits. Inputs are actual archived4-cell coarse and8-cell coarse initial snapshots inside docs/sandbox/research/free-spatial-study-v1/raw-evidence.zip. Exact result/archive hashes and Fraction ratios are saved in initial-candidates.json. These are earlier spatial-run observations, not new endpoint-strategy observations.

## Actual computed candidates

The saved inventory layout is A,B,H2O,H2O_liquid,fixture. Recomputed net liquid rate is **left liquid face rate minus right liquid face rate plus liquid source rate**, using Fraction of each stored float, exactly as current candidate code. Saved liquid face rates are zero and evaporation is positive.

-4cells: cell0/1 each tau=.0002831733318826513s; cell2/3 each tau=.0002671129331012913s. Sorted first cells2,3 have exact Fraction gap0.
-8cells: cells0–3 each tau=.0002831733318826513s; cells4–7 each tau=.0002671129331012913s. Sorted first cells4,5 have exact Fraction gap0 (all four hot-parent children tie).

Child inventories and rates both scale with parent subdivision, so the identical ratios are supported by actual saved values, not only symmetry reasoning. Between-parent estimate difference is about16.0604microseconds, but this does not resolve the within-parent ties.

## Exact current rejection condition and timing

In depletion_integration.py candidate(op,state,obs), each existing_liquid cell with represented Nl>0 and exact net derivative<0 contributes (Fraction(Nl)/−rate,cell). Nonpositive evaporation under such a sink is a different unsupported case. Options are sorted; if at least two and abs(options[1].tau−options[0].tau)<=Fraction(event_policy.time_absolute_s), the code raises unsupported / simultaneous_events_not_separated. The original event threshold is1e-8s. Gap0 therefore satisfies rejection exactly for both saved observations.

Main event loop calls observe then candidate before advancing its next path (current line955); it does not first evolve the spatial gradient until symmetry breaks. Hence **if** these saved observations are reproduced by current source at initial state, the event integrator rejects immediately before the first accepted advance. This is a concrete software-admission finding, not proof of simultaneous physical roots. Ordinary spatial integration previously did not invoke this event selector, so its successful15µs run is consistent with this finding.

Actual dynamics may separate adjacent/nonadjacent children after heat/gas propagation, or two actual events may remain simultaneous. Initial N/r is neither an event-time interval nor a proof of either. Changed numerical strategy/source bytes may perturb reported rates; tiny differences need not exceed1e-8s, and numerical perturbations cannot be used as a deliberate symmetry breaker. Therefore do not label the current new-source4/8 run already executed/blocked, and do not assert actual event nonseparation solely from these historical rates.

## Bounded next check

Before a long4/8 native allocation, build the exact same4-cell physical case under current frozen endpoint-strategy event policy, evaluate **one initial actual WaterPhaseTransfer callback**, save full conserved initial state and actual net liquid/evaporation/T/error observations and compute the same exact sorted ratios. Root-owned external40s cap is a limit, not a promised completion; preserve timeout/failure. No trajectory integration or second callback required. Four cells are the smallest refined case already exhibiting the historical tie;8cells need not run until4cell admission is understood.

If the current initial gap still lies within the original1e-8 gate, report the selector's exact initial rejection, then design a certified simultaneous-event group or an explicitly proved safe pre-event advance policy separately. Do not perturb child inventories/temperature, alter event gate, arbitrarily select one sibling, or start the fine mesh from a coarse post-drying state. A group solution must preserve each cell's N/E/T/P/stretch gates, local correction/evaporation fractions and original global budgets; simply zeroing all tied liquid inventories is not such a certificate.

If the initial gap is above the gate, it permits initial candidate selection only. Actual event/common-time refinements must still establish original acceptance and may encounter later nonseparation. Save this as an observed admission result, not event-separation proof. No change to original short-time spatial FAIL follows.

Command used for this report's calculation: Python3 standard-library zipfile/json/hashlib/Fraction read of the two archived result.json and case.json records; no production imports. The exact inputs and computed values are in initial-candidates.json. No native tests launched.
