"""Single root-owned service run; external watchdog belongs to the caller."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import traceback

REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')
CASE=REPO/'data/sandbox/cases/reacting-wet-free-thermal-timescale-coarse-v1.json'
OLD_CASE=REPO/'data/sandbox/cases/reacting-wet-free-longer-pilot-v1.json'
WATER=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')


def save(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    temporary.replace(path)


def require(ok,message):
    if not ok:raise AssertionError(message)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    directory=parser.parse_args().output
    require(not directory.exists(),'fresh service output required')
    report_path=directory.parent/(directory.name+'-runner.json')
    require(not report_path.exists(),'fresh runner evidence required')
    directory.parent.mkdir(parents=True,exist_ok=True)
    started=time.monotonic()
    report={'status':'started','external_watchdog_seconds':840,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'qualification':'Manufactured strategy service run; no spatial convergence or material admission claim.'}
    save(report_path,report)
    try:
        from sludge_sandbox.run_service import run_case,read_run,runtime_identity
        from sludge_sandbox.verification_case import encode
        before=runtime_identity();report['runtime_before']=before
        raw=CASE.read_bytes();original_raw=OLD_CASE.read_bytes()
        case=json.loads(raw);original=json.loads(original_raw)
        stripped=json.loads(raw)
        require(stripped['numerics']['end_s']==1.125 and stripped['numerics']['integration']['maximum_step_s']==2**-9,'registered pilot changes')
        stripped['numerics']['end_s']=original['numerics']['end_s']
        stripped['numerics']['integration']['maximum_step_s']=original['numerics']['integration']['maximum_step_s']
        stripped['case_id']=original['case_id']
        require(stripped==original,'physical case or original policy changed')
        report.update(case_sha256=hashlib.sha256(raw).hexdigest(),original_case_sha256=hashlib.sha256(original_raw).hexdigest())
        save(report_path,report)
        returned=run_case(CASE,WATER,directory,evidence_directory=REPO/'data/sandbox')
        report['returned_status']=returned.get('status');report['returned_reason']=returned.get('reason')
        save(report_path,report)
        result,manifest=read_run(directory)
        report['read_run_verified']=True;report['artifact_count']=len(manifest['files'])
        require(returned==result,'returned/saved result mismatch')
        record=json.loads((directory/'depletion_result.json').read_bytes())
        report.update(run_status=result['status'],reason=result.get('reason'),record_status=record['status'],
            steps=len(record['steps']),events=len(record['events']),final_time_s=record['times_s'][-1],
            evaluations=record['evaluations'],attempted_steps=record['attempted_steps'],
            rejected_trials=record['rejected_trials'],phase_costs=record['phase_costs'],
            integration_elapsed_seconds=record['elapsed_seconds'])
        save(report_path,report)
        require(record==result['integration'],'raw/audited depletion record mismatch')
        require(result['status']==record['status']=='completed','completed service run required')
        require(record['times_s'][0]==case['numerics']['start_s'] and record['times_s'][-1]==case['numerics']['end_s'],'original horizon')
        require(len(record['events'])==2,'two actual depletion events required')
        require(result['runtime_before']==result['runtime_after']==before,'service runtime binding')
        require((directory/'case.json').read_bytes()==raw,'saved case exact bytes')
        require(CASE.read_bytes()==raw and OLD_CASE.read_bytes()==original_raw,'input changed during run')
        report['status']='passed'
    except BaseException as exc:
        chain=[];pending=[exc];seen=set()
        while pending:
            error=pending.pop()
            if id(error) in seen:continue
            seen.add(id(error));row={'type':type(error).__name__,'message':str(error)}
            if hasattr(error,'pressure_trial_ledger'):
                row['pressure_trial_ledger']=encode(error.pressure_trial_ledger)
            chain.append(row)
            pending.extend(e for e in (error.__cause__,error.__context__) if e is not None)
        report.update(status='failed',exception_chain=chain,traceback=traceback.format_exc())
        # run_case retains its own raw files and seals even when it catches a
        # solver exception internally. Never edit those diagnostic artifacts.
        if (directory/'result.json').exists():
            try:report['saved_failure_result']=json.loads((directory/'result.json').read_bytes())
            except Exception as error:report['failure_read_error']=str(error)
    finally:
        try:
            from sludge_sandbox.run_service import runtime_identity
            report['runtime_after']=runtime_identity()
            require(report['runtime_before']==report['runtime_after'],'runtime changed')
        except BaseException:
            report['integrity_error']=traceback.format_exc();report['status']='failed'
        report['wall_seconds']=time.monotonic()-started;save(report_path,report)
    require(report['status']=='passed',str(report.get('exception_chain','runner failed')))


if __name__=='__main__':main()
