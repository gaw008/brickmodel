# Thermal-timescale coarse feasibility review

APPROVE for the registered bounded feasibility run; no EOS or source edits.

Inspected SHA256:
- run.py: 3801f48813c0dfb320a3b3f591b43281d060629eaa3e7370f3313fd8df617251
- PLAN.md: d3c9ecbdc1a83f4f776d55293f390f2d12022a20e7c31fa3c4c925941fb5994f
- case: d33adcfec628ad5e78fed067e10e06b288bd2d099ca77753cff3739727854586

Independent complete JSON comparison confirms only case_id and end_s differ from the completed .51 s pilot. Absolute end 1.125 s gives .625 s elapsed from .5. Ordinary cap remains 2^-9 s, initial/nested wet cap 2^-14 s, maximum_steps 512 and wall limit 800 s. All physical inputs, source envelopes, error tolerances and event gates are unchanged. Runner diff retains fresh output, one uninterrupted service call, raw/sealed record comparison, source/runtime and exact case-byte guards, required full endpoint and two events. Hard 840 s watchdog remains root-owned.

The dry sample-based estimate is correctly conditional: 320*7*.01719 is approximately38.5 s, plus68 s gives106.5 s, and threefold allowance is319.5 s below800 s. Neither accepted step count nor all native/wrapper costs are bounded by this estimate. The observed event prefix consumed more attempted panels than accepted steps; budget accounting must retain those additional attempts (roughly320 continuation plus70 previous attempted panels remains below512 before new refinement/rejection costs). Active numerical/resource/domain guards remain authoritative.

Original independent prefix audit and unchanged2e-8 J global work target remain mandatory after termination. A larger physical interval may fail domain, global work or resources even if the pilot passed. Such failure must remain failure. The separately acknowledged half-cap run would exceed the current512 budget at the cap estimate alone and needs separate registration. This coarse run cannot establish temporal or spatial convergence, real-material validity or overall Goal completion.

The separately saved four-cell diagnostic reports equal first candidate ratios for cells2 and3 and zero gap; this is only initial selector arithmetic, not an integrated simultaneous-event proof. Deferring4/8 long runs pending selector support is consistent with the plan.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — scoped feasibility plan/case/runner, with unchanged rejection gates.
