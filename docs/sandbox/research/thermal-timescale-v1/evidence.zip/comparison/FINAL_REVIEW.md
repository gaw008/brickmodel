# Final comparison and fine-result review

APPROVE. Earlier original-audit and actual-policy findings are closed in compare.py SHA48f6bb7158f048b5293ae1c4baca42ec359afdc5d59a9ac0696f71c6992f8c06. The script now binds audit.script_sha256 and actual audit_prefix.py to original287bc351617df55f534978648010c781128603a7dfe2d4480cef08af91135245, and reconstructs/compares the complete actual integration policy from case refinement. Cap checks use the existing correctly-rounded absolute-endpoint contract. Preserved before-review report already passed the strict duration cap; this was a contract correction, not a failed-result tolerance relaxation.

Reviewed actual report and verified its script, both raw result/record/case hashes and both audit JSON hashes against files. Fine raw record equals result.integration; runner/service before-after identity agrees;65 recorded modules match repository bytes. Fine original six-dimensional refinement gates pass. Audit script and actual case/record inputs match saved audit fields. No EOS, compare rerun or prefix-audit rerun.

Fine completed end1.125 with669 steps,709 attempts,5065 evaluations and two depletion events in173.666924125 s process time (171.267546583 s integration). Both final modes are depleted_no_nucleation. Saved audit covers all669 prefixes and reports PASS. Exact recorded diagnostics give maximum global pressure-work residual4.0715432405327004e-10 J and cumulative absolute cross-cell constraint sum1.6665388953659998e-17 J, below original2e-8 J.

Actual comparison uses distinct349/669-step grids and halved ordinary caps. Event time differences are exactly zero within original1e-8 s. Endpoint maximum differences are approximately1.39820e-10 mol,1.26136e-7 J,4.09054e-9 stretch,1.30858e-8 K and9.87175e-4 Pa. The recorded T differences lie below the approximately4e-8 K point bounds, and P differences below approximately1.7e-3 Pa point bounds. Thus these differences do not establish an observed asymptotic order. Final endpoint differences are reported, not tested against newly invented gates or the event-only pressure threshold.

Initial energy identities differ because the separately sourced case definitions differ; exact numerical initial arrays and complete case comparison establish the stated controlled experiment, not checkpoint interchangeability. Nested event controls were not independently halved. This is a two-grid manufactured ordinary-trajectory comparison, not spatial convergence, real-material validation, complete-cycle proof or Goal completion.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — prior findings resolved; bounded comparison and saved-result scope only.
