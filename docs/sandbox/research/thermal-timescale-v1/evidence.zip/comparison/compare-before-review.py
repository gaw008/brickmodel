"""Saved two-level time comparison. Standard library only; never calls a solver."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import traceback

HERE=Path(__file__).resolve().parent
PATHS=(Path('/private/tmp/brick-thermal-timescale-coarse-v1/attempt01'),
       Path('/private/tmp/brick-thermal-timescale-fine-v1/attempt01'))


def require(ok,message):
    if not ok:raise AssertionError(message)


def read(path):
    def unique(items):
        d={}
        for k,v in items:
            require(k not in d,'duplicate JSON key');d[k]=v
        return d
    return json.loads(path.read_text(),object_pairs_hook=unique,
                      parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def number(v):
    require(type(v) in (int,float) and math.isfinite(v),'finite numeric')
    return F(v)


def difference(a,b):
    if isinstance(a,list):
        require(isinstance(b,list) and len(a)==len(b),'quantity shape')
        return [difference(x,y) for x,y in zip(a,b)]
    value=abs(number(a)-number(b))
    return {'exact':str(value),'float':float(value)}


def load(directory):
    case=read(directory/'case.json');result=read(directory/'result.json')
    record=read(directory/'depletion_result.json');manifest=read(directory/'manifest.json')
    actual={p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file() and p!=directory/'manifest.json'}
    require(actual==set(manifest['files']),'manifest membership')
    for name,digest in manifest['files'].items():
        path=directory/name
        require(path.resolve().is_relative_to(directory.resolve()) and not path.is_symlink(),'safe artifact path')
        require(sha(path)==digest,'artifact hash: '+name)
    require(result['case_sha256']==sha(directory/'case.json'),'case SHA')
    require(result['integration']==record,'raw/result record equality')
    require(result['runtime_before']==result['runtime_after'],'within-run source equality')
    require(result['status']==record['status']=='completed','completed run')
    audit_path=directory.parent/(directory.name+'-prefix-audit.json')
    audit=read(audit_path)
    require(audit['acceptance']=='passed' and audit['prefix_arithmetic']=='passed','independent prefix audit PASS')
    for name in ('case.json','depletion_result.json'):
        require(audit['input_sha256'][name]==sha(directory/name),'prefix audit actual input SHA')
    require(len(audit['prefixes'])==len(record['steps']),'all accepted prefixes audited')
    require(record['times_s'][0]==case['numerics']['start_s'] and record['times_s'][-1]==case['numerics']['end_s'],'fixed horizon')
    require(len(record['times_s'])==len(record['states'])==len(record['steps'])+1,'complete mesh')
    cap=number(result['policy']['maximum_step_s'])
    for i,step in enumerate(record['steps']):
        require(step['start_s']==record['times_s'][i] and step['end_s']==record['times_s'][i+1],'accepted panel time binding')
        require(0<number(step['end_s'])-number(step['start_s'])<=cap,'actual policy timestep cap')
    require(result['final_snapshot']['state']==record['states'][-1],'final snapshot accepted state')
    return case,result,record,{'directory':str(directory),'audit_sha256':sha(audit_path),
        'case_sha256':sha(directory/'case.json'),'result_sha256':sha(directory/'result.json'),
        'depletion_result_sha256':sha(directory/'depletion_result.json'),
        'steps':len(record['steps']),'actual_policy':result['policy'],
        'declared_case_policy':case['numerics']['integration'],'prefix_audit':'passed'}


def main():
    report={'status':'failed','qualification':'Two actual time meshes; reported differences and original uncertainty only. No fitted order, spatial convergence or new posthoc endpoint gates.',
            'script_sha256':sha(Path(__file__))}
    try:
        loaded=[load(p) for p in PATHS];(ca,ra,a,ma),(cb,rb,b,mb)=loaded
        report['runs']=[ma,mb]
        left=read(PATHS[0]/'case.json');right=read(PATHS[1]/'case.json')
        for obj in (left,right):
            obj.pop('case_id');obj.pop('refinement');obj['numerics']['integration'].pop('maximum_steps')
        require(left==right,'unregistered case difference')
        require(cb['refinement']==ca['refinement']+1,'one refinement level')
        require(ra['runtime_before']==rb['runtime_before'],'two-run runtime/source equality')
        require(a['times_s']!=b['times_s'],'distinct actual accepted grids')
        require(number(rb['policy']['maximum_step_s'])==number(ra['policy']['maximum_step_s'])/2,'actual maximum cap halved')
        for key in ('amounts_mol','internal_energy_j','mechanical_stretches'):
            require(a['states'][0][key]==b['states'][0][key],'exact same initial '+key)
        report['initial_energy_identities_equal']=a['states'][0]['energy_model_identity']==b['states'][0]['energy_model_identity']
        sa,sb=ra['final_snapshot'],rb['final_snapshot']
        report['endpoint_differences']={key:difference(a['states'][-1][key],b['states'][-1][key])
            for key in ('amounts_mol','internal_energy_j','mechanical_stretches')}
        report['endpoint_differences'].update({key:difference(sa[key],sb[key]) for key in ('temperature_k','pressure_pa')})
        report['mechanical_layout']='cell normal stretches followed by one common tangent'
        report['original_point_bounds']={
            'temperature_coarse_k':sa['inverse_temperature_error_k'],'temperature_fine_k':sb['inverse_temperature_error_k'],
            'pressure_coarse_pa':[c['thermal']['pressure_error_bound_pa'] for c in sa['cells']],
            'pressure_fine_pa':[c['thermal']['pressure_error_bound_pa'] for c in sb['cells']]}
        require(len(a['events'])==len(b['events'])==2,'two events per run')
        require([e['cell_index'] for e in a['events']]==[e['cell_index'] for e in b['events']],'same event identities/order')
        gate=number(ca['numerics']['depletion']['time_absolute_s'])
        require(gate==number(1e-8),'original event clock gate')
        report['event_time_comparison']=[{'cell':x['cell_index'],'difference_s':difference(x['time_s'],y['time_s']),
            'original_gate_s':float(gate),'within_gate':abs(number(x['time_s'])-number(y['time_s']))<=gate}
            for x,y in zip(a['events'],b['events'])]
        require(all(row['within_gate'] for row in report['event_time_comparison']),'event time original gate')
        report['status']='passed_registered_comparison_contract'
    except Exception as exc:
        report['failure']={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
    (HERE/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    require(report['status']=='passed_registered_comparison_contract',str(report.get('failure')))


if __name__=='__main__':main()
