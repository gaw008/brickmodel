# Final longer-pilot review

APPROVE for the bounded manufactured pilot. Read-only raw result and saved-audit review; no EOS or repeat audit execution.

Actual process exit 0 without timeout, 67.543580750 s total; integration reports 65.518639375 s. Completed the exact interval [0.5, 0.51] with 34 accepted steps, 620 evaluations, 74 attempted panels, zero rejected trials and 24 completed/attempted paired endpoints. Two depletion events occurred: cell 1 at 0.5002686445610502 (common time 0.5002774733491246), then cell 0 at 0.5002848875652363 (common time 0.5002927321381871). Both final liquid inventories are exactly zero and modes are depleted_no_nucleation. The saved trajectory continues to the registered longer endpoint.

Independent JSON comparison confirms the case differs from the prior endpoint-strategy case only in case ID, end=.51 and ordinary maximum_step=2^-9. Original physical inputs, envelopes, numerical tolerances, six-dimensional event gates and 800 s budget remain unchanged. Each saved non-null six-dimensional refinement comparison was checked against its original threshold and passes. Raw depletion_result.json equals result.integration; service and runner runtime identities agree before and after; all 65 recorded source module hashes match current repository bytes. Runner records read_run verification of 94 sealed artifacts.

The executed independent prefix verifier retains exact SHA256 287bc351617df55f534978648010c781128603a7dfe2d4480cef08af91135245. Its case input hash f4c380c98cf87d4fe7c9933bdc19c212dd9a1e2721c6a60322ec9458f238876f and depletion record hash d5b9194361cdbbb789e4e503d44fd7b88edd11374eb66c023b8ce704e4af7b42 match actual files. It reports all 34 prefixes and two corrections passed. Re-reading its exact Fraction diagnostics yields maximum global pressure-work residual 2.509428614671677e-10 J and cumulative absolute cross-cell constraint sum 3.460286753850202e-19 J, both at prefix 34 and below unchanged 2e-8 J. This is saved conservation/correction arithmetic, not endpoint EOS recertification.

The longer pilot completed with only four additional accepted steps versus the shorter run, but this does not certify future long-time cost, spatial convergence, thermal error bounds outside the declared regime, or real-material behavior. Event times need not equal the previous run bit-for-bit because the ordinary step cap changed. The conditional manufactured source/error assumptions remain explicit. Overall Goal remains unfinished.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — scoped recorded pilot and retained audit evidence only.
