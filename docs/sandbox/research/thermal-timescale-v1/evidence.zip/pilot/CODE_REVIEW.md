# Longer pilot review

APPROVE for the bounded uninterrupted cost pilot. No EOS, source edits, or experiment execution.

Inspected SHA256:
- run.py: 904c19063f2e4fab46a64e49524ada3f2c7ef05c830693ba7744a2eb1dbb7814
- PLAN.md: 63576dc0bfa98a7c574e7d6f43330764f89a0b38628f7ac3d4dc730c3c54f3f7
- new case: f4c380c98cf87d4fe7c9933bdc19c212dd9a1e2721c6a60322ec9458f238876f
- previous endpoint-strategy case: 9d930a6c6d60cf328e5abe2e61dc6a5f9f0cf06d9453827b84d0f0b56e5746f4

Independent JSON comparison confirms exactly three differences: case ID, end time 0.51 s, and ordinary maximum step 2^-9 s (0.001953125 s). Initial time/inventories, physical laws and parameters, source envelopes, strategy, tolerances, event declarations and gates all remain identical. Initial step remains 2^-14 s; nested wet approach maximum step also remains 2^-14 s. The larger ordinary cap permits larger steps but does not promise that error control will accept them. Maximum steps remains 512 and cumulative wall budget remains 800 s.

Diff against the previously reviewed single-service runner contains only CASE/OLD_CASE paths and the exact three-field admission logic. Fresh directories, one uninterrupted run_case call, raw result preservation, sealing verification, exact saved/returned record comparison, before/after runtime binding and input-byte checks remain intact. Success still requires completed status, exact requested horizon and two actual depletion events. There is no intentional cancellation or restart in this pilot.

The 840 s hard watchdog remains root-owned and external. Preserved failures must remain failures, including step-budget, time-budget or original prefix-gate failures; the longer horizon cannot justify loosening thresholds. Reusing the unchanged independent prefix audit after termination is appropriate. That audit does not establish physical or spatial convergence, and a completed pilot is only bounded evidence about this manufactured model and its post-event computational cost. Source bounds and the conditional paired-pressure assumptions remain qualifications, not real-material admission.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — scoped plan, case and runner only; no experimental result reviewed.
