# Four-cell candidate probe review

APPROVE for the one-callback diagnostic. run.py SHA256 dbaa2e3e13e571168c6b48a2568673b7c3d1faa2557cd98002f6efc48c0fe8fb. Read-only review against actual depletion_integration.py candidate selector; no EOS or integrator run.

Derived case retains the two physical parent cells and changes only cell count to four, case ID and four extensive integration amount/energy absolute-tolerance/scale fields by .5. Restore-and-compare enforces all other settings unchanged, including original 1e-8 s event gate. Actual built child inventories are checked against half the correct parent and state shape is checked. This probe does not establish full thermal/mechanical spatial equivalence or convergence.

One WPT operator.evaluate call occurs after build; initial state and actual observation are saved before candidate reconstruction. Fraction arithmetic uses represented left-minus-right liquid face rates plus liquid reaction rate, positive initial liquid and negative net rate, sorted N/(-rate), with first gap <= original time gate. This matches the current selector arithmetic. The nonpositive evaporation predicate is retained, while its diagnostic outcome label is explicitly a probe label. It does not call the selector's rates.derivatives validation or integrator, so its conclusion remains arithmetic diagnosis, not full integration admission or physical simultaneity proof.

Runtime before/after and source/derived case byte checks remain. External 40 s watchdog is root-owned; builder native calls are separate from the single callback count. An unsupported/tied selection can legitimately produce completed_probe, meaning the diagnostic finished, not that integration succeeded. Raw observation remains available for independent interpretation.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — scoped saved arithmetic diagnostic only.
