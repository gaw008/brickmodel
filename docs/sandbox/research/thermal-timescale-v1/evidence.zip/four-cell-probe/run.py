"""One initial WPT callback, no integration and no second callback."""
import argparse
import copy
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import time
import traceback

REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')
CASE=REPO/'data/sandbox/cases/reacting-wet-free-paired-events-endpoint-root-v1.json'
WATER=Path('/private/tmp/brick-free-native-events-v1/attempt01/water')


def save(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)


def require(ok,message):
    if not ok:raise AssertionError(message)


def exact(value):return {'numerator':value.numerator,'denominator':value.denominator}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    output=parser.parse_args().output;output.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();report={'status':'started','callback_attempts':0,
      'external_wall_limit_seconds':40,'qualification':'Initial callback and reconstructed selector arithmetic only; no integrator execution or physical simultaneity proof.'}
    save(output/'result.json',report)
    try:
        from sludge_sandbox.run_service import runtime_identity
        from sludge_sandbox.verification_case import read_case,build_case,encode
        before=runtime_identity();report['runtime_before']=before
        require(len(before['modules'])==65,'registered 65-module runtime')
        original=CASE.read_bytes();case=json.loads(original);old=copy.deepcopy(case)
        require(case['grid']['cells']==2 and case['grid']['parent_cells']==2,'original parent grid')
        case['grid']['cells']=4;case['case_id']+='-four-cell-initial-probe'
        scaled=('amount_absolute_tolerance_mol','amount_scale_mol','energy_absolute_tolerance_j','energy_scale_j')
        for field in scaled:case['numerics']['integration'][field]*=.5
        restored=copy.deepcopy(case);restored['grid']['cells']=2;restored['case_id']=old['case_id']
        for field in scaled:restored['numerics']['integration'][field]=old['numerics']['integration'][field]
        require(restored==old,'unregistered physical or policy changes')
        require(case['numerics']['depletion']['time_absolute_s']==1e-8,'original event time gate')
        save(output/'case.json',case);definition=read_case(output/'case.json')
        report.update(original_case_sha256=hashlib.sha256(original).hexdigest(),case_sha256=definition.sha256,
                      case_schema=case['schema'],scaled_integration_fields=list(scaled),scale_factor=.5)
        save(output/'result.json',report)
        built=build_case(definition,WATER);state=built.initial;operator=built.operator
        save(output/'initial.json',encode(state))
        require(len(state.amounts_mol)==4 and len(state.mechanical_stretches)==5,'actual refined state schema')
        for i,row in enumerate(state.amounts_mol):
            parent=0 if case['profile']=='uniform' else i//2
            require(list(row)==[value/2 for value in case['initial']['parent_amounts_mol'][parent]],'actual child inventory extensity')
        report['callback_attempts']=1;save(output/'result.json',report)
        call_start=time.monotonic();actual=operator.evaluate(state,built.start_s)
        report['callback_seconds']=time.monotonic()-call_start
        base=actual.base_evaluation
        observed={'rates':encode(actual.rates),'cell_transfers':encode(actual.cell_transfers),
            'geometry':encode(base.geometry),'free':encode(base.free),
            'inverses':[{'target':encode(inv.target),'thermal_state':encode(inv.state.thermal_state),
                'skeleton_state':encode(inv.state.skeleton_state),'total_energy_j':inv.state.total_energy_j,
                'temperature_error_bound_k':inv.temperature_error_bound_k,
                'total_energy_residual_j':inv.total_energy_residual_j} for inv in base.total_inverses]}
        save(output/'observation.json',observed)
        li=operator.liquid_index;rates=actual.rates;options=[];unsupported=[]
        for i,mode in enumerate(operator.interfaces):
            inventory=F(float(state.amounts_mol[i,li]))
            net=F(float(rates.face_species_mol_s[i,li]))-F(float(rates.face_species_mol_s[i+1,li]))+F(float(rates.reaction_species_mol_s[i,li]))
            if mode=='existing_liquid' and inventory>0 and net<0:
                if actual.cell_transfers[i].rate_mol_s<=0:unsupported.append(i)
                options.append((inventory/-net,i,inventory,net))
        options.sort()
        gate=F(case['numerics']['depletion']['time_absolute_s'])
        gap=options[1][0]-options[0][0] if len(options)>1 else None
        outcome=('unsupported_nonpositive_evaporation' if unsupported else
                 'simultaneous_events_not_separated' if gap is not None and gap<=gate else
                 'initial_candidate_selectable' if options else 'no_initial_candidate')
        selection={'scope':'Exact reconstruction of nested candidate arithmetic, not a call to integrator.',
            'options':[{'cell':i,'time_ratio_s':exact(t),'time_ratio_float_s':float(t),
                        'liquid_mol':exact(n),'net_liquid_mol_s':exact(r)} for t,i,n,r in options],
            'first_gap_s':None if gap is None else exact(gap),'original_gate_s':exact(gate),
            'unsupported_nonpositive_evaporation_cells':unsupported,'outcome':outcome}
        save(output/'selection.json',selection)
        report['selection_outcome']=outcome;report['status']='completed_probe'
        require(CASE.read_bytes()==original,'original case changed')
        require(hashlib.sha256((output/'case.json').read_bytes()).hexdigest()==definition.sha256,'derived case changed')
    except BaseException as exc:
        report.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
    finally:
        try:
            from sludge_sandbox.run_service import runtime_identity
            report['runtime_after']=runtime_identity()
            require(report['runtime_before']==report['runtime_after'],'runtime changed')
        except BaseException:report['integrity_error']=traceback.format_exc();report['status']='failed'
        report['elapsed_seconds']=time.monotonic()-started;save(output/'result.json',report)
    require(report['status']=='completed_probe',report.get('reason','probe failed'))


if __name__=='__main__':main()
