# Independent design and arithmetic read

ROOT read DESIGN.md and material_arithmetic.py after the author completed their
recorded standard-library run. The script's source hashes and result/request
checks bind the same saved Cedrone pool; the observed atomic-weight binary64
values are converted to exact Fractions without replacing them by decimal
approximations. D = C + H/4 + S - O/2 and the O/N increments follow directly
from the stated reference products. At lambda1 the reference-product atom map
closes all five elements; it is not an equilibrium prediction. At each lambda
the added O2/N2 molecular mass equals the weighted element increments, and the
total is .704 kg plus added gas. The mass tolerance is precisely the original
element tolerance propagated by those atomic weights.

Approved for two separately initialized, explicit VCS attempts at lambda1/4
and1, following the stated plan. No extra baseline solve, monotonicity gate,
graphite-disappearance requirement, heat-duty or material qualification is
introduced. The actual script invocation used normal Python (not -O), so the
recorded assertion checks were enabled. This is a read of the finite design and
short arithmetic script, not a new EOS/native run or an experimental validation.

Bindings: DESIGN.md 19b553dd8782307f0f5f92d031550833e778a1565340e5ec95917332ffc939a6.
The recorded material_arithmetic.py and MATERIAL_ARITHMETIC.json hashes are in
the author's SHA256SUMS/SHA record; all physical input sources remain unchanged.
