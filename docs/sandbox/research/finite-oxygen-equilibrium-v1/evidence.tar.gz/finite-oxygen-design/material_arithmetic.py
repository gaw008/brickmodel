"""Exact material-balance design from saved bytes; no thermodynamic backend."""
from __future__ import annotations

from fractions import Fraction
import hashlib
import json
from pathlib import Path


WORK = Path(__file__).resolve().parent
BASE = WORK.parent / 'cedrone-execution/native01'
POOL = Path('/Users/wanggaoying/Desktop/brickmodel-github/data/sandbox/research/'
            'cedrone2024-element-pool-v1/printed-pool.json')
ELEMENTS = ('C', 'H', 'O', 'N', 'S')
EXPECTED = {
    'printed-pool.json': '92feba43d25479d99a2607466fb902841d0afcffc5b1108ca2ff74a42145f7fd',
    'INPUT.json': '7dae7e3aa78d42fff68b8fe49c0bdc6dd05d7f074f05e2b8b1f4fd2736a3492c',
    'RESULT.json': 'c8f544fe09694ef4bcadde046a98a6c125ab99e9cc1b5e5abb5d4330bb1739f9',
    'OBSERVABLES.json': '6179099fc6c9ac33d5b5c167b8c8fc62dfa821797734ebcd794fc464c6472e9f',
    'STATUS.json': '89ab8f2b77d84154ceb2c346a9a42267da95597b86bed290a433a70c68800edf',
}


def fraction(record: dict) -> Fraction:
    """Decode a saved integer fraction without a float conversion."""
    return Fraction(int(record['numerator']), int(record['denominator']))


def encode(value: object) -> object:
    """Preserve exact arithmetic with a separate display-only approximation."""
    if isinstance(value, Fraction):
        return {'numerator': value.numerator, 'denominator': value.denominator,
                'fraction': str(value), 'approximate_display': float(value)}
    if isinstance(value, dict):
        return {key: encode(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(item) for item in value]
    return value


def calculate() -> dict:
    """Derive two proposed additions and a stoichiometric comparison vector."""
    docs, evidence = {}, {}
    for name, expected in EXPECTED.items():
        path = POOL if name == 'printed-pool.json' else BASE / name
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != expected:
            raise ValueError('saved_input_changed:' + name)
        docs[name] = json.loads(raw)
        evidence[name] = {'path': str(path), 'sha256': digest, 'bytes': len(raw)}
    source, result = docs['printed-pool.json'], docs['RESULT.json']
    assert docs['STATUS.json']['status'] == result['status'] == 'completed'
    assert result['actual_source_properties_checked'] is True
    assert result['request']['temperature_k'] == 800 and result['request']['pressure_pa'] == 100000
    actual = result['initial']['loaded_definition']['gas_atomic_weights_kg_kmol']
    assert actual == result['final']['loaded_definition']['gas_atomic_weights_kg_kmol']
    weights = {e: Fraction.from_float(actual[e]) for e in ELEMENTS}
    masses = {e: fraction(source['nominal_CHONS_kg'][e]) for e in ELEMENTS}
    b = {e: 1000 * masses[e] / weights[e] for e in ELEMENTS}
    assert sum(masses.values(), Fraction()) == Fraction('0.704')
    assert tuple(b.values()) == tuple(map(fraction, result['request']['element_mol']))
    assert tuple(b.values()) == tuple(map(fraction, docs['INPUT.json']['derivation']['element_mol']))
    demand = b['C'] + b['H'] / 4 + b['S'] - b['O'] / 2
    assert demand > 0
    carrier_ratio = Fraction(79, 21)
    rows = []
    for lam in (Fraction(0), Fraction(1, 4), Fraction(1)):
        oxygen, nitrogen = lam * demand, carrier_ratio * lam * demand
        increments = {'C': Fraction(0), 'H': Fraction(0), 'O': 2 * oxygen,
                      'N': 2 * nitrogen, 'S': Fraction(0)}
        total = {e: b[e] + increments[e] for e in ELEMENTS}
        added_mass = (2 * oxygen * weights['O'] + 2 * nitrogen * weights['N']) / 1000
        input_mass = Fraction('0.704') + added_mass
        assert sum(total[e] * weights[e] / 1000 for e in ELEMENTS) == input_mass
        if lam:
            assert oxygen / (oxygen + nitrogen) == Fraction(21, 100)
        tolerance_mass = sum(weights[e] * Fraction(1, 10**10) * (1 + total[e]) / 1000
                             for e in ELEMENTS)
        rows.append({'lambda': lam, 'execution': 'reuse saved baseline' if lam == 0 else 'proposed; not run',
                     'added_O2_mol': oxygen, 'added_N2_mol': nitrogen,
                     'added_O2_mass_kg': 2 * oxygen * weights['O'] / 1000,
                     'added_N2_mass_kg': 2 * nitrogen * weights['N'] / 1000,
                     'element_increment_mol': increments, 'total_element_mol': total,
                     'added_gas_mass_kg': added_mass, 'model_input_mass_kg': input_mass,
                     'oxygen_atom_deficit_to_reference_products_mol': 2 * (1 - lam) * demand,
                     'nominal_mass_bound_from_original_element_tolerances_kg': tolerance_mass})
    reference = {'CO2': b['C'], 'H2O': b['H'] / 2, 'SO2': b['S'],
                 'N2': b['N'] / 2 + carrier_ratio * demand}
    reference_atoms = {'C': reference['CO2'], 'H': 2 * reference['H2O'],
                       'O': 2 * reference['CO2'] + reference['H2O'] + 2 * reference['SO2'],
                       'N': 2 * reference['N2'], 'S': reference['SO2']}
    assert reference_atoms == rows[2]['total_element_mol']
    return {'scope': 'independent exact material arithmetic; no new equilibrium, property, or experiment',
            'basis': source['basis'], 'excluded_and_unidentified': source['excluded_and_unidentified'],
            'evidence': evidence, 'actual_saved_atomic_weights_kg_kmol': actual,
            'exact_binary64_atomic_weights_kg_kmol': weights, 'base_masses_kg': masses,
            'base_element_mol': b, 'reference_O2_demand_mol': demand,
            'reference_demand_meaning': 'CO2/H2O/SO2/N2 counterfactual atom balance, not actual process oxygen demand',
            'selected_dry_gas_mole_fractions': {'O2': Fraction(21, 100), 'N2': Fraction(79, 100)},
            'cases': rows, 'lambda1_reference_product_mol_NOT_equilibrium': reference,
            'lambda0_saved_graphite_carbon_mass_kg': fraction(docs['OBSERVABLES.json']['graphite_carbon_mass_kg']),
            'nominal_material_balance_identities_passed': True,
            'uncertainty_of_reference_demand_and_additions': None,
            'source_TP_or_Cantera_calls_this_script': 0}


if __name__ == '__main__':
    result = calculate()
    with (WORK / 'MATERIAL_ARITHMETIC.json').open('x', encoding='utf-8') as stream:
        json.dump(encode(result), stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': 'passed', 'cases': 3, 'new_equilibrium_calls': 0,
                      'output': str(WORK / 'MATERIAL_ARITHMETIC.json')}))
