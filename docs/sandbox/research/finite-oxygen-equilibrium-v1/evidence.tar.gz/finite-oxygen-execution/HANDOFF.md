# 作者交接：有限加氧两点薄驱动

已完成但未执行任何新物性调用。只写本 scratch 下 `run_finite_oxygen.py`、`PLAN.md` 和作者测试/证据；ROOT 的 `launch.py` 未改。仓库 `git diff -- '*.py'` 与 `git status --short` 均为空。

入口为独立安装 runtime 的 Python `-I run_finite_oxygen.py`，由 ROOT 的既有监督器启动。脚本无命令行可调物理参数，输出固定新目录 `native01`，存在则拒绝。新点仅 λ=1/4、1，各原池独立一次；λ=0 复用 pinned Cedrone 保存数据。实际 source/module/provider、原全部门、10/30/40+5 s 预算和仅首点同次 profiling 详见 PLAN。

有限 API：`load_inputs(out)` 读取/保存固定证据；`case_input(context, lambda)` 从原池算本点精确分子、元素和质量；`observables(record, case, context)` 核原门、源/请求/实际库存对应及质量恒等式；`main()` 串行调用、立即保存原返回、处理失败和三行比较。`load_runtime` 是测试唯一替换的运行时边界，生产路径必须匹配旧非 editable 安装及模块 SHA。

验证全部为 stdlib saved-data / manufactured：

- `author-tests/GREEN01.log/xml`：3 passed，0.04 s。精确加料对冻结独立算术、原基线 19 物种质量账、新加气请求拒绝冒用旧结果。
- `author-tests/EDGE_RED01.log/xml`：1 failed / 2 passed，0.08 s。profile 写失败时原行误标 completed；保留该实际失败。
- `author-tests/EDGE_GREEN01.log/xml`：3 passed / 3 deselected，0.07 s。修正返回未验收状态后，完整失败返回、profile 写失败、返回后 driver 超时均保留原 RESULT 并停止下一点。
- `author-tests/DISPATCH_GREEN01.log/xml`：2 passed / 5 deselected，0.07 s。首次失败路径确实保存 stdlib profile；另用解析 element_basis 制造库存检查仅两个独立 pool、原 VCS 参数透传、三行完整 19 物种输出和仅第一点 profile。测试不把这个制造库存称平衡解。
- `author-tests/STATIC01.log`：源码/测试 AST 通过，未导入实际 TP。ruff/mypy/pylint/black 在当前作者环境不可用，没有为此安装工具。
- 初始缺文件 `RED01.log` 保留，不把该 collection 失败计入物理行为反例。

当前冻结见 `AUTHOR_SHA01.json`：driver `bd96aee27773b4b6d7ef72dc280f6b4c87729703f531d81e04d1463f87f47276`；PLAN `6389965b3df33441c6d3dd42bd4426ccbd8d86a4978e6f24e9be7a7261eecdd0`。7 个不同作者用例已在上述有界分组中通过；没有为冻结重复整套测试、基线、实际 EOS 或求解。

请 ROOT 安排另一审查者核这两个文件与自己拥有的 launcher，再决定唯一新增两点受监督执行。profile 只能在既定首点中采集；尚无实际 profile 性能结论，也没有材料、排放、char、热耗或完整 Goal 完成资格。

## 独审后的最小修正（SHA02，取代上列 SHA01 候选）

独审在 RESULT 首次写入抛 OSError 的制造路径记录了实际 RED：已调用一次却仍标 not_run。现每点调用前将行持久化为 about_to_call，成功保存 RESULT 后才成为 returned_unchecked。原候选完整保存在 author-tests/candidate01/，原独审 RED 未覆盖。

仅复跑受影响 review/test_result_write_failure.py：author-tests/RESULT_WRITE_GREEN01.log/xml 实际 1 passed，0.03 s；没有其他测试重跑或 EOS。新 driver SHA 596a8d52b08c415c944018339c44cb38eabe1fc8becab8160a730190fe9f24f4；PLAN SHA 4fdb331339e201448bb94bf14b5bcf6ea11dd140931ba038ff4b44d2023e109b。原物理、计数、profiling 与预算保持。
