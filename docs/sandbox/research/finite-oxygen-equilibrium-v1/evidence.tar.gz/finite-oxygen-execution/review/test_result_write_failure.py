"""One non-EOS probe: the solve returned, but its initial output write failed."""
import importlib.util
import json
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

SCRIPT=Path('/private/tmp/sludge-tp-equilibrium-v1/finite-oxygen-execution/run_finite_oxygen.py')
spec=importlib.util.spec_from_file_location('finite_review',SCRIPT)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

@dataclass
class Pool:
    temperature_k: float
    pressure_pa: float
    element_mol: tuple
    basis_id: str
    classification: str
    source_ids: tuple


def test_result_write_failure_does_not_label_attempt_as_not_run(monkeypatch,tmp_path):
    evidence=tmp_path/'baseline';evidence.mkdir()
    context=m.load_inputs(evidence)
    calls=[]
    class Policy:
        def __init__(self,**kwargs):pass
        def definition(self):return context['baseline']['policy']
    def solve(*args,**kwargs):
        calls.append((args,kwargs))
        return {'status':'postcheck_failed','failure':{'reason':'manufactured_returned_result'}}
    monkeypatch.setattr(m,'OUT',tmp_path/'run')
    monkeypatch.setattr(m,'load_runtime',lambda _:SimpleNamespace(TPPool=Pool,TPPolicy=Policy,solve_tp=solve))
    original=m.save
    def save(path,value,**kwargs):
        if path.name=='RESULT.json' and path.parent.name=='point01':
            raise OSError('manufactured_result_write_failure')
        return original(path,value,**kwargs)
    monkeypatch.setattr(m,'save',save)
    assert m.main()==1
    status=json.loads((m.OUT/'STATUS.json').read_text())
    comparison=json.loads((m.OUT/'COMPARISON.json').read_text())
    assert len(calls)==status['new_solve_attempts']==1
    assert status['failure']['reason']=='manufactured_result_write_failure'
    assert comparison['rows'][2]['status']=='not_run'
    assert comparison['rows'][1]['status']!='not_run',comparison['rows'][1]
