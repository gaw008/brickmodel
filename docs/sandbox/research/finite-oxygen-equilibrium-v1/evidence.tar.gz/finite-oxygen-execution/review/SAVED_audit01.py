"""Finite two-point saved audit. No model imports, EOS, native calls or profiling."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,math,re
W=Path('/private/tmp/sludge-tp-equilibrium-v1');D=W/'finite-oxygen-execution';O=D/'native01';ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
def hook(d):return F(d['numerator'],d['denominator']) if set(d)=={'numerator','denominator'} and all(type(x)is int for x in d.values()) else d
def read(p):return json.loads(p.read_text(),object_hook=hook)
def sha(p):return sha256(p.read_bytes()).hexdigest()
def norm(d):return {k:v['sha256'] if isinstance(v,dict) else v for k,v in d.items()}
def wire(v):
 if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
 if isinstance(v,dict):return {k:wire(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [wire(x) for x in v]
 return v
checks=[]
def check(k,v):checks.append({'name':k,'passed':bool(v)})
comp=read(O/'COMPARISON.json');status=read(O/'STATUS.json');baseline=read(O/'inputs/RESULT.json');source=read(O/'inputs/printed-pool.json');base_input=read(O/'inputs/INPUT.json');base_obs=read(O/'inputs/OBSERVABLES.json')
E=['C','H','O','N','S'];Aw=baseline['initial']['loaded_definition']['gas_atomic_weights_kg_kmol'];weights={e:F(Aw[e]) for e in E};mass={e:F(source['printed_values'][e]['printed_wt_percent'])/100 for e in E};base=[1000*mass[e]/weights[e] for e in E];demand=base[0]+base[1]/4+base[4]-base[2]/2
check('exact_original_pool_mass_weights',sum(mass.values(),F())==F('.704') and base==baseline['request']['element_mol']==base_input['derivation']['element_mol'] and weights==base_input['derivation']['atomic_weights_exact_binary64'])
check('three_rows_two_new_calls_no_baseline_rerun',comp['status']==status['status']=='completed' and comp['new_solve_attempts']==status['new_solve_attempts']==2 and status['attempt_count_final'] and [r['lambda'] for r in comp['rows']]==[F(),F(1,4),F(1)] and [r['reused'] for r in comp['rows']]==[True,False,False] and all(r['status']=='completed' for r in comp['rows']) and sorted(p.name for p in O.glob('point*'))==['point01','point02'])
check('baseline_four_original_streams_reused',all(sha(O/'inputs'/n)==sha(W/'cedrone-execution/native01'/n) for n in ['INPUT.json','RESULT.json','OBSERVABLES.json','STATUS.json']) and comp['rows'][0]['result_file']=='inputs/RESULT.json')
check('all_fixed_input_evidence_copied_unchanged',all(sha(O/'inputs'/name)==sha(Path(v['path']))==v['sha256'] and (O/'inputs'/name).stat().st_size==v['bytes'] for name,v in comp['source_evidence'].items()))
loaded=baseline['initial']['loaded_definition'];names=[s['name'] for s in loaded['species']];atoms=[[int(s['composition'].get(e,0)) for e in E] for s in loaded['species']]
ref=read(W/'source-reference/REFERENCE.json');check('reference_identity',sha(W/'source-reference/REFERENCE.json')=='388caee3d17027f64a4ced9bef56d3bb50760daaf28bf4e5d29d928e70c3047d' and [x['species'] for x in ref['records']]==names)
points=[];properties=[]
for index,row in enumerate(comp['rows']):
 lam=row['lambda'];oxygen=lam*demand;nitrogen=F(79,21)*oxygen;delta=[F(),F(),2*oxygen,2*nitrogen,F()];b=[v+x for v,x in zip(base,delta)];added=sum((weights[e]*delta[j] for j,e in enumerate(E)),F())/1000;Min=F('.704')+added
 if index:
  folder=O/f'point{index:02d}';inp=read(folder/'INPUT.json');r=read(folder/'RESULT.json');obs=read(folder/'OBSERVABLES.json');case=inp['case'];tag=f'lambda_{lam}'
  check(tag+'_exact_independent_original_pool_addition',case['base_element_mol']==base and case['reference_O2_demand_mol']==demand and case['lambda']==lam and case['element_increment_mol']==delta and case['total_element_mol']==b and case['added_O2_mol']==oxygen and case['added_N2_mol']==nitrogen and case['added_gas_mass_kg']==added and case['added_O2_mass_kg']==2*oxygen*weights['O']/1000 and case['added_N2_mass_kg']==2*nitrogen*weights['N']/1000 and case['model_input_mass_kg']==Min and case['actual_atomic_weights']==weights)
  check(tag+'_request_and_policy_sourceIDs',inp['pool']==r['request'] and r['request']['element_mol']==b and r['request']['source_ids']==baseline['request']['source_ids']+[f'virtual_design:finite_O2_N2_21_79_lambda_{lam}'] and r['request']['basis_id']==baseline['request']['basis_id'] and case['original_reported_sample_basis_kg']==1 and case['addition_classification']=='virtual_design_choice' and inp['policy']==r['policy']==baseline['policy'])
  check(tag+'_status_and_single_call_budget',r['status']==row['module_status']=='completed' and r['failure'] is None and r['provider_calls_attempted']==r['provider_calls_completed']==3 and r['elapsed_seconds']<10 and row['solve_elapsed_s']>=r['elapsed_seconds'] and inp['profile_this_solve']==row['profiled']==(index==1) and inp['seed_variant']==r['seed']['variant']=='element_basis')
 else:r=baseline;obs=row['observables'];tag='lambda_0_reused'
 diag=r['diagnostics'];obs_comp=row['observables'];check(tag+'_comparison_full_output',obs==obs_comp)
 check(tag+'_physical_and_source_binding',r['request']['temperature_k']==800 and r['request']['pressure_pa']==100000 and r['provenance']==baseline['provenance'] and r['provider_identity']==baseline['provider_identity'] and r['initial']['loaded_definition']==r['final']['loaded_definition']==loaded and r['actual_source_properties_checked'] and all(diag['checks'].values()))
 inv={};G={};mu={};eres=[]
 for label in ['initial','final']:
  s=r[label];n=[F(x)*1000 for x in s['amounts_kmol']];bout=[sum((n[j]*atoms[j][e] for j in range(19)),F()) for e in range(5)];res=[x-y for x,y in zip(bout,b)];inv[label]=(n,bout,res)
  check(tag+'_'+label+'_inventory_TP_element_gates',len(n)==19 and all(math.isfinite(x) and x>=0 for x in s['amounts_kmol']) and s['temperature_k']==800 and s['pressure_pa']==100000 and all(abs(x)<=F(1,10**10)*(1+abs(be)) for x,be in zip(res,b)))
  eres.extend({'state':label,'element':e,'residual_mol':x,'original_gate_mol':F(1,10**10)*(1+abs(be))} for e,x,be in zip(E,res,b))
  rt=s['gas_constant_j_mol_k']*800;Ng=sum(n[:18],F());mu[label]=[s['standard_g_j_mol'][j]+rt*(math.log(n[j])-math.log(Ng)) if n[j] else None for j in range(18)]+[s['standard_g_j_mol'][18]];G[label]=sum((a*F(v) for a,v in zip(n,mu[label]) if a),F())
  if index:
   for j,sp in enumerate(ref['records']):
    p=next(v for v in sp['points'] if v['temperature_k']==800)
    for key,rkey,tflag in [('standard_cp_j_mol_k','cp_over_R',False),('standard_h_j_mol','h_over_RT',True),('standard_s_j_mol_k','s_over_R',False),('standard_g_j_mol','g_over_RT',True)]:
     expected=float(p['binary64_coefficients'][rkey]['decimal_90_digits']);actual=s[key][j]/(s['gas_constant_j_mol_k']*(800 if tflag else 1));error=actual-expected;limit=2e-10+5e-12*abs(expected)
     properties.append({'lambda':lam,'state':label,'species':sp['species'],'property':rkey,'difference':error,'original_tolerance':limit,'passed':math.isfinite(error) and abs(error)<=limit})
 n,bout,res=inv['final'];B=sum(bout,F());rt=r['final']['gas_constant_j_mol_k']*800
 check(tag+'_exact_saved_inventory_and_G',n==diag['amounts_mol'] and bout==diag['elements_mol'] and res==diag['element_residual_mol'] and mu['final']==diag['chemical_potentials_j_mol'] and G['final']==diag['gibbs_j'] and G['initial']==diag['seed_gibbs_j'])
 lam_e=diag['element_potentials_j_mol_atoms'];imp=[math.fsum(a*v for a,v in zip(at,lam_e)) for at in atoms];std=r['final']['standard_g_j_mol'];logs=[(imp[j]-std[j])/rt for j in range(18)];mx=max(logs);lz=mx+math.log(math.fsum(math.exp(v-mx) for v in logs));dc=(std[18]-lam_e[0])/rt;penalty=F(rt)*F(max(0.,lz,-dc));L=sum((F(v)*x for v,x in zip(lam_e,bout)),F())-penalty*B;Lreq=sum((F(v)*x for v,x in zip(lam_e,b)),F())-penalty*sum(b,F());gap=G['final']-L;greq=G['final']-Lreq;correction=sum((F(v)*x for v,x in zip(lam_e,res)),F())-penalty*sum(res,F())
 check(tag+'_partition_same_and_requested_pool_G',all(diag['structurally_admitted']) and lz==diag['log_partition_sum'] and gap==diag['gap_out_j'] and greq==diag['gap_requested_j'] and greq-gap==correction==diag['requested_pool_gap_correction_j'] and gap/(F(rt)*B)==diag['scaled_gap_out'] and -F(1,10**10)<=gap/(F(rt)*B)<=F(1,10**7))
 active=[j for j in range(19) if n[j]>B*F(1,10**12)];ar=[(mu['final'][j]-imp[j])/rt for j in active]
 check(tag+'_active_mu_carbon_Gdescent_original_gates',ar==diag['active_residuals_over_RT'] and max(map(abs,ar))<=1e-7 and (abs(dc)<=1e-7 if 18 in active else dc>=-1e-7) and G['final']<=G['initial']+F(rt)*B*F(1,10**7))
 masses=[n[j]*sum((atoms[j][i]*weights[e] for i,e in enumerate(E)),F())/1000 for j in range(19)];Mout=sum(masses,F());mres=Mout-Min;weighted=sum((weights[e]*x for e,x in zip(E,res)),F())/1000;triangle=sum((weights[e]*abs(x) for e,x in zip(E,res)),F())/1000;bound=sum((weights[e]*F(1,10**10)*(1+abs(be)) for e,be in zip(E,b)),F())/1000
 check(tag+'_all_19_species_gas_and_mass_readouts',len(obs['species'])==19 and all(v['name']==names[j] and v['amount_mol']==n[j] and v['model_mass_kg']==masses[j] and (v['gas_mole_fraction']==n[j]/sum(n[:18],F()) if j<18 else v['gas_mole_fraction'] is None) for j,v in enumerate(obs['species'])) and obs['model_input_mass_kg']==Min and obs['model_output_mass_kg']==Mout)
 check(tag+'_mass_identity_and_original_propagated_bounds',obs['mass_audit']=={'residual_kg':mres,'weighted_element_residual_kg':weighted,'actual_residual_triangle_bound_kg':triangle,'original_element_tolerance_bound_kg':bound} and mres==weighted and abs(mres)<=triangle<=bound)
 check(tag+'_carbon_fraction_no_normalization',obs['graphite_carbon_mol']==n[18] and obs['graphite_carbon_mass_kg']==masses[18] and obs['graphite_carbon_fraction']==n[18]/base[0] and obs['gas_total_mol']==sum(n[:18],F()) and obs['element_residual_mol']==dict(zip(E,res)))
 check(tag+'_material_unknown',r['material_qualified'] is False and r['training_eligible'] is False and 'not char yield' in obs['qualification'])
 points.append({'lambda':lam,'reused':index==0,'model_input_mass_kg':float(Min),'added_O2_mol':float(oxygen),'added_N2_mol':float(nitrogen),'graphite_carbon_mol':float(n[18]),'graphite_carbon_kg':float(masses[18]),'graphite_carbon_fraction':float(n[18]/base[0]),'mass_residual_kg':float(mres),'original_mass_bound_kg':float(bound),'scaled_gap':float(gap/(F(rt)*B)),'elements':eres,'elapsed_s':row.get('solve_elapsed_s')})
check('all_304_new_standard_properties',len(properties)==304 and all(v['passed'] for v in properties))
meta=read(D/'supervised-native01/metadata.json');sup=read(D/'supervised-native01/status.json');before=norm(meta['inputs_before']);after=norm(sup['inputs_after'])
check('supervision_all_before_after_current_inputs',before==after and sup['inputs_unchanged'] and all(Path(p).is_file() and sha(Path(p))==h for p,h in before.items()))
check('final_reviewed_driver_launcher_core',before[str(D/'run_finite_oxygen.py')]=='596a8d52b08c415c944018339c44cb38eabe1fc8becab8160a730190fe9f24f4' and before[str(D/'launch.py')]=='38962a24c3a36fb96c4cd7e4e71f5e66683b1dadc975dde4c3f334192284db6b' and before[str(ROOT/'src/sludge_sandbox/tp_equilibrium.py')]=='da382eead7211e5a91a1630fbe30a75a8c7feca9cb1af6814398c57f8914849c')
check('original_budgets_complete_and_reaped',status['elapsed_before_final_save_s']<status['driver_budget_s']==30 and status['module_budget_s']==10 and meta['timeout_s']==40 and meta['cleanup_grace_s']==5 and sup['status']=='complete' and sup['returncode']==0 and sup['cleanup']['leader_reaped'] and sup['elapsed_s']<40)
profile=(O/'point01/first_solve_profile.txt').read_text();profile_rows={}
for line in profile.splitlines():
 m=re.match(r'\s*(\d+)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+.*tp_equilibrium.py:\d+\(([^)]+)\)',line)
 if m:profile_rows[m[6]]={'calls':int(m[1]),'self_s_rounded':float(m[2]),'cumulative_s_rounded':float(m[4])}
check('one_profile_on_actual_first_solve_only',comp['rows'][1]['profile_saved'] and (O/'point01/first_solve.prof').stat().st_size>0 and not (O/'point02/first_solve.prof').exists() and profile_rows['solve_tp']['calls']==1 and profile_rows['prepare']['calls']==1 and abs(profile_rows['solve_tp']['cumulative_s_rounded']-comp['rows'][1]['solve_elapsed_s'])<.001)
check('scope_and_exclusions',comp['material_qualified'] is False and comp['training_eligible'] is False and comp['excluded_and_unidentified']==source['excluded_and_unidentified'])
old=read(W/'review/VCS_FINAL_READ01.json')['files'];check('old_Gibbs_failure_preserved',all(sha(Path(p))==v['sha256'] for p,v in old.items() if '/root-execution/native01/' in p or '/root-execution/supervised-native01/' in p))
output={'verdict':'PASS' if all(v['passed'] for v in checks) else 'FAIL','checks':checks,'points':points,'new_standard_property_checks':properties,'max_standard_property_abs_difference':max(abs(v['difference']) for v in properties),'profile_text_rows':profile_rows,'driver_elapsed_s':status['elapsed_before_final_save_s'],'supervisor_elapsed_s':sup['elapsed_s'],'supervision_input_count':len(before),'eos_or_native_calls_by_audit':0,'material_qualified':False,'training_eligible':False}
with (D/'review/SAVED_AUDIT01.json').open('x') as f:json.dump(wire(output),f,indent=2,allow_nan=False)
print(output['verdict'],len(checks),'groups',len(properties),'property comparisons',len(before),'inputs')
for p in points:print({k:v for k,v in p.items() if k!='elements'})
print('profile',profile_rows);print('failed',[v for v in checks if not v['passed']])
raise SystemExit(0 if output['verdict']=='PASS' else 1)
