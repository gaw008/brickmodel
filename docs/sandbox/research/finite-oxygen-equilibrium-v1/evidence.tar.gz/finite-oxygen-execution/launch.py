"""Run the two new finite-oxygen points once under the existing supervisor."""
import importlib.util
import json
from pathlib import Path

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK = Path(__file__).resolve().parent
RUNTIME = WORK.parent / 'runtime'
PYTHON = RUNTIME / 'bin/python'
SUPERVISOR = ROOT / 'docs/sandbox/research/research-process-supervisor/supervisor.py'
inputs = [ROOT / 'pyproject.toml', ROOT / 'uv.lock',
          ROOT / 'src/sludge_sandbox/tp_equilibrium.py',
          ROOT / 'tests/sandbox/test_tp_equilibrium.py',
          WORK / 'PLAN.md', WORK / 'run_finite_oxygen.py', Path(__file__).resolve(),
          SUPERVISOR, PYTHON.resolve(strict=True)]
for folder in (ROOT / 'data/sandbox/research/tp-equilibrium-v1',
               RUNTIME / 'lib/python3.12/site-packages/sludge_sandbox',
               RUNTIME / 'lib/python3.12/site-packages/cantera',
               RUNTIME / 'lib/python3.12/site-packages/numpy',
               RUNTIME / 'lib/python3.12/site-packages/numpy.libs'):
    if folder.is_dir():
        inputs.extend(p for p in sorted(folder.rglob('*')) if p.is_file() and p.suffix != '.pyc')
for name in ('native01', 'supervised-native01'):
    if (WORK / name).exists() or (WORK / name).is_symlink():
        raise FileExistsError('refuse_repeat_attempt:' + name)
inputs.append(ROOT / 'data/sandbox/research/cedrone2024-element-pool-v1/printed-pool.json')
design = WORK.parent / 'finite-oxygen-design'
inputs.extend(design / name for name in ('DESIGN.md', 'material_arithmetic.py',
                                        'MATERIAL_ARITHMETIC.json', 'ROOT_REVIEW.md'))
prior = WORK.parent / 'cedrone-execution'
inputs.extend(prior / 'native01' / name for name in
              ('INPUT.json', 'RESULT.json', 'OBSERVABLES.json', 'STATUS.json'))
inputs.extend(prior / 'supervised-native01' / name for name in ('metadata.json', 'status.json'))
spec = importlib.util.spec_from_file_location('tp_supervisor', SUPERVISOR)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result = module.run_attempt(WORK / 'supervised-native01',
    ['/usr/bin/env', '-u', 'PYTHONPATH', str(PYTHON), '-I', str(WORK / 'run_finite_oxygen.py')],
    cwd='/private/tmp', input_paths=inputs, timeout_s=40., cleanup_grace_s=5.)
print(json.dumps({k: v for k, v in result.items() if not k.startswith('inputs_')}, indent=2))
raise SystemExit(0 if result['status'] == 'complete' and result['returncode'] == 0
                 and result['inputs_unchanged'] is True else 1)
