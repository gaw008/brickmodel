"""Author manufactured/saved-data checks; no EOS or native solves."""
import importlib.util
import copy
from dataclasses import dataclass
from fractions import Fraction as F
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

SCRIPT=Path(__file__).resolve().parents[1]/'run_finite_oxygen.py'
spec=importlib.util.spec_from_file_location('finite_oxygen',SCRIPT)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


@pytest.fixture
def context(tmp_path):
    return module.load_inputs(tmp_path)


def test_additions_start_from_original_pool_and_match_frozen_arithmetic(context):
    quarter=module.case_input(context,F(1,4))
    one=module.case_input(context,F(1))
    assert one['added_O2_mol']==4*quarter['added_O2_mol']
    assert one['added_N2_mol']==4*quarter['added_N2_mol']
    assert quarter['added_N2_mol']/quarter['added_O2_mol']==F(79,21)
    for case in (quarter,one):
        assert case['model_input_mass_kg']==F('.704')+case['added_gas_mass_kg']
        assert case['model_input_mass_kg']>F('.704')
        assert case['total_element_mol'][0]==context['base_element_mol'][0]
        assert case['total_element_mol'][2]==context['base_element_mol'][2]+2*case['added_O2_mol']


def test_reused_baseline_observables_keep_full_mass_and_carbon_account(context):
    case=module.case_input(context,F())
    out=module.observables(context['baseline'],case,context)
    assert len(out['species'])==19
    assert out['model_input_mass_kg']==F('.704')
    assert out['graphite_carbon_fraction']==out['graphite_carbon_mol']/context['base_element_mol'][0]
    audit=out['mass_audit']
    assert audit['residual_kg']==audit['weighted_element_residual_kg']


def test_added_case_cannot_be_compared_with_unmodified_baseline_inventory(context):
    case=module.case_input(context,F(1,4))
    with pytest.raises(ValueError): module.observables(context['baseline'],case,context)


@dataclass
class FakePool:
    temperature_k: float
    pressure_pa: float
    element_mol: tuple
    basis_id: str
    classification: str
    source_ids: tuple


def fake_run(monkeypatch,tmp_path,context,result):
    """Inject only the runtime boundary; fixture records are not physical solves."""
    calls=[]
    class FakePolicy:
        def __init__(self,**kwargs): self.arguments=kwargs
        def definition(self): return context['baseline']['policy']
    def solve(pool,root,**kwargs):
        calls.append((pool,kwargs))
        return result
    runtime=SimpleNamespace(TPPool=FakePool,TPPolicy=FakePolicy,solve_tp=solve)
    monkeypatch.setattr(module,'OUT',tmp_path/'run')
    monkeypatch.setattr(module,'load_runtime',lambda ctx: runtime)
    return calls


def test_first_returned_failure_is_saved_and_second_is_not_called(monkeypatch,tmp_path,context):
    result={'status':'postcheck_failed','failure':{'reason':'manufactured_nonconvergence'},
            'last_completed_snapshot':{'actual_returned_vector':[1.,2.]}}
    calls=fake_run(monkeypatch,tmp_path,context,result)
    assert module.main()==1
    assert len(calls)==1
    assert json.loads((module.OUT/'point01/RESULT.json').read_text())==result
    comparison=json.loads((module.OUT/'COMPARISON.json').read_text())
    assert comparison['rows'][0]['reused'] is True
    assert comparison['rows'][2]['status']=='not_run'
    assert not (module.OUT/'point02').exists()
    assert json.loads((module.OUT/'STATUS.json').read_text())['new_solve_attempts']==1
    assert (module.OUT/'point01/first_solve.prof').stat().st_size>0
    assert 'solve' in (module.OUT/'point01/first_solve_profile.txt').read_text()


def test_profile_save_failure_preserves_returned_result_without_accepting_row(monkeypatch,tmp_path,context):
    result=copy.deepcopy(context['baseline'])
    calls=fake_run(monkeypatch,tmp_path,context,result)
    def fail_profile(*args): raise OSError('manufactured_profile_write_failure')
    monkeypatch.setattr(module,'save_profile',fail_profile)
    assert module.main()==1
    assert len(calls)==1
    assert json.loads((module.OUT/'point01/RESULT.json').read_text())==result
    comparison=json.loads((module.OUT/'COMPARISON.json').read_text())
    assert comparison['status']=='failed'
    assert comparison['rows'][1]['status']=='returned_unchecked'
    assert comparison['rows'][1]['module_status']=='completed'
    assert comparison['rows'][2]['status']=='not_run'
    assert json.loads((module.OUT/'STATUS.json').read_text())['failure']['reason']=='manufactured_profile_write_failure'


def test_returned_numeric_timeout_preserves_result_and_stops(monkeypatch,tmp_path,context):
    result={'status':'resource_limit','failure':{'reason':'manufactured_native_elapsed'},
            'last_completed_snapshot':{'actual_returned_vector':[3.,4.]}}
    calls=fake_run(monkeypatch,tmp_path,context,result)
    now=[0.]
    monkeypatch.setattr(module.time,'monotonic',lambda:now[0])
    runtime=module.load_runtime(context)
    original=runtime.solve_tp
    def timed_return(*args,**kwargs):
        returned=original(*args,**kwargs)
        now[0]=31.
        return returned
    runtime.solve_tp=timed_return
    assert module.main()==1
    assert len(calls)==1
    assert json.loads((module.OUT/'point01/RESULT.json').read_text())==result
    assert json.loads((module.OUT/'STATUS.json').read_text())['status']=='resource_limit'
    assert json.loads((module.OUT/'COMPARISON.json').read_text())['rows'][2]['status']=='not_run'


def test_two_fake_element_feasible_returns_keep_three_rows_and_profile_only_first(monkeypatch,tmp_path,context):
    """Analytic element_basis inventory exercises dispatch/accounting, not equilibrium."""
    calls=fake_run(monkeypatch,tmp_path,context,{})
    runtime=module.load_runtime(context)
    def solve(pool,root,**kwargs):
        calls.append((pool,kwargs))
        b=pool.element_mol
        n=[F() for _ in module.SPECIES]
        for i,v in ((0,b[1]/2),(5,b[2]/2),(6,b[3]/2),(17,b[4]/2),(18,b[0])):
            n[i]=v
        record=copy.deepcopy(context['baseline'])
        record['request']=module.json_value(pool)
        raw=[float(v/1000) for v in n]
        actual=[F(v)*1000 for v in raw]
        b_out=(actual[18],2*actual[0],2*actual[5],2*actual[6],2*actual[17])
        record['final']['amounts_kmol']=raw
        record['diagnostics']['amounts_mol']=module.json_value(actual)
        record['diagnostics']['element_residual_mol']=module.json_value(tuple(a-v for a,v in zip(b_out,b)))
        return record
    runtime.solve_tp=solve
    assert module.main()==0
    assert len(calls)==2 and calls[0][0] is not calls[1][0]
    for (pool,kwargs),lam in zip(calls,(F(1,4),F(1))):
        assert pool.element_mol==module.case_input(context,lam)['total_element_mol']
        assert kwargs['seed_variant']=='element_basis'
        assert kwargs['policy'].arguments=={'solver':'vcs','rtol':1e-10,'max_steps':1000,'maximum_elapsed_s':10.}
    comparison=json.loads((module.OUT/'COMPARISON.json').read_text())
    assert comparison['status']=='completed' and len(comparison['rows'])==3
    assert [r['reused'] for r in comparison['rows']]==[True,False,False]
    assert all(len(r['observables']['species'])==19 for r in comparison['rows'])
    assert (module.OUT/'point01/first_solve.prof').exists()
    assert not (module.OUT/'point02/first_solve.prof').exists()
