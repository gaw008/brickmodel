"""Two explicit finite O2/N2 TP points; reuse the accepted lambda-zero bytes."""
from __future__ import annotations
import cProfile
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from fractions import Fraction as F
import hashlib
import io
import json
import math
import os
from pathlib import Path
import pstats
import time

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK=Path(__file__).resolve().parent
OUT=WORK/'native01'
BASE=WORK.parent/'cedrone-execution/native01'
DESIGN=WORK.parent/'finite-oxygen-design'
RUNTIME=WORK.parent/'runtime'
ELEMENTS=('C','H','O','N','S')
SPECIES=('H2','H2O','CO','CO2','CH4','O2','N2','NH3','HCN','NO','NO2','N2O','H2S','SO2','SO3','COS','CS2','S2','C(gr)')
MODULE_SHA='da382eead7211e5a91a1630fbe30a75a8c7feca9cb1af6814398c57f8914849c'
INPUTS={
 'INPUT.json':(BASE/'INPUT.json','7dae7e3aa78d42fff68b8fe49c0bdc6dd05d7f074f05e2b8b1f4fd2736a3492c'),
 'RESULT.json':(BASE/'RESULT.json','c8f544fe09694ef4bcadde046a98a6c125ab99e9cc1b5e5abb5d4330bb1739f9'),
 'OBSERVABLES.json':(BASE/'OBSERVABLES.json','6179099fc6c9ac33d5b5c167b8c8fc62dfa821797734ebcd794fc464c6472e9f'),
 'STATUS.json':(BASE/'STATUS.json','89ab8f2b77d84154ceb2c346a9a42267da95597b86bed290a433a70c68800edf'),
 'printed-pool.json':(ROOT/'data/sandbox/research/cedrone2024-element-pool-v1/printed-pool.json','92feba43d25479d99a2607466fb902841d0afcffc5b1108ca2ff74a42145f7fd'),
 'MATERIAL_ARITHMETIC.json':(DESIGN/'MATERIAL_ARITHMETIC.json','01f7402ec2e0711e688ce5c44c0529ae94e259a3a5f984ff6c5847cb1b0754db'),
 'DESIGN.md':(DESIGN/'DESIGN.md','19b553dd8782307f0f5f92d031550833e778a1565340e5ec95917332ffc939a6'),
 'material_arithmetic.py':(DESIGN/'material_arithmetic.py','6540427365322ea9c392ff572819c73c4d27191c67f0dca8da9fab124a882ec4'),
 'ROOT_REVIEW.md':(DESIGN/'ROOT_REVIEW.md','027c5a74da074beb4b5d4f602416cc9f2da1787b083f8310e684ce468266328c'),
 'supervisor-metadata.json':(BASE.parent/'supervised-native01/metadata.json','54402b50e82f62c9cb827d2b5406324c71d1d1da3678de4da77f5284fe67dbbb'),
 'supervisor-status.json':(BASE.parent/'supervised-native01/status.json','178bcabf15947d01cb101cb866a2177d88e2c0fc8f2e351f5884e7afec879981'),
 'module-source.py':(ROOT/'src/sludge_sandbox/tp_equilibrium.py',MODULE_SHA),
}


def require(condition: bool, reason: str) -> None:
    if not condition: raise ValueError(reason)


def fraction(value: object) -> F:
    return value if isinstance(value,F) else F(int(value['numerator']),int(value['denominator']))


def json_value(value: object) -> object:
    if is_dataclass(value) and not isinstance(value,type):
        return {f.name:json_value(getattr(value,f.name)) for f in fields(value)}
    if isinstance(value,F): return {'numerator':value.numerator,'denominator':value.denominator}
    if isinstance(value,Mapping): return {str(k):json_value(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [json_value(v) for v in value]
    if isinstance(value,float) and not math.isfinite(value): return {'invalid_computed_float':str(value)}
    if value is None or isinstance(value,(str,bool,int,float)): return value
    raise TypeError('unsupported_record:'+type(value).__name__)


def save(path: Path, value: object, *, new: bool=True) -> None:
    text=json.dumps(json_value(value),indent=2,allow_nan=False)+'\n'
    with path.open('x' if new else 'w',encoding='utf-8') as stream:
        stream.write(text); stream.flush(); os.fsync(stream.fileno())


def guard(started: float) -> None:
    if time.monotonic()-started>30.: raise TimeoutError('driver_budget_30s')


def load_inputs(out: Path) -> dict:
    documents,evidence={},{}
    (out/'inputs').mkdir()
    for label,(path,expected) in INPUTS.items():
        raw=path.read_bytes()
        with (out/'inputs'/label).open('xb') as stream: stream.write(raw)
        digest=hashlib.sha256(raw).hexdigest()
        require(digest==expected,'frozen_input_changed:'+label)
        evidence[label]={'path':str(path),'sha256':digest,'bytes':len(raw)}
        if label.endswith('.json'): documents[label]=json.loads(raw)
    baseline=documents['RESULT.json']; status=documents['supervisor-status.json']
    require(documents['STATUS.json']['status']==baseline['status']=='completed','baseline_not_completed')
    require(status['status']=='complete' and status['returncode']==0 and status['inputs_unchanged'] is True
            and status['cleanup']['leader_reaped'] is True,'baseline_supervision_not_accepted')
    before=documents['supervisor-metadata.json']['inputs_before']; after=status['inputs_after']
    require(set(before)==set(after) and all(v['sha256']==after[p] for p,v in before.items()),'baseline_inputs_changed')
    installed=documents['INPUT.json']['installed_module_path']
    require(before[installed]['sha256']==before[str(ROOT/'src/sludge_sandbox/tp_equilibrium.py')]['sha256']==MODULE_SHA,
            'baseline_module_identity_changed')
    actual=baseline['initial']['loaded_definition']['gas_atomic_weights_kg_kmol']
    require(set(actual)==set(ELEMENTS) and all(type(v) is float and math.isfinite(v) and v>0 for v in actual.values()),'invalid_bound_weights')
    weights={e:F.from_float(actual[e]) for e in ELEMENTS}
    masses={e:fraction(documents['printed-pool.json']['nominal_CHONS_kg'][e]) for e in ELEMENTS}
    b=tuple(1000*masses[e]/weights[e] for e in ELEMENTS)
    require(sum(masses.values(),F())==F('.704'),'base_mass_mismatch')
    require(b==tuple(map(fraction,baseline['request']['element_mol']))
            ==tuple(map(fraction,documents['INPUT.json']['derivation']['element_mol'])),'base_inventory_mismatch')
    context={'baseline':baseline,'documents':documents,'evidence':evidence,'weights':weights,'base_element_mol':b,
             'base_masses_kg':masses,'installed_module_path':installed}
    zero=observables(baseline,case_input(context,F()),context)
    old=documents['OBSERVABLES.json']
    require(all(a['name']==b['name'] and a['amount_mol']==fraction(b['amount_mol'])
                and a['model_mass_kg']==fraction(b['model_mass_kg'])
                for a,b in zip(zero['species'],old['species'],strict=True)),'baseline_observables_mismatch')
    context['baseline_observables']=zero
    return context


def case_input(context: dict, lam: F) -> dict:
    require(lam in (F(),F(1,4),F(1)),'unregistered_lambda')
    b=context['base_element_mol']; weights=context['weights']
    demand=b[0]+b[1]/4+b[4]-b[2]/2
    require(demand>0,'nonpositive_reference_demand')
    oxygen=lam*demand; nitrogen=F(79,21)*oxygen
    delta=(F(),F(),2*oxygen,2*nitrogen,F())
    total=tuple(v+d for v,d in zip(b,delta,strict=True))
    mass=sum((weights[e]*delta[i]/1000 for i,e in enumerate(ELEMENTS)),F())
    expected=next(row for row in context['documents']['MATERIAL_ARITHMETIC.json']['cases'] if fraction(row['lambda'])==lam)
    require(total==tuple(fraction(expected['total_element_mol'][e]) for e in ELEMENTS)
            and mass==fraction(expected['added_gas_mass_kg'])
            and oxygen==fraction(expected['added_O2_mol']) and nitrogen==fraction(expected['added_N2_mol']),
            'independent_arithmetic_mismatch')
    return {'lambda':lam,'reference_O2_demand_mol':demand,'base_element_mol':b,'element_increment_mol':delta,
            'added_O2_mol':oxygen,'added_N2_mol':nitrogen,'added_O2_mass_kg':2*oxygen*weights['O']/1000,
            'added_N2_mass_kg':2*nitrogen*weights['N']/1000,'added_gas_mass_kg':mass,
            'total_element_mol':total,'model_input_mass_kg':F('.704')+mass,'actual_atomic_weights':weights,
            'original_reported_sample_basis_kg':F(1),'basis_id':context['baseline']['request']['basis_id'],
            'source_ids':tuple(context['baseline']['request']['source_ids'])+((f'virtual_design:finite_O2_N2_21_79_lambda_{lam}',) if lam else ()),
            'addition_classification':'virtual_design_choice','material_uncertainty':'unknown'}


def observables(result: dict, case: dict, context: dict) -> dict:
    baseline=context['baseline']
    require(result['status']=='completed' and result['actual_source_properties_checked'] is True
            and all(v is True for v in result['diagnostics']['checks'].values()),'module_result_not_accepted')
    require(result['policy']==baseline['policy'] and result['provider_identity']==baseline['provider_identity']
            and result['provenance']==baseline['provenance'],'provider_policy_or_source_changed')
    loaded=result['final']['loaded_definition']
    require(loaded==result['initial']['loaded_definition']==baseline['initial']['loaded_definition'],'bound_thermochemistry_changed')
    request=result['request']
    require(request['temperature_k']==800 and request['pressure_pa']==100000
            and tuple(map(fraction,request['element_mol']))==case['total_element_mol']
            and request['basis_id']==case['basis_id'] and tuple(request['source_ids'])==case['source_ids'],'request_case_mismatch')
    require(tuple(r['name'] for r in loaded['species'])==SPECIES,'species_order_changed')
    n=tuple(F(v)*1000 for v in result['final']['amounts_kmol'])
    require(len(n)==19 and all(v>=0 for v in n) and n==tuple(map(fraction,result['diagnostics']['amounts_mol'])),'inventory_readback_mismatch')
    atoms=[tuple(F(row['composition'].get(e,0)) for e in ELEMENTS) for row in loaded['species']]
    w=context['weights']
    masses=tuple(n[i]*sum((atoms[i][j]*w[e] for j,e in enumerate(ELEMENTS)),F())/1000 for i in range(19))
    b_out=tuple(sum((n[i]*atoms[i][j] for i in range(19)),F()) for j in range(5))
    residual=tuple(v-b for v,b in zip(b_out,case['total_element_mol'],strict=True))
    require(residual==tuple(map(fraction,result['diagnostics']['element_residual_mol'])),'element_diagnostic_mismatch')
    tolerances=tuple(F(1,10**10)*(1+abs(v)) for v in case['total_element_mol'])
    require(all(abs(r)<=t for r,t in zip(residual,tolerances,strict=True)),'original_element_gate_failed')
    mass_residual=sum(masses,F())-case['model_input_mass_kg']
    weighted=sum((w[e]*residual[j]/1000 for j,e in enumerate(ELEMENTS)),F())
    observed=sum((w[e]*abs(residual[j])/1000 for j,e in enumerate(ELEMENTS)),F())
    bound=sum((w[e]*tolerances[j]/1000 for j,e in enumerate(ELEMENTS)),F())
    require(mass_residual==weighted and abs(weighted)<=observed<=bound,'mass_identity_or_bound_failed')
    gas_total=sum(n[:18],F()); require(gas_total>0,'empty_gas_phase')
    return {'species':[{'name':name,'amount_mol':n[i],'model_mass_kg':masses[i],
                         'gas_mole_fraction':n[i]/gas_total if i<18 else None} for i,name in enumerate(SPECIES)],
            'gas_total_mol':gas_total,'graphite_carbon_mol':n[18],'graphite_carbon_mass_kg':masses[18],
            'graphite_carbon_fraction':n[18]/context['base_element_mol'][0],
            'model_input_mass_kg':case['model_input_mass_kg'],'model_output_mass_kg':sum(masses,F()),
            'element_residual_mol':dict(zip(ELEMENTS,residual,strict=True)),
            'mass_audit':{'residual_kg':mass_residual,'weighted_element_residual_kg':weighted,
                          'actual_residual_triangle_bound_kg':observed,'original_element_tolerance_bound_kg':bound},
            'basis':'absolute mol/kg per original 1kg reported sample; not per kg gas-added mixture',
            'qualification':'conditional restricted TP composition; not char yield, heat release/duty, or actual emissions'}


def load_runtime(context: dict):
    from sludge_sandbox import tp_equilibrium as tp
    path=Path(tp.__file__).resolve()
    require(str(path)==context['installed_module_path'] and path.is_relative_to(RUNTIME.resolve()),'installed_module_location_changed')
    require(hashlib.sha256(path.read_bytes()).hexdigest()==MODULE_SHA,'installed_module_bytes_changed')
    require(tp.ELEMENTS==ELEMENTS and tp.SPECIES==SPECIES
            and tp.MODEL_SHA256==context['baseline']['provenance']['model_sha256'],'installed_physical_model_changed')
    require(json_value(tp.TPPolicy(solver='vcs').definition())==context['baseline']['policy'],'installed_VCS_policy_changed')
    return tp


def save_profile(profiler: cProfile.Profile, folder: Path) -> None:
    require(not (folder/'first_solve.prof').exists(),'profile_already_exists')
    profiler.dump_stats(str(folder/'first_solve.prof'))
    stream=io.StringIO()
    pstats.Stats(profiler,stream=stream).sort_stats('cumulative').print_stats(80)
    with (folder/'first_solve_profile.txt').open('x') as output: output.write(stream.getvalue())


def main() -> int:
    started=time.monotonic(); OUT.mkdir()
    status={'status':'preflight','new_solve_attempts':0,'attempt_count_final':False,'driver_budget_s':30.,
            'module_budget_s':10.,'baseline_reused':True,'profiling':'first added point only; elapsed includes profiler overhead'}
    comparison={'status':'started','rows':[{'lambda':v,'status':'not_run','reused':v==0} for v in (F(),F(1,4),F(1))],
                'basis':'original 1kg reported Cedrone sample','material_qualified':False,'training_eligible':False}
    attempts=0
    save(OUT/'STATUS.json',status)
    try:
        context=load_inputs(OUT)
        comparison['source_evidence']=context['evidence']
        comparison['excluded_and_unidentified']=context['documents']['printed-pool.json']['excluded_and_unidentified']
        comparison['rows'][0].update(status='completed',result_file='inputs/RESULT.json',observables=context['baseline_observables'])
        save(OUT/'COMPARISON.json',comparison)
        guard(started); tp=load_runtime(context); guard(started)
        for index,lam in enumerate((F(1,4),F(1)),1):
            guard(started)
            folder=OUT/f'point{index:02d}'; folder.mkdir()
            case=case_input(context,lam)
            pool=tp.TPPool(800.,100000.,case['total_element_mol'],case['basis_id'],'derived_from_evidence',case['source_ids'])
            policy=tp.TPPolicy(solver='vcs',rtol=1e-10,max_steps=1000,maximum_elapsed_s=10.)
            save(folder/'INPUT.json',{'case':case,'pool':pool,'policy':policy.definition(),'seed_variant':'element_basis',
                                      'source_evidence':context['evidence'],'profile_this_solve':index==1})
            row=comparison['rows'][index]
            row['status']='about_to_call'
            save(OUT/'COMPARISON.json',comparison,new=False)
            status.update(status='about_to_call',lambda_value=lam,new_solve_attempts=attempts,attempt_count_final=False)
            save(OUT/'STATUS.json',status,new=False); guard(started)
            profiler=cProfile.Profile() if index==1 else None
            attempts+=1
            solve_started=time.monotonic()
            if profiler: profiler.enable()
            try: result=tp.solve_tp(pool,ROOT,policy=policy,seed_variant='element_basis')
            finally:
                if profiler: profiler.disable()
            solve_elapsed=time.monotonic()-solve_started
            save(folder/'RESULT.json',result)
            record=json_value(result)
            row.update(status='returned_unchecked',module_status=record['status'],
                       result_file=str(folder.relative_to(OUT)/'RESULT.json'),
                       solve_elapsed_s=solve_elapsed,profiled=index==1)
            save(OUT/'COMPARISON.json',comparison,new=False)
            guard(started)
            if profiler:
                save_profile(profiler,folder)
                row['profile_saved']=True
            guard(started)
            if record['status']=='resource_limit': raise TimeoutError('module_reported_resource_limit')
            values=observables(record,case,context)
            save(folder/'OBSERVABLES.json',values)
            row.update(status='completed',observables=values)
            save(OUT/'COMPARISON.json',comparison,new=False); guard(started)
        for path,expected in INPUTS.values(): require(hashlib.sha256(path.read_bytes()).hexdigest()==expected,'input_changed_during_run:'+str(path))
        guard(started); status['status']='completed'
    except Exception as exc:
        status.update(status='resource_limit' if isinstance(exc,TimeoutError) else 'failed',
                      failure={'type':type(exc).__name__,'reason':str(exc)})
    status.update(new_solve_attempts=attempts,attempt_count_final=True,elapsed_before_final_save_s=time.monotonic()-started)
    if status['elapsed_before_final_save_s']>30.: status.update(status='resource_limit',resource_reason='driver_budget_at_return')
    comparison['status']=status['status']; comparison['new_solve_attempts']=attempts
    save(OUT/'COMPARISON.json',comparison,new=False); save(OUT/'STATUS.json',status,new=False)
    elapsed=time.monotonic()-started
    if elapsed>30.:
        status.update(status='resource_limit',resource_reason='driver_budget_after_save',elapsed_after_final_save_s=elapsed)
        comparison['status']='resource_limit'
        save(OUT/'COMPARISON.json',comparison,new=False); save(OUT/'STATUS.json',status,new=False)
    print(json.dumps({'status':status['status'],'new_solve_attempts':attempts}))
    return 0 if status['status']=='completed' else 1


if __name__=='__main__': raise SystemExit(main())
