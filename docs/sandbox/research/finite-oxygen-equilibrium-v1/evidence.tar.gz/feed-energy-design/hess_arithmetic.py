"""Unit conversion and a conditional combustion atom balance; no EOS calls."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path


WORK = Path(__file__).resolve().parent
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
RESULT = WORK.parent / 'cedrone-execution/native01/RESULT.json'
POOL = ROOT / 'data/sandbox/research/cedrone2024-element-pool-v1/printed-pool.json'


def f(value: dict) -> F:
    """Decode a saved exact integer fraction."""
    return F(int(value['numerator']), int(value['denominator']))


def encoded(value: object) -> object:
    """Keep exact fractions and label the additional float as display only."""
    if isinstance(value, F):
        return {'numerator': value.numerator, 'denominator': value.denominator,
                'approximate_display': float(value)}
    if isinstance(value, dict):
        return {k: encoded(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encoded(v) for v in value]
    return value


def calculate() -> dict:
    """Calculate only terms identifiable from the fixed reported data."""
    result_raw, source_raw = RESULT.read_bytes(), POOL.read_bytes()
    assert hashlib.sha256(result_raw).hexdigest() == 'c8f544fe09694ef4bcadde046a98a6c125ab99e9cc1b5e5abb5d4330bb1739f9'
    assert hashlib.sha256(source_raw).hexdigest() == '92feba43d25479d99a2607466fb902841d0afcffc5b1108ca2ff74a42145f7fd'
    result, source = json.loads(result_raw), json.loads(source_raw)
    assert result['status'] == 'completed' and result['actual_source_properties_checked']
    elements = ('C', 'H', 'O', 'N', 'S')
    actual = result['initial']['loaded_definition']['gas_atomic_weights_kg_kmol']
    a = {e: F.from_float(actual[e]) for e in elements}
    m = {e: f(source['nominal_CHONS_kg'][e]) for e in elements}
    b = {e: 1000 * m[e] / a[e] for e in elements}
    assert tuple(b.values()) == tuple(map(f, result['request']['element_mol']))
    demand = b['C'] + b['H'] / 4 + b['S'] - b['O'] / 2
    delta_n = b['N'] / 2 - b['H'] / 4 + b['O'] / 2
    assert b['C'] + b['S'] + b['N'] / 2 - demand == delta_n
    q_mj = F(source['HHV']['printed_MJ_kg'])
    quoted_pm_mj = F(source['HHV']['printed_plus_minus_MJ_kg'])
    moisture = f(source['printed_values']['moisture']['nominal_kg_per_1kg_reported_sample'])
    equation1_subtraction = F('2.5') * (9 * m['H'] + moisture)
    saved_r = F.from_float(result['final']['gas_constant_j_mol_k'])
    selected_temperature = F('298.15')
    return {
        'scope': 'first-law algebra and unit conversion only; no inferred feed enthalpy',
        'input_bytes': {'source': {'path': str(POOL), 'sha256': hashlib.sha256(source_raw).hexdigest()},
                        'saved_result': {'path': str(RESULT), 'sha256': hashlib.sha256(result_raw).hexdigest()}},
        'HHV_reported_J_per_kg_reported_basis': q_mj * 10**6,
        'quoted_plus_minus_J_per_kg_not_a_validated_interval': quoted_pm_mj * 10**6,
        'nominal_aliquot_kg': F('0.0005'),
        'HHV_times_nominal_aliquot_J_not_raw_bomb_heat': q_mj * 10**6 * F('0.0005'),
        'quoted_plus_minus_times_nominal_aliquot_J': quoted_pm_mj * 10**6 * F('0.0005'),
        'source_equation1': {'subtraction_MJ_kg': equation1_subtraction,
                             'LHV_MJ_kg_from_printed_central_values': q_mj - equation1_subtraction,
                             'meaning': 'replay of paper Eq1, not a pV/acid correction or measurement'},
        'actual_saved_atomic_weights_kg_kmol': actual,
        'represented_atomic_weights_exact': a, 'base_element_mol': b,
        'reference_O2_demand_mol': demand,
        'delta_n_g_mol_condensed_feed_liquid_water_products': delta_n,
        'R_from_actual_saved_result_J_mol_K_exact_binary64': saved_r,
        'ideal_gas_delta_pV_coefficient_J_K': delta_n * saved_r,
        'selected_reference_temperature_K_not_measured_bomb_temperature': selected_temperature,
        'ideal_gas_delta_pV_at_selected_temperature_J': delta_n * saved_r * selected_temperature,
        'conditions': ['condensed feed', 'CO2(g),H2O(l),SO2(g),N2(g) reference products',
                       'same selected temperature', 'ideal gas pV',
                       'extra N2 and unchanged excess O2 cancel',
                       'source nominal CHONS availability approximation retained'],
        'unknowns_not_set_to_zero': ['basis_conversion_kappa', 'target_internal_energy_correction_C_U',
                                   'actual_bomb_temperature', 'condensed_delta_pV',
                                   'acid_capture_and_mineral_endpoint_changes',
                                   'feed_reference_enthalpy'],
        'EOS_Cantera_equilibrium_calls': 0,
    }


if __name__ == '__main__':
    report = calculate()
    with (WORK / 'HESS_ARITHMETIC.json').open('x', encoding='utf-8') as stream:
        json.dump(encoded(report), stream, indent=2, allow_nan=False)
        stream.write('\n')
    print('PASS: exact unit/atom-balance arithmetic; 0 EOS/Cantera/equilibrium calls.')
