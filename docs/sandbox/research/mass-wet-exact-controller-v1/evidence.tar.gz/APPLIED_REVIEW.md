# Independent application identity review

APPROVE application consistency. All three repository additions were compared in full against frozen candidate files and FREEZE.json, with exact byte equality:

- src/sludge_sandbox/mass_wet_exact_controller.py: 7e9bd6d3237d2258b1dde3866d360319a5d470401457bd5d3986758e14ce4f0f
- tests/sandbox/test_mass_wet_exact_controller.py: be021e805b15e20c93172535508c6002d0438876a4c20844f83d1ca3f3f7397c
- tests/sandbox/independent_mixed_ode.py: bc05a2829143394c6d0da172eb691af8e5bf254a0f601f2f6376736bac689d5a

They are currently untracked additions, so ordinary git diff does not show content. No temporary conftest was copied. Main tests use normal sludge_sandbox imports and existing sibling sandbox fixture imports; independent_mixed_ode is beside the test and uses existing declared source constants/caloric functions. No hard-coded temporary import paths were introduced. Solid inventories remain kg and liquid/gas mol, with total U; the independent helper explicitly uses a manufactured analytic-liquid fixture. This identity check does not convert its numerical tests into native EOS or real-material evidence.

This is application verification of the independently approved candidate, not a second full code/numerical review. No tests, EOS, install, or repository edits performed. Original single-atomic-packet/no-resume and generic wet-pressure-unavailable qualifications remain intact.

## Connected-tube result read for subsequent interface planning

Read coexistence_study/connected-tube-result01.json only; did not recompute mathematical EOS. Saved result reports 31 evaluated boxes, 16 accepted leaves, no pending boxes, and unchanged source/implementation binding over T=[299.9999999,300.0000001] K, connecting the selected local coexistence liquid box to the mechanical box. Its reported saturation pressure interval is approximately [3533.2651,3540.3519] Pa and it retains a positive pressure-separation margin including the original ambiguity band.

The result explicitly uses a declared study T interval, not the actual U-inverse uncertainty interval. It keeps manufactured-explicit-error-envelope, global_phase_admission=false and native_error_admission=false. The next interface must therefore preserve separate local branch connection, actual inverse T coverage, and provider/numerical correspondence; this saved connection alone cannot enable native wet pressure admission. No new implementation undertaken here.
