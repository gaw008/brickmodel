# Mixed kg/mol exact wet-to-dry controller candidate

## Executable interface and supported scope

`integrate_mixed_exact(pair, initial, start, end, stage_policy, roundoff_policy, original_liquid_fraction_limit, controller_policy, constant_liquid_fixture=None, cancel=None)` uses exact-time ordinary trials, internally sampled affine terminal preparation, reviewed liquid-to-vapor projection, and the real WetPair depleted-no-nucleation mode constructor. Solid kg, liquid mol, three gas inventories and total U remain distinct. There is no pseudo-solid molar mass or separate latent/reaction heat source.

This first controller treats the entire requested interval as **one speculative atomic packet**, potentially containing both depletion transitions and the final dry tail. Every refinement restarts from the exact same original initial state, host, time and policy. No saved spine state is reused. Nothing becomes globally accepted until all requirements pass. Consequently a failure retains only the original global accepted prefix, plus complete speculative paths/attempts/costs; it does not publish a partial packet. This is not yet a service/resume/codec implementation or an optimized multi-packet rolling controller.

Ordinary steps call actual full-vs-two-half midpoint trials and use the fine two panels. Terminal sampling is invoked only near the declared terminal window; positive initial tangent estimates schedule sampling/approach, never select an event. Exact terminal evidence performs all-cell numerical root ordering and full component integration. A successful local projection alone permits creating a new host mode via with_depleted_cells. Each frame records old/new operator identities and mode vectors. Its rebound context retains original states, original time, full policy and every per-cell correction accumulator; these are never reset on a mode change.

## Required comparisons and audit

Terminal-window refinement requires **two consecutive successful comparisons**. Each comparison includes every matched event and the shared exact final endpoint: solid kg, all liquid/gas mol, total U, temperature, pressure and time. Event time differences include both root enclosure widths. Temperature and pressure include both actual inverse/forward errors. Independent verification then rebuilds the entire path from the original state with approach cap and safe fraction both halved, keeping the final terminal window. Its actual pre-first-event grids must both be nonempty and different; changed settings alone do not qualify. All six comparisons must pass again. The committed path is the twice-refined main path; the independently rebuilt path is retained as verification evidence.

Every completed candidate is audited from the original initial state before comparison, and the selected path is audited again before atomic publication. Each exact clock/state/ledger sequence is checked, as are represented and exact kg/mol/U increments, cumulative increment residuals, absolute quadrature residuals, and cumulative component-energy discrepancies. Terminal corrections enter once, via the actual frame/ledger identity. Per-cell cumulative correction/storage totals are reconstructed from actual correction records, not trusted after a mode change. Tests independently check the earlier B closed-system whole-prefix element/mass/water/U gates as well.

The caller supplies explicit fixed policies. Maximum wall time, host evaluation count and conservative panel work charges are cumulative across all ordinary trials, failed trials, terminal attempts, refinements and independent validation. A local full-vs-two-half trial reserves **three panel work units** and a terminal request one; no charge is refunded if it fails before completing every panel. Thus the `panel_attempts` budget field is a conservative charged-work counter, not a claim that all reserved quadratures were completed. Ordinary/terminal request counts and actual host evaluations are separately retained. Host evaluation counts are not an independent per-EOS-call journal. Per-trial stage limits are also retained when bounding remaining controller resources.

Standalone host callback inputs/outcomes are saved in observation_journal, including failed mixed-mode endpoint calls. Child stage/terminal results retain their own actual samples and failures. Prepared transitions are stored before observing their new endpoint; a failed frame has observation=None and never becomes a globally committed packet. Original source and policies are guarded throughout.

## Pressure admission and material limits

Generic wet pressure-temperature propagation remains unavailable and refuses explicitly. The end-to-end pure tests opt into the reviewed **manufactured constant-liquid test model**, bound to actual non-production callbacks and their declarations. This is not a HEOS certificate or real material uncertainty admission. The original caller fixture is checked throughout, and mode-only host copies carry the same physical parameter declarations. Dry pressure uses the exact ideal-gas/volume interval contract.

The affine event roots remain numerical surrogates, not certificates of the true nonlinear physical root. The two-pass and independently rebuilt approach comparisons are necessary numerical checks, not real-material validation. Tests operate near 305 K for a short closed, fixed-geometry manufactured case. Full wet-to-fired physics, real sludge reactions/materials, geometry evolution, nucleation, open boundaries, native wet P uncertainty, codecs, service replay/resume and more general event/no-event scheduling remain separate tasks.

## Actual verification evidence

- tests01: initial full manufactured trajectory test passed in 32.69 s.
- tests02: four tests passed in 34.55 s.
- tests03: retained actual test-only failure (1 failed / 3 passed): local temperature variable `T` shadowed ExactEventTime in the new oracle assertions. No physics or gate changed; test-before-ode-name.txt preserves it.
- tests04: five tests passed in 34.84 s, including the independent nonlinear segmented DOP853 reference.
- tests05: seven tests passed in 57.52 s. Strict original time tolerance failure leaves no committed packet, and empty pre-first grids cannot falsely qualify as independent.
- tests06-global-prefix: the modified complete-trajectory test additionally checks all earlier B whole-prefix conservation gates; see its actual log/XML.

The actual complete candidate has 18 accepted panels, one atomic packet with events cell 0 at 0.0002932672427520446 s and cell 1 at 0.0003812391189182242 s, and common end 0.0005 s. Four complete paths (coarse, two successive refinements, independent) spend 396 actual host evaluations, 36 ordinary trial requests, eight terminal requests and 116 conservative panel work units. No rejections occurred in this successful fixture; separate failure tests exercise refusal/cost retention.

The independent reference reconstructs coupled energy inversion, reaction, evaporation, diffusion, Darcy and donor enthalpy algebra, using only the shared declared ideal-water caloric/entropy source functions; it does not call tested host, face, stage, terminal or controller methods in the RHS. SciPy localizes its own two liquid-zero events and advances changed mixed/dry RHS. Actual maxima vs the accepted trajectory are approximately 1.57e-16 kg, 5.56e-15 mol, 5.60e-11 J; endpoint T/P differences are 3.13e-8 K and 1.06e-4 Pa, all inside the pre-existing fixture gates. Exact values are printed in tests04/05 logs.

Files to review: mass_wet_exact_controller.py; test_mass_wet_exact_controller.py; independent_mixed_ode.py (test helper). Temporary conftest overlays only this candidate and must not be installed. Tests use normal sludge_sandbox imports. No repository source, installation or native water EOS changed. Await independent review before adoption.
