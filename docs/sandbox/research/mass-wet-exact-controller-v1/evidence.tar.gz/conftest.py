from pathlib import Path
import sys
import sludge_sandbox
sludge_sandbox.__path__.append(str(Path(__file__).parent))
sys.path.insert(0,str(Path.cwd()/'tests'/'sandbox'))
