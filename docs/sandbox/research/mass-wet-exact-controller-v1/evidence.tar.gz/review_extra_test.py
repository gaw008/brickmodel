"""Independent budget/source failure checks; manufactured callbacks only."""
from dataclasses import replace
import pytest
from test_mass_wet_exact_controller import setup, execute
from sludge_sandbox.mass_wet_transport import WetPair
from sludge_sandbox.integration import DomainExit


def check_costs(result):
    costs = dict(result.costs)
    attempted = len(result.observation_journal)
    completed = sum(entry.sample is not None for entry in result.observation_journal)
    for refinement in result.refinements:
        for _, trial in refinement.path.attempts:
            attempted += trial.evaluations_attempted
            completed += trial.evaluations_completed
    assert costs['evaluations_attempted'] == attempted
    assert costs['evaluations_completed'] == completed
    assert not result.steps and not result.packets
    assert result.roundoff_totals.aggregate.events == 0


@pytest.mark.parametrize('budget', [0, 1, 2, 3, 4, 5, 13])
def test_actual_budget_matches_raw_callback_journals(monkeypatch, budget):
    pair, initial, rp, cp = setup(monkeypatch)
    count = [0]
    old = WetPair.evaluate
    def observed(self, states):
        count[0] += 1
        return old(self, states)
    monkeypatch.setattr(WetPair, 'evaluate', observed)
    result = execute(pair, initial, rp, replace(cp, maximum_evaluations=budget))
    assert result.status == 'resource_limit'
    assert count[0] == dict(result.costs)['evaluations_attempted'] <= budget
    assert result.states == (initial,)
    check_costs(result)


def test_failed_child_callback_cost_is_never_refunded(monkeypatch):
    pair, initial, rp, cp = setup(monkeypatch)
    count = [0]
    old = WetPair.evaluate
    def observed(self, states):
        count[0] += 1
        if count[0] == 3:
            raise DomainExit('review_callback_domain_failure')
        return old(self, states)
    monkeypatch.setattr(WetPair, 'evaluate', observed)
    result = execute(pair, initial, rp, cp)
    assert result.status == 'domain_exit'
    assert dict(result.costs)['evaluations_attempted'] == 3
    assert dict(result.costs)['evaluations_completed'] == 2
    check_costs(result)


def test_physics_change_during_actual_callback_cannot_commit(monkeypatch):
    pair, initial, rp, cp = setup(monkeypatch)
    old = WetPair.evaluate
    def changed(self, states):
        value = old(self, states)
        object.__setattr__(pair, 'transfer_coefficients_mol_s_pa', (2e-8, 1e-8))
        return value
    monkeypatch.setattr(WetPair, 'evaluate', changed)
    result = execute(pair, initial, rp, cp)
    assert result.status == 'failed'
    assert 'changed' in result.reason
    assert dict(result.costs)['evaluations_attempted'] == 1
    assert dict(result.costs)['evaluations_completed'] == 1
    check_costs(result)
