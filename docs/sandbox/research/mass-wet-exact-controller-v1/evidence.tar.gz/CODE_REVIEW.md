# Independent exact-controller review

Decision: APPROVE for the explicitly manufactured analytic-liquid research controller. No CRITICAL or HIGH correctness issue found in the frozen candidate. This is not native-water admission, a global phase certificate, a resume/codec/service implementation, or real-material validation.

Reviewed source SHA256 `7e9bd6d3237d2258b1dde3866d360319a5d470401457bd5d3986758e14ce4f0f`, final main test `be021e805b15e20c93172535508c6002d0438876a4c20844f83d1ca3f3f7397c`, independent ODE `bc05a2829143394c6d0da172eb691af8e5bf254a0f601f2f6376736bac689d5a`. Hashes were independently checked after execution against FREEZE.json. No candidate/repository/install edits or native EOS calls were made by this reviewer. `git diff -- '*.py'` was empty. ruff, mypy, pylint and black were unavailable; no installation attempted.

## Actual independent execution

- `independent-main01.log` / XML: 7 passed in 57.14s. Includes full wet/wet -> dry/wet -> dry/dry trajectory, all accepted-prefix original conservation checks, two consecutive main comparisons plus independent halved actual approach grid, strict time-gate refusal, mode-endpoint failure diagnostics, and independently assembled DOP853 reference.
- Reviewer-owned `review_extra_test.py`, `independent-extra01.log` / XML: 9 passed in 3.41s. Seven tiny evaluation budgets (0,1,2,3,4,5,13) compare actual entered callbacks with every raw observation/child journal, enforce no overrun and no committed prefix; a failing third callback preserves attempted=3/completed=2; physics binding mutation during an actual successful callback refuses the packet and retains its actual cost.

## Numerical and transactional assessment

Every proposal restarts from the original states/time and empty original correction context. Within each proposal mode changes carry per-cell accumulators and change only the context operator/source binding. Failed speculative states, projections and attempts remain accessible in refinement diagnostics, while the public accepted packet/state sequence stays at the original state. Observation entries are allocated before entry and stage/terminal results are attached before cumulative accounting checks.

Comparisons keep kg, mol, total U, T, P and exact time separate and use the original six policy thresholds. Event time includes both localization enclosure widths; T includes both inverse bounds; P delegates to the previously reviewed full-temperature pressure radius, so ordinary generic wet states still refuse without an admitted bound. The explicit manufactured fixture is not a native pressure certificate. Consecutive-pass count resets on failure. Independent validation uses both halved approach controls and an actually different nonempty pre-first-event grid, then checks each corresponding event and common endpoint.

Prefix audit follows exact ledger times and binds each terminal projection to its actual ledger/state/time, adds phase correction once, checks represented and exact inventory/U cumulative discrepancies under original unit-specific budgets, and recomputes per-cell correction totals from actual records. The accepted main test also checks original overall elements, mass, water and energy at every accepted state. The independently assembled ODE does not invoke the tested transport/step RHS; it shares declared caloric/entropy source functions, which is appropriate for this manufactured numerical-reference scope and does not constitute independent physical-source validation.

Evaluation cost counts actual entered callbacks without resetting between proposals. `panel_attempts` is explicitly a conservative reservation (three panels per ordinary trial, one per terminal), not a count of completed panels; unused reservations are not refunded. This is honest and does not loosen the original budget. Wall checking is cooperative around synchronous calls, not a hard timeout capable of preempting one callback.

## Nonblocking maintainability observation

[MEDIUM] The controller uses dense nested closures and broad `tuple`/`object` record annotations; the main integration function spans roughly 165 lines. Explicit typed records for comparison rows and child attempts, plus extraction of proposal/comparison helpers, would improve maintenance. This does not invalidate the tested numerical or transactional contract; avoid mixing that refactor into the frozen mathematical change.
