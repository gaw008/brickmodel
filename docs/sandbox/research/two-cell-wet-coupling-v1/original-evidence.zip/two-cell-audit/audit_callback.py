"""Independent saved callback arithmetic; standard library only, no model imports."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import traceback
from typing import Any

HERE = Path(__file__).resolve().parent


def audit(data: dict[str, Any], plan: dict[str, Any], policy: dict[str, Any], result: dict[str, Any]) -> None:
    checks: list[dict[str, Any]] = []
    result['checks'] = checks

    def require(condition: bool, label: str) -> None:
        checks.append({'name': label, 'passed': bool(condition)})
        if not condition:
            raise ValueError(label)

    def close(actual: float, expected: float, label: str, terms: tuple[float, ...] = ()) -> None:
        values = (actual, expected, *terms)
        if not all(math.isfinite(v) for v in values):
            raise ValueError('nonfinite:'+label)
        bound = policy['relative_tolerance']*max(abs(actual), abs(expected))
        bound += policy['ulp_sum_multiplier']*math.fsum(math.ulp(v) for v in values)
        error = abs(actual-expected)
        checks.append({'name': label, 'actual': actual, 'expected': expected,
                       'absolute_error': error, 'bound': bound, 'passed': error <= bound})
        if error > bound:
            raise ValueError('arithmetic_mismatch:'+label)

    require(data['status'] == 'passed', 'callback_passed')
    mode = data['mode']
    require(mode in ('coupled', 'control'), 'known_mode')
    s = data['snapshot']
    inventory = s['state']['amounts_mol']
    require(s['state'] == data['initial'], 'snapshot_is_initial')
    require(inventory == plan['initial_amounts_mol'], 'registered_inventory')
    require(s['time_s'] == plan['time_interval_s'][0], 'registered_time')
    names = tuple(s['gas_states'][0]['concentrations_mol_m3'])
    require(set(names) == {'fixture', 'H2O'}, 'gas_species')
    masses, gas_r = s['molar_masses_kg_mol'], s['gas_constant_j_mol_k']
    layout = plan['layout']
    gases = []
    for cell, stored in enumerate(s['gas_states']):
        m = s['cells'][cell]['thermal']['mechanical']
        t, volume = m['temperature_k'], m['gas_volume_m3']
        require(volume > 0 and t > 0, f'cell{cell}:positive_domain')
        close(stored['temperature_k'], t, f'cell{cell}:T')
        close(stored['gas_constant_j_mol_k'], gas_r, f'cell{cell}:R')
        concentrations = {k: inventory[cell][layout.index(k)]/volume for k in names}
        total = math.fsum(concentrations.values())
        x = {k: concentrations[k]/total for k in names}
        mean = math.fsum(x[k]*masses[k] for k in names)
        rho, pressure = total*mean, total*gas_r*t
        y = {k: x[k]*masses[k]/mean for k in names}
        for k in names:
            close(stored['molar_masses_kg_mol'][k], masses[k], f'cell{cell}:mass:{k}')
            for field, values in [('concentrations_mol_m3', concentrations), ('mole_fractions', x), ('mass_fractions', y)]:
                close(stored[field][k], values[k], f'cell{cell}:{field}:{k}')
        for field, value in [('mean_molar_mass_kg_mol', mean), ('density_kg_m3', rho), ('pressure_pa', pressure)]:
            close(stored[field], value, f'cell{cell}:{field}')
        gases.append({'t': t, 'p': pressure, 'x': x, 'y': y})
    require(len(gases) == 2, 'two_gases')
    area = s['face_area_m2']
    widths = s['cell_widths_m']
    for i in range(2):
        close(widths[i], s['motion']['current']['widths_m'][i], f'current_width:{i}')
    for i, value in enumerate(s['motion']['current']['face_areas_m2']):
        close(area, value, f'current_area:{i}')
    dl, dr = widths[0]/2, widths[1]/2
    distance, weight = dl+dr, dr/(dl+dr)
    left, right = gases
    face_t = weight*left['t']+(1-weight)*right['t']
    face_p = weight*left['p']+(1-weight)*right['p']
    xinput = {k: weight*left['x'][k]+(1-weight)*right['x'][k] for k in names}
    xsum = math.fsum(xinput.values())
    # Reservoir construction normalizes its interpolated composition, then
    # derives gas intensives from its represented species concentrations.
    face_c = {k: (face_p/(gas_r*face_t))*xinput[k]/xsum for k in names}
    face_total = math.fsum(face_c.values())
    face_x = {k: face_c[k]/face_total for k in names}
    mean = math.fsum(face_x[k]*masses[k] for k in names)
    face_rho = face_total*mean
    diffusion = {}
    for k in names:
        dleft, dright = s['diffusivities_m2_s'][k]
        registered = plan['transport'][mode]['H2O_diffusivities_m2_s'] if k == 'H2O' else plan['transport']['carrier_diffusivities_m2_s']
        require([dleft, dright] == registered, 'registered_diffusion:'+k)
        diffusion[k] = 0. if dleft == 0 or dright == 0 else distance/(dl/dleft+dr/dright)
    require(plan['transport']['permeability_m2'] == [0, 0], 'registered_zero_Darcy_scope')
    star = {k: -face_rho*(masses[k]/mean)*diffusion[k]*(right['x'][k]-left['x'][k])/distance for k in names}
    total_star = math.fsum(star.values())
    donor = left if total_star < 0 else right if total_star > 0 else None
    correction = {k: -total_star*donor['y'][k] if donor else 0. for k in names}
    molar = {k: area*(star[k]+correction[k])/masses[k] for k in names}
    ex = s['face_exchange_reconstructed']
    close(ex['face_temperature_k'], face_t, 'face_T')
    close(ex['face_density_kg_m3'], face_rho, 'face_rho')
    close(ex['diffusion_correction_velocity_m_s'], -total_star/face_rho, 'correction_velocity')
    require(ex['diffusion_correction_donor'] == ('left' if total_star < 0 else 'right' if total_star > 0 else None), 'correction_donor')
    require(ex['darcy_velocity_m_s'] == 0 and ex['advective_donor'] is None, 'zero_Darcy_observed')
    fn, fe = s['rates']['face_species_mol_s'], s['rates']['face_energy_w']
    require(len(fn) == len(fe) == 3 and all(len(row) == 5 for row in fn), 'face_shapes')
    require(all(v == 0 for row in (fn[0], fn[2]) for v in row) and fe[0] == fe[2] == 0, 'external_faces_zero')
    require(all(fn[1][layout.index(k)] == 0 for k in ('A', 'B', 'H2O_liquid')), 'immobile_columns')
    for k in names:
        require(ex['advective_mol_s'][k] == 0, 'zero_advection:'+k)
        close(ex['diffusive_mol_s'][k], molar[k], 'diffusive:'+k)
        close(ex['net_mol_s'][k], molar[k], 'net:'+k)
        close(fn[1][layout.index(k)], molar[k], 'assembled_molar:'+k)
    mass_terms = tuple(molar[k]*masses[k] for k in names)
    close(math.fsum(mass_terms), 0., 'mass_frame_sum', mass_terms)
    kleft, kright = s['conductivities_w_m_k']
    require([kleft, kright] == plan['transport'][mode]['conductivities_w_m_k'], 'registered_conductivity')
    heat = 0. if kleft == 0 or kright == 0 else area*(left['t']-right['t'])/(dl/kleft+dr/kright)
    enthalpy_terms = tuple(molar[k]*s['face_enthalpy_j_mol'][k] for k in names)
    expected_energy = math.fsum((heat, *enthalpy_terms))
    close(fe[1], expected_energy, 'assembled_energy', (heat, *enthalpy_terms))
    require((molar['H2O'] != 0 and heat != 0) if mode == 'coupled' else all(v == 0 for v in (*molar.values(), heat, fe[1])), 'mode_effect')
    result['reconstruction'] = {'mode': mode, 'face_temperature_k': face_t, 'face_pressure_pa': face_p,
        'face_density_kg_m3': face_rho, 'j_star_kg_m2_s': star, 'correction_kg_m2_s': correction,
        'species_mol_s': molar, 'fourier_w': heat, 'species_enthalpy_w': math.fsum(enthalpy_terms),
        'assembled_energy_w': expected_energy}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--plan', type=Path, default=Path('/private/tmp/brick-reacting-wet-two-cell-v1/PLAN.json'))
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Preserve existing audit output')
    result: dict[str, Any] = {'status': 'started', 'inputs': [],
        'qualification': 'independent saved arithmetic; source caloric samples reused, no EOS or trajectory accuracy claim'}
    try:
        records = []
        for path in (args.input, args.plan, HERE/'ALGEBRA_POLICY.json'):
            raw = path.read_bytes()
            result['inputs'].append({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
            records.append(json.loads(raw))
        data, plan, policy = records
        result['policy'] = policy
        if policy['relative_tolerance'] != 1e-12 or policy['ulp_sum_multiplier'] != 64:
            raise ValueError('unexpected_frozen_policy')
        audit(data, plan, policy, result)
        result['status'] = 'passed'
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        temporary = args.output.with_suffix(args.output.suffix+'.tmp')
        temporary.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
        temporary.replace(args.output)
    print(json.dumps({'status': result['status'], 'checks': len(result.get('checks', [])), 'output': str(args.output)}))
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
