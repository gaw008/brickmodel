"""Saved-JSON-only four-run empirical comparison; no model imports or EOS."""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import traceback
from typing import Any

HERE = Path(__file__).resolve().parent
EXPERIMENT = Path('/private/tmp/brick-reacting-wet-two-cell-v1')
MODES = ('coupled', 'control')
SPECIES = ('A', 'B', 'H2O', 'H2O_liquid', 'fixture')


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def number(value: Any) -> Fraction:
    require(type(value) in (int, float) and math.isfinite(value), 'finite numerical value required')
    return Fraction(value)


def load(path: Path, report: dict[str, Any]) -> dict[str, Any]:
    record: dict[str, Any] = {'path': str(path), 'exists': path.is_file()}
    report['inputs'].append(record)
    data = path.read_bytes()
    record.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    result = json.loads(data)
    require(type(result) is dict, 'JSON object required: '+str(path))
    return result


def check_modules(record: dict[str, Any], registered: dict[str, str]) -> None:
    # Lazy imports may expand the module set; every observed file must match.
    require(bool(record['modules']), 'empty installed module evidence')
    for name, item in record['modules'].items():
        require(name == 'sludge_sandbox' or name.startswith('sludge_sandbox.'), 'unexpected package module')
        require(item['path'] in registered, 'unregistered installed module: '+name)
        require(item['sha256'] == registered[item['path']], 'installed hash mismatch: '+name)


def screen(fine_c: Fraction, coarse_c: Fraction, fine_z: Fraction,
           coarse_z: Fraction, floor: Fraction) -> dict[str, Any]:
    signed = fine_c-fine_z
    rc, rz = abs(fine_c-coarse_c), abs(fine_z-coarse_z)
    threshold = 4*max(rc+rz, floor)
    return {'signed_fine_effect': float(signed), 'absolute_fine_effect': float(abs(signed)),
            'coupled_cap_difference': float(rc), 'control_cap_difference': float(rz),
            'sum_cap_differences': float(rc+rz), 'sum_local_control_scales': float(floor),
            'resolution_threshold': float(threshold), 'resolved_indicator': abs(signed) > threshold}


def temperature(run: dict[str, Any], cell: int) -> tuple[Fraction, Fraction]:
    observed = run['final_snapshot']['cells'][cell]
    bound = number(observed['inverse_temperature_error_k'])
    require(bound >= 0, 'negative inverse temperature bound')
    return number(observed['thermal']['mechanical']['temperature_k']), bound


def compare(report: dict[str, Any]) -> None:
    plan = load(EXPERIMENT/'PLAN.json', report)
    report['plan_experiment_id'] = plan['experiment_id']
    require(plan['layout'] == list(SPECIES), 'unexpected layout')
    require(plan['numerical_policy']['refinements'] == [0, 1], 'two registered caps required')
    registered = {row['installed_path']: row['sha256'] for row in plan['source_snapshot']['modules']}
    require(len(registered) == 43, '43 registered source modules required')
    callbacks: dict[str, Any] = {}
    runs: dict[tuple[str, int], Any] = {}
    report['gates'] = []
    canonical_provider = None
    canonical_assets = None
    canonical_versions = None
    canonical_motion = None
    for mode in MODES:
        callback = load(EXPERIMENT/f'callback-{mode}-result.json', report)
        require(callback['status'] == 'passed' and callback['mode'] == mode, 'fresh callback mode/status')
        require(callback['initial']['amounts_mol'] == plan['initial_amounts_mol'], 'registered physical initial amounts')
        initial_snapshot = callback['snapshot']
        require(initial_snapshot['state'] == callback['initial'], 'callback snapshot state mismatch')
        require(initial_snapshot['time_s'] == plan['time_interval_s'][0], 'callback time mismatch')
        for cell in range(2):
            observation = initial_snapshot['cells'][cell]
            initial_t = number(observation['thermal']['mechanical']['temperature_k'])
            bound = number(observation['inverse_temperature_error_k'])
            require(bound >= 0 and abs(initial_t-number(plan['initial_temperatures_k'][cell])) <= bound,
                    'initial temperature does not enclose registered value')
        expected = plan['transport'][mode]
        require(initial_snapshot['conductivities_w_m_k'] == expected['conductivities_w_m_k'], 'mode conductivity mismatch')
        require(initial_snapshot['diffusivities_m2_s']['H2O'] == expected['H2O_diffusivities_m2_s'], 'mode water diffusion mismatch')
        require(initial_snapshot['diffusivities_m2_s']['fixture'] == [0., 0.], 'carrier diffusivity mismatch')
        if canonical_provider is None:
            canonical_provider = initial_snapshot['implementation']
            canonical_assets = initial_snapshot['water_source_asset_sha256']
            canonical_versions = callback['installed_before']['versions']
            canonical_motion = initial_snapshot['motion']
        require(initial_snapshot['implementation'] == canonical_provider, 'water implementation differs between modes')
        require(initial_snapshot['water_source_asset_sha256'] == canonical_assets, 'water assets differ between modes')
        require(initial_snapshot['motion'] == canonical_motion, 'physical initial motion differs between modes')
        for label in ('installed_before', 'installed_after'):
            check_modules(callback[label], registered)
            require(callback[label]['versions'] == canonical_versions, 'callback dependency versions changed')
        callbacks[mode] = callback
        for refinement in (0, 1):
            path = EXPERIMENT/f'wet-{mode}-{refinement}-result.json'
            run = load(path, report)
            raw_sha = report['inputs'][-1]['sha256']
            audit = load(HERE/f'ledger-{mode}-{refinement}.json', report)
            require(audit['status'] == 'prefix_audit_passed' and audit['all_saved_prefixes_pass'], 'ledger gate failed')
            require(audit['sha256'] == raw_sha, 'ledger audit is not bound to this run')
            require(audit['trajectory_completed'] and audit['solver_status'] == 'completed', 'ledger run incomplete')
            require(run['status'] == 'passed_pending_independent_ledger_audit', 'wet script gate failed')
            require(run['mode'] == mode and run['refinement'] == refinement, 'run mode/refinement mismatch')
            require(run['initial'] == callback['initial'], 'run initial differs from same-mode callback')
            policy = run['policy']
            declared = plan['numerical_policy']
            expected_policy = {
                'initial_step_s': declared['initial_and_maximum_step_s_by_refinement'][refinement],
                'maximum_step_s': declared['initial_and_maximum_step_s_by_refinement'][refinement],
                'minimum_step_s': declared['minimum_step_s'], 'relative_tolerance': declared['relative_tolerance'],
                'amount_absolute_tolerance_mol': declared['amount_absolute_tolerance_mol'],
                'energy_absolute_tolerance_j': declared['energy_absolute_tolerance_j'],
                'amount_scale_mol': declared['amount_scale_mol'], 'energy_scale_j': declared['energy_scale_j'],
                'maximum_steps': declared['maximum_steps'], 'maximum_rejections': declared['maximum_rejections'],
                'maximum_wall_seconds': declared['internal_wall_s']}
            require(policy == expected_policy, 'unregistered policy change')
            trajectory = run['run']
            require(trajectory['status'] == 'completed' and len(trajectory['steps']) > 0, 'solver incomplete/empty')
            require(trajectory['times_s'][0] == plan['time_interval_s'][0] and
                    trajectory['times_s'][-1] == plan['time_interval_s'][1], 'different trajectory horizon')
            require(trajectory['states'][0] == run['initial'], 'first trajectory state differs')
            final = run['final_snapshot']
            require(final['state'] == trajectory['states'][-1], 'decoded final state mismatch')
            require(final['time_s'] == plan['time_interval_s'][1], 'final snapshot time mismatch')
            require(final['energy_identity'] == initial_snapshot['energy_identity'] == run['initial']['energy_model_identity'],
                    'same-mode energy identity changed')
            require(final['implementation'] == canonical_provider and final['water_source_asset_sha256'] == canonical_assets,
                    'final water identity changed')
            require(final['conductivities_w_m_k'] == initial_snapshot['conductivities_w_m_k'] and
                    final['diffusivities_m2_s'] == initial_snapshot['diffusivities_m2_s'], 'transport coefficients changed')
            for label in ('installed_before', 'installed_after'):
                check_modules(run[label], registered)
                require(run[label]['versions'] == canonical_versions, 'run dependency versions changed')
            require(len(final['cells']) == 2 and len(final['state']['amounts_mol']) == 2, 'two final cells required')
            for cell in final['cells']:
                require(cell['reaction_binding_same_object'] and cell['current_storage_same_object'] and
                        cell['thermal_inverse_reused'], 'final binding/inverse reuse gate')
            runs[mode, refinement] = run
            report['gates'].append({'mode': mode, 'refinement': refinement, 'passed': True, 'ledger_sha256': raw_sha})
    # Compare physical initial states without requiring transport identities equal.
    for mode in MODES:
        require(callbacks[mode]['initial']['amounts_mol'] == plan['initial_amounts_mol'], 'physical initial N mismatch')
    report['amount_indicators'] = []
    report['energy_indicators'] = []
    report['temperature_indicators'] = []
    report['phase_rate_observations'] = []
    def scale(mode: str, kind: str) -> Fraction:
        policy = runs[mode, 1]['policy']
        if kind == 'amount':
            return number(policy['amount_absolute_tolerance_mol'])+number(policy['relative_tolerance'])*number(policy['amount_scale_mol'])
        return number(policy['energy_absolute_tolerance_j'])+number(policy['relative_tolerance'])*number(policy['energy_scale_j'])
    for cell in range(2):
        for column, species in enumerate(SPECIES):
            values = [number(runs[mode, ref]['final_snapshot']['state']['amounts_mol'][cell][column])
                      for mode, ref in (('coupled', 1), ('coupled', 0), ('control', 1), ('control', 0))]
            report['amount_indicators'].append({'cell': cell, 'species': species,
                **screen(*values, scale('coupled', 'amount')+scale('control', 'amount'))})
        energies = [number(runs[mode, ref]['final_snapshot']['state']['internal_energy_j'][cell])
                    for mode, ref in (('coupled', 1), ('coupled', 0), ('control', 1), ('control', 0))]
        report['energy_indicators'].append({'cell': cell,
            **screen(*energies, scale('coupled', 'energy')+scale('control', 'energy'))})
        (tc, bc), (tco, bco), (tz, bz), (tzo, bzo) = [temperature(runs[key], cell)
            for key in (('coupled', 1), ('coupled', 0), ('control', 1), ('control', 0))]
        rc, rz = abs(tc-tco)+bc+bco, abs(tz-tzo)+bz+bzo
        threshold = 4*(bc+bz+rc+rz)
        report['temperature_indicators'].append({'cell': cell, 'coupled_fine_k': float(tc),
            'control_fine_k': float(tz), 'signed_fine_effect_k': float(tc-tz),
            'coupled_cap_difference_k': float(abs(tc-tco)), 'control_cap_difference_k': float(abs(tz-tzo)),
            'coupled_inverse_bounds_k': [float(bc), float(bco)], 'control_inverse_bounds_k': [float(bz), float(bzo)],
            'R_T_coupled_k': float(rc), 'R_T_control_k': float(rz), 'S_T_k': float(bc+bz+rc+rz),
            'resolution_threshold_k': float(threshold), 'resolved_temperature_indicator': abs(tc-tz) > threshold,
            'decoded_interval_separation': abs(tc-tz) > bc+bz})
        phase = {(mode, ref): number(runs[mode, ref]['final_snapshot']['transfers'][cell]['rate_mol_s'])
                 for mode in MODES for ref in (0, 1)}
        report['phase_rate_observations'].append({'cell': cell,
            'coupled_fine_mol_s': float(phase['coupled', 1]), 'control_fine_mol_s': float(phase['control', 1]),
            'signed_fine_difference_mol_s': float(phase['coupled', 1]-phase['control', 1]),
            'coupled_cap_difference_mol_s': float(abs(phase['coupled', 1]-phase['coupled', 0])),
            'control_cap_difference_mol_s': float(abs(phase['control', 1]-phase['control', 0])),
            'resolution': 'unresolved_no_certified_phase_rate_sensitivity_interval'})
    gradients = {mode: temperature(runs[mode, 1], 1)[0]-temperature(runs[mode, 1], 0)[0] for mode in MODES}
    report['temperature_gradient'] = {'orientation': 'cell1 minus cell0, divided by common current center distance',
        'coupled_fine_delta_k': float(gradients['coupled']), 'control_fine_delta_k': float(gradients['control']),
        'signed_delta_effect_k': float(gradients['coupled']-gradients['control']),
        'nominal_gradient_magnitude_decreases': abs(gradients['coupled']) < abs(gradients['control']),
        'qualification': 'nominal gradient comparison; resolved per-cell indicators reported separately'}
    widths_c = runs['coupled', 1]['final_snapshot']['cell_widths_m']
    widths_z = runs['control', 1]['final_snapshot']['cell_widths_m']
    require(widths_c == widths_z and len(widths_c) == 2, 'different final geometry')
    distance = (number(widths_c[0])+number(widths_c[1]))/2
    require(distance > 0, 'nonpositive center distance')
    report['temperature_gradient'].update(center_distance_m=float(distance),
        coupled_fine_k_m=float(gradients['coupled']/distance), control_fine_k_m=float(gradients['control']/distance))
    report['status'] = 'comparison_completed'


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=HERE/'four-run-comparison.json')
    output = parser.parse_args().output
    if output.exists():
        raise SystemExit('Preserve existing comparison evidence; choose a new output path')
    report: dict[str, Any] = {'status': 'started', 'inputs': [], 'qualification':
        'Fixed factor4 empirical cap-resolution indicators, not statistical significance or certified global ODE/model error. '
        'Unresolved effects do not invalidate passed callback/ledger gates; no full-cycle/material admission.'}
    try:
        compare(report)
    except BaseException as exc:
        report.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        temporary = output.with_suffix(output.suffix+'.tmp')
        temporary.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
        temporary.replace(output)
    return 0 if report['status'] == 'comparison_completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
