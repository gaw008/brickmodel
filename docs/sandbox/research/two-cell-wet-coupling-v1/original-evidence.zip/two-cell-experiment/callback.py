"""Fresh two-cell callback and audit inputs; no trajectory claim."""
from __future__ import annotations
import argparse
import time
import traceback
from typing import Any
import numpy as np
from fixture import build, snapshot, installed_identity, save_result, START, COMPONENTS


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('coupled', 'control'))
    mode = parser.parse_args().mode
    started = time.monotonic()
    name = f'callback-{mode}-result.json'
    result: dict[str, Any] = {'status': 'started', 'mode': mode}
    try:
        result['installed_before'] = installed_identity()
        operator, initial = build(mode)
        result['initial'] = initial
        observed = snapshot(operator, initial, START)
        result['snapshot'] = observed
        save_result(name, result)
        rates = observed['rates']
        assert rates.face_species_mol_s.shape == (3, 5) and rates.face_energy_w.shape == (3,)
        assert np.all(rates.face_species_mol_s[[0, 2]] == 0) and np.all(rates.face_energy_w[[0, 2]] == 0)
        if mode == 'coupled':
            assert rates.face_species_mol_s[1, 2] != 0
        else:
            assert np.all(rates.face_species_mol_s == 0) and np.all(rates.face_energy_w == 0)
        assert set(rates.cell_power_components_w) == COMPONENTS
        assert np.array_equal(rates.cell_power_w, observed['base_rates'].cell_power_w)
        for index, cell in enumerate(observed['cells']):
            assert cell['reaction_binding_same_object'] and cell['current_storage_same_object'] and cell['thermal_inverse_reused']
            assert abs(cell['total_energy_residual_j']) <= 1e-6
            assert cell['inverse_temperature_error_k'] <= 1e-6
            assert abs(cell['thermal'].mechanical.temperature_k-(300.+index)) <= 1e-6
            row = rates.reaction_species_mol_s[index]
            assert row[0] < 0 and row[1] == -row[0] and abs(row[1]-.2) <= 1e-14
            assert row[2] == -row[3] == observed['transfers'][index].rate_mol_s > 0
            assert row[4] == 0
        result['status'] = 'passed'
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        try:
            result['installed_after'] = installed_identity()
        except BaseException as exc:
            result.update(status='failed', identity_error=str(exc))
        result['elapsed_s'] = time.monotonic()-started
        save_result(name, result)
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
