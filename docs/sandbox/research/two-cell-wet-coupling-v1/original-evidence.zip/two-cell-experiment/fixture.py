"""Manufactured A/B reacting wet fixture; imports installed package exclusively."""
from __future__ import annotations
from collections.abc import Mapping
from dataclasses import fields, is_dataclass, replace
from sludge_sandbox.depletion_integration import NestedApproachPolicy
from fractions import Fraction
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys
from typing import Any
import numpy as np
from test_incompressible_solid import phase, caloric
from test_water_phase_transfer import transfer, DATA
from test_depletion_integration import policies
from test_reactions import kinetics
from test_rigid_storage import R
from sludge_sandbox.water_properties import load_water_properties
from sludge_sandbox.ideal_water_vapor import IdealWaterVapor
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.geometry import ReferenceSlab
from sludge_sandbox.deformation_program import PrescribedSlabMotion
from sludge_sandbox.skeleton_energy import DiagonalSkeletonEnergy
from sludge_sandbox.reacting_skeleton_energy import ManufacturedReactingSkeletonEnergy
from sludge_sandbox.deforming_solid_storage import DeformingSolidStorage, DeformationErrorBounds, solid_provider_identity
from sludge_sandbox.deforming_solid_heat import DeformingSolidHeat
from sludge_sandbox.solid_fluid_storage import SolidFluidStorage
from sludge_sandbox.solid_fluid_heat import SolidFluidHeat, InventoryLayout
from sludge_sandbox.solid_reactions import SolidReactionConfig, ReactionSpeciesBinding
from sludge_sandbox.reactions import SpeciesDefinition, ReactionDefinition, ReactionNetwork
from sludge_sandbox.phase_storage import InversePolicy
from sludge_sandbox.water_phase_transfer import WaterPhaseTransfer
from sludge_sandbox.integration import ConservedState, IntegrationPolicy
from sludge_sandbox.depletion_integration import DepletionPolicy

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
HERE = Path(__file__).resolve().parent
START, END = .5, .5+1/65536
COMPONENTS = {'elastic_deformation', 'interface_deformation', 'dissipation', 'bulk_pressure', 'body'}


def encode(value: Any) -> Any:
    if isinstance(value, Fraction):
        return {'numerator': value.numerator, 'denominator': value.denominator}
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if is_dataclass(value):
        return {field.name: encode(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Mapping):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(item) for item in value]
    return value


def installed_identity() -> dict[str, Any]:
    modules = {}
    for name, module in tuple(sys.modules.items()):
        path = getattr(module, '__file__', None)
        if name.startswith('sludge_sandbox') and path:
            installed = Path(path).resolve()
            assert '/site-packages/sludge_sandbox/' in str(installed), str(installed)
            relative = str(installed).split('/site-packages/', 1)[1]
            assert installed.read_bytes() == (ROOT/'src'/relative).read_bytes(), name
            modules[name] = {'path': str(installed), 'sha256': hashlib.sha256(installed.read_bytes()).hexdigest()}
    return {'modules': modules, 'versions': {name: importlib.metadata.version(name)
            for name in ('numpy', 'scipy', 'iapws', 'CoolProp', 'sludge-vme')}}


def build(mode: str) -> tuple[WaterPhaseTransfer, ConservedState]:
    if mode not in ('coupled', 'control'):
        raise ValueError('mode must be coupled or control')
    selection = {'backend': 'heos', 'backend_manifest': DATA/'heos-8.0.0-approved-manifest.json'}
    ingredients = (load_water_properties(DATA, **selection), IdealWaterVapor(DATA, **selection),
                   WaterChemicalPotential(DATA, **selection))
    wet = transfer(ingredients)
    transport = replace(wet.base_model, inverse_policy=InversePolicy(1e-6, 1e-6, 120),
        storages=(wet.base_model.storages[0], wet.base_model.storages[0]),
        cell_widths_m=(.01, .01), conductivities_w_m_k=((1., 1.) if mode == 'coupled' else (0., 0.)),
        effective_diffusivities_m2_s={'fixture': (0., 0.), 'H2O': ((1e-8, 1e-8) if mode == 'coupled' else (0., 0.))},
        permeability_m2=(0., 0.), relative_permeability=(1., 1.), viscosity_pa_s=(1e-5, 1e-5),
        temperature_brackets_k=((295., 310.), (295., 310.)),
        coefficient_set_id='manufactured-two-cell-'+mode)
    a = phase(molar_mass_kg_mol=.012, caloric=caloric(species_id='A'))
    b = replace(a, molar_volume_m3_mol=1e-5, caloric=replace(a.caloric, species_id='B',
        coefficients=(5., 0., 0., 0., 0., -100.005, 0., -100.005), formation_enthalpy_298_j_mol=-100005.))
    template = SolidFluidStorage(fluid_template=transport.storages[0], solid_phases={'A': a, 'B': b},
        bulk_volume_m3=1e-4, bulk_volume_error_m3=1e-18, geometry_id='manufactured:reacting-wet-bulk-v1',
        geometry_version='1', geometry_classification='manufactured_test_fixture',
        geometry_source_ids=('manufactured:reacting-wet-bulk-v1',), allow_manufactured=True)
    layout = InventoryLayout(species_order=('A', 'B', 'H2O', 'H2O_liquid', 'fixture'),
        liquid_column_id='H2O_liquid', gas_species_order=('fixture', 'H2O'), solid_species_order=('A', 'B'))
    sources = ('manufactured:reacting-wet-A-to-B-v1',)
    species = tuple(SpeciesDefinition(name, 'solid', {'C': 1}, .012, sources, 'manufactured') for name in ('A', 'B'))
    reaction = ReactionDefinition('A-to-B', 'wet-v1', {'A': -1, 'B': 1},
        kinetics({'A': 1.}, prefactor_mol_m3_s=.1, gas_constant_j_mol_k=R,
                 temperature_range_k=(295., 310.), candidate_id='manufactured-wet-kinetics-v1'),
        'oxygen_free_pyrolysis', sources)
    templates = (template, replace(template))
    config = SolidReactionConfig(network=ReactionNetwork(species, (reaction,), allow_manufactured=True),
        bindings=tuple(ReactionSpeciesBinding(name, name, template.solid_phases[name]) for name in ('A', 'B')),
        storages=templates, inventory_layout=layout, allow_manufactured=True,
        binding_id='manufactured-reacting-wet-binding', version='1', source_ids=sources)
    base = SolidFluidHeat(storages=templates, inventory_layout=layout, transport=transport, solid_reactions=config)
    reference = ReferenceSlab(.02, .01, 2)
    motion = PrescribedSlabMotion(reference=reference, knot_times_s=(0., 1.),
        normal_stretches_at_knots=((1., 1.), (.9, .9)), tangential_stretches_at_knots=(1., .9),
        motion_id='manufactured-reacting-wet-motion', version='1', classification='manufactured_test_fixture',
        source_ids=('manufactured-reacting-wet-motion',), source_asset_sha256=())
    points = []
    for index, template in enumerate(templates):
        reference_model = DiagonalSkeletonEnergy(reference=reference, cell_index=index,
            fixed_solid_inventory_mol=(('A', 2.), ('B', 0.)), solid_provider_identity=solid_provider_identity(template.solid_phases),
            bulk_modulus_pa=1000., shear_modulus_pa=400., viscosity_pa_s=3., interface_energy_j_m2=100.,
            reference_interface_area_m2=.003, stretch_range=(.5, 2.), maximum_absolute_log_rate_per_s=2.,
            model_id='manufactured-reacting-wet-reference', version='1', source_ids=('manufactured-reacting-wet-reference',),
            classification='manufactured_test_fixture', allow_manufactured=True)
        skeleton = ManufacturedReactingSkeletonEnergy(reference_model=reference_model, composition_offset=1.,
            composition_weights_per_mol=(('A', 0.), ('B', 10.)), model_id='manufactured-reacting-wet-q', version='1',
            classification='manufactured_test_fixture', allow_manufactured=True)
        point = DeformingSolidStorage(template=template, motion=motion, skeleton=skeleton,
            error_bounds=DeformationErrorBounds((0., 1.), 0., 0., ('manufactured-wet-motion-bounds',),
                                               'conditional_declared_not_material_admission'),
            model_id='manufactured-reacting-wet-point', version='1', allow_manufactured=True)
        points.append(point)
    host = DeformingSolidHeat(base_model=base, point_storages=tuple(points),
        mechanical_regime='prescribed_cellwise_quasistatic_incompressible_skeleton',
        transport_regime='manufactured_relative_moving_faces', model_id='manufactured-reacting-wet-host', version='1',
        source_ids=('manufactured-reacting-wet-host',), allow_manufactured=True, solid_inventory_regime='reacting_manufactured')
    operator = replace(wet, base_model=host, coefficients_mol_s_pa=(1e-6, 1e-6),
                       coefficient_set_id='manufactured-reacting-wet-interface-v1')
    state = host.state_from_temperatures([[2., 0., 1e-8, 1e-6, .001], [2., 0., 2e-8, 1e-6, .001]], [300., 301.], time_s=START)
    return operator, state


def integration_policy(refinement: int) -> IntegrationPolicy:
    if refinement not in (0, 1):
        raise ValueError('refinement must be0 or1')
    policy, _ = policies()
    return replace(policy, initial_step_s=(END-START)/(2*2**refinement), maximum_step_s=(END-START)/(2*2**refinement),
                   maximum_steps=100, maximum_wall_seconds=120.)


def snapshot(operator: WaterPhaseTransfer, state: ConservedState, time_s: float) -> dict[str, Any]:
    out = operator.evaluate(state, time_s)
    base = out.base_evaluation
    current = base.current_host
    transport = current.transport
    # Reconstruct only transport algebra from already decoded states. This
    # performs no second thermal inverse and is not the independent audit.
    exchange = transport._face(base.gas_states[0], base.gas_states[1], 0, 1)
    enthalpies = {name: transport.storages[0].gas_phases[name]._curve.enthalpy_j_mol(exchange.face_temperature_k)
                 for name in transport.gas_species_order}
    cells = []
    for index, (thermal, inverse) in enumerate(zip(base.storage_states, base.total_inverses)):
        cells.append(dict(thermal=thermal, skeleton=inverse.state.skeleton_state,
            total_energy_residual_j=inverse.total_energy_residual_j,
            inverse_temperature_error_k=inverse.temperature_error_bound_k,
            bulk_volume_m3=current.storages[index].bulk_volume_m3,
            reaction_binding_same_object=current.solid_reactions.storages[index] is current.storages[index],
            current_storage_same_object=current.storages[index] is inverse.state.current_storage,
            thermal_inverse_reused=base.storage_inverses[index] is inverse.thermal_inverse))
    return dict(state=state, time_s=time_s, rates=out.rates, base_rates=base.rates,
        transfers=out.cell_transfers, gas_states=base.gas_states, cells=cells, motion=base.motion,
        face_exchange_reconstructed=exchange, face_enthalpy_j_mol=enthalpies,
        face_area_m2=transport.face_area_m2, cell_widths_m=transport.cell_widths_m,
        conductivities_w_m_k=transport.conductivities_w_m_k,
        diffusivities_m2_s=transport.effective_diffusivities_m2_s,
        gas_constant_j_mol_k=transport.storages[0].mechanical.gas_constant_j_mol_k,
        molar_masses_kg_mol={name: transport.storages[0].gas_phases[name].metadata.molar_mass_kg_mol
                           for name in transport.gas_species_order},
        interfaces=operator.interfaces, energy_identity=operator.base_model.energy_model_identity,
        implementation=json.loads(operator.chemical.water.implementation.canonical_json),
        water_source_asset_sha256=operator.chemical.source_asset_sha256)


def save_result(name: str, result: dict[str, Any]) -> None:
    (HERE/name).write_text(json.dumps(encode(result), indent=2, allow_nan=False)+'\n')
