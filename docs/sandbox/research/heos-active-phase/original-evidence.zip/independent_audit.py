"""Saved-number audit only; no EOS imports or execution."""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import math

P = Path(__file__).parent
def fraction(x): return F(x['numerator'], x['denominator'])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
reports = {}
results = {}
for mode in ('active', 'disabled'):
    r = json.loads((P / (mode+'-result.json')).read_text())
    results[mode] = r
    meta = json.loads((P / (mode+'-attempt01/metadata.json')).read_text())
    status = json.loads((P / (mode+'-attempt01/status.json')).read_text())
    assert {k:v['sha256'] for k,v in meta['inputs_before'].items()} == status['inputs_after']
    assert all(sha(Path(k)) == v for k,v in status['inputs_after'].items())
    assert status['status'] == 'complete' and status['returncode'] == 0
    run = r['run']; initial = r['initial']
    assert r['status'] == 'passed' and run['status'] == 'completed'
    assert run['times_s'][0] == .5 and run['times_s'][-1] == .51
    assert len(run['states']) == len(run['steps'])+1 == len(run['times_s'])
    energy = F(); amount = [F() for _ in range(4)]
    water = F(initial['amounts_mol'][0][1])+F(initial['amounts_mol'][0][2])
    component_roundoff = F(); audit = []
    for state, step, stored in zip(run['states'][1:],run['steps'],r['prefix_audit']):
        energy += F(step['cell_work_j'][0])+F(step['face_energy_j'][0])-F(step['face_energy_j'][1])
        for j in range(4):
            amount[j] += F(step['face_species_mol'][0][j])-F(step['face_species_mol'][1][j])+F(step['reaction_species_mol'][0][j])
        er = F(state['internal_energy_j'][0])-F(initial['internal_energy_j'][0])-energy
        nr = [F(state['amounts_mol'][0][j])-F(initial['amounts_mol'][0][j])-amount[j] for j in range(4)]
        wr = F(state['amounts_mol'][0][1])+F(state['amounts_mol'][0][2])-water
        assert er == fraction(stored['energy_residual_j']) and abs(er)<=F(1e-5)
        assert nr == [fraction(x) for x in stored['amount_residual_mol']] and max(map(abs,nr))<=F(1e-10)
        assert wr == fraction(stored['water_sum_residual_mol']) and abs(wr)<=F(1e-11)
        assert all(x>=0 for x in state['amounts_mol'][0])
        assert state['amounts_mol'][0][0] == initial['amounts_mol'][0][0]
        assert state['amounts_mol'][0][3] == initial['amounts_mol'][0][3]
        reaction=step['reaction_species_mol'][0]
        assert F(reaction[1])+F(reaction[2]) == 0 and reaction[0] == reaction[3] == 0
        if mode=='disabled': assert all(x==0 for x in reaction)
        assert all(x==0 for row in step['face_species_mol'] for x in row)
        assert all(x==0 for x in step['face_energy_j'])
        components=step['cell_work_components_j']
        assert set(components)=={'body','pore','elastic','interface','dissipation'}
        residual=F(step['cell_work_j'][0])-sum((F(v[0]) for v in components.values()),F())
        assert abs(residual)==abs(fraction(step['component_sum_residual_j'][0]))
        component_roundoff+=abs(residual)
        audit.append(dict(energy_residual_j=float(er),water_sum_residual_mol=float(wr),component_sum_residual_j=float(residual)))
    assert component_roundoff==fraction(run['cumulative_absolute_component_residual_j'][0])
    reports[mode]=dict(elapsed_s=status['elapsed_s'],evaluations=run['evaluations'],accepted=len(run['steps']),prefixes=audit)

a,b=results['active'],results['disabled']
for key in ('initial','policy','inverse_policy','layout','implementation','versions'):assert a[key]==b[key]
delta=b['final_temperature_k']-a['final_temperature_k'];assert delta>=1e-4
assert b['final_amounts_mol']==b['initial']['amounts_mol'] and b['final_rate_mol_s']==0
c=a['final_cell_transfer'];t=a['final_temperature_k'];peq=c['equilibrium']['equilibrium_partial_pressure_pa'];pv=c['vapor_partial_pressure_pa'];R=8.31446261815324
rate=float(F(c['coefficient_mol_s_pa'])*(F(peq)-F(pv)))
affinity=float(F(R)*F(t)*F(math.log(peq)-math.log(pv)))
entropy=float(F(rate)*F(affinity)/F(t))
assert rate==c['rate_mol_s'] and affinity==c['driving_chemical_potential_j_mol']
assert entropy==c['entropy_production_w_k'] and entropy>0
comparison=json.loads((P/'comparison.json').read_text())
assert delta==comparison['temperature_difference_k']
for n,v in comparison['result_sha256'].items():assert sha(P/n)==v
reports['comparison']=dict(temperature_difference_k=delta,vapor_increase_mol=a['final_amounts_mol'][0][1]-a['initial']['amounts_mol'][0][1],final_affinity_j_mol=affinity,final_entropy_production_w_k=entropy)
(P/'independent-audit.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))
