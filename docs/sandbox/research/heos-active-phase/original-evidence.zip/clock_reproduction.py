from pathlib import Path
import json,math
from sludge_sandbox.integration import ConservedState,IntegrationPolicy,Rates,integrate
p=Path(__file__).parent
initial=ConservedState([[1.]], [100.])
def inert(state,t):return Rates([[0.],[0.]],[0.,0.],[[0.]],[0.])
rows=[]
for cap in (8,10):
    policy=IntegrationPolicy(initial_step_s=.00125,maximum_step_s=.00125,minimum_step_s=1e-10,relative_tolerance=1e-7,amount_absolute_tolerance_mol=1e-10,energy_absolute_tolerance_j=1e-5,amount_scale_mol=.001,energy_scale_j=1.,maximum_steps=cap,maximum_rejections=10,maximum_wall_seconds=5)
    r=integrate(initial,inert,start_s=.5,end_s=.51,policy=policy)
    assert all(s.amounts_mol[0,0]==1. and s.internal_energy_j[0]==100. for s in r.states)
    rows.append({'step_cap':cap,'status':r.status,'reason':r.reason,'evaluations':r.evaluations,'times':r.times_s,'actual_steps':len(r.steps),'last_step_s':r.times_s[-1]-r.times_s[-2],'remaining_s':.51-r.times_s[-1]})
assert rows[0]['status']=='resource_limit' and rows[0]['actual_steps']==8
assert rows[1]['status']=='completed' and rows[1]['actual_steps']==9
assert rows[1]['last_step_s']==2*math.ulp(.51)
(p/'clock-reproduction.json').write_text(json.dumps({'scope':'deterministic zero-EOS clock behavior; invariant analytic state, observed extra tail step preserved','rows':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))
