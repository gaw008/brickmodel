MODE='disabled'
from pathlib import Path
from dataclasses import replace
from decimal import Decimal,localcontext
from fractions import Fraction as F
import json,time,traceback
import numpy as np
from test_solid_fluid_heat import solid_host
from test_water_phase_transfer import transfer,DATA
from sludge_sandbox.water_properties import load_water_properties
from sludge_sandbox.ideal_water_vapor import IdealWaterVapor
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.geometry import ReferenceSlab
from sludge_sandbox.deformation_program import PrescribedSlabMotion
from sludge_sandbox.skeleton_energy import DiagonalSkeletonEnergy
from sludge_sandbox.deforming_solid_storage import DeformingSolidStorage,DeformationErrorBounds,solid_provider_identity
from sludge_sandbox.deforming_solid_heat import DeformingSolidHeat
r=Path(__file__).resolve().parent;started=time.monotonic();result={'attempt_id':'installed-'+MODE+'-integration'}
try:
    selection=dict(backend='heos',backend_manifest=DATA/'heos-8.0.0-approved-manifest.json')
    ingredients=(load_water_properties(DATA,**selection),IdealWaterVapor(DATA,**selection),WaterChemicalPotential(DATA,**selection))
    import sys,hashlib,importlib.metadata
    result['loaded_modules']={n:m.__file__ for n,m in sys.modules.items() if n.startswith('sludge_sandbox') and getattr(m,'__file__',None)}
    assert all('/site-packages/sludge_sandbox/' in p for p in result['loaded_modules'].values())
    result['versions']={n:importlib.metadata.version(n) for n in ('numpy','scipy','iapws','CoolProp')}
    result['implementation']=json.loads(ingredients[0].implementation.canonical_json)
    base=solid_host(ingredients)
    reference=ReferenceSlab(half_thickness_m=.01,reference_area_m2=.01,cells=1)
    motion=PrescribedSlabMotion(reference=reference,knot_times_s=(0.,1.),
        normal_stretches_at_knots=((1.,),(.9,)),tangential_stretches_at_knots=(1.,.9),
        motion_id='manufactured-wet-callback-motion',version='1',classification='manufactured_test_fixture',
        source_ids=('manufactured-wet-callback-motion',),source_asset_sha256=())
    skeleton=DiagonalSkeletonEnergy(reference=reference,cell_index=0,fixed_solid_inventory_mol=(('fixture_solid',2.),),
        solid_provider_identity=solid_provider_identity(base.storages[0].solid_phases),bulk_modulus_pa=1000.,
        shear_modulus_pa=400.,viscosity_pa_s=3.,interface_energy_j_m2=.5,reference_interface_area_m2=.003,
        stretch_range=(.5,2.),maximum_absolute_log_rate_per_s=2.,model_id='manufactured-wet-callback-skeleton',version='1',
        source_ids=('manufactured-wet-callback-skeleton',),classification='manufactured_test_fixture',allow_manufactured=True)
    point=DeformingSolidStorage(template=base.storages[0],motion=motion,skeleton=skeleton,
        error_bounds=DeformationErrorBounds((0.,1.),0.,0.,('manufactured-callback-extra-bounds',),'conditional_declared_not_material_admission'),
        model_id='manufactured-wet-callback-point',version='1',allow_manufactured=True)
    host=DeformingSolidHeat(base_model=base,point_storages=(point,),
        mechanical_regime='prescribed_cellwise_quasistatic_incompressible_skeleton',
        transport_regime='manufactured_relative_moving_faces',model_id='manufactured-wet-callback-host',version='1',
        source_ids=('manufactured-wet-callback-host',),allow_manufactured=True)
    op=transfer(ingredients,base_model=host)
    if MODE=='disabled':op=replace(op,coefficients_mol_s_pa=(0.,))
    state=host.state_from_temperatures([[2.,1e-8,1e-4,.001]],[300.],time_s=.5)
    from sludge_sandbox.integration import integrate,IntegrationPolicy
    from dataclasses import fields,is_dataclass
    from collections.abc import Mapping
    def enc(v):
        if isinstance(v,F):return {'numerator':v.numerator,'denominator':v.denominator}
        if isinstance(v,np.ndarray):return v.tolist()
        if isinstance(v,np.generic):return v.item()
        if is_dataclass(v):return {f.name:enc(getattr(v,f.name)) for f in fields(v)}
        if isinstance(v,Mapping):return {str(k):enc(w) for k,w in v.items()}
        if isinstance(v,(tuple,list)):return [enc(w) for w in v]
        return v
    assert host.base_model.inventory_layout.species_order==('fixture_solid','H2O','H2O_liquid','fixture')
    pol=IntegrationPolicy(initial_step_s=.005,maximum_step_s=.005,minimum_step_s=1e-10,
        relative_tolerance=1e-7,amount_absolute_tolerance_mol=1e-10,energy_absolute_tolerance_j=1e-5,
        amount_scale_mol=.001,energy_scale_j=1.,maximum_steps=10,maximum_rejections=10,maximum_wall_seconds=25)
    result.update(mode=MODE,initial=enc(state),policy=enc(pol),inverse_policy=vars(base.transport.inverse_policy),layout=host.base_model.inventory_layout.species_order)
    run=integrate(state,op,start_s=.5,end_s=.51,policy=pol)
    result['run']=enc(run)
    assert run.status=='completed',run.reason
    energy=F();amounts=[F() for _ in range(4)];prefix=[]
    initial_water=F(float(state.amounts_mol[0,1]))+F(float(state.amounts_mol[0,2]))
    for time_s,s,l in zip(run.times_s[1:],run.states[1:],run.steps):
        energy+=F(float(l.cell_work_j[0]))+F(float(l.face_energy_j[0]))-F(float(l.face_energy_j[1]))
        for j in range(4):amounts[j]+=F(float(l.face_species_mol[0,j]))-F(float(l.face_species_mol[1,j]))+F(float(l.reaction_species_mol[0,j]))
        er=F(float(s.internal_energy_j[0]))-F(float(state.internal_energy_j[0]))-energy
        nr=[F(float(s.amounts_mol[0,j]))-F(float(state.amounts_mol[0,j]))-amounts[j] for j in range(4)]
        wr=F(float(s.amounts_mol[0,1]))+F(float(s.amounts_mol[0,2]))-initial_water
        assert abs(er)<=F(1e-5) and max(abs(v) for v in nr)<=F(1e-10) and abs(wr)<=F(1e-11)
        assert s.amounts_mol[0,0]==state.amounts_mol[0,0] and s.amounts_mol[0,3]==state.amounts_mol[0,3]
        assert F(float(l.reaction_species_mol[0,1]))+F(float(l.reaction_species_mol[0,2]))==0
        assert l.reaction_species_mol[0,0]==l.reaction_species_mol[0,3]==0
        if MODE=='disabled':assert np.all(l.reaction_species_mol==0)
        assert np.all(l.face_species_mol==0) and np.all(l.face_energy_j==0)
        assert set(l.cell_work_components_j)=={'elastic','interface','dissipation','pore','body'}
        prefix.append({'t':time_s,'energy_residual_j':enc(er),'amount_residual_mol':enc(nr),'water_sum_residual_mol':enc(wr)})
    result['prefix_audit']=prefix
    final=op.evaluate(run.states[-1],.51);m=final.base_evaluation.storage_states[0].mechanical
    assert np.array_equal(final.rates.cell_power_w,final.base_evaluation.rates.cell_power_w)
    for key in final.rates.cell_power_components_w:assert np.array_equal(final.rates.cell_power_components_w[key],final.base_evaluation.rates.cell_power_components_w[key])
    result['final_cell_transfer']=enc(final.cell_transfers[0])
    if MODE=='disabled':assert final.cell_transfers[0].rate_mol_s==0
    final_state=run.states[-1]
    if MODE=='active':assert final_state.amounts_mol[0,1]>state.amounts_mol[0,1] and final_state.amounts_mol[0,2]<state.amounts_mol[0,2]
    else:assert np.array_equal(final_state.amounts_mol,state.amounts_mol)
    result.update(status='passed',final_temperature_k=m.temperature_k,final_pressure_pa=m.liquid_pressure_pa,final_rate_mol_s=final.cell_transfers[0].rate_mol_s,
        final_amounts_mol=final_state.amounts_mol.tolist(),final_work_components_w={k:v.tolist() for k,v in final.rates.cell_power_components_w.items()},
        final_energy_j=final_state.internal_energy_j.tolist(),qualification='manufactured_active_or_disabled_phase_prescribed_deformation_short_integration; ledger verification not independent trajectory accuracy oracle')
except BaseException as exc:
    result.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
finally:
    result['elapsed_s']=time.monotonic()-started
    (r/(MODE+'-result.json')).write_text(json.dumps(result,indent=2,default=str)+'\n')
if result['status']!='passed':raise SystemExit(1)
