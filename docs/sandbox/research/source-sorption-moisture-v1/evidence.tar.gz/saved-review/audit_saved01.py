"""One-case passive JSON/Fraction audit; never imports application or calls EOS."""
from fractions import Fraction as F
from pathlib import Path
import csv
import hashlib
import json
import math
import time
import traceback
import xml.etree.ElementTree as ET

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK=Path('/private/tmp/sludge-sorption-moisture-v1')
OUT=WORK/'saved-review'
START=time.monotonic()
CHECKS=[]
RECOMPUTED={}
INPUTS={}

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def hook(v):
    if set(v)=={'numerator','denominator'} and type(v['numerator']) is int and type(v['denominator']) is int:
        return F(v['numerator'],v['denominator'])
    return v

def read(path):
    path=Path(path); INPUTS[str(path)]=sha(path)
    return json.loads(path.read_bytes(),object_hook=hook)

def check(label,condition):
    CHECKS.append({'id':label,'passed':bool(condition)})

def original(label,condition):
    if label in RECOMPUTED: raise ValueError('duplicate original check '+label)
    RECOMPUTED[label]=bool(condition)
    check('original/'+label,condition)

def T(p): return p['fluid']['mechanical']['temperature_k']
def P(p): return p['fluid']['mechanical']['pressure_pa']
def total(states,kind):
    if kind=='U': return sum((F(s['internal_energy_j']) for s in states),F())
    if kind=='W': return sum((F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]) for s in states),F())
    return sum((F(s['gas_amounts_mol'][kind]) for s in states),F())
def default(value):
    if isinstance(value,F): return {'numerator':value.numerator,'denominator':value.denominator}
    raise TypeError(type(value).__name__)

SUMMARY={}
try:
    a=read(WORK/'native01/ACCEPTANCE.json'); run=read(WORK/'native01/RUN.json')
    ini=read(WORK/'native01/INITIAL.json'); prefix=read(WORK/'native01/CONSTRUCTION_PREFIX.json')
    meta=read(WORK/'supervised-native01/metadata.json'); status=read(WORK/'supervised-native01/status.json')
    freeze=read(WORK/'install/SOURCE_FREEZE.json')['files']
    facts=read(ROOT/'data/sandbox/research/septien-conductivity-v1/source.json')
    model=read(ROOT/'data/sandbox/research/septien-conductivity-v1/model.json')
    prov=ini['provenance']; initial=ini['states']; thermal=prov['thermal_provider']
    m=prov['cells'][0]['wet_definition']['water']['molar_mass_kg_mol']
    source_ids=(facts['source_id'],model['model_id'],facts['primary_asset']['sha256'],
                sha(ROOT/'data/sandbox/research/septien-conductivity-v1/source.json'),
                sha(ROOT/'data/sandbox/research/septien-conductivity-v1/model.json'))
    provider_id=hashlib.sha256(json.dumps((*source_ids[1:2],*source_ids[2:],(.3,.8),(308.15,368.15)),separators=(',',':')).encode()).hexdigest()
    check('provider/model_identity',provider_id==thermal['model_identity'])
    check('provider/provenance_facts',thermal['source_facts']==facts and thermal['model_definition']==model)
    check('classification',facts['classification']=='measured_public_data' and model['classification']=='derived_from_evidence'
        and model['usage_scope']=='hybrid_exploratory_donor_transport' and prov['transport_classification']=='mixed_source_exploratory'
        and prov['gas_face_transport']=='disabled for this apparent total-loss moisture allocation')
    check('unknown_errors',all(model['uncertainty_policy'][key] is None for key in ('interpolated_conductivity_confidence_interval',
        'interpolation_model_error','temperature_extension_model_error','pressure_extension_model_error','cross_material_transfer_error','total_model_uncertainty')))
    check('false_qualifications',all(x['material_qualified'] is False and x['training_eligible'] is False for x in (facts,model,thermal)))
    check('initial/prefix',prefix=={'states':initial,'points':ini['points']} and run['states'][0]==initial)
    check('initial/geometry',prov['cell_widths_m']==[.02,.02] and prov['face_area_m2']==.001 and prov['boundary_conditions']==['closed_no_flux']*2)
    check('initial/registered_inventory',[(s['solid_mass_kg'],s['liquid_water_mol'],s['gas_amounts_mol'],T(p)) for s,p in zip(initial,ini['points'])]
        ==[([.01],.2,[.000048,.000181,.000001],330.),([.01],.225,[.000045,.000168,.000001],333.)])
    # Original printed k nodes were read/reviewed in the prior frozen phase; no XML/PDF reread.
    nodes=[(F(23,77),F('.056')),(F(47,53),F('.062'))]
    check('k/source_nodes',[(F(p['moisture_dry_basis']),F(p['conductivity_w_m_k'])) for p in facts['points']]==nodes)
    wet=prov['cells'][0]['wet_definition']; water=wet['water']; factor_nodes=ini['source_factor_nodes']
    records=wet['source_point_records']
    rational_record=lambda x:F(int(x['numerator']),int(x['denominator']))
    rs=water['gas_constant_j_mol_k']/m
    expected_m={'x':[float(rational_record(p['moisture_kg_water_per_kg_dry_matter'])) for p in records],
        'y':[rs*368.15*math.log(float(rational_record(p['activity']['value']))) for p in records]}
    qr=[p for p in records if p['total_desorption_heat']['value'] is not None]
    expected_q={'x':[float(rational_record(p['moisture_kg_water_per_kg_dry_matter'])) for p in qr],
        'y':[float(rational_record(p['total_desorption_heat']['value'])) for p in qr]}
    check('D/source_nodes_correspondence',factor_nodes=={'m':expected_m,'q':expected_q,'mass':m,'T_ref':368.15})
    source95=ROOT/'data/sandbox/research/arlabosse95/source.json'
    check('D/source_reading_identity',all(p['source_sha256']==sha(source95) for p in records)
        and wet==prov['cells'][1]['wet_definition'] and water['backend']=='python')
    dfacts=read(ROOT/'data/sandbox/research/makela-moisture-v1/source.json')
    dmodel=read(ROOT/'data/sandbox/research/makela-moisture-v1/model.json')
    dprov=prov['moisture_transport']; dsnap=dprov['diffusivity']; dp=dsnap['provenance']
    dids=[dfacts['source_id'],dmodel['model_id'],dfacts['original_pdf']['sha256'],
        sha(ROOT/'data/sandbox/research/makela-moisture-v1/source.json'),sha(ROOT/'data/sandbox/research/makela-moisture-v1/model.json')]
    check('D/facts_model_snapshot',dp['source_facts']==dfacts and dp['model_definition']==dmodel
        and dsnap['source_ids']==dids and F(*dsnap['value_m2_s'])==F('8.56e-9')
        and dmodel['D_m2_s']==dfacts['selected_diffusivity_m2_s']=='8.56e-9')
    check('D/qualification',all(x['material_qualified'] is False and x['training_eligible'] is False for x in (dfacts,dmodel,dprov,dp))
        and all(v is None for v in dmodel['errors'].values()) and dmodel['full_firing_cycle'] is False
        and dsnap['input_classification']==dfacts['classification']==dmodel['classification']=='derived_from_evidence'
        and dfacts['alternative_printed_diffusivity_m2_s']=='8.57e-9')
    def interp(curve,w):
        for x0,x1,y0,y1 in zip(curve['x'],curve['x'][1:],curve['y'],curve['y'][1:]):
            x0,x1,y0,y1=map(F,(x0,x1,y0,y1))
            if x0<=w<=x1: return y0+(y1-y0)*(w-x0)/(x1-x0)
        raise ValueError('saved source node domain')
    def gamma_data(points):
        lp,rp=points; tf=(lp['temperature_k']+rp['temperature_k'])/2
        lo,hi=sorted((lp['moisture_kg_water_per_kg_dry'],rp['moisture_kg_water_per_kg_dry']))
        assert lo<hi, 'This registered case uses unequal W; no equal-W extension in passive audit.'
        r=tf/F(factor_nodes['T_ref']); M=F(m)
        change=lambda a,b:M*(r*(interp(factor_nodes['m'],b)-interp(factor_nodes['m'],a))-(1-r)*(interp(factor_nodes['q'],b)-interp(factor_nodes['q'],a)))
        knots=sorted({lo,hi,*[F(x) for c in ('m','q') for x in factor_nodes[c]['x'] if lo<F(x)<hi]})
        slopes=[change(a,b)/(b-a) for a,b in zip(knots,knots[1:])]
        return tf,(lo,hi),change(lo,hi)/(hi-lo),slopes
    def audit_context(label,states,mw,kpoints):
        for i,(state,mp,inv,phase,kp) in enumerate(zip(states,mw['points'],mw['inverses'],mw['phases'],kpoints)):
            p=inv['point']; liq=phase['equilibrium']['pure_equilibrium']['liquid']; native=liq['state']; ref=native['reference']
            residual=F(p['total_internal_energy_j'])-F(state['internal_energy_j'])
            check(label+f'/cell{i}/context',inv['target_energy_j']==state['internal_energy_j'] and inv['energy_residual_j']==residual
                and p['fluid']['mechanical']['liquid_inventory_mol']==state['liquid_water_mol']
                and [p['fluid']['mechanical']['gas_inventory_mol'][gas] for gas in ('O2','N2','H2O')]==state['gas_amounts_mol']
                and mp['temperature_k']==F(T(p))==F(kp['temperature_k'])==F(native['temperature_k'])
                and mp['pressure_pa']==F(P(p))==F(native['pressure_pa'])
                and mp['moisture_kg_water_per_kg_dry']==F(moisture(state))==F(p['moisture_kg_water_per_kg_dry']))
            check(label+f'/cell{i}/inverse_domain',abs(residual)+F(p['energy_error_j'])<=F(1e-5) and inv['temperature_error_bound_k']<=1e-6
                and 325<=T(p)<=338 and F(.3)<=mp['moisture_kg_water_per_kg_dry']<=F(.8)
                and 90000<=P(p)-p['pressure_error_pa'] and P(p)+p['pressure_error_pa']<=110000)
            u_limits.append(float(abs(residual)+F(p['energy_error_j'])));t_limits.append(inv['temperature_error_bound_k'])
            h=native['native_enthalpy_j_kg']*m+ref['energy_offset_j_mol']
            entropy=native['native_entropy_j_kg_k']*m
            mu=math.fsum((h,-native['temperature_k']*entropy))
            check(label+f'/cell{i}/pure_native_reference',ref==water['reference'] and native['implementation'] is None
                and native['method_id']=='iapws95_real_fluid_helmholtz' and native['phase']=='liquid'
                and liq['enthalpy_j_mol']==h and liq['entropy_j_mol_k']==entropy and liq['chemical_potential_j_mol']==mu)
            check(label+f'/cell{i}/full_mu_h',mp['chemical_potential_j_mol']==F(mu)+F(p['excess_chemical_potential_j_mol'])
                and mp['partial_molar_enthalpy_j_mol']==F(h)+F(p['excess_partial_water_enthalpy_j_mol'])
                and mp['water_molar_mass_kg_mol']==F(m) and mp['energy_reference_id']==mw['points'][0]['energy_reference_id']
                and mw['storage_identities'][i]==p['model_identity']==prov['cells'][i]['model_identity'])
            check(label+f'/cell{i}/phase_activity',phase['equilibrium']['activity']==p['activity']
                and phase['equilibrium']['equilibrium_partial_pressure_pa']==float(F(p['activity'])*F(phase['equilibrium']['pure_equilibrium']['equilibrium_partial_pressure_pa']))
                and abs(phase['equilibrium']['chemical_potential_residual_j_mol'])<=1e-7 and phase['entropy_production_w_k']>0)
        tf,interval,gamma,slopes=gamma_data(mw['points']); fac=mw['factor'];ex=mw['exchange'];lp,rp=mw['points']
        xt=1/rp['temperature_k']-1/lp['temperature_k'];xm=lp['chemical_potential_j_mol']/lp['temperature_k']-rp['chemical_potential_j_mol']/rp['temperature_k']
        hf=(lp['partial_molar_enthalpy_j_mol']+rp['partial_molar_enthalpy_j_mol'])/2; y=xm+hf*xt
        rhos=[F(s['solid_mass_kg'][0])/(F(prov['face_area_m2'])*F(width)) for s,width in zip(states,prov['cell_widths_m'])]
        gm=F(prov['face_area_m2'])*rhos[0]*F('8.56e-9')/(F(m)*(sum(map(F,prov['cell_widths_m']),F())/2)*gamma)
        mobility=tf*gm;ne=mobility*y;he=hf*ne;sig=mobility*y*y;rounded=F(ex['carried_energy_w'])*xt+F(ex['molar_flow_mol_s'])*xm
        check(label+'/gamma',fac['gamma_j_mol']==gamma and fac['temperature_k']==tf and fac['moisture_interval']==list(interval)
            and fac['method']=='declared_secant' and all(v>0 for v in slopes))
        check(label+'/rho_mobility',rhos[0]==rhos[1]==ex['dry_density_kg_m3'] and ex['chemical_conductance_mol2_j_s']==gm
            and ex['mobility_mol2_k_j_s']==mobility and ex['driving_force_j_mol_k']==y)
        check(label+'/rates_entropy',ex['exact_molar_flow_mol_s']==ne and ex['molar_flow_mol_s']==float(ne)
            and ex['exact_carried_energy_w']==he and ex['carried_energy_w']==float(he)
            and ex['exact_moisture_entropy_w_k']==sig and ex['moisture_entropy_w_k']==float(sig)
            and ex['rounded_rate_entropy_balance_w_k']==rounded and sig>0 and rounded>0)
        values={'dry_density_kg_m3':rhos[0],'factor_gamma_j_mol':gamma,'face_temperature_k':tf,
            'chemical_conductance_mol2_j_s':gm,'mobility_mol2_k_j_s':mobility,'face_enthalpy_j_mol':hf,
            'inverse_temperature_difference_1_k':xt,'chemical_force_j_mol_k':xm,'driving_force_j_mol_k':y,
            'molar_flow_mol_s':ne,'carried_energy_w':he,'moisture_entropy_w_k':sig}
        projections=ex['numerical_projections']
        check(label+'/all_projections',len(projections)==len(values) and {x['name'] for x in projections}==set(values)
            and all(x['exact']==values[x['name']] and x['binary64']==float(x['exact'])
                and x['absolute_projection_error']==abs(F(x['binary64'])-x['exact'])
                and math.isfinite(x['binary64']) and (x['exact']==0 or x['binary64']!=0) for x in projections))
        check(label+'/binding_flags',mw['source_state_binding_verified'] is True and ex['source_state_binding_verified'] is False
            and all(x['material_qualified'] is False and x['training_eligible'] is False for x in (mw,ex))
            and set(dids).issubset(ex['source_ids']) and mw['isothermal_fick_drive_residual_j_mol'] is None)
        return {'Gamma_j_mol':float(gamma),'positive_segment_slopes_j_mol':list(map(float,slopes)),
            'n_mol_s':float(ne),'H_w':float(he),'nominal_sigma_w_k':float(sig),'rounded_sigma_w_k':float(rounded)}
    def nominal(w):
        return nodes[0][1]+(nodes[1][1]-nodes[0][1])*(F(w)-nodes[0][0])/(nodes[1][0]-nodes[0][0])
    def moisture(s): return float(F(s['liquid_water_mol'])*F(m)/F(s['solid_mass_kg'][0]))
    def audit_k(label,point,state):
        w=moisture(state); expected=nominal(w); trace=json.loads(point['_provenance_json'])
        check(label+'/W',point['moisture_kg_water_per_kg_dry']==w)
        check(label+'/k',point['nominal_k_w_m_k']==expected and point['k_w_m_k']==float(expected)
              and point['binary64_projection_error_w_m_k']==abs(F(point['k_w_m_k'])-expected))
        check(label+'/domain',F(.3)<=F(w)<=F(.8) and F(308.15)<=F(point['temperature_k'])<=F(368.15))
        check(label+'/source',point['source_ids']==list(source_ids) and point['model_identity']==provider_id
              and trace['source_facts']==facts and trace['model_definition']==model)
        check(label+'/exact_coordinates',trace['evaluation_coordinates_exact']=={
              'temperature_k':[F(point['temperature_k']).numerator,F(point['temperature_k']).denominator],
              'moisture_kg_water_per_kg_dry':[F(w).numerator,F(w).denominator]})
        check(label+'/qualification',point['material_qualified'] is False and point['training_eligible'] is False
              and point['source_confidence_intervals_are_total_model_bounds'] is False
              and all(point[k] is None for k in ('interpolation_model_error','temperature_extension_model_error',
                   'pressure_extension_model_error','cross_material_transfer_error','total_model_uncertainty')))
    original('completed',run['status']=='completed' and run['reason'] is None)
    original('counts',len(run['states'])==3 and len(run['ledgers'])==len(run['observations'])==2 and run['evaluations_attempted']==run['evaluations_completed']==6)
    original('clock',run['times_s']==[F(),F(.05)/2,F(.05)])
    original('identity',run['model_identity']==prov['model_identity'])
    original('false_material',run['material_qualified'] is False)
    original('roundoff_energy_budget',run['energy_roundoff_used_j']<=F(1e-8))
    original('roundoff_inventory_budget',run['inventory_roundoff_used_mol']<=F(1e-12))
    cumulative={key:F() for key in ('U','W',0,1)}
    u_limits=[];t_limits=[];middle=[];inventory_cost=F();energy_floor=F()
    for n,(old,new,ledger,obs) in enumerate(zip(run['states'],run['states'][1:],run['ledgers'],run['observations'])):
        tag=f'step{n}'; dt=ledger['duration_s']; faces=ledger['faces']; f=faces[1]; witness=f['conductivity_witness']; err=ledger['roundoff']
        original(tag+'_clock',dt==run['times_s'][n+1]-run['times_s'][n])
        original(tag+'_closed',all(ff['energy_j']==0 and all(v==0 for v in ff['gas_mol']) for ff in (faces[0],faces[-1])))
        original(tag+'_active_heat',f['conduction_j']!=0)
        original(tag+'_middle_Q',f['conduction_j']==dt*F(witness['conduction_w']))
        original(tag+'_thermal_entropy',witness['entropy_production_w_k']>0)
        pl,pr=witness['conductivity_points']; dl,dr=(v/2 for v in prov['cell_widths_m']); area=prov['face_area_m2']
        G=F(area)/(F(dl)/F(pl['k_w_m_k'])+F(dr)/F(pr['k_w_m_k']))
        exactQ=G*(F(pl['temperature_k'])-F(pr['temperature_k']))
        kernelQ=area*((pl['temperature_k']-pr['temperature_k'])/(dl/pl['k_w_m_k']+dr/pr['k_w_m_k']))
        entropy=F(witness['conduction_w'])*(1/F(pr['temperature_k'])-1/F(pl['temperature_k']))
        original(tag+'_G',witness['conductance_w_k']==float(G))
        original(tag+'_actual_shared_Q',witness['conduction_w']==kernelQ)
        original(tag+'_thermal_arithmetic',witness['conduction_arithmetic_residual_w']==F(witness['conduction_w'])-exactQ)
        original(tag+'_entropy_value',witness['entropy_production_w_k']==float(entropy))
        original(tag+'_source_registration',set(source_ids).issubset(obs['source_ids']))
        check(tag+'/witness_false',witness['material_qualified'] is False)
        middle.append({'step':n,'W':[pl['moisture_kg_water_per_kg_dry'],pr['moisture_kg_water_per_kg_dry']],
            'k':[pl['k_w_m_k'],pr['k_w_m_k']],'T':[pl['temperature_k'],pr['temperature_k']],
            'G':float(G),'Q':kernelQ,'Q_arithmetic_residual_w':float(F(kernelQ)-exactQ),'sigma':float(entropy)})
        for i,kpoint in enumerate(witness['conductivity_points']):
            w=moisture(ledger['midpoint_states'][i]); expected=nominal(w)
            original(tag+f'_middle_W{i}',kpoint['moisture_kg_water_per_kg_dry']==w)
            original(tag+f'_source_k{i}',kpoint['nominal_k_w_m_k']==expected and kpoint['k_w_m_k']==float(expected))
            original(tag+f'_middle_not_endpoint{i}',kpoint['k_w_m_k']!=obs['conductivity_points'][i]['k_w_m_k'])
            original(tag+f'_source_false{i}',kpoint['material_qualified'] is False and kpoint['training_eligible'] is False)
            audit_k(tag+f'/middle{i}',kpoint,ledger['midpoint_states'][i])
            audit_k(tag+f'/endpoint{i}',obs['conductivity_points'][i],new[i])
            check(tag+f'/endpoint_T{i}',obs['conductivity_points'][i]['temperature_k']==T(obs['cells'][i]['inverse']['point']))
        original(tag+'_disabled_gas',all(v==0 for v in f['gas_mol']))
        original(tag+'_disabled_gas_enthalpy',all(v==0 for v in (*f['diffusive_enthalpy_j'],*f['advective_enthalpy_j'])))
        original(tag+'_active_phase',all(v!=0 for v in ledger['phase_water_mol']))
        mw=f['moisture_witness'];ex=mw['exchange'];lp,rp=mw['points']
        middle[-1]['moisture']=audit_context(tag+'/middle_moisture',ledger['midpoint_states'],mw,witness['conductivity_points'])
        ef=obs['faces'][1]; emw=ef['moisture_witness']
        audit_context(tag+'/endpoint_moisture',new,emw,obs['conductivity_points'])
        check(tag+'/endpoint_context_copy',emw['points']==obs['moisture_points']
            and emw['inverses']==[c['inverse'] for c in obs['cells']] and emw['phases']==[c['phase'] for c in obs['cells']])
        check(tag+'/endpoint_gas_disabled',all(v==0 for v in (*ef['gas_mol_s'],*ef['diffusive_enthalpy_w'],*ef['advective_enthalpy_w'])))
        original(tag+'_active_moisture',f['moisture_mol']!=0 and f['moisture_enthalpy_j']!=0)
        original(tag+'_middle_moisture',f['moisture_mol']==dt*F(ex['molar_flow_mol_s']))
        original(tag+'_middle_carried_energy',f['moisture_enthalpy_j']==dt*F(ex['carried_energy_w']))
        original(tag+'_moisture_projection',f['moisture_molar_projection_mol']==f['moisture_mol']-dt*ex['exact_molar_flow_mol_s']
            and f['moisture_enthalpy_projection_j']==f['moisture_enthalpy_j']-dt*ex['exact_carried_energy_w'])
        tf,interval,gamma,slopes=gamma_data(mw['points'])
        xt=1/rp['temperature_k']-1/lp['temperature_k'];xm=lp['chemical_potential_j_mol']/lp['temperature_k']-rp['chemical_potential_j_mol']/rp['temperature_k']
        hf=(lp['partial_molar_enthalpy_j_mol']+rp['partial_molar_enthalpy_j_mol'])/2;y=xm+hf*xt
        rho=F(initial[0]['solid_mass_kg'][0])/(F(area)*F(prov['cell_widths_m'][0]))
        distance=sum(map(F,prov['cell_widths_m']),F())/2;gm=F(area)*rho*F('8.56e-9')/(F(m)*distance*gamma)
        original(tag+'_moisture_factor',mw['factor']['gamma_j_mol']>0 and mw['factor']['temperature_k']==tf)
        original(tag+'_actual_source_gamma',mw['factor']['gamma_j_mol']==gamma)
        original(tag+'_moisture_mobility',ex['chemical_conductance_mol2_j_s']==gm and ex['mobility_mol2_k_j_s']==tf*gm)
        original(tag+'_moisture_exact_rates',ex['exact_molar_flow_mol_s']==tf*gm*y and ex['exact_carried_energy_w']==hf*tf*gm*y)
        original(tag+'_moisture_entropy',ex['exact_moisture_entropy_w_k']==tf*gm*y*y
            and ex['rounded_rate_entropy_balance_w_k']==F(ex['carried_energy_w'])*xt+F(ex['molar_flow_mol_s'])*xm and ex['rounded_rate_entropy_balance_w_k']>0)
        original(tag+'_moisture_binding',mw['source_state_binding_verified'] and not mw['material_qualified'] and not mw['training_eligible'])
        original(tag+'_moisture_sources',set(dids).issubset(obs['source_ids']))
        for i,mp in enumerate(mw['points']):
            inv=mw['inverses'][i];sp=inv['point'];pure=mw['phases'][i]['equilibrium']['pure_equilibrium']['liquid'];mid=ledger['midpoint_states'][i]
            original(tag+f'_moisture_middle_W{i}',mp['moisture_kg_water_per_kg_dry']==F(moisture(mid)))
            original(tag+f'_moisture_middle_TP{i}',mp['temperature_k']==F(T(sp))==F(witness['conductivity_points'][i]['temperature_k'])==F(pure['state']['temperature_k'])
                and mp['pressure_pa']==F(P(sp))==F(pure['state']['pressure_pa']))
            original(tag+f'_moisture_middle_full_mu{i}',mp['chemical_potential_j_mol']==F(pure['chemical_potential_j_mol'])+F(sp['excess_chemical_potential_j_mol']))
            original(tag+f'_moisture_middle_full_h{i}',mp['partial_molar_enthalpy_j_mol']==F(pure['enthalpy_j_mol'])+F(sp['excess_partial_water_enthalpy_j_mol']))
            original(tag+f'_moisture_middle_inverse{i}',inv['target_energy_j']==mid['internal_energy_j']
                and inv['energy_residual_j']==F(sp['total_internal_energy_j'])-F(mid['internal_energy_j'])
                and abs(inv['energy_residual_j'])+F(sp['energy_error_j'])<=F(1e-5) and inv['temperature_error_bound_k']<=1e-6)
        for i,(mp,cell) in enumerate(zip(obs['moisture_points'],obs['cells'])):
            sp=cell['inverse']['point'];pure=cell['phase']['equilibrium']['pure_equilibrium']['liquid']
            original(tag+f'_moisture_full_mu{i}',mp['chemical_potential_j_mol']==F(pure['chemical_potential_j_mol'])+F(sp['excess_chemical_potential_j_mol']))
            original(tag+f'_moisture_full_h{i}',mp['partial_molar_enthalpy_j_mol']==F(pure['enthalpy_j_mol'])+F(sp['excess_partial_water_enthalpy_j_mol']))
        inventory_cost+=abs(f['moisture_molar_projection_mol'])
        energy_floor+=abs(f['moisture_enthalpy_projection_j'])
        for ff in faces:
            original(tag+f"_face{ff['face_id']}_energy",ff['energy_j']==ff['conduction_j']+sum(ff['diffusive_enthalpy_j'],F())+sum(ff['advective_enthalpy_j'],F())+ff['energy_decomposition_roundoff_j']+ff.get('moisture_enthalpy_j',F()))
        for i,(before,after,cell) in enumerate(zip(old,new,obs['cells'])):
            label=tag+f'_cell{i}'; left,right=faces[i:i+2]; inv=cell['inverse']; p=inv['point']; eq=cell['phase']['equilibrium']
            residual=F(p['total_internal_energy_j'])-F(after['internal_energy_j'])
            original(label+'_U_ledger',F(after['internal_energy_j'])-F(before['internal_energy_j'])==left['energy_j']-right['energy_j']+err['energy_j'][i])
            original(label+'_Nc_ledger',F(after['liquid_water_mol'])-F(before['liquid_water_mol'])==left.get('moisture_mol',F())-right.get('moisture_mol',F())-ledger['phase_water_mol'][i]+err['liquid_mol'][i])
            for k in range(3):
                original(label+f'_gas{k}_ledger',F(after['gas_amounts_mol'][k])-F(before['gas_amounts_mol'][k])==left['gas_mol'][k]-right['gas_mol'][k]+(ledger['phase_water_mol'][i] if k==2 else F())+err['gas_mol'][i][k])
            original(label+'_actual_target',inv['target_energy_j']==after['internal_energy_j'] and inv['energy_residual_j']==residual)
            u_limit=abs(residual)+F(p['energy_error_j']);u_limits.append(float(u_limit));t_limits.append(inv['temperature_error_bound_k'])
            original(label+'_inverse_U',u_limit<=F(1e-5))
            original(label+'_inverse_T',inv['temperature_error_bound_k']<=1e-6)
            original(label+'_T_domain',325<=T(p)<=338)
            original(label+'_W_domain',.30<=p['moisture_kg_water_per_kg_dry']<=.8)
            original(label+'_P_domain',90000<=P(p)-p['pressure_error_pa'] and P(p)+p['pressure_error_pa']<=110000)
            original(label+'_actual_liquid_P',eq['pure_equilibrium']['liquid']['state']['pressure_pa']==P(p))
            original(label+'_aw',eq['equilibrium_partial_pressure_pa']==float(F(p['activity'])*F(eq['pure_equilibrium']['equilibrium_partial_pressure_pa'])))
            original(label+'_mu',abs(eq['chemical_potential_residual_j_mol'])<=1e-7)
            original(label+'_entropy',cell['phase']['entropy_production_w_k'] is not None and cell['phase']['entropy_production_w_k']>0)
            original(label+'_positive',after['liquid_water_mol']>0 and all(v>=0 for v in after['gas_amounts_mol']))
            original(label+'_false_flags',p['material_qualified'] is False and p['training_eligible'] is False)
            check(label+'/inventory_binding',p['fluid']['mechanical']['liquid_inventory_mol']==after['liquid_water_mol']
                  and list(p['fluid']['mechanical']['gas_inventory_mol'].values())==after['gas_amounts_mol'])
            check(label+'/point_W',p['moisture_kg_water_per_kg_dry']==moisture(after))
        errors={'U':sum(err['energy_j'],F()),'W':sum(err['liquid_mol'],F())+sum((v[2] for v in err['gas_mol']),F())}
        errors.update({k:sum((v[k] for v in err['gas_mol']),F()) for k in range(2)})
        for kind,e in errors.items():
            cumulative[kind]+=e
            suffix=kind if isinstance(kind,str) else f'gas{kind}'
            original(tag+('_global_'+suffix if isinstance(kind,str) else '_'+suffix+'_global'),total(new,kind)-total(old,kind)==e)
            original(tag+('_prefix_'+suffix if isinstance(kind,str) else '_'+suffix+'_prefix'),total(new,kind)-total(initial,kind)==cumulative[kind])
        for e in (err,ledger['predictor_roundoff']):
            inventory_cost+=sum(map(abs,e['liquid_mol']),F())+sum((sum(map(abs,row),F()) for row in e['gas_mol']),F())
            energy_floor+=sum(map(abs,e['energy_j']),F())
        energy_floor+=sum((abs(ff['energy_decomposition_roundoff_j']) for ff in faces),F())
    for i,(first,cell,state) in enumerate(zip(ini['points'],run['observations'][-1]['cells'],run['states'][-1])):
        p=cell['inverse']['point']
        original(f'cell{i}_resolved_delta_T',abs(T(p)-T(first))>cell['inverse']['temperature_error_bound_k']+1e-6)
        original(f'cell{i}_changed_Nc',state['liquid_water_mol']!=initial[i]['liquid_water_mol'])
        original(f'cell{i}_changed_P',P(p)!=P(first))
        original(f'cell{i}_evolving_k',run['observations'][-1]['conductivity_points'][i]['k_w_m_k']!=float(nominal(first['moisture_kg_water_per_kg_dry'])))
    original('integrator_wall',run['elapsed_seconds']<60.)
    original('whole_driver_wall',a['driver_seconds']<80.)
    check('record/original_count_unique',len(RECOMPUTED)==len(a['checks']) and len({c['id'] for c in a['checks']})==len(a['checks']))
    check('record/original_correspondence',{c['id']:c['passed'] for c in a['checks']}==RECOMPUTED and a['passed'] is True)
    check('record/inventory_charge_saved_floor',inventory_cost<=run['inventory_roundoff_used_mol'])
    check('record/energy_charge_saved_floor',energy_floor<=run['energy_roundoff_used_j'])
    check('record/budget_metadata',run['energy_roundoff_budget_j']==1e-8 and run['inventory_roundoff_budget_mol']==1e-12)
    check('record/summary',a['integrator_seconds']==run['elapsed_seconds'] and a['evaluations']==6 and a['model_duration_seconds']==.05
        and a['final_temperature_k']==[T(c['inverse']['point']) for c in run['observations'][-1]['cells']]
        and a['final_pressure_pa']==[P(c['inverse']['point']) for c in run['observations'][-1]['cells']]
        and a['material_qualified'] is False and a['spatial_temporal_convergence_demonstrated'] is False)
    check('supervisor/complete',status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] is True and status['cleanup']['signal_errors']==[])
    check('supervisor/scope',status['cleanup']['scope']=='original_process_group_only; escaped_sessions_not_contained')
    check('supervisor/resources',meta['timeout_s']==100. and meta['cleanup_grace_s']==5. and status['elapsed_s']<105. and a['driver_seconds']<=status['elapsed_s'])
    check('supervisor/isolated_command',meta['command']==['/usr/bin/env','-u','PYTHONPATH','/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python','-I',str(WORK/'native_driver.py')])
    before_input={k:v['sha256'] for k,v in meta['inputs_before'].items()}
    check('supervisor/input_before_after',before_input==status['inputs_after'] and status['inputs_unchanged'] is True)
    required=[WORK/n for n in ('native_driver.py','native_case.py','run_supervised_native01.py','NATIVE_PLAN.md','install/SOURCE_FREEZE.json')]
    required += [ROOT/f'data/sandbox/research/{case}/{name}.json' for case in ('makela-moisture-v1','septien-conductivity-v1') for name in ('source','model')]
    required += [ROOT/'runs/sandbox/source-cache/makela2016/makela2016-accepted.pdf',ROOT/'runs/sandbox/source-cache/septien2020/fecal2019-original.xml']
    check('supervisor/physics_protocol_assets_bound',all(str(path) in before_input for path in required)
        and all(sha(path)==before_input[str(path)] for path in required if path.suffix not in ('.pdf','.xml'))
        and before_input[str(required[-2])]==dids[2] and before_input[str(required[-1])]==source_ids[2])
    coverage={}
    for key,needle in {'source_package':'/src/sludge_sandbox/', 'installed_package':'/site-packages/sludge_sandbox/',
        'numpy':'/site-packages/numpy/', 'scipy':'/site-packages/scipy/','iapws':'/site-packages/iapws/',
        'numpy_metadata':'/site-packages/numpy-', 'scipy_metadata':'/site-packages/scipy-', 'iapws_metadata':'/site-packages/iapws-',
        'water_sources':'/data/sandbox/water/', 'gas_sources':'/data/sandbox/thermochemistry/', 'arlabosse_sources':'/arlabosse'}.items():
        coverage[key]=sum(needle in name for name in before_input)
    check('supervisor/input_category_coverage',all(coverage[key]>0 for key in ('source_package','installed_package','numpy','scipy','iapws',
        'numpy_metadata','scipy_metadata','iapws_metadata','water_sources','arlabosse_sources'))
        and any(Path(p).name=='pyvenv.cfg' for p in before_input)
        and str(Path(meta['command'][3]).resolve()) in before_input)
    before=read(WORK/'install/INSTALL_IDENTITY_BEFORE_TESTS.json'); after=read(WORK/'install/INSTALL_IDENTITY_AFTER_TESTS.json')
    check('install/record_match',before==after and before['passed'] is True and before['file_count']==len(freeze)
        and before['source']==before['installed']==before['frozen']==freeze)
    installed=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
    source_now={name:sha(ROOT/'src/sludge_sandbox'/name) for name in freeze}
    installed_now={name:sha(installed/name) for name in freeze}
    check('install/current_frozen_identity',source_now==installed_now==freeze)
    check('install/freeze_supervisor_coverage',all(before_input[str(ROOT/'src/sludge_sandbox'/name)]==before_input[str(installed/name)]==expected for name,expected in freeze.items()))
    for name,expected in read(WORK/'host-review/HOST_FINAL_SNAPSHOT.json')['files'].items():
        check('reviewed_candidate/'+name,sha(ROOT/name)==expected)
    xmlpath=WORK/'install/INSTALLED_TESTS01.xml';INPUTS[str(xmlpath)]=sha(xmlpath)
    suite=ET.parse(xmlpath).getroot().find('testsuite')
    check('install/130_tests',suite.get('tests')=='130' and suite.get('failures')==suite.get('errors')==suite.get('skipped')=='0')
    test_groups={}
    for test in suite.findall('testcase'):
        group=test.get('classname');test_groups[group]=test_groups.get(group,0)+1
    install_failure=(WORK/'install/INSTALL01.log').read_text(); install_success=(WORK/'install/INSTALL02.log').read_text()
    for name in ('install/INSTALL01.log','install/INSTALL02.log','install/INSTALLED_TESTS01.log','host-review/INDEPENDENT_RED01.xml','code-review/INDEPENDENT_RED01.xml'):
        INPUTS[str(WORK/name)]=sha(WORK/name)
    check('install/failed_attempt_preserved',"No module named 'setuptools'" in install_failure and 'Built sludge-vme' in install_success)
    check('record/terminal_files',not (WORK/'native01/FAILURE.json').exists() and read(WORK/'supervised-native01/stdout.log')==a)
    trace_path=ROOT/'docs/sandbox/research/source-sorption-moisture-v1/TRACE.csv'
    face_path=ROOT/'docs/sandbox/research/source-sorption-moisture-v1/FACE_TRACE.csv'
    def csv_read(path):
        INPUTS[str(path)]=sha(path)
        with path.open(newline='') as stream:
            rows=list(csv.reader(stream))
        return rows[0],[[float(x) for x in row] for row in rows[1:]]
    trace_header,trace_rows=csv_read(trace_path);face_header,face_rows=csv_read(face_path)
    expected_trace=[];expected_faces=[]
    for step,(t,states) in enumerate(zip(run['times_s'],run['states'])):
        points=ini['points'] if step==0 else [c['inverse']['point'] for c in run['observations'][step-1]['cells']]
        for i,(state,p) in enumerate(zip(states,points)):
            w=moisture(state)
            expected_trace.append([float(t),i,T(p),w,P(p),state['liquid_water_mol'],state['gas_amounts_mol'][2],state['internal_energy_j'],float(nominal(w))])
    for step,ledger in enumerate(run['ledgers']):
        face=ledger['faces'][1];mw=face['moisture_witness'];ex=mw['exchange']
        expected_faces.append([step,float(ledger['duration_s']),ex['molar_flow_mol_s'],ex['carried_energy_w'],face['conductivity_witness']['conduction_w'],
            float(mw['factor']['gamma_j_mol']),ex['moisture_entropy_w_k'],float(ex['rounded_rate_entropy_balance_w_k']),float(face['moisture_mol']),float(face['moisture_enthalpy_j'])])
    check('export/TRACE',trace_header==['t_s','cell','T_K','W_kg_kg_dry','P_Pa','Nc_mol','Nv_mol','U_J','k_W_m_K'] and trace_rows==expected_trace)
    check('export/FACE_TRACE',face_header==['step','dt_s','n_mol_s','carried_W','conduction_W','Gamma_J_mol','nominal_entropy_W_K','rounded_entropy_W_K','water_integral_mol','carried_integral_J'] and face_rows==expected_faces)
    summary=read(WORK/'DERIVED_SUMMARY.json')
    expected_summary={'status':run['status'],'reason':run['reason'],'acceptance_passed':a['passed'],'checks':len(a['checks']),
        'states':len(run['states']),'steps':len(run['ledgers']),'evaluations':run['evaluations_completed'],
        'final_temperature_k':a['final_temperature_k'],'final_pressure_pa':a['final_pressure_pa'],
        'max_inverse_residual_plus_error_j':max(u_limits),'max_inverse_temperature_bound_k':max(t_limits),
        'energy_roundoff_used_j':float(run['energy_roundoff_used_j']),'inventory_roundoff_used_mol':float(run['inventory_roundoff_used_mol']),
        'midpoint_molar_flow_mol_s':[row[2] for row in expected_faces],'midpoint_carried_energy_w':[row[3] for row in expected_faces],
        'integrator_seconds':a['integrator_seconds'],'driver_seconds':a['driver_seconds'],
        'material_qualified':False,'training_eligible':False,'convergence_demonstrated':False,'goal_complete':False}
    check('export/DERIVED_SUMMARY',summary==expected_summary)
    check('audit/records_unchanged',all(sha(Path(p))==value for p,value in INPUTS.items()))
    SUMMARY={'original_checks_recomputed':len(RECOMPUTED),'original_input_count':len(before_input),'input_coverage':coverage,
        'frozen_installed_file_count':len(freeze),'frozen_python_module_count':sum(p.endswith('.py') for p in freeze),
        'installed_test_count':int(suite.get('tests')),'installed_test_seconds':float(suite.get('time')),'installed_test_groups':test_groups,
        'integration_steps':len(run['ledgers']),'rhs_attempted':run['evaluations_attempted'],'rhs_completed':run['evaluations_completed'],
        'model_duration_s':float(run['times_s'][-1]),'integrator_seconds':run['elapsed_seconds'],'driver_seconds':a['driver_seconds'],'supervisor_seconds':status['elapsed_s'],
        'max_midpoint_and_accepted_inverse_U_plus_error_j':max(u_limits),'max_midpoint_and_accepted_inverse_T_bound_k':max(t_limits),
        'final_temperature_k':a['final_temperature_k'],'final_pressure_pa':a['final_pressure_pa'],
        'delta_temperature_k':[T(c['inverse']['point'])-T(p) for c,p in zip(run['observations'][-1]['cells'],ini['points'])],
        'middle_thermal_and_moisture':middle,'energy_roundoff_used_j':float(run['energy_roundoff_used_j']),
        'inventory_roundoff_used_mol':float(run['inventory_roundoff_used_mol']),
        'saved_energy_charge_floor_j':float(energy_floor),'saved_inventory_charge_floor_mol':float(inventory_cost),
        'budget_scope':'Saved charged totals and visible term lower bounds only; initial predictor face rates/projections/decompositions absent, so complete independent debit reconstruction is not claimed.',
        'midpoint_scope':'Actual midpoint inverse and phase records verified against midpoint conserved inventories, target U, actual T/P and source full mu/h; no EOS rerun.',
        'source_scope':'Source factor nodes rebuilt from saved source readouts, source IDs and supervision-bound source/facts/model checked; no new literature reading or independent EOS certification.',
        'csv':{'TRACE_rows':len(trace_rows),'TRACE_numeric_values':sum(map(len,trace_rows)),'FACE_TRACE_rows':len(face_rows),'FACE_TRACE_numeric_values':sum(map(len,face_rows))},
        'material_qualified':False,'training_eligible':False,'full_firing_cycle':False,'spatial_temporal_convergence_demonstrated':False}
except BaseException as exc:
    CHECKS.append({'id':'audit_exception','passed':False,'exception':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
report={'passed':all(c['passed'] for c in CHECKS),'check_count':len(CHECKS),'failed_count':sum(not c['passed'] for c in CHECKS),
    'elapsed_seconds':time.monotonic()-START,'summary':SUMMARY,'checks':CHECKS,'inputs':INPUTS,'audit_script_sha256':sha(Path(__file__))}
with (OUT/'SAVED_REVIEW01.json').open('x') as f: json.dump(report,f,indent=2,default=default);f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('checks','inputs')},indent=2,default=default))
for c in CHECKS:
    if not c['passed']: print('FAILED',json.dumps(c))
raise SystemExit(0 if report['passed'] else 1)
