"""Bounded independent host probes using only the existing manufactured fluid seams."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_source_sorption_moisture import setup
from sludge_sandbox.source_sorption_moisture import condensed_water_point

@pytest.fixture(scope='module')
def case():
    patch=pytest.MonkeyPatch()
    try:
        column,states=setup(patch)
        yield column,states,column.evaluate(states)
    finally:patch.undo()

@pytest.mark.parametrize('kind',['chemical_potential','energy_reference'])
def test_public_exchange_does_not_attest_unbound_replaced_points(case,kind):
    column,states,rates=case
    points=rates.moisture_points
    if kind=='chemical_potential':
        points=tuple(replace(p,chemical_potential_j_mol=p.chemical_potential_j_mol+F(1000)) for p in points)
    else:
        points=tuple(replace(p,energy_reference_id='manufactured:unrelated_common_reference') for p in points)
    try:
        witness=column.moisture_transport.exchange(column.storages,points,area_m2=column.face_area_m2,
            widths_m=column.cell_widths_m,geometry_sources=column.coefficient_source_ids)
    except ValueError:
        return
    assert witness.source_state_binding_verified is False


def test_adapter_reuses_actual_phase_liquid_without_another_eos(case,monkeypatch):
    column,states,rates=case
    def forbidden(*args,**kwargs):raise AssertionError('unexpected EOS callback')
    monkeypatch.setattr(type(column.chemical),'liquid_tp',forbidden)
    for storage,state,cell,p in zip(column.storages,states,rates.cells,rates.moisture_points):
        assert condensed_water_point(storage,column.chemical,state,cell.inverse,cell.phase)==p


def test_modified_full_pure_chemical_quantities_are_rejected(case):
    column,states,rates=case
    c=rates.cells[0];eq=c.phase.equilibrium;pure=eq.pure_equilibrium.liquid
    bad=replace(c.phase,equilibrium=replace(eq,pure_equilibrium=replace(eq.pure_equilibrium,
        liquid=replace(pure,enthalpy_j_mol=pure.enthalpy_j_mol+1))))
    with pytest.raises(ValueError,match='moisture_pure_liquid_state_or_reference_mismatch'):
        condensed_water_point(column.storages[0],column.chemical,states[0],c.inverse,bad)
