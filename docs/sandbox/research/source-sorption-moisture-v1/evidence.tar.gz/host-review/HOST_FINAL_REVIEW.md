# 凝聚水迁移实际适配与 Column 独立审查

APPROVE。当前实际 adapter、Column 接线和相变校验函数提取无未解决问题。此结论不替代后续唯一原生路径、保存结果和收敛检查。叶子本身已另行审查，本轮未重复其整套验证。

## 实际发现与最终验证

[HIGH，已关闭] 初稿 `MakelaMoistureTransport.exchange(storages,points,...)` 未复核实际 state/inverse/phase，却直接返回 `source_state_binding_verified=True`。在实际制造 host 产生的点上，仅将两侧μ加1000 J/mol而不改h，或同时替换无关能量参考标签，公开接口仍输出已绑定标记。独立真实 RED 为 2 failed / 2 passed，2.12 s，原脚本保存在 INDEPENDENT_RED_TEST01.py，原日志/XML保留。

修复后公开 exchange 要求两侧真实 state/inverse/phase 和实际 chemical；无 EOS 地重新调用 condensed_water_point，并要求与 supplied points 完全相同，随后才显式设 verified=True。SourceMoistureWitness 默认false。独立复测传入了**完整上下文**再篡改两点，确认两种情况均被拒绝，正常完整上下文仍被接受；不是用“缺参数错误”替代修复验证。

最终 INDEPENDENT_GREEN02 为 **7 passed / 0 failed，2.85 s**。包括两项篡改拒绝、复用原phase液态不触发 liquid_tp、pure enthalpy篡改拒绝、真实上下文正常绑定且保留同一 inverse/phase 对象，以及 n/H 两种新增通量投影预算门。

预算探针保留真实制造面结果，仅冻结 operator 返回来隔离控制器收费逻辑；原 `_integrals`、state写回和预算提交顺序均实际执行。把限制设置在“含/不含新增通量投影”成本之间时，n或H两种预算都在第二次评价后拒绝、0接受步。不是另跑真实物理轨迹，也不能用该冻结operator结果证明温度反解。

已读取作者 factor-tests 原日志/XML：14 passed，0.15 s，涵盖 m/q不同节点、仅q节点、跨段整体割线正但内部Γ非正、单侧非正但均值正、节点两侧配对和半ULP精确Tf。已读取 ROOT HOST_TESTS01：16 passed，44.67 s；该批早于后续绑定/Γ/记录补正，不将它表述为最终字节全套回归。最终安装回归由 ROOT 另行执行。

## 物理与接口对应

- condensed_water_point 校验实际 storage/state、精确 inverse target/residual 及液/气库存；提取的 check_sorption_point 保留原同源水/模型、T、P±error、平面液压、库存W和µex/aw/偏焓一致性检查。复用实际相变返回的纯液态并重算 `_liquid` μ/h，要求同一实际 T/P、原 reference 对象和 implementation。新增完整摩尔 μ=纯液μ+摩尔excess，完整摩尔 h=纯液h+摩尔excess偏焓；没有混用J/kg、只取excess或拿固定1bar代替格压。
- Γ取精确Tf=(TL+TR)/2及当前表示W；m/q联合节点切段逐段要求正，不能由正的整体割线掩盖不稳定内部段。同W使用明确单侧/正侧对称平均。等T/P下，非零ΔW而完整Δμ塌缩或反向会拒绝；δμ=实际完整Δμ−ΓΔW被明确保留，不把已投影驱动称为无限精度Fick恒等式。Γ来源由实际wet节点绑定。
- controlled总体积为 A×格宽，ρ=md/总体积且两侧精确相同；不用可用流体孔体积。新配置严格实际类型、依赖原动态k、保持静态k=0，并要求三种气体面扩散和Darcy全部关闭。凝聚水Darcy及干界面依然不可混入；旧None分支与旧精确/程序类型边界保持。
- 每次 inverse/phase 后逐格构造真实迁水点，N=1也检查源和W；每面通过完整上下文再次核对，不只根据来源字符串授予资格。PDF/facts/model快照在 binding/_check 重读校验，Column最终状态检查再次覆盖源身份。这里证明同一进程内来源和记录对应，未声明可认证任意外部伪造EOS结果。
- 共享面总能量只取旧共享Q加一次迁水H，新增n通过同一个凝聚水Nc写回路径两侧反号；本地相变仍只搬Nc/Nv，没有新水库存、潜热源或额外pΔV功。积分保留原sharedfloat n/H、exact值和投影，面总能量分解残差独立记录，投影成本计入原预算。
- 接受步直接保留实际middle的thermal与moisture witness；最新增量进一步存同一已求解inverse/phase对象，无第二次EOS。后续可以从真正保存的中点证书核T/P/完整μ/h和inverse门；不是由末态补造。材料/训练资格仍false；叶子子记录source_state_binding_verified保持false，只有完成实际上下文检查的上层witness为true。

## 范围与限制

测试为制造流体回调、实际文件/类/控制器路径；审查者未执行EOS、原生积分、安装或修改生产。瞬时名义/实际浮点面熵、共享U/水算术与源绑定均不等于整个离散步总熵增长或收敛。表观总失水D的凝聚路径分配、温压/湿度冻结和跨材料误差仍未知，几何/本地相变系数保留制造标签。没有升级完整烧结模型或材料资格。

## 当前最终字节

| 文件 | SHA256 |
|---|---|
| `src/sludge_sandbox/source_sorption_moisture.py` | `b0da48cbd12a53f17b3af6420fa2e156b545be7eda2bb553b95e2fe5241c3177` |
| `src/sludge_sandbox/source_wet_column.py` | `4f5284fa20ba5984a2c65143388639be7242b03870dba5cc8bdc145d7cf30a48` |
| `src/sludge_sandbox/arlabosse_sorption_phase.py` | `25beee27ad64106b095bfcda425703b03e487010ac3f5a225551db522f80d9f5` |
| `tests/sandbox/test_source_sorption_moisture.py` | `703532626f68ba91849923c4f48162d431d38b52aa5f25ac57d4cdf850492f00` |
| `tests/sandbox/test_source_sorption_moisture_factor.py` | `d33edf47e5894d7af703d09fc3efbbaf8761d814b17d13d3987c2ee3214986d5` |

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — 当前有限实现审查完成，原生执行和保存结果仍需单独验收。
