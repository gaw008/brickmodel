"""Passive CSV/summary readout of the unique saved run; no model calls."""
import csv,json
from fractions import Fraction as F
from pathlib import Path
W=Path('/private/tmp/sludge-sorption-moisture-v1')
D=Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/source-sorption-moisture-v1')
def load(name): return json.loads((W/'native01'/name).read_bytes())
def rat(v): return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)
r=load('RUN.json');i=load('INITIAL.json');a=load('ACCEPTANCE.json')
rows=[]
for step,(t,states) in enumerate(zip(r['times_s'],r['states'])):
    points=i['points'] if step==0 else [c['inverse']['point'] for c in r['observations'][step-1]['cells']]
    for cell,(st,p) in enumerate(zip(states,points)):
        m=p['fluid']['mechanical']; w=F(p['moisture_kg_water_per_kg_dry'])
        k=F('.056')+F('.006')*(w-F(23,77))/(F(47,53)-F(23,77))
        if step: assert float(k)==r['observations'][step-1]['conductivity_points'][cell]['k_w_m_k']
        rows.append([float(rat(t)),cell,m['temperature_k'],float(w),m['pressure_pa'],st['liquid_water_mol'],st['gas_amounts_mol'][2],st['internal_energy_j'],float(k)])
with (D/'TRACE.csv').open('w',newline='') as f:
    writer=csv.writer(f);writer.writerow(['t_s','cell','T_K','W_kg_kg_dry','P_Pa','Nc_mol','Nv_mol','U_J','k_W_m_K']);writer.writerows(rows)
faces=[]; inverses=[c['inverse'] for o in r['observations'] for c in o['cells']]
for j,l in enumerate(r['ledgers']):
    f=l['faces'][1]; w=f['moisture_witness'];e=w['exchange'];inverses.extend(w['inverses'])
    faces.append([j,float(rat(l['duration_s'])),e['molar_flow_mol_s'],e['carried_energy_w'],f['conductivity_witness']['conduction_w'],float(rat(w['factor']['gamma_j_mol'])),e['moisture_entropy_w_k'],float(rat(e['rounded_rate_entropy_balance_w_k'])),float(rat(f['moisture_mol'])),float(rat(f['moisture_enthalpy_j']))])
with (D/'FACE_TRACE.csv').open('w',newline='') as f:
    writer=csv.writer(f);writer.writerow(['step','dt_s','n_mol_s','carried_W','conduction_W','Gamma_J_mol','nominal_entropy_W_K','rounded_entropy_W_K','water_integral_mol','carried_integral_J']);writer.writerows(faces)
summary={'status':r['status'],'reason':r['reason'],'acceptance_passed':a['passed'],'checks':len(a['checks']),
 'states':len(r['states']),'steps':len(r['ledgers']),'evaluations':r['evaluations_completed'],
 'final_temperature_k':a['final_temperature_k'],'final_pressure_pa':a['final_pressure_pa'],
 'max_inverse_residual_plus_error_j':float(max(abs(rat(v['energy_residual_j']))+F(v['point']['energy_error_j']) for v in inverses)),
 'max_inverse_temperature_bound_k':max(v['temperature_error_bound_k'] for v in inverses),
 'energy_roundoff_used_j':float(rat(r['energy_roundoff_used_j'])),
 'inventory_roundoff_used_mol':float(rat(r['inventory_roundoff_used_mol'])),
 'midpoint_molar_flow_mol_s':[row[2] for row in faces],'midpoint_carried_energy_w':[row[3] for row in faces],
 'integrator_seconds':a['integrator_seconds'],'driver_seconds':a['driver_seconds'],
 'material_qualified':False,'training_eligible':False,'convergence_demonstrated':False,'goal_complete':False}
(W/'DERIVED_SUMMARY.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(json.dumps(summary,indent=2))
