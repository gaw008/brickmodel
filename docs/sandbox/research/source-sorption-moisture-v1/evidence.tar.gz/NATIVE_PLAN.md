# Unique sourced sorption-moisture native01

Registered before execution, base 7b78528. Final production code must pass the
independent host review and related installed tests. Freeze source and installed
identities before the unique actual run. No new native probe; reuse measured
3.428046 s/operator and 20.462983 s/six-call sourced-heat segment costs.

Same actual two-cell case, Python water backend, initial inventory/U/T,
geometry/dry masses, source k(W), local phase coefficients, and original inverse
policies as source-conductivity-column-v1. Explicit new constitutive selection:
Mäkelä apparent total-loss D=8.56e-9 m²/s drives the same condensed Nc inventory,
with actual full μ/h and positive source Γ; disable all three gas face
 diffusivities and Darcy permeability to avoid double counting this D. The
allocation is an unmeasured conditional model, not phase-specific measured D.
No separate latent source, extra water pool, or temperature overwrite.

Exactly two midpoint steps over represented .05 s, six RHS. Retain 60 s
integrator, 80 s driver, 100 s supervisor, 5 s cleanup limits. Preserve 1e-5 J /
1e-6 K inverse gates, 1e-8 J /1e-12 mol arithmetic budgets and the original
resolved final temperature-change gate (> final inverse bound +1e-6 K).
Run/initial/accepted prefix are saved before any acceptance; original failures
remain, no threshold changes or identical rerun after success.

Verify previous clock/positivity/T/P/water-U-inert and source-k checks, with new
W lower domain .30. Replace previously required nonzero gas exchange by exact
zero gas exchange, add actual Nc face term and carried energy to balances.
Require nonzero moisture, carried energy and phase transfer, true middle
points/W/k/n/H correspondence, source identity, exact Γ/Tf/Gμ/Lm/Y/n/H/entropy
arithmetic and actual projected-rate entropy >0. Retain separate flow/energy
projections in integrals and arithmetic budgets. Full actual µ and h must equal
pure-liquid values plus existing molar sorption excess (no second mass factor).
Keep material/training/fullcycle/convergence flags false and unknown donor,
geometry, transfer, temperature/pressure, cross-effect and constitutive errors.

This is a short actual coupling and shared-ledger check. It is not a complete
external drying experiment, time/space convergence proof, or whole wet-to-fired
brick trajectory. Source PDF is private/local and not redistributed. Source
facts/model, actual PDF/XML and all actual source/installed modules are checked
by the existing supervisor before/after, child is reaped.

Pre-execution review addition: retain the already computed actual midpoint
inverse and phase inputs on the new witness; check full mu/h, T/P alignment
with thermal witness, actual target and original inverse gates at midpoint.
Supervisor numerical inputs now include installed NumPy and SciPy package
files (including extension binaries), not only iapws/project modules.

Interpreter executable, pyvenv.cfg and NumPy/SciPy/iapws distribution metadata
are also recorded as inputs. Operating-system libraries and hardware are not
a complete immutable environment certificate; no such claim is made.
