"""Archive an explicit evidence whitelist; never include private source bodies."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

WORK = Path('/private/tmp/sludge-sorption-moisture-v1')
DEST = Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/source-sorption-moisture-v1')
ROOT_NAMES = (
    'HOST_RED01.log','HOST_TESTS01.log','HOST_BINDING_FIX01.log',
    'NATIVE_PLAN.md','native_case.py','native_driver.py','run_supervised_native01.py',
    'SUPERVISED_NATIVE01.log','export_saved.py','DERIVED_SUMMARY.json','publish_evidence.py',
    'implementation/src/sludge_sandbox/sorption_moisture_face.py',
    'implementation/tests/sandbox/test_sorption_moisture_face.py',
    'implementation/data/sandbox/research/makela-moisture-v1/source.json',
    'implementation/data/sandbox/research/makela-moisture-v1/model.json',
)
DIRECTORIES = ('implementation','code-review','host-review','factor-tests','math-review',
               'install','native01','supervised-native01','saved-review','next-material')
ALLOWED_SUFFIXES = {'.py', '.md', '.json', '.log', '.xml', '.csv'}
paths = [WORK/name for name in ROOT_NAMES]
for directory in DIRECTORIES:
    parent=WORK/directory
    if not parent.is_dir():
        raise ValueError('missing_evidence_directory: '+directory)
    # Only immediate regular audit/record files. No recursion into original
    # PDFs/XML/assets, test source fixtures, caches, or environment directories.
    paths.extend(p for p in parent.iterdir() if p.is_file() and not p.is_symlink()
                 and p.suffix in ALLOWED_SUFFIXES)
paths=sorted(set(paths))
if any(not p.is_file() or p.is_symlink() for p in paths):
    raise ValueError('nonregular_evidence')
archive=DEST/'evidence.tar.gz'
if archive.exists():
    raise FileExistsError('do_not_overwrite_existing_evidence_archive')
members=[]
with tarfile.open(archive, 'w:gz') as handle:
    for path in paths:
        data=path.read_bytes(); name=str(path.relative_to(WORK))
        entry=tarfile.TarInfo(name); entry.size=len(data); entry.mode=0o644
        handle.addfile(entry, io.BytesIO(data))
        members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive, 'r:gz') as handle:
    names=handle.getnames()
    if names!=[m['path'] for m in members]:
        raise ValueError('archive_member_mismatch')
    for member in members:
        data=handle.extractfile(member['path']).read()
        if len(data)!=member['bytes'] or hashlib.sha256(data).hexdigest()!=member['sha256']:
            raise ValueError('archive_content_mismatch: '+member['path'])
manifest={'schema':'evidence_archive_v1','base_commit':'7b78528',
    'archive':archive.name,'archive_bytes':archive.stat().st_size,
    'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'member_count':len(members),'uncompressed_bytes':sum(m['bytes'] for m in members),
    'members':members,'all_members_reopened_and_verified':True,
    'excluded':'Private original source bodies, nested fixtures/assets, caches and environments.',
    'software_status':'limited_source_sorption_moisture_column_verified',
    'scientific_status':'conditional_numerical_check; material_and_external_prediction_unvalidated',
    'deployment_status':'offline_research_only', 'goal_complete':False}
(DEST/'EVIDENCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'},indent=2))
