# Finite JSON provenance fix after independent review

The independent reviewer found that NaN, Infinity and the exponent-overflow token 1e9999 were accepted in diffusivity provenance and subsequently made strict face-record JSON export fail. Their original `code-review/INDEPENDENT_RED01.*` artifacts remain untouched.

The only production change validates the parsed provenance with `json.dumps(..., allow_nan=False)` inside `EffectiveMoistureDiffusivity.__post_init__`. Invalid or nonfinite JSON is converted to `SorptionMoistureError('diffusivity_finite_json_provenance_required')`. The existing object-root requirement remains separate. No mathematical formula, transport input, source parameter or uncertainty definition changed.

The new author regressions cover NaN, both infinities, nested exponent overflow, malformed JSON and a valid finite strict-export control. `JSON_RED01.log/xml` preserves the actual five failures before the fix. `JSON_GREEN01.log/xml` records **32 passed in 0.06 s** after the fix.

Final review must use the formal repository files; the earlier scratch source/test remain the unchanged historical migration candidate:

- `src/sludge_sandbox/sorption_moisture_face.py`: `556441ea92ce3574916a4e16d7154f4c24670bdb78c24d118ea9792924d9c854`
- `tests/sandbox/test_sorption_moisture_face.py`: `6c8b524959afb6f1ec9f63474e2f4d97b5f5ea136afe824ddc74d0397f4933d8`
- Source JSON unchanged: `b4f77618270d5e21977eada439af7a55197527b3947c02c79173161dde52c5df`
- Model JSON unchanged: `118bf0ec21a5989e20cb3761d0833afb08b4503107219f441b19385f27abb0fe`

Root and the independent reviewer were notified. Other agents' files were not edited, and no commit, installation or native EOS execution was performed.
