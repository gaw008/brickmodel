# Condensed-water face leaf: scratch-only handoff

The formal repository was not edited. The module, test and two JSON files below remain under this implementation directory. The parent owns all migration, independent review, actual-state adapter work and Column integration.

## API

```python
diffusion = load_makela_diffusivity(repository_root, original_pdf_path)
exchange = sorption_moisture_face(left, right, geometry, diffusion, factor)
```

`CondensedWaterPoint` contains T, W, actual declared P, **complete** condensed-water molar chemical potential and partial molar enthalpy, water molar mass, one explicit shared energy-reference ID, input source IDs and classification. These are caller-declared records. Equal reference IDs do not authenticate the actual physical providers; the result explicitly keeps `source_state_binding_verified=false`.

`MoistureFaceGeometry` contains face area, center distance, and **both** dry masses and controlled **total** specimen volumes. The leaf computes each rho=md/Vtotal exactly and requires equal dry densities. No independently adjustable rho is accepted; available fluid volume is not the total volume.

`MoistureThermodynamicFactor` contains positive Gamma in J/mol, its face temperature, sorted actual W interval, declared method, source IDs and input classification. It must correspond exactly to `(T_left+T_right)/2` and the actual W interval. The caller can supply a Fraction for this exact mean. Different W requires `declared_secant`; equal W requires `declared_same_W_limit`. Neither a positive value nor its label authenticates a source thermodynamic factor. The subsequent real host adapter must derive it from the admitted wet m/q nodes and bind it to actual storage/chemical objects.

The pure leaf computes the selected equations with Fraction arithmetic, then returns one shared left-to-right `molar_flow_mol_s` and `carried_energy_w`. `moisture_entropy_w_k` is the projected nominal `Lm*Y^2`; the exact values, mobility, density, drive and every reported quantity's exact/projection residual remain available. It separately computes `rounded_rate_entropy_balance_w_k` from the **actual shared float n/H** and exact input forces. Negative or unresolved nonzero rounded entropy is rejected. Any nonzero-to-zero or nonfinite numeric projection is rejected. A true zero drive gives actual zero rates.

Conduction Q is excluded and must remain in the existing K face. No additional latent/desorption source is supplied. This is an instantaneous nominal constitutive check, not a proof of whole-step entropy increase, numerical convergence, material validity or native host completion.

## Diffusivity source and qualification

The source loader reads the pinned accepted PDF and facts/model files and verifies all SHA values. It produces a snapshot with D=8.56e-9 m2/s (107/12500000000), the original Table1/abstract branch. The separately printed results value 8.57e-9 remains a discrepancy, not an interval. The PDF was fully read in the preceding source audit; this worker only rechecked its bytes, without new rendering or EOS.

D is a shrinkage-corrected **apparent effective coefficient inferred from total drying loss** of untreated paper-mill sludge, not separately measured condensed-liquid diffusivity. Freezing it to 35--95 degC, W=.30--.80 and the 90--110 kPa hybrid branch is conditional; temperature/moisture/pressure/transfer/cross-effect errors and total uncertainty remain unknown. The pure face does not reread sources, and a production adapter must recheck its source snapshot. The first actual D host must avoid automatically placing apparent total-loss D in parallel with independent gas-water transport. Material qualification and training eligibility remain false.

## Validation

- `RED01.log/xml`: absent-module RED before implementation.
- `GREEN01.log/xml`: 22 passed, one negative-control expectation failed. The smallest subnormal D was amplified by the initially selected geometry and its resulting quantities remained representable; this was not a missed zero. The test's face area was reduced to produce actual nonzero-to-zero projection. The original failed artifact is retained.
- `GREEN02.log/xml`: 23 passed in 0.04 s.
- `GREEN03.log/xml`: 26 passed in 0.04 s, adding separate energy/entropy underflow cases and source-loader corruption checks.
- Covered analytic isothermal/equal-pressure Fick limit, left/right symmetry, true zero, nonisothermal exact and rounded entropy identities, common reference shift, observability of omitted enthalpy, bad/mismatched Gamma, same-W limit declaration, exact density agreement, state/domain/reference guards, overflow/underflow, source discrepancy/unknowns, and JSON projection provenance.
- `SOURCE_READ01.log` / `SOURCE_DIFFUSIVITY_READ01.json`: read-only actual PDF/facts/model hash validation and source snapshot. No real storage face, EOS, installation or native trajectory was executed.
- Both Python files parsed with AST. No additional static tools were installed; the selected runtime's Ruff/mypy/black/pylint availability was already checked as absent in the previous bounded phase.

## Candidate hashes

See `CANDIDATE_SHA01.json` for the machine-readable record.

| Scratch-relative path | SHA256 |
|---|---|
| src/sludge_sandbox/sorption_moisture_face.py | 3f664e2d123790787811e3d4d0c14bd8d737074423635b7ad50a89d9648215f1 |
| tests/sandbox/test_sorption_moisture_face.py | 2fa1f8911172adeef8733ed7922431506126c53848db7bfd6a7099f941542b2e |
| data/sandbox/research/makela-moisture-v1/source.json | b4f77618270d5e21977eada439af7a55197527b3947c02c79173161dde52c5df |
| data/sandbox/research/makela-moisture-v1/model.json | 118bf0ec21a5989e20cb3761d0833afb08b4503107219f441b19385f27abb0fe |
