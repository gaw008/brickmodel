# 独立初次问题记录

[MEDIUM] 扩散系数 provenance 接受非有限 JSON，成功返回的交换记录无法严格导出。

File: `src/sludge_sandbox/sorption_moisture_face.py:EffectiveMoistureDiffusivity.__post_init__`

初始候选只调用 `json.loads` 并验证顶层 dict；Python 解析 NaN、Infinity 和 1e9999 时会产生非有限 float。`sorption_moisture_face` 随后仍成功返回。下游严格 `json.dumps(exchange.to_record(), allow_nan=False)` 会失败。源 loader 固定 JSON 本身不受此问题影响，但公共 declared-input 入口允许构造该不可保存记录。

实际独立 RED：`INDEPENDENT_RED01.log/xml` 为 3 failed / 3 passed，0.03 s。三个失败分别对应上述三种文本；不是原生 EOS 测试。修复建议限于该构造入口：解析后验证允许严格 JSON 导出，并将错误转为 SorptionMoistureError；无需通用 codec。

另 `CORE_GREEN01.log/xml` 为 5 passed / 3 deselected，0.02 s，独立覆盖有限嵌套 metadata、不同受控总体积但同ρ、非线性化学势割线的解析 Fick 限、实际浮点n/H熵为负时拒绝，以及不先float化的精确Tf对应。后三项中正PSD不覆盖实际rounded熵的负号门。

本文件保留最初问题和 RED 证据；最终候选结论另见最终报告。
