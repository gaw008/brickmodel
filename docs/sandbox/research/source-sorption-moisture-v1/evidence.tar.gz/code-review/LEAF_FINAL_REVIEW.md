# 凝聚水迁移叶子独立代码审查

APPROVE。基线 `7b78528` 后，已检查实际迁入文件及完整稳定草稿、两份来源/模型 JSON、作者测试、相关 `TRANSPORT_NEXT.md` 和所用源证据。本结论仅适用于 declared-input leaf；实际 storage/chemical 适配器和 Column 接线不在本次审查范围，不能把该叶子当作完整物理主机。

审查者没有改生产、安装、执行 EOS 或原生轨迹；独立探针和报告仅写新 scratch/code-review。

## 唯一发现及修复

[MEDIUM，已关闭] `EffectiveMoistureDiffusivity.__post_init__` 先前允许 provenance 中的 NaN、Infinity 和指数溢出 1e9999，面函数成功返回但严格 JSON 导出失败。实际独立 `INDEPENDENT_RED01` 为 3 failed / 3 passed，0.03 s；初始问题原文保存在 FINDINGS01.md。

当前正式文件在 json.loads 后用 `json.dumps(..., allow_nan=False)` 验证整个对象，错误统一转为 SorptionMoistureError，再保留原根对象守卫。作者另保存实际 JSON_RED01 的 5 个失败；JSON_GREEN01 原日志/XML 为 32 passed，0.06 s。独立最终 INDEPENDENT_GREEN01 为 **8 passed / 0 failed，0.02 s**。原失败全部保留，没有把修复后的绿色测试称为原失败。

## 数学与数值边界

令 X_T=1/T_R−1/T_L，X_mu=mu_L/T_L−mu_R/T_R，h*=平均完整摩尔偏焓，Y=X_mu+h*X_T。叶子返回 n=L_m Y，H=h*n，故精确瞬时熵 H X_T+n X_mu=L_m Y²≥0；在 (H,n) 表示中，矩阵 L_m[[h*²,h*],[h*,1]] 对称正半定。导热 Q 在叶子之外，没有另加潜热或脱附热。

G_mu=A rho_d D/(M distance Gamma)，L_m=T_face G_mu，量纲一致。Γ为正且与精确平均 Tf、当前有序 W 区间和 secant/same-W 方法逐项对应；等 T/P 且 Γ 为实际割线时精确还原 Fick。独立使用非线性 μ(W) 的割线跨区间核验，避免只验证线性制造例。Γ数值来源真实性不是叶子认证的内容。

共同能量参考平移 c 时 X_mu 变化 −cX_T，h*变化 +c，Y/n/精确熵不变，H 变化 cn。使用完整 μ 和完整偏焓对于此抵消是必要的；从旧 excess-only 点直接作非等温面不满足该前提。原作者测试覆盖共同参考平移和缺携焓负控。

rho_d 从两侧显式 md/总体积独立计算并要求精确相等；独立探针确认不对称 md/Vtotal、相同ρ可正常工作。可用孔体积不是这里总体积，叶子没有提供可任意调整的独立 rho 数值。

所有输入数值严格为有限 int/float/Fraction，非零→零与非有限投影拒绝；输出保留精确值和各投影误差。名义 L_mY² 的浮点展示值与实际共享 float n/H 算出的精确熵余额分开。独立构造了名义熵>0、实际 rounded n/H 熵<0 的输入，确认当前拒绝；不能只凭 PSD 形式覆盖实际投影负熵。真零驱动正常返回零。相邻 binary64 T 的均值可能不可表示为单个 float，独立测试确认 Γ/Tf 对应必须保留精确 Fraction 均值。

最终8项独立探针覆盖3种非有限JSON拒绝、有限嵌套JSON/false绑定标记、不对称体积同ρ、非线性割线Fick、名义/实际熵符号分离和半ULP均值对应。它们都是明确制造输入，不是 EOS、实际材料状态或整个离散步总熵证明。

## 来源、分类与后续适配责任

独立点核原 accepted PDF SHA `f4200d99c4fa8f3f6585fde9ec2e15455bfa78644a953e52b7311c1df25cba91`、4,442,717 bytes；读取相关原文本并查看已有第22页图。Table1脚注/摘要的未处理纸厂泥 D=8.56e−9 m²/s 与正文8.57e−9差异均保留；它不是置信区间。105°C是干燥空气条件，未把局部材料温度历史虚构出来。60% primary/40% biological 的 donor 与 Arlabosse 材料不同，所用D为由总干燥失水推算的表观有效系数，不能称为液相专测系数。

source 与 model 都使用 derived_from_evidence；冻结 D 的温度/湿度域、跨材料使用、面平均与零交叉闭合分别为 virtual_design_choice；二进制投影为 numerical_policy。原测量、迁移与交叉效应误差和总误差均 unknown，材料/训练资格 false，没有给予 PDF 额外转载授权。

纯函数不读文件，loader 产生源PDF/facts/model已校验的快照；后续 adapter 必须重核源字节、实际 storage/chemical 的共同水参考、源 m/q 导出的 Γ、实际 md/受控总体积与完整 T/P/μ/h 绑定。叶子明确 `source_state_binding_verified=false`，正Γ或相同参考字符串不等于上述身份已获认证。

首个实际主机还须关闭独立气相格间水迁移/Darcy，避免把总失水表观D未经分配地与另一气相路径并联；本地凝聚/蒸发与独立导热仍可保留。新 n 只更新同一 Nc 库存、单个共享 H 进入 U 账，实际反解后检查域和正库存。该责任是现有设计的明确接线前提，不是本叶子已经完成的功能。

## 最终正式字节

稳定 scratch 原候选保留历史；以下为修复后的正式树字节。

| 文件 | SHA256 |
|---|---|
| `src/sludge_sandbox/sorption_moisture_face.py` | `556441ea92ce3574916a4e16d7154f4c24670bdb78c24d118ea9792924d9c854` |
| `tests/sandbox/test_sorption_moisture_face.py` | `6c8b524959afb6f1ec9f63474e2f4d97b5f5ea136afe824ddc74d0397f4933d8` |
| `data/sandbox/research/makela-moisture-v1/source.json` | `b4f77618270d5e21977eada439af7a55197527b3947c02c79173161dde52c5df` |
| `data/sandbox/research/makela-moisture-v1/model.json` | `118bf0ec21a5989e20cb3761d0833afb08b4503107219f441b19385f27abb0fe` |

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — 当前声明输入叶子无未解决问题；真实状态适配和主机接线须另外审查。
