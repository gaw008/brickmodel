"""Independent declared-input probes: no actual storage, source calibration, or EOS."""
from dataclasses import replace
from fractions import Fraction as F
import json
import pytest
from test_sorption_moisture_face import inputs
from sludge_sandbox.sorption_moisture_face import (
    EffectiveMoistureDiffusivity, SorptionMoistureError, sorption_moisture_face,
)

@pytest.mark.parametrize('literal',['NaN','Infinity','1e9999'])
def test_nonfinite_json_provenance_cannot_produce_unserializable_exchange(literal):
    args=inputs()
    with pytest.raises(ValueError):
        d=EffectiveMoistureDiffusivity(args[3].value_m2_s,args[3].source_ids,
            args[3].input_classification,'{"nonfinite":'+literal+'}')
        sorption_moisture_face(*args[:3],d,args[-1])


def test_finite_provenance_remains_standard_json_and_false_bound():
    args=inputs(temperatures=(F(325),F(355)))
    d=replace(args[3],_provenance_json='{"nested":[1,-2,0.1,null,{"note":"finite"}]}')
    out=sorption_moisture_face(*args[:3],d,args[-1])
    json.dumps(out.to_record(),allow_nan=False)
    assert out.source_state_binding_verified is False
    assert out.material_qualified is out.training_eligible is False


def test_uniform_total_density_permits_asymmetric_controlled_volumes():
    args=inputs(temperatures=(F(325),F(355)))
    base=sorption_moisture_face(*args)
    geometry=replace(args[2],left_dry_mass_kg=F(7),left_total_volume_m3=F('0.007'),
                     right_dry_mass_kg=F(11),right_total_volume_m3=F('0.011'))
    out=sorption_moisture_face(*args[:2],geometry,*args[3:])
    assert out.exact_molar_flow_mol_s==base.exact_molar_flow_mol_s
    assert out.exact_carried_energy_w==base.exact_carried_energy_w
    assert out.dry_density_kg_m3==F(1000)


def test_exact_nonlinear_secant_restores_fick_across_interval():
    args=inputs(moistures=(F('.73'),F('.32')))
    l,r=args[:2]
    mu=lambda w:F(-200000)+F(1234)*w*w
    l=replace(l,chemical_potential_j_mol=mu(l.moisture_kg_water_per_kg_dry))
    r=replace(r,chemical_potential_j_mol=mu(r.moisture_kg_water_per_kg_dry))
    gamma=(l.chemical_potential_j_mol-r.chemical_potential_j_mol)/(l.moisture_kg_water_per_kg_dry-r.moisture_kg_water_per_kg_dry)
    factor=replace(args[-1],gamma_j_mol=gamma)
    out=sorption_moisture_face(l,r,*args[2:4],factor)
    g=args[2]
    expected=g.area_m2*F(1000)*args[3].value_m2_s/(l.water_molar_mass_kg_mol*g.center_distance_m)*(l.moisture_kg_water_per_kg_dry-r.moisture_kg_water_per_kg_dry)
    assert out.exact_molar_flow_mol_s==expected


def test_nominal_psd_does_not_override_negative_actual_rounded_entropy():
    args=inputs(temperatures=(F(330),F(331)))
    h=F(-200000);delta=F(1,10**18)
    left=replace(args[0],chemical_potential_j_mol=h+delta,partial_molar_enthalpy_j_mol=h)
    right=replace(args[1],chemical_potential_j_mol=h,partial_molar_enthalpy_j_mol=h)
    xt=1/right.temperature_k-1/left.temperature_k
    xmu=left.chemical_potential_j_mol/left.temperature_k-right.chemical_potential_j_mol/right.temperature_k
    drive=xmu+h*xt
    geometry=args[2]
    L=(left.temperature_k+right.temperature_k)/2*geometry.area_m2*F(1000)*args[3].value_m2_s/(left.water_molar_mass_kg_mol*geometry.center_distance_m*args[-1].gamma_j_mol)
    n=L*drive;H=h*n
    assert L*drive*drive>0
    assert F(float(H))*xt+F(float(n))*xmu<0
    with pytest.raises(SorptionMoistureError,match='rounded_moisture_entropy_negative'):
        sorption_moisture_face(left,right,*args[2:])


def test_factor_requires_exact_mean_of_represented_temperatures():
    import math
    args=inputs(temperatures=(F(330.),F(math.nextafter(330.,math.inf))))
    exact=(args[0].temperature_k+args[1].temperature_k)/2
    assert F(float(exact))!=exact
    wrong=replace(args[-1],temperature_k=float(exact))
    with pytest.raises(SorptionMoistureError,match='thermodynamic_factor_state_correspondence'):
        sorption_moisture_face(*args[:-1],wrong)
    out=sorption_moisture_face(*args)
    assert out.exact_moisture_entropy_w_k>=0
