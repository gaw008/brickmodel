# D native01 预登记与驱动有限独审

结论：**有条件 APPROVE**。对照 source-conductivity-column-v1 归档的实际三份脚本，原数值门均保留；Nc 与携焓账的新增项及关闭气相格间输运是正确的。审查提出的两项见证缺口已完成增量静态复核并关闭，无未解决 CRITICAL/HIGH/MEDIUM 问题。实际唯一短段仍须完成预登记已有的独立 host 审查、安装、测试与 SOURCE_FREEZE 前置项；此结论不表示 native 已执行或通过。

## 本次读取版本

| 文件 | SHA256 |
|---|---|
| native_case.py | 19bac6de834a876a5f9ddaa00dc4c38c82342b4d5ca9cbfc60065cbd2c02cf2d |
| native_driver.py | 963bcdeb25d7d3e1ccc93429161356041a21fda498f5dd544aae82cd690450f0 |
| run_supervised_native01.py | 1b59a6f12e56bd164d80a1f913c044d52e49cc01871a7aab523a0cda092ddef1 |
| NATIVE_PLAN.md | 2761ceb2d3bf80537a8af167adbb1b68987abfc20462e8713e497ad5bd954e30 |

前三份当前脚本仅做 AST 解析，均成功；没有 import 项目包、EOS 调用、驱动执行、安装或数值模拟。PATH 未发现 ruff/mypy/pylint/black。读取过 git diff/status，没有改生产文件。旧脚本直接从 `docs/sandbox/research/source-conductivity-column-v1/evidence.tar.gz` 读取；SHA 分别为 c87837cc16788b17603c43bc8ba98340c233b302e40e42fcb7180124264c188a、0f7977c14a792052e1bd223146511107d9786f090af3bc3f9422f0c526835e7e、3aef4e5ee059e83764a4e3806486fde88febb24d3db4f9b7b19f9a41f8c3728b。

## 已关闭的有限审查事项（保留提出与修正记录）

[MEDIUM → CLOSED] 监督清单遗漏实际数值库

File: `run_supervised_native01.py:41`

Issue: 递归清单只有 repo/installed sludge_sandbox 与 installed iapws。实际 installed `iapws/iapws95.py:30–32` 导入 NumPy exp/log/chebyshev 和 SciPy fsolve；这些包及其二进制扩展、包内依赖库不在 inputs 中，所以不能声称所有实际数值实现均受 before/after hash 监督。初版也未纳入解释器目标/venv 身份。

Fix: 扩展清单到实际 installed NumPy/SciPy 及其 bundled library 目录、对应分发元数据，记录/冻结解释器真实目标与 venv 配置。对操作系统、系统动态库与运行环境明确监督边界即可，不必把有限运行升级为操作系统不可变证明。before/after hash 是文件变化检测，不是整个运行期间不可变的证明。

Closure: 最新脚本递归包含实际 NumPy/SciPy（含扩展与当前本机 SciPy 包内 `.dylibs`），并加入唯一匹配的 numpy/scipy/iapws dist-info、`PYTHON.resolve()` 和 `pyvenv.cfg`；元数据多重/缺失匹配拒绝。预登记明确 OS 库/硬件不属于完整不可变环境证明。这项关闭。

[MEDIUM → CLOSED] 中点 μ/h 组成验算实际只覆盖末态

File: `native_driver.py:113–120`

Issue: 真正积分用的 `mw.points` 只独立核了中点 W；完整 μ/h 相加验算使用 `observation.moisture_points` 和末态 inverse/phase。中点 n/H 的后续精确算式正确，但没有独立确认中点 T 与同一次导热见证对应，也未在 native 产物中保存/验算这次中点 pure μ/h 与 excess μ/h 的组成。适配器代码本身有实际 state/inverse/phase 绑定校验，因此这是预登记及可审查见证的缺口，并非发现实际用了错误末态。

Fix: 保存已计算的中点热力学输入见证（实际 pure T/P/μ/h 与 source point 的 T/P/W/excess），在 driver 核对 `mp.T == Fraction(conductivity_point.T)`、对应中点库存和实际输入、以及两个 Fraction 直接相加的完整 μ/h。复用现成中点计算，不增加 EOS 调用。保留末态核验。

Closure: 最新 SourceMoistureWitness 保存调用中现有 inverses/phases；driver 对真正的中点逐格核对 T/P、thermal witness T、pure μ/h＋excess、实际 target/residual 与原 1e-5 J/1e-6 K 反解门；末态核验保留。静态调用链没有增加 EOS。所读适配器 SHA256 为 b0da48cbd12a53f17b3af6420fa2e156b545be7eda2bb553b95e2fe5241c3177。这项关闭。

`install/SOURCE_FREEZE.json` 在本次读取时尚不存在；这是 NATIVE_PLAN 已明示的前置项，不能据此声称已冻结或已完成运行。上述两项现已补齐；唯一 attempt 应待独立代码审查、installed 测试和 source/install freeze 通过后启动。

## 原门与新账本核对

- 原两格 dry mass、几何、初始 Nc/gas/T、压力/温度域、后端与数值 envelope、局部相变系数、反解策略保持。最终实际 face 明确 k=(0,0)、三气体 D=(0,0,0)、Darcy permeability=0，再由实际 Septien 与 Mäkelä provider 接管。构造中的旧 face 没有被用于 RHS。
- 保留 represented .05 s、2 midpoint steps、6 RHS、3 states、2 ledgers；60/80/100 s 与 5 s cleanup，inverse 1e-5 J/1e-6 K，roundoff 1e-8 J/1e-12 mol，原 final ΔT > inverse bound +1e-6 K 门均未放宽。W 下界由旧 driver 的 .15 收紧到 .30；source k 自己原本也有更窄域检查。
- 原非零气体交换门按预登记换成气体通量及其两类携焓严格为零；局部凝聚/蒸气相变仍非零。Nc 单格增量为左水通量−右水通量−相变量＋投影误差；水蒸气增量为相反相变量。无第二水池。
- 内能 face decomposition 包含新增 moisture_enthalpy_j，单格 U 是左能流−右能流＋投影误差；全局和每个时间前缀 U、水、惰性气体保留原精确 Fraction 账。水/能流投影分开记录，未添加独立潜热源或温度覆写。
- 中点导热 k(W)、G、共享核 Q、Q 的精确算术残差、熵产生、dt×Q 与 source IDs 门保留。新中点 n/H、dt×投影流、精确/投影差、Tf/Gμ/Lm/Y 与实际投影熵产生正值均有检查。
- 最新 driver INITIAL 保存实际 `_m/_q` 节点与 M，并自行 Fraction 插值重算 Γ；已补上原先只检查 Γ>0/Tf 的缺口。保存的 368.15 与当前 wet 模块 T_REF 一致。该限定轨迹使用不同 W 正割；若 W 相等，driver 拒绝而非自行转入未预登记极限路径，适用于本短段。
- 顺带静态核对适配器：两侧/跨段 Γ 正值门、实际 point W 的 Fraction、精确平均 Tf、full μ/h 的两个已为 J/mol 的项直接 Fraction 相加、同 T/P δμ 保留及有 ΔW 时塌缩/反号拒绝均已落实。未将质量因子乘第二遍。
- INITIAL、构造前缀、RUN 在 acceptance 前落盘；目录唯一、失败信息保存。监督已有原进程组清理与 before/after 输入比较结构；本审查未执行其清理路径或证明系统硬截止。

## 结论适用范围

批准的是包含已补见证的短程实际耦合/守恒检查设计。D 来自不同污泥的表观总失水关系，分配给凝聚态库存、105°C 向当前温域迁移、几何及其他制造条件和 cross-effect 假设仍是显式条件模型，误差 unknown。实际全过程材料验证、现实可预测性、空间/时间收敛与训练资格均未因此成立。后续收敛工作不应写入本短段的已完成成果。
