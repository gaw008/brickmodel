# Γ适配器与水参考：有界独立数学审核

**有条件 APPROVE 该Γ构造。** 正割线公式及左右节点平均可实现，但必须采用下列单位、严格正性和数值范围声明。实际适配器尚未提供，本报告不构成其代码通过。仅静态读取已实现叶子、storage和TRANSPORT_NEXT；无网络、原件重读、EOS、积分或生产修改。当前`git diff -- '*.py'`为空。版本SHA见`READ_SNAPSHOT.json`。

## 1. 公式与二进制语义

`arlabosse_rigid_sorption._value`按**存储的binary64节点**转Fraction，给出该连续折线的精确值；在节点取左段不会改变函数值。现有`wet._excess`定义的是每kg水量：

μex(T,W)=r m(W)+(1−r)[L0−q(W)]，r=T/T_REF。

固定T/P下，纯液μ不依赖W。因此，用Wlo<Whi、Tf=(F(TL)+F(TR))/2、r=Tf/F(T_REF)、M=F(wet._mass)：

Γsec = M·[r(m(Whi)−m(Wlo))−(1−r)(q(Whi)−q(Wlo))]/(Whi−Wlo)，单位J/mol。

L0严格抵消，不需要求新的参考EOS。该式跨越m/q不同节点也成立。m、q分别调用精确插值，不要先减两个很大的float μ值再转Fraction。`F((TL+TR)/2)`与上述Tf不等价；`F('368.15')`也不是当前所存`F(T_REF)`的二进制语义。以叶子所接收的同一W、Tf生成`factor.moisture_interval/temperature_k`。

`point.W`是Nc·M/md的binary64投影。建议同时记录W_inventory=F(Nc)F(M)/F(md)、W_point=F(point.W)及投影差，并验证float(W_inventory)==point.W；Γ采用W_point属于明确的**点读出坐标约定**。不能将它声称为在未投影库存坐标上精确求得的U导数，也不能用投影掩盖严格库存域越界。

## 2. 同W与更清晰的拒绝规则

先以m/q节点并集划分有效区间；每段精确斜率给Γsegment=M[r m′−(1−r)q′]。

- 同W、非节点：采用其所在段Γsegment。
- 同W、内部节点：Γnode=(Γleft+Γright)/2是对称的**数值闭合约定**，可接受；但左右斜率不同时不存在唯一导数，非对称趋近的正割线也不趋于此平均。记录两侧值及`interior_knot_arithmetic_mean`子方法，勿标成测得导数或唯一极限。叶子当前`declared_same_W_limit`可仅作为路由token，适配器证据须说明其真实含义。
- 模型有效域端点：使用域内单侧斜率；若端点同时位于更宽湿热曲线内部，也按本输运域内侧定义。

建议拒绝：所用侧Γ≤0；节点任一有效侧Γ≤0；跨W所穿过任一合并段Γ≤0；非有限值/正量投影下溢；W或T超域。正割线最终Γ>0仍检查。此逐段严格性避免正平均隐藏退化段；它是使Γ倒数处处有定义的明确准入规则，不是新实测材料限制。不要加epsilon地板、不夹紧、不把不定Γ当零迁移率。Γ对Tf线性，绑定阶段可用允许T域两端检查每个相关段，再每面检查实际Tf；无需EOS。

## 3. μ/h单位与参考：必须避免重复乘M

**实际`ArlabosseSorptionPoint.excess_chemical_potential_j_mol`已是J/mol**（storage第226行已乘M）；`excess_partial_water_enthalpy_j_mol`也已是J/mol（第217、227行）。正确接法为：

μfull = F(pure.chemical_potential_j_mol) + F(point.excess_chemical_potential_j_mol)

hfull = F(pure.enthalpy_j_mol) + F(point.excess_partial_water_enthalpy_j_mol)

只有`wet._excess`直接返回的μ/kg或b/kg才乘M。不可再将point的摩尔字段乘M。纯液部分须来自已绑定同一`WaterChemicalPotential.liquid_tp(point.T, point.P)`，不是固定1bar的`wet.evaluate`输出或另一套能量零点。使用实际水参考、M、后端、源SHA和energy-reference绑定；仅比较调用者填的参考字符串不足以完成认证。可用Fraction相加保留既有二进制读数，避免额外float大基准相消。

数学上h_ex,mol=M(L0−q)，且Fex零体积，使excess偏焓与偏内能相同。完整h含纯液焓；不能以全U/N、q_desorption或纯液h替代。当前storage的μ经过`_excess`浮点插值/运算及最终投影，h_ex使用未投影W_inventory的精确插值后投影：这属于已存在的名义读出层次，不是全物性误差已知。

## 4. 与已实现面叶子的衔接边界

`sorption_moisture_face`第278–303行验证所声明Γ/Tf/W区间，随后以正mobility乘Y，并核对舍入通量的瞬时熵式；**不认证Γ、μ/h来自实际storage**。适配器需自行绑定/复核来源与点身份，保留该叶子原有资格范围。

FractionΓ是精确折线的正割线，而现有point μ是舍入读出。因此真实适配器不能直接继承制造测试的“逐位精确Fick极限”表述。等T/P时建议报告

δμ = (μfull,R−μfull,L)−Γsec(W_R−W_L)

这是算术一致性残差，不是实验误差。若ΔW≠0而实际μ差为零或与ΔW反号，拒绝为化学驱动力分辨率失败，不标为平衡。同T/P正常差值的Fick核验应带该可计算残差；叶子的精确熵代数仍只针对实际传入读数，不升级为包含逆解/EOS/材料误差的方向证书。非等温/不同P时不能拿Δμfull/ΔW代替固定T/P的Γ，它会把热项/压力项混入因子。

最小静态/制造核验建议：m/q不共节点的跨段割线；合并节点两侧平均与单侧端点；零/负侧被平均掩盖负控；先float平均Tf的错配；point μ/h二次乘M负控；能量参考同时平移的Y/σ不变；极近W的读出塌缩拒绝。原D打印差异、105°C空气迁移到35–95°C、跨材料与零交叉系数假设继续为已声明unknown，不由Γ的精确算术消除。
