# Independent code and numerical review

Reviewed frozen mass_wet_exact_terminal.py SHA256 4f186cfbf8a7bb5b8ed58d011edfc8a35ff8acb3c53ea8aa00a272c396518b1b and test_mass_wet_exact_terminal.py SHA256 7d0242c40bc7f3e921ee4629c88fcf611ba1295f15b6e4f6b02d5455541f71a4, surrounding production WetPair, exact stage components/advance, and existing exact-affine/writeback contracts. Repository staged/unstaged diffs were empty during inspection. No source edits, installation or EOS execution.

APPROVE for the documented speculative local terminal-preparation API. No blocking defect found. Two actual WetPair evaluations feed the shared affine coefficients; caller-provided rates are not accepted. Pre/post host binding and context/totals digests, actual water M, source declarations and modes are checked. Exact component ledgers reconstruct all raw kg/mol/U fields before reviewed writeback. Selected correction leaves solids and U unchanged. Failed/cancelled/resource-limited attempts clear projection while preserving reached samples, predictor/ledger/root evidence and attempted/completed counts; original totals remain unchanged.

All wet cells participate as candidates or exact positive-domain exclusions. Potential roots must meet the existing strictly decreasing affine contract. Ordering uses strict enclosure separation, not time tolerance as a minimum spacing; exact common earliest roots refuse instead of arbitrary cell-index selection. The full terminal interval checks every inventory polynomial, including interior quadratic minima, and keeps other wet liquid strictly positive. Nonmonotone unsupported candidates fail conservatively. Root-refinement exhaustion cannot return prepared state.

Independent pure tests added in review_independent_test.py: cancellation and zero callback budget before any evaluation; independent endpoint/vertex evaluation of every inventory polynomial; exact Fraction raw water/face/source arithmetic; complete candidate/exclusion membership. Combined original 11 + independent 2 tests: 13 passed (authoritative review-tests.log/XML). Analytic liquid test seam only; not native-water evidence.

Qualification boundaries remain material: time_absolute_s is explicitly supplied by the caller and captured in clock/order binding, but this API has no independent original event-policy registry. Likewise it checks original state/model/context content, not historical reachability from the original state. A future controller must bind the time limit to its immutable original policy, authenticate retained history/totals, prevent duplicate correction charging/reset, perform post-projection mode/endpoint validation and all event/common-time error comparisons before committing. Prepared is not accepted; this review does not establish nonlinear event accuracy or native pressure-temperature error closure.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — bounded local preparation contract only.
