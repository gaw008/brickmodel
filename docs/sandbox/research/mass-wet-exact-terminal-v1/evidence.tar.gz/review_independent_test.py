from dataclasses import replace
from fractions import Fraction as F
from test_mass_wet_exact_terminal import setup,run
from sludge_sandbox.mass_wet_exact_terminal import prepare_mixed_terminal,source_labels
from sludge_sandbox.mass_wet_writeback import MixedWritebackTotals
from sludge_sandbox.exact_event_clock import ExactEventTime as T


def test_no_callback_before_cancellation_and_zero_budget(monkeypatch):
    pair,s,c,t=setup(monkeypatch)
    a=run(pair,s,c,t,cancel=lambda:True)
    b=run(pair,s,c,t,maximum_evaluations=0)
    assert a.status=='cancelled' and b.status=='resource_limit'
    for r in (a,b):
        assert r.evaluations_attempted==r.evaluations_completed==0
        assert r.samples==() and r.projection is None and r.initial_state is s


def test_every_inventory_minimum_and_raw_water_balance(monkeypatch):
    pair,s,c,t=setup(monkeypatch);r=run(pair,s,c,t)
    assert r.status=='prepared'
    h=r.ledger.end.elapsed_since(r.start)
    for p in r.inventory_polynomials:
        probes=[F(),h]
        if p.quadratic>0:
            v=-p.linear/(2*p.quadratic)
            if 0<v<h:probes.append(v)
        m=min(p.initial+p.linear*x+p.quadratic*x*x for x in probes)
        assert m>=0
        if p.family=='liquid' and p.cell!=r.root_order.selected_cell:assert m>0
    terms=dict(r.ledger.represented_integrals)
    for i in range(2):
        before,after=s[i],r.raw_states[i]
        waterchange=F(after.liquid_water_mol)+F(after.gas_amounts_mol[2])-F(before.liquid_water_mol)-F(before.gas_amounts_mol[2])
        physical=F(terms['chemical_gas',i,2])+(-1,1)[i]*F(terms['face_species',2])
        assert abs(waterchange-physical)<=F(1e-16)
    assert r.root_order.wet_cells==(0,1)
    assert set(x.cell_index for x in r.root_order.candidates)|set(x.cell_index for x in r.root_order.exclusions)=={0,1}
