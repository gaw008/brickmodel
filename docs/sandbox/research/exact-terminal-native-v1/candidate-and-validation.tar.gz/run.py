"""Actual source-bound terminal from saved initial state with fresh RHS samples."""
from pathlib import Path
from fractions import Fraction
from dataclasses import fields,is_dataclass
from collections.abc import Mapping
import json,hashlib,time,traceback
from sludge_sandbox.verification_case import read_case,build_case,encode
from sludge_sandbox.integration import ConservedState
from sludge_sandbox.depletion_roundoff import DepletionRoundoffTotals
from sludge_sandbox.exact_terminal_executor import execute_exact_terminal
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.water_properties import is_water_provider
from sludge_sandbox.deforming_solid_storage import _canonical
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent
out=root/'native01';out.mkdir(exist_ok=False)
prior=Path('/private/tmp/brick-four-cell-ordered-failure-evidence-v1/attempt01')
def save(name,x):(out/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def decode(v):
    if isinstance(v,list):return tuple(decode(x) for x in v)
    if isinstance(v,dict):
        if set(v)=={'numerator','denominator'}:return Fraction(v['numerator'],v['denominator'])
        return {k:decode(x) for k,x in v.items()}
    return v
def capture(v):
    if is_water_provider(v):return {'type':[type(v).__module__,type(v).__qualname__],'source':_canonical(v),'implementation':_canonical(v.implementation)}
    if is_dataclass(v):return {f.name:capture(getattr(v,f.name)) for f in fields(v)}
    if isinstance(v,Mapping):return {str(k):capture(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [capture(x) for x in v]
    return encode(v)
started=time.monotonic();before=runtime_identity();save('runtime-before.json',before)
casebytes=(prior/'case.json').read_bytes();(out/'case.json').write_bytes(casebytes)
sourcebytes=(prior/'core-result.json').read_bytes()
report={'status':'started','qualification':'Actual speculative terminal with fresh initial/midpoint/endpoint samples. No accepted packet or complete trajectory.'}
try:
    source=json.loads(sourcebytes)
    d=source['result']['refinements'][0]['comparison_details']['writeback_failure']
    built=build_case(read_case(out/'case.json'),Path('/private/tmp/brick-free-native-events-v1/attempt01/water'))
    assert encode(built.initial)==json.loads((prior/'initial.json').read_text())
    state=ConservedState(**decode(d['initial_state']))
    assert state.energy_model_identity==built.initial.energy_model_identity
    dry=tuple(i for i,row in enumerate(state.amounts_mol) if row[built.operator.liquid_index]==0)
    assert dry==(3,)
    operator=ExactFreeWaterTransfer(built.operator).with_depleted_cells(state,dry)
    assert d['totals_before']['policy']==d['roundoff_policy']
    values=decode(d['totals_before']);values.pop('policy')
    assert encode(built.depletion_policy.roundoff_policy)==d['roundoff_policy']
    totals=DepletionRoundoffTotals(built.depletion_policy.roundoff_policy,**values)
    start=ExactEventTime.from_float(d['clock']['start_s'])
    common=ExactEventTime.from_float(built.end_s)
    save('input-times.json',{'start':start.to_record(),'common_endpoint':common.to_record()})
    save('input-state.json',encode(state));save('input-totals.json',encode(totals))
    save('input-policies.json',encode({'integration':built.policy,'depletion':built.depletion_policy}))
    identity=operator.operator_identity
    result=execute_exact_terminal(state,operator,start=start,common_endpoint=common,
        integration_policy=built.policy,event_policy=built.depletion_policy,totals=totals)
    save('terminal-result.json',capture(result))
    assert identity==operator.operator_identity
    assert encode(state)==d['initial_state']
    report.update(core_status=result.status,core_reason=result.reason,costs=encode(result.costs))
    # A refused speculative terminal is saved evidence, not capture failure.
    if result.status=='speculative_completed':
        assert result.root_order.selected_cell==2
        assert result.candidate_operator.operator.interfaces==('existing_liquid','existing_liquid','depleted_no_nucleation','depleted_no_nucleation')
        assert len(result.observations)==3
        result.observations[-1].evaluation.rates.derivatives(result.corrected_state)
    report.update(status='captured',original_operator_identity=encode(identity))

except BaseException:
    report.update(status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-after.json',after)
        assert before==after
        assert casebytes==(prior/'case.json').read_bytes()==(out/'case.json').read_bytes()
        assert sourcebytes==(prior/'core-result.json').read_bytes()
    except BaseException:report.update(status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_s=time.monotonic()-started,modules=len(before['modules']),
        source_sha256=hashlib.sha256(sourcebytes).hexdigest(),runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    save('report.json',report)
assert report['status']=='captured',report
