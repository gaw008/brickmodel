"""Independent stdlib saved-data arithmetic audit; no model imports or EOS."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,math,copy
P=Path(__file__).parent;D=P/'native01'
def read(p):return json.loads(p.read_text())
def q(x):return F(x['numerator'],x['denominator']) if isinstance(x,dict) else F(x)
def tm(x):return q(x['seconds'])
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def tree(x):
    if isinstance(x,dict):
        if set(x)=={'numerator','denominator'}:return [x['numerator'],x['denominator']]
        return {k:tree(v) for k,v in x.items()}
    if isinstance(x,list):return [tree(v) for v in x]
    return x
r=read(D/'terminal-result.json');report=read(D/'report.json');pol=read(D/'input-policies.json');ip=pol['integration'];ep=pol['depletion'];rp=ep['roundoff_policy']
assert report['status']=='captured' and r['status']=='speculative_completed' and r['reason'] is None
assert read(D/'runtime-before.json')==read(D/'runtime-after.json')
assert len(read(D/'runtime-before.json')['modules'])==75
prior=Path('/private/tmp/brick-four-cell-ordered-failure-evidence-v1/attempt01')
assert report['source_sha256']==hashlib.sha256((prior/'core-result.json').read_bytes()).hexdigest()
assert (D/'case.json').read_bytes()==(prior/'case.json').read_bytes()
failure=read(prior/'core-result.json')['result']['refinements'][0]['comparison_details']['writeback_failure']
assert r['initial_state']==read(D/'input-state.json')==failure['initial_state']
assert r['input_totals']==read(D/'input-totals.json')==failure['totals_before']
assert rp==failure['roundoff_policy']==r['input_totals']['policy']
obs=r['observations'];assert [o['role'] for o in obs]==['initial','midpoint','endpoint']
assert obs[0]['state']==r['initial_state'] and obs[1]['state']==r['predictor_panel']['raw_state'] and obs[2]['state']==r['corrected_state']
assert r['costs']['evaluation_attempts']==r['costs']['evaluation_completed']==3
source=['exact-operator:'+digest(report['original_operator_identity'])]
assert r['predictor_panel']['source_binding']==r['terminal_panel']['source_binding']==source
maxima={'amount':F(),'energy':F(),'stretch':F()}
def leaves(a,b):
    if isinstance(a,list):
        assert len(a)==len(b)
        for x,y in zip(a,b):yield from leaves(x,y)
    else:yield a,b

def check_panel(panel,first,mid,hm):
    ledger=panel['ledger'];h=tm(ledger['end_s'])-tm(ledger['start_s']);raw=panel['raw_state'];initial=r['initial_state']
    pairs=[('face_species_mol','face_species_mol_s'),('face_energy_j','face_energy_w'),('reaction_species_mol','reaction_species_mol_s'),('cell_work_j','cell_power_w'),('stretch_increment','mechanical_rates_per_s')]
    for target,key in pairs:
        for (x,y),(v,_) in zip(leaves(first[key],mid[key]),leaves(ledger[target],ledger[target])):
            exact=q(x)*h+(q(y)-q(x))*h*h/(2*hm)
            assert v==float(exact)
    for i,row in enumerate(initial['amounts_mol']):
        for j,n in enumerate(row):
            exact=q(n)+q(ledger['face_species_mol'][i][j])-q(ledger['face_species_mol'][i+1][j])+q(ledger['reaction_species_mol'][i][j])
            assert raw['amounts_mol'][i][j]==float(exact)
            e=abs(q(raw['amounts_mol'][i][j])-exact);assert e<=q(ip['amount_absolute_tolerance_mol']);maxima['amount']=max(maxima['amount'],e)
        exact=q(initial['internal_energy_j'][i])+q(ledger['face_energy_j'][i])-q(ledger['face_energy_j'][i+1])+q(ledger['cell_work_j'][i])
        assert raw['internal_energy_j'][i]==float(exact)
        e=abs(q(raw['internal_energy_j'][i])-exact);assert e<=q(ip['energy_absolute_tolerance_j']);maxima['energy']=max(maxima['energy'],e)
    for i,n in enumerate(initial['mechanical_stretches']):
        exact=q(n)+q(ledger['stretch_increment'][i]);assert raw['mechanical_stretches'][i]==float(exact)
        a=q(first['mechanical_rates_per_s'][i]);b=q(mid['mechanical_rates_per_s'][i]);integral=a*h+(b-a)*h*h/(2*hm)
        assert q(ledger['stretch_quadrature_roundoff'][i])==q(ledger['stretch_increment'][i])-integral
        e=abs(q(raw['mechanical_stretches'][i])-q(n)-integral);assert e<=q(ip['stretch_absolute_tolerance']);maxima['stretch']=max(maxima['stretch'],e)
    for key,values in ledger['cell_work_components_j'].items():
        for i,v in enumerate(values):
            a=q(first['cell_power_components_w'][key][i]);b=q(mid['cell_power_components_w'][key][i]);exact=a*h+(b-a)*h*h/(2*hm)
            assert v==float(exact) and q(ledger['component_quadrature_roundoff_j'][key][i])==q(v)-exact
    for i,w in enumerate(ledger['cell_work_j']):
        residual=q(w)-sum((q(v[i]) for v in ledger['cell_work_components_j'].values()),F())
        assert residual==q(ledger['component_sum_residual_j'][i]) and abs(residual)<=q(ip['energy_absolute_tolerance_j'])
first=obs[0]['evaluation']['rates'];mid=obs[1]['evaluation']['rates'];start=tm(obs[0]['time']);hm=tm(obs[1]['time'])-start
check_panel(r['predictor_panel'],first,first,hm/2);check_panel(r['terminal_panel'],first,mid,hm)
assert tm(r['predictor_panel']['ledger']['end_s'])==tm(obs[1]['time'])
assert tm(r['terminal_panel']['ledger']['end_s'])==tm(obs[2]['time'])
c=r['correction'];i=c['cell_index'];li=c['liquid_index'];vi=c['vapor_index'];assert (i,li,vi)==(2,3,2)
raw=r['terminal_panel']['raw_state'];after=copy.deepcopy(raw);delta=q(raw['amounts_mol'][i][li]);v=q(raw['amounts_mol'][i][vi]);after['amounts_mol'][i][li]=0.;after['amounts_mol'][i][vi]=float(v+delta)
assert after==r['corrected_state'];err=q(after['amounts_mol'][i][vi])-v-delta
assert q(c['ideal_liquid_increment_mol'])==-delta and q(c['ideal_vapor_increment_mol'])==delta and q(c['vapor_storage_roundoff_mol'])==err
assert q(c['actual_vapor_increment_mol'])==q(after['amounts_mol'][i][vi])-v
clock=c['clock_evidence'];sample=clock['samples'];h=tm(clock['lower'])-start
assert clock['lower']==r['terminal_panel']['ledger']['end_s'] and clock['policy']==rp and sample['source_ids']==source
for role,rate,suffix in ((0,first,'start'),(1,mid,'mid')):
    assert sample['liquid_rates_'+suffix+'_mol_s']==[rate['face_species_mol_s'][i][li],-rate['face_species_mol_s'][i+1][li],rate['reaction_species_mol_s'][i][li]]
    assert sample['evaporation_'+suffix+'_mol_s']==obs[role]['evaluation']['cell_transfers'][i]['rate_mol_s']
a=q(sample['evaporation_start_mol_s']);b=q(sample['evaporation_mid_mol_s']);slope=(b-a)/hm
assert a>0 and a+slope*h>0
gross=a*h+slope*h*h/2;down=float(gross)
if q(down)>gross:down=math.nextafter(down,-math.inf)
assert c['positive_evaporated_mol']==down and delta<=q(down)*q(rp['correction_fraction_evaporated']) and delta<=q(rp['correction_absolute_mol'])
net=sum(map(q,sample['liquid_rates_start_mol_s']),F());acc=(sum(map(q,sample['liquid_rates_mid_mol_s']),F())-net)/hm
inventory=lambda t:q(sample['start_inventory_mol'])+net*t+acc*t*t/2
assert q(c['numerical_clock_inventory_residual_mol'])==inventory(h)>=0
assert inventory(tm(clock['upper'])-start)<=0 and tm(clock['upper'])-tm(clock['lower'])<=q(ep['time_absolute_s'])
ledger=r['terminal_panel']['ledger'];terms=[ledger['face_species_mol'][i][li],-ledger['face_species_mol'][i+1][li],ledger['reaction_species_mol'][i][li]]
local=4*sum((q(math.ulp(x)) for x in [sample['start_inventory_mol'],*terms,float(delta)]),F())
assert q(c['local_correction_limit_mol'])==local+inventory(h) and delta<=local+inventory(h)
old=r['input_totals'];new=r['candidate_totals'];assert new['events']==old['events']+1==2
for name,addition in [('signed_storage_roundoff_mol',err),('absolute_storage_roundoff_mol',abs(err)),('numerical_phase_correction_mol',delta)]:assert q(new[name])==q(old[name])+addition
for prefix,value in [('',abs(err)),('cumulative_',q(new['absolute_storage_roundoff_mol']))]:
    assert value<=q(rp[prefix+'storage_absolute_mol']) and 2*value<=q(rp[prefix+'element_absolute_mol']) and value*q(rp['molar_mass_kg_mol'])<=q(rp[prefix+'mass_absolute_kg'])
assert q(new['numerical_phase_correction_mol'])<=q(rp['cumulative_correction_absolute_mol'])
original=copy.deepcopy(r['original_operator']['operator']);candidate=r['candidate_operator']['operator'];original['interface_modes'][i]='depleted_no_nucleation';assert original==candidate
assert obs[2]['evaluation']['interface_modes']==candidate['interface_modes']
summary={'status':'passed','scope':'saved speculative terminal arithmetic only; no packet acceptance','selected_cell':i,'root_levels':r['root_order']['refinement_level'],'max_ledger_state_residuals':{k:float(v) for k,v in maxima.items()},'correction_mol':float(delta),'gross_evaporation_mol':down,'fraction':float(delta/q(down)),'storage_roundoff_mol':float(err),'terminal_sha256':hashlib.sha256((D/'terminal-result.json').read_bytes()).hexdigest()}
(P/'audit-result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
