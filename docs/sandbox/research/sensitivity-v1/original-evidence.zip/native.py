from fractions import Fraction
from pathlib import Path
import hashlib
import json
import subprocess
from sludge_sandbox.sensitivity import analyze_sensitivity
from sludge_sandbox.experiments import read_experiment
from sludge_sandbox.run_service import read_run
from sludge_sandbox.job_supervisor import read_job
from audit_ledgers import audit
root=Path('/Users/wanggaoying/Desktop/brickmodel-github')
out=Path('/private/tmp/brick-sensitivity-v1')
design=out/'native-design'
cli='/private/tmp/brick-water-backend-probe/venv/bin/sludge-sandbox'
commands=[['sensitivity-prepare',str(root/'data/sandbox/sensitivity/initial-temperature-contrast-v1.json'),
 '--water-data',str(root/'data/sandbox/water'),'--evidence-data',str(root/'data/sandbox'),'--output',str(design)],
 ['experiment-run',str(design/'experiment')],['sensitivity-analyze',str(design)]]
for i,command in enumerate(commands):
    completed=subprocess.run([cli,*command],timeout=150,capture_output=True,text=True)
    (out/f'command-{i}.stdout').write_text(completed.stdout)
    (out/f'command-{i}.stderr').write_text(completed.stderr)
    (out/f'command-{i}.json').write_text(json.dumps({'argv':[cli,*command],'returncode':completed.returncode}))
    assert completed.returncode==0,completed.stdout+completed.stderr
analysis=analyze_sensitivity(design)
assert json.loads((out/'command-2.stdout').read_text())==analysis
state=read_experiment(design/'experiment')
assert state['status']=='completed' and len(state['candidates'])==len(state['attempts'])==2
assert 0<state['charged_wall_seconds']<=100
paths=list((design/'experiment/jobs').glob('*/run/result.json'))
assert len(paths)==2
for index,attempt in enumerate(state['attempts']):
    jobdir=design/'experiment'/attempt['job_artifact']
    job=read_job(jobdir)
    assert job['child_reaped'] and job['returncode']==0 and job['status']=='completed'
    result,manifest=read_run(jobdir/'run')
    assert result['status']=='completed' and len(result['integration']['steps'])==2
    assert manifest['files']['result.json']==attempt['result_sha256']==analysis['outcomes'][index]['result_sha256']
    path=out/f'ledger-input-{index}.json'
    path.write_text(json.dumps({'run':result['integration'],'initial':result['integration']['states'][0]}))
    checked=audit(path,{})
    assert checked['accepted_steps']==2 and checked['all_saved_prefixes_pass']
    (out/f'ledger-audit-{index}.json').write_text(json.dumps(checked,indent=2))
contrasts=analysis['contrasts']
assert len(contrasts)==1 and contrasts[0]['units']=='K'
assert contrasts[0]['low']==300 and contrasts[0]['high']==300.5
assert len(contrasts[0]['metrics'])==8
for name,metric in contrasts[0]['metrics'].items():
    assert metric['status']=='computed'
    low=Fraction(analysis['outcomes'][0]['metrics'][name])
    high=Fraction(analysis['outcomes'][1]['metrics'][name])
    assert metric['contrast']==float(high-low)
    assert metric['per_unit_slope']==float((high-low)/Fraction(.5))
report={'status':'passed','candidates':2,'accepted_steps':[2,2],
        'charged_wall_seconds':state['charged_wall_seconds'],'contrasts_checked':8,
        'cli_python_equal':True,'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'temperature_contrast':contrasts[0]['metrics']['final_temperature_span_k']}
(out/'verified.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
