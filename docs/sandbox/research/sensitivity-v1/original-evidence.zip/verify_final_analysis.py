from fractions import Fraction as F
from pathlib import Path
import hashlib,json,subprocess
from sludge_sandbox.sensitivity import analyze_sensitivity
from sludge_sandbox.run_service import read_run
from sludge_sandbox.experiments import read_experiment
out=Path('/private/tmp/brick-sensitivity-v1')
design=out/'native-design'
analysis=analyze_sensitivity(design)
state=read_experiment(design/'experiment')
assert len(state['candidates'])==len(state['attempts'])==2
expected=[]
for index,attempt in enumerate(state['attempts']):
    result,manifest=read_run(design/'experiment'/attempt['job_artifact']/'run')
    assert analysis['outcomes'][index]['result_sha256']==manifest['files']['result.json']
    states=result['integration']['states']
    snapshots=[result['initial_snapshot'],result['final_snapshot']]
    totals=[]
    for value in [states[0],states[-1]]:
        water=float(sum((F(row[i]) for row in value['amounts_mol'] for i in [2,3]),F()))
        energy=float(sum(map(F,value['internal_energy_j']),F()))
        totals.append((water,energy))
    spans=[max(s['temperature_k'])-min(s['temperature_k']) for s in snapshots]
    pressures=[max(s['pressure_pa']) for s in snapshots]
    metrics={'final_temperature_span_k':spans[1],'change_temperature_span_k':spans[1]-spans[0],
      'maximum_final_pressure_pa':pressures[1],'change_maximum_pressure_pa':pressures[1]-pressures[0],
      'final_total_water_mol':totals[1][0],'change_total_water_mol':totals[1][0]-totals[0][0],
      'final_total_internal_energy_j':totals[1][1],'change_total_internal_energy_j':totals[1][1]-totals[0][1]}
    assert metrics==analysis['outcomes'][index]['metrics']
    expected.append(metrics)
for name,metric in analysis['contrasts'][0]['metrics'].items():
    difference=F(expected[1][name])-F(expected[0][name])
    assert metric['contrast']==float(difference)
    assert metric['per_unit_slope']==float(difference/F(.5))
response=subprocess.run(['/private/tmp/brick-water-backend-probe/venv/bin/sludge-sandbox','sensitivity-analyze',str(design)],capture_output=True,text=True,timeout=30)
(out/'final-analysis.stdout').write_text(response.stdout)
(out/'final-analysis.stderr').write_text(response.stderr)
assert response.returncode==0 and json.loads(response.stdout)==analysis
for name,path in [('analysis_implementation_sha256','sensitivity.py'),('metric_provider_implementation_sha256','experiments.py')]:
    import sludge_sandbox
    assert analysis[name]==hashlib.sha256((Path(sludge_sandbox.__file__).parent/path).read_bytes()).hexdigest()
summary={'status':'passed','saved_candidates':2,'raw_metrics_reconstructed':16,'contrasts_and_slopes_checked':8,
    'final_cli_python_equal':True,'final_analysis_sha256':analysis['analysis_implementation_sha256'],
    'metric_provider_sha256':analysis['metric_provider_implementation_sha256'],
    'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'qualification':'Saved simulations retain earlier frozen runtime; final source change adds provider identity only. No native rerun or changed physical result.'}
(out/'final-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
