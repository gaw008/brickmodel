"""Registered installed-CLI supervision experiment, one mode per invocation."""
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
OUT = Path('/private/tmp/brick-job-supervisor-v1')
mode = sys.argv[1]
assert mode in ('completed','replayed','cancelled','timeout')
job = OUT/'jobs'/mode
operation = 'replay' if mode == 'replayed' else 'run'
source = OUT/'jobs/completed/run' if mode == 'replayed' else ROOT/'data/sandbox/cases/reacting-wet-slab-v1.json'
args = [sys.executable,'-m','sludge_sandbox','supervise',operation,str(source),
        '--job-directory',str(job),'--wall-seconds','0.05' if mode=='timeout' else '120',
        '--grace-seconds','0.1' if mode=='timeout' else '5']
if operation == 'run':
    args += ['--water-data',str(ROOT/'data/sandbox/water'),'--evidence-data',str(ROOT/'data/sandbox')]
started = time.monotonic()
with (OUT/(mode+'-stdout.log')).open('wb') as stdout, (OUT/(mode+'-stderr.log')).open('wb') as stderr:
    owner = subprocess.Popen(args,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL)
    try:
        if mode == 'cancelled':
            try:
                owner.wait(timeout=10.)
            except subprocess.TimeoutExpired:
                command = [sys.executable,'-m','sludge_sandbox','cancel-job',str(job)]
                reply = subprocess.run(command,capture_output=True,timeout=5.,check=True)
                (OUT/'cancel-request.json').write_bytes(reply.stdout)
            else:
                raise AssertionError('run finished before registered cancellation')
        code = owner.wait(timeout=max(.01,150.-(time.monotonic()-started)))
    finally:
        if owner.poll() is None:
            owner.kill()
            owner.wait()
record = json.loads((job/'job.json').read_bytes())
report = {'mode':mode,'argv':args,'external_elapsed_seconds':time.monotonic()-started,
          'owner_returncode':code,'job_status':record['status'], 'child_reaped':record['child_reaped'],
          'child_returncode':record['returncode'],'hard_killed':record['hard_killed'],
          'metrics':record['metrics'], 'result_verification':record.get('result_verification')}
(OUT/(mode+'-report.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
assert record['child_reaped']
expected = {'completed':'completed','replayed':'completed','cancelled':'cancelled','timeout':'timed_out'}[mode]
assert record['status'] == expected
assert code == (0 if expected=='completed' else 1)
if expected=='completed':
    assert record['metrics']['availability']=='observed_at_wrapper_exit'
    assert record['result_verification']['manifest_verified']
