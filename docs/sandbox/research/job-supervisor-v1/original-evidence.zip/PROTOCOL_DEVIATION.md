# Executed runner limitation, retained rather than hidden

The original native.py was executed for all four registered modes. Reviewer
identified that the timeout mode's outer emergency wait was150 seconds, whereas
PLAN.json requested10. The product supervisor itself correctly used0.05 seconds
work+0.1 seconds grace, hard-killed/reaped its child, and the measured complete
outer experiment took0.269836250 seconds. This is a documented runner protocol
deviation: observed completion was under10 seconds, but the trial did not enforce
the registered10-second outer emergency bound. No rerun or reinterpretation of
that emergency bound is claimed. native.py is retained as actually executed.

The original outer emergency branch kills/reaps only its owned supervisor, not
an orphaned native grandchild. That branch was not entered in these four trials.
The inner supervisor deadline normally precedes the outer deadline; this is not
a watchdog that survives supervisor death. Exceptions before report writing leave
logs and missing report evidence; report absence means incomplete, never passed.
These are experiment-runner limits, not a claim of general orphan cleanup.

The first verify.py audited saved ledgers and replay but only recorded cancellation
and timeout status. native.py independently asserted the expected outcomes. To
make the standalone verifier sufficient, the original is retained as
verify-before-review.py; final verify.py now requires all four actual reports,
expected job states, owner/child exit codes, reaping and measured elapsed bounds.
Installation bytes are independently checked by installed-before/after.json.
No physics, product source, resource policy, saved result or original plan changed.
