# Supervisor, child and CLI review

Disposition: approve the inspected candidate for validation. No CRITICAL or HIGH correctness finding identified. Read-only source/test review; no EOS or test execution by this reviewer.

## Reviewed identities

- `src/sludge_sandbox/job_supervisor.py`: `b14ba8f9598f503514573e89874df5b0e56cf065626ddf3a85f4083d7269a6cd`
- `src/sludge_sandbox/job_child.py`: `397601f6bb7c31fda838ea332cdeddc0d2c15b65a30f754a9614030fa7d00bb6`
- `src/sludge_sandbox/cli.py`: `aa0e86abbf721f798858e46ee3003c5e38b09ee3f1866e091f0cbdccb1874669`
- `tests/sandbox/test_job_supervisor.py`: `58a6948e29d8b2f669334942f786a7b77268088c59ecdc57c8375f9001afbc89`

AST parsing passed for all four files. Ruff, mypy and black were unavailable on the review PATH; no static-tool pass is claimed.

## Ownership and termination

Signals target only the call-owned Popen object. Normal and exception paths wait/reap the child, escalating SIGINT to SIGKILL after grace when required. The inherited flock descriptor remains open in the child; the parent closes its descriptor without an explicit unlock. Lock scope is explicitly the resolved job-parent directory, not machine-wide serialization. The wrapper's deadline includes imports, initialization, integration and diagnostics; it is qualified by grace, polling/reaping and OS scheduling. Forced termination may retain an unsealed run, which is not reported as verified completion.

Cancellation requests are bound to a UUID and never signal a persisted PID. Saved job status explicitly does not prove current liveness. Completion requires exit code zero and a manifest-verified completed run. Resource reporting preserves platform-native RSS units and RUSAGE_SELF scope; hard-kill metrics remain unknown.

## CLI and test adequacy

CLI forwards explicit wall/grace and input directories, uses cooperative SIGINT, and returns nonzero for every supervised status except completed. job-status and cancel-job return command success when an observation/request is produced; neither claims the child is live or cancellation confirmed.

Tests replace only the fixed child's workload while retaining actual subprocess handles, signals, inherited descriptors, sessions and wait/reap behavior. They cover successful and nonzero exits, corrupted artifacts, child signal death, wall timeout and forced kill, cooperative file cancellation, same-parent contention, callback exception cleanup, prelaunch cancellation, wrong request IDs, launch failure, and the actual service-child invalid-input/metrics path without EOS. The owner-death test kills only its live owned process; its separate child has a two-second self-expiry/release path. It tests inherited lock persistence and eventual release without signalling a saved PID.

The CLI test checks option forwarding and timeout exit semantics. These process fixtures establish supervision behavior; they do not establish native thermodynamic success, scientific accuracy, or full Goal completion. Root owns actual suite and native validation evidence.

## Native experiment script review

Read-only review of the following bytes; no tests or EOS launched. AST/JSON parsing passed.

- `native.py`: `c75059215df18b01d6f195be4f703f1d305deb5e6e6d7c5514a09cb7dc85870d`
- `verify.py`: `4c7d2666781114f9a0771ff0d8d29e9f071156fa2fa487c48bb2c74cca688254`
- `PLAN.json`: `b84fb72a27d0c5d9f6d2ea2cb262c9e9ec97c04459ed54ae0e3c3ac6a2721bc9`

The native runner invokes the installed CLI with explicit operation and budgets, retains owner stdout/stderr, and on normal return asserts expected job status, owner exit status and child reaping. Successful run/replay additionally require sealed-result verification and clean-wrapper metrics. The independent verification script audits available accepted ledgers and compares saved run/replay states, steps, times and initial/final snapshots exactly. Exact replay equality is an observation for these inputs, not general floating-platform equivalence or physics validation.

[HIGH] Registered timeout outer budget differs from runner
File: native.py:33
Issue: PLAN.json registers a 10-second external timeout-mode bound, while the runner computes its outer wait from 150 seconds for all modes. The timeout protocol is not implemented as registered.
Fix: Apply the registered per-mode external bound before that trial, or preserve and explicitly identify any protocol deviation. Do not rewrite the registration retroactively as if the mismatch never existed.

[MEDIUM] Verification success omits explicit cancellation/timeout outcome gates
File: verify.py:14
Issue: The verifier records job statuses but does not assert the registered cancelled/timed_out outcomes or owner exit codes. native.py separately checks these, so combined evidence may prove them; verification.json alone does not.
Fix: Include explicit expected statuses and completed native-report/exit-code checks, or limit the verification report's claim to ledger and replay comparison and cite each runner's successful assertion result separately.

Emergency-cleanup limitation: native.py finally kills/reaps only its owned supervisor process. Its normal inner child limit (120 seconds plus 5 seconds grace) precedes the 150-second outer watchdog, but if the supervisor stalls/dies, that outer cleanup does not ensure its inherited-lock-holding child is terminated. No supervisor-death watchdog or descendant cleanup claim is supported. Parent-death behavior is deliberately outside PLAN; process/lock state must be checked independently if this emergency path fires, before another native launch.

Failure-evidence limitation: native.py writes its summary only after owner wait succeeds. An exception during cancellation or timeout leaves logs but may leave no report JSON. Missing report is incomplete/failed evidence, never a successful trial. verify.py does preserve its own failure JSON and traceback. Installation identity remains a separate before/after module comparison under PLAN, not something either script independently proves.

No claim is made here that current native trials passed; their authoritative process outputs and saved artifacts belong to root's execution audit. Experiment disposition: address the timeout registration mismatch and qualify or strengthen the aggregate verification gates before final experimental approval. Production supervisor review remains approved; this is a runner/evidence finding.

## Experiment closeout after disclosed deviation

Re-read final verify.py, PROTOCOL_DEVIATION.md, timeout-report.json and saved verification.json. Final verifier SHA256: `21d318d3470b6d91ebf0d7f7225a9598da6c04fc5d5d34f4c290e9a62086193f`; AST parsing passed. No verifier rerun or native execution was performed by this reviewer.

The final verifier explicitly requires all four reports, expected completed/replayed/cancelled/timed_out states, owner and child exit outcomes, reaping, measured elapsed bounds, and completed-run manifest/metrics evidence. It retains ledger audits and exact saved replay comparisons. The saved verification report records passed with exact saved replay equality. The earlier verifier is retained separately. This resolves the standalone outcome-gate finding.

The timeout report records 0.26983624999411404 seconds external elapsed, timed_out, child return code -9 and child_reaped=true. PROTOCOL_DEVIATION.md correctly preserves the original 150-second outer watchdog versus the registered 10-second bound. Observed completion under 10 seconds does not prove that a 10-second emergency watchdog was enforced. The original runner remains unmodified, with the deviation, missing-report failure semantics and owner-only emergency cleanup limitations disclosed. No claim of general orphan cleanup or a supervisor-death watchdog is supported.

Final disposition: accept the recorded supervision outcomes and strengthened verification with the explicitly retained protocol deviation. The registered outer 10-second emergency enforcement remains unvalidated by this trial. Production-code approval is unchanged. These outcomes do not establish material physics or full Goal completion.
