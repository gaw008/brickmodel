"""Read-only native-result comparisons with unchanged independent ledger oracle."""
import json
from pathlib import Path
import traceback
from sludge_sandbox.run_service import read_run
from sludge_sandbox.job_supervisor import read_job
from audit_ledgers import audit

root = Path(__file__).parent
report = {'status':'started','runs':{}}
try:
    results = {}
    for name in ('completed','replayed','cancelled','timeout'):
        job = read_job(root/'jobs'/name)
        expected = {'completed':'completed','replayed':'completed',
                    'cancelled':'cancelled','timeout':'timed_out'}[name]
        experiment = json.loads((root/(name+'-report.json')).read_bytes())
        assert job['status'] == expected and experiment['job_status'] == expected
        assert experiment['owner_returncode'] == (0 if expected=='completed' else 1)
        assert job['child_reaped'] and job['returncode'] is not None
        assert experiment['child_returncode'] == job['returncode']
        assert experiment['external_elapsed_seconds'] < (10 if name=='timeout' else 150)
        if expected=='completed':
            assert job['returncode'] == 0 and job['result_verification']['manifest_verified']
            assert job['metrics']['availability'] == 'observed_at_wrapper_exit'
        else:
            assert job['returncode'] != 0
        report['runs'][name] = {'status':job['status'],'elapsed_wall_seconds':job['elapsed_wall_seconds'],
                                'hard_killed':job['hard_killed'],'metrics':job['metrics']}
        if name in ('completed','replayed','cancelled') and job.get('result_verification',{}).get('manifest_verified'):
            result, manifest = read_run(root/'jobs'/name/'run')
            results[name] = result
            if result.get('integration',{}).get('steps'):
                path = root/(name+'-ledger-input.json')
                path.write_text(json.dumps({'run':result['integration'],'initial':result['integration']['states'][0]},indent=2))
                report['runs'][name]['ledger_audit'] = audit(path,{})
                report['runs'][name]['accepted_steps'] = len(result['integration']['steps'])
    a,b = results['completed'],results['replayed']
    for field in ('states','steps','times_s'):
        assert a['integration'][field] == b['integration'][field]
    for field in ('initial_snapshot','final_snapshot'):
        assert a[field] == b[field]
    report['replay_exact_saved_numerics'] = True
    report['status'] = 'passed'
except Exception as exc:
    report.update(status='failed',reason=str(exc),traceback=traceback.format_exc())
finally:
    (root/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'replay_exact_saved_numerics':report.get('replay_exact_saved_numerics')}))
raise SystemExit(0 if report['status']=='passed' else 1)
