from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_source_liquid_column import setup,config
from sludge_sandbox.source_wet_column import integrate_source_column,SourceWetColumn
from sludge_sandbox.source_wet_storage import SourceWetStorage

def test_reverse_inventory_reverses_donor_not_enthalpy_sign_assumption(monkeypatch):
    m,s=setup(monkeypatch,count=2)
    a=m.evaluate(s).faces[1]
    b=m.evaluate(tuple(reversed(s))).faces[1]
    assert a.liquid_exchange.donor!=b.liquid_exchange.donor
    assert a.liquid_mol_s==-b.liquid_mol_s
    assert a.liquid_enthalpy_w==-b.liquid_enthalpy_w
    # Water reference h may be negative: energy sign follows J*h, not J alone.
    assert a.liquid_enthalpy_projection_w!=0

def test_zero_mobility_unknown_connection_is_declared_zero(monkeypatch):
    m,s=setup(monkeypatch,count=2,status='unknown',permeability=0.)
    o=m.evaluate(s)
    assert o.faces[1].liquid_exchange.status=='zero_mobility'
    assert o.faces[1].liquid_mol_s==o.faces[1].liquid_enthalpy_w==0

def test_dry_cell_active_mobility_refuses_without_partial_commit(monkeypatch):
    m,s=setup(monkeypatch,count=2)
    dry=replace(s[0],liquid_water_mol=0.,gas_amounts_mol=(.125,.25,0.))
    dry=replace(dry,internal_energy_j=m.storages[0].evaluate(dry,325.).total_internal_energy_j)
    s=(dry,s[1]);m=m.with_depleted_cells(s,(0,))
    r=integrate_source_column(m,s,duration_s=1/1024,steps=1)
    assert r.status=='domain_exit' and 'active_face_requires_existing_liquid' in r.reason
    assert r.states==(s,) and not r.ledgers

def test_liquid_projection_and_energy_budget_exact_sum(monkeypatch):
    m,s=setup(monkeypatch,count=2)
    r=integrate_source_column(m,s,duration_s=1/1024,steps=1)
    assert r.status=='completed',r.reason
    l=r.ledgers[0]
    from sludge_sandbox.source_wet_column import _integrals
    pf,_=_integrals(m.evaluate(s),l.duration_s/2)
    expected=l.roundoff.absolute_energy_j+l.predictor_roundoff.absolute_energy_j
    for f in (*pf,*l.faces):
        expected+=abs(f.energy_decomposition_roundoff_j)
        if hasattr(f,'liquid_enthalpy_projection_j'):expected+=abs(f.liquid_enthalpy_projection_j)
    assert r.energy_roundoff_used_j==expected
    assert l.faces[1].liquid_enthalpy_j!=0

def test_forged_liquid_configuration_pre_inverse(monkeypatch):
    m,s=setup(monkeypatch,count=2)
    object.__setattr__(m,'liquid_transport',object())
    monkeypatch.setattr(SourceWetStorage,'invert',lambda *a,**kw:pytest.fail('fake config reached inverse'))
    with pytest.raises(ValueError):m.evaluate(s)
