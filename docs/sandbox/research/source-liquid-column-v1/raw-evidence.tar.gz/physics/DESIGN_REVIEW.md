# Source N-cell liquid transport design: read-only physics review

Status: design review only; no new implementation verified, no EOS/trajectory execution, no repository changes. Reviewed existing LiquidTransportConfig, SolidFluidHeat._liquid_faces and liquid_transport.py primitives. The proposed optional source-column admission is consistent under the following explicit limits.

## Driving pressure and decoded state

Use the same already inverted cell state for T, inventories, mechanical liquid volume, available fluid volume and pressure. The existing mechanical closure is planar/no capillary pressure: liquid pressure equals total pore gas pressure. Therefore liquid Darcy driving pressure is total liquid pressure difference, not water-vapor partial pressure, equilibrium vapor pressure, or a chemical potential difference. This primitive is horizontal and includes no gravity or capillary/suction term. It does not become a general unsaturated-sludge flow law merely because mobility depends on saturation.

At each wet cell, obtain liquid molar volume and molar enthalpy from the same water provider at decoded T and liquid pressure. No second inverse is required; one additional liquid property query at that decoded point is consistent. Dry state must preserve None molar volume/enthalpy and zero saturation, rather than evaluating nonexistent liquid.

Nominal saturation S=V_liquid/V_available, with V_available the liquid-plus-gas space used by storage. It is not V_liquid/V_bulk or V_liquid/V_gas. A manufactured V_available still makes this a manufactured constitutive state. Use SourceWetPoint.pressure_error_pa including the available-volume contribution; the inner fluid pressure_error_bound_pa alone omits that term. Supply the full nonnegative bound without narrowing it to force a direction claim.

The bound remains conditional at fixed decoded temperature: inverse T uncertainty is not propagated to p, source fit error is unknown, and uncertainty in saturation, mobility and liquid enthalpy is not propagated through the Darcy rate. The helper's direction tag and full_inverse_direction_certified=false must be retained. Nominal S and nominal T/P selection inside a mobility table is not whole-uncertainty-domain certification.

## Shared face equations and limitations

For left/right half distances dL,dR>0, mobility Mi=ki*kri/mui and pressure difference dp=pL-pR:

Q = A*dp/(dL/ML+dR/MR)
J_liquid = Q/v_donor
E_liquid = J_liquid*h_donor

Positive Q is left to right; use left donor for Q>0, right for Q<0. Both cells receive the exact same signed molar and energy face values with opposite signs. This is a frozen face upwind discretization; if donor and receiver liquid specific volumes differ, it is not an exact compressible steady volume-flux solution. Storage re-closes the cell fluid volume after inventory changes.

Preserve source identity checks between liquid states. Mobility must be interpolated at each cell's saturation within its declared T/P/S domain, without extrapolation. A supplied fixed-pressure direction is conditionally resolved only when abs(dp)>epsL+epsR. Otherwise the existing primitive may return a nominal flow with 'nominal_direction_not_certified'; this is not automatically a rejected face, and must not be reported as direction-certified.

Existing semantics matter: disabled connection returns zero before relation evaluation. With an active connection, relation-domain checks occur before zero-mobility early return. Unknown/disconnected with nonzero mobility is refused; connected flow with nonzero mobility requires positive liquid on both sides. Do not relabel an unknown connection as disconnected/no-flow merely to continue a run. Any change to these semantics would require an explicit contract change and regression tests.

The source host should require exact LiquidTransportConfig and exactly N relations/N-1 connections, manufactured relation/connection classifications, and allow_manufactured=True. Config classification may permit broader values in the old host; that is not authorization for source host material admission. Bind the full config, table contents/domains, connection identities and source hashes into the host identity. None must retain old closed/open complete-run golden behavior, including serialized shape if this is required by the parity gate.

## Combined balance and boundary handling

At each internal face evaluate gas/conduction once and liquid once, then form one total energy flux from gas diffusive enthalpy + gas advective enthalpy + liquid donor enthalpy + conduction. Preserve each component and its signed decomposition rounding.

Cell i liquid update is old + left_liquid - right_liquid - local_phase. Gas H2O receives local_phase plus its gas-face divergence. Energy receives only total face-energy divergence. There is no additional latent or phase source; liquid donor h already shares the water phase energy reference. Do not replace h by u or add separate pQ flow work.

Use Fraction to aggregate all adjacent liquid, gas, phase and energy increments before the single binary projection. Pairwise liquid fluxes and phase transfer cancel exactly in global total water; final global residual equals external water exchange plus accepted signed rounding. The predictor roundoff remains separate. Negative inventory, unsupported dry or constitutive domain exit preserves the complete prior accepted prefix.

Both outer liquid fluxes are exactly zero in this admission. A programmed right gas/heat reservoir can stay open, but must not fabricate a liquid reservoir or drop/duplicate liquid fields when replacing its gas/heat face. Global total water external contribution remains the gas H2O boundary integral only. If the new face or ledger adds a liquid enthalpy field, its decomposition must explicitly include it rather than hide that physical term in a field called numerical roundoff.

## Independent numerical plan after code freezes

A three-cell artificial liquid v=1.8e-5 m3/mol and u=75T-300000 J/mol permits an independent state oracle: solve printed source solid integral + gas caloric sum + liquid U for T; then Vgas=Vavailable-Nl*v, p=Ng*R*T/Vgas and h_liquid=u+p*v. Use the existing independent gas/phase RHS as a base, and implement the equations above independently from liquid_face_exchange and decoded-state helper.

Choose explicit manufactured saturation tables with a nonconstant kr(S) and distinct nonuniform half-widths, all three cells initially wet and safely inside table domains. Frozen tables provide a separate algebraic case for exact resistance/donor testing. Ensure both internal liquid faces are nonzero so the middle cell receives both. A reversed pressure order should switch the donor and its h, verified as an algebraic point case rather than tuning a long trajectory.

For a bounded smooth closed three-cell run, compare midpoint 2/4/8 steps to a segmented/tight DOP853 reference, preserving predeclared conditions and tolerances. Track gas-only, liquid-only, combined water and total energy exchanges explicitly. Verify each cell and global exact Fraction ledgers independently. Then a saved open-result audit can verify zero boundary liquid with nonzero boundary gas water. Runtime-probe the manufactured oracle first; no native EOS trajectory should be launched by this design task.

Add a focused pressure-uncertainty case whose available-volume contribution changes the direction qualification from resolved to nominal, without changing nominal dp. Verify the full bound reached the helper. Include disabled, unknown active, zero-mobility and dry connected cases with exactly the existing semantics. No numerical outcome is claimed here.

Remaining source gaps: actual liquid connectivity, mobility/saturation relationship, capillarity, effective porosity/available volume and source-material matching. Source Cp and native water EOS do not close these gaps; material_qualified stays false.
