import json,time,hashlib
from pytest import MonkeyPatch
from test_mass_wet_storage import setup
from test_solid_fluid_heat import ingredients
from test_liquid_solid_fluid_heat import liquid_host
from test_surface_balance_kernel import snapshot
start=time.monotonic()
with MonkeyPatch.context() as mp:
 setup(mp)
 host=liquid_host(ingredients.__wrapped__())
 state=host.state_from_temperatures([[2.,1e-5,2.,.02],[2.,1e-5,1.,.01]],[300.,301.])
 out=host.evaluate(state,0)
 value=snapshot(out);raw=json.dumps(value,sort_keys=True,separators=(',',':'))
 print(json.dumps({'elapsed_s':time.monotonic()-start,'observation_digest':hashlib.sha256(raw.encode()).hexdigest(),'observation':value,'sources':host.source_ids},indent=2))
