# N格单事件：必须检查项

只读已提交next-runtime-slice、当前liquid_transport/source_wet_column；无EOS、生产或测试修改。下一实现尚未视为通过。

1. k必须从同一个实际完整4N root order唯一('liquid',k,0)导出；root_index仍为两路径索引0/1，不能混作k。两路径必须同k、同初模式、同固定kg/provider/energy，保留全部实际采样及原root共用深度。起始4N全正；非选中液体与全部气体在整个选中root enclosure区间严格正（含凸多项式内点最小值），不是只看采样或末点。切触/并列/气先/零初始不授本路线。

2. 完整液三项=(J_left,−J_right,−E)，与source panel逐项同数。允许净排空含运输，但必须全区间仿射E>0、净液导数全区间<0、有限根被括住。gross仅积分positive E，绝不把总排空/face drainage当gross。原ExactAffineEvidence及writeback的absolute、gross fraction、local ULP、时间、累计门槛逐项保留；delta只是有界数值相校正，不代表实际多蒸发了transport总量。Nl'=Jleft−Jright−E且E<=0的纯/主运输情况没有本phase写回授权。

3. 液面每个实际采样均独立复核完整源/几何/关系/连接/decoded状态绑定。q=A*(PL−PR)/(dL/ML+dR/MR)，ML/R=permeability*relative_permeability/viscosity（都按实际float的Fraction）；donor由exact q符号选，n=q/vdonor，Q=n*hdonor。返回J=float(n)、Q_saved=float(Q)，通常不等于float(J_saved*hdonor)。必须保留并核对两种舍入关系，不能用错误J*h逐位要求替代真实原语。误差方向范围仍fixed_decoded_temperature，全部液体压力半径含volumeextra；未授full_inverse_direction_certified。

4. 每个活动面两样本及整个终端仿射J符号需与原donor一致（上端外推也检查）。disabled/zero_mobility与零流status从原配置复核，不能仅看J==0或空reversal列表。Q的仿射积分与J的仿射积分是分别由真实样本建立的离散量；Q=J*h仅在采样时按各自舍入成立，不能声称整个区间的仿射Q等于两条仿射J,h乘积或连续守恒PDE真解。

5. terminal必须继续使用完整N格source prefix：同内部面一次J积分、一次Q积分，左右格反号；气体/导热/液体焓按原totalU功组成保留，不另加潜热。写回只修改[k,liquid/vapor]，除这两个槽外全部库存逐位不变，所有U逐位不变；fixedkg不变。明确仅一次模式k改变，其他格仍wet。

6. dry后仍用原预声明mobility/connection。saturation0的确切零mobility可使两侧液流零；不可在事件后暗改参数或禁连通。正零饱和mobility反例应保留DomainExit和此前候选/普通接受前缀，不能伪造dry成功。零液相化学驱动仍检查凝结/未知域退出。

7. 每实际event/common样本必须有N个pressure bound：仅精确Nl=0且模式dry的k走SourceDryPressure，其余Nl>0走SourceInversePressure。两路径模式图一致，逐格N/U/T/报告P及完整条件P均记录，顶层max由这些格重算。共享V策略只作用同一个cell k两路径的同live storage/volume参数，不能顺带抵消其他格或湿格压力。任何湿格原门槛失败必须阻止全事件接受。

8. 全链每格数组从唯一原始初态累计普通、terminal、writeback、dry。writeback actual delta=(-d,+d+rho)仅k；U校正0。每prefix并列represented和terminal-full-exact残差，rho显式，不在mode/分段起点清零。全域共享内部faceJ/Q应Fraction严格抵消，只剩真实外边界；phase每格液汽相消。全域水/H/O/N/流体质量/U由逐格残差相加独立核对，固定干物绝对组成未知但差量0，不造dry分子量。不能把只看总量替代逐格检查（左右错配可全球抵消）。

9. 原IntegrationPolicy逐格量纲阈值与原event-only校正/元素/质量阈值区别保留。全域余额若另设准入要求必须明示使用何原阈值；不能因为有N格就暗乘N放大门槛，也不能把per-cell<=tol说成sum<=tol。仅记录全域精确余额与据各格推得的N*tol上界可作为诊断，但不冒充新政策通过。

建议冻结后保存制造N3/k1：全实际calls、面配置/两decoded状态/原exchange及源sample、clock/prior、完整prefix和写回、每个dry普通ledger、各格pressure rows、局部及全域余额。独立审核将只读这些原始对象重建；一次成功和positive-zero-mobility拒绝例分开保留。数值事件成功不等于真实污泥适用性或一般多事件/再润湿支持。
