"""Additional independent native scalar budgets, identities, qualifications."""
from pathlib import Path
from fractions import Fraction as F
import runpy,json,hashlib,time
P=Path(__file__).parent;dec=runpy.run_path('/private/tmp/brick-source-dry-transition-v1/physics/audit_manufactured.py')['dec'];f=Path('/private/tmp/brick-source-multicell-transition-v1/root/native-result.json');start=time.monotonic();raw=f.read_bytes();r=dec(json.loads(raw));checks=0

def ck(x,label):
 global checks
 checks+=1
 if not x:raise AssertionError(label)
ck(hashlib.sha256(raw).hexdigest()=='2660d33ec0e832e006d5adcccd8ddcf38cc314ac5e65a17830cdf2f73cbdc51d','SHA')
t=r['transition'];ep=r['event_policy'];policy=r['integration_policy'];identity=r['adapter_provenance']['energy_model_identity']
for key,v in dict(time_absolute_s=1e-8,amount_absolute_mol=1e-11,energy_absolute_j=1e-7,temperature_absolute_k=1e-5,pressure_absolute_pa=1e-4,maximum_refinements=32).items():ck(ep[key]==v,'original event '+key)
for key,v in dict(amount_absolute_tolerance_mol=1e-7,energy_absolute_tolerance_j=1e-3,relative_tolerance=1e-8,maximum_steps=4,maximum_rejections=4).items():ck(policy[key]==v,'original integration '+key)
for i,cap in enumerate(r['captures']):
 ck(cap['ordinal']==i+1 and cap['energy_identity']==identity and cap['packed_input']['energy_model_identity']==identity,'actual energy identity')
 obs=cap['evaluation'];ck(obs['material_qualified'] is False and obs['source_evaluation']['material_qualified'] is False and obs['operator_identity']==cap['operator_identity'],'actual operator and qualifications')
 ck(obs['source_evaluation']['full_inverse_liquid_direction_certified'] is False and obs['source_evaluation']['liquid_pressure_interval_scope']=='fixed_decoded_temperature','liquid conditional direction scope')
for c in t['candidates']:
 z=c['terminal'];rp=ep['roundoff_policy'];rho=z['totals']['signed_storage_roundoff_mol'];absolute=z['totals']['absolute_storage_roundoff_mol'];d=z['totals']['numerical_phase_correction_mol'];ck(absolute==abs(rho) and d<=F(rp['cumulative_correction_absolute_mol']),'original cumulative correction')
 for pre in ('','cumulative_'):ck(absolute<=F(rp[pre+'storage_absolute_mol']) and 2*absolute<=F(rp[pre+'element_absolute_mol']) and absolute*F(rp['molar_mass_kg_mol'])<=F(rp[pre+'mass_absolute_kg']),'storage element mass '+pre)
 for rows in c['cell_pressure_endpoints']:
  for b in rows:ck(b['source_certified'] is b['event_admitted'] is b['material_qualified'] is False,'all pressure qualifications')
ca,cb=[c['terminal']['clock'] for c in t['candidates']];distance=max(abs(ca['lower']['seconds']-cb['upper']['seconds']),abs(ca['upper']['seconds']-cb['lower']['seconds']));ck(distance==t['clock_distance_upper_s'] and t['clock_gate']==(distance<=F(ep['time_absolute_s'])),'absolute full clock')
ck(t['material_qualified'] is r['material_qualified'] is False and t['numerical_event_accepted'] is r['numerical_event_accepted'] is False,'no event or material acceptance')
res={'checks':checks,'elapsed_s':time.monotonic()-start,'clock_upper_s':float(distance),'actual_event_times_s':[float(c['terminal']['clock']['lower']['seconds']) for c in t['candidates']],'common_end_s':float(t['candidates'][0]['end']['seconds']),'original_policy_preserved':True,'event_accepted':False,'material_qualified':False};(P/'NATIVE_SCOPE_RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
