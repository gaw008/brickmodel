"""Offline N3/k1 Fraction oracle. Geometry pinned to actual fixture source."""
import runpy,json,math,hashlib,time
from pathlib import Path
from fractions import Fraction as F
P=Path(__file__).parent;dec=runpy.run_path('/private/tmp/brick-source-dry-transition-v1/physics/audit_manufactured.py')['dec'];start=time.monotonic();checks=0

def ck(x,label):
 global checks
 checks+=1
 if not x:raise AssertionError(label)
def up(x):
 y=float(x)
 return F(math.nextafter(y,math.inf)) if F(y)<x else F(y)
f=Path('/private/tmp/brick-source-multicell-transition-v1/root/manufactured-result.json');raw=f.read_bytes();sha=hashlib.sha256(raw).hexdigest();ck(sha=='db8cc74ec8e6c119d10054e28a00794ec08526a2d54f7e25ba148f7bff98f211','input SHA');r=dec(json.loads(raw));t=r['cases']['shared_multicell'];ck(t['selected_cell_index']==1,'selected middle cell');summaries=[]
for path,c in enumerate(t['candidates']):
 z=c['terminal'];panel=z['panel'];a,b=panel['first'],panel['interior'];hm=b['evaluation']['time']['seconds']-a['evaluation']['time']['seconds'];h=z['clock']['lower']['seconds']-a['evaluation']['time']['seconds'];H=panel['upper']['seconds']-a['evaluation']['time']['seconds'];order=z['root_order']['order'];ck(order['earliest_labels']==[['liquid',1,0]] and len(order['polynomials'])==12,'all twelve competitors')
 pc=z['prior_clock'];choice=pc['choices'][path];spent=choice['order']['refinement_level']+choice['additional_refinement_rounds']+pc['additional_rounds'][path];ck(z['clock']['iterations']==spent+z['additional_clock_rounds']<=32 and z['reused_clock_rounds']==spent,'prior root budget')
 for sample in (a,b):
  rawobs=sample['evaluation']['source_evaluation'];face=rawobs['faces'][2];ex=face['liquid_exchange'];L,R=rawobs['liquid_states'][1:3];lm,rm=ex['left_mobility'],ex['right_mobility'];mob=lambda v:F(v['permeability_m2'])*F(v['relative_permeability'])/F(v['viscosity_pa_s']);dp=F(L['pressure_pa'])-F(R['pressure_pa']);q=F(.01)*dp/(F(.15625)/mob(lm)+F(.1875)/mob(rm));donor=L if q>0 else R;n=q/F(donor['molar_volume_m3_mol']);Q=n*F(donor['enthalpy_j_mol'])
  ck([ex['volume_flow_m3_s'],ex['molar_flow_mol_s'],ex['enthalpy_flow_w']]==list(map(float,(q,n,Q))),'independent Darcy and signed donor h')
  ck(ex['donor']=='left' and Q<0 and n>0,'positive recipient water negative reference enthalpy')
  ck(face['liquid_enthalpy_projection_w']==F(float(Q))-F(float(n))*F(donor['enthalpy_j_mol']),'donor h projection')
  ck(ex['pressure_difference_error_pa']==float(up(F(L['pressure_error_pa'])+F(R['pressure_error_pa']))) and ex['full_inverse_direction_certified'] is False,'pressure scope preserved')
  ck(rawobs['faces'][1]['liquid_exchange']['status']=='disabled','original inactive first face')
  for i,s in enumerate(rawobs['liquid_states']):ck(s['pressure_error_pa']==rawobs['cells'][i]['inverse']['point']['pressure_error_pa'],'total decoded P error')
 # Independently integrate every saved rate component before represented incidence.
 pieces={name:(exact,error) for name,exact,error in z['prefix']['integrals']};A=a['evaluation']['rates'];B=b['evaluation']['rates']
 def flat(x):return [v for row in x for v in row] if isinstance(x[0],list) else x
 for field,(exact,errors) in pieces.items():
  want=[F(x)*h+(F(y)-F(x))*h*h/(2*hm) for x,y in zip(flat(A[field]),flat(B[field]))];ck(want==exact,'independent full source affine integrals '+field);ck([F(float(x))-x for x in want]==errors,'all shared integral projections')
 liquid0=F(A['face_species_mol_s'][2][0]);liquidm=F(B['face_species_mol_s'][2][0]);ck(liquid0>0 and liquid0+(liquidm-liquid0)*H/hm>0,'whole affine donor sign')
 E0=F(A['reaction_species_mol_s'][1][3]);Em=F(B['reaction_species_mol_s'][1][3]);gross=E0*h+(Em-E0)*h*h/(2*hm);ck(min(E0,E0+(Em-E0)*H/hm)>0,'strict actual gross evaporation')
 samples=z['clock']['samples'];n0=F(samples['start_inventory_mol']);rate=sum(map(F,samples['liquid_rates_start_mol_s']),F());acc=sum(((F(y)-F(x))/hm for x,y in zip(samples['liquid_rates_start_mol_s'],samples['liquid_rates_mid_mol_s'])),F());val=lambda x:n0+rate*x+acc*x*x/2;lo,hi=F(),H
 for _ in range(z['clock']['iterations']):
  mid=(lo+hi)/2
  if val(mid)>=0:lo=mid
  else:hi=mid
 ck(lo==h and hi==z['clock']['upper']['seconds']-a['evaluation']['time']['seconds'] and max(rate,rate+acc*H)<0,'full three-term legacy clock')
 for pp in order['polynomials']:
  if (pp['family'],pp['cell'],pp['index'])==('liquid',1,0):continue
  ts=[F(),hi];quad=pp['quadratic'];linear=pp['linear']
  if quad>0 and 0<-linear/(2*quad)<hi:ts.append(-linear/(2*quad))
  ck(min(pp['initial']+linear*x+quad*x*x for x in ts)>0,'other inventory interior positivity')
 before=z['prefix']['raw_state'];after=z['corrected_state'];delta=[[F(x)-F(y) for x,y in zip(ra,rb)] for ra,rb in zip(after['amounts_mol'],before['amounts_mol'])];rho=sum(delta[1],F());d=F(before['amounts_mol'][1][0]);rp=z['event_policy']['roundoff_policy'];gd=float(gross)
 if F(gd)>gross:gd=math.nextafter(gd,-math.inf)
 ck(d<=F(rp['correction_absolute_mol']) and d<=F(gd)*F(rp['correction_fraction_evaporated']),'phase correction bound never drainage')
 ck(all(x==0 for i,row in enumerate(delta) for j,x in enumerate(row) if (i,j)not in ((1,0),(1,3))) and after['internal_energy_j']==before['internal_energy_j'] and rho==z['totals']['signed_storage_roundoff_mol'],'only k phase correction and all U unchanged')
 # Global/local full chain oracle.
 ordinary=[] if path==0 else [t['refinement']['approach']['trial']];origin=(ordinary[0] if ordinary else c['seed'])['initial'];exch=[[F()]*4 for _ in range(3)];full=[[F()]*4 for _ in range(3)];energy=[F()]*3;fulle=[F()]*3;corr=[[F()]*4 for _ in range(3)];storage=[F()]*3;rows=[];policy=c['seed']['policy'];masses=[g['molar_masses_kg_mol'] for g in c['captures'][0]['evaluation']['source_evaluation']['gas_states']]
 def record(state,when,phase):
  cells=[]
  for i in range(3):
   nr=[F(x)-F(y)-v-w for x,y,v,w in zip(state['amounts_mol'][i],origin['amounts_mol'][i],exch[i],corr[i])];fn=[F(x)-F(y)-v-w for x,y,v,w in zip(state['amounts_mol'][i],origin['amounts_mol'][i],full[i],corr[i])];u=F(state['internal_energy_j'][i])-F(origin['internal_energy_j'][i])-energy[i];uf=F(state['internal_energy_j'][i])-F(origin['internal_energy_j'][i])-fulle[i];water=nr[0]+nr[3]+storage[i];ele=[['H',2*water],['O',water+2*nr[1]],['N',2*nr[2]]];mass=F(masses[i]['H2O'])*water+F(masses[i]['O2'])*nr[1]+F(masses[i]['N2'])*nr[2]
   ck(max(map(abs,nr+fn))<=F(policy['amount_absolute_tolerance_mol']) and max(abs(u),abs(uf))<=F(policy['energy_absolute_tolerance_j']),'each original per-cell budget');cells.append(dict(cell_index=i,inventory_residual_mol=nr,energy_residual_j=u,full_inventory_residual_mol=fn,full_energy_residual_j=uf,water_balance_residual_mol=water,event_water_storage_roundoff_mol=storage[i],fluid_element_residuals_mol=ele,fluid_mass_residual_kg=mass))
  row=dict(time=when,phase=phase,cell_balances=cells)
  for key in ('inventory_residual_mol','full_inventory_residual_mol'):row[key]=[sum((c[key][j] for c in cells),F()) for j in range(4)]
  for key in ('energy_residual_j','full_energy_residual_j','water_balance_residual_mol','event_water_storage_roundoff_mol','fluid_mass_residual_kg'):row[key]=sum((c[key] for c in cells),F())
  row['fluid_element_residuals_mol']=[[el,sum((dict(c['fluid_element_residuals_mol'])[el] for c in cells),F())] for el in ('H','O','N')];ck(max(map(abs,row['inventory_residual_mol']+row['full_inventory_residual_mol']))<=F(policy['amount_absolute_tolerance_mol']) and max(abs(row['energy_residual_j']),abs(row['full_energy_residual_j']))<=F(policy['energy_absolute_tolerance_j']),'global original budget not N times');rows.append(row)
 def step(state,l,phase,exact=None):
  ns=[[F(l['face_species_mol'][i][j])-F(l['face_species_mol'][i+1][j])+F(l['reaction_species_mol'][i][j]) for j in range(4)] for i in range(3)];us=[F(l['face_energy_j'][i])-F(l['face_energy_j'][i+1])+F(l['cell_work_j'][i]) for i in range(3)];en,eu=(ns,us) if exact is None else exact
  ck(sum(us,F())==F(l['face_energy_j'][0])-F(l['face_energy_j'][-1])+sum(map(F,l['cell_work_j']),F()),'all internal energy exchange cancels')
  for j in range(4):ck(sum((ns[i][j] for i in range(3)),F())==F(l['face_species_mol'][0][j])-F(l['face_species_mol'][-1][j])+sum((F(x[j]) for x in l['reaction_species_mol']),F()),'all internal mol exchange cancels')
  for i in range(3):
   for j in range(4):exch[i][j]+=ns[i][j];full[i][j]+=en[i][j]
   energy[i]+=us[i];fulle[i]+=eu[i]
  record(state,l['end_s'],phase)
 for trial in ordinary:
  for s,l in zip(trial['reference']['states'][1:],trial['reference']['steps']):step(s,l,'wet_reference')
 fp=pieces['face_species_mol_s'][0];lr=pieces['reaction_species_mol_s'][0];ue=pieces['face_energy_w'][0];work=pieces['cell_power_w'][0];step(before,z['prefix']['ledger'],'wet_terminal',([[fp[i*4+j]-fp[(i+1)*4+j]+lr[i*4+j] for j in range(4)] for i in range(3)],[ue[i]-ue[i+1]+work[i] for i in range(3)]));corr=delta;storage[1]=rho;record(after,z['prefix']['ledger']['end_s'],'writeback')
 for s,l in zip(c['reference']['states'][1:],c['reference']['steps']):step(s,l,'dry_reference')
 ck(rows==t['balance_paths'][path],'all exact saved local/global balance rows')
 ck(c['reference']['states'][0]==after and len(c['reference']['steps'])>0,'actual mixed-mode continuation')
 for cap in c['captures']:
  if cap['evaluation'] is None:continue
  obs=cap['evaluation']['source_evaluation'];ck(cap['state']['amounts_mol'][1][0]==0 and all(cap['state']['amounts_mol'][i][0]>0 for i in (0,2)),'only middle dry');ck(obs['faces'][2]['liquid_exchange']['status']=='zero_mobility' and obs['faces'][2]['liquid_mol_s']==0,'original dry zero-mobility branch')
 summaries.append({'prefixes':len(rows),'dry_steps':len(c['reference']['steps']),'terminal_liquid_transport_mol':float(fp[8]),'terminal_gross_evaporation_mol':float(gross),'recipient_terminal_U_change_j':float(F(before['internal_energy_j'][2])-F(c['seed']['initial']['internal_energy_j'][2])),'rho':str(rho)})
# Actual all-cell endpoint comparison; dry shared only k, wet original retained.
pressure=[]
for idx,k in enumerate((0,-1)):
 cs=[c['captures'][k] for c in t['candidates']];cellrows=[];original=[];selected=[]
 for i in range(3):
  inv=[c['evaluation']['source_evaluation']['cells'][i]['inverse'] for c in cs];me=[v['point']['fluid']['mechanical'] for v in inv];row=[max(abs(F(x)-F(y)) for x,y in zip(cs[0]['state']['amounts_mol'][i],cs[1]['state']['amounts_mol'][i])),abs(F(cs[0]['state']['internal_energy_j'][i])-F(cs[1]['state']['internal_energy_j'][i])),abs(F(me[0]['temperature_k'])-F(me[1]['temperature_k']))+sum((F(v['temperature_error_bound_k']) for v in inv),F()),abs(F(me[0]['pressure_pa'])-F(me[1]['pressure_pa']))+sum((F(v['point']['pressure_error_pa']) for v in inv),F())];bounds=[c['cell_pressure_endpoints'][k][i] for c in t['candidates']]
  for j,bound in enumerate(bounds):ck(bound['inverse']==inv[j] and bound['state']==cs[j]['evaluation']['source_states'][i],'actual all-cell pressure state binding')
  for j,bb in enumerate(bounds):
   co=bb['continuation'];pp=inv[j]['point'];mm=me[j]
   if i!=1:
    nl,ng,R,B,T,eT,P0,eP=co['inputs'];ck([T,eT,P0,eP]==list(map(F,(mm['temperature_k'],inv[j]['temperature_error_bound_k'],mm['pressure_pa'],pp['pressure_error_pa']))),'wet original pressure inputs');Tmin=co['temperature_domain_k'][0];Pmax=co['pressure_domain_pa'][1];L=Pmax/Tmin*(1+nl*B*Pmax/(ng*R*Tmin));g=eP+L*eT;L2=(P0+g)/(T-eT)*(1+nl*B*(P0+g)/(ng*R*(T-eT)));ck(co['global_radius_pa']==g and co['radius_pa']==eP+L2*eT,'independent wet global bootstrap pressure')
   else:
    ng,R,T,eT,V,eV,P0,eP=co['inputs'];tb=[T-eT,T+eT];vb=[V-eV,V+eV];analytic=[ng*R*tb[0]/vb[1],ng*R*tb[1]/vb[0]];er=eP+ng*R/vb[0]*eT;interval=[min(analytic[0],P0-er),max(analytic[1],P0+er)];ck(co['analytic_interval_pa']==analytic and co['interval_pa']==interval and co['radius_pa']==max(P0-interval[0],interval[1]-P0),'independent dry complete T V pressure')
  conditional=abs(F(me[0]['pressure_pa'])-F(me[1]['pressure_pa']))+sum((x['continuation']['radius_pa'] for x in bounds),F());original.append(conditional);cellrows.append(row)
  if i==1:
   pair=t['shared_pressure_pairs'][idx];ck(pair['endpoints']==bounds and pair['bound_pa']==pair['joint_bound_pa'],'joint only selected middle');chosen=pair['bound_pa']
   parts=[];nts=[]
   for j,bb in enumerate(bounds):
    co=bb['continuation'];ng,R,T,eT,V,eV,P0,eP=co['inputs'];pp=inv[j]['point'];fluid=F(pp['fluid']['pressure_error_bound_pa']);maxp=F(pp['fluid']['envelope']['pressure_range_pa'][1]);g=up(fluid+up(eV*maxp**2/(ng*R*T)));ex=up(eV*min(maxp,P0+g)**2/(ng*R*T));total=up(fluid+ex);proj=abs(total-fluid-ex);nh=F(math.fsum(bb['state']['gas_amounts_mol']));nr=F(float(float(nh)*float(R)));dn=abs(nh-ng);dnr=abs(nr-nh*R);spacing=lambda x:F(math.ulp(float(up(x))));mult=spacing(abs(nr)*(T+eT));box=((dn*R+dnr)*(T+eT)+mult)/(V-eV)+spacing((abs(nr)*(T+eT)+mult)/(V-eV));eta=fluid+proj+box
    ck(list(pair['error_parts'][j].values())==[bb['initial_bounds_pa'][0],fluid,g,ex,total,proj,dn,dnr,box,eta],'all shared error parts');parts.append(eta);nts.append((ng,R,T-eT,T+eT,V-eV,V+eV))
   aa,bb=nts;num=[aa[1]*(aa[0]*aa[2]-bb[0]*bb[3]),aa[1]*(aa[0]*aa[3]-bb[0]*bb[2])];cs0=[x/v for x in num for v in aa[4:]];ideal=[min(cs0),max(cs0)];joint=[ideal[0]-sum(parts,F()),ideal[1]+sum(parts,F())];ck(pair['ideal_interval_pa']==ideal and pair['joint_interval_pa']==joint and chosen==max(map(abs,joint)),'joint only full shared T V corners')
  else:chosen=max(row[3],conditional)
  selected.append(chosen)
 ck(cellrows==t['cell_endpoint_differences'][idx] and original==t['cell_conditional_pressure_bounds_pa'][idx] and selected==t['cell_selected_pressure_bounds_pa'][idx],'all-cell pressure and selected rows')
 ck([max(x[j] for x in cellrows) for j in range(4)]==t['endpoint_differences'][idx][3] and max(selected)==t['selected_pressure_bounds_pa'][idx],'top-level maxima preserve all cells')
 pressure.append([float(x) for x in selected])
ck(all(row==[False,True,False] for row in t['cell_selected_pressure_gates']) and t['numerical_event_accepted'] is False,'wet neighbors block total acceptance')
failures=[{'case':x['case'],'reason':x.get('reason'),'stage':x.get('stage'),'candidate_statuses':[c['status'] for c in x.get('candidates',[])]} for x in r['retained_failures']];ck(any('active_face_requires_existing_liquid_both_sides' in str(x) for x in r['retained_failures']),'real positive-dry-mobility failure retained')
result={'checks':checks,'elapsed_s':time.monotonic()-start,'input_sha256':sha,'paths':summaries,'cell_selected_pressure_pa':pressure,'event_accepted':t['numerical_event_accepted'],'retained_failures':failures,'scope':'saved manufactured N3/k1 arithmetic; no EOS or model imports'};(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
