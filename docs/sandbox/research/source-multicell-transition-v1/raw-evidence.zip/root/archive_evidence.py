"""Archive frozen stage evidence and verify every member without model execution."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

repo = Path('/Users/wanggaoying/Desktop/brickmodel-github')
temporary = Path('/private/tmp/brick-source-multicell-transition-v1')
destination = repo / 'docs/sandbox/research/source-multicell-transition-v1'
archive_path = destination / 'raw-evidence.zip'
assert not archive_path.exists(), 'Do not overwrite existing evidence'
freeze = json.loads((temporary / 'root/source-freeze.json').read_text())
review = json.loads((temporary / 'code-review/RUNNER_REVIEW_FINAL.json').read_text())
execution_files = list(freeze['files'])
for path, sha in review['files_sha256'].items():
    execution_files.append({'path': path, 'sha256': sha, 'bytes': (repo / path).stat().st_size})
for entry in execution_files:
    raw = (repo / entry['path']).read_bytes()
    assert len(raw) == entry['bytes']
    assert hashlib.sha256(raw).hexdigest() == entry['sha256']
    assert raw == (temporary / 'root/frozen' / entry['path']).read_bytes()

members = []
with ZipFile(archive_path, 'x', ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(temporary.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        assert not path.is_symlink(), path
        raw = path.read_bytes()
        name = str(path.relative_to(temporary))
        archive.writestr(name, raw)
        members.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with ZipFile(archive_path) as archive:
    assert set(archive.namelist()) == {item['path'] for item in members}
    assert len(archive.namelist()) == len(members)
    for member in members:
        raw = archive.read(member['path'])
        assert len(raw) == member['bytes']
        assert hashlib.sha256(raw).hexdigest() == member['sha256']
        assert raw == (temporary / member['path']).read_bytes()

raw_archive = archive_path.read_bytes()
manifest = {
    'baseline': '3fdea988f23a42ecb993f4ff7830a425aa232c9d',
    'reviewed_execution_files_unchanged': execution_files,
    'archive': {
        'path': archive_path.name, 'bytes': len(raw_archive),
        'sha256': hashlib.sha256(raw_archive).hexdigest(), 'member_count': len(members),
        'all_members_reopened_and_byte_equal': True,
    },
    'members': members,
    'scope': 'Frozen raw evidence and package snapshots; hashes do not certify physical correctness',
}
(destination / 'final-freeze.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive']))
