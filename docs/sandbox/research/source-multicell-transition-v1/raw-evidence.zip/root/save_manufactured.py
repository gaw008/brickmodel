"""Persist returned test trajectories and structured failures; no extra solves."""
from collections.abc import Mapping
from dataclasses import fields,is_dataclass
from fractions import Fraction
from pathlib import Path
import importlib,json
import numpy as np

OUTPUT=Path('/private/tmp/brick-source-multicell-transition-v1/root/manufactured-result.json')
results={};failures=[]

def encode(value):
    if isinstance(value,Fraction):return {'numerator':value.numerator,'denominator':value.denominator}
    if isinstance(value,np.ndarray):return {'dtype':str(value.dtype),'shape':list(value.shape),'values':encode(value.tolist())}
    if isinstance(value,np.generic):return encode(value.item())
    if is_dataclass(value):
        return {'type':type(value).__module__+'.'+type(value).__qualname__,
                'fields':{f.name:encode(getattr(value,f.name)) for f in fields(value)
                          if f.name not in ('adapter','dry_adapter','storage')}}
    if isinstance(value,Mapping):return {k:encode(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [encode(v) for v in value]
    if value is None or type(value) in (str,int,float,bool):return value
    raise TypeError(type(value).__name__)

def pytest_collection_modifyitems(items):
    for module_name in ('test_source_dry_transition','test_source_multicell_transition'):
        module=importlib.import_module(module_name)
        original=module.evaluate_source_dry_transition
        def observed(refinement,_original=original,**kwargs):
            column=refinement.approach.proposal.original_trial.adapter.column
            shared=kwargs.get('shared_volume') is not None
            label=('multicell' if column.cell_count>1 else 'programmed' if hasattr(column,'base') else 'closed')
            label=('shared_' if shared else '')+label
            try:out=_original(refinement,**kwargs)
            except Exception as exc:
                if hasattr(exc,'candidates'):
                    failures.append({'case':label,'type':type(exc).__name__,'reason':str(exc),
                                     'stage':getattr(exc,'stage',None),'candidates':encode(exc.candidates)})
                raise
            if label not in results:results[label]=encode(out)
            return out
        module.evaluate_source_dry_transition=observed

def pytest_sessionfinish(session,exitstatus):
    document={'classification':'manufactured_test_fixture','native_eos_used':False,
              'pytest_exitstatus':int(exitstatus),'cases':results,'retained_failures':failures,
              'omitted_live_fields':['adapter','dry_adapter','storage']}
    pending=OUTPUT.with_suffix('.pending');pending.write_text(json.dumps(document,indent=2,allow_nan=False)+'\n')
    pending.replace(OUTPUT)
