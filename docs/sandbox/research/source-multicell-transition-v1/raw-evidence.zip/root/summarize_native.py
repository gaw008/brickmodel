"""Produce a display-only view of the single saved N3 run; never call physics."""
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path

root = Path('/private/tmp/brick-source-multicell-transition-v1/root')
dest = Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/source-multicell-transition-v1')
raw = (root / 'native-result.json').read_bytes()
data = json.loads(raw)


def fields(value):
    return value.get('fields', value) if isinstance(value, dict) else value


def display(value):
    if isinstance(value, dict):
        if set(value) == {'numerator', 'denominator'}:
            return float(Fraction(value['numerator'], value['denominator']))
        return {key: display(item) for key, item in value.items()}
    if isinstance(value, list):
        return [display(item) for item in value]
    return value


transition = fields(data['transition'])
summary = {
    'raw_path_in_archive': 'root/native-result.json',
    'sha256': hashlib.sha256(raw).hexdigest(),
    'bytes': len(raw),
    'numeric_view': 'Fraction leaves converted to approximate binary64 for display; exact values retained in raw JSON',
    'process_session': 8377,
    'process_exit_code': 0,
}
for name in (
    'status', 'numerical_comparison_completed', 'numerical_event_accepted',
    'material_qualified', 'scope', 'cell_count', 'selected_cell_index',
    'wall_seconds', 'build_seconds', 'outer_seconds', 'per_trial_callback_cap',
    'per_dry_path_callback_cap', 'total_callback_cap',
    'backend_constructors_started', 'backend_constructors_completed',
    'constructor_reference_anchor_checks', 'initial_energy_evaluations_attempted',
    'initial_energy_evaluations_completed', 'initial_temperature_k',
    'initial_phase_water_mol_s', 'initial_selected_left_liquid_mol_s',
    'initial_selected_right_liquid_mol_s', 'initial_selected_net_liquid_loss_mol_s',
    'horizon', 'all_actual_attempts_retained',
):
    summary[name] = display(data[name])
summary['callbacks'] = len(data['captures'])
summary['callbacks_by_phase'] = dict(Counter(item['phase'] for item in data['captures']))
summary['transition'] = {
    name: display(value) for name, value in transition.items()
    if name not in ('refinement', 'candidates', 'balance_paths', 'shared_volume', 'shared_pressure_pairs')
}
summary['candidates'] = []
for raw_candidate, balances in zip(transition['candidates'], transition['balance_paths'], strict=True):
    candidate = fields(raw_candidate)
    reference = fields(candidate['reference'])
    terminal = fields(candidate['terminal'])
    summary['candidates'].append({
        'status': candidate['status'],
        'reason': candidate['reason'],
        'selected_cell_index': terminal['selected_cell_index'],
        'path_root_index': terminal['root_index'],
        'reused_clock_rounds': terminal['reused_clock_rounds'],
        'additional_clock_rounds': terminal['additional_clock_rounds'],
        'dry_reference_status': reference['status'],
        'dry_steps': len(reference['steps']),
        'dry_captures': len(candidate['captures']),
        'cumulative_prefixes': len(balances),
        'pressure_record_types': [[item['type'] for item in row] for row in candidate['cell_pressure_endpoints']],
        'final_balance': display(balances[-1]),
    })
(dest / 'native-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('sha256', 'bytes', 'callbacks', 'status', 'numerical_event_accepted')}))
