from dataclasses import replace
from fractions import Fraction as F
import signal
import time
import pytest
from test_source_multicell_transition import completed_multicell
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox._heos_kernel import HEOSCandidate
from sludge_sandbox.source_dry_transition import _audit_path


def test_actual_matrix_global_budget_and_legacy_selected_identity():
    started=time.monotonic(); calls=[]
    def timeout(*args):raise TimeoutError('independent_40s_cap')
    previous=signal.signal(signal.SIGALRM,timeout);signal.setitimer(signal.ITIMER_REAL,40.)
    try:
        with pytest.MonkeyPatch.context() as patch:
            patch.setattr(HEOSCandidate,'__init__',lambda *a,**k:pytest.fail('native EOS forbidden'))
            actual_evaluate=ExactSourceColumn.evaluate
            def observed(*args,**kwargs):
                assert len(calls)<48,'independent48callcap'
                calls.append(1)
                return actual_evaluate(*args,**kwargs)
            patch.setattr(ExactSourceColumn,'evaluate',observed)
            generator=completed_multicell.__wrapped__()
            out=next(generator)
            try:
                patch.setattr(ExactSourceColumn,'evaluate',lambda *a,**k:pytest.fail('passive check called physics'))
                candidate=out.candidates[0]
                # Each exact perturbation is within the original per-cell N bound,
                # while their global sum exceeds it; only the global gate rejects.
                last=candidate.reference.states[-1];amounts=last.amounts_mol.copy()
                delta=F(1,2**24); tolerance=F(candidate.seed.policy.amount_absolute_tolerance_mol)
                assert delta<tolerance<3*delta
                for i in range(3):amounts[i,1]+=float(delta)
                assert all(F(float(amounts[i,1]))-F(float(last.amounts_mol[i,1]))==delta for i in range(3))
                altered=replace(last,amounts_mol=amounts)
                altered_candidate=replace(candidate,reference=replace(candidate.reference,states=(*candidate.reference.states[:-1],altered)))
                with pytest.raises(ValueError,match='cumulative_original_balance_budget'):_audit_path(altered_candidate)
                # The new full matrix correctly rejects equal-content foreign storage.
                bound=candidate.pressure_endpoints[0]; foreign=replace(bound.storage)
                assert foreign is not bound.storage and foreign.model_identity==bound.storage.model_identity
                foreign_bound=replace(bound,storage=foreign)
                foreign_bound.check()
                rows=list(candidate.cell_pressure_endpoints); row=list(rows[0]);row[1]=foreign_bound;rows[0]=tuple(row)
                with pytest.raises(ValueError,match='source_cell_pressure_binding_changed'):
                    replace(candidate,cell_pressure_endpoints=tuple(rows)).check()
                print({'elapsed_seconds':time.monotonic()-started,'actual_callbacks':len(calls),'global_original_budget_rejected':True,'full_matrix_foreign_storage_rejected':True})
                # The retained selected-cell API must enforce the same live storage binding.
                with pytest.raises(ValueError):
                    replace(candidate,pressure_endpoints=(foreign_bound,candidate.pressure_endpoints[1])).check()
            finally:
                generator.close()
    finally:
        signal.setitimer(signal.ITIMER_REAL,0.);signal.signal(signal.SIGALRM,previous)
