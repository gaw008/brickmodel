# N3 delivery content review — preliminary

No substantive factual errors were found in the current REPORT.md, DERIVATION.md and native-summary.json. Their reviewed hashes are in DOC_REVIEW_PRELIMINARY.json. Six central-document additions and the not-yet-created archive remain outside this preliminary scope. No model, EOS or test rerun was performed.

The complete raw native JSON was read and hashed: 45,527,737 bytes, SHA256 2660d33ec0e832e006d5adcccd8ddcf38cc314ac5e65a17830cdf2f73cbdc51d. The actual native log and saved values confirm 71.769373832969 s wall time, 32 whole-column callbacks, four constructors/reference anchors and three initial U evaluations. The simulated common endpoint is about 1.0937596266e-6 s, correctly distinguished from runtime. Both candidates select cell 1 and retain one mixed reference step and 3/4 cumulative prefixes.

Original clock/N/U/T comparisons pass. Every old reported/independent cell P comparison fails. Only the selected dry cell's new shared P bound passes; wet cells 0/2 remain false, the aggregate pressure gate remains false, and numerical_event_accepted/material_qualified are false. The report and summary preserve those distinctions and make no claim that normal process completion or dry-cell P acceptance certifies the whole event or real material.

The stated manufactured 221 checks, numerical transport/evaporation and nonzero fine writeback rho match the actual saved physics result. The completed native physics files report 265+132=397 checks; those are independent physics-agent arithmetic/scope results, not a second recomputation performed by this review. Six reviewed production/test hashes still match the prior code approval. Actual installed identity records 128 modules/135 files, and the already-read 52+52 final test results remain consistent.

The derivation matches the reviewed implementation: full 4N unique root competition and remaining depth, fixed decoded liquid sample law and signed donor enthalpy, affine donor scope, only selected liquid/vapor writeback, explicit predeclared dry mobility, original per-cell and global N/U budgets, and all-cell pressure gates. It preserves limitations on continuous trajectory certification, rewetting, repeat events, real materials and the complete original Goal.

The summary script review is recorded separately in SUMMARY_SCRIPT_REVIEW.md. Final delivery approval awaits only the announced completed central-document additions and archive metadata, not another model execution.
