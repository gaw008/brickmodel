"""Pure control probe: execute only the actual initialization-loop AST with sentinels.

No run(), module import, model constructor, provider, EOS or physics is invoked.
Sentinel returns are control data, never claimed as physical observations.
"""
import ast
from copy import deepcopy
from dataclasses import dataclass, asdict, replace
from pathlib import Path
import json

runner=Path('docs/sandbox/research/source-multicell-transition-v1/run_native.py')
tree=ast.parse(runner.read_text())
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
loop=next(n for n in ast.walk(run) if isinstance(n,ast.For) and ast.unparse(n.target)=='(i, storage)')
timeout=next(n for n in ast.walk(run) if isinstance(n,ast.FunctionDef) and n.name=='timeout')
module=ast.fix_missing_locations(ast.Module(body=[timeout,loop],type_ignores=[]))
@dataclass(frozen=True)
class State:
    inventory:float
    gas:tuple
    internal_energy_j:float
@dataclass(frozen=True)
class Point:
    total_internal_energy_j:float

def probe(failure):
    calls=[];snapshots=[]
    result=dict(initial_energy_attempts=[],initial_energy_evaluations_attempted=0,initial_energy_evaluations_completed=0)
    env=dict(result=result,states=[],replace=replace,encode=lambda x:asdict(x),
             INITIAL_LIQUID_MOL=(.25,1e-11,.25),INITIAL_GAS_MOL=((.125,.25,1e-12),(.1875,.25,1e-12),(.125,.25,1e-12)))
    env['save']=lambda:snapshots.append(deepcopy(result))
    class Sentinel:
        def __init__(self,i):self.i=i
        def state(self,*args):return State(*args)
        def evaluate(self,state,temp):
            calls.append(self.i)
            if self.i==1 and failure=='ordinary':raise RuntimeError('sentinel_initial_U_failure')
            if self.i==1 and failure=='outer':env['timeout']()
            return Point(float(self.i+10))
    env['storages']=tuple(Sentinel(i) for i in range(3))
    exc=None
    try:exec(compile(module,str(runner)+':initialization-control-only','exec'),env)
    except Exception as err:exc=err
    if failure:
        assert calls==[0,1] and result['initial_energy_evaluations_attempted']==2 and result['initial_energy_evaluations_completed']==1
        assert len(result['initial_energy_attempts'])==2
        assert 'point' in result['initial_energy_attempts'][0] and 'point' not in result['initial_energy_attempts'][1]
        assert result['initial_energy_attempts'][1]['exception_type']==type(exc).__name__
        assert snapshots[-1]==result and len(env['states'])==1
        assert bool(result.get('outer_timeout_requested'))==(failure=='outer')
    else:
        assert exc is None and calls==[0,1,2]
        assert result['initial_energy_evaluations_attempted']==result['initial_energy_evaluations_completed']==3
        assert len(env['states'])==len(result['initial_energy_attempts'])==3
        assert snapshots[-1]==result
    json.dumps(result,allow_nan=False)
    return dict(case=failure or 'all_success',attempted=result['initial_energy_evaluations_attempted'],completed=result['initial_energy_evaluations_completed'],failure_type=None if exc is None else type(exc).__name__,snapshots=len(snapshots))

print(json.dumps({'status':'passed','cases':[probe(None),probe('ordinary'),probe('outer')],'executed_runner_run':False,'actual_model_calls':0,'eos_calls':0},indent=2))
