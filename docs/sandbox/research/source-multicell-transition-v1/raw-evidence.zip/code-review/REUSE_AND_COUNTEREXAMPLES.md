# 多格来源耗尽：只读接口检查与待执行反例

基线 3fdea988f23a42ecb993f4ff7830a425aa232c9d。此文只读检查既有 N1 实现；以下是新 N 格实现的反例设计，不是已执行失败，也不把当前明确拒绝 N>1 的实现称为漏洞。没有运行测试、EOS、模型 check 或安装，没有修改生产代码。

## 当前 N1 假设的确切位置

- `SourceDryCandidate.check` 的成功绑定在 event/common 两 capture 上只核 `source_states[0]`、`cells[0].inverse`。`pressure_endpoints` 要求两个 `SourceDryPressure`；没有 N 格形状或每格压力类型/索引绑定。
- `execute_source_dry_candidate` 同样只从 `storages[0]` 建两项干压力。新增完整记录时要保存部分成功行，不能在最后一个湿格后处理失败时丢掉此前已完成项。
- `_audit_path` 的 exchange/full/correction 是 4 向量，energy/full_energy/storage 是标量；所有状态只取第 0 格、面 0/1、反应 0。精确 prefix integrals 中 `fn[j]-fn[j+4]+rn[j]`、`fu[0]-fu[1]+power[0]` 也只支持第 0 格。水/元素/流体质量诊断及写回修正同样只针对它。
- `compare_source_dry_candidates` 的 N 差已经覆盖 `amounts_mol.flat`，但 U/T/报告 P 和完整 T 压力仅看第 0 格。不能误认为只改 N 的 max 就完成全格比较。
- `_check_shared_volume` 声明绑定当前 `storages[0]`。扩展后应明确绑定 selected dry cell，不能把它用于其他湿格，也不能因测试模型复用了同一个 storage 对象而推定空间单元共享实际体积参数。
- `source_terminal` 原入口拒绝 N>1、液体运输、非第 0 格首根；另一代理正负责泛化。上述 N1 假设当前受到这个 guard 保护。

## 最重要的待执行反例

| 优先项 | 输入或有意破坏方式 | 必须看到的结果 |
|---|---|---|
| 1. 非零事件索引和不同单元身份 | actual N2/N3，唯一首根在 cell 1，其他格保持有液且 T/gas/U 非对称。各格用独立 storage/volume 实例，避免 `(storage,)*N` 掩盖错索引。 | 只 cell 1 模式切换；旧 `pressure_endpoints` 精确对应完整 2×N 中的第 1 项。所有 event/common 压力都按本格 state/inverse/storage 绑定；交换列、错用 cell 0、缺一格或多一格均拒绝。 |
| 2. 非事件格单独拒绝 | 实际新制造案例中 selected dry 格的 shared P 合格，而某湿格的原完整压力区间未决或超过原 P 门槛；另用局部热边界的实际轨迹构造非事件格 T/U 限制主导的情况。 | 顶部 maxima 和每格行一致；任一湿格 P 未决/超限，或任一格 N/U/T 失败，都保持整体 numerical_event_accepted=false。不能只检查 selected dry P，也不能跳过 None。若用更严格阈值制造反例，必须在新案例构造时显式声明，不能事后改已绑定记录或放宽原 native gate。 |
| 3. 全局相消不能掩盖逐格错误 | N3 的两个非事件格分别注入相反的库存/能量差，和为零；以已返回真实轨迹的副本做只读篡改探针。另在真实不同粗/细路径比较中关注局部变化而非总 U。 | candidate/balance binding 拒绝篡改；如错误到达账本比较，各格原容差必须分别检查。全局净和为零不能使超限单元通过。不可把同一总计复制给每格。 |
| 4. 内面索引与完整 prefix 积分 | N3 非对称内部液流与供体焓，两个内面交换不相等，selected cell 1 具有左/右两面。独立按 `face[i]-face[i+1]+reaction[i]` 计算各格 ordinary/full residual。 | 逐格 N/U、完整精确终端项一致；内部面在全局求和恰好相消，只剩外边界/局部源。没有遗漏第二内面、重复计算第一面、用 gas-only 能量代替含供体液焓的原 face energy。原 full-prefix 与普通投影两套量同时保留。 |
| 5. 写回只影响 selected 的水分量 | actual 非零 selected 索引的 terminal；检查所有 N×4 分量、所有 U，故意把修正移到别格或别种气体，同时保持全局和不变。 | 仅 selected liquid/vapor 可有原 writeback 改动，所有 U 不变，其余格/种类不变；signed_storage_roundoff 只记 selected 一次，再聚合一次。原相变 correction 预算不能被运输残差、跨格抵消或额外格的水修正消耗冒充。 |
| 6. 运输在干侧的真实分支 | 两案例明确分开：沿用现常数 kr=0.5；新声明 kr(0)=0 且湿端非零的制造表。第一例应实际记录 dry 侧 DomainExit；第二例应记录湿段非零液流/供体焓，干后相邻 face 的 zero_mobility，其余 wet-wet 面仍真实求值。 | 不能悄悄把全部 liquid_transport=None、连接改 disabled 或所有流量清零。dry 段不捏造液体密度/焓。未知/断开有活动 mobility 仍按原规则拒绝；不是再润湿支持。 |
| 7. 后处理/资源失败的部分证据 | 在真实 dry 积分已完成后，仅令 event 行较后一个湿格的 pressure assessment 抛异常；另在 mixed 全列 callback 中途发生域退出/资源停止。 | reference、所有已返回整列 capture、终端和已完成的压力格/行仍可追查；不得截短 2×N 记录再报告成功。来源 callback 是整列一次，不是每格各一次；新增纯压力 check 不增加 EOS 或隐式重跑 callback。保存上层已完成 candidate。 |
| 8. 两条路径选中不同单元/预算身份 | 对比两条真实路径的同域 root order：唯一首根标签不是同一个 cell；或把 root_index（粗/细路径 0/1）误当 selected_cell_index（空间索引）。 | 不因两根时间很接近就接受不同事件。两路径都绑定原完整 4N 面板/同一 selected 标签，保留 prior+additional 原共用细化预算；不同事件或有歧义首根拒绝/未决，不静默改回 cell 0。 |

这些测试宜先有真实 actual fixture，再在独立保存副本上做篡改断言。篡改失败只能证明绑定检查有效，不能冒称真实物理数值误差或门槛执行案例；后者必须由实际求值轨迹和构造前明确的政策提供证据。

## 可直接复用、需要保持的边界

1. `ExactSourceColumn.pack/unpack/evaluate/with_depleted_cells` 已处理 N×4 状态、N 个 U 和显式逐格模式；原 `integrate_exact`、capture/replay 和 `SourcePrefixTrial` 已覆盖完整列。无需新 driver。
2. `SourceWetColumn.with_depleted_cells(states,(selected,))` 已只切选中精确零液水格，并保留 storage、能量身份及原 transport 内容。
3. `SourceDryPressure` 与 `SourceInversePressure` 分别提供 dry/wet 的被动完整 T 压力核查；完整 2×N 中按实际模式和库存精确匹配类型。共享 dry pair 只施用于两路径同一 selected dry cell 的显式声明，其他格保留其原合法比较。
4. `measure_source_endpoint_pair` 已有逐格 N/U/T/P 数组及四个 maxima，可直接用于同一 common time。它明确要求样本时间相同；两条事件 lower 时刻通常不同，不能伪改 capture.time 或绕过其校验来复用，应保留两原始事件时间、原 clock gate 及相同的逐格算术定义。
5. `test_source_wet_column.setup(count=...)` / `test_source_liquid_column.config/setup` 是现成 actual source manufactured 入口；保留同一个已构造 column，避免在仍激活禁用 legacy reaction 的 fixture 中重入 setup。它们不是材料数据。
6. 现 `config` 的关系是 `frozen_manufactured`、常数 kr=0.5。要构造 kr(0)=0、湿端非零，须明确新 `manufactured_test_fixture` + `tabulated_saturation_relation`，不能给 frozen 类型塞变值。`decoded_liquid_state` 已在 dry 不请求 liquid TP，`liquid_face_exchange` 已在零 mobility 时返回零；有正 mobility 的 dry 邻面会按原规则退出。这是声明关系下的运输分支，不能升级材料资格。

## 审查结论

当前 N1 合同没有新发现的缺陷。以上八项用于之后实际 N 格增量的独立审查，尚未执行，无测试通过声明。最小实现继续使用原 source terminal、capture、reference 与 pressure interfaces；重点是逐格完整绑定、全前缀累计和全格 gate，避免新增比较包装层替代真实混合湿干推进。

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — read-only interface investigation complete; new implementation remains to be reviewed when frozen.
