"""Actual manufactured N1 input, full old/new terminal fields; no native EOS."""
from dataclasses import fields, replace
import importlib.util
import json
from pathlib import Path
import sys
import pytest
from test_source_dry_transition import prepare
from sludge_sandbox.source_net_prefix import _same
from sludge_sandbox.source_terminal import build_source_terminal

root = Path(__file__).parent
name = 'sludge_sandbox._source_terminal_legacy'
spec = importlib.util.spec_from_file_location(name, root/'source_terminal.before.py')
legacy = importlib.util.module_from_spec(spec)
sys.modules[name] = legacy
spec.loader.exec_module(legacy)
checks = []
with pytest.MonkeyPatch.context() as patch:
    refinement, _ = prepare(patch)
    event = refinement.approach.proposal.event_policy
    original = refinement.approach.proposal.original_trial
    for label, seed, kwargs in (
        ('standalone', original, {}),
        ('prior_coarse', original, {'prior_clock': refinement.clock, 'root_index': 0}),
        ('prior_shifted', refinement.shifted_trial, {'prior_clock': refinement.clock, 'root_index': 1}),
    ):
        before = legacy.build_source_terminal(seed, event_policy=event, **kwargs)
        after = build_source_terminal(seed, event_policy=event, **kwargs)
        for field in fields(before):
            assert _same(getattr(before, field.name), getattr(after, field.name)), (label, field.name)
            checks.append((label, field.name))
        assert after.selected_cell_index == 0
    failures = []
    for change in ({'terminal_method':'euler'}, {'maximum_refinements':2}, {'terminal_window_s':1e-12}):
        outputs = []
        for function in (legacy.build_source_terminal, build_source_terminal):
            try:
                function(original, event_policy=replace(event, **change))
            except ValueError as exc:
                outputs.append((type(exc).__name__, str(exc)))
            else:
                raise AssertionError(('expected refusal', change))
        assert outputs[0] == outputs[1], (change, outputs)
        failures.append({'change':change, 'same_refusal':outputs[0]})
result = {'old_field_comparisons':len(checks), 'checks':checks, 'failures':failures, 'new_selected_index':0, 'native_eos_calls':0}
(root/'legacy-compare.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
