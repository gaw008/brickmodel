from pathlib import Path
p=Path('docs/sandbox/research/source-multicell-transition-v1/run_native.py')
s=p.read_text()
def edit(old,new):
 global s
 assert s.count(old)==1, (s.count(old),old[:80])
 s=s.replace(old,new)
edit('Prepared single HEOS/source shared-volume wet-to-dry study', 'Prepared single N3 HEOS/source mixed wet-to-dry study')
edit('OUTER_SECONDS = 210.', 'OUTER_SECONDS = 510.')
edit('INITIAL_LIQUID_MOL = 1e-11', "CELL_COUNT = 3\nSELECTED_CELL = 1\nINITIAL_LIQUID_MOL = (.25, 1e-11, .25)\nINITIAL_GAS_MOL = ((.125, .25, 1e-12), (.1875, .25, 1e-12), (.125, .25, 1e-12))\nWET_MODES = ('existing_liquid',)*CELL_COUNT\nMIXED_MODES = ('existing_liquid', 'depleted_no_nucleation', 'existing_liquid')")
edit("PREVIOUS_RUNNER = 'source-dry-transition-v1/run_native.py'", "PREVIOUS_RUNNER = 'source-dry-shared-pressure-v1/run_native.py'")
edit("PREVIOUS_RUNNER_SHA256 = 'a7916d30ee0eb0abf5852a76c5b92eec3a70acd1b0e130cd05a1dc556f2d6e71'", "PREVIOUS_RUNNER_SHA256 = 'f0c8a659053630ccad55901b0a7f6bf16c07b35313f54ce596087f54f277196b'")
edit("scope='explicit_shared_volume_N1_source_wet_to_dry_numerical_scenario',", "scope='explicit_N3_source_liquid_transport_single_selected_cell_transition',\n        cell_count=CELL_COUNT, selected_cell_index=SELECTED_CELL,")
edit('initial_liquid_mol=INITIAL_LIQUID_MOL, prior_1e_minus_6_scenario_unchanged=True,', 'initial_liquid_mol=INITIAL_LIQUID_MOL, initial_gas_mol=INITIAL_GAS_MOL,\n        prior_N1_scenarios_unchanged=True,')
edit('constructor_reference_anchor_checks=0, initial_energy_evaluations_attempted=0,', 'constructor_reference_anchor_checks=0, initial_energy_evaluations_attempted=0,\n        initial_energy_evaluations_completed=0, initial_energy_attempts=[],')
edit("raise TimeoutError('outer_210s_budget_exceeded')", "raise TimeoutError('outer_510s_budget_exceeded')")
edit('from sludge_sandbox.source_wet_column import SourceWetColumn', 'from sludge_sandbox.source_wet_column import SourceWetColumn\n        from sludge_sandbox.mass_wet_transport import WetFace\n        from sludge_sandbox.liquid_transport import SaturationMobilityTable, LiquidConnection\n        from sludge_sandbox.solid_fluid_heat import LiquidTransportConfig')
edit('storage, _ = source.make_case(root)', 'template_storage, _ = source.make_case(root)')
start=s.index('        column = SourceWetColumn(')
end=s.index('        actual = ExactSourceColumn.evaluate',start)
s=s[:start]+'''        # Independent spatial volume parameters; all paths retain these actual
        # objects. Providers/Cp are shared declarations, not extra constructions.
        storages = tuple(replace(template_storage, volume=replace(template_storage.volume))
                         for _ in range(CELL_COUNT))
        require(len({id(value) for value in storages}) == CELL_COUNT
                and len({id(value.volume) for value in storages}) == CELL_COUNT,
                'independent_cell_storage_and_volume_objects')
        require(all(value.volume.value_m3 == .001 and value.volume.error_m3 == 1e-12
                    for value in storages), 'original_volume_and_error_unchanged')
        widths = (.25, .3125, .375)
        faces = tuple(WetFace(.01, (widths[i]/2, widths[i+1]/2), (0., 0.),
            (0.,)*3, 0., 1.8e-5, ('manufactured:source-column-transport',))
            for i in range(CELL_COUNT-1))
        # Mirror the preregistered manufactured terminal fixture numerically;
        # bind this actual run's table source to the runner bytes rather than a
        # dummy asset digest. These remain declared numerical test coefficients.
        table = SaturationMobilityTable(saturation_knots=(0., 1e-18, 1.),
            permeability_m2=(1e-18,)*3, relative_permeability=(0., .5, .5),
            viscosity_pa_s=(.001,)*3, temperature_range_k=(310., 350.),
            pressure_range_pa=(1e4, 1e7), model_id='manufactured:source-multicell-native-liquid-mobility',
            version='1', classification='manufactured_test_fixture',
            source_ids=('manufactured:source-multicell-native-liquid-mobility',),
            source_asset_sha256=(('source-multicell-transition-v1/run_native.py', result['runner_sha256']),),
            relation_kind='tabulated_saturation_relation')
        connections = tuple(LiquidConnection(status='disabled' if i == 0 else 'connected',
            connection_id='manufactured:source-multicell-native-liquid-link-'+str(i), version='1',
            classification='manufactured_test_fixture',
            source_ids=('manufactured:source-multicell-native-liquid-links',))
            for i in range(CELL_COUNT-1))
        liquid = LiquidTransportConfig(relations=(table,)*CELL_COUNT,
            connections=connections, allow_manufactured=True)
        column = SourceWetColumn(storages, (InversePolicy(1e-5, 1e-6, 100),)*CELL_COUNT,
            chemical, (0., 1e-9, 0.), faces, widths, .01, WET_MODES,
            ('manufactured:source-column-transport',), liquid_transport=liquid)
        shared = declare_source_shared_dry_volume(storages[SELECTED_CELL])
        shared.check()
        result['shared_volume_declaration'] = encode(shared)
        result['liquid_transport_configuration'] = encode(liquid)
        result['live_cell_parameter_identities'] = [dict(cell=i, storage_object_id=id(value),
            volume_object_id=id(value.volume), storage_identity=value.model_identity)
            for i, value in enumerate(storages)]
        result['shared_parameter_runtime_admission'] = dict(selected_cell=SELECTED_CELL,
            same_initial_storage_object=shared.storage is storages[SELECTED_CELL],
            same_initial_volume_object=shared.volume is storages[SELECTED_CELL].volume,
            distinct_spatial_storage_objects=True, distinct_spatial_volume_objects=True,
            object_identity_scope='current_process_only_not_offline_reconstruction')
        save()
        states = []
        result['initial_temperature_k'] = (325.,)*CELL_COUNT
        for i, storage in enumerate(storages):
            state = storage.state(INITIAL_LIQUID_MOL[i], INITIAL_GAS_MOL[i], 0.)
            item = dict(cell=i, unset_energy_state=encode(state), temperature_k=325.)
            result['initial_energy_attempts'].append(item)
            result['initial_energy_evaluations_attempted'] += 1
            save()
            try:
                point = storage.evaluate(state, 325.)
                item['point'] = encode(point)
                state = replace(state, internal_energy_j=point.total_internal_energy_j)
                item['state_with_energy'] = encode(state)
                result['initial_energy_evaluations_completed'] += 1
                states.append(state)
                save()
            except Exception as exc:
                item.update(exception_type=type(exc).__name__, exception=str(exc))
                save()
                raise
        require(result['initial_energy_evaluations_attempted'] ==
                result['initial_energy_evaluations_completed'] == CELL_COUNT,
                'three_actual_initial_energy_evaluations')
        adapter = ExactSourceColumn(column)
        initial = adapter.pack(tuple(states))
        result.update(status='constructed', initial=encode(initial),
            adapter_provenance=encode(adapter.provenance()), build_seconds=time.monotonic()-started)
        save()
''' + s[end:]
edit("require((self is adapter and self.interfaces == ('existing_liquid',))\n                    or (self is not adapter and self.interfaces == ('depleted_no_nucleation',)),", "require((self is adapter and self.interfaces == WET_MODES)\n                    or (self is not adapter and self.interfaces == MIXED_MODES),")
edit("require(len(self.column.storages) == 1 and self.column.storages[0] is shared.storage\n                    and self.column.storages[0].volume is shared.volume,\n                    'same_declared_live_storage_and_volume_required')", "require(len(self.column.storages) == CELL_COUNT\n                    and all(self.column.storages[i] is storages[i]\n                            and self.column.storages[i].volume is storages[i].volume\n                            for i in range(CELL_COUNT))\n                    and self.column.storages[SELECTED_CELL] is shared.storage\n                    and self.column.storages[SELECTED_CELL].volume is shared.volume,\n                    'same_declared_live_storage_and_volume_required')\n            require(packed.amounts_mol.shape == (CELL_COUNT, 4)\n                    and packed.internal_energy_j.shape == (CELL_COUNT,), 'complete_three_cell_input_required')")
edit("same_declared_storage_object=self.column.storages[0] is shared.storage,\n                same_declared_volume_object=self.column.storages[0].volume is shared.volume)", "same_declared_storage_object=self.column.storages[SELECTED_CELL] is shared.storage,\n                same_declared_volume_object=self.column.storages[SELECTED_CELL].volume is shared.volume,\n                same_original_cell_storage_objects=[self.column.storages[i] is storages[i] for i in range(CELL_COUNT)],\n                same_original_cell_volume_objects=[self.column.storages[i].volume is storages[i].volume for i in range(CELL_COUNT)])")
edit("phase = first.source_evaluation.cells[0].phase.phase_water_mol_s\n            result['initial_phase_water_mol_s'] = encode(phase)\n            save()\n            require(math.isfinite(phase) and phase > 0, 'initial_phase_not_positive')\n            horizon = F(3, 2)*F(state.liquid_water_mol)/F(phase)", "phases = tuple(cell.phase.phase_water_mol_s for cell in first.source_evaluation.cells)\n            phase = phases[SELECTED_CELL]\n            left = float(first.rates.face_species_mol_s[SELECTED_CELL, 0])\n            right = float(first.rates.face_species_mol_s[SELECTED_CELL+1, 0])\n            net_loss = F(phase)+F(right)-F(left)\n            result.update(initial_phase_water_mol_s=encode(phases),\n                initial_selected_left_liquid_mol_s=encode(left), initial_selected_right_liquid_mol_s=encode(right),\n                initial_selected_net_liquid_loss_mol_s=encode(net_loss))\n            save()\n            require(math.isfinite(phase) and phase > 0 and net_loss > 0, 'initial_phase_or_net_loss_not_positive')\n            require(left == 0. and right > 0\n                    and first.source_evaluation.faces[2].liquid_enthalpy_w != 0.,\n                    'actual_internal_liquid_and_donor_enthalpy_required')\n            horizon = F(3, 2)*F(states[SELECTED_CELL].liquid_water_mol)/net_loss")
edit("require(_same(source_mass, storage.water.reference.molar_mass_kg_mol), 'actual_shared_water_molar_mass')", "require(all(_same(source_mass, value.water.reference.molar_mass_kg_mol) for value in storages),\n                    'actual_shared_water_molar_mass')")
edit("require(refinement.clock is not None, 'independent_shifted_root_not_available')", "require(refinement.clock is not None, 'independent_shifted_root_not_available')\n            require(all(choice.order.earliest_labels == (('liquid', SELECTED_CELL, 0),)\n                        for choice in refinement.clock.choices), 'actual_middle_cell_first_root_required')")
edit("pressure_strategy=transition.pressure_strategy,\n            material_qualified=False", "pressure_strategy=transition.pressure_strategy,\n            selected_cell_index=SELECTED_CELL, cell_endpoint_gates=transition.cell_endpoint_gates,\n            cell_conditional_pressure_gates=transition.cell_conditional_pressure_gates,\n            cell_selected_pressure_gates=transition.cell_selected_pressure_gates,\n            material_qualified=False")
p.write_text(s)
