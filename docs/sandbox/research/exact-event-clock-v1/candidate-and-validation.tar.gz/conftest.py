"""Temp-only loader; not part of candidate production modules/tests."""
import importlib.util
from pathlib import Path
import sys
for short in ('exact_event_clock','exact_boundary_program'):
    name='sludge_sandbox.'+short
    spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name(short+'.py'))
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
