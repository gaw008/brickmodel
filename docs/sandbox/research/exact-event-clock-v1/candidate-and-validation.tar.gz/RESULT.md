# Canonical exact event clock and program view candidate

No repository changes, native calls, installation, or commits. This is preparation for an entire exact-clock solver/ledger contract, not admission of that solver path.

Frozen SHA256:
- exact_event_clock.py: 1b8a9961aa3123b188ebd56cf922a031a7466f3b966d6ebfb5e5072ce706ba36
- exact_boundary_program.py: 1904c9cb168555512df5855dbffad34161c49a63345edc89d7ba75ea83e33727
- test_exact_clock.py: 87fc7bfb054277053bd19c5eea69e7faa6cb5d99049641cbf22592bf14136eeb

Actual command: `PYTHONPATH=src /private/tmp/brick-water-backend-probe/venv/bin/python -m pytest /private/tmp/brick-exact-event-clock-v1/test_exact_clock.py -q`. Final 23 passed (tests02.log). First 22-case run also passed (tests01.log); no failed test run is being omitted.

`ExactEventTime.seconds` is the sole semantic value, an exact Fraction. Different origin/offset constructions normalize to identical equality/hash/order/serialization. Shifts and elapsed times use rational seconds, not display values. Explicit from_float adopts a binary64 rational exactly. Ordinary constructors reject floats, bools, NaN/infinity, and strings. The record decoder requires precisely schema/numerator/positive denominator, with reduced canonical rational representation. Exact intervals allow degenerate root bounds and reject inversion; their records independently validate each endpoint.

`display()` returns a labelled binary64 projection plus signed error, or explicit unavailable values on overflow. Display fields are absent from semantic serialization. No __float__ implicit conversion is supplied. The display record itself is descriptive and is not accepted by numerical time APIs.

`ExactProgramView` wraps an actual validated existing ScalarProgram or BoundaryProgram, retaining its input identity, values, species order, and source knots. It supports an explicitly declared Fraction translation of the entire schedule. Query times must be ExactEventTime. Node selection and interpolation weights use exact semantic values; only final physical column values round to binary64. Composition retains the existing no-normalization checks. Returned boundary states carry exact time rather than an ambiguous float time_s. Interior breakpoints retain exact semantics and exclude endpoints. Existing program classes/default at()/breakpoints_s() methods are untouched.

Independent tests include piecewise triangle expectations, exact weights immediately to both sides of a knot while both displays equal that knot, endpoint exclusion, full-schedule translation, analytic boundary columns/composition, legacy value parity at represented times, deep output-map immutability, strict malformed serialization, exact interval arithmetic, and display overflow/projection.

Copy only the two candidate modules and permanent test when approved. conftest.py is a TEMP-only loader, not a proposed repository change. Tests use normal sludge_sandbox imports. The program view reuses the existing private composition validator; repository integration may choose to expose that validator, but this candidate does not change it or duplicate its rules.

Remaining integration requirements are those in the earlier local-clock PLAN: exact stage/query times, all StepLedger durations, first-root/correction evidence, shared semantic common endpoints, cancellation/cost handling, strict new records/resume, and explicit time-dependent provider admission. Program translation is an input design choice and must join any eventual runtime/case identity; wrapping an existing source identity does not claim a translated schedule was physically measured. No precision or material validation claim is made beyond these pure primitives.
