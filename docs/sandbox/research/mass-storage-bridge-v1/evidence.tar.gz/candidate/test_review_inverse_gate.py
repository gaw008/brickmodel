from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_mass_storage_bridge import fixture
from mass_storage_bridge import MixedStorage
from sludge_sandbox.phase_storage import InversePolicy

def test_energy_acceptance_uses_unrounded_difference(monkeypatch):
    cell,state=fixture(monkeypatch)
    sample=cell.storage.evaluate(state,300.)
    # An exact affine energy path centered at the first bisection midpoint.
    # Test the inverse's numerical acceptance, not a physical provider claim.
    def affine(self,state,t):
        e=100*(t-395)+1
        return replace(sample,temperature_k=t,internal_energy_j=e,
                       energy_error_j=0.,minimum_heat_capacity_j_k=100.,closed_heat_capacity_j_k=100.)
    monkeypatch.setattr(MixedStorage,'evaluate',affine)
    state=replace(state,internal_energy_j=-2**-54)
    out=cell.storage.invert(state,InversePolicy(1.,1.,80))
    assert abs(F(out.point.internal_energy_j)-F(state.internal_energy_j))+F(out.point.energy_error_j)<=F(1.)
