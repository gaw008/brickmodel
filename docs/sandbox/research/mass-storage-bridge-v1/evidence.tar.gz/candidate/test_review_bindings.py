from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_mass_storage_bridge import fixture
from mass_storage_bridge import MixedStorage, MixedError

def test_named_oxygen_must_not_be_carbon_in_reference(monkeypatch):
    cell,state=fixture(monkeypatch)
    net=cell.storage.reference.network
    # Swap C/O compositions throughout: AB stays exactly conserved, but named O2 becomes carbon.
    components=tuple(replace(c,element_mass_fractions=(c.element_mass_fractions[1],c.element_mass_fractions[0],c.element_mass_fractions[2])) for c in net.components)
    altered=replace(net,components=components).solve()
    with pytest.raises(MixedError,match='element|composition'):
        replace(cell.storage,reference=altered)
