from dataclasses import replace
from fractions import Fraction as F
from test_mass_storage_bridge import fixture
from sludge_sandbox.reaction_reference import Anchor

def test_heat_identified_by_anchors_is_used_or_refused_at_construction(monkeypatch):
    cell,state=fixture(monkeypatch)
    old=cell.storage.reference;net=old.network
    b=Anchor('B',old.particular_h0_j_kg[1],net.reference_convention,net.reference_temperature_k,net.reference_pressure_pa,'solid',('manufactured:equivalent-anchor',))
    net=replace(net,anchors=net.anchors+(b,),reactions=(replace(net.reactions[0],enthalpy_j_per_kg_extent=None),))
    solution=net.solve(required_outputs=((-1,2,-1,0),))
    assert solution.identified_value((-1,2,-1,0))==F(-200000)
    storage=replace(cell.storage,reference=solution)
    cell=replace(cell,storage=storage)
    state=storage.state(state.solid_mass_kg,state.fluid_amounts_mol,state.internal_energy_j)
    # Either constructor should explicitly reject the unsupported heat form,
    # or evaluate must use the identified heat instead of float(None).
    out=cell.evaluate(state)
    assert out.chemical_reference_power_w!=0
