from dataclasses import replace
from fractions import Fraction as F
from test_mass_storage_bridge import fixture, R

def test_actual_dry_inverse_bound_against_fraction_energy(monkeypatch):
    cell,initial=fixture(monkeypatch)
    storage=cell.storage
    for xi in (0.,.00001,.0002):
        prototype=storage.state((.01-xi,2*xi),(.2-xi/.0319988,.2),0.)
        for target_t in (291.,307.125,410.):
            state=replace(prototype,internal_energy_j=storage.evaluate(prototype,target_t).internal_energy_j)
            inverse=storage.invert(state,cell.inverse_policy)
            cap=sum(F(m)*F(s.cp_j_kg_k) for m,s in zip(state.solid_mass_kg,storage.solids))
            offset=sum(F(m)*(h-F(s.cp_j_kg_k)*F(300)-F(100000)*F(s.volume_m3_kg)) for m,s,h in zip(state.solid_mass_kg,storage.solids,storage.reference.particular_h0_j_kg))
            cap+=F(state.fluid_amounts_mol[0])*(F(30)-F(R))+F(state.fluid_amounts_mol[1])*(F(29)-F(R))
            exact_t=(F(state.internal_energy_j)-offset)/cap
            assert abs(F(inverse.point.temperature_k)-exact_t)<=F(inverse.temperature_error_bound_k)
            exact_v=F(storage.bulk_volume_m3)-sum(F(m)*F(s.volume_m3_kg) for m,s in zip(state.solid_mass_kg,storage.solids))
            exact_p=sum(map(F,state.fluid_amounts_mol))*F(R)*F(inverse.point.temperature_k)/exact_v
            assert abs(F(inverse.point.pressure_pa)-exact_p)<=F(inverse.point.pressure_error_pa)
