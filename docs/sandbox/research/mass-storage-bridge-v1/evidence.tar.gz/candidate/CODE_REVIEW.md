# Independent mixed-storage bridge review

Reviewed original d09d7381 source/test/HANDOFF/molar-mass provenance, then ea3963d4 element/energy-gate fixes. No repository or installed-source changes, no EOS. Only reviewer-owned pure tests and this report were written. Final source approval awaits the identified-heat diagnostic fix described below.

## Physical and implementation scope

Separate immutable kg-solid and mol-fluid tuples avoid the old amounts_mol unit conflict. Actual RigidStorage dry gas machinery is evaluated; native water methods are forbidden by the test fixture. The original full reference solution is recomputed and actual gas h(Tref,pref)/M values are bound. Constant-volume solid U=h0+Cp(T−Tref)−pref*v and H=U+p*v are consistent; current pore volume uses current solid masses. Reaction changes both solid kg and O2 mol with the same declared provider M. Total U receives no duplicate chemical heat: reference power is diagnostic only. Finite oxygen limits the rate, and zero oxygen gives zero reaction.

The midpoint segment calls the combined U inverse at actual start, predictor midpoint and endpoint states; accepted state/ledger publication follows successful endpoint evaluation. A failed candidate does not publish partial arrays. The analytic extent oracle is independently derived from the finite-O2 mass-action ODE, and its U/Cp/Cv temperature and gas pressure are calculated outside the storage inverse. The 8/16 grids test temporal behavior of this manufactured fixed rigid dry cell; they are not a general adaptive/event solver, spatial convergence test, real sludge validation or wet/mechanical bridge.

Gas molecular-weight facts are declared nominal NIST cache readouts with explicit source/cache locators and unknown physical uncertainty; constant caloric coefficients, solids, kinetics and reaction heat remain manufactured. Element/phase/reference data must still be bound, not inferred from a self-consistent user matrix. No transport enthalpy/gauge test or live liquid admission is claimed in this candidate.

## Findings and retained evidence

[HIGH — fixed in ea3963d4] Named gas element identity was not bound.
Original constructor accepted a reference network with every C/O composition exchanged, preserving AB=0 while declaring actual O2 pure carbon. `test_review_bindings.py` produced actual DID NOT RAISE in `review-element-red.log`. Final explicit O2→O/N2→N mapping uses element labels, accepts a valid column permutation and rejects unadmitted gas definitions.

[HIGH — fixed in ea3963d4] Rounded residual could pass the original energy gate.
The inverse accepted U=1, target=−2^-54, error=0 under a 1-J tolerance because float subtraction rounded the residual down to 1. `test_review_inverse_gate.py` is an instrumented exact affine energy-path predicate check, not an actual material trajectory claim; original failure remains in `review-inverse-red.log`. Fixed endpoint, residual/error acceptance and sign comparisons use Fraction; unresolved signs now refuse instead of arbitrarily shrinking the bracket. No tolerance was loosened.

[HIGH — pending] Identifiable unknown reaction heat crashes diagnostic evaluation.
The reference network supports raw q=None when anchors identify its reaction functional. Adding the original solved B anchor and setting q=None produces the exact same identified q=−200000 and passes MixedStorage/MixedCell construction, but evaluate calls float(None). This TypeError also escapes integrate_closed's failure handling. `test_review_identified_heat.py` and `review-identified-heat-red.log` preserve the actual failure. Use reference.identified_value(B) for the diagnostic heat (or explicitly refuse the unsupported form before accepting a cell); do not alter the closed total-U equation.

## Independent verification so far

After the first two fixes: actual combined author suite + two original reviewer attacks + new actual-bound check **10 passed in 3.06 s**, retained in `review-final-tests.log`. The additional `test_review_actual_bounds.py` independently computes exact constant-Cp/Cv reference-energy roots and ideal-gas pressure from Fraction primitive values for 3 reaction extents × 3 target temperatures. All nine returned T/P values lie inside the returned bounds (separate run 1 passed in 0.49 s). This verifies those actual sampled dry states, not every possible declared envelope or measurement uncertainty.

Both original negative controls for missing oxygen consumption and duplicate reaction heat materially fail independent element/energy/oracle checks. They are deliberate monkeypatched wrong-physics experiments, not supported cell configuration choices.

## Final corrected source and portable application

Final source SHA256 `cc98bc97bde59f425e55633bd877d6d212ef1ecf9f8a5afdbb3dda0744911aa7` independently matched. The third HIGH is fixed by obtaining diagnostic q through `reference.identified_value(reaction.mass_change_kg_per_kg_extent)`, rather than reading the optional raw heat field. A fully anchored equivalent network now evaluates without float(None); genuinely unidentified outputs retain the reference helper's refusal. No heat is added to external power and no numerical policy is changed.

Independent final source run: **11 passed in 3.10 s**, `review-complete-tests.log` (7 author cases, all three reviewer regressions, and the 9-state independent Fraction T/P-bound test). Original RED evidence and source snapshots remain intact. All three HIGH findings above are closed at the final hash.

Read the portable formal-import test adaptation, tracked small molar-mass fact file and optional offline `verify_sources.py`. Numerical tests retain all original trajectory tolerances, actual typed dry-fluid machinery, water-call sentinels and attack assertions. They now use repository-relative tracked water/fact paths; runtime cache availability is no longer silently required for clean-checkout numerical tests. The separate evidence checker explicitly verifies cached file hashes, exact locators and Decimal readout-to-kg/mol conversion, failing on missing/mismatched data. This separation does not turn nominal source readouts into quantified physical uncertainty. No full cached source page is redistributed. Temporary conftest/overlays and water symlinks must not be applied to the repository.

## Review Summary

| Severity | Open Count | Status |
|----------|------------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass (3 fixed with retained RED) |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE — bounded manufactured closed dry mixed-basis storage/rate segment. No wet EOS, transport, deformation, adaptive-event/continuation or real-material qualification is granted.

Portable test SHA256 `5a612eec79f47ce99d51ec32cb671363e08982e5ca932ac66b275bfb93987718` independently checked; actual isolated formal-import portable run **10 passed in 2.92 s**, retained in `review-portable-tests.log`. No installed-source changes or EOS were performed.
