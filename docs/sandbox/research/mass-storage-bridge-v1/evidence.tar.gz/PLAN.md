# Mass-solid / mol-fluid total-energy bridge — implementable first slice

Decision: add a separate, explicitly mixed-basis rigid-cell state and storage host. Keep all existing molar providers, ConservedState, InventoryLayout, event codecs and continuation paths unchanged. First deliver one actually evaluated reacting rigid cell with kg solid inventories, genuine mol fluid inventories and total U; do not begin by generalizing the entire exact event integrator. The first time-dependent test must call the new storage inverse and rate assembly at every stage, not feed it a precomputed temperature or prescribed motion.

This is an implementation blueprint only. No source changes/EOS or new material parameters were introduced. The current reference helper is nominal algebra, with measured-data uncertainty and material admission still outside its scope.

## Existing seams inspected

- phase_storage.py: PhaseMetadata/PhasePoint require molar mass and J/mol, m3/mol; PhaseStorage checks a single reference/basis. This is useful for the actual fluid subspace, not a place to disguise kg as mol.
- solid_fluid_storage.py: SolidFluidStorage fixes typed IncompressibleSolidPhase, mol solid inventories and NIST common reference. Its useful algorithm is current solid volume subtraction → RigidStorage fluid pressure/energy → combined heat-capacity/error budget → bracketed total-U inverse. Reuse that algorithm with a new class; do not bypass its existing guards.
- solid_fluid_heat.py: InventoryLayout combines liquid/gas/solid into one species_order, all carried through amounts_mol. Rates and ConservedState in integration.py then assume that array and its mol tolerances everywhere.
- solid_reactions.py: SolidReactionConfig binds actual mol providers and current-bulk mol concentration laws. Its binding discipline is useful; its species/molar kinetic adapter is incompatible with an unqualified kg pseudo-component.
- RigidStorage already supplies real mol-water/gas closure and numerical envelopes. It can remain unchanged beneath an explicit reference adapter. Free-slab geometry, strain energy, depletion events and existing exact-record codecs are later typed integration work, not automatically supported by this first rigid host.
- ReactionReferenceNetwork supplies B^T h0=q, exact mass/element checks and unknown-output refusal. A solution must carry the full originating network, including phase/Tref/pref, extent basis, source declarations and uncertainty, not just the union of source IDs.

## Concrete interfaces and ownership boundaries

New modules, each narrowly typed:

1. `mass_inventory.py`

   `MixedInventoryLayout(solid_component_ids, fluid_layout, source_binding)`; fluid_layout has liquid-water and gas species in mol only. Complete, disjoint identities and actual fluid provider molar masses are bound explicitly.

   `MixedConservedState(solid_mass_kg[cell, solid], fluid_amounts_mol[cell, fluid], internal_energy_j[cell], energy_model_identity)`; immutable bytes-backed finite arrays, nonnegative amounts, no mechanical stretch in the first rigid variant. A fluid-only ConservedState may be made as a temporary adapter value if an existing pure utility requires it, but it must never be the mixed state or carry solid kg. Return full state on failure, not just fluid projection.

   `MixedRates(face_fluid_mol_s, reaction_fluid_mol_s, reaction_solid_kg_s, face_energy_w, external_cell_power_w)`; no mobile solids initially. Derivatives separately produce dm/dt, dn/dt, dU/dt. Independent kg and mol absolute tolerances/scales are mandatory. The first ledger stores both inventory integrals and shared energy fluxes; no implicit unit array or universal numeric tolerance.

2. `mass_solid_phase.py`

   `MassPhaseMetadata(component_id, phase='solid', inventory_basis='kg_of_declared_component', reference_binding, composition_binding, source_content_binding, classification, temperature_domain, pressure_domain)`.

   `MassPhasePoint(T,p,u_j_kg,h_j_kg,v_m3_kg,du_dT_path_j_kg_k,energy_error_j_kg,volume_error_m3_kg,source_binding)` with a checked h−u−pv relation. Initial provider is a positively bounded incompressible manufactured solid with constant specific volume and an integrated sensible Cp relation. For constant v:

       h(T,p) = h0(Tref,pref) + integral_Tref^T Cp(theta)dtheta + v*(p-pref)
       u(T,p) = h(T,p) - p*v
              = h0 + integral Cp dT - pref*v.

   Do not omit the v*(p-pref) term: defining h=h0+sensible then u=h−pv would create spurious pressure-dependent internal energy for this incompressible model. Every term and its uncertainty must use the same reference. Reference T must lie in the caloric evidence domain or have a separately evidenced bridge; Arlabosse cannot be extrapolated from 35°C down to a customary 25°C zero.

   General thermal expansion/compressibility is explicitly unsupported by this first provider: Cp, volume and h/u derivatives must satisfy thermodynamic consistency before such an extension. Solid h/u must not already include any separately added strain/interface storage.

3. `mass_reference_bridge.py`

   `BoundMassReference(network_solution, coordinate_choice, fluid_reference_anchors, source_content_manifest)` binds complete network input and the actual chosen reference coordinate. It requires all needed reaction energy directions to be identifiable. A chosen nullspace coordinate is a declared convention, not a measured component enthalpy; unmeasured allowed reaction directions still refuse.

   Known fluid anchors are evaluated at the SAME Tref, pref and phase: h0_mass = actual h_molar / actual M. Prefer retaining existing NIST fluid reference and solving compatible solid offsets from reaction heats plus those anchors. Do not set arbitrary zero solid offsets while leaving fluid reference untouched. Source binding must include provider type/implementation and full content, not the textual reference name alone.

   `FluidReferenceAdapter(base_rigid_storage, delta_h_j_mol_by_phase, error_binding)` is only needed when deliberately choosing a different common gauge. Constant offsets must add equally to fluid u and h, to total stored energy, and to donor enthalpies. Pressure, volume and heat-capacity derivatives are unchanged by a fixed offset. Different arbitrary offsets for water liquid/vapor would alter latent/chemical energy: use a common conserved-element shift, or an independently validated phase-reference bridge. Preserve actual chemical-potential/reference consistency before phase-transfer admission.

4. `mass_solid_fluid_storage.py`

   `MassSolidFluidStorage(fluid_template, mass_solid_phases, bound_reference, bulk_geometry, numerical_envelope)` exposes:

       evaluate_at_temperature(T, fluid_mol, solid_kg) -> MixedStoragePoint
       temperature_from_energy(U, fluid_mol, solid_kg, bracket, inverse_policy,
                               target_energy_error_bound_j=...) -> MixedStorageInverse

   At each call recompute Vs=sum(m_s*v_s) and Vpore=Vbulk−Vs from current masses; retain rounding and physical volume errors and reject an enclosure including nonpositive pore space. Evaluate the actual fluid template with Vpore, combine sum(m_s*u_s) with the actual fluid U and consistent offsets, and combine H similarly. At a shared phase pressure, H−U=p*Vbulk; otherwise report sum(p_phase*V_phase), never substitute one pressure silently. Fixed-volume first scope contains no strain/interface energy or external mechanical work.

   Invert THIS combined U, not fluid U alone. For incompressible solids the fixed-inventory closed heat-capacity lower bound is fluid bound + sum(m_s*solid Cp lower); pressure/volume uncertainty and target/subtraction/rounding errors all enter the acceptance radius. A positive local derivative is not a global monotonicity certificate. Unknown provider uncertainty remains unknown; it cannot be coerced into zero to make an inverse pass.

5. `mass_reaction_host.py`

   `BoundMassReaction(network, mixed_layout, bound_reference, extent_rate_law, source_binding)` maps each reaction's kg changes separately to solid kg and fluid mol. For known fluid g: dn_g/dt=sum_j B_gj*xi_dot_j / M_g. M_g comes from the exact same actual gas/water provider identity. Check full mass/element residuals using that conversion, including binary representation errors; no invented pseudo molar mass.

   `RigidMixedCell.evaluate(state,time)` performs current inventory→combined U inverse→actual T/P→extent rates→mixed source arrays. The rate law returns kg of the declared extent per second, with explicitly compatible inventory/concentration units. It may not reuse molar Arrhenius parameters by renaming their units. Reaction only changes inventories in the total-U formulation; external_cell_power has NO additional q*xi_dot for the same reaction. Stoichiometric diagnostics report the chemical-reference energy change separately, not as external heating.

## First mandatory LIVE coupled manufactured test

Use a one-cell rigid vessel, finite gas O2 supply and optional inert gas, with two manufactured solid pseudo-components A and B. Declare A as one kg carbon element and B as half carbon/half oxygen by mass solely for this algebra/host fixture. The artificial balanced reaction per kg extent is:

    delta m_A = -1; delta m_O2 = -1; delta m_B = +2.

These are made-up phase identities and reaction data, not a claimed reaction mechanism or real carbon oxide. O2 remains a real named gas with its provider-bound molar mass: delta n_O2=-1/M_O2 per kg extent. No molecular mass is assigned to A or B. O2 is initially finite in the actual state, not supplied implicitly by an infinite atmosphere. Liquid water is explicitly zero for the first pure dry test; this avoids EOS while exercising the real mixed-basis storage/rate seam.

Bind one explicit manufactured reaction heat q_ref and a coordinate anchor for A to the actual O2 reference at Tref/pref; solve the B offset. Choose constant positive manufactured solid Cp and v; gas caloric/ideal closure must be executed through typed provider objects (known real molar mass, clearly manufactured caloric coefficients if using a constant-Cv analytic oracle). Classification and source labels remain manufactured, and the host must require opt-in. Never label artificial caloric coefficients as measured O2 data.

For the FIRST oracle choose v_A=2*v_B, so reaction leaves total solid volume constant without prescribing motion. Gas mole loss still changes gas pressure and gas thermal capacity. A bounded rate such as xi_dot=k*m_A*(n_O2/n_ref), with explicit units and manufactured k, couples actual inventory and finite oxygen. Begin with enough O2 and stop at a registered positive interior time; no new depletion event semantics in this slice.

Implement a small typed mixed-state RK segment (or pure test driver calling MixedRates at every stage) with whole-state positivity and accepted ledgers. It must invoke the combined storage inverse afresh at every RHS evaluation. Independently integrate the extent law and derive T from constant-Cp/Cv total-U algebra:

    m_A=m_A0-xi; m_B=m_B0+2xi; n_O2=n_O20-xi/M_O2
    U(T,xi)=U_ref(xi)+C_closed(xi)*(T-Tref)
    T=Tref+[U_initial-U_ref(xi)]/C_closed(xi).

Compute the oracle from declared primitive constants, not by calling the new storage inverse or reusing its summed U. Then derive ideal-gas P from actual n_total, T and Vpore. This tests reaction heat via changing stored reference energy, gas consumption, changing thermal capacity, actual thermal inversion and pressure together. Nonzero q must produce the expected nontrivial T response while total U stays constant; no precomputed stage T/pressure injection is allowed.

Required outputs/gates: every accepted prefix solid kg, fluid mol, elemental totals, total U residual, component-source sums, actual T/P versus independent oracle, positive inventories/pore volume, inverse error bounds and provider/reference identities. Use explicit independent kg/mol/J/T/P tolerances fixed before execution; report physical bounds separately from arithmetic residuals. Negative controls: omitting O2 source, adding reaction heat to external power, missing one reference offset, using the wrong gas M, and inverse outside domain all fail the appropriate gate or materially fail the independent oracle. Return the last complete accepted mixed state on failure.

Second small extension of the SAME live test: a real shared gas face between two such cells (or an explicitly prescribed finite reservoir state) transfers O2 with actual donor h_molar. A face flux is assembled once and used with opposite signs in both cells. For a conserved-element reference shift g, translate initial U by the appropriate inventory-weighted offsets and translate every carried enthalpy by M_g*g_g. Require unchanged T/P/reaction rates and a matching shift of stored/boundary energy at every prefix. A negative control leaving donor enthalpy unshifted must fail. The first closed test alone cannot establish this transport property.

## Uncertainty and actual-material boundary

Current reaction_reference is exact NOMINAL algebra, not an uncertainty solver. First manufactured coefficients can have zero physical uncertainty because their definitions are exact, with numerical rounding still budgeted. Actual measured q/anchors need bounded, correlated reference uncertainty or an interval/constraint-set solver; do not silently project inconsistent measured cycles onto a convenient exact system. Shared reference correlations can cancel only with an explicit model; otherwise use conservative independent bounds. Every phase Cp/v and fluid error remains included in the combined inverse. An arbitrary coordinate offset should not improve physical accuracy or erase an error enclosure.

Real material substitution requires the same sludge/ash/char identities and complete oxygen/product stoichiometry, independently constrained reaction heats, caloric data over the actual temperature domain, volume/porosity laws, kinetics with the correct mass-extent units, and transport/phase assumptions. It does NOT require inventing an absolute formation enthalpy or a molecular mass for sludge. Arlabosse can supply only its evidenced low-temperature dry-basis sensible relation with unresolved fit uncertainty; it does not supply the artificial A/B reaction, their volumes, high-temperature Cp or kinetics.

## Build order and admission boundary

Implement mixed state/layout and typed mass point → source-bound reference bridge → rigid current-mass combined storage/inverse → reaction mapping/evaluate host → the LIVE one-cell oracle test above → shared-face gauge test. Those are the first reviewable deliverables, not another isolated RREF test. Reuse narrow pure utilities and existing fluid machinery with strict adapters; do not fork the entire event driver.

Only after this coupled slice passes should the generic time integrator acquire explicit kg arrays, mixed ledger/policy schema, immutable record/audit support and resource/cancel semantics. Free deformation then needs current mass volume/stress/energy derivatives and global work closure; real liquid phase transfer needs the full water reference/chemical-potential bridge. Old codecs and exact continuation must reject the new state until those typed contracts exist. No automatic case/service schema admission follows from a successful manufactured cell.
