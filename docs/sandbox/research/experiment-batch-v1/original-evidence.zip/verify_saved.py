from pathlib import Path
import json
import subprocess
import hashlib
from sludge_sandbox.run_service import read_run
from sludge_sandbox.experiments import read_experiment, compare_experiment
from sludge_sandbox.job_supervisor import read_job
out = Path('/private/tmp/brick-experiments-v1')
directory = out/'final-native-final'
state = read_experiment(directory)
assert state['status'] == 'completed' and len(state['attempts']) == 2
paths = sorted((directory/'jobs').glob('*/run/result.json'))
assert len(paths) == 2
for index, path in enumerate(paths):
    result, manifest = read_run(path.parent)
    job = read_job(path.parent.parent)
    assert job['child_reaped'] and job['returncode'] == 0 and job['status'] == 'completed'
    audit_input = out/f'ledger-input-{index}.json'
    audit_input.write_text(json.dumps({'run': result['integration'], 'initial': result['integration']['states'][0]}))
    audit = subprocess.run(['/private/tmp/brick-water-backend-probe/venv/bin/python', str(out/'audit_ledgers.py'), str(audit_input), str(out/f'ledger-audit-{index}.json')], capture_output=True, text=True)
    (out/f'ledger-audit-{index}.stdout').write_text(audit.stdout)
    (out/f'ledger-audit-{index}.stderr').write_text(audit.stderr)
    assert audit.returncode == 0, audit.stdout+audit.stderr
for command in ['experiment-status', 'experiment-compare']:
    response = subprocess.run(['/private/tmp/brick-water-backend-probe/venv/bin/sludge-sandbox', command, str(directory)], capture_output=True, text=True)
    (out/(command+'.stdout')).write_text(response.stdout)
    (out/(command+'.stderr')).write_text(response.stderr)
    assert response.returncode == 0
    expected = state if command == 'experiment-status' else compare_experiment(directory)
    assert json.loads(response.stdout) == expected
summary = {'verified_trajectories': len(paths), 'jobs_completed_and_reaped': 2,
           'charged_wall_seconds': state['charged_wall_seconds'], 'cli_python_equal': True,
           'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(out/'saved-verification.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary))
