import json
from pathlib import Path
from sludge_sandbox.experiments import prepare_experiment, run_experiment, compare_experiment
from sludge_sandbox.job_supervisor import read_job
from sludge_sandbox.run_service import read_run
root = Path('/Users/wanggaoying/Desktop/brickmodel-github')
out = Path('/private/tmp/brick-experiments-v1')
directory = out/'final-native-final'
prepared = prepare_experiment(root/'data/sandbox/experiments/wet-transport-comparison-v1.json', directory,
    water_directory=root/'data/sandbox/water', evidence_directory=root/'data/sandbox')
(out/'final-native-preparation.json').write_text(json.dumps(prepared, indent=2))
result = run_experiment(directory)
(out/'final-native-return.json').write_text(json.dumps(result, indent=2))
comparison = compare_experiment(directory)
(out/'final-native-comparison.json').write_text(json.dumps(comparison, indent=2))
assert result['status'] == 'completed', result['reason']
assert len(result['attempts']) == 2
assert 0 < result['charged_wall_seconds'] <= 100
assert all(c['status'] == 'completed' for c in result['candidates'])
for attempt, item in zip(result['attempts'], comparison['outcomes']):
    job_dir = directory/attempt['job_artifact']
    job = read_job(job_dir)
    assert job['status'] == 'completed' and job['child_reaped'] and job['returncode'] == 0
    run, manifest = read_run(job_dir/'run')
    assert item['result_sha256'] == manifest['files']['result.json']
    assert item['metrics'] and run['status'] == 'completed'
print(json.dumps({'status': result['status'], 'attempts': len(result['attempts']),
                  'charged_wall_seconds': result['charged_wall_seconds'], 'outcomes': comparison['outcomes']}, indent=2))
