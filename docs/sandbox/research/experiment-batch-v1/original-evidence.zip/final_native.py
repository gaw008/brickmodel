from pathlib import Path
import subprocess
import json
out = Path('/private/tmp/brick-experiments-v1')
script = (out/'run_native.py').read_text().replace("out/'native'", "out/'native-final'").replace("out/'native-", "out/'final-native-")
(out/'run_native_final.py').write_text(script)
r = subprocess.run(['/private/tmp/brick-water-backend-probe/venv/bin/python', str(out/'run_native_final.py')], timeout=150, capture_output=True, text=True)
(out/'final-native.stdout').write_text(r.stdout)
(out/'final-native.stderr').write_text(r.stderr)
print(r.stdout, r.stderr)
assert r.returncode == 0
for n, p in enumerate(sorted((out/'native-final/jobs').glob('*/run/result.json'))):
    result = json.loads(p.read_text())
    audit_input = out/f'ledger-input-{n}.json'
    audit_input.write_text(json.dumps({'run': result['integration'], 'initial': result['integration']['states'][0]}))
    audited = subprocess.run(['/private/tmp/brick-water-backend-probe/venv/bin/python', str(out/'audit_ledgers.py'), str(audit_input), str(out/f'ledger-audit-{n}.json')], capture_output=True, text=True)
    (out/f'ledger-audit-{n}.stdout').write_text(audited.stdout)
    (out/f'ledger-audit-{n}.stderr').write_text(audited.stderr)
    assert audited.returncode == 0, audited.stdout+audited.stderr
print('Both saved trajectories passed independent original ledger audit')
