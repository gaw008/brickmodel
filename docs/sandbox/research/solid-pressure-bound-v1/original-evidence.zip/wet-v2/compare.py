"""No-EOS comparison of two previously completed preregistered wet paths."""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import traceback

HERE = Path(__file__).resolve().parent


def main() -> int:
    result = {'status': 'started', 'inputs': [],
              'qualification': 'two-step-cap convergence indicator, no independent wet temperature oracle'}
    try:
        paths = []
        for i in (0, 1):
            path = HERE/f'depletion-result-{i}.json'
            record = {'path': str(path)}
            result['inputs'].append(record)
            raw = path.read_bytes()
            record['sha256'] = hashlib.sha256(raw).hexdigest()
            record['bytes'] = len(raw)
            paths.append(json.loads(raw))
        assert all(path['status'] == 'passed' for path in paths), 'both_depletion_runs_must_pass'
        assert paths[0]['initial'] == paths[1]['initial'], 'initial_states_differ'
        states = [path['run']['states'][-1] for path in paths]
        differences = {
            'amount_mol': max(abs(a-b) for a, b in zip(states[0]['amounts_mol'][0], states[1]['amounts_mol'][0], strict=True)),
            'energy_j': abs(states[0]['internal_energy_j'][0]-states[1]['internal_energy_j'][0]),
            'temperature_k': abs(paths[0]['final_temperature_k']-paths[1]['final_temperature_k']),
            'pressure_pa': abs(paths[0]['final_pressure_pa']-paths[1]['final_pressure_pa']),
            'event_time_s': abs(paths[0]['run']['events'][0]['time_s']-paths[1]['run']['events'][0]['time_s'])}
        if not all(math.isfinite(value) for value in differences.values()):
            raise ValueError('nonfinite_endpoint_difference')
        limits = {'amount_mol': 1e-10, 'energy_j': 1e-6, 'temperature_k': 1e-5, 'pressure_pa': 1., 'event_time_s': 1e-7}
        result.update(differences=differences, limits=limits)
        result['status'] = 'passed' if all(differences[key] <= limits[key] for key in limits) else 'failed'
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        (HERE/'comparison-result.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
