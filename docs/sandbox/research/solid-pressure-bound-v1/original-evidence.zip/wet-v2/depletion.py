"""Joined reacting/wet trajectory; full ledgers retained even on failed assertions."""
from __future__ import annotations
from dataclasses import fields
from fractions import Fraction as F
import argparse
import json
import math
import time
import traceback
from typing import Any
import numpy as np
from fixture import build, installed_identity, integration_policies, save_result, encode, HERE, START, END, COMPONENTS
from sludge_sandbox.depletion_integration import integrate_depletion, DepletionResult
from sludge_sandbox.integration import ConservedState


def audit_prefixes(run: DepletionResult, initial: ConservedState) -> list[dict[str, Any]]:
    assert len(run.times_s) == len(run.states) == len(run.steps)+1
    energy = F()
    water0 = F(float(initial.amounts_mol[0, 2]))+F(float(initial.amounts_mol[0, 3]))
    prefix = []
    for t, state, step in zip(run.times_s[1:], run.states[1:], run.steps, strict=True):
        row = state.amounts_mol[0]
        assert state.energy_model_identity == initial.energy_model_identity
        assert row[4] == initial.amounts_mol[0, 4]
        solid_residual = F(float(row[0]))+F(float(row[1]))-2
        analytic_residual = row[0]-2*math.exp(-.1*(t-START))
        assert abs(solid_residual) <= F(1e-10)
        assert abs(analytic_residual) <= 1e-9
        assert set(step.cell_work_components_j) == COMPONENTS
        assert step.cell_work_components_j['body'][0] == 0
        represented = sum((F(float(v[0])) for v in step.cell_work_components_j.values()), F())
        assert represented+step.component_sum_residual_j[0] == F(float(step.cell_work_j[0]))
        energy += F(float(step.cell_work_j[0]))+F(float(step.face_energy_j[0]))-F(float(step.face_energy_j[1]))
        energy_residual = F(float(state.internal_energy_j[0]))-F(float(initial.internal_energy_j[0]))-energy
        water_residual = F(float(row[2]))+F(float(row[3]))-water0
        assert abs(energy_residual) <= F(1e-7) and abs(water_residual) <= F(1e-12)
        assert np.all(step.face_species_mol == 0) and np.all(step.face_energy_j == 0)
        if t >= run.events[0].time_s:
            assert row[3] == 0
        prefix.append({'time_s': t, 'energy_residual_j': energy_residual,
            'water_residual_mol': water_residual, 'water_H_residual_mol': 2*water_residual,
            'water_O_residual_mol': water_residual, 'solid_C_residual_mol': solid_residual,
            'solid_mass_residual_kg': F(.012)*solid_residual, 'A_analytic_residual_mol': analytic_residual,
            'occupied_solid_volume_exact_m3': F(float(row[0]))*F(2e-5)+F(float(row[1]))*F(1e-5)})
    return prefix


def audit_corrections(run: DepletionResult) -> dict[str, Any]:
    signed, absolute, phase = F(), F(), F()
    for correction in run.corrections:
        assert correction.ideal_liquid_increment_mol == -F(correction.liquid_before_mol)
        assert correction.ideal_vapor_increment_mol == F(correction.liquid_before_mol)
        actual = F(correction.vapor_after_mol)-F(correction.vapor_before_mol)
        assert actual == correction.actual_vapor_increment_mol
        assert actual-correction.ideal_vapor_increment_mol == correction.vapor_storage_roundoff_mol
        signed += correction.vapor_storage_roundoff_mol
        absolute += abs(correction.vapor_storage_roundoff_mol)
        phase += correction.ideal_vapor_increment_mol
    totals = run.roundoff_totals
    assert signed == totals.signed_storage_roundoff_mol
    assert absolute == totals.absolute_storage_roundoff_mol
    assert phase == totals.numerical_phase_correction_mol
    assert len(run.corrections) == totals.events
    return {'signed': signed, 'absolute': absolute, 'numerical_phase': phase, 'events': totals.events}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--refinement', type=int, choices=(0, 1), default=0)
    args = parser.parse_args()
    started = time.monotonic()
    result: dict[str, Any] = {'status': 'started', 'refinement': args.refinement}
    name = f'depletion-result-{args.refinement}.json'
    try:
        result['installed_before'] = installed_identity()
        operator, initial = build()
        callback = json.loads((HERE/'callback-result.json').read_text())
        assert callback['status'] == 'passed'
        assert encode(initial) == callback['initial']
        policy, event_policy = integration_policies(operator, args.refinement)
        result.update(initial=initial, integration_policy=policy, event_policy=event_policy)
        run = integrate_depletion(initial, operator, start_s=START, end_s=END,
                                  integration_policy=policy, event_policy=event_policy)
        result['run'] = {field.name: getattr(run, field.name) for field in fields(run) if field.name != 'operator'}
        result['final_interfaces'] = run.operator.interfaces
        result['final_coefficients_mol_s_pa'] = run.operator.coefficients_mol_s_pa
        save_result(name, result)
        assert run.status == 'completed', (run.status, run.reason)
        assert run.times_s[-1] == END and len(run.events) == 1
        assert START < run.events[0].time_s < END
        assert run.operator.interfaces == ('depleted_no_nucleation',)
        assert run.operator.coefficients_mol_s_pa == (1e-6,)
        event = run.events[0]
        for observed, limit in ((event.event_time_difference_s, 1e-7), (event.common_amount_difference_mol, 1e-10),
            (event.common_energy_difference_j, 1e-6), (event.common_temperature_difference_k, 1e-5),
            (event.common_pressure_difference_pa, 1.)):
            assert 0 <= observed <= limit
        result['prefix_audit'] = audit_prefixes(run, initial)
        result['correction_audit'] = audit_corrections(run)
        final = run.operator.evaluate(run.states[-1], END)
        thermal = final.base_evaluation.storage_states[0]
        assert final.cell_transfers[0].rate_mol_s == 0
        assert final.rates.reaction_species_mol_s[0, 0] < 0
        assert final.rates.reaction_species_mol_s[0, 1] > 0
        assert run.states[-1].amounts_mol[0, 0] < next(state.amounts_mol[0, 0]
               for t, state in zip(run.times_s, run.states, strict=True) if t >= event.time_s)
        actual_solid = F(float(run.states[-1].amounts_mol[0, 0]))*F(2e-5)+F(float(run.states[-1].amounts_mol[0, 1]))*F(1e-5)
        assert abs(F(thermal.solid_volume_m3)-actual_solid) <= F(1e-18)
        current_bulk = final.base_evaluation.current_host.storages[0].bulk_volume_m3
        assert abs(F(thermal.available_pore_volume_m3)-(F(current_bulk)-actual_solid)) <= F(1e-18)
        result.update(final_temperature_k=thermal.mechanical.temperature_k, final_pressure_pa=thermal.mechanical.pressure_pa,
            final_storage=thermal, final_skeleton=final.base_evaluation.total_inverses[0].state.skeleton_state,
            final_rates=final.rates, installed_after=installed_identity(), status='passed',
            qualification='manufactured reacting wet coupling; one path is not an accuracy certificate or sludge material validation')
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        result['elapsed_s'] = time.monotonic()-started
        save_result(name, result)
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
