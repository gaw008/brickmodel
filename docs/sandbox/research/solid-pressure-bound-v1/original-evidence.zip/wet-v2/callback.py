"""Single installed reacting/wet callback; not trajectory validation."""
from __future__ import annotations
from fractions import Fraction as F
import json
import time
import traceback
from typing import Any
import numpy as np
from fixture import build, installed_identity, save_result, START, COMPONENTS


def main() -> int:
    started = time.monotonic()
    result: dict[str, Any] = {'status': 'started', 'attempt_id': 'reacting-wet-callback-v1'}
    try:
        result['installed_before'] = installed_identity()
        operator, state = build()
        host = operator.base_model
        out = operator.evaluate(state, START)
        base = out.base_evaluation
        current = base.current_host
        thermal = base.storage_states[0]
        inverse = base.total_inverses[0]
        row = out.rates.reaction_species_mol_s[0]
        result.update(initial=state, layout=host.base_model.inventory_layout.species_order,
            implementation=json.loads(operator.chemical.water.implementation.canonical_json),
            water_source_asset_sha256=operator.chemical.source_asset_sha256,
            energy_identity=host.energy_model_identity,
            rates=out.rates, transfer=out.cell_transfers[0], skeleton=inverse.state.skeleton_state,
            temperature_k=thermal.mechanical.temperature_k, pressure_pa=thermal.mechanical.pressure_pa,
            total_energy_residual_j=inverse.total_energy_residual_j,
            inverse_temperature_error_k=inverse.temperature_error_bound_k,
            bulk_volume_m3=current.storages[0].bulk_volume_m3,
            solid_volume_m3=thermal.solid_volume_m3, pore_volume_m3=thermal.available_pore_volume_m3,
            current_reaction_binding_same_object=current.solid_reactions.storages[0] is current.storages[0])
        assert result['current_reaction_binding_same_object']
        assert current.storages[0] is inverse.state.current_storage
        assert base.storage_inverses[0] is inverse.thermal_inverse
        assert row[0] < 0 and row[1] == -row[0]
        assert abs(row[1]-.2) <= 1e-14
        assert row[2] == -row[3] == out.cell_transfers[0].rate_mol_s > 0
        assert row[4] == 0
        assert np.all(out.rates.face_species_mol_s == 0) and np.all(out.rates.face_energy_w == 0)
        assert set(out.rates.cell_power_components_w) == COMPONENTS
        assert out.rates.cell_power_components_w['body'][0] == 0
        assert np.array_equal(out.rates.cell_power_w, base.rates.cell_power_w)
        assert all(np.array_equal(value, base.rates.cell_power_components_w[key])
                   for key, value in out.rates.cell_power_components_w.items())
        assert state.energy_model_identity == host.energy_model_identity
        assert abs(inverse.total_energy_residual_j) <= 1e-6
        assert inverse.temperature_error_bound_k <= 1e-6
        assert abs(thermal.mechanical.temperature_k-300.) <= 1e-6
        solid = F(2.)*F(2e-5)
        assert abs(F(thermal.solid_volume_m3)-solid) <= F(1e-18)
        expected_pore = F(current.storages[0].bulk_volume_m3)-solid
        assert abs(F(thermal.available_pore_volume_m3)-expected_pore) <= F(1e-18)
        result['installed_after'] = installed_identity()
        result['status'] = 'passed'
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        result['elapsed_s'] = time.monotonic()-started
        save_result('callback-result.json', result)
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
