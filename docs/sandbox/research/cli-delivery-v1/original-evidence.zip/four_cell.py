import json
from pathlib import Path
import time
from sludge_sandbox.verification_case import read_case, build_case, snapshot

here = Path(__file__).parent
payload = json.loads((here/'run/case.json').read_bytes())
payload['case_id'] = 'reacting-wet-slab-four-cell-initialization-v1'
payload['grid']['cells'] = 4
path = here/'four-cell-case.json'
path.write_text(json.dumps(payload, indent=2)+'\n')
record = {'status': 'started', 'scope': 'initialization and callback only, not trajectory validation'}
started = time.monotonic()
try:
    case = read_case(path)
    built = build_case(case, here/'run/water')
    record.update(case_sha256=case.sha256, initialization=built.initialization,
                  snapshot=snapshot(built, built.initial, built.start_s))
    assert len(record['snapshot']['initial_temperature_checks']) == 4
    assert len(record['initialization']['extensive_storage_checks']) == 2
    record['status'] = 'passed'
except Exception as exc:
    record.update(status='failed', error_type=type(exc).__name__, reason=str(exc))
finally:
    record['elapsed_seconds'] = time.monotonic()-started
    (here/'four-cell-result.json').write_text(json.dumps(record, indent=2))
print(json.dumps({k:v for k,v in record.items() if k not in ('snapshot','initialization')}))
raise SystemExit(0 if record['status'] == 'passed' else 1)
