"""Saved-artifact checks only; no EOS. Original ledger oracle retained unchanged."""
import hashlib
import json
from pathlib import Path
from sludge_sandbox.run_service import read_run, trace_run
from audit_ledgers import audit

here = Path(__file__).parent
record = {'status': 'started', 'runs': {}}
try:
    runs = []
    for name in ('run', 'replay'):
        result, manifest = read_run(here/name)
        assert result['status'] == 'completed'
        assert result['initial_snapshot']['initial_temperature_checks']
        assert result['integration']['states'][0] == result['initialization']['conservative_state']
        normalized = {'run': result['integration'], 'initial': result['initialization']['conservative_state']}
        path = here/(name+'-ledger-input.json')
        path.write_text(json.dumps(normalized, indent=2))
        checked = audit(path, {})
        checked['original_result_sha256'] = manifest['files']['result.json']
        record['runs'][name] = checked
        runs.append(result)
    left, right = runs
    assert right['replay_of']['result_sha256'] == hashlib.sha256((here/'run/result.json').read_bytes()).hexdigest()
    for key in ('initialization', 'initial_snapshot', 'final_snapshot', 'policy', 'runtime_before', 'runtime_after'):
        assert left[key] == right[key], key
    for key in left['integration']:
        if key != 'elapsed_seconds':
            assert left['integration'][key] == right['integration'][key], key
    for quantity in ('amounts_mol','internal_energy_j','temperature_k','pressure_pa'):
        trace = trace_run(here/'run', quantity)
        assert trace['value']
        assert len(trace['implementation_artifacts']) == 47
    record.update(status='passed', replay_numerical_values_identical=True,
                  integration_steps=len(left['integration']['steps']),
                  final_temperature_k=left['final_snapshot']['temperature_k'])
finally:
    (here/'verification.json').write_text(json.dumps(record, indent=2))
print(json.dumps({k:v for k,v in record.items() if k != 'runs'}))
