import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).parent
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
PYTHON = '/private/tmp/brick-water-backend-probe/venv/bin/python'
name = sys.argv[1]
if name == 'run':
    args = ['run', str(ROOT/'data/sandbox/cases/reacting-wet-slab-v1.json'),
            '--water-data', str(ROOT/'data/sandbox/water'), '--output', str(HERE/'run')]
elif name == 'replay':
    args = ['replay', str(HERE/'run'), '--output', str(HERE/'replay')]
else:
    raise ValueError(name)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
env.pop('PYTHONPATH', None)
started = time.monotonic()
record = {'command': [PYTHON, '-m', 'sludge_sandbox', *args], 'timeout_s': 150}
try:
    result = subprocess.run(record['command'], cwd='/private/tmp', env=env,
                            capture_output=True, text=True, timeout=150)
    record.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
except subprocess.TimeoutExpired as exc:
    record.update(returncode=None, timeout=True, stdout=str(exc.stdout), stderr=str(exc.stderr))
record['elapsed_seconds'] = time.monotonic()-started
(HERE/(name+'-process.json')).write_text(json.dumps(record, indent=2))
print(json.dumps(record))
raise SystemExit(0 if record.get('returncode') == 0 else 1)
