# Independent mixed exact-stage review — revision required

## Final repaired freeze — APPROVE within its declared supported domains

Re-reviewed source 9bd9ffd53eb1ba89cc74135c8359ce66055a751811d896250944a80683cb2007 and tests de4ae1d9d3988fb3f113d0f0e0829547cf5356287d55c6adb306406966d2b50a / 3b11612c8f7bcc2c6789060e116e966a68c9351ca19b390467be893c27636425. Actual independent execution: **28 passed in 9.75 s**, in independent-fixed01.log/XML. Prior source/reviewer probes and RED results remain preserved.

The HIGH finding is addressed by fail-closed admission: wet trials without the new explicit analytic manufactured-liquid declaration return pressure_temperature_envelope_unavailable. Supported dry and declared constant-liquid calculations enclose the full inverse-temperature and volume intervals by exact Fraction pressure corner arithmetic and retain the original fixed-T pressure error additionally. Both paths' resulting radii enter the unchanged pressure gate. The manufactured declaration binds host, domains, callback objects/code and explicit constant-volume fixture annotations; it selects independently tested artificial physics, not a proof of arbitrary Python callback semantics or a native-water certificate. Native methods cannot enter this fixture route. No generic wet/native pressure-interval claim is now made.

The MEDIUM failure-record issue is fixed: endpoint_attempts records the actual endpoint input, timestamp, panel and constructed ledger before entering the endpoint callback guard. Both formal endpoint failures at calls 3/9 and an independent equality check against the actual failed input passed. Attempts do not invent nonexistent rates or commit a candidate.

No unresolved HIGH/CRITICAL finding remains for these explicit domains. Full wet native interval support is still missing work, not waived by this approval. The next actual EOS interval project must be reviewed independently before changing that boundary.

## Preserved original findings

Initial frozen source: 467658a333b9bdb8c39b24e49b39bf37d0fa357fc2449bede037fe65a466ab3e. Independent actual baseline: 17 passed in 5.96 s (`independent-baseline.log/XML`); independent probes: 5 passed in 2.14 s (`independent-extra01.log/XML`). No native EOS, installation, source or repository edits were made.

[HIGH] Pressure comparison is not a pressure bound for the U-inverted state
File: mass_wet_exact_stage.py:244
Issue: The pressure comparison adds each point.pressure_error_pa, which is conditional on its returned temperature. The U-to-T inverse has a separate nonzero temperature_error_bound_k; its induced pressure uncertainty is omitted. The present expression is correctly a fixed-returned-T pressure comparison, but cannot satisfy a stronger pressure gate on the U-inverted physical state. Existing fluid envelopes provide liquid numerical errors and |du/dp|, not a domain-wide |dv/dT| or equivalent liquid-volume interval certificate.
Fix: Preserve fixed-T diagnostics separately, and require an appropriately bound interval pressure certificate for the inverse temperature range before passing a true state-pressure gate. Do not promote local derivatives, finite samples or the manufactured liquid seam to native EOS interval evidence. Missing evidence must fail closed at the original numerical thresholds.

[MEDIUM] Endpoint failure omits the already constructed trial input and ledger
File: mass_wet_exact_stage.py:224
Issue: Endpoint state and exact/represented ledger exist before the endpoint callback, but only enter StepTrial after that callback succeeds. A failing endpoint leaves panel and midpoint samples, with no direct record of the actual endpoint input or its constructed ledger. The independent third-callback failure proves correct 3 attempted / 2 completed cost and no commit, but also confirms that the failed endpoint is absent from result samples/steps.
Fix: Preserve explicit pre-callback attempt records containing actual input/time/role, and preserve the already constructed ledger without inventing nonexistent endpoint rates. Cover failures at both full and half2 endpoints.

Positive findings: kg, liquid mol, gas mol and energy channels are separate; midpoint affine-rate integration identities are checked exactly. Exact large-origin timestamps are retained and callback budgets are charged. Inventory polynomials check whole-interval minima, including an interior vertex, with strict positive wet liquid and identically zero dry liquid. All generated candidates remain local, with no event switch or global commit. The independent probes confirm both T bounds enter the temperature comparison and both fixed-T bounds enter the existing pressure comparison, plus budgets of 0/2/8, failed endpoint costs and noncommit behavior. These findings do not resolve the pressure-certificate gap.

Verdict: BLOCK use as a full U-state pressure-certified stage pending the first fix. This does not challenge the correctness of the saved fixed-T diagnostics or permit reducing the original completion requirement. Author/root have been notified; original results and frozen source are retained.
