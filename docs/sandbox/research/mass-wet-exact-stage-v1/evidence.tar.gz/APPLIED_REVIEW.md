# Applied exact-stage verification

Actual applied production SHA256 is 9bd9ffd53eb1ba89cc74135c8359ce66055a751811d896250944a80683cb2007, exactly the reviewed freeze. Applied main test SHA256 is de4ae1d9d3988fb3f113d0f0e0829547cf5356287d55c6adb306406966d2b50a. Applied tests/sandbox/test_mass_wet_exact_stage_guards.py is 3b11612c8f7bcc2c6789060e116e966a68c9351ca19b390467be893c27636425, matching the reviewed test_review_fixes.py despite its destination filename.

The narrow source/test application is APPROVED under CODE_REVIEW.md's repaired-domain limitations. Root's source/installed regressions run separately; no tests, source mutations, installation or EOS calls were added by this applied-hash check. GOAL_STATUS.md has independent root edits not covered by this code-byte approval.
