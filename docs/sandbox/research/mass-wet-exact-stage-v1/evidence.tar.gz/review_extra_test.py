"""Independent exact-stage probes; manufactured seam, no native EOS."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_mass_wet_exact_stage import setup, run, policy, fixture
from sludge_sandbox.mass_wet_transport import WetPair
from sludge_sandbox.mass_wet_exact_stage import try_step_doubling
from sludge_sandbox.exact_event_clock import ExactEventTime as T


def test_individual_thermodynamic_error_bounds_are_not_dropped(monkeypatch):
    pair, initial = setup(monkeypatch)
    result = run(pair, initial)
    assert result.status == 'accepted'
    whole, _, fine = result.steps
    temperature = []
    pressure = []
    for left, right in zip(whole.endpoint_sample.rates.cells, fine.endpoint_sample.rates.cells):
        a, b = left.inverse, right.inverse
        temperature.append(abs(F(a.point.temperature_k)-F(b.point.temperature_k))
                           + F(a.temperature_error_bound_k)+F(b.temperature_error_bound_k))
        pressure.append(abs(F(a.point.pressure_pa)-F(b.point.pressure_pa))
                        + F(a.point.pressure_error_pa)+F(b.point.pressure_error_pa))
    assert dict(result.comparisons)['temperature_k'] == max(temperature)
    assert dict(result.comparisons)['pressure_pa'] > max(pressure)
    # Pressure expression above only certifies fixed-returned-T mechanical
    # error. It is deliberately NOT a proof of U-inverse pressure uncertainty.


@pytest.mark.parametrize('budget', [0, 2, 8])
def test_evaluation_budget_preserves_all_finished_sample_evidence(monkeypatch, budget):
    pair, initial = setup(monkeypatch)
    result = try_step_doubling(pair, initial, start=T(F(10**16)), end=T(F(10**16)+F(1,1000)),
                               policy=policy(maximum_evaluations=budget))
    assert result.status == 'resource_limit' and result.candidate_state is None
    assert result.evaluations_attempted == result.evaluations_completed == budget
    assert len(result.samples) == budget
    assert result.initial_state is initial


def test_endpoint_failure_reports_cost_without_committing(monkeypatch):
    pair, initial = setup(monkeypatch)
    original = WetPair.evaluate
    calls = [0]
    observed_inputs = []
    def fail(self, states):
        calls[0] += 1
        observed_inputs.append(states)
        if calls[0] == 3:
            raise ValueError('independent_full_endpoint_failure')
        return original(self, states)
    monkeypatch.setattr(WetPair, 'evaluate', fail)
    result = run(pair, initial)
    assert result.status == 'failed' and result.reason == 'independent_full_endpoint_failure'
    assert (result.evaluations_attempted, result.evaluations_completed) == (3, 2)
    assert len(result.panels) == 1 and len(result.samples) == 2
    assert not result.steps and result.candidate_state is None
    # Record the actual failed input rather than inventing an endpoint sample
    # carrying rates which never existed.
    assert observed_inputs[-1] != initial
    attempt = result.endpoint_attempts[-1]
    assert attempt.endpoint_state == observed_inputs[-1]
    assert attempt.ledger.start == result.start and attempt.ledger.end == result.end
    assert attempt.panel == result.panels[-1]
