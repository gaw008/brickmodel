from pathlib import Path
import sys
import sludge_sandbox
candidate=Path('/private/tmp/brick-water-pressure-interval-v1/native_controller_candidate')
sludge_sandbox.__path__.insert(0,str(candidate))
sys.path.insert(0,str(candidate))
sys.path.insert(0,str(Path.cwd()/'tests/sandbox'))
