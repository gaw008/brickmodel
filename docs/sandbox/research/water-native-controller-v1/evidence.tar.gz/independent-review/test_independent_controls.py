from dataclasses import replace
from fractions import Fraction as F
import json
from test_mass_wet_native_controller import setup,make_session,execute
from sludge_sandbox import mass_wet_controller_pressure as helper


def test_independent_pressure_gate_failure_is_atomic(monkeypatch):
    pair,initial,rp,cp=setup(monkeypatch)
    session,calls,_=make_session(monkeypatch)
    actual=helper.controller_pressure_radius
    def widened(*args,**kw):
        value=actual(*args,**kw)
        c=kw['context']
        if c.refinement_role=='independent' and c.comparison_kind=='event' and c.side=='candidate':
            return value+F(1000000)
        return value
    monkeypatch.setattr(helper,'controller_pressure_radius',widened)
    result=execute(pair,initial,rp,cp,session)
    assert result.status=='failed' and result.reason=='independent_approach_comparison_failed'
    assert result.states==(initial,) and result.times==(result.original_start,) and not result.steps and not result.packets
    assert result.operator is pair and result.roundoff_totals.aggregate.events==0
    assert result.refinements[-1].role=='independent' and result.refinements[-1].status=='comparison_fail'
    assert len(result.refinements[-1].comparison)==3
    assert result.refinements[-1].comparison[0][2][4]>F(result.stage_policy.pressure_absolute_pa)
    assert result.pressure_session_after.attempts==tuple(calls)


def test_initial_mutation_preserves_original_entry(monkeypatch):
    pair,initial,rp,cp=setup(monkeypatch)
    original=initial[0].internal_energy_j
    def mutate(n,context):
        object.__setattr__(initial[0],'internal_energy_j',original+1.)
    session,calls,_=make_session(monkeypatch,after=mutate)
    result=execute(pair,initial,rp,cp,session)
    assert result.status=='failed' and 'native_original_controller_inputs_changed' in result.reason
    assert not result.steps and not result.packets and len(calls)==1
    frozen=json.loads(result.original_controller_inputs_json)
    # encoded float has a tagged exact hexadecimal representation.
    assert frozen[0][0]['fields']['internal_energy_j'] != json.loads(__import__('sludge_sandbox.mass_wet_pressure_interval',fromlist=['encoded']).encoded(initial))[0]['fields']['internal_energy_j']
