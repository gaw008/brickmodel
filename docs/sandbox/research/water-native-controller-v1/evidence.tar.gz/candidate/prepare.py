from pathlib import Path
p=Path(__file__).parent;s=(p/'baseline_controller.py').read_text().replace('from dataclasses import dataclass, replace','from dataclasses import dataclass, replace, fields')
s=s.replace('class Stop(ValueError):','''@dataclass(frozen=True, kw_only=True)
class NativePressureMixedControllerResult(MixedControllerResult):
    """Versioned research result; intentionally unsupported by legacy codec."""
    original_controller_inputs_json: bytes
    pressure_session_before: object
    pressure_session_after: object
    pressure_comparison_contexts: tuple
    native_schema: str = 'mixed_native_pressure_controller_v1'


class Stop(ValueError):''')
s=s.replace('        cancel=None) -> MixedControllerResult:', '        cancel=None, pressure_session=None) -> MixedControllerResult:')
s=s.replace("    cp=controller_policy;sp=stage_policy", """    session_before=None;native_inputs_json=None;pressure_contexts=[]
    if pressure_session is not None:
        from sludge_sandbox.mass_wet_pressure_session import PressureSession
        from sludge_sandbox.mass_wet_pressure_interval import encoded
        from sludge_sandbox.mass_wet_controller_pressure import ControllerPressureQueryContext,controller_pressure_radius
        require(type(pressure_session) is PressureSession,'explicit_controller_pressure_session')
        require(constant_liquid_fixture is None,'native_controller_pressure_and_fixture_are_exclusive')
        session_before=pressure_session.snapshot()
    cp=controller_policy;sp=stage_policy""")
s=s.replace('    begun=time.monotonic();refs=', '''    if pressure_session is not None:
        native_inputs_json=encoded((initial,start,end,sp,roundoff_policy,original_liquid_fraction_limit,cp,context,original_binding,
            session_before.original_configuration_json,session_before.original_physics_json,session_before.source_before))
    begun=time.monotonic();refs=''')
s=s.replace('    def guard():\n        require(pair.binding()', '''    def guard():
        if pressure_session is not None:
            snapshot=pressure_session.snapshot()
            require(encoded((initial,start,end,sp,roundoff_policy,original_liquid_fraction_limit,cp,context,original_binding,
                snapshot.original_configuration_json,snapshot.original_physics_json,snapshot.source_before))==native_inputs_json,'native_original_controller_inputs_changed')
        require(pair.binding()''')
s=s.replace('    def fixture_for(op):', '''    def native_guard():
        # Session/stage classify actual exception types, never reason strings.
        try:guard()
        except Stop as exc:
            if exc.status=='cancelled':raise InterruptedError(str(exc)) from exc
            if exc.status=='resource_limit':raise TimeoutError(str(exc)) from exc
            raise
    def native_cancel():
        native_guard();return False
    def fixture_for(op):''')
old='                    trial=try_step_doubling(op,state,start=now,end=now.shifted(duration),policy=policy,constant_liquid_fixture=fixture_for(op),cancel=cancel)'
new='''                    if pressure_session is None:
                        trial=try_step_doubling(op,state,start=now,end=now.shifted(duration),policy=policy,constant_liquid_fixture=fixture_for(op),cancel=cancel)
                    else:
                        trial=try_step_doubling(op,state,start=now,end=now.shifted(duration),policy=policy,pressure_session=pressure_session,cancel=native_cancel)'''
assert old in s;s=s.replace(old,new)
s=s.replace('    def differences(a,b,op_a,op_b,obs_a,obs_b,ta,tb,width_a=F(),width_b=F()):', '    def differences(a,b,op_a,op_b,obs_a,obs_b,ta,tb,width_a=F(),width_b=F(),*,comparison_kind=None,comparison_level=None,comparison_role=None,event_index=None,selected_cell=None):')
old="            pressure=max(pressure,abs(F(va.point.pressure_pa)-F(vb.point.pressure_pa))+pressure_radius(op_a,a[i],va,i,fixture_for(op_a))+pressure_radius(op_b,b[i],vb,i,fixture_for(op_b)))"
new="""            if pressure_session is None:
                pressure=max(pressure,abs(F(va.point.pressure_pa)-F(vb.point.pressure_pa))+pressure_radius(op_a,a[i],va,i,fixture_for(op_a))+pressure_radius(op_b,b[i],vb,i,fixture_for(op_b)))
            else:
                radii=[]
                for side,op,states,obs,at in (('reference',op_a,a,obs_a,ta),('candidate',op_b,b,obs_b,tb)):
                    ctx=ControllerPressureQueryContext(comparison_kind,side,comparison_level,comparison_role,event_index,selected_cell,i,at,op.binding(),op.interfaces,native_inputs_json)
                    pressure_contexts.append(ctx)
                    try:
                        radius=controller_pressure_radius(op,states,obs,i,pressure_session=pressure_session,context=ctx,
                            caller_guard=native_guard,remaining_caller_wall=remaining_wall)
                    except InterruptedError as exc:raise Stop('cancelled',str(exc)) from exc
                    except TimeoutError as exc:raise Stop('resource_limit',str(exc)) from exc
                    except DomainExit as exc:raise Stop('domain_exit',str(exc)) from exc
                    radii.append(radius)
                pressure=max(pressure,abs(F(va.point.pressure_pa)-F(vb.point.pressure_pa))+sum(radii,F()))"""
assert old in s;s=s.replace(old,new)
s=s.replace('    def compare(a,b):','    def compare(a,b,comparison_level,comparison_role):')
s=s.replace('        for fa,fb in zip(a.frames,b.frames):','        for event_index,(fa,fb) in enumerate(zip(a.frames,b.frames)):')
s=s.replace('eb.upper.elapsed_since(eb.lower))','eb.upper.elapsed_since(eb.lower),comparison_kind=\'event\',comparison_level=comparison_level,comparison_role=comparison_role,event_index=event_index,selected_cell=fa.terminal.root_order.selected_cell)')
s=s.replace('a.times[-1],b.times[-1])))', "a.times[-1],b.times[-1],comparison_kind='common',comparison_level=comparison_level,comparison_role=comparison_role)))")
s=s.replace('compare(previous,path)', "compare(previous,path,level,'terminal')").replace('compare(path,fine)',"compare(path,fine,level,'independent')")
s=s.replace('    return MixedControllerResult(status,reason,accepted.times', '    result=MixedControllerResult(status,reason,accepted.times')
end='''    if pressure_session is None:return result
    return NativePressureMixedControllerResult(**{f.name:getattr(result,f.name) for f in fields(MixedControllerResult) if f.name!='qualification'},
        qualification='autonomous_research_single_atomic_packet_conditional_native_pressure_no_codec_service_or_resume',
        original_controller_inputs_json=native_inputs_json,pressure_session_before=session_before,
        pressure_session_after=pressure_session.snapshot(),pressure_comparison_contexts=tuple(pressure_contexts))


'''
s=s.replace('\n\ndef audit_prefix(', '\n'+end+'def audit_prefix(')
(p/'mass_wet_exact_controller.py').write_text(s)
p=p/'mass_wet_controller_pressure.py';s=p.read_text().replace('WetPair,WetCellRate','WetPair,WetCellRate,WetRates');s=s.replace('    time: T\n','    cell: int\n    time: T\n');s=s.replace("        require(type(self.time) is T", "        require(type(self.cell) is int and self.cell in (0,1),'explicit_pressure_query_cell')\n        require(type(self.time) is T");s=s.replace("    context.__post_init__()", "    context.__post_init__()\n    require(context.cell==cell and type(sample.rates) is WetRates and len(sample.rates.cells)==2,'actual_controller_pressure_rate_layout')");p.write_text(s)
