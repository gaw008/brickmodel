from pathlib import Path
import sys,importlib.util,json,dataclasses
from fractions import Fraction as F
from pytest import MonkeyPatch
import sludge_sandbox
P=Path(__file__).parent
sludge_sandbox.__path__.insert(0,str(P));sys.path.insert(0,str(Path.cwd()/'tests/sandbox'))
from test_mass_wet_exact_controller import setup
from test_mass_wet_exact_stage import fixture,policy
from sludge_sandbox import mass_wet_exact_controller as new
from sludge_sandbox.exact_event_clock import ExactEventTime as T
spec=importlib.util.spec_from_file_location('baseline_controller',P/'baseline_controller.py');old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
def norm(x):
 if dataclasses.is_dataclass(x):return {'type':type(x).__name__,'fields':{f.name:norm(getattr(x,f.name)) for f in dataclasses.fields(x) if f.name!='elapsed_seconds'}}
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return tuple(norm(v) for v in x)
 return x
with MonkeyPatch.context() as mp:
 pair,initial,rp,cp=setup(mp);results=[]
 for usefixture in (False,True):
  out=[]
  for module in (old,new):
   controls=dataclasses.asdict(cp)
   if usefixture:controls['maximum_evaluations']=5
   result=module.integrate_mixed_exact(pair,initial,start=T(F()),end=T(F(1,2000)),stage_policy=policy(),roundoff_policy=rp,original_liquid_fraction_limit=F('1e-8'),controller_policy=module.MixedControllerPolicy(**controls),constant_liquid_fixture=fixture(pair) if usefixture else None)
   out.append(result)
  assert norm(out[0])==norm(out[1]);results.append({'fixture':usefixture,'status':out[0].status,'full_nonwall_value_equal':True,'costs':dict(out[0].costs)})
(P/'default-parity.json').write_text(json.dumps(results,indent=2)+'\n')
