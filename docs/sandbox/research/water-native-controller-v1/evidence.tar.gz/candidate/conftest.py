# Temporary overlay, not for application.
from pathlib import Path
import sys
import sludge_sandbox
HERE=Path(__file__).parent
sludge_sandbox.__path__.insert(0,str(HERE))
sys.path.insert(0,str(Path.cwd()/'tests/sandbox'))
