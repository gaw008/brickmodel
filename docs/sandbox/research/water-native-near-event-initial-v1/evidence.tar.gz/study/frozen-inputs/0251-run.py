"""One tiny-positive-inventory initial observation; never a stage or event."""
from pathlib import Path
from fractions import Fraction
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent


def main():
    begun = time.monotonic()
    output = HERE / 'attempt01'
    output.mkdir(exist_ok=False)
    freeze = json.loads((HERE / 'EXECUTION_FREEZE.json').read_bytes())
    case = json.loads((HERE / 'CASE.json').read_bytes())
    limits = case['resource_budget']
    summary = {'status': 'started', 'freeze': freeze, 'case': case,
               'qualification': 'conditional_source_water_original_manufactured_material_and_error_contracts',
               'native_internal_call_count': None, 'global_commit': False}
    host_attempted = host_completed = 0

    def sha(path):
        try:
            return hashlib.sha256(Path(path).read_bytes()).hexdigest()
        except OSError:
            return None

    def save(path, value):
        from sludge_sandbox.mass_wet_pressure_interval import data
        tmp = path.with_suffix('.partial')
        tmp.write_text(json.dumps(data(value), indent=2, allow_nan=False) + '\n')
        os.replace(tmp, path)

    def members():
        return {directory: sorted(str(p) for p in Path(directory).rglob(pattern) if p.is_file())
                for directory, pattern in freeze['directory_patterns'].items()}

    def guard():
        expected_package = Path(freeze['installed_package_root'])
        spec = importlib.util.find_spec('sludge_sandbox')
        if spec is None or spec.origin is None or Path(spec.origin).resolve() != expected_package / '__init__.py':
            raise ValueError('actual_import_path_not_frozen_installation')
        direct = json.loads(importlib.metadata.distribution('sludge-vme').read_text('direct_url.json'))
        if direct != freeze['direct_url'] or direct.get('dir_info', {}).get('editable', False):
            raise ValueError('actual_distribution_not_frozen_installation')
        for name, module in tuple(sys.modules.items()):
            if name == 'sludge_sandbox' or name.startswith('sludge_sandbox.'):
                filename = getattr(module, '__file__', None)
                if filename is None:
                    raise ValueError('loaded_module_without_frozen_source:' + name)
                actual = Path(filename).resolve()
                if not actual.is_relative_to(expected_package) or str(actual) not in freeze['files']:
                    raise ValueError('loaded_module_not_frozen_installation:' + name)
        if time.monotonic() - begun >= limits['whole_study_wall_seconds']:
            raise TimeoutError('original_whole_study_wall')
        if any(sha(path) != digest for path, digest in freeze['files'].items()):
            raise ValueError('frozen_source_changed')
        if members() != freeze['directory_members']:
            raise ValueError('frozen_directory_membership_changed')

    try:
        guard()
        from build_initial import build_initial

        save(output / 'summary.json', summary)

        def initial_guard():
            guard()
            if time.monotonic() - begun >= limits['initialization_wall_seconds']:
                raise TimeoutError('initial_energy_construction_wall')

        pair, states = build_initial(output / 'initial', initial_guard)
        initial_guard()
        binding = pair.binding()
        save(output / 'observation-input.json', states)
        guard()
        if host_attempted >= limits['maximum_host_evaluations']:
            raise ValueError('original_one_pair_cap')
        host_attempted += 1
        summary.update(status='host_entered', host_attempted=host_attempted, host_completed=host_completed)
        save(output / 'summary.json', summary)
        rates = pair.evaluate(states)
        host_completed += 1
        # Save returned observations before post-call rejection or diagnostics.
        save(output / 'rates.json', rates)
        summary.update(status='host_returned', host_completed=host_completed)
        save(output / 'summary.json', summary)
        guard()
        if pair.binding() != binding or pair.interfaces != ('existing_liquid', 'existing_liquid'):
            raise ValueError('observation_source_or_mode_changed')
        diagnostics = []
        for state, rate in zip(states, rates.cells, strict=True):
            phase = Fraction(rate.phase_water_mol_s)
            diagnostics.append({'liquid_mol': Fraction(state.liquid_water_mol),
                'phase_rate_mol_s': phase,
                'tangent_seconds': Fraction(state.liquid_water_mol)/phase if phase > 0 else None,
                'tangent_qualification': 'diagnostic_only_not_root_order_or_event_permission'})
        save(output / 'diagnostics.json', diagnostics)
        initial_status = json.loads((output / 'initial/operation-status.json').read_bytes())
        counts = initial_status['costs']
        if not (counts['initial_forward_attempted'] == counts['initial_forward_completed'] == 2
                and counts['host_attempted'] == counts['host_completed'] == 0
                and host_attempted == host_completed == 1):
            raise ValueError('preregistered_two_forward_one_pair_work')
        summary.update(status='observation_completed', diagnostics=diagnostics,
                       scientific_admission=False, event_admission=False)
        guard()
    except Exception as exc:
        summary.update(status='failed', reason=type(exc).__name__ + ': ' + str(exc),
                       traceback=traceback.format_exc())
    finally:
        summary.update(host_attempted=host_attempted, host_completed=host_completed)
        summary['source_after'] = {p: sha(p) if Path(p).is_file() else None for p in freeze['files']}
        summary['directory_members_after'] = members()
        summary['inputs_unchanged'] = summary['source_after'] == freeze['files']
        summary['membership_unchanged'] = summary['directory_members_after'] == freeze['directory_members']
        summary['elapsed_seconds'] = time.monotonic() - begun
        if not summary['inputs_unchanged'] or not summary['membership_unchanged'] or summary['elapsed_seconds'] >= limits['whole_study_wall_seconds']:
            summary['status'] = 'failed'
        save(output / 'summary.json', summary)
    print(summary['status'], summary.get('reason'), summary['elapsed_seconds'])
    return 0 if summary['status'] == 'observation_completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
