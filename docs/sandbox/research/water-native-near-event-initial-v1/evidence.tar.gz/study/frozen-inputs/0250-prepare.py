"""Freeze the reviewed installed runtime without executing any physical query."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import sysconfig
import sludge_sandbox

HERE = Path(__file__).resolve().parent
REPO = Path('/Users/wanggaoying/Desktop/brickmodel-github')
BASE = HERE.parent
INPUTS = Path('/private/tmp/brick-mass-wet-transport-native-v1/inputs')


def main():
    target = HERE / 'EXECUTION_FREEZE.json'
    if target.exists():
        raise FileExistsError('execution freeze already exists; preserve it')
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    package = Path(sludge_sandbox.__file__).resolve().parent
    site = Path(sysconfig.get_paths()['purelib']).resolve()
    if not package.is_relative_to(site):
        raise ValueError('noninstalled_package')
    direct = json.loads(importlib.metadata.distribution('sludge-vme').read_text('direct_url.json'))
    if direct.get('dir_info', {}).get('editable', False):
        raise ValueError('editable_installation_not_admitted')
    source = REPO / 'src/sludge_sandbox'
    installed = {str(p.relative_to(package)): sha(p) for p in package.rglob('*.py')}
    expected = {str(p.relative_to(source)): sha(p) for p in source.rglob('*.py')}
    if installed != expected or len(installed) != 104:
        raise ValueError('reviewed_104_module_installation_required')
    files = {str(package / relative): digest for relative, digest in installed.items()}
    # Keep the complete actual constructor inputs and its original implementation.
    for p in INPUTS.rglob('*'):
        if p.is_file():
            files[str(p)] = sha(p)
    old_builder = INPUTS.parent / 'run.py'
    files[str(old_builder)] = sha(old_builder)
    for name in ('CASE.json', 'build_initial.py', 'run.py', 'supervise.py', 'prepare.py', 'HANDOFF.md'):
        p = HERE / name
        files[str(p)] = sha(p)
    official = REPO / 'data/sandbox/water/IAPWS95-2018.pdf'
    coefficients = BASE / 'heos-water.json'
    proposal = BASE / "native_controller_cost_review/NEAR_EVENT_CASE_PROPOSAL.md"
    selection_trial = BASE / "native_stage_study/attempt01/trial.json"
    for p in (official, coefficients, proposal, selection_trial):
        files[str(p)] = sha(p)
    native = json.loads((INPUTS / 'water/heos-8.0.0-approved-manifest.json').read_bytes())
    for relative, digest in native['files'].items():
        p = site / 'CoolProp' / relative
        if sha(p) != digest:
            raise ValueError('approved_native_package_changed')
        files[str(p)] = digest
    patterns = {str(package): '*.py', str(INPUTS): '*'}
    members = {directory: sorted(str(p) for p in Path(directory).rglob(pattern) if p.is_file())
               for directory, pattern in patterns.items()}
    payload = {'status': 'prepared_not_executed', 'files': files,
               'installed_package_root': str(package),
               'directory_patterns': patterns, 'directory_members': members,
               'installed_python_module_count': len(installed), 'direct_url': direct,
               'official_pdf': str(official), 'coefficient_json': str(coefficients),
               'case_sha256': sha(HERE / 'CASE.json'),
               'qualification': 'one tiny-inventory initial observation; no stage/event/material admission'}
    with target.open('x') as stream:
        json.dump(payload, stream, indent=2)
        stream.write('\n')
    print(len(files), len(installed), sha(target))


if __name__ == '__main__':
    main()
