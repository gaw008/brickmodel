"""Two initial forwards for an explicit tiny-inventory numerical seam fixture."""
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
import importlib.util
import json
import time

HERE = Path(__file__).resolve().parent
OLD = Path('/private/tmp/brick-mass-wet-transport-native-v1')
_spec = importlib.util.spec_from_file_location('reviewed_native_mass_builder', OLD / 'run.py')
_builder = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_builder)
capture = _builder.capture
save = _builder.save


def derived_case():
    original = json.loads((OLD / 'inputs/case.json').read_bytes())
    declaration = json.loads((HERE / 'CASE.json').read_bytes())
    for literal, rate, target in zip(declaration['liquid_inventory_hex'], declaration['selection_rule']['saved_phase_rate_exact'], declaration['selection_rule']['old_rate_target_seconds'], strict=True):
        if float(Fraction(*rate) * Fraction(*target)).hex() != literal:
            raise ValueError('fixed_inventory_selection_mismatch')
    if declaration['resource_budget']['maximum_initial_forward_evaluations'] != 2 or declaration['resource_budget']['maximum_host_evaluations'] != 1:
        raise ValueError('fixed_observation_work_caps')
    new = json.loads(json.dumps(original))
    new['initial_temperatures_k'] = declaration['initial_temperature_design_k']
    if len(new['initial_cells']) != 2:
        raise ValueError('original_two_cells_required')
    for cell, literal in zip(new['initial_cells'], declaration['liquid_inventory_hex'], strict=True):
        value = float.fromhex(literal)
        if value <= 0:
            raise ValueError('strictly_positive_new_liquid')
        cell['liquid_water_mol'] = value
    restored = json.loads(json.dumps(new))
    restored['initial_temperatures_k'] = original['initial_temperatures_k']
    for a, b in zip(restored['initial_cells'], original['initial_cells'], strict=True):
        a['liquid_water_mol'] = b['liquid_water_mol']
    if restored != original:
        raise ValueError('unapproved_physical_case_difference')
    return original, new, declaration


def build_initial(output: Path, guard):
    """Original storage constructor; fresh U at each declared temperature."""
    from sludge_sandbox.mass_wet_transport import WetPair, WetFace
    from sludge_sandbox.phase_storage import InversePolicy
    from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
    output.mkdir(exist_ok=False)
    original, case, declaration = derived_case()
    save(output / 'original-case.json', original)
    save(output / 'case.json', case)
    save(output / 'input-differences.json', {
        'case_id': declaration['case_id'],
        'original_temperatures_k': original['initial_temperatures_k'],
        'new_temperatures_k': case['initial_temperatures_k'],
        'original_liquid_mol': [c['liquid_water_mol'] for c in original['initial_cells']],
        'new_liquid_hex': declaration['liquid_inventory_hex'],
        'other_physical_fields_identical': True})
    costs = {'initial_forward_attempted': 0, 'initial_forward_completed': 0,
             'host_attempted': 0, 'host_completed': 0, 'native_internal_call_count': None}
    begun = time.monotonic()

    def checkpoint(status, reason=None):
        save(output / 'operation-status.json', dict(status=status, reason=reason,
             costs=costs, elapsed_seconds=time.monotonic() - begun))

    checkpoint('started')
    try:
        guard(); st = _builder.build_storage(output); guard()
        save(output / 'storage-inputs.json', capture(st))
        water = OLD / 'inputs/water'
        guard()
        chemical = WaterChemicalPotential(water, backend='heos', backend_manifest=water / 'heos-8.0.0-approved-manifest.json')
        guard()
        face = {k: tuple(v) if isinstance(v, list) else v for k, v in case['face'].items()}
        pair = WetPair((st, st), (InversePolicy(**case['inverse_policy']),) * 2,
            chemical, tuple(case['rate_constants_per_s']), tuple(case['oxygen_references_mol']),
            tuple(case['transfer_coefficients_mol_s_pa']), tuple(case['coefficient_source_ids']), WetFace(**face))
        identity = pair.binding()
        save(output / 'pair-inputs.json', capture(pair))
        states = []
        for i, (values, temperature) in enumerate(zip(case['initial_cells'], case['initial_temperatures_k'], strict=True)):
            state = st.state(tuple(values['solid_mass_kg']), values['liquid_water_mol'], tuple(values['gas_amounts_mol']), 0.)
            save(output / f'initial-prototype-{i}.json', capture(state))
            guard()
            if costs['initial_forward_attempted'] >= 2:
                raise ValueError('original_two_forward_cap')
            costs['initial_forward_attempted'] += 1
            checkpoint('initial_forward')
            point = st.evaluate(state, temperature)
            costs['initial_forward_completed'] += 1
            save(output / f'initial-forward-{i}.json', capture(point))
            checkpoint('initial_forward_returned')
            guard()
            states.append(replace(state, internal_energy_j=point.total_internal_energy_j))
        states = tuple(states)
        save(output / 'initial.json', capture(states))
        guard()
        if pair.binding() != identity:
            raise ValueError('initial_binding_changed')
        checkpoint('completed_initial_energy_construction')
        return pair, states
    except Exception as exc:
        checkpoint('failed', type(exc).__name__ + ': ' + str(exc))
        raise
