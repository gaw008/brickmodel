"""AST/data-only preparation check; never imports builder or physical modules."""
from pathlib import Path
from fractions import Fraction
import ast,json,hashlib,difflib
P=Path(__file__).resolve().parent
B=P.parent/'native_stage_study'
files=('CASE.json','build_initial.py','run.py','prepare.py','supervise.py','HANDOFF.md')
for name in files:
 if name.endswith('.py'):ast.parse((P/name).read_text())
tree=ast.parse((P/'build_initial.py').read_text());func=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='derived_case')
ns={'Path':Path,'json':json,'Fraction':Fraction,'HERE':P,'OLD':Path('/private/tmp/brick-mass-wet-transport-native-v1')}
exec(compile(ast.fix_missing_locations(ast.Module(body=[func],type_ignores=[])),'derived_case_only','exec'),ns)
original,new,c=ns['derived_case']()
assert original['initial_cells'][0]['liquid_water_mol']==original['initial_cells'][1]['liquid_water_mol']==.02
assert [x['liquid_water_mol'].hex() for x in new['initial_cells']]==c['liquid_inventory_hex']
assert new['initial_temperatures_k']==[300.125,305.25]
run=(P/'run.py').read_text();builder=(P/'build_initial.py').read_text()
for forbidden in ('try_step_doubling','PressureSession','prepare_mixed_terminal','integrate_mixed_exact'):
 assert forbidden not in run+builder,forbidden
assert run.count('pair.evaluate(states)')==1 and builder.count('st.evaluate(state, temperature)')==1
assert 'timeout=50.' in (P/'supervise.py').read_text()
assert not (P/'EXECUTION_FREEZE.json').exists()
changes=[]
for name in ('run.py','prepare.py','supervise.py','build_initial.py'):
 changes.extend(difflib.unified_diff((B/name).read_text().splitlines(True),(P/name).read_text().splitlines(True),fromfile='reviewed-stage/'+name,tofile='new-initial/'+name))
(P/'MINIMAL_DIFF.patch').write_text(''.join(changes))
r={'status':'passed_ast_and_data_only','case_id':c['case_id'],'initial_liquid_hex':c['liquid_inventory_hex'],'exact_selection_rule_verified':True,'other_physical_fields_identical_except_documented_temperature_and_liquid':True,'only_one_pair_call_site':True,'stage_session_terminal_controller_call_absent':True,'syntax_files_checked':4,'external_seconds':50,'native_calls':0,'execution_freeze_generated':False,'source_sha256':{n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in files}}
(P/'structure-result.json').write_text(json.dumps(r,indent=2)+'\n')
(P/'CANDIDATE_FREEZE.json').write_text(json.dumps({'status':'candidate_not_executed','files':r['source_sha256'],'checks':'structure-result.json','qualification':'root execution only after review; not an execution freeze'},indent=2)+'\n')
print(json.dumps(r,indent=2))
