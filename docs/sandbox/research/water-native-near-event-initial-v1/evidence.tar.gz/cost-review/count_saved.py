from pathlib import Path
from fractions import Fraction
import json
P=Path(__file__).resolve().parent
def dec(v):
 if isinstance(v,list):return [dec(x) for x in v]
 if not isinstance(v,dict):return v
 if 'float_hex'in v:return float.fromhex(v['float_hex'])
 if 'fraction'in v:return Fraction(*v['fraction'])
 if 'tuple'in v:return tuple(dec(x) for x in v['tuple'])
 if 'fields'in v:return {k:dec(x) for k,x in v['fields'].items()}
 return {k:dec(x) for k,x in v.items()}
d=dec(json.loads(Path('/private/tmp/brick-mass-wet-integration-v1/actual_record_study/packed-result.json').read_bytes()))
rows=[];ordinary_queries=0
for ref in d['refinements']:
 path=ref['path'];modes=[]
 for kind,a in path['attempts']:
  if kind=='ordinary':
   wet=sum(m=='existing_liquid' for m in a['samples'][0]['interfaces']);ordinary_queries+=2*wet;modes.append(wet)
 rows.append({'level':ref['level'],'role':ref['role'],'status':ref['status'],'costs':dict(ref['costs']),'ordinary_wet_cell_counts':modes,'steps':len(path['steps']),'events':len(path['frames']),'grid_points':len(path['approach_grid'])})
# Every recorded comparison pairs paths with matching modes; each wet cell needs one certificate per side.
comparison_queries=0
for ref in d['refinements']:
 if ref['comparison']:
  path=ref['path']
  comparison_queries+=sum(2*sum(m=='existing_liquid' for m in frame['modes_after']) for frame in path['frames'])
  comparison_queries+=2*sum(m=='existing_liquid' for m in path['operator']['operator_reference']['captured_modes'])
trial=dec(json.loads(Path('/private/tmp/brick-water-pressure-interval-v1/native_stage_study/attempt01/trial.json').read_bytes()))
session=trial['pressure_session_after'];queries=session['attempts']
for row in rows:
 assert row['costs']['evaluations_completed']==10*row['costs']['ordinary_trials']+4*row['events']+1
assert sum(x['costs']['evaluations_completed'] for x in rows)==396
r={'saved_manufactured_costs':dict(d['costs']),'paths':rows,'projected_native_queries_same_saved_grid':{'ordinary':ordinary_queries,'comparisons':comparison_queries,'total':ordinary_queries+comparison_queries,'proof_operations':4*(ordinary_queries+comparison_queries),'seed_evaluations_if_same_measured_5_per_query':5*(ordinary_queries+comparison_queries)},'native_stage':{'elapsed':trial['elapsed_seconds'],'host_callbacks':trial['evaluations_completed'],'session_elapsed':session['elapsed_seconds'],'query_elapsed':sum(x['elapsed_seconds'] for x in queries),'query_elapsed_each':[x['elapsed_seconds'] for x in queries],'seed':session['seed_attempted'],'proof':session['proof_attempted']}}
r['initial_tangent_seconds']=[float(Fraction(s['liquid_water_mol'])/Fraction(c['phase_water_mol_s'])) for s,c in zip(trial['initial_state'],trial['samples'][0]['rates']['cells'])]
r['native_stage']['stage_non_query_elapsed']=r['native_stage']['elapsed']-r['native_stage']['query_elapsed']
(P/'counts.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
