"""Execute only isolated pure derived_case function; no module/native imports."""
from pathlib import Path
from fractions import Fraction
import ast,json,hashlib,tempfile
C=Path('/private/tmp/brick-water-pressure-interval-v1/native_near_event_initial_study')
R=Path(__file__).parent
freeze=json.loads((C/'CANDIDATE_FREEZE.json').read_bytes())
assert all(hashlib.sha256((C/p).read_bytes()).hexdigest()==h for p,h in freeze['files'].items())
case=json.loads((C/'CASE.json').read_bytes())
# Read literal lossless float from original initial observation, independently.
trial=json.loads(Path('/private/tmp/brick-water-pressure-interval-v1/native_stage_study/attempt01/trial.json').read_bytes())['fields']
sample=trial['samples'][0]['fields'];rates=sample['rates']['fields']['cells']
for i,cell in enumerate(rates):
    rate=Fraction(float.fromhex(cell['fields']['phase_water_mol_s']['float_hex']))
    assert rate==Fraction(*case['selection_rule']['saved_phase_rate_exact'][i])
    value=float(rate*Fraction(*case['selection_rule']['old_rate_target_seconds'][i]))
    assert value.hex()==case['liquid_inventory_hex'][i] and 0<value<case['stage_policy']['amount_absolute_mol']
tree=ast.parse((C/'build_initial.py').read_text());function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='derived_case')
checks=[]
with tempfile.TemporaryDirectory(dir=R) as folder:
    base=Path(folder);(base/'old/inputs').mkdir(parents=True);(base/'new').mkdir()
    original=json.loads(Path(case['source_case']).read_bytes());(base/'old/inputs/case.json').write_text(json.dumps(original))
    namespace={'OLD':base/'old','HERE':base/'new','json':json,'Fraction':Fraction}
    exec(compile(ast.Module(body=[function],type_ignores=[]),'pure-derived-case','exec'),namespace)
    def run(declaration):
        (base/'new/CASE.json').write_text(json.dumps(declaration))
        return namespace['derived_case']()
    before,after,_=run(case)
    assert before==original
    for i in range(2):
        assert after['initial_cells'][i]['liquid_water_mol'].hex()==case['liquid_inventory_hex'][i]
        after['initial_cells'][i]['liquid_water_mol']=original['initial_cells'][i]['liquid_water_mol']
    after['initial_temperatures_k']=original['initial_temperatures_k'];assert after==original;checks.append('only_declared_input_changes')
    for label,mutate,reason in [
      ('mismatched_rule',lambda c:c['liquid_inventory_hex'].__setitem__(0,(1.).hex()),'fixed_inventory_selection_mismatch'),
      ('zero_inventory',lambda c:(c['liquid_inventory_hex'].__setitem__(0,(0.).hex()),c['selection_rule']['saved_phase_rate_exact'].__setitem__(0,[0,1])),'strictly_positive_new_liquid'),
      ('host_cap',lambda c:c['resource_budget'].__setitem__('maximum_host_evaluations',2),'fixed_observation_work_caps')]:
        changed=json.loads(json.dumps(case));mutate(changed)
        try:run(changed)
        except ValueError as exc:assert str(exc)==reason;checks.append(label)
        else:raise AssertionError(label)
with (R/'review_pure01.json').open('x') as f:json.dump({'status':'PASS','checks':checks,'original_phase_rule_matches':True,'below_original_amount_gate':True,'candidate_freeze':freeze,'native_calls':0},f,indent=2)
print('PASS',checks)
