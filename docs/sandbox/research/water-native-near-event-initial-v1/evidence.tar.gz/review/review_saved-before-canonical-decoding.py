"""Saved fresh query audit only. No model imports or EOS execution."""
from pathlib import Path
from decimal import Decimal as D
from fractions import Fraction as F
from itertools import product
from collections import deque
import hashlib,json
R=Path(__file__).parent;C=R.with_name('native_near_event_initial_study');O=C/'attempt01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def decode(v):
    if isinstance(v,list):return [decode(x) for x in v]
    if not isinstance(v,dict):return v
    if set(v)=={'float_hex'}:return float.fromhex(v['float_hex'])
    if set(v)=={'decimal'}:return D(v['decimal'])
    if set(v)=={'fraction'}:return F(*v['fraction'])
    if set(v)=={'bytes_hex'}:return bytes.fromhex(v['bytes_hex'])
    if set(v)=={'type','fields'}:return decode(v['fields'])
    return {k:decode(x) for k,x in v.items()}
def read(p):return decode(json.loads(p.read_bytes()))
def blob(v):return decode(json.loads(v))
def iv(v):return F(v['lo']),F(v['hi'])
def pt(v):return v,v
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
    v=[x*y for x in a for y in b];return min(v),max(v)
def isum(xs):
    s=pt(F())
    for x in xs:s=add(s,x)
    return s
def encloses(saved,exact):
    a,b=iv(saved);assert a<=exact[0]<=exact[1]<=b
def fraction_saved(value):
    return F(value['numerator'],value['denominator']) if isinstance(value,dict) else F(value)

def check_all_sample_energy(trial,pair):
    reports=[]
    for sample in trial['samples']:
        for cell,(state,rate) in enumerate(zip(sample['state'],sample['rates']['cells'],strict=True)):
            inv=rate['inverse'];p=inv['point'];st=pair['storages'][cell];m=p['fluid']['mechanical']
            assert inv['target_energy_j']==state['internal_energy_j'] and p['model_identity']==state['energy_model_identity']==st['_identity']
            assert m['liquid_inventory_mol']==state['liquid_water_mol'] and m['gas_inventory_mol']==dict(zip(('O2','N2','H2O'),state['gas_amounts_mol'],strict=True))
            net=st['reference']['network'];tr=fraction_saved(net['reference_temperature_k']);pr=fraction_saved(net['reference_pressure_pa'])
            terms=[F(mass)*(fraction_saved(h)+F(solid['cp_j_kg_k'])*(F(m['temperature_k'])-tr)-pr*F(solid['volume_m3_kg'])) for mass,solid,h in zip(state['solid_mass_kg'],st['solids'],st['reference']['particular_h0_j_kg'][:2],strict=True)]
            total=F(p['fluid']['internal_energy_j'])+sum(terms,F())
            assert p['total_internal_energy_j']==float(total) and p['solid_internal_energy_j']==list(map(float,terms))
            cp=F(p['fluid']['minimum_heat_capacity_j_k'])+sum((F(mass)*F(solid['cp_j_kg_k']) for mass,solid in zip(state['solid_mass_kg'],st['solids'],strict=True)),F())
            assert 0<F(p['minimum_heat_capacity_j_k'])<=cp
            error=F(p['fluid']['energy_error_bound_j'])+abs(F(p['total_internal_energy_j'])-total)+F(state['liquid_water_mol'])*F(st['fluid_template']['envelope']['liquid_abs_du_dp_bound_j_mol_pa'])*F(p['extra_pressure_error_pa'])
            assert F(p['extra_pressure_error_pa'])>=0 and F(p['energy_error_j'])>=error
            required=(abs(F(p['total_internal_energy_j'])-F(state['internal_energy_j']))+F(p['energy_error_j']))/F(p['minimum_heat_capacity_j_k'])
            assert required<=F(inv['temperature_error_bound_k'])
            reports.append({'role':sample['role'],'cell':cell,'required_epsilon':str(required),'saved_epsilon':str(F(inv['temperature_error_bound_k']))})
    assert len(reports)==2
    return reports

s=read(O/'summary.json');freeze=read(C/'EXECUTION_FREEZE.json');watch=read(C/'supervisor-result01.json')
assert s['freeze']==freeze and s['source_after']==freeze['files']=={p:sha(Path(p)) for p in freeze['files']}
assert len(freeze['files'])==254 and freeze['installed_python_module_count']==104
members={d:sorted(str(p) for p in Path(d).rglob(pattern) if p.is_file()) for d,pattern in freeze['directory_patterns'].items()}
assert members==freeze['directory_members']==s['directory_members_after']
assert s['status']=='observation_completed' and s['inputs_unchanged'] and s['membership_unchanged']
assert not s['scientific_admission'] and not s['event_admission'] and not s['global_commit'] and s['native_internal_call_count'] is None
assert s['host_attempted']==s['host_completed']==1
assert watch['returncode']==0 and not watch['external_timeout'] and watch['runner_unchanged']
assert watch['runner_sha256']==sha(C/'run.py') and watch['freeze_sha256']==sha(C/'EXECUTION_FREEZE.json') and watch['supervisor_sha256']==sha(C/'supervise.py')
assert s['elapsed_seconds']<40 and watch['elapsed_seconds']<watch['external_limit_seconds']==50
case=read(C/'CASE.json');h=O/'initial';initial=read(h/'initial.json');pair=read(h/'pair-inputs.json');rates=read(O/'rates.json');status=read(h/'operation-status.json')
assert status['status']=='completed_initial_energy_construction' and status['elapsed_seconds']<30
assert status['costs']=={'initial_forward_attempted':2,'initial_forward_completed':2,'host_attempted':0,'host_completed':0,'native_internal_call_count':None}
assert read(O/'observation-input.json')==initial and pair['interface_modes'] is None
source_case=read(Path(case['source_case']));derived=read(h/'case.json');original=read(h/'original-case.json')
assert original==source_case
for i,T in enumerate(case['initial_temperature_design_k']):
    p=read(h/f'initial-forward-{i}.json');prototype=read(h/f'initial-prototype-{i}.json');state=initial[i]
    assert p['fluid']['mechanical']['temperature_k']==T and state['internal_energy_j']==p['total_internal_energy_j']
    assert all(state[k]==prototype[k] for k in ('solid_mass_kg','liquid_water_mol','gas_amounts_mol','energy_model_identity'))
    assert state['liquid_water_mol'].hex()==case['liquid_inventory_hex'][i]
    assert 0<state['liquid_water_mol']<case['stage_policy']['amount_absolute_mol']
    assert state['solid_mass_kg']==source_case['initial_cells'][i]['solid_mass_kg'] and state['gas_amounts_mol']==source_case['initial_cells'][i]['gas_amounts_mol']
    derived['initial_cells'][i]['liquid_water_mol']=source_case['initial_cells'][i]['liquid_water_mol']
derived['initial_temperatures_k']=source_case['initial_temperatures_k'];assert derived==source_case
energy=check_all_sample_energy({'samples':[{'state':initial,'rates':rates,'role':'one_actual_observation'}]},pair)
diagnostics=read(O/'diagnostics.json');assert diagnostics==s['diagnostics'];rows=[]
for i,(state,rate,diag) in enumerate(zip(initial,rates['cells'],diagnostics,strict=True)):
    nl=F(state['liquid_water_mol']);phase=F(rate['phase_water_mol_s']);expected=nl/phase if phase>0 else None
    assert diag['liquid_mol']==nl and diag['phase_rate_mol_s']==phase and diag['tangent_seconds']==expected
    assert diag['tangent_qualification']=='diagnostic_only_not_root_order_or_event_permission'
    st=pair['storages'][i];inv=rate['inverse'];p=inv['point'];m=p['fluid']['mechanical'];liquid=rate['equilibrium']['liquid']['state'];water=st['fluid_template']['mechanical']['water']
    assert water==pair['chemical']['water'] and liquid['implementation']==water['implementation']
    assert liquid['phase']=='liquid' and liquid['method_id']=='iapws95_real_fluid_helmholtz'
    assert liquid['temperature_k']==m['temperature_k'] and liquid['pressure_pa']==m['pressure_pa']==m['liquid_pressure_pa']
    descriptor=json.loads(liquid['implementation']['canonical_descriptor'])['real_fluid'];mp=float.fromhex(descriptor['public_mass_hex']);mn=float.fromhex(descriptor['native_mass_hex'])
    assert descriptor['runtime']['fluid_sha256']==sha(Path(freeze['coefficient_json'])) and mp==liquid['reference']['molar_mass_kg_mol']
    assert m['liquid_volume_m3']==(state['liquid_water_mol']*mp)/liquid['density_kg_m3']
    lo,hi=map(F,inv['final_temperature_bracket_k']);t=F(m['temperature_k']);eps=F(inv['temperature_error_bound_k'])
    assert lo<=t-eps<=t+eps<=hi
    assert F(inv['temperature_error_bound_k'])<=F(pair['inverse_policies'][i]['temperature_tolerance_k'])
    err=abs(F(p['total_internal_energy_j'])-F(state['internal_energy_j']))+F(p['energy_error_j'])
    assert err<=F(pair['inverse_policies'][i]['energy_tolerance_j'])
    for domain in (st['temperature_domain_k'],st['fluid_template']['envelope']['temperature_range_k']):assert F(domain[0])<=t-eps<=t+eps<=F(domain[1])
    rows.append({'cell':i,'liquid_exact_mol':str(nl),'phase_exact_mol_s':str(phase),'tangent_exact_s':None if expected is None else str(expected),'tangent_s':None if expected is None else float(expected),'temperature_k':m['temperature_k'],'pressure_pa':m['pressure_pa'],'target_U_j':inv['target_energy_j'],'inverse_epsilon_k':float(eps),'public_native_mass_ratio':str(F(mp)/F(mn))})
result={'status':'PASS','freeze_sha256':sha(C/'EXECUTION_FREEZE.json'),'source_files':254,'installed_modules':104,'summary_sha256':sha(O/'summary.json'),'rates_sha256':sha(O/'rates.json'),'initial_forward_attempted':2,'initial_forward_completed':2,'host_attempted':1,'host_completed':1,'whole_elapsed_seconds':s['elapsed_seconds'],'external_elapsed_seconds':watch['elapsed_seconds'],'cells':rows,'energy_checks':energy,'review_native_calls':0,'qualification':'Saved exact arithmetic and bound current observation only; no new pressure proof, event/root order/controller/material admission. Small inventories below original amount gate and conditional U/Cp/v remain explicit.'}
with (R/'review_saved01.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
