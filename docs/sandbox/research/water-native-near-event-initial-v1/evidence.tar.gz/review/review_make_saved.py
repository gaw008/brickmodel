from pathlib import Path
old=Path('/private/tmp/brick-water-pressure-interval-v1/native_stage_study/review_saved_native.py').read_text()
head=old[:old.index('def audit_query')].replace("R=Path(__file__).parent;O=R/'attempt01'","R=Path(__file__).parent;C=R.with_name('native_near_event_initial_study');O=C/'attempt01'")
energy=old[old.index('def fraction_saved'):old.index("s=read(O/'summary.json')")].replace('len(reports)==18','len(reports)==2')
body='''s=read(O/'summary.json');freeze=read(C/'EXECUTION_FREEZE.json');watch=read(C/'supervisor-result01.json')
assert s['freeze']==freeze and s['source_after']==freeze['files']=={p:sha(Path(p)) for p in freeze['files']}
assert len(freeze['files'])==254 and freeze['installed_python_module_count']==104
members={d:sorted(str(p) for p in Path(d).rglob(pattern) if p.is_file()) for d,pattern in freeze['directory_patterns'].items()}
assert members==freeze['directory_members']==s['directory_members_after']
assert s['status']=='observation_completed' and s['inputs_unchanged'] and s['membership_unchanged']
assert not s['scientific_admission'] and not s['event_admission'] and not s['global_commit'] and s['native_internal_call_count'] is None
assert s['host_attempted']==s['host_completed']==1
assert watch['returncode']==0 and not watch['external_timeout'] and watch['runner_unchanged']
assert watch['runner_sha256']==sha(C/'run.py') and watch['freeze_sha256']==sha(C/'EXECUTION_FREEZE.json') and watch['supervisor_sha256']==sha(C/'supervise.py')
assert s['elapsed_seconds']<40 and watch['elapsed_seconds']<watch['external_limit_seconds']==50
case=read(C/'CASE.json');h=O/'initial';initial=read(h/'initial.json');pair=read(h/'pair-inputs.json');rates=read(O/'rates.json');status=read(h/'operation-status.json')
assert status['status']=='completed_initial_energy_construction' and status['elapsed_seconds']<30
assert status['costs']=={'initial_forward_attempted':2,'initial_forward_completed':2,'host_attempted':0,'host_completed':0,'native_internal_call_count':None}
assert read(O/'observation-input.json')==initial and pair['interface_modes'] is None
source_case=read(Path(case['source_case']));derived=read(h/'case.json');original=read(h/'original-case.json')
assert original==source_case
for i,T in enumerate(case['initial_temperature_design_k']):
    p=read(h/f'initial-forward-{i}.json');prototype=read(h/f'initial-prototype-{i}.json');state=initial[i]
    assert p['fluid']['mechanical']['temperature_k']==T and state['internal_energy_j']==p['total_internal_energy_j']
    assert all(state[k]==prototype[k] for k in ('solid_mass_kg','liquid_water_mol','gas_amounts_mol','energy_model_identity'))
    assert state['liquid_water_mol'].hex()==case['liquid_inventory_hex'][i]
    assert 0<state['liquid_water_mol']<case['stage_policy']['amount_absolute_mol']
    assert state['solid_mass_kg']==source_case['initial_cells'][i]['solid_mass_kg'] and state['gas_amounts_mol']==source_case['initial_cells'][i]['gas_amounts_mol']
    derived['initial_cells'][i]['liquid_water_mol']=source_case['initial_cells'][i]['liquid_water_mol']
derived['initial_temperatures_k']=source_case['initial_temperatures_k'];assert derived==source_case
energy=check_all_sample_energy({'samples':[{'state':initial,'rates':rates,'role':'one_actual_observation'}]},pair)
diagnostics=read(O/'diagnostics.json');assert diagnostics==s['diagnostics'];rows=[]
for i,(state,rate,diag) in enumerate(zip(initial,rates['cells'],diagnostics,strict=True)):
    nl=F(state['liquid_water_mol']);phase=F(rate['phase_water_mol_s']);expected=nl/phase if phase>0 else None
    assert diag['liquid_mol']==nl and diag['phase_rate_mol_s']==phase and diag['tangent_seconds']==expected
    assert diag['tangent_qualification']=='diagnostic_only_not_root_order_or_event_permission'
    st=pair['storages'][i];inv=rate['inverse'];p=inv['point'];m=p['fluid']['mechanical'];liquid=rate['equilibrium']['liquid']['state'];water=st['fluid_template']['mechanical']['water']
    assert water==pair['chemical']['water'] and liquid['implementation']==water['implementation']
    assert liquid['phase']=='liquid' and liquid['method_id']=='iapws95_real_fluid_helmholtz'
    assert liquid['temperature_k']==m['temperature_k'] and liquid['pressure_pa']==m['pressure_pa']==m['liquid_pressure_pa']
    descriptor=json.loads(liquid['implementation']['canonical_descriptor'])['real_fluid'];mp=float.fromhex(descriptor['public_mass_hex']);mn=float.fromhex(descriptor['native_mass_hex'])
    assert descriptor['runtime']['fluid_sha256']==sha(Path(freeze['coefficient_json'])) and mp==liquid['reference']['molar_mass_kg_mol']
    assert m['liquid_volume_m3']==(state['liquid_water_mol']*mp)/liquid['density_kg_m3']
    lo,hi=map(F,inv['final_temperature_bracket_k']);t=F(m['temperature_k']);eps=F(inv['temperature_error_bound_k'])
    assert lo<=t-eps<=t+eps<=hi
    assert F(inv['temperature_error_bound_k'])<=F(pair['inverse_policies'][i]['temperature_tolerance_k'])
    err=abs(F(p['total_internal_energy_j'])-F(state['internal_energy_j']))+F(p['energy_error_j'])
    assert err<=F(pair['inverse_policies'][i]['energy_tolerance_j'])
    for domain in (st['temperature_domain_k'],st['fluid_template']['envelope']['temperature_range_k']):assert F(domain[0])<=t-eps<=t+eps<=F(domain[1])
    rows.append({'cell':i,'liquid_exact_mol':str(nl),'phase_exact_mol_s':str(phase),'tangent_exact_s':None if expected is None else str(expected),'tangent_s':None if expected is None else float(expected),'temperature_k':m['temperature_k'],'pressure_pa':m['pressure_pa'],'target_U_j':inv['target_energy_j'],'inverse_epsilon_k':float(eps),'public_native_mass_ratio':str(F(mp)/F(mn))})
result={'status':'PASS','freeze_sha256':sha(C/'EXECUTION_FREEZE.json'),'source_files':254,'installed_modules':104,'summary_sha256':sha(O/'summary.json'),'rates_sha256':sha(O/'rates.json'),'initial_forward_attempted':2,'initial_forward_completed':2,'host_attempted':1,'host_completed':1,'whole_elapsed_seconds':s['elapsed_seconds'],'external_elapsed_seconds':watch['elapsed_seconds'],'cells':rows,'energy_checks':energy,'review_native_calls':0,'qualification':'Saved exact arithmetic and bound current observation only; no new pressure proof, event/root order/controller/material admission. Small inventories below original amount gate and conditional U/Cp/v remain explicit.'}
with (R/'review_saved01.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
'''
Path(__file__).with_name('review_saved.py').write_text(head+energy+body)
