# Low-moisture excess leaf: implementation handoff

Only the three authorized files were created and then migrated to the repository. No EOS, installation, native trajectory, network, commit, old source-fact change or other worker-file edit occurred.

## API and numerical meaning

`ArlabosseLowMoisture(wet)` requires the exact existing `ArlabosseWetThermodynamics` class and uses its `repository_root`. `evaluate(T,W)` accepts finite int/float/Fraction/Decimal values; booleans and strings are rejected. Domain endpoints are the same represented binary64 source values (308.15–368.15 K, 0–.8); exact rational input W is retained. There is no pressure/EOS calculation in this leaf.

`LowMoistureExcessPoint` has Fraction `temperature_k`, `moisture_kg_water_per_kg_dry`, `h_ex_j_kg_dry`, `s_ex_j_kg_dry_k` and `f_ex_j_kg_dry`. No dry mass is included. The host must multiply excess primitives by its exact dry mass. `h_ex` uses exact represented-node algebra over the whole domain. At positive W<.15, `s_ex`/`f_ex` use exact algebra **conditional on the nominal log/log1p result**; no transcendental error bound or physical precision is implied. At W=0 the xlogx term uses its analytical zero limit and h0/s0 are retained. `f=h-T*s` is exact nominal algebra; excess Cp and volume are zero.

`mu_ex_j_mol` and `partial_h_ex_j_mol` already contain M; the host must not multiply by M again. `gamma_left_j_mol`/`gamma_right_j_mol` are molar derivatives with respect to dry-basis W, and retain the distinct low/source sides at .15. The upper endpoint has no right derivative. On the low branch Gamma=RT/W. Molar logarithms use the same actual R and M, while old wet-source m nodes remain their original represented values; small differences from the former float interpolation/Rs path are explicitly documented readout differences.

At W=0, activity=0, mu is null with `minus_infinity_at_zero_inventory`, and both Gamma values are null with `positive_infinite_boundary_limit`. Positive W whose required nominal finite values underflow/overflow is rejected instead of reported dry. No epsilon substitution, dry-reference shift or disappearance of stored excess occurs.

`binding()`, `definition()` and `source_ids` check the pinned low-model, actual upstream facts/wet metadata/wet Python source bytes, the original wet public source checks, and a snapshot of actual represented curves, reference values and water definition. Definitions and JSON point records are fresh; Fraction records use numerator/denominator strings. The .10 activity observation remains held out and is not queried for fitting. Low-W constant q/no hysteresis/zero excess volume/temperature extension remain explicit choices with unknown errors and false qualification.

## Evidence

- `RED01.log/xml`: tests were written first; collection failed because the new module did not exist. This is an implementation-missing RED, not a claim of a pre-existing material or numerical defect.
- `GREEN01.log/xml`: first implemented leaf, 38 manufactured tests passed in 0.26 s.
- `GREEN02.log/xml`: three additional bounded analytic/node/classification checks, 41 passed in 0.28 s.
- `MIGRATED_GREEN01.log/xml`: actual formal repository modules, 41 passed in 0.33 s.
- `DRY_OFFSET_NEGATIVE_CONTROL01.log/xml`: process-local deliberately wrong zero-reference replacement; the dry-energy test actually failed (1 failure, 0.06 s). Production files were untouched. This separately demonstrates that the behavior test catches deletion of the dry excess constant.
- AST parsing passed for module and test. Ruff/mypy/black/pylint are unavailable in the selected runtime; no substitute lint approval is claimed.

All water/source behavior in these tests is explicitly manufactured through existing test seams while retaining the actual wet class. No result here establishes a real-material trajectory or validates the whole host. The root worker owns storage/phase/outlet integration and independent review.

Frozen SHA and size are in `MIGRATED_SHA01.json`. Module: `b49f8246a01e119dfe3c865113b2d2cb7d98a963ba8186ac25783797d1801095` (12,155 bytes); tests: `7c679302efdd4cc35eb69dbb302e9349e8b1dc5b5fdc99c9c2ec965ad4ec3a6e`; model: `906f2a8a7b1d97c30f38edd51d019f874b14c9caf178b7aeb0f3797adb7b4a3f`.
