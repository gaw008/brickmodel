# Low-moisture transport implementation handoff

Owned and migrated only `src/sludge_sandbox/low_moisture_transport.py`, its matching test, and `data/sandbox/research/arlabosse-low-moisture-transport-v1/model.json`. No installation, commit, EOS, native trajectory, network or other author's file edit. Actual registered donor files are only read and verified through the existing providers.

## API

- `LowMoistureConductivity(original: SeptienConductivity)` has `binding()`, `definition()`, `source_ids`, `evaluate(T,W)`. Returned `LowMoistureConductivityPoint` retains exact T/W, compatible `k_w_m_k` and exact nominal k/projection error, original source evaluation, new identity and branch. Below .30 it explicitly evaluates the original .30 endpoint and uses that constant; original source domain is unchanged. Measurement T and total extrapolation errors remain unknown.
- `LowMoistureTransport(original: MakelaMoistureTransport)` has the same identity/definition/source methods and `factor(storage,left,right)`. Original D=8.56e-9 is reverified, and its new lower-W use is a separately identified assumption.
- `low_moisture_water_point(storage,chemical,state,inverse,phase)` returns `LowMoistureWaterPoint` only after exact actual-class/source/inventory/inverse/phase-reference correspondence. Full h is pure liquid h plus the already-molar sorption partial h; full mu is analogous at positive W, null at zero. The pure-liquid dry reference is explicitly hypothetical. No second EOS point is requested.
- `exchange(storages,points,*,area_m2,widths_m,geometry_sources,chemical,states,inverses,phases)` checks the complete runtime pair, reconstructs both water points and compares them, and creates total-slab geometry from actual dry masses. It returns `LowMoistureTransportWitness(points,factor,exchange,storage_identities,inverses,phases,source_state_binding_verified=True)`.
- Exchange retains shared `molar_flow_mol_s`, `carried_energy_w`, `exact_molar_flow_mol_s`, `exact_carried_energy_w`, `source_ids`, nominal entropy, actual rounded-rate entropy, projection records, drive/readout difference and complete input provenance. It adds neither conduction nor latent heat.

## Numerical and physical scope

For two positive low-W points the canonical log ratio and logarithmic mean produce `n=K*(DeltaW+Llog*C/R)`. Canonical orientation preserves exact nominal reversal. Same-W uses the analytical logmean limit. Cross/source intervals use a full excess-mu secant at exact arithmetic face T; every traversed source segment and every same-knot side must be positive. The join uses an explicit low/source one-sided mean. A positive global secant cannot hide a zero/negative source segment.

One dry side gives finite analytical `n=K*DeltaW` and `H=hface*n`, with entropy null and `positive_infinite_boundary_limit`. Two dry sides have `no_exchange_double_dry`; no finite chemical potential or unique two-variable entropy limit is claimed. Required nonzero float rates cannot silently underflow. Positive-W actual rounded n/H entropy must remain nonnegative and resolved. Exact algebra of nominal logarithms is distinguished from the unquantified logarithm and physical model errors.

Geometry positivity is enforced by the existing `MoistureFaceGeometry.__post_init__` at lines 105–110 for area, center distance, both dry masses and both total volumes. Public `exchange` constructs a fresh geometry, independently of Column prechecks, and checks equal exact dry density. Root's subsequent concern about missing public positivity did not reproduce; no production change or artificial RED was made.

## Actual evidence

- `RED01.*`: tests preceded implementation; collection failed because the module did not yet exist. This is not a historical material-defect claim.
- `GREEN01.*`: 13 pass, 1 failed test calibration. The proposed 1e-310 W case still had representable nonzero rates, so expecting underflow was wrong; preserved as-is.
- `GREEN02.*`: 20 pass, 4.58 s. The corrected 1e-320 W test actually enters rate underflow. Includes analytic Fick, swap, true zero, nonisothermal entropy, reference shift, source segment/join positivity, exact face T, runtime mismatch, constant k extension and domains.
- `MIGRATED_GREEN01.*`: the same 20 necessary tests passed against formal files, 4.76 s.
- `GEOMETRY_PUBLIC_GREEN01.*`: root-requested single-dry public area/distance/volume zero/negative cases, 6 pass with 20 deselected, 4.32 s. Exact named positive-geometry rejections were observed, with no new production fix.
- AST parsing passed for module/test; selected runtime has no Ruff/mypy/black/pylint, as recorded in the previous leaf handoff.

Runtime tests use existing actual classes and registered sources with explicitly manufactured water callbacks, without native EOS or trajectory runs. Private face probes are manufactured inputs and carry no source-state authentication. Neither the tests nor the runtime witness qualifies this donor combination as actual brick material or verifies the complete firing cycle.

Production and model bytes remained unchanged after migration. Final hashes, including the six requested boundary tests, are in `FINAL_SHA02.json`; the earlier `MIGRATED_SHA01.json` and every test log are preserved. Root owns Column integration and independent review/native evidence.
