# 低 W 至干极限：有条件 APPROVE 的三页设计

**可以先实施这一显式虚拟延拓**，无需把未知实验总误差当作禁令。它由同源接点约束，能给连续能量、有限干端储能和可逆排湿/再润湿路线；它没有取得低 W 热量、输运或现实砖坯验证。以下推导不运行 EOS，不重新读取/渲染原图，不改变原事实。

## 1 / 3　接点、解析自由能及干参考

令固定干质量为 $m_d$，唯一凝聚水库存为 $N_c$，$W=MN_c/m_d$，$M$ 为现有水摩尔质量，$R_s=R/M$，$T_0=368.15\,K$，$W_j=0.15$。全部小写 excess 量按 kg 干物质计；其 W 偏导按 kg 水计。取**现有同一 wet 模型**在接点的 $m_j=m_0(W_j)$、$b_j=L_0-q_0(W_j)$、$h_j=h_{ex,0}(W_j)$、$s_j=[h_j-g_{ex,0}(W_j)]/T_0$，并令 $c_j=(b_j-m_j)/T_0$。旧模型给

$$\mu_j(T)=b_j-Tc_j,\qquad f_j(T)=h_j-Ts_j.$$

对 $0<W<W_j$，定义 $\psi(W)=W\ln(W/W_j)-W+W_j$：

$$f_{ex}=f_j+\mu_j(W-W_j)+R_sT\psi,$$
$$h_{ex}=h_j+b_j(W-W_j),\quad s_{ex}=s_j+c_j(W-W_j)-R_s\psi.$$

于是 $\partial_W f_{ex}=\mu_j+R_sT\ln(W/W_j)$，$\partial_W h_{ex}=b_j$，$f_{ex}=h_{ex}-Ts_{ex}$，固定 W 的 $C_{p,ex}=0$。沿用刚性宿主的零 excess 体积假设时，这个 excess 也可作为 Helmholtz 项，$U_{ex}=m_dh_{ex}$、$S_{ex}=m_ds_{ex}$，不改变机械压力或固定库存热容。定压总 $C_p=C_{p,dry}+W C_{p,liquid}$ 趋于干基 Cp；刚性宿主干端仍包含实际气体热容。

在 $W_j$，$f,h,s$ 及其 W 一阶导连续；$\mu$ 连续但其 W 导数一般跳变。由 $W\ln W\to0$ 得到真正解析端点：

$$h_0=h_j-b_jW_j,\quad s_0=s_j-c_jW_j-R_sW_j,\quad f_0=h_0-Ts_0.$$

**一般 $h_0,s_0\ne0$。** 最小兼容接法是始终保留 $U_{dry\ endpoint}=U_{base}+m_dh_0$ 及 $S_{base}+m_ds_0$；不能到零就删除 excess 而跳回 base dry U。也可全域统一减去 $h_0,s_0$，但必须给新模型身份并同步平移已有 U 状态/反解目标。它是固定 $m_d$ 的参考变换，不是形成焓；将来干质量发生反应时必须重新核对反应参考。现有 base 干 Cp 的温度参考与 wet 的 $T_0$ 参考偏移也继续单列。

**真实来源可约束到哪里：** `arlabosse95/facts.json` 的 Fig.1 已读曲线在 W=.10 为 $1365/3743\approx.364681$，读图界 [.342169,.387019]；W=.15 为 $1941/3743\approx.518568$，界 [.510843,.526442]。候选在 95°C 预测 $a(.10)=\frac23a(.15)=.345712$，接点界传播 [.340562,.350962] 与 .10 的读图界相交。`.10` 未进入现有 wet 的 `_W_NODES`，可保留为**不用于定参的曲线留出约束**；两点来自同一曲线/校准，不能称独立实验或统计验证。Fig.2 的 .10 热量仍 unknown（网格遮挡），最低完整热节点 .15 为 2,647,301.587 J/kg 脱除水；低 W 的恒定 $q_0=q_j$ 是新假设，不能写回原 facts。未取得 W<.10 的已审读节点或低 W 多温数据。

## 2 / 3　Γ、D/k 以及零库存的可计算含义

低 W 的 $a(T,W)=a_j(T)W/W_j$；同一实际 T/P 标准态下，$q(T,P,W)=L(T,P)-b_j$，95°C、原参考压力处回到 $q_j$。它保留热量接点而没有测得“更干时热量不再上升”。

$$\Gamma(T,W)=M\partial_W\mu_{ex}=RT/W>0.$$

$\Gamma(W_j^-)=RT/W_j$ 通常不等于旧段 $\Gamma(W_j^+)$；不得报告 Γ 光滑。跨接点面用完整新 $\mu_{ex}(T_f,W)$ 的正割，检查每个穿过的分段正值；同 W 接点保留显式正的一侧均值数值约定。局部迁移率随 Γ 跳变允许作为分段模型，但需在积分中控制误差。

Mäkelä D 可在新分支继续取已登记 8.56e−9 m²/s，**把 W<.30 的冻结也声明为新延拓**。Septien 现有 k 域只有 [.30,.80]；最少新形状假设是低于 .30 时保持 $k=k_{existing}(.30)$，在 .30 连续、斜率有折角。这应是有独立身份/出处的显式常值延拓，不能以“输入裁剪”偷偷改变旧 provider。无同泥低 W D/k 数据、D 跨温误差及 k 测量温度仍 unknown；本提议没有测得干导热率。

对于两端均在低 W 区的面，令 $K=A\rho_dD/(M\ell)$，$\mathcal L=(W_L-W_R)/(\ln W_L-\ln W_R)$（同值时等于 W），$\bar h$ 为现有两侧**完整摩尔偏焓**的均值。将 $\mu/T=R\ln W+c(T,P)$，$X_T=1/T_R-1/T_L$ 代入现有熵相容闭合，有

$$n=K\{W_L-W_R+\mathcal L[c_L-c_R+\bar h X_T]/R\},\qquad H=\bar h n.$$

这与 $n=L_mY$、$L_m=T_fA\rho_dD/(M\ell\Gamma)$ 等价，可避免直接做“零迁移率×无穷驱动力”。因此一端 $W\to0$、另一端正值时，$\mathcal L\to0$，$n\to K(W_L-W_R)$，携焓也有限；同 T/P 恰为 Fick。跨接点单干端也有这个主导对数极限。双零定义无库存交换 $n=H=0$。

但是单干端的**瞬时** $L_mY^2$ 一般趋于 $+\infty$，不能伪造有限熵产生；双零的两变量熵极限甚至依赖趋近路径。用明确的 `minus_infinity_at_zero_inventory` / `positive_infinite_boundary_limit` / `no_exchange` 状态表达，不向当前有限 Fraction 点结构塞 `inf`/NaN，不以 ε 代替零。沿瞬间再润湿轨迹可有有限累积自由能变化；这个结论也不是现有 midpoint 步进的熵单调证明。

干端凝聚相纯水参考只能是实际干态 T/P 下的**假想无限稀释标准态**，不等于仍有一份液水。需单独标记、核对旧水 EOS 的液态参考适用域；机械液量/体积保持零。当前 `existing_liquid` 正库存检查、`depleted_no_nucleation` 分支和有限 μ 点结构不能直接复用为可再润湿干态。

## 3 / 3　实际排湿、渐近干燥与最小实现

现有局部速率 $r_{ph}=K_{ph}(p_{eq}-p_v)$（正为蒸发），低 W 时 $p_{eq}=p^0_{eq}(T,P)a_j(T)W/W_j$。固定 T/P、$p_v=0$ 时，$\dot W=-\lambda W$；有限系数下只能指数趋零，没有有限耗尽事件。$p_v>0$ 时有正残余平衡含水量。W=0、$p_v>0$ 时解析速率是 $r_{ph}=-K_{ph}p_v$，允许向**同一** $N_c$ 再润湿；这新增“无吸附成核屏障/无滞回”的显式模型选择。$p_v=p_{eq}=0$ 时净速率零，不调用 `ideal_vapor(T,0)` 计算化学势。相变熵在单侧零处同样可能有奇异极限。

当前 Column 的两个 `closed_no_flux` 边界不排出总水。最小真正排湿接法是在外表面增加显式受控蒸气出口，局部相变仍只负责 $N_c\leftrightarrow N_v$：

$$\dot N_c|_{ph}=-r_{ph},\quad\dot N_v|_{ph,out}=r_{ph}-n_{out},$$
$$\dot U|_{out}=Q_{ext}-n_{out}h_v\quad(n_{out}>0).$$

出口通过实际气相库存抽走水，不再直接扣一次 $N_c$；入流取环境蒸气携焓。出口系数、环境分压/温度、换热必须是显式控制输入，不从原总干燥 D 猜出，也不偷偷复用局部相变系数。第一有限验证可令出口环境与表面同温，采用正系数 $n_{out}=K_v(p_v-p_{v,env})$，以免加入未经核对的非等温边界交叉效应；正分压时其物质交换熵非负。零环境分压须明示理想真空的熵奇异性。总账验证 $\Delta(N_c+N_v)=-\int n_{out}dt$、$\Delta U=\int(Q_{ext}-H_{out})dt$ 加原数值投影；无需再加潜热源。真实非等温环境边界是后续独立闭合。

**最小实现顺序：** ①新低 W excess provider，0 的解析储能/原反解门和参考偏移；②新版本低 W D/k 与正库存对数面核，显式零面极限和可逆相变接口；③上述受控蒸气出口，做跨 .30/.15/.10 的含水量变化、U 反解与进出水/携焓闭合。初始严格干态的静态/再润湿检查与正 W 趋近零检查分开；不以小阈值删水或转换模式。正库存跨步至负值要拒绝/缩步或使用保正积分，不能裁剪。报告低 W 残余量，不能把数值分辨率耗尽写成物理耗尽。

干端还须维持温压域：$N_c\to0,N_v\to0$ 时 $P\to N_{inert}RT/V_{available}$。原两格 native 的几何/惰性量不自动满足原 90–110 kPa 界，不能原样延时假定可到干端。应显式选择可行的受控库存/几何/边界并记录压力解，或如实终止于域外；不得覆写压力。35–95°C 域和无反应干 Cp 也不会因这次延拓自动扩大。

实现层面保持一个 R/M 定义（建议对数增量直接用摩尔 $RT\ln(W/W_j)$），区分旧 binary64 接点舍入和精确热力学恒等；`xlogx(0)=0` 解析分支、近接点 `log1p`、下溢拒绝/显式极限记录都应有行为测试。现实资格仍需要同材料低 W 多温吸附/脱附及滞回、低 W 热量/Cp、D/k 与收缩/孔容、已知气氛下完整失水曲线和留出验证。现有 .10 曲线留出能约束近接点形状，不能约束这些缺项；未知误差不妨碍先做上述清楚标识的可计算探索。

来源定位：`data/sandbox/research/arlabosse95/facts.json`（Fig.1/2 observations；SHA256 543d55918db7df6d0cc0f695c5dceadbdebda82b83f4fdde206266bcd12f2f16，DOI 10.1590/S0104-66322005000200009）；`arlabosse_wet_thermo.py` 的 `_W_NODES/_Q_NODES/_excess/_evaluate`；`arlabosse_rigid_sorption.py` 的 `_moisture/evaluate/provenance`；`arlabosse_sorption_phase.py` 的 `evaluate_sorption_phase`；`source_sorption_moisture.py` 的 `factor/exchange`；`source_wet_column.py` 的边界与共享账；Septien/Mäkelä 的现有 `model.json`。本次只读已取得事实与代码，唯一计算为以上读图数值的分数四则核对；原件未重下载，未做 EOS/积分/新拟合。读取版本另见 READ_SNAPSHOT.json。
