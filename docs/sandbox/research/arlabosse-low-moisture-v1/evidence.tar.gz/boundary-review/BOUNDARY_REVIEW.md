# Controlled vapor boundary：有限独立物理/数学审查

**APPROVE，仅限明确受控的选择性蒸气接触与独立热浴。** 未发现 CRITICAL/HIGH/MEDIUM 待修问题。未批准完整窑炉环境、实际材料能力或后续长程/收敛成果。

已读版本：controlled_vapor_column.py SHA256 94dc6597eed247cafe52c31273a88461109d0fabfe9e0c5c734259c8cdea9a94；source_wet_column.py SHA256 c7170fa4b7b2984db08121562979e97260d851dffdd3b81606d34ceb28cf4702。其他读取文件见 READ_SNAPSHOT.json。

## 方程与参考

1. 外表面右边界的 gas[2]=nout，能量 face=Hout−Qin，所以共享 `_advance` 得到 dNv=rphase−nout、dNc=−rphase（再加内部凝聚水通量）、dU=Qin−Hout。气体顺序的第三项 H2O 由 SourceWetStorage.binding 显式固定为 O2/N2/H2O。边界不再次扣 Nc，也不再加潜热；源储能 U 已有局部相变/吸附能量。
2. n_exact=Kv(pv−pe)，Kv≥0；外部无限选择性理想储槽始终与该外格同温。两个方向均取现有共同理想蒸气 h_v(Tcell)，无需查询 ideal_vapor(T,0)。这只定义接口处瞬时交换；随温无限储槽和热浴所需的外部控制装置能耗不在砖坯账内，也没有宣称全环境封闭守恒。
3. 两侧正分压且有交换时，实际投影 n 的瞬时蒸气熵产生为 R n ln(pv/pe)>0。接近等压用 log1p；n=0（含 Kv=0、等压、双零）记录 no_exchange。单零且 n≠0 记录明确的 positive_infinite_vacuum_limit，数值为 None；这没有把无限极限冒充有限误差。双零 no_exchange 是该确切状态的无交换约定，不是任意双变量趋近路径的连续熵极限证明。
4. 独立热浴 Qin=G(Tbath−Tcell) 及实际投影热流的 Qin(1/Tcell−1/Tbath)≥0；加热、冷却与等温/禁用都正确。储槽温度取 Tcell，热浴温度另取 Tbath，两者不是同一个外界温度，provenance 已明确。
5. 共同水能量参考平移 C 时，n、压力与两个熵产生不变，精确携焓变化为 C*n_exact。**Hout 不要求正值**：已选择的水焓参考可以为负；它与按相同参考变化的水库存储能一起才能判断温度变化。不得把 nout>0 与 Hout>0 混为验收门。

## 实际投影与共享账

生产边界对 n_exact、n_exact*h_v、Qin_exact 各自做一次 float 投影。实际 Hfloat 未必恰等于 nfloat*h_v，故账本分开保留水量/携焓/热流投影与总能量分解残差；这是正确的分层数值约定，不是可以丢弃的差异。参考平移的离散残差满足

`ΔJenergy − C*Jwater = ΔδHv − C*δN + Δδdecomposition`

（同热浴项相消），本次直接用 Fraction 核验两个流向。`_integrals` 采用真正 middle rate；ControlledVaporLedger 另保留 middle rates/见证。`integrate_source_column` 把 predictor+accepted 的边界水量投影加入库存预算，把两项能量投影加入原能量预算，原单格/全局舍入账继续由 `_advance` 生成。预算只含这些投影/分解算术，未变成时间截断、反解传播或边界 log 误差的总证书。

## 独立证据及范围

实际读取作者 BOUNDARY_TESTS01.log 的 4 passed/26.42 s，未重跑或把它记为本次执行。本次新增 **14 项通过，0.15 s**（INDEPENDENT01.log/xml、test_boundary_independent.py）：

- 外排、回流、单零真空、双零、等压、禁用接触、近等压正熵。
- 独立热浴加热/冷却/等温，外排水在负焓参考下 Hout<0。
- 实际边界 rate → 共享 `_integrals` → `_advance`，逐项核验 Nc/Nv/U、惰性库存、3 类边界投影和总分解残差。
- 两个流向的精确焓参考平移与完整实际投影协变。

探针保留真实 ControlledVaporColumn 与共享积分/更新函数，但其 closed host、温度、分压、气体焓和 state factory 均明确制造，并将实际 WaterProperties 构造/solve/状态/理想蒸气与 WaterChemicalPotential 构造/平衡/ideal_vapor 入口设 forbidden。这是边界与账本代数审查，不是实际低 W 宿主或源轨迹验证；无 EOS、安装、下载、生产修改。AST 解析通过；未提供 ruff/mypy/pylint/black，不宣称它们已运行。

剩余原有范围：控制 Kv/G/pe/Tbath 是虚拟输入，只有水蒸气可通过，尚无完整对流/辐射/惰性气交换；zero 与极小正库存仍由已批准的相变/输运极限接口处理。边界输出不能绕过共享库存非负、温压域、反解及数值预算门。
