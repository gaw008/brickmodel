"""Boundary and shared-ledger algebra with an explicitly manufactured closed host.

No real provider construction, EOS, source trajectory or installation occurs.
The actual ControlledVaporColumn and shared integral/advance functions run.
"""
from dataclasses import replace
from fractions import Fraction as F
import math
from types import SimpleNamespace as NS

import pytest

from sludge_sandbox.controlled_vapor_column import ControlledVaporColumn, VaporBoundaryControl
from sludge_sandbox.deforming_solid_storage import _digest
from sludge_sandbox.source_wet_column import (
    ColumnFaceRate, LowMoistureSorptionColumn, SourceColumnRates, _integrals, _advance,
)
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential


R=8.31446261815324


class ManufacturedStorage:
    gas_ids=('O2','N2','H2O')

    def state(self,nc,gas,u):
        return NS(liquid_water_mol=nc,gas_amounts_mol=gas,internal_energy_j=u)


@pytest.fixture
def make(monkeypatch):
    def forbidden(*args,**kwargs):
        raise AssertionError('boundary_review_forbids_real_EOS')
    for name in ('__init__','_solve','state_tp','state_tp_response','saturation_pair','ideal_vapor'):
        monkeypatch.setattr(WaterProperties,name,forbidden)
    for name in ('__init__','ideal_vapor','equilibrium_at_liquid_tp'):
        monkeypatch.setattr(WaterChemicalPotential,name,forbidden)

    def identity(base):
        return _digest(('manufactured-boundary-review',base.review_parameters))

    def closed(base,states):
        t,pv,hv,phase=base.review_parameters
        cell=NS(inverse=NS(point=NS(temperature_k=t)),
                phase=NS(water_partial_pressure_pa=pv,phase_water_mol_s=phase))
        zero=(0.,0.,0.)
        faces=tuple(ColumnFaceRate(i,None if i==0 else 0,0 if i==0 else None,
            zero,0.,0.,zero,zero,None) for i in range(2))
        return SourceColumnRates(cells=(cell,),gas_states=(),faces=faces,
            model_identity=identity(base),source_ids=('manufactured:closed-boundary-review',))

    monkeypatch.setattr(LowMoistureSorptionColumn,'model_identity',property(identity))
    monkeypatch.setattr(LowMoistureSorptionColumn,'evaluate',closed)

    def construct(*,pv,pe,coefficient=1e-7,t=330.,hv=-240000.2,phase=0.,bath=330.,g=0.):
        base=object.__new__(LowMoistureSorptionColumn)
        for name,value in {'storages':(ManufacturedStorage(),),
                'interface_modes':('reversible_sorption',),
                'review_parameters':(t,pv,hv,phase),
                'chemical':NS(gas_constant_j_mol_k=R,
                    vapor=NS(enthalpy_j_mol=lambda actual_t: hv if actual_t==t else forbidden()))}.items():
            object.__setattr__(base,name,value)
        control=VaporBoundaryControl(pe,coefficient,bath,g,('virtual:boundary-review-controls',))
        return ControlledVaporColumn(base,control)
    return construct


@pytest.mark.parametrize('pv,pe,coefficient,state,sign',[
    (1200.,300.,1e-7,'finite',1),
    (300.,1200.,1e-7,'finite',-1),
    (1200.,0.,1e-7,'positive_infinite_vacuum_limit',1),
    (0.,1200.,1e-7,'positive_infinite_vacuum_limit',-1),
    (0.,0.,1e-7,'no_exchange',0),
    (300.,300.,1e-7,'no_exchange',0),
    (300.,1200.,0.,'no_exchange',0),
])
def test_all_zero_incoming_outgoing_and_disabled_contact_cases(make,pv,pe,coefficient,state,sign):
    column=make(pv=pv,pe=pe,coefficient=coefficient)
    rates=column.evaluate(())
    b=rates.boundary; face=rates.faces[-1]
    assert b.cell_temperature_k==b.reservoir_temperature_k==330.
    assert b.vapor_entropy_state==state
    assert (b.outward_water_mol_s>0)-(b.outward_water_mol_s<0)==sign
    assert face.gas_mol_s[:2]==(0.,0.)
    assert face.exact_water_mol_s==F(coefficient)*(F(pv)-F(pe))
    assert face.exact_carried_energy_w==face.exact_water_mol_s*F(b.common_vapor_enthalpy_j_mol)
    if state=='finite':
        expected=F(b.outward_water_mol_s)*F(R)*F(math.log(pv/pe))
        assert b.vapor_entropy_w_k==pytest.approx(float(expected),rel=1e-14)
        assert b.vapor_entropy_w_k>0
    elif state=='no_exchange':
        assert b.vapor_entropy_w_k==0
    else:
        assert b.vapor_entropy_w_k is None
    # Outward moles do not imply positive referenced enthalpy.
    if sign:
        assert b.outward_water_mol_s*b.outward_carried_energy_w<0


@pytest.mark.parametrize('bath',[300.,330.,360.])
def test_heat_bath_direction_and_entropy_are_independent_of_vapor(make,bath):
    column=make(pv=300.,pe=300.,bath=bath,g=.003)
    rates=column.evaluate(()); b=rates.boundary
    q=F(.003)*(F(bath)-330)
    assert rates.faces[-1].exact_heat_into_cell_w==q
    assert rates.faces[-1].conduction_w==-b.heat_into_cell_w
    assert rates.faces[-1].energy_w==-b.heat_into_cell_w
    assert b.heat_entropy_w_k==float(F(b.heat_into_cell_w)*(F(1,330)-1/F(bath)))
    assert b.heat_entropy_w_k>=0


def test_actual_float_projections_and_shared_cell_updates_have_complete_ledgers(make):
    column=make(pv=30.1,pe=2.3,phase=.125,bath=339.1,g=.003)
    rates=column.evaluate(())
    dt=F(1,10)
    faces,phase=_integrals(rates,dt)
    face=faces[-1]; raw=rates.faces[-1]
    assert face.vapor_molar_projection_mol==dt*(F(raw.gas_mol_s[2])-raw.exact_water_mol_s)
    assert face.vapor_enthalpy_projection_j==dt*(F(raw.diffusive_enthalpy_w[2])-raw.exact_carried_energy_w)
    assert face.heat_projection_j==dt*(F(rates.boundary.heat_into_cell_w)-raw.exact_heat_into_cell_w)
    assert face.energy_j==face.conduction_j+sum(face.diffusive_enthalpy_j)+face.energy_decomposition_roundoff_j
    state=column.storages[0].state(1.,(1.,2.,5.),1000.)
    new,error=_advance(column,(state,),faces,phase)
    out=new[0]
    assert F(out.liquid_water_mol)-1==-phase[0]+error.liquid_mol[0]
    assert F(out.gas_amounts_mol[2])-5==phase[0]-face.gas_mol[2]+error.gas_mol[0][2]
    assert F(out.internal_energy_j)-1000==-face.energy_j+error.energy_j[0]
    assert (F(out.liquid_water_mol)+F(out.gas_amounts_mol[2])-6)==(
        -face.gas_mol[2]+error.liquid_mol[0]+error.gas_mol[0][2])
    assert out.gas_amounts_mol[:2]==state.gas_amounts_mol[:2]


@pytest.mark.parametrize('pv,pe',[(30.1,2.3),(2.3,30.1)])
def test_energy_reference_shift_covaries_with_exact_flow_and_projected_ledger(make,pv,pe):
    h0=-240000.2; shift=F(1001,8); h1=float(F(h0)+shift)
    assert F(h1)-F(h0)==shift
    a=make(pv=pv,pe=pe,hv=h0,bath=339.1,g=.003).evaluate(())
    b=make(pv=pv,pe=pe,hv=h1,bath=339.1,g=.003).evaluate(())
    fa,fb=a.faces[-1],b.faces[-1]
    assert fa.exact_water_mol_s==fb.exact_water_mol_s
    assert fb.exact_carried_energy_w-fa.exact_carried_energy_w==shift*fa.exact_water_mol_s
    assert a.boundary.outward_water_mol_s==b.boundary.outward_water_mol_s
    assert a.boundary.vapor_entropy_w_k==b.boundary.vapor_entropy_w_k
    assert a.boundary.heat_entropy_w_k==b.boundary.heat_entropy_w_k
    ia=_integrals(a,F(1,10))[0][-1]; ib=_integrals(b,F(1,10))[0][-1]
    discrepancy=ib.energy_j-ia.energy_j-shift*ia.gas_mol[2]
    explained=(ib.vapor_enthalpy_projection_j-ia.vapor_enthalpy_projection_j
        -shift*ia.vapor_molar_projection_mol
        +ib.energy_decomposition_roundoff_j-ia.energy_decomposition_roundoff_j)
    assert discrepancy==explained


def test_nearly_equal_positive_pressures_keep_positive_projected_entropy(make):
    pe=1000.; pv=math.nextafter(pe,math.inf)
    b=make(pv=pv,pe=pe,coefficient=1.).evaluate(()).boundary
    assert b.outward_water_mol_s>0 and b.vapor_entropy_w_k>0
    assert b.vapor_entropy_state=='finite'
