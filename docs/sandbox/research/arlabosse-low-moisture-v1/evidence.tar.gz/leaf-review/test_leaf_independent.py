"""Bounded independent algebra probes; existing manufactured seams, no EOS."""
from decimal import Decimal, localcontext
from fractions import Fraction as F
import json
import math
from pathlib import Path

import pytest

from test_arlabosse_wet_thermo import factory
from test_arlabosse_low_moisture import make
import sludge_sandbox.arlabosse_low_moisture as low
from sludge_sandbox.arlabosse_wet_thermo import T_MIN, T_REF, W_MIN, W_REF, _Linear
from sludge_sandbox.water_properties import WaterProperties


@pytest.fixture(autouse=True)
def forbid_real_eos(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError('independent_leaf_review_forbids_real_water_EOS')
    for name in ('__init__', '_solve', 'state_tp', 'state_tp_response',
                 'saturation_pair', 'ideal_vapor'):
        monkeypatch.setattr(WaterProperties, name, forbidden)


def spline_primitive(curve, w):
    """Independent truncated-power linear-spline primitive, not trapezoid code."""
    x, y = tuple(map(F, curve.x)), tuple(map(F, curve.y))
    slopes = tuple((y[i+1]-y[i])/(x[i+1]-x[i]) for i in range(len(x)-1))
    z = w-x[0]
    total = y[0]*z+slopes[0]*z*z/2
    for k in range(1, len(slopes)):
        tail = max(F(0), w-x[k])
        total += (slopes[k]-slopes[k-1])*tail*tail/2
    return total


def test_independent_spline_primitive_and_all_source_knots(make):
    def edit(wet):
        object.__setattr__(wet, '_m', _Linear(wet._m.x,
            tuple(-150000.+1000.*i*i for i in range(len(wet._m.x)))))
        object.__setattr__(wet, '_q', _Linear(wet._q.x,
            tuple(2800000.-3000.*i*i for i in range(len(wet._q.x)))))
    model = make(edit)
    m, q = model.wet._m, model.wet._q
    anchor = F(W_REF)
    for w in (*map(F, m.x), F(1, 3), F(7, 13)):
        im = spline_primitive(m, w)-spline_primitive(m, anchor)
        iq = spline_primitive(q, w)-spline_primitive(q, anchor)
        h = F(model.wet._latent_reference)*(w-anchor)-iq
        s = (h-im)/F(T_REF)
        for t in (F(T_MIN), F(340), F(T_REF)):
            p = model.evaluate(t, w)
            assert (p.h_ex_j_kg_dry, p.s_ex_j_kg_dry_k,
                    p.f_ex_j_kg_dry) == (h, s, h-t*s)
            for actual, sign in ((p.gamma_left_j_mol, -1), (p.gamma_right_j_mol, 1)):
                if w == F(W_MIN) and sign == -1:
                    expected = F(model.wet._chemical.gas_constant_j_mol_k)*t/w
                elif w == anchor and sign == 1:
                    assert actual is None
                    continue
                else:
                    # A sample strictly within the relevant adjacent side selects
                    # each curve piece independently, including mismatched grids.
                    probe = w+sign*F(1, 10**12)
                    def side_slope(curve):
                        for a,b,ya,yb in zip(curve.x,curve.x[1:],curve.y,curve.y[1:]):
                            if F(a)<probe<F(b):
                                return (F(yb)-F(ya))/(F(b)-F(a))
                        raise AssertionError('oracle_piece_not_found')
                    expected = F(model.wet._mass)*(t/F(T_REF)*side_slope(m)
                        -(1-t/F(T_REF))*side_slope(q))
                assert actual == float(expected)


@pytest.mark.parametrize('w', (.2,.4,.8))
def test_negative_source_curvature_is_rejected_before_point(make,w):
    def edit(wet):
        object.__setattr__(wet, '_m', _Linear(wet._m.x,
            tuple(-100000.-1000.*i for i in range(len(wet._m.x)))))
        object.__setattr__(wet, '_q', _Linear(wet._q.x,(2700000.,)*len(wet._q.x)))
    model=make(edit)
    with pytest.raises(low.LowMoistureError,match='negative_source_composition_derivative'):
        model.evaluate(T_REF,w)


def test_marginal_flat_source_leaf_does_not_claim_positive_transport_factor(make):
    def edit(wet):
        object.__setattr__(wet,'_m',_Linear(wet._m.x,(-100000.,)*len(wet._m.x)))
        object.__setattr__(wet,'_q',_Linear(wet._q.x,(2700000.,)*len(wet._q.x)))
    p=make(edit).evaluate(340.,.4)
    assert p.gamma_left_j_mol == p.gamma_right_j_mol == 0
    assert p.model_error is None and not p.material_qualified


def test_activity_above_one_rejected_on_both_positive_branches(make):
    def edit(wet):
        object.__setattr__(wet,'_m',_Linear(wet._m.x,(100.,)*len(wet._m.x)))
    model=make(edit)
    for w in (.1,.15,.5):
        with pytest.raises(low.LowMoistureError,match='activity_above_one'):
            model.evaluate(T_REF,w)


def decimal_fraction(x):
    return Decimal(x.numerator)/Decimal(x.denominator)


def test_nominal_log_and_activity_against_separate_high_precision_oracle(make):
    model=make(); t=F(337); j=F(W_MIN)
    mass=F(model.wet._mass); r=F(model.wet._chemical.gas_constant_j_mol_k)
    b=F(model.wet._latent_reference)-F(model.wet._q.y[0])
    mu_j=mass*(b-t*(b-F(model.wet._m.y[0]))/F(T_REF))
    for w in (j/2, j/2-F(1,10**30),F(1,10**6),F(1,10**100),F(1,10**304)):
        p=model.evaluate(t,w)
        with localcontext() as ctx:
            ctx.prec=100
            ratio=decimal_fraction(w)/decimal_fraction(j)
            expected=decimal_fraction(mu_j)+decimal_fraction(r*t)*ratio.ln()
            residual=abs(Decimal.from_float(p.mu_ex_j_mol)-expected)
            # Bounded diagnostic sample; this is not a new production error certificate.
            assert residual < Decimal('1e-8')
            residual_aw=abs(Decimal.from_float(p.activity).ln()
                           -Decimal.from_float(p.mu_ex_j_mol)/decimal_fraction(r*t))
            assert residual_aw < Decimal('1e-11')
        assert p.activity > 0 and p.mu_state == 'finite'
        assert p.gamma_left_j_mol == float(r*t/w)
        assert p.log_numerical_error is p.activity_numerical_error is None
    with pytest.raises(low.LowMoistureError,match='gamma_representation_overflow'):
        model.evaluate(t,F(1,10**306))


def test_existing_point_zero_offset_is_exactly_a_temperature_independent_reference(make):
    model=make()
    p=model.evaluate(F(T_MIN),F(0)); q=model.evaluate(F(T_REF),F(0))
    assert p.h_ex_j_kg_dry == q.h_ex_j_kg_dry != 0
    assert p.s_ex_j_kg_dry_k == q.s_ex_j_kg_dry_k != 0
    assert q.f_ex_j_kg_dry-p.f_ex_j_kg_dry == -(F(T_REF)-F(T_MIN))*p.s_ex_j_kg_dry_k
    for x in (p,q):
        json.dumps(x.to_record(),allow_nan=False)


def test_actual_curve_holdout_arithmetic_without_fitting_or_actual_water(make):
    facts=json.loads((Path.cwd()/'data/sandbox/research/arlabosse95/facts.json').read_bytes())
    rows={(o['figure'],F(o['requested_moisture_kg_water_per_kg_dry_matter'])):o
          for o in facts['observations']}
    def number(record):
        return F(record['numerator'])/F(record['denominator'])
    def edit(wet):
        # Actual public curve values + manufactured water reference only.
        values=tuple(wet._rs*T_REF*math.log(float(number(rows[1,F(str(w))]['value'])))
                     for w in wet._m.x)
        object.__setattr__(wet,'_m',_Linear(wet._m.x,values))
    model=make(edit)
    p=model.evaluate(T_REF,F(1,10))
    held=rows[1,F(1,10)]
    assert float(number(held['digitization_bounds'][0])) <= p.activity <= float(number(held['digitization_bounds'][1]))
    expected=number(rows[1,F(3,20)]['value'])*F(2,3)
    assert p.activity == pytest.approx(float(expected),rel=5e-15)
    assert all(F(x)>F(1,10) for x in model.wet._m.x)
    assert rows[2,F(1,10)]['value'] is None
    assert model.definition()['held_out']['used_for_fitting'] is False
