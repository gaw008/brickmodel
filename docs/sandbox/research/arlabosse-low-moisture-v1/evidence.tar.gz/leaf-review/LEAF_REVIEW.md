# Arlabosse low-moisture excess 叶层独立审查

**APPROVE（仅本叶层的数学、来源约定和实现）**。没有发现未解决的 CRITICAL/HIGH/MEDIUM 问题。本审查不批准尚在接线的 storage/phase/transport/outlet，不证明实际低含水污泥或全周期资格。

读取版本：

| 文件 | SHA256 |
|---|---|
| src/sludge_sandbox/arlabosse_low_moisture.py | b49f8246a01e119dfe3c865113b2d2cb7d98a963ba8186ac25783797d1801095 |
| data/sandbox/research/arlabosse-low-moisture-v1/model.json | 906f2a8a7b1d97c30f38edd51d019f874b14c9caf178b7aeb0f3797adb7b4a3f |
| tests/sandbox/test_arlabosse_low_moisture.py | 7c679302efdd4cc35eb69dbb302e9349e8b1dc5b5fdc99c9c2ec965ad4ec3a6e |

设计对照为 design/LOW_MOISTURE_DESIGN.md（b23821ce580b78ceb6a56ee91d1309cef266675cb51c4e2f2b6918c3d5922a5e）。全部读取文件/本次探针版本见 READ_SNAPSHOT.json。

## 数学及来源核对

- **零端 h/s 正确保留**：evaluate:237–253 的 hjoin、sjoin、cjoin 及 psi(0)=Wj 给 h0=hj−bj Wj、s0=sj−cj Wj−(R/M)Wj。零端 h/s 独立于 T，f=h−Ts；没有把一般非零的干端参考删掉。返回 μ/Gamma 的明确极限标签，不把未知数据替代为数值零；aw=0 是该数学端点的定义。
- **单位和同一 R/M 正确**：h/s/f 为 kg dry 基准，partial_h=M bj、mu=M(bj−T cj)+RT ln(W/Wj)、Gamma=RT/W 已为摩尔量。R 与 M 分别转 Fraction；低 W 没有再次使用已舍入 specific-R，也没有第二次乘 M。旧 m 节点自身的历史 binary64 舍入保留，metadata 如实区分这种名义差异。
- **接点符合批准设计**：低/源分支 h/s/f、μ 与 partial_h 接续；.15 保留不同左右 Gamma，未冒充平滑。源分支使用同一 m/q 的精确分段积分与插值，左右斜率分别按实际网格计算，不要求 q 具有 .5/.6 节点。源上端右导数为 None，而非伪造零斜率。
- **数值范围声明正确**：正低 W 的 s/f 是以名义 log/log1p 为条件的精确有理代数；这不使其对连续函数的导数或 log/exp 误差成为精确证书。aw 由名义接点 aw 与精确 W 比例构成，mu 来自名义对数；两者可能有不同末位舍入，错误仍为 None。`_nominal` 拒绝非零投影为零/溢出，极小正 W 不被伪装成干态。
- **源节点与留出诚实**：model.json 绑定未改的 facts、wet model 与 wet Python 源；实际 m/q、latent、R/M 进入 snapshot 身份。evaluate 不调用 desorption.at_moisture，不拟合 .10。Fig.2 的 .10 热量依旧 unknown，低 W 常 q、理想稀释、无滞回等均单列为虚拟假设。该图上 .10 是同一曲线的留出，不能称独立实验验证。
- `type(...) is ...` 在此是有意的真实 provider 类型限制，符合现有接口身份约束；没有按一般多态风格要求放宽。严格 JSON 及新建 metadata/record 未发现可变返回值泄漏。

## 本次独立证据

已读取现有 41 项测试及 MIGRATED_GREEN01 原始日志，未把那次运行算作本次执行。本次另写 test_leaf_independent.py，并使用正式 src 路径运行 **9 项通过，0.11 s**，见 INDEPENDENT01.log/xml：

1. 用独立“截断幂样条原函数”核对全部源节点、非节点有理 W 的 h/s/f；它不复制生产 trapezoid 积分算法，并逐侧核对不同 m/q 网格 Gamma。
2. 制造负曲率，验证三个位置拒绝；制造 aw>1，验证低/源两个正 W 分支拒绝。
3. 检查平坦源曲线输出 Gamma=0 的边缘稳定状态，未冒充严格正迁移率。
4. 在 Wj/2 分支交界、1e−6、1e−100、1e−304 等有限样本，使用独立 100 位 Decimal 对数 oracle 对照名义 mu/aw，保留其误差未知标签；1e−306 的 Gamma 溢出拒绝。探针容差仅属于这些制造诊断样本，未写回生产或宣称全域误差界。
5. 验证干端非零 h/s 是固定参考而 f 仅按温度线性变化；严格 JSON 成功。
6. 用实际 facts 中 .15 活度构建 m 节点、配合明确制造的水参考，仅做 .10 留出算术：名义预测约 .345712 落在该节点读图界 [.342169,.387019]，.10 未加入构造节点，热量仍 unknown。此混合测试不属于实际材料运行。

测试对真正 WaterProperties 的构造、solve、状态、响应、饱和与理想蒸气入口均设 forbidden，实际 wet 外壳使用已读现有制造源/水 seams；没有执行 EOS、下载、安装或轨迹积分。只在 leaf-review 写产物。已检查 git diff/status，保留 ROOT 的其他工作。AST 解析通过；PATH 未提供 ruff/mypy/pylint/black，不宣称完成它们的检查。

## 接线时保持的边界

这些是既有设计/接口约束，没有新增修复要求：

- 返回的 Gamma=0 可以作为自由能边缘稳定状态，但 D 迁移率计算必须另外要求 Gamma>0。0 的无限 Gamma/μ 标签须走显式解析面/相变极限，不能送入现有有限 Fraction 面核。
- 宿主使用精确 h/s/f，并仅在质量量纲处乘固定干质量；μ/partial_h 已是 J/mol。旧湿分支与新精确节点分支有名义舍入差，需保留宿主当前的残差/误差账，不能把新 identity 当作旧状态自动兼容。
- 输入端点是原 binary64 T/W 节点；精确 Fraction/Decimal 的数学十进制端点不保证等于这些 binary64 端点，metadata 已明确。名义 log/aw 无全域误差证书，极小正状态可能因所需 Gamma 超出 binary64 而拒绝。
- 保留干端 excess 常数、唯一凝聚水库存与气相库存；当前叶不提供相变速率、D/k、再润湿、外排蒸气或有限干燥事件。独审通过不升级这些能力或材料资格。
