"""Single-case passive saved-record audit; standard library only, no application import.

Prepared before native execution; invoke only after ROOT confirms terminal state.
"""
from fractions import Fraction as F
from pathlib import Path
import csv
import hashlib
import json
import math
import time
import traceback
import xml.etree.ElementTree as ET

ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK=Path('/private/tmp/arlabosse-low-moisture-v1')
OUT=WORK/'saved-review'
CHECKS=[]; ORIGINAL={}; INPUTS={}; SUMMARY={}
START=time.monotonic()

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def hook(d):
    if set(d)=={'numerator','denominator'} and all(type(v) is int for v in d.values()):
        return F(d['numerator'],d['denominator'])
    return d

def read(p):
    p=Path(p); INPUTS[str(p)]=sha(p)
    return json.loads(p.read_bytes(),object_hook=hook,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def check(name,ok):CHECKS.append({'id':name,'passed':bool(ok)})
def original(name,ok):
    if name in ORIGINAL:raise ValueError('duplicate original check '+name)
    ORIGINAL[name]=bool(ok);check('original/'+name,ok)
def save_default(x):
    if isinstance(x,F):return {'numerator':x.numerator,'denominator':x.denominator}
    raise TypeError(type(x).__name__)
def T(p):return p['fluid']['mechanical']['temperature_k']
def P(p):return p['fluid']['mechanical']['pressure_pa']
def W(s):return F(s['liquid_water_mol'])*M/MD
def total(states,kind):
    if kind=='U':return sum((F(s['internal_energy_j']) for s in states),F())
    if kind=='W':return sum((F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]) for s in states),F())
    if kind=='Nc':return sum((F(s['liquid_water_mol']) for s in states),F())
    return sum((F(s['gas_amounts_mol'][kind]) for s in states),F())
def curve_value(curve,w):
    for a,b,ya,yb in zip(curve['x'],curve['x'][1:],curve['y'],curve['y'][1:]):
        a,b,ya,yb=map(F,(a,b,ya,yb))
        if a<=w<=b:return ya+(yb-ya)*(w-a)/(b-a)
    raise ValueError('source curve domain')
def integral(curve,a,b):
    if b<a:return -integral(curve,b,a)
    edges=[a,*[F(x) for x in curve['x'] if a<F(x)<b],b]
    return sum(((curve_value(curve,x)+curve_value(curve,y))*(y-x)/2 for x,y in zip(edges,edges[1:])),F())
def lowlog(a,b):
    delta=a-b
    return F(math.log1p(float(delta/b)) if abs(delta)<=b/2 else math.log(float(a))-math.log(float(b)))
def logratio(a,b):return -lowlog(b,a) if a<b else lowlog(a,b)
def error_cost(e):
    return sum(map(abs,e['energy_j']),F()),sum(map(abs,e['liquid_mol']),F())+sum((sum(map(abs,row),F()) for row in e['gas_mol']),F())

def audit_point(label,state,point,inv=None,phase=None,mp=None):
    t=F(T(point));w=W(state);ex=point['excess'];mech=point['fluid']['mechanical']
    check(label+'/inventory',mech['liquid_inventory_mol']==state['liquid_water_mol'] and
        [mech['gas_inventory_mol'][g] for g in IDS]==state['gas_amounts_mol'] and ex['moisture_kg_water_per_kg_dry']==w)
    check(label+'/domain',0<=w<F(.15) and 325<=t<=338 and F(P(point))-F(point['pressure_error_pa'])>=90000 and
        F(P(point))+F(point['pressure_error_pa'])<=110000 and point['pressure_error_pa']>=0)
    check(label+'/liquid_occupancy',(mech['liquid_pressure_pa'] is None and mech['liquid_volume_m3']==0) if w==0 else mech['liquid_pressure_pa']==P(point))
    h=HJ+BJ*(w-J);ell=lowlog(w,J) if w else F();psi=w*ell-w+J
    s=SJ+CJ*(w-J)-(R/M)*psi;mu_join=M*(BJ-t*CJ)
    mu=None if not w else float(mu_join+R*t*ell)
    aw=0. if not w else float(F(math.exp(float(mu_join/(R*t))))*w/J)
    check(label+'/source_excess',ex['h_ex_j_kg_dry']==h and ex['s_ex_j_kg_dry_k']==s and ex['f_ex_j_kg_dry']==h-t*s
        and ex['mu_ex_j_mol']==mu and ex['partial_h_ex_j_mol']==float(M*BJ) and ex['activity']==aw)
    check(label+'/md_excess',point['excess_internal_energy_j']==MD*h and point['excess_entropy_j_k']==MD*s and
        point['excess_helmholtz_energy_j']==MD*(h-t*s))
    base_exact=F(point['fluid']['internal_energy_j'])+point['solid_internal_energy_j']
    base_u=float(base_exact);all_exact=F(base_u)+MD*h
    check(label+'/full_U',point['total_internal_energy_j']==float(all_exact))
    floor=F(point['fluid']['energy_error_bound_j'])+abs(F(base_u)-base_exact)+abs(F(point['total_internal_energy_j'])-all_exact)
    check(label+'/U_error_floor',F(point['energy_error_j'])>=floor>=0)
    check(label+'/flags',not point['material_qualified'] and not point['training_eligible'] and not ex['material_qualified'] and
        not ex['training_eligible'] and ex['model_error'] is None and ex['log_numerical_error'] is None)
    if inv is not None:
        residual=F(point['total_internal_energy_j'])-F(state['internal_energy_j']);allowance=abs(residual)+F(point['energy_error_j'])
        check(label+'/inverse',inv['target_energy_j']==state['internal_energy_j'] and inv['energy_residual_j']==residual and
            allowance<=F(1e-5) and 0<F(point['minimum_heat_capacity_j_k'])<=F(point['closed_heat_capacity_j_k']) and
            allowance/F(point['minimum_heat_capacity_j_k'])<=F(inv['temperature_error_bound_k'])<=F(1e-6))
        U_LIMITS.append(float(allowance));T_LIMITS.append(inv['temperature_error_bound_k'])
    if phase is not None:
        eq=phase['equilibrium'];pure=eq['pure_equilibrium']['liquid'];native=pure['state'];ref=native['reference']
        pureh=native['native_enthalpy_j_kg']*float(M)+ref['energy_offset_j_mol']
        pures=native['native_entropy_j_kg_k']*float(M);puremu=math.fsum((pureh,-float(t)*pures))
        check(label+'/native_reference_readout',native['temperature_k']==float(t) and native['pressure_pa']==P(point) and
            ref==WATER['reference'] and native['implementation'] is None and native['method_id']=='iapws95_real_fluid_helmholtz' and
            pure['enthalpy_j_mol']==pureh and pure['entropy_j_mol_k']==pures and pure['chemical_potential_j_mol']==puremu)
        pv=float(F(state['gas_amounts_mol'][2])*R*t/F(mech['gas_volume_m3']))
        peq=float(F(eq['pure_equilibrium']['equilibrium_partial_pressure_pa'])*F(aw))
        rate=float(F(1e-10)*(F(peq)-F(pv)))
        check(label+'/phase_readout',eq['activity']==aw and eq['equilibrium_partial_pressure_pa']==peq and
            eq['excess_partial_water_enthalpy_j_mol']==float(M*BJ) and
            eq['phase_enthalpy_difference_j_mol']==float(F(eq['pure_equilibrium']['phase_enthalpy_difference_j_mol'])-F(float(M*BJ))) and
            phase['water_partial_pressure_pa']==pv and phase['phase_water_mol_s']==rate)
        if not w:
            check(label+'/dry_limit',eq['chemical_potential_residual_j_mol'] is None and eq['liquid_reference_scope']=='hypothetical_standard_state_at_zero_inventory'
                and phase['chemical_driving_force_j_mol'] is None and phase['chemical_drive_state']=='minus_infinity_at_zero_inventory'
                and phase['entropy_production_w_k'] is None and phase['entropy_state']=='positive_infinite_boundary_limit')
        else:
            d=peq-pv
            logarithm=math.log1p(d/pv) if abs(d)<.5*pv else math.log(peq)-math.log(pv)
            drive=float(R*t*F(logarithm));entropy=float(F(rate)*F(drive)/t)
            check(label+'/positive_phase',eq['chemical_potential_residual_j_mol'] is not None and abs(eq['chemical_potential_residual_j_mol'])<=1e-7 and
                phase['chemical_driving_force_j_mol']==drive and phase['entropy_production_w_k']==entropy>=0)
        if mp is not None:
            regular=F(puremu)/t+M*(BJ-t*CJ)/t
            check(label+'/full_mu_h_context',mp['temperature_k']==t and mp['pressure_pa']==F(P(point)) and mp['moisture_kg_water_per_kg_dry']==w
                and mp['chemical_potential_j_mol']==(None if not w else F(puremu)+F(mu)) and
                mp['partial_molar_enthalpy_j_mol']==F(pureh)+F(float(M*BJ)) and
                mp['join_chemical_potential_over_temperature_j_mol_k']==regular and
                mp['water_molar_mass_kg_mol']==M and mp['gas_constant_j_mol_k']==R and
                mp['liquid_reference_scope']==eq['liquid_reference_scope'])

def audit_rates(label,states,rates):
    closed=rates['closed_rates'];interior=rates['faces'][1];mw=interior['moisture_witness']
    check(label+'/retained_context',rates['cells']==closed['cells'] and rates['faces'][1]==closed['faces'][1] and
        mw['inverses']==[c['inverse'] for c in rates['cells']] and mw['phases']==[c['phase'] for c in rates['cells']] and
        mw['points']==closed['moisture_points'] and mw['source_state_binding_verified'] is True and
        mw['storage_identities']==[p['model_identity'] for p in ini['points']])
    for i,(state,cell,mp) in enumerate(zip(states,rates['cells'],mw['points'])):
        audit_point(label+f'/cell{i}',state,cell['inverse']['point'],cell['inverse'],cell['phase'],mp)
    lp,rp=mw['points'];wl,wr=map(lambda p:p['moisture_kg_water_per_kg_dry'],mw['points'])
    tl,tr=lp['temperature_k'],rp['temperature_k'];tf=(tl+tr)/2;hf=(lp['partial_molar_enthalpy_j_mol']+rp['partial_molar_enthalpy_j_mol'])/2
    xt=1/tr-1/tl;fac=mw['factor'];ex=mw['exchange'];K=F(.001)*RHO*D/(M*F(.02))
    if not wl or not wr:
        gamma=None;n=K*(wl-wr);drive=readout=residual=entropy=rounded=None
        state='positive_infinite_boundary_limit' if wl!=wr else 'no_exchange_double_dry'
    else:
        gamma=R*tf/wl if wl==wr else R*tf*logratio(max(wl,wr),min(wl,wr))/abs(wl-wr)
        xm=lp['chemical_potential_j_mol']/tl-rp['chemical_potential_j_mol']/tr
        readout=xm+hf*xt;c=lp['join_chemical_potential_over_temperature_j_mol_k']-rp['join_chemical_potential_over_temperature_j_mol_k']+hf*xt
        logarithm=F() if wl==wr else logratio(wl,wr);mean=wl if wl==wr else (wl-wr)/logarithm
        drive=R*logarithm+c;n=K*((wl-wr)+mean*c/R);entropy=n*drive;residual=readout-drive
        rounded=F(ex['carried_energy_w'])*xt+F(ex['molar_flow_mol_s'])*xm;state='no_exchange' if not n else 'finite'
    h=hf*n
    check(label+'/factor',fac['temperature_k']==tf and fac['moisture_interval']==sorted((wl,wr)) and fac['gamma_j_mol']==gamma and
        fac['method']=='analytic_low_moisture_or_zero_limit' and fac['log_numerical_error'] is None)
    check(label+'/shared_nH',ex['exact_molar_flow_mol_s']==n and ex['molar_flow_mol_s']==float(n) and
        ex['exact_carried_energy_w']==h and ex['carried_energy_w']==float(h) and ex['dry_density_kg_m3']==RHO)
    check(label+'/instantaneous_entropy',ex['driving_force_j_mol_k']==drive and ex['complete_mu_readout_drive_j_mol_k']==readout and
        ex['drive_readout_residual_j_mol_k']==residual and ex['exact_moisture_entropy_w_k']==entropy and
        ex['rounded_rate_entropy_balance_w_k']==rounded and ex['moisture_entropy_w_k']==(None if entropy is None else float(entropy)) and
        ex['entropy_state']==state and (rounded is None or rounded>=0))
    expected_residual=None
    if tl==tr and lp['pressure_pa']==rp['pressure_pa'] and wl and wr:
        expected_residual=lp['chemical_potential_j_mol']-rp['chemical_potential_j_mol']-gamma*(wl-wr)
    check(label+'/source_resolution_residual',mw['isothermal_fick_drive_residual_j_mol']==expected_residual)
    trace=json.loads(ex['_input_provenance_json']);g=trace['geometry']
    check(label+'/geometry_snapshot',g['input_classification']=='manufactured_test_fixture' and F(*g['area_m2'])==F(.001) and
        F(*g['center_distance_m'])==F(.02) and F(*g['left_total_volume_m3'])==F(.001)*F(.02) and
        F(*g['right_total_volume_m3'])==F(.001)*F(.02) and F(*g['left_dry_mass_kg'])==MD and F(*g['right_dry_mass_kg'])==MD)
    for projection in ex['numerical_projections']:
        exact={'molar_flow_mol_s':n,'carried_energy_w':h,'moisture_entropy_w_k':entropy}[projection['name']]
        check(label+'/projection/'+projection['name'],projection['exact']==exact and projection['binary64']==float(exact)
            and projection['absolute_projection_error']==abs(F(projection['binary64'])-exact))
    kp=closed['conductivity_points'];kw=interior['conductivity_witness']
    expected_k=F('.056')+(F('.062')-F('.056'))*(F(.30)-F(23,77))/(F(47,53)-F(23,77))
    check(label+'/constant_k_extension',kw['conductivity_points']==kp and all(p['nominal_k_w_m_k']==expected_k and p['k_w_m_k']==float(expected_k)
        and p['moisture_kg_water_per_kg_dry']==W(s) and p['branch']=='constant_low_W_extension' for p,s in zip(kp,states)))
    conductance=F(.001)/(F(.01)/F(kp[0]['k_w_m_k'])+F(.01)/F(kp[1]['k_w_m_k']));heat_exact=conductance*(tl-tr)
    check(label+'/shared_conduction',kw['conductance_w_k']==float(conductance) and kw['conduction_w']==interior['conduction_w'] and
        kw['conduction_arithmetic_residual_w']==F(interior['conduction_w'])-heat_exact and
        kw['entropy_production_w_k']==float(F(interior['conduction_w'])*xt))

def decode_original(prefix,states,rates):
    for i,(state,cell) in enumerate(zip(states,rates['cells'])):
        key=prefix+f'_cell{i}';inv=cell['inverse'];p=inv['point'];ex=p['excess'];eq=cell['phase']['equilibrium'];mech=p['fluid']['mechanical']
        original(key+'_actual_Nc',mech['liquid_inventory_mol']==state['liquid_water_mol'])
        original(key+'_actual_gas',mech['gas_inventory_mol']==dict(zip(IDS,state['gas_amounts_mol'])))
        original(key+'_actual_target',inv['target_energy_j']==state['internal_energy_j'] and inv['energy_residual_j']==F(p['total_internal_energy_j'])-F(state['internal_energy_j']))
        original(key+'_inverse_U',abs(inv['energy_residual_j'])+F(p['energy_error_j'])<=F(1e-5))
        original(key+'_inverse_T',inv['temperature_error_bound_k']<=1e-6)
        original(key+'_T_domain',325<=T(p)<=338)
        original(key+'_P_domain',90000<=P(p)-p['pressure_error_pa'] and P(p)+p['pressure_error_pa']<=110000)
        original(key+'_W',ex['moisture_kg_water_per_kg_dry']==W(state) and 0<=W(state)<F(.15))
        original(key+'_retained_excess_U',p['excess_internal_energy_j']==MD*ex['h_ex_j_kg_dry'])
        original(key+'_F_identity',p['excess_helmholtz_energy_j']==p['excess_internal_energy_j']-F(T(p))*p['excess_entropy_j_k'])
        original(key+'_actual_liquid_reference',eq['pure_equilibrium']['liquid']['state']['temperature_k']==T(p) and eq['pure_equilibrium']['liquid']['state']['pressure_pa']==P(p))
        original(key+'_activity',0<eq['activity']<=1 and eq['equilibrium_partial_pressure_pa']==float(F(eq['activity'])*F(eq['pure_equilibrium']['equilibrium_partial_pressure_pa'])))
        original(key+'_mu',eq['chemical_potential_residual_j_mol'] is not None and abs(eq['chemical_potential_residual_j_mol'])<=1e-7)
        original(key+'_phase_entropy',cell['phase']['entropy_production_w_k'] is not None and cell['phase']['entropy_production_w_k']>=0)
        original(key+'_nonnegative',state['liquid_water_mol']>=0 and all(v>=0 for v in state['gas_amounts_mol']))
        original(key+'_false_flags',not p['material_qualified'] and not p['training_eligible'])

def stage_ledger(label,before,after,rates,faces,phase,dt,error):
    ecost,ncost=error_cost(error)
    check(label+'/phase_integrals',phase==[dt*F(c['phase']['phase_water_mol_s']) for c in rates['cells']])
    for f,r in zip(faces,rates['faces']):
        common=(f['gas_mol']==[dt*F(n) for n in r['gas_mol_s']] and f['energy_j']==dt*F(r['energy_w']) and
            f['conduction_j']==dt*F(r['conduction_w']) and f['diffusive_enthalpy_j']==[dt*F(v) for v in r['diffusive_enthalpy_w']] and
            f['advective_enthalpy_j']==[dt*F(v) for v in r['advective_enthalpy_w']])
        extra=f.get('moisture_enthalpy_j',F())
        check(label+f"/face{f['face_id']}/integrals",common and f['energy_decomposition_roundoff_j']==f['energy_j']-f['conduction_j']-
            sum(f['diffusive_enthalpy_j'],F())-sum(f['advective_enthalpy_j'],F())-extra)
        ecost+=abs(f['energy_decomposition_roundoff_j'])
        if 'moisture_witness' in f:
            x=r['moisture_witness']['exchange']
            check(label+'/internal_moisture_projection',f['moisture_witness']==r['moisture_witness'] and f['moisture_mol']==dt*F(x['molar_flow_mol_s']) and
                f['moisture_enthalpy_j']==dt*F(x['carried_energy_w']) and
                f['moisture_molar_projection_mol']==f['moisture_mol']-dt*x['exact_molar_flow_mol_s'] and
                f['moisture_enthalpy_projection_j']==f['moisture_enthalpy_j']-dt*x['exact_carried_energy_w'])
            ncost+=abs(f['moisture_molar_projection_mol']);ecost+=abs(f['moisture_enthalpy_projection_j'])
        if 'vapor_molar_projection_mol' in f:
            check(label+'/boundary_integral_witness',f['boundary']==r['boundary']==rates['boundary'])
            ncost+=abs(f['vapor_molar_projection_mol']);ecost+=abs(f['vapor_enthalpy_projection_j'])+abs(f['heat_projection_j'])
    for i,(old,new) in enumerate(zip(before,after)):
        l,r=faces[i:i+2]
        check(label+f'/cell{i}/U',F(new['internal_energy_j'])-F(old['internal_energy_j'])==l['energy_j']-r['energy_j']+error['energy_j'][i])
        check(label+f'/cell{i}/Nc',F(new['liquid_water_mol'])-F(old['liquid_water_mol'])==l.get('moisture_mol',F())-r.get('moisture_mol',F())-phase[i]+error['liquid_mol'][i])
        check(label+f'/cell{i}/gas',all(F(new['gas_amounts_mol'][k])-F(old['gas_amounts_mol'][k])==
            l['gas_mol'][k]-r['gas_mol'][k]+(phase[i] if k==2 else F())+error['gas_mol'][i][k] for k in range(3)))
    check(label+'/global_Nc',total(after,'Nc')-total(before,'Nc')==-sum(phase,F())+sum(error['liquid_mol'],F()))
    for k in range(3):
        check(label+f'/global_gas{k}',total(after,k)-total(before,k)==-faces[-1]['gas_mol'][k]+
            (sum(phase,F()) if k==2 else F())+sum((row[k] for row in error['gas_mol']),F()))
    check(label+'/global_U',total(after,'U')-total(before,'U')==-faces[-1]['energy_j']+sum(error['energy_j'],F()))
    check(label+'/global_water',total(after,'W')-total(before,'W')==-faces[-1]['gas_mol'][2]+sum(error['liquid_mol'],F())+
        sum((row[2] for row in error['gas_mol']),F()))
    return ecost,ncost

try:
    status=read(WORK/'supervised-native01/status.json')
    if status['status']=='running':raise RuntimeError('Refusing to audit a running native attempt')
    meta=read(WORK/'supervised-native01/metadata.json')
    a=read(WORK/'native01/ACCEPTANCE.json');run=read(WORK/'native01/RUN.json');ini=read(WORK/'native01/INITIAL.json')
    construction=read(WORK/'native01/CONSTRUCTION_PREFIX.json')
    prov=ini['provenance'];base=prov['base'];initial=ini['states'];control=prov['control'];nodes=ini['actual_source_nodes']
    IDS=('O2','N2','H2O');MD=F(.01);M=F(nodes['M']);R=F(nodes['R']);D=F('8.56e-9');RHO=MD/(F(.001)*F(.02));J=F(.15)
    mcurve,qcurve=nodes['m'],nodes['q'];latent=F(nodes['L95']);BJ=latent-curve_value(qcurve,J)
    HJ=latent*(J-F(.8))-integral(qcurve,F(.8),J);SJ=(HJ-integral(mcurve,F(.8),J))/F(368.15)
    CJ=(BJ-curve_value(mcurve,J))/F(368.15);U_LIMITS=[];T_LIMITS=[]
    WATER=base['cells'][0]['wet_definition']['water']
    check('initial/actual_constants',M==F(WATER['molar_mass_kg_mol']) and R==F(WATER['gas_constant_j_mol_k']) and WATER['backend']=='python')
    check('initial/construction_prefix',construction=={'states':initial,'points':ini['points']} and run['states'][0]==initial)
    check('initial/registered_case',[(s['liquid_water_mol'],s['gas_amounts_mol'],T(p)) for s,p in zip(initial,ini['points'])]==
        [(0.,[.000075,.000287,.000001],330.),(.06,[.000068,.000252,.000001],333.)] and
        base['cell_widths_m']==[.02,.02] and base['face_area_m2']==.001 and all(s['solid_mass_kg']==[.01] for s in initial))
    check('initial/registered_control',control['vapor_pressure_pa']==0. and control['transfer_coefficient_mol_s_pa']==1e-8 and
        control['heat_bath_temperature_k']==350. and control['heat_conductance_w_k']==.001 and control['classification']=='virtual_design_choice')
    newmodel=read(ROOT/'data/sandbox/research/arlabosse-low-moisture-transport-v1/model.json')
    modelsha=sha(ROOT/'data/sandbox/research/arlabosse-low-moisture-transport-v1/model.json')
    check('source/final_resolution_model',modelsha=='853ef0731172d091d965896a28d463464bb2d0c59ecc714228e012dbb0826b16' and
        newmodel==base['moisture_transport']['model']==base['thermal_provider']['model'] and
        newmodel['input_classifications']['geometry']=='manufactured_test_fixture' and 'source_resolution' in newmodel['numerical_policy'])
    for i,snapshot in enumerate(base['cells']):
        actual=snapshot['low_moisture_definition']['actual_source_binding']
        check(f'source/cell{i}/same_snapshot',actual['actual_m_nodes']==[mcurve['x'],mcurve['y']] and actual['actual_q_nodes']==[qcurve['x'],qcurve['y']] and
            actual['latent_reference_j_kg_water']==nodes['L95'] and actual['molar_mass_kg_mol']==nodes['M'] and
            actual['gas_constant_j_mol_k']==nodes['R'] and actual['wet_definition']==snapshot['wet_definition'])
        check(f'source/cell{i}/dry_reference',F(*snapshot['dry_endpoint_excess_internal_energy_j'])==MD*(HJ-BJ*J) and
            F(*snapshot['dry_endpoint_excess_entropy_j_k'])==MD*(SJ-CJ*J-R/M*J))
        audit_point(f'initial/cell{i}',initial[i],ini['points'][i])
    original('complete',run['status']=='completed' and run['reason'] is None)
    original('counts',len(run['states'])==3 and len(run['ledgers'])==2 and len(run['observations'])==2 and run['evaluations_attempted']==run['evaluations_completed']==6)
    original('clock',run['times_s']==[F(),F(.05)/2,F(.05)])
    original('identity',run['model_identity']==prov['model_identity'])
    original('energy_budget',run['energy_roundoff_used_j']<=F(1e-8));original('inventory_budget',run['inventory_roundoff_used_mol']<=F(1e-12))
    original('no_material_claim',run['material_qualified'] is False)
    p0=ini['points'][0]
    original('initial_true_dry',initial[0]['liquid_water_mol']==0 and p0['fluid']['mechanical']['liquid_pressure_pa'] is None and
        p0['fluid']['mechanical']['liquid_volume_m3']==0 and p0['excess_internal_energy_j']!=0 and p0['excess']['mu_ex_j_mol'] is None)
    cumulative_u=cumulative_water=outflow=energy_cost=inventory_cost=F();cumulative_species={k:F() for k in ('Nc',0,1,2)}
    for j,(old,new,ledger,rates) in enumerate(zip(run['states'],run['states'][1:],run['ledgers'],run['observations'])):
        key=f'step{j}';dt=ledger['duration_s'];check(key+'/duration',dt==F(.05)/2)
        if j==0:
            original('initial_phase_limit_preserved',ledger['predictor_rates']['cells'][0]['phase']['entropy_state']=='positive_infinite_boundary_limit')
            original('initial_transport_limit_preserved',ledger['predictor_rates']['faces'][1]['moisture_witness']['exchange']['entropy_state']=='positive_infinite_boundary_limit')
        for stage,srates,faces,width,sphase,serror,before,after in (
            ('predictor',ledger['predictor_rates'],ledger['predictor_faces'],dt/2,ledger['predictor_phase_water_mol'],ledger['predictor_roundoff'],old,ledger['midpoint_states']),
            ('accepted',ledger['midpoint_rates'],ledger['faces'],dt,ledger['phase_water_mol'],ledger['roundoff'],old,new)):
            observation=srates['boundary'];rr=srates['faces'][-1];ff=faces[-1]
            en=F(control['transfer_coefficient_mol_s_pa'])*(F(observation['cell_vapor_pressure_pa'])-F(control['vapor_pressure_pa']))
            eh=en*F(observation['common_vapor_enthalpy_j_mol']);eq=F(control['heat_conductance_w_k'])*(F(control['heat_bath_temperature_k'])-F(observation['cell_temperature_k']))
            original(key+'_'+stage+'_boundary_context',observation['cell_temperature_k']==T(srates['cells'][-1]['inverse']['point']) and observation['cell_vapor_pressure_pa']==srates['cells'][-1]['phase']['water_partial_pressure_pa'])
            original(key+'_'+stage+'_boundary_nH',rr['exact_water_mol_s']==en and rr['exact_carried_energy_w']==eh)
            original(key+'_'+stage+'_boundary_Q',rr['exact_heat_into_cell_w']==eq)
            original(key+'_'+stage+'_boundary_n_projection',ff['vapor_molar_projection_mol']==ff['gas_mol'][2]-width*en)
            original(key+'_'+stage+'_boundary_H_projection',ff['vapor_enthalpy_projection_j']==ff['diffusive_enthalpy_j'][2]-width*eh)
            original(key+'_'+stage+'_boundary_Q_projection',ff['heat_projection_j']==-ff['conduction_j']-width*eq)
            original(key+'_'+stage+'_stored_faces',all(f['energy_j']==width*F(r['energy_w']) for f,r in zip(faces,srates['faces'])))
            check(key+'/'+stage+'/boundary_shared_readouts',observation['outward_water_mol_s']==float(en)==rr['gas_mol_s'][2] and
                observation['outward_carried_energy_w']==float(eh)==rr['diffusive_enthalpy_w'][2] and observation['heat_into_cell_w']==float(eq)==-rr['conduction_w'] and
                rr['energy_w']==float(F(float(eh))-F(float(eq))) and observation['heat_entropy_w_k']==float(F(float(eq))*(1/F(observation['cell_temperature_k'])-1/F(control['heat_bath_temperature_k']))) and
                observation['reservoir_temperature_k']==observation['cell_temperature_k'] and observation['reservoir_vapor_pressure_pa']==0.)
            audit_rates(key+'/'+stage,before if stage=='predictor' else ledger['midpoint_states'],srates)
            e,n=stage_ledger(key+'/'+stage,before,after,srates,faces,sphase,width,serror);energy_cost+=e;inventory_cost+=n
        audit_rates(key+'/end',new,rates)
        left,interior,outer=ledger['faces'];mw=interior['moisture_witness'];err=ledger['roundoff']
        original(key+'_center_closed',left['energy_j']==0 and all(v==0 for v in left['gas_mol']))
        original(key+'_internal_gas_disabled',interior['gas_mol']==[F(),F(),F()])
        original(key+'_active_heat',interior['conduction_j']!=0)
        original(key+'_active_internal_water',interior['moisture_mol']<0 and interior['moisture_enthalpy_j']!=0)
        original(key+'_bound_runtime',mw['source_state_binding_verified'])
        original(key+'_actual_midpoint_states',ledger['midpoint_rates']['closed_rates']['model_identity']==base['model_identity'])
        original(key+'_midpoint_nH',interior['moisture_mol']==dt*F(mw['exchange']['molar_flow_mol_s']) and interior['moisture_enthalpy_j']==dt*F(mw['exchange']['carried_energy_w']))
        original(key+'_positive_outflow',outer['gas_mol'][2]>0 and outer['gas_mol'][:2]==[F(),F()])
        original(key+'_boundary_heat',ledger['boundary']['heat_into_cell_w']>0)
        original(key+'_vacuum_entropy',ledger['boundary']['vapor_entropy_w_k'] is None and ledger['boundary']['vapor_entropy_state']=='positive_infinite_vacuum_limit')
        original(key+'_heat_entropy',ledger['boundary']['heat_entropy_w_k']>=0)
        check(key+'/actual_boundary_witness',ledger['boundary']==ledger['midpoint_rates']['boundary']==outer['boundary'])
        for i,(before,after) in enumerate(zip(old,new)):
            lf,rf=ledger['faces'][i:i+2]
            original(key+f'_cell{i}_U',F(after['internal_energy_j'])-F(before['internal_energy_j'])==lf['energy_j']-rf['energy_j']+err['energy_j'][i])
            original(key+f'_cell{i}_Nc',F(after['liquid_water_mol'])-F(before['liquid_water_mol'])==lf.get('moisture_mol',F())-rf.get('moisture_mol',F())-ledger['phase_water_mol'][i]+err['liquid_mol'][i])
            for k in range(3):original(key+f'_cell{i}_gas{k}',F(after['gas_amounts_mol'][k])-F(before['gas_amounts_mol'][k])==lf['gas_mol'][k]-rf['gas_mol'][k]+(ledger['phase_water_mol'][i] if k==2 else F())+err['gas_mol'][i][k])
        for f in ledger['faces']:original(key+f"_face{f['face_id']}_energy_decomposition",f['energy_j']==f['conduction_j']+sum(f['diffusive_enthalpy_j'],F())+sum(f['advective_enthalpy_j'],F())+f.get('moisture_enthalpy_j',F())+f['energy_decomposition_roundoff_j'])
        eu=-outer['energy_j']+sum(err['energy_j'],F());ew=-outer['gas_mol'][2]+sum(err['liquid_mol'],F())+sum((r[2] for r in err['gas_mol']),F())
        cumulative_u+=eu;cumulative_water+=ew;outflow+=outer['gas_mol'][2]
        original(key+'_global_U',total(new,'U')-total(old,'U')==eu);original(key+'_global_water',total(new,'W')-total(old,'W')==ew)
        original(key+'_prefix_U',total(new,'U')-total(initial,'U')==cumulative_u);original(key+'_prefix_water',total(new,'W')-total(initial,'W')==cumulative_water)
        cumulative_species['Nc']+=-sum(ledger['phase_water_mol'],F())+sum(err['liquid_mol'],F())
        for k in range(3):cumulative_species[k]+=-outer['gas_mol'][k]+(sum(ledger['phase_water_mol'],F()) if k==2 else F())+sum((r[k] for r in err['gas_mol']),F())
        check(key+'/all_species_prefix',all(total(new,k)-total(initial,k)==v for k,v in cumulative_species.items()))
        for k in range(2):original(key+f'_inert{k}',[s['gas_amounts_mol'][k] for s in new]==[s['gas_amounts_mol'][k] for s in initial])
        decode_original(key+'_middle',ledger['midpoint_states'],ledger['midpoint_rates']);decode_original(key+'_end',new,rates)
    original('rewetted_dry_cell',run['states'][-1][0]['liquid_water_mol']>0)
    original('total_water_removed',outflow>0 and total(run['states'][-1],'W')<total(initial,'W'))
    for i,(p,c) in enumerate(zip(ini['points'],run['observations'][-1]['cells'])):
        original(f'cell{i}_resolved_temperature_change',abs(T(c['inverse']['point'])-T(p))>c['inverse']['temperature_error_bound_k']+1e-6)
    original('integrator_wall',run['elapsed_seconds']<60.);original('driver_wall',a['driver_seconds']<80.)
    check('record/all_original_checks_recomputed',len(a['checks'])==len(ORIGINAL)==len({c['id'] for c in a['checks']}) and {c['id']:c['passed'] for c in a['checks']}==ORIGINAL and a['passed'] is True)
    check('record/complete_fee_accounting',run['energy_roundoff_used_j']==energy_cost and run['inventory_roundoff_used_mol']==inventory_cost and
        run['energy_roundoff_budget_j']==1e-8 and run['inventory_roundoff_budget_mol']==1e-12)
    check('record/summary',a['integrator_seconds']==run['elapsed_seconds'] and a['total_water_outflow_mol']==outflow and
        a['final_temperatures_k']==[T(c['inverse']['point']) for c in run['observations'][-1]['cells']] and
        a['material_qualified'] is False and a['spatial_temporal_convergence_demonstrated'] is False)
    check('supervisor/terminal',status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] is True and status['cleanup']['signal_errors']==[])
    check('supervisor/resource_and_scope',meta['timeout_s']==100. and meta['cleanup_grace_s']==5. and a['driver_seconds']<=status['elapsed_s']<105. and
        status['cleanup']['scope']=='original_process_group_only; escaped_sessions_not_contained')
    check('supervisor/isolated_command',meta['command']==['/usr/bin/env','-u','PYTHONPATH','/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/bin/python','-I',str(WORK/'native_driver.py')])
    inputs_before={p:d['sha256'] for p,d in meta['inputs_before'].items()}
    check('supervisor/input_before_after',inputs_before==status['inputs_after'] and status['inputs_unchanged'] is True)
    required=[WORK/n for n in ('native_driver.py','native_case.py','run_supervised_native01.py','NATIVE_PLAN.md','install/SOURCE_FREEZE.json')]
    required += [ROOT/'data/sandbox/research'/name/'model.json' for name in ('arlabosse-low-moisture-v1','arlabosse-low-moisture-transport-v1','makela-moisture-v1','septien-conductivity-v1')]
    check('supervisor/registered_plan_and_models',all(str(p) in inputs_before and sha(p)==inputs_before[str(p)] for p in required))
    coverage={group:sum(needle in p for p in inputs_before) for group,needle in {
        'source':'/src/sludge_sandbox/','installed':'/site-packages/sludge_sandbox/','water':'/data/sandbox/water/',
        'iapws':'/site-packages/iapws/','numpy':'/site-packages/numpy/','scipy':'/site-packages/scipy/',
        'iapws_metadata':'/site-packages/iapws-','numpy_metadata':'/site-packages/numpy-','scipy_metadata':'/site-packages/scipy-',
        'gas_sources':'/data/sandbox/thermochemistry/','source_pdfs_xml':'/runs/sandbox/source-cache/'}.items()}
    check('supervisor/input_category_coverage',all(v>0 for v in coverage.values()) and any(Path(p).name=='pyvenv.cfg' for p in inputs_before)
        and str(Path(meta['command'][3]).resolve()) in inputs_before)
    frozen=read(WORK/'install/SOURCE_FREEZE.json')['files'];before=read(WORK/'install/INSTALL_IDENTITY_BEFORE_TESTS.json');after=read(WORK/'install/INSTALL_IDENTITY_AFTER_TESTS.json')
    check('install/records',before==after and before['passed'] is True and before['source']==before['installed']==before['frozen']==frozen)
    installed=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
    check('install/current_and_supervised_bytes',all(sha(ROOT/'src/sludge_sandbox'/name)==sha(installed/name)==digest==
        inputs_before[str(ROOT/'src/sludge_sandbox'/name)]==inputs_before[str(installed/name)] for name,digest in frozen.items()))
    check('install/reviewed_transport_version',frozen['low_moisture_transport.py']=='618486941301106095623ca6175b4ab7f3801ce05fb4feea55604e97cb68a3e0' and
        frozen['controlled_vapor_column.py']=='a336458669e067a3939775f34677c4168bc8a0dbcde1865ba8506adf9ce6ef5a')
    testpath=WORK/'install/INSTALLED_TESTS01.xml';INPUTS[str(testpath)]=sha(testpath);suite=ET.parse(testpath).getroot().find('testsuite')
    groups={}
    for tc in suite.findall('testcase'):groups[tc.get('classname')]=groups.get(tc.get('classname'),0)+1
    check('install/tests_terminal_green',int(suite.get('tests'))>0 and all(suite.get(k)=='0' for k in ('failures','errors','skipped')))
    check('install/new_test_coverage',all(any(name in group for group in groups) for name in ('low_moisture_storage','low_moisture_phase','low_moisture_column','controlled_vapor_column','low_moisture_transport')))
    SUMMARY.update(original_checks=len(ORIGINAL),supervised_input_count=len(inputs_before),input_coverage=coverage,
        installed_files=len(frozen),installed_tests=dict(suite.attrib),test_groups=groups,
        maximum_inverse_U_plus_error_j=max(U_LIMITS),maximum_temperature_bound_k=max(T_LIMITS),
        energy_roundoff_j=energy_cost,inventory_roundoff_mol=inventory_cost,total_water_outflow_mol=outflow,
        final_temperatures_k=a['final_temperatures_k'],final_pressures_pa=[P(c['inverse']['point']) for c in run['observations'][-1]['cells']],
        final_condensed_water_mol=[s['liquid_water_mol'] for s in run['states'][-1]],
        integrator_seconds=run['elapsed_seconds'],driver_seconds=a['driver_seconds'],supervisor_seconds=status['elapsed_s'])
except BaseException as exc:
    CHECKS.append({'id':'audit_exception','passed':False,'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
finally:
    record={'passed':all(c['passed'] for c in CHECKS),'checks':CHECKS,'summary':SUMMARY,'inputs_sha256':INPUTS,
        'elapsed_seconds':time.monotonic()-START,'audit_source_sha256':sha(__file__),
        'limits':['No application import, EOS, integration, or independent physical strategy review.',
        'Exact Fraction recomputation refers to saved represented inputs and nominal log readouts; physical/log errors remain unknown.',
        'Saved native h/s reference transformations are checked without independently evaluating the EOS.',
        'Both predictor and accepted rates/integrals are now saved, permitting complete reported projection-fee recomputation.',
        'No material, training, convergence, long-duration drying or full-firing-cycle qualification.']}
    destination=OUT/'SAVED_REVIEW01.json'
    with destination.open('x') as f:json.dump(record,f,indent=2,default=save_default,allow_nan=False);f.write('\n')
    print(json.dumps({'passed':record['passed'],'checks':len(CHECKS),'failures':[c for c in CHECKS if not c['passed']], 'summary':SUMMARY},default=save_default,allow_nan=False))
    if not record['passed']:raise SystemExit(1)
