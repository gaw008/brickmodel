# Controlled vapor boundary — bounded independent code review

Verdict: **APPROVE** for the reviewed code wiring. No unresolved CRITICAL, HIGH, MEDIUM, or LOW findings.

Reviewed `controlled_vapor_column.py`, the four existing author tests, and only the new controlled-vapor admission, `_integrals`, projection-budget and step-ledger branches in `source_wet_column.py`. Original author tests were read, not rerun. No production edits, package installation, actual EOS calls, or native trajectory replay occurred.

## Independent evidence

`INDEPENDENT01.log` / `.xml`: **10 passed in 31.05 s**, zero failures/errors/skips. The new tests are saved in `test_boundary_independent.py`.

- Exact runtime type gates refuse old plain/sorption hosts, derived control objects, and derived controlled hosts at integrator admission. Old exact/programmed source interfaces also reject the new wrapper.
- A configuration mutation inside the manufactured vapor-enthalpy callback is detected after the callback and before an RHS result or accepted state is recorded; attempted/completed counts and the initial prefix remain honest.
- A two-step manufactured path captures all six returned RHS objects. Each accepted ledger retains the actual middle rates, middle states, and same boundary observation; endpoint observations remain distinct. Saved cell temperature/partial pressure, shared signed water/enthalpy/heat integrals, and every cell's gas, condensed water and U balance match the actual middle readouts.
- Independent Fraction arithmetic recomputes total projected-writeback, decomposition, vapor-molar, carried-energy and heat fees for both predictor and actual stages, exactly matching the run's cumulative debits.
- Six isolated budget probes separately exercise each boundary fee in the predictor and middle stage. Every under-budget case refuses before acceptance. The face values are valid binary64 projections; a zero-writeback seam isolates billing and does not represent a physical solve.
- An excessive outward-vapor trial during the second step rejects negative inventory without clipping; the first accepted state, observation and ledger survive, with no failed trial appended.

## Static correspondence

The wrapper binds the exact low-moisture base identity and explicit virtual controls, rechecks before and after evaluation, inherits the fixed three-gas order, and replaces only the closed outer face. `_integrals` stores signed projection differences; the integrator charges their absolute values from predictor and middle stages. The actual U update uses the single signed outward total energy, with the conductive and carried terms retained as its decomposition. `step_ledger` receives the same `middle` object used for the accepted face integration. Existing closed-host defaults and old exact-event admission were not broadened.

This verdict concerns software admission and accounting. It does not establish independent EOS accuracy, physical entropy/reference-shift proofs, material transport calibration, a real kiln atmosphere, convergence, full-cycle execution or training eligibility. The separate physical reviewer owns the model-level entropy and reference-translation review. Native acceptance remains pending.

## Subject SHA-256

- `src/sludge_sandbox/controlled_vapor_column.py`: `94dc6597eed247cafe52c31273a88461109d0fabfe9e0c5c734259c8cdea9a94`
- `src/sludge_sandbox/source_wet_column.py`: `c7170fa4b7b2984db08121562979e97260d851dffdd3b81606d34ceb28cf4702`
- `tests/sandbox/test_controlled_vapor_column.py`: `b12ca98bc75af6095dfc6af46083fc00e0c5f9dba4112b5d8b8f6fe2fa52dc55`

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE** — no unresolved findings in this bounded code review.
