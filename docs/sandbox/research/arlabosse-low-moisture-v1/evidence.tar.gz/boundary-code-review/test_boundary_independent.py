"""Bounded code-wiring probes. Actual EOS is replaced by existing manufactured fixtures.

The six fee tests isolate billing with rounded, exactly specified face readouts
and a zero-writeback seam; they are not physical trajectory evidence.
"""
from dataclasses import replace
from fractions import Fraction as F

import pytest

from test_low_moisture_column import setup
import sludge_sandbox.source_wet_column as sc
from sludge_sandbox.controlled_vapor_column import (
    ControlledVaporColumn, ControlledVaporFaceRate, ControlledVaporFaceIntegral,
    ControlledVaporLedger, VaporBoundaryControl,
)


def boundary(base):
    return ControlledVaporColumn(base, VaporBoundaryControl(
        1000., 1e-9, 350., .001, ('virtual:independent_code_probe',)))


def test_exact_type_admission_closes_old_hosts_and_subclass_integrator(monkeypatch):
    from sludge_sandbox.exact_source_column import ExactSourceColumn
    from sludge_sandbox.programmed_source_wet_column import ProgrammedSourceWetColumn
    base, initial = setup(monkeypatch)
    column = boundary(base)
    for old_type in (sc.SourceWetColumn, sc.ArlabosseSorptionColumn):
        with pytest.raises(ValueError, match='actual_low_moisture_column_required'):
            ControlledVaporColumn(object.__new__(old_type), column.control)
    with pytest.raises(ValueError, match='actual_fixed_source_column_required'):
        ExactSourceColumn(column)
    old = object.__new__(ProgrammedSourceWetColumn)
    object.__setattr__(old, 'base', column)
    with pytest.raises(ValueError, match='actual_source_column_required'):
        old.binding()
    class DerivedControl(VaporBoundaryControl):
        pass
    with pytest.raises(ValueError, match='actual_vapor_boundary_control_required'):
        ControlledVaporColumn(base, DerivedControl(0.,0.,330.,0.,('virtual:x',)))
    class DerivedHost(ControlledVaporColumn):
        pass
    with pytest.raises(ValueError, match='explicit_column_steps'):
        sc.integrate_source_column(DerivedHost(base,column.control),initial,duration_s=.01,steps=1)


def test_post_callback_mutation_fails_before_output_or_accepted_state(monkeypatch):
    base, initial = setup(monkeypatch)
    column = boundary(base)
    closed = base.evaluate(initial)
    monkeypatch.setattr(type(base), 'evaluate', lambda self, states: closed)
    vapor_type = type(base.chemical.vapor)
    original = vapor_type.enthalpy_j_mol
    called = []
    def mutate(self, temperature):
        out = original(self, temperature)
        called.append(temperature)
        object.__setattr__(column.control, 'source_ids', ('virtual:changed_during_callback',))
        return out
    monkeypatch.setattr(vapor_type, 'enthalpy_j_mol', mutate)
    run = sc.integrate_source_column(column,initial,duration_s=.01,steps=1)
    assert called and run.status == 'failed'
    assert run.reason == 'controlled_vapor_column_content_changed'
    assert run.evaluations_attempted == 1 and run.evaluations_completed == 0
    assert run.states == (initial,) and run.times_s == (F(),)
    assert not run.ledgers and not run.observations


def test_actual_midpoint_identity_shared_ledger_and_all_projection_debits(monkeypatch):
    base, initial = setup(monkeypatch,(.04,.04))
    column = boundary(base)
    original = ControlledVaporColumn.evaluate
    calls = []
    def capture(self, states):
        out = original(self, states)
        calls.append((states,out))
        return out
    monkeypatch.setattr(ControlledVaporColumn, 'evaluate', capture)
    run = sc.integrate_source_column(column,initial,duration_s=1/128,steps=2)
    assert run.status == 'completed', run.reason
    assert len(calls) == 6 and len(run.ledgers) == 2
    energy = inventory = F()
    boundary_parts = [F(),F(),F()]
    for k, ledger in enumerate(run.ledgers):
        assert type(ledger) is ControlledVaporLedger
        assert ledger.midpoint_rates is calls[3*k+1][1]
        assert ledger.midpoint_states is calls[3*k+1][0]
        assert ledger.boundary is ledger.midpoint_rates.boundary
        assert ledger.faces[-1].boundary is ledger.boundary
        assert run.observations[k] is calls[3*k+2][1]
        assert ledger.midpoint_rates is not run.observations[k]
        actual = ledger.midpoint_rates.faces[-1]
        integrated = ledger.faces[-1]
        assert type(integrated) is ControlledVaporFaceIntegral
        dt = ledger.duration_s
        assert integrated.gas_mol[2] == dt*F(actual.boundary.outward_water_mol_s)
        assert integrated.energy_j == dt*F(actual.energy_w)
        assert integrated.diffusive_enthalpy_j[2] == dt*F(actual.boundary.outward_carried_energy_w)
        assert integrated.conduction_j == -dt*F(actual.boundary.heat_into_cell_w)
        assert actual.boundary.cell_temperature_k == ledger.midpoint_rates.cells[-1].inverse.point.temperature_k
        assert actual.boundary.cell_vapor_pressure_pa == ledger.midpoint_rates.cells[-1].phase.water_partial_pressure_pa
        energy += ledger.roundoff.absolute_energy_j + ledger.predictor_roundoff.absolute_energy_j
        inventory += ledger.roundoff.absolute_inventory_mol + ledger.predictor_roundoff.absolute_inventory_mol
        for rates, width in ((calls[3*k][1],dt/2),(calls[3*k+1][1],dt)):
            for face in rates.faces:
                energy += abs(width*(F(face.energy_w)-F(face.conduction_w)
                    -sum(map(F,face.diffusive_enthalpy_w),F())-sum(map(F,face.advective_enthalpy_w),F())))
                if type(face) is ControlledVaporFaceRate:
                    pn = abs(width*(F(face.gas_mol_s[2])-face.exact_water_mol_s))
                    ph = abs(width*(F(face.diffusive_enthalpy_w[2])-face.exact_carried_energy_w))
                    pq = abs(width*(-F(face.conduction_w)-face.exact_heat_into_cell_w))
                    inventory += pn
                    energy += ph+pq
                    boundary_parts = [a+b for a,b in zip(boundary_parts,(pn,ph,pq))]
        old,new = run.states[k:k+2]
        for i in range(len(old)):
            lf,rf = ledger.faces[i:i+2]
            assert F(new[i].internal_energy_j)-F(old[i].internal_energy_j) == lf.energy_j-rf.energy_j+ledger.roundoff.energy_j[i]
            for g in range(3):
                assert F(new[i].gas_amounts_mol[g])-F(old[i].gas_amounts_mol[g]) == (
                    lf.gas_mol[g]-rf.gas_mol[g]+(ledger.phase_water_mol[i] if g==2 else 0)+ledger.roundoff.gas_mol[i][g])
            assert F(new[i].liquid_water_mol)-F(old[i].liquid_water_mol) == -ledger.phase_water_mol[i]+ledger.roundoff.liquid_mol[i]
    assert run.energy_roundoff_used_j == energy
    assert run.inventory_roundoff_used_mol == inventory
    assert any(boundary_parts), 'fixture must exercise nonzero boundary projection'


@pytest.mark.parametrize('component', ('water','enthalpy','heat'))
@pytest.mark.parametrize('stage', (0,1), ids=('predictor','middle'))
def test_each_boundary_projection_debit_can_refuse_before_acceptance(monkeypatch,component,stage):
    base, initial = setup(monkeypatch)
    column = boundary(base)
    template = column.evaluate(initial)
    eps = F(1,2**60)
    zero_face = lambda f: replace(f,gas_mol_s=(0.,0.,0.),energy_w=0.,conduction_w=0.,
                                  diffusive_enthalpy_w=(0.,0.,0.),advective_enthalpy_w=(0.,0.,0.))
    ordinary = tuple(zero_face(f) for f in template.faces[:-1])
    outer = replace(template.faces[-1], gas_mol_s=(0.,0.,.25),energy_w=0.,conduction_w=-.25,
                    diffusive_enthalpy_w=(0.,0.,.25),advective_enthalpy_w=(0.,0.,0.),
                    exact_water_mol_s=F(1,4),exact_carried_energy_w=F(1,4),exact_heat_into_cell_w=F(1,4))
    name = {'water':'exact_water_mol_s','enthalpy':'exact_carried_energy_w','heat':'exact_heat_into_cell_w'}[component]
    charged = replace(outer, **{name:F(1,4)-eps})
    assert float(F(1,4)-eps) == .25  # true binary64 projection, no artificial underflow
    count = 0
    def rates(self, states):
        nonlocal count
        face = charged if count == stage else outer
        count += 1
        return replace(template,faces=(*ordinary,face))
    monkeypatch.setattr(ControlledVaporColumn,'evaluate',rates)
    zero_error = sc.ColumnRoundoff((F(),F()),((F(),)*3,)*2,(F(),F()))
    monkeypatch.setattr(sc,'_advance',lambda column,old,faces,phase:(old,zero_error))
    fee = eps*(F(1,2) if stage == 0 else 1)
    kwargs = {'inventory_roundoff_budget_mol' if component == 'water' else 'energy_roundoff_budget_j':float(fee/2)}
    run = sc.integrate_source_column(column,initial,duration_s=1.,steps=1,**kwargs)
    assert run.status == 'failed'
    expected = 'column_inventory_roundoff_budget_exceeded' if component == 'water' else 'column_energy_roundoff_budget_exceeded'
    assert run.reason == expected and count == 2
    assert run.states == (initial,) and not run.ledgers and not run.observations
    assert run.energy_roundoff_used_j == run.inventory_roundoff_used_mol == 0


def test_negative_boundary_trial_preserves_the_accepted_prefix(monkeypatch):
    base, initial = setup(monkeypatch,(.04,.04))
    column = boundary(base)
    original = ControlledVaporColumn.evaluate
    calls = []
    def exhaust_on_second_step(self, states):
        out = original(self,states)
        calls.append((states,out))
        if len(calls) == 4:
            face = replace(out.faces[-1],gas_mol_s=(0.,0.,1e6),exact_water_mol_s=F(10**6))
            out = replace(out,faces=(*out.faces[:-1],face))
        return out
    monkeypatch.setattr(ControlledVaporColumn,'evaluate',exhaust_on_second_step)
    run = sc.integrate_source_column(column,initial,duration_s=1/128,steps=2)
    assert run.status == 'domain_exit' and run.reason == 'column_inventory_domain_exit'
    assert run.evaluations_attempted == run.evaluations_completed == len(calls) == 4
    assert run.times_s == (F(),F(1,256))
    assert len(run.states) == 2 and run.states[0] is initial
    assert len(run.observations) == len(run.ledgers) == 1
    assert run.states[-1] is calls[-1][0]
    assert all(s.liquid_water_mol>=0 and all(n>=0 for n in s.gas_amounts_mol) for row in run.states for s in row)
