"""One new proof: existing first RHS and predictor-integral objects survive unchanged."""
from fractions import Fraction as F
from test_low_moisture_transport_column import setup
from sludge_sandbox.controlled_vapor_column import ControlledVaporColumn,VaporBoundaryControl
import sludge_sandbox.source_wet_column as sc


def test_first_actual_rhs_and_integral_objects_are_saved_without_extra_evaluation(monkeypatch):
    base, initial = setup(monkeypatch)
    column = ControlledVaporColumn(base,VaporBoundaryControl(0.,1e-9,350.,.001,('virtual:predictor_identity_probe',)))
    original_rhs = ControlledVaporColumn.evaluate
    original_integrals = sc._integrals
    calls, integrals = [], []
    def rhs(self, states):
        result = original_rhs(self,states)
        calls.append((states,result))
        return result
    def integrate(rates,duration):
        result = original_integrals(rates,duration)
        integrals.append((rates,duration,result))
        return result
    monkeypatch.setattr(ControlledVaporColumn,'evaluate',rhs)
    monkeypatch.setattr(sc,'_integrals',integrate)
    run = sc.integrate_source_column(column,initial,duration_s=1/256,steps=1)
    assert run.status == 'completed',run.reason
    assert len(calls) == run.evaluations_attempted == run.evaluations_completed == 3
    assert len(integrals) == 2
    ledger = run.ledgers[0]
    assert calls[0][0] is initial
    assert ledger.predictor_rates is calls[0][1] is integrals[0][0]
    assert ledger.predictor_faces is integrals[0][2][0]
    assert ledger.predictor_phase_water_mol is integrals[0][2][1]
    assert integrals[0][1] == ledger.duration_s/2 == F(1,512)
    assert ledger.midpoint_rates is calls[1][1]
    assert ledger.faces is integrals[1][2][0]
    assert ledger.phase_water_mol is integrals[1][2][1]
    assert ledger.predictor_rates.cells[0].phase.entropy_state == 'positive_infinite_boundary_limit'
    assert ledger.predictor_rates.closed_rates.faces[1].moisture_witness.exchange.entropy_state == 'positive_infinite_boundary_limit'
    assert ledger.predictor_rates is not ledger.midpoint_rates
    assert run.observations[0] is calls[2][1]
