# Source-resolution guard — final static closure 02

**APPROVE**, no unresolved findings. The previous `SOURCE_RESOLUTION_STATIC01.md/json` and earlier frozen reviews remain unchanged.

- The residual field now uses `field(default=None, kw_only=True)`. Existing positional witness flags retain their original positions; `exchange` supplies the new field by keyword. The prior MEDIUM signature finding is closed by direct static inspection.
- Geometry is now `manufactured_test_fixture` in the actual public geometry constructor and the model input classifications, consistent with the supported Column provenance. D/k low-W extension and domain assumptions retain their separate virtual classification. The model now explicitly records the source-resolution rejection and residual semantics, and the module's pinned hash matches the actual model bytes.
- The equal-T/P positive-W residual domain and stable two-low-W exemption remain as reviewed. This closure did not rerun tests, invoke EOS, or modify production.

Final subject SHA-256:

- `src/sludge_sandbox/low_moisture_transport.py`: `618486941301106095623ca6175b4ab7f3801ce05fb4feea55604e97cb68a3e0`
- `data/sandbox/research/arlabosse-low-moisture-transport-v1/model.json`: `853ef0731172d091d965896a28d463464bb2d0c59ecc714228e012dbb0826b16`

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE** for this incremental code and metadata closure.
