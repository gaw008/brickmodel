# Source-resolution guard — incremental static review 01

The source-resolution guard and residual calculation are correctly confined to actual equal-T/P, positive-W pairs. All such factor paths produce non-null Gamma. The source/cross-join branch rejects a collapsed or reversed full-mu difference before it can report no exchange; the stable analytic two-low-W path remains unchanged. The new residual is distinct from the leaf's complete-readout versus stable-drive discrepancy. Zero-W or unequal-T/P pairs retain null.

## Findings

[MEDIUM] New default field shifts an existing positional result parameter
File: `src/sludge_sandbox/low_moisture_transport.py:335`
Issue: `isothermal_fick_drive_residual_j_mol` is inserted before the existing `source_state_binding_verified`, `material_qualified`, and `training_eligible` defaults. An existing seventh positional `False` previously selected an unverified witness; it now becomes the residual and leaves `source_state_binding_verified=True`. The current public `exchange` call uses a keyword and is unaffected, but the public result constructor signature is not backward compatible.
Fix: Declare the new field as `field(default=None, kw_only=True)`, retaining the existing keyword use; alternatively append it after every pre-existing field.

## Geometry classification judgment

For the currently supported Column, use `manufactured_test_fixture` consistently with its actual geometry source IDs and existing provenance. Update the new adapter's geometry constructor and the pinned model's `input_classifications.geometry` together, including the required model SHA cascade. The D/k low-W extensions, numerical domain and unmeasured cross-effect choices remain `virtual_design_choice`. No generic classification API or inference from string prefixes is required.

The prior reviewed SHA and all prior evidence remain untouched. No tests or physical calls were run for this incremental static review. Root's separate source-resolution RED/GREEN evidence remains its own evidence.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 1 | info |
| LOW | 0 | pass |

Verdict: **APPROVE with the stated API compatibility correction before final freeze**; source-resolution arithmetic control flow is approved.
