"""Two bounded public-adapter probes using manufactured fluid contexts only."""
from dataclasses import replace
from fractions import Fraction as F
from pathlib import Path
import json
import pytest
from test_low_moisture_transport import runtime
import sludge_sandbox.low_moisture_transport as low
from sludge_sandbox.septien_conductivity import SeptienConductivity


def test_full_context_rejects_canonical_join_mu_reference_and_nested_context_changes(runtime):
    storage, transport, context = runtime
    a,b = context(.04),context(0.)
    storages=(storage,storage)
    points=(a[3],b[3])
    kwargs=dict(area_m2=.01,widths_m=(.25,.25),geometry_sources=('virtual:independent_geometry',),
        chemical=storage.wet._chemical,states=(a[0],b[0]),inverses=(a[1],b[1]),phases=(a[2],b[2]))
    result=transport.exchange(storages,points,**kwargs)
    assert result.source_state_binding_verified
    assert result.inverses is kwargs['inverses'] and result.phases is kwargs['phases']
    changes=(
        {'join_chemical_potential_over_temperature_j_mol_k':a[3].join_chemical_potential_over_temperature_j_mol_k+1},
        {'chemical_potential_j_mol':a[3].chemical_potential_j_mol+1},
        {'energy_reference_id':'manufactured:other_reference'},
    )
    for fields in changes:
        with pytest.raises(ValueError,match='points_do_not_match_actual_runtime'):
            transport.exchange(storages,(replace(a[3],**fields),b[3]),**kwargs)
    with pytest.raises(ValueError,match='inverse_state_mismatch'):
        transport.exchange(storages,points,**{**kwargs,'inverses':(replace(a[1],energy_residual_j=F(1)),b[1])})
    pure=a[2].equilibrium.pure_equilibrium
    bad_liquid=replace(pure.liquid,enthalpy_j_mol=pure.liquid.enthalpy_j_mol+1.)
    bad_phase=replace(a[2],equilibrium=replace(a[2].equilibrium,pure_equilibrium=replace(pure,liquid=bad_liquid)))
    with pytest.raises(ValueError,match='phase_reference_mismatch'):
        transport.exchange(storages,points,**{**kwargs,'phases':(bad_phase,b[2])})
    assert transport.exchange(storages,points,**kwargs)==result


def test_every_public_binding_rechecks_own_and_upstream_bytes_and_cached_D(runtime,monkeypatch):
    storage,transport,_=runtime
    root=transport.original.repository_root.resolve()
    conductivity=low.LowMoistureConductivity(SeptienConductivity(root,root/'runs/sandbox/source-cache/septien2020'))
    definition=json.loads((root/low.MODEL_PATH).read_text())
    own=root/low.MODEL_PATH
    upstream=[root/x['path'] for x in definition['upstream']]
    read=Path.read_bytes
    target=None
    def altered(path):
        raw=read(path)
        return raw+b' ' if target is not None and path.resolve()==target.resolve() else raw
    monkeypatch.setattr(Path,'read_bytes',altered)
    for target in [own,*upstream]:
        expected='low_transport_model_changed' if target==own else 'low_transport_upstream_changed'
        for provider in (transport,conductivity):
            with pytest.raises(ValueError,match=expected):
                provider.binding()
    target=None
    transport.binding()
    conductivity.binding()
    original=transport.original._diffusivity
    object.__setattr__(transport.original,'_diffusivity',replace(original,value_m2_s=original.value_m2_s*2))
    with pytest.raises(ValueError,match='moisture_diffusivity_source_changed'):
        transport.binding()
    object.__setattr__(transport.original,'_diffusivity',original)
    transport.binding()
