# Low-moisture transport — bounded independent code review

**APPROVE**, no unresolved findings. Reviewed the complete `low_moisture_transport.py`, its pinned model and author tests, with the actual low-W storage/phase and Column call sites. This is a software-boundary and data-correspondence review. The separate physical reviewer owns the independent closure, entropy, reference-translation and cross-join mathematical assessment.

## Actual new evidence

`INDEPENDENT01.log` / `.xml`: **2 passed in 1.90 s**, zero failures/errors/skips. No author 20+6 tests or root host tests were rerun. The fixture uses registered sources and actual storage/result classes with explicit manufactured water callbacks; no actual EOS, installation or native trajectory occurred.

1. A valid public exchange with complete runtime context obtains a bound witness retaining the same inverse/phase tuples. With that same full context present, changes to the canonical low-W join term, full chemical potential, or energy reference are rejected. Independently changed inverse residual and nested pure-liquid enthalpy are also rejected. The untouched context still reproduces the original exchange.
2. A read-only byte-read seam changes the model or each of its three upstream model snapshots in turn. Both D and k public bindings reject all these changes; original files remain untouched. A changed cached D is independently rejected against the original verified source diffusivity, and restoring it restores the binding.

## Static checks and practical limits

- The public adapter admits exact low-W storage and inverse/phase result classes, verifies actual inventories and target/residual U correspondence, reuses the existing pure-liquid reference and reconstructs water points before comparing caller points. The resulting full mu and molar h include the existing excess terms once. Source/backend/reference checks remain delegated to the actual storage/chemical validators. This is in-process correspondence, not authentication of arbitrary serialized records.
- Every public D/k use rechecks the new model and upstream snapshots through existing providers. Low-W k is a separately identified constant extension at the original .30 endpoint; the original provider's domain is unchanged. The D extension remains an explicit assumption. All total/model/logarithm/transfer errors and material/training qualifications remain unknown/false.
- Total slab volumes are computed from area and widths, positivity is enforced by `MoistureFaceGeometry`, and exact equal dry density is required. Source factor branches preserve exact face T and traversed-node positivity checks. Zero-W uses named finite-flux/singular-entropy limits; nonzero readout underflow and overflow are rejected. Generated provenance JSON disallows nonfinite values.
- Column routing supplies the actual cell state/inverse/phase tuple, enforces the separate low-W providers, disables parallel gas/Darcy paths when this D is used, and retains actual internal-face witnesses. The shared face energy and one condensed-water inventory use existing signed U/Nc ledgers and projection fees. No second water pool or latent-energy source is introduced.
- `LowMoistureTransportWitness` is a plain result record. The affirmative correspondence conclusion here applies to witnesses returned by checked public `exchange`; construction of arbitrary records is outside the declared authentication scope.

This does not validate source-material transfer, actual kiln boundary conditions, EOS numerical certificates, continuum/time convergence, a complete firing cycle or training eligibility. Those qualifications are not upgraded by these manufactured tests.

## Subject SHA-256

- `src/sludge_sandbox/low_moisture_transport.py`: `f6dc2c669c5b4ebd4338731ad8e50d4c5e20340d4f947ae33556328cbc19b1b8`
- `tests/sandbox/test_low_moisture_transport.py`: `86740409f4467bd4ff10b15899a75601c9e9fa0d4ffeced803b895c5f5578e31`
- `data/sandbox/research/arlabosse-low-moisture-transport-v1/model.json`: `951717175fd720f5a34b357903d95d5cf16321bffc9a30c7c1b6e1b06b78620b`

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE** within the stated code-review scope.
