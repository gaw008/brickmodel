"""Bounded low-water phase probes using actual classes and manufactured fluid calls."""
from dataclasses import asdict, replace
from fractions import Fraction as F
import json

import pytest

from test_low_moisture_storage import setup as low_setup
from sludge_sandbox.low_moisture_phase import evaluate_low_moisture_phase
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential


def test_positive_condensed_zero_vapor_uses_named_limit_without_zero_pressure_query(monkeypatch):
    low, old, gas = low_setup(monkeypatch)
    drygas = (*gas[:2], 0.)
    state = low.state(.04, drygas, 0.)
    point = low.evaluate(state, 330.)
    original = WaterChemicalPotential.ideal_vapor
    queries = []
    def positive_only(self, t, p):
        assert p > 0, 'zero_vapor_has_no_finite_chemical_potential'
        queries.append(p)
        return original(self, t, p)
    monkeypatch.setattr(WaterChemicalPotential, 'ideal_vapor', positive_only)
    active = evaluate_low_moisture_phase(low, low.wet._chemical, point, 0., 1e-9)
    assert active.phase_water_mol_s > 0 and active.water_partial_pressure_pa == 0
    assert active.chemical_drive_state == 'plus_infinity_at_zero_vapor'
    assert active.chemical_driving_force_j_mol is None and active.entropy_production_w_k is None
    assert active.entropy_state == 'positive_infinite_boundary_limit'
    disabled = evaluate_low_moisture_phase(low, low.wet._chemical, point, 0., 0.)
    assert disabled.phase_water_mol_s == disabled.entropy_production_w_k == 0
    assert disabled.entropy_state == 'no_exchange' and disabled.chemical_driving_force_j_mol is None
    assert queries and all(p > 0 for p in queries)
    # Verify the corrected exact-zero path with its actual absent liquid pressure.
    dry = low.evaluate(low.state(0., gas, 0.), 330.)
    assert dry.fluid.mechanical.liquid_pressure_pa is None
    assert dry.fluid.mechanical.liquid_volume_m3 == 0
    rewet = evaluate_low_moisture_phase(low, low.wet._chemical, dry, gas[2], 1e-9)
    assert rewet.phase_water_mol_s == float(-F(1e-9)*F(rewet.water_partial_pressure_pa)) < 0
    assert rewet.equilibrium.liquid_reference_scope == 'hypothetical_standard_state_at_zero_inventory'
    assert rewet.chemical_drive_state == 'minus_infinity_at_zero_inventory'
    assert rewet.entropy_state == 'positive_infinite_boundary_limit'
    assert rewet.chemical_driving_force_j_mol is rewet.entropy_production_w_k is None
    mech = dry.fluid.mechanical
    for bad_mech in (replace(mech, liquid_pressure_pa=mech.pressure_pa),
                     replace(mech, liquid_volume_m3=1e-9)):
        bad = replace(dry, fluid=replace(dry.fluid, mechanical=bad_mech))
        with pytest.raises(ValueError, match='low_sorption'):
            evaluate_low_moisture_phase(low, low.wet._chemical, bad, gas[2], 1e-9)
    # This phase result contains finite floats and explicit nulls, not infinity/NaN.
    json.dumps(asdict(active), default=lambda x: dict(x) if hasattr(x,'items') else str(x), allow_nan=False)


def test_modified_excess_energy_or_pressure_refused_before_pure_query(monkeypatch):
    low, old, gas = low_setup(monkeypatch)
    point = low.evaluate(low.state(.04, gas, 0.), 330.)
    def forbidden(*args, **kwargs):
        raise AssertionError('bad_point_reached_pure_query')
    monkeypatch.setattr(WaterChemicalPotential, 'equilibrium_at_liquid_tp', forbidden)
    variants=(replace(point, excess_internal_energy_j=point.excess_internal_energy_j+1),
              replace(point, excess_entropy_j_k=point.excess_entropy_j_k+1),
              replace(point, excess_helmholtz_energy_j=point.excess_helmholtz_energy_j+1),
              replace(point, pressure_error_pa=point.pressure_pa-90000.+1))
    for bad in variants:
        with pytest.raises(ValueError, match='low_sorption_point'):
            evaluate_low_moisture_phase(low, low.wet._chemical, bad, gas[2], 1e-9)
