[HIGH] 真正干态在相变入口被误拒绝
File: src/sludge_sandbox/low_moisture_phase.py:66
Issue: check_low_moisture_point 无条件把 mechanical.liquid_pressure_pa 送入正数转换。实际 RigidWaterGas 的零凝聚水解析支路明确保存 liquid_pressure_pa=None（rigid_water_gas.py:205、214–220），所以零库存的再润湿、双零和关闭路径均无法到达新极限分支。
Fix: 先检查 Nc；正 Nc 保持液压=P，零 Nc 保持液压 None 与液体体积 0，并只在后面的假想标准态查询中使用真实气相 P。

发现依据为新函数与现有干态输出结构的确定静态对应。ROOT 已确认，将先运行现有干态测试留真实失败再修复。本文件不把“尚缺 provider 模块”的早期收集失败当作此行为的 RED 证明。

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 1 | warn |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: WARNING — 此时静态快照的 HIGH 应修复并通过真实干态入口测试后再验收。
