"""Finite wrapper boundary probes with existing manufactured liquid callbacks; no EOS."""
from dataclasses import replace
from fractions import Fraction as F

import pytest

from test_low_moisture_storage import setup as low_setup
from sludge_sandbox.arlabosse_low_moisture_storage import LowMoistureSorptionStorage
from sludge_sandbox.arlabosse_sorption_phase import evaluate_sorption_phase
from sludge_sandbox.source_wet_storage import SourceWetStorage
from sludge_sandbox.source_wet_column import SourceWetColumn, ArlabosseSorptionColumn
from sludge_sandbox.phase_storage import InversePolicy
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential


def test_actual_dry_point_is_not_admitted_by_old_hosts(monkeypatch):
    low, old, gas = low_setup(monkeypatch)
    point = low.evaluate(low.state(0., gas, 0.), 330.)
    def forbidden(*args, **kwargs):
        raise AssertionError('old_phase_EOS_must_not_be_called')
    monkeypatch.setattr(WaterChemicalPotential, 'equilibrium_at_liquid_tp', forbidden)
    with pytest.raises(ValueError, match='actual_sorption_storage_required'):
        evaluate_sorption_phase(low, low.wet._chemical, point, gas[2], 1e-9, 'existing_liquid')
    args=((low,), (InversePolicy(1e-6, 1e-6, 100),), low.wet._chemical,
          (1e-9,), (), (.25,), .01, ('existing_liquid',), ('manufactured:independent-low-storage',))
    for cls in (SourceWetColumn, ArlabosseSorptionColumn):
        with pytest.raises(ValueError, match='actual_source_wet_storages'):
            cls(*args)


def test_pressure_error_interval_must_fit_for_zero_water(monkeypatch):
    low, old, gas = low_setup(monkeypatch)
    state = low.state(0., gas, 0.)
    base_evaluate = SourceWetStorage.evaluate
    def crossing(self, st, t):
        point = base_evaluate(self, st, t)
        # Nominal P remains inside, but its full interval crosses the lower bound.
        return replace(point, pressure_error_pa=point.pressure_pa-90000.+1.)
    monkeypatch.setattr(SourceWetStorage, 'evaluate', crossing)
    with pytest.raises(ValueError, match='low_sorption_pressure_domain_exit'):
        low.evaluate(state, 330.)


def test_dry_U_error_cannot_be_dropped_by_inversion(monkeypatch):
    low, old, gas = low_setup(monkeypatch)
    state = low.state(0., gas, 0.)
    target = replace(state, internal_energy_j=low.evaluate(state, 330.).total_internal_energy_j)
    base_evaluate = SourceWetStorage.evaluate
    def uncertain(self, st, t):
        return replace(base_evaluate(self, st, t), energy_error_j=1e-4)
    monkeypatch.setattr(SourceWetStorage, 'evaluate', uncertain)
    point = low.evaluate(target, 330.)
    assert F(point.energy_error_j) >= F(1e-4)
    with pytest.raises(ValueError):
        low.invert(target, InversePolicy(1e-6, 1e-6, 100))


def test_fixed_dry_reference_shift_keeps_low_excess_and_inverted_temperature(monkeypatch):
    low, old, gas = low_setup(monkeypatch)
    state = low.state(0., gas, 0.)
    first = low.evaluate(state, 330.)
    shifted_base = replace(low.base, caloric=replace(low.base.caloric, reference_temperature_k=F('333.15')))
    shifted = LowMoistureSorptionStorage(shifted_base, low.wet, low.pressure_domain_pa, excess=low.excess)
    second_state = shifted.state(0., gas, 0.)
    second = shifted.evaluate(second_state, 330.)
    assert low.model_identity != shifted.model_identity
    assert first.excess_internal_energy_j == second.excess_internal_energy_j != 0
    assert first.excess_entropy_j_k == second.excess_entropy_j_k
    assert first.pressure_pa == second.pressure_pa
    # Existing exact dry-Cp integration gives the constant reference translation.
    exact_shift = F(low.dry_mass_kg)*(low.base.caloric.specific_internal_energy(F(330))
                    -shifted_base.caloric.specific_internal_energy(F(330)))
    residual = F(first.total_internal_energy_j)-F(second.total_internal_energy_j)-exact_shift
    assert abs(residual) <= F(first.energy_error_j)+F(second.energy_error_j)
    with pytest.raises(ValueError, match='identity'):
        shifted.invert(replace(state, internal_energy_j=first.total_internal_energy_j), InversePolicy(1e-6, 1e-6, 100))
    inverse = shifted.invert(replace(second_state, internal_energy_j=second.total_internal_energy_j), InversePolicy(1e-6, 1e-6, 100))
    assert abs(inverse.point.temperature_k-330.) <= inverse.temperature_error_bound_k <= 1e-6
