"""Bounded public source-branch resolution probe; all liquid callbacks manufactured."""
from fractions import Fraction as F
from pathlib import Path
import math,json,pytest
from test_low_moisture_transport import runtime
from sludge_sandbox.water_properties import WaterProperties

def test_actual_public_source_resolution(runtime):
    storage,transport,context=runtime
    rows=[]
    for nc in (.1,.17,.2,.3,.4):
        a,b=context(nc),context(math.nextafter(nc, math.inf))
        factor=transport.factor(storage,a[3],b[3])
        row={'Nc_left':nc,'Nc_right':b[0].liquid_water_mol,
             'W_left':float(a[3].moisture_kg_water_per_kg_dry),
             'same_pressure':a[3].pressure_pa==b[3].pressure_pa,
             'same_mu':a[3].chemical_potential_j_mol==b[3].chemical_potential_j_mol,
             'gamma':float(factor.gamma_j_mol)}
        try:
            x=transport.exchange((storage,storage),(a[3],b[3]),area_m2=.01,widths_m=(.25,.25),
                geometry_sources=('virtual:independent_resolution_probe',),chemical=storage.wet._chemical,
                states=(a[0],b[0]),inverses=(a[1],b[1]),phases=(a[2],b[2]))
            row.update(flow=x.exchange.molar_flow_mol_s,entropy_state=x.exchange.entropy_state,
                drive_residual=str(x.exchange.drive_readout_residual_j_mol_k))
        except ValueError as e:
            row['rejected']=str(e)
        rows.append(row)
    Path('/private/tmp/arlabosse-low-moisture-v1/transport-review/RESOLUTION_PROBE.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(rows,indent=2))
