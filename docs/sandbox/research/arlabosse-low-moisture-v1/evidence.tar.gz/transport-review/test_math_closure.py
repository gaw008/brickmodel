"""Three independent manufactured-fluid checks; no real EOS or native integration."""
from dataclasses import replace
from decimal import Decimal, localcontext
from fractions import Fraction as F
import math

from test_low_moisture_transport import runtime
import sludge_sandbox.low_moisture_transport as low
from sludge_sandbox.arlabosse_wet_thermo import T_REF, W_MIN
from sludge_sandbox.sorption_moisture_face import MoistureFaceGeometry


def barycentric(curve,w):
    for x,y,xx,yy in zip(curve.x,curve.y,curve.x[1:],curve.y[1:]):
        x,y,xx,yy=map(F,(x,y,xx,yy))
        if x<=w<=xx:
            return ((xx-w)*y+(w-x)*yy)/(xx-x)
    raise AssertionError('oracle outside represented source domain')


def exchange(storage,transport,a,b):
    return transport.exchange((storage,storage),(a[3],b[3]),area_m2=.01,widths_m=(.25,.25),
        geometry_sources=('virtual:independent_math_geometry',),chemical=storage.wet._chemical,
        states=(a[0],b[0]),inverses=(a[1],b[1]),phases=(a[2],b[2]))


def test_resolved_source_drive_has_independent_nonzero_fick_residual(runtime):
    storage,transport,context=runtime
    a,b=context(.2),context(math.nextafter(.2,math.inf))
    assert a[3].temperature_k==b[3].temperature_k and a[3].pressure_pa==b[3].pressure_pa
    w1,w2=(p[3].moisture_kg_water_per_kg_dry for p in (a,b))
    ratio=a[3].temperature_k/F(T_REF)
    delta=F(storage.wet._mass)*(ratio*(barycentric(storage.wet._m,w1)-barycentric(storage.wet._m,w2))-
        (1-ratio)*(barycentric(storage.wet._q,w1)-barycentric(storage.wet._q,w2)))
    out=exchange(storage,transport,a,b)
    measured=a[3].chemical_potential_j_mol-b[3].chemical_potential_j_mol
    assert measured*(w1-w2)>0
    assert delta==out.factor.gamma_j_mol*(w1-w2)
    assert out.isothermal_fick_drive_residual_j_mol==measured-delta!=0
    assert out.exchange.drive_readout_residual_j_mol_k==0
    assert out.exchange.exact_molar_flow_mol_s<0
    assert out.exchange.rounded_rate_entropy_balance_w_k>0


def test_cross_join_gamma_against_separate_barycentric_and_decimal_log_oracle(runtime):
    storage,transport,context=runtime
    a,b=context(.08,330.),context(.2,333.)
    p1,p2=a[3],b[3]
    w1,w2=p1.moisture_kg_water_per_kg_dry,p2.moisture_kg_water_per_kg_dry
    j=F(W_MIN); assert w1<j<w2
    tf=(p1.temperature_k+p2.temperature_k)/2
    ratio=tf/F(T_REF)
    source_delta=F(storage.wet._mass)*(ratio*(barycentric(storage.wet._m,w2)-barycentric(storage.wet._m,j))-
        (1-ratio)*(barycentric(storage.wet._q,w2)-barycentric(storage.wet._q,j)))
    def dec(v):return Decimal(v.numerator)/Decimal(v.denominator)
    with localcontext() as ctx:
        ctx.prec=100
        oracle=(dec(source_delta)+dec(p1.gas_constant_j_mol_k*tf)*(dec(j).ln()-dec(w1).ln()))/dec(w2-w1)
        factor=transport.factor(storage,p1,p2)
        assert abs(dec(factor.gamma_j_mol)-oracle)<abs(oracle)*Decimal('2e-15')
    assert factor.method=='declared_cross_join_or_source_secant'
    # Check every traversed source segment using a separate midpoint/barycentric construction.
    edges=sorted({j,w2}|{F(x) for curve in (storage.wet._m,storage.wet._q) for x in curve.x if j<F(x)<w2})
    for lo,hi in zip(edges,edges[1:]):
        derivative=F(storage.wet._mass)*(ratio*(barycentric(storage.wet._m,hi)-barycentric(storage.wet._m,lo))-
            (1-ratio)*(barycentric(storage.wet._q,hi)-barycentric(storage.wet._q,lo)))/(hi-lo)
        assert derivative>0
    out=exchange(storage,transport,a,b)
    assert out.factor==factor and out.exchange.exact_moisture_entropy_w_k>0
    assert out.exchange.rounded_rate_entropy_balance_w_k>0


def test_source_cross_join_reference_translation_and_single_zero_limit(runtime):
    storage,transport,context=runtime
    a,b=context(.04,330.),context(.2,333.)
    geometry=MoistureFaceGeometry(F(.01),F(.25),F(storage.dry_mass_kg),F(storage.dry_mass_kg),
        F(.01)*F(.25),F(.01)*F(.25),('manufactured:math_review_geometry',),'manufactured_test_fixture')
    source=transport.original._diffusivity
    factor=transport.factor(storage,a[3],b[3])
    original=low._face(a[3],b[3],geometry,source,factor)
    c=F(12345)
    def shifted(p):
        return replace(p,chemical_potential_j_mol=p.chemical_potential_j_mol+c,
            partial_molar_enthalpy_j_mol=p.partial_molar_enthalpy_j_mol+c,
            join_chemical_potential_over_temperature_j_mol_k=p.join_chemical_potential_over_temperature_j_mol_k+c/p.temperature_k,
            energy_reference_id='manufactured:translated_reference',input_classification='manufactured_test_fixture')
    result=low._face(shifted(a[3]),shifted(b[3]),geometry,source,factor)
    assert result.exact_molar_flow_mol_s==original.exact_molar_flow_mol_s
    assert result.exact_carried_energy_w==original.exact_carried_energy_w+c*original.exact_molar_flow_mol_s
    assert result.exact_moisture_entropy_w_k==original.exact_moisture_entropy_w_k
    z=context(0.,330.)
    out=exchange(storage,transport,z,b)
    k=geometry.area_m2*(geometry.left_dry_mass_kg/geometry.left_total_volume_m3)*source.value_m2_s/(b[3].water_molar_mass_kg_mol*geometry.center_distance_m)
    assert out.exchange.exact_molar_flow_mol_s==-k*b[3].moisture_kg_water_per_kg_dry
    assert out.exchange.entropy_state=='positive_infinite_boundary_limit'
    assert out.exchange.exact_moisture_entropy_w_k is None
    assert out.points[0].chemical_potential_j_mol is None
