"""Bounded mode/identity checks; no EOS, installation or physical trajectory."""
import ast
from dataclasses import replace
from fractions import Fraction as F
from pathlib import Path

import pytest

from test_source_wet_column import setup as plain_setup
from test_arlabosse_sorption_column import setup as sorption_setup
from test_low_moisture_column import setup as low_setup
from test_programmed_source_wet_column import setup as programmed_setup
import sludge_sandbox.source_wet_column as column_module
from sludge_sandbox.source_wet_column import ColumnFaceIntegral, _advance
from sludge_sandbox.integration import DomainExit


def zero_faces(count):
    return tuple(ColumnFaceIntegral(i,(F(),)*3,F(),F(),(F(),)*3,(F(),)*3,F()) for i in range(count+1))


def test_unknown_advance_mode_is_rejected_even_when_Nc_stays_zero(monkeypatch):
    low, states = low_setup(monkeypatch, (0.,0.))
    # Actual valid storage and conserved states; only mode spelling is corrupted.
    object.__setattr__(low, 'interface_modes', ('unrecognized_mode',)*2)
    with pytest.raises((DomainExit, ValueError), match='mode|interface|content'):
        _advance(low, states, zero_faces(2), (F(),F()))


def old_binding(column):
    path=Path(__file__).with_name('BASELINE_SOURCE_WET_COLUMN.py')
    module=ast.parse(path.read_text())
    cls=next(n for n in module.body if isinstance(n,ast.ClassDef) and n.name=='SourceWetColumn')
    function=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='binding')
    code=ast.Module(body=[function],type_ignores=[])
    namespace=dict(vars(column_module))
    exec(compile(ast.fix_missing_locations(code),str(path),'exec'),namespace)
    return namespace['binding'](column)


def test_existing_plain_wet_dry_and_sorption_identity_bytes_unchanged(monkeypatch):
    plain,states=plain_setup(monkeypatch,1)
    assert plain.model_identity==old_binding(plain)
    dry=replace(states[0], liquid_water_mol=0.)
    switched=plain.with_depleted_cells((dry,), (0,))
    assert switched.model_identity==old_binding(switched)
    monkeypatch.undo()
    old,_=sorption_setup(monkeypatch)
    assert old.model_identity==old_binding(old)


def test_programmed_old_base_admission_stays_closed(monkeypatch):
    model,_=programmed_setup(monkeypatch)
    assert model.base.model_identity==old_binding(model.base)
    monkeypatch.undo()
    low,_=low_setup(monkeypatch)
    with pytest.raises(ValueError,match='actual_source_column_required'):
        replace(model,base=low)


def test_exact_rewetting_projection_and_negative_trial_not_clipped(monkeypatch):
    low, states=low_setup(monkeypatch,(0.,0.))
    q=F(-1,2**24)
    new,errors=_advance(low,states,zero_faces(2),(q,F()))
    assert F(new[0].liquid_water_mol)==-q
    assert F(new[0].gas_amounts_mol[2])-F(states[0].gas_amounts_mol[2])==q+errors.gas_mol[0][2]
    assert F(new[0].internal_energy_j)==F(states[0].internal_energy_j)
    assert new[1]==states[1]
    with pytest.raises(DomainExit,match='inventory'):
        _advance(low,states,zero_faces(2),(-q,F()))
    assert all(s.liquid_water_mol==0 for s in states)
