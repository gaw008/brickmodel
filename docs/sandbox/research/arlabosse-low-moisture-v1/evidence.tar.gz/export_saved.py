"""Export only already saved low-W runtime observations; no model imports/EOS."""
import csv
import json
from fractions import Fraction as F
from pathlib import Path

WORK=Path('/private/tmp/arlabosse-low-moisture-v1')
run=json.loads((WORK/'native01/RUN.json').read_text())

def exact(v):
    return F(v['numerator'],v['denominator']) if isinstance(v,dict) else F(v)

def number(v):
    return None if v is None else float(exact(v))

def write(name,rows):
    with (WORK/name).open('w',newline='') as stream:
        output=csv.DictWriter(stream,fieldnames=list(rows[0]))
        output.writeheader()
        output.writerows(rows)

rows=[]
decoded=[run['ledgers'][0]['predictor_rates'],*run['observations']]
for time,states,rates in zip(run['times_s'],run['states'],decoded):
    for i,(state,cell) in enumerate(zip(states,rates['cells'])):
        inv=cell['inverse'];p=inv['point'];m=p['fluid']['mechanical'];ex=p['excess']
        rows.append({'time_s':number(time),'cell':i,'temperature_k':m['temperature_k'],
            'pressure_pa':m['pressure_pa'],'condensed_water_mol':state['liquid_water_mol'],
            'vapor_water_mol':state['gas_amounts_mol'][2],
            'W_kg_water_per_kg_dry':number(ex['moisture_kg_water_per_kg_dry']),
            'state_U_j':state['internal_energy_j'],'decoded_U_j':p['total_internal_energy_j'],
            'excess_U_j':number(p['excess_internal_energy_j']),'activity':ex['activity'],
            'U_residual_plus_error_j':float(abs(exact(inv['energy_residual_j']))+exact(p['energy_error_j'])),
            'temperature_error_bound_k':inv['temperature_error_bound_k'],
            'phase_water_mol_s':cell['phase']['phase_water_mol_s'],
            'phase_entropy_state':cell['phase']['entropy_state'],
            'material_qualified':False,'model_identity':run['model_identity']})
write('TRACE.csv',rows)
faces=[]
for i,ledger in enumerate(run['ledgers']):
    for stage,rates,when in (
        ('predictor',ledger['predictor_rates'],exact(run['times_s'][i])),
        ('accepted_midpoint',ledger['midpoint_rates'],exact(run['times_s'][i])+exact(ledger['duration_s'])/2)):
        internal=rates['faces'][1];ex=internal['moisture_witness']['exchange'];boundary=rates['boundary']
        faces.append({'step':i,'stage':stage,'evaluation_time_s':float(when),
            'internal_moisture_mol_s':ex['molar_flow_mol_s'],
            'internal_moisture_enthalpy_w':ex['carried_energy_w'],
            'internal_conduction_w':internal['conduction_w'],
            'internal_moisture_entropy_w_k':ex['moisture_entropy_w_k'],
            'internal_moisture_entropy_state':ex['entropy_state'],
            'outward_vapor_mol_s':boundary['outward_water_mol_s'],
            'outward_vapor_enthalpy_w':boundary['outward_carried_energy_w'],
            'external_heat_into_cell_w':boundary['heat_into_cell_w'],
            'external_vapor_entropy_state':boundary['vapor_entropy_state'],
            'external_heat_entropy_w_k':boundary['heat_entropy_w_k'],
            'material_qualified':False})
write('FACE_TRACE.csv',faces)
print(json.dumps({'state_rows':len(rows),'face_rows':len(faces),'source':'native01/RUN.json','new_EOS_calls':0}))
