# Independent event provenance review

Verdict: **APPROVE for the isolated schema/catalog candidate.** No blocking findings. Combined service admission still requires explicit case-schema dispatch and the separately reviewed event core/record contracts.

## Inspected SHA-256

| File | SHA-256 |
|---|---|
| run_provenance.py | 8eac91b12afea2f3679902f043ad1912087399ac5af7b2f30d3717adaa4dee26 |
| free-wet-event-slab-equations-v1.json | 1b39284cdd0e11ad273ef23fee820241374caa06cb372646561fd25cfa4867b5 |
| test_event_provenance.py | 8b2b77faba6148c13a253b85f20261917e08a5ef16feb6869df6a636e64e49df |

## Binding and compatibility

catalog_filename adds keyword-only case_schema and maps the explicit event schema only to the free model's fixed event filename. Unknown schema/model combinations fail without path interpolation. Calls omitting schema retain the original ordinary catalog choice. catalog_bytes preserves original raw bytes and additionally checks catalog case_schema, treating its absence as the legacy ordinary schema. build_graph checks actual case schema against that declaration, so an event case cannot silently use the ordinary graph. Missing schema remains compatible for old ad-hoc graph fixtures. Actual service run/resume selection must supply case_schema; model ID alone intentionally continues selecting ordinary behavior.

## Algorithm and evidence wording

The catalog retains the previously reviewed current-composition free mechanics and storage equations. Its event update describes ordinary SSPRK2 adaptive panels followed by a distinct affine-midpoint terminal path, six comparison dimensions, independent approach checking, optional exact-zero/no-correction events, cumulative budgets and full-history continuation without duplicate merging. The writeback and audit nodes are explicitly numerical policies; their source is the active case declaration. They do not pretend to supply material constants or physical evidence for numerical corrections. The record-audit text correctly limits itself to retained observations and does not claim speculative paths were rerun or integrity hashes are signatures.

Every result root continues through accepted-time-update and therefore includes the new event policy, writeback, and record-audit dependencies. New source pointers resolve the complete depletion object and preserve source/physical qualification rather than presenting simulation as measurement. Core continuation and final record binding are implementation dependencies still under separate review; these catalog descriptions are the intended combined behavior, not evidence of a completed deployed service.

Two useful nonblocking precision improvements: label the opening SSPRK2 formula explicitly “For an ordinary panel” so it cannot be mistaken for the affine terminal integration formula; add an implementation anchor for affine_depletion_clock.locate_affine_depletion_clock to the clock/writeback node. The current clock node has only depletion_writeback as its direct anchor, while the actual clock locator is reached through the integration implementation. These do not change the numerical method or gate.

## Tests and scope

The two tests exercise explicit dispatch and incompatible schemas, then build/query an event graph using actual source files plus the separate record candidate. They require the new event nodes and policy leaf in every result-root trace and reject ordinary/event catalog substitutions. The graph fixture intentionally supplies only a minimal depletion object: this validates graph wiring, not case-policy parsing or actual execution. Catalog-byte payload mismatch/default-byte behavior and complete event-case/service integration remain complementary tests from the surrounding work.

Read-only review only; no EOS, test rerun, installation or repository edit. The parent-reported two passing tests were not rerun here. No full native lifecycle, final record-audit approval, material admission or complete firing-cycle claim is made.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE** for the exact isolated provenance candidate.
