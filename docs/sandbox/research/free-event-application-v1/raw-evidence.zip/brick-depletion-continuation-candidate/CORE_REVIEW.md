# Independent depletion continuation core review

Verdict: **Core accounting approved; combined admission pending complete operator binding in the separately owned record/service contract.** No independent defect found in the scoped core accumulator changes. One cross-contract HIGH finding is detailed below.

## Inspected SHA-256

| File | SHA-256 |
|---|---|
| depletion_integration.py | 9186e219188c7d281f2eff04f786ce2432c3fc2b1405718380992bcc849def37 |
| candidate.patch | 4e29dd67125718eea0934fc798961bbb3a52f2e0ef882b0c93e471cd17ed76c8 |
| test_continuation.py | 426b4d42df508e3858fadfd69533d5ca9f442a7cba6ae0a6cc9926ec0c5b597b |
| separate event_record.py dependency | 42b4c4b9af16145ad10c1b07491e5afa88bd9bb395455fe4238d63703ad0bca1 |

The supplied core before.py matches current production. No EOS, tests, installs, or repository edits were performed. The record module is still under active separate authorship and this report is not a complete record-decoder review.

## Core accounting

- `_restore_continuation` requires the exact audited type, calls its byte re-audit, compares original policy content/end time, and requires a cancelled interior accepted prefix. It compares checkpoint amounts, energy, energy binding and full mechanical vector before replacing the local initial reference.
- Full arrays, events, optional corrections, roundoff totals, cumulative N/E, resource counters, refinement diagnostics and work component schema are seeded. Mechanical represented, exact, and absolute quadrature sums are recomputed from all saved ledgers. Subsequent commit checks use original initial; newly attempted paths and breakpoint enumeration use the checkpoint time. This distinction is correct.
- The return is full cumulative history. No parent/suffix re-merge is needed or permitted. Original event and correction ordering is retained without imposing correction-per-event or ascending cell indices.
- Original global attempted-panel/rejection limits are retained. Saved attempted_steps includes discarded accepted speculative panels and is not replaced by committed-history length. Costs and evaluations continue cumulatively; caches remain fresh. The existing transactional commit boundary still controls state/mode/roundoff changes.
- Elapsed accounting adds prior charge once, rounds cumulative upward, and rounds nested remaining wall downward. Exhaustion is checked before new observations. The old policy's positive minimum nested wall is explicitly overridden for continuation, preventing a tiny budget refund. Audit/reconstruction inside this kernel entry contributes to current charged elapsed; service rebuild/snapshot time must remain separately described.
- None does not import or restore event records and retains old arrays, counters, numerical paths, gates and return shape. The only shared path change routes elapsed measurement through a helper; measured runtime naturally differs. The supplied parity test compares all serializable numerical/cost/ledger fields excluding elapsed clocks and callback objects against original module bytes.

## [HIGH] Cross-contract actual phase operator binding is incomplete

Location: `_restore_continuation` core lines 320–343, relying on separate event_record.py `binding`/`restore_result` (approximately lines 94–159 in the inspected dependency).

The core intentionally delegates operator-content verification to the record layer and only adds an interface equality check. Current record binding includes base energy identity, source IDs, species/index order and adapter contract, but omits WaterPhaseTransfer coefficients and coefficient identity/version. A new valid WaterPhaseTransfer created with different coefficients_mol_s_pa but the same base/source IDs has the same recorded binding, so it can resume under a different phase rate law. Source labels alone do not bind numeric coefficient content. The chemical/operator content and any nested programmed identity also require explicit treatment.

Before combined admission, add an immutable full supported operator-content identity excluding only the sanctioned evolving interface modes (which are separately validated). Test same IDs with changed phase coefficient values and changed coefficient identity before any provider evaluation. If complete content binding is instead owned by service, state that restriction explicitly and require the service to recompute/compare actual rebuilt operator content; frozen input files alone must not be misrepresented as a core-level guarantee. The typed continuation itself is not an authorization token: original-initial/case/manifest provenance still requires external service checks, as the implementation report correctly acknowledges.

## Test review and remaining integration dependency

Supplied tests cover Euler and affine twice-resume, cancellation before/after the event, current mechanical evolution, full-history re-audit, tampered immutable bytes, discarded attempted-panel charges, remaining-one-panel exhaustion and wall exhaustion without a new callback. They use the actual separately authored record module rather than a dummy certificate. They do not alone establish cumulative near-limit correction/component/stretch exhaustion or unchanged phase-operator content; retain the design's corruption and exhausted-budget coverage in the final combined suite.

Re-audit the final frozen record implementation with this core before application. Do not weaken the original budgets, omit resume, or bypass data audit to resolve the dependency.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 1 | cross-contract binding unresolved |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **WARNING for combined admission**; scoped core accumulation and None compatibility are approved subject to final record/operator binding integration.
