# Independent explicit event-service review

Verdict: **APPROVE for the inspected candidate**, with the separately reviewed case/core/record/catalog snapshots as coordinated dependencies. No blocking findings.

## Inspected SHA-256

- run_service.py: `ef11252a0385d6039a91747a7b2ff1c9caf47da0f8323b82a75f9afb2c6ecb46`
- test_service.py: `3f34af6cc7f42bea90a122fedde524514933f9e9f9cd0ff39abd18f40dfd2c5c`
- Final approved event_record.py dependency: `32213ca1ae0083cb2298b0470fbcbe054486df5767ec0bcfb61866b7b33c13e7`.

The supplied before.py matches actual production. Read-only inspection of the complete diff, surrounding service flow and tests; no EOS, test execution, installation or repository edits.

## Event dispatch and history

Explicit event case schema selects the event catalog and _run_event; a missing depletion policy raises rather than falling through to ordinary integration. The ordinary branch preserves existing initialization, breakpoints, IntegrationPolicy, suffix merge and snapshot flow. The event branch passes original policies to the actual continuation kernel and never applies ordinary remaining_policy or merge_integration to event history.

Before event continuation, the service requires a cancelled accepted prefix, checks both saved policies against the rebuilt case, and compares the full saved original initial and initial snapshot state against freshly rebuilt initial. Final modes are restored from the actual original operator, then the full record is audited and restored. Only the verified final state/time is used to start continuation. Original interfaces and initial snapshot remain authoritative. Boundary metadata records the separate history lengths and prior resource counters; it explicitly describes full cumulative return semantics.

depletion_result.json stores the raw full returned event record before post-run audit. Audited full history is then copied into result.json before final reconstruction. A failed post-run audit retains the previously copied parent integration while preserving the raw rejected record separately. A failed final snapshot retains the already audited event result and produces a failed top-level status. The actual run.operator is used for final-mode reconstruction. Thus completed top-level status cannot survive a snapshot exception, and raw kernel status is not lost.

## Source binding, replay and resume

Existing source/runtime/case/manifest bindings remain. The new private parent record has its own bytes/hash consistency and parent-result manifest check before copied inputs are admitted. The copied water, evidence, implementation, case and catalog hashes and membership are checked against the frozen parent before model construction. Resume selects the schema-aware catalog and verifies both numerical policies.

Event replay checks runtime_after as well as runtime_before, frozen implementation/catalog/case binding, then passes immutable parent evidence into the normal new-run path. It starts from a newly rebuilt original initial state, not the saved final state. The rebuilt initial and policies are checked; copied-source membership/hashes prevent silent replacement of frozen inputs. Trace anchors select event integration/writeback while retaining the physical free-slab anchors and schema-bound graph.

The service still performs rebuilding/forward initialization and checkpoint snapshots outside the core active-integration wall budget. Core resource guards prevent newly budgeted integration when exhausted; this should not be described as a guarantee that an exhausted service resume does no provider construction or snapshot work. No new total service wall-budget guarantee is introduced by this patch.

## Tests and limits

The seven inspected tests use an analytic manufactured callback and source overlay while calling actual service, core, record and provenance functions. They cover event run/replay and actual final modes, twice-resume without duplicate histories, diagnostic failure persistence, rebuilt initial mismatch before suffix callbacks, ordinary numerical parity against original service, runtime-after mismatch rejection, and failed post-run audit preserving raw result plus trusted parent.

These tests do not establish native water execution, installed-package lifecycle behavior, all UI states, or full firing-cycle/material qualification. Their mocked builder is explicitly disclosed. Final coordinated source freeze and package/native validation remain parent-owned work. Earlier record findings are closed only in the final dependency hash above; do not combine with an older record snapshot.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE** for the exact inspected event-service candidate and stated scope.
