from pathlib import Path
p=Path(__file__).with_name('run_service.py');s=p.read_text();pos=s.index('def run_case(')
helper='''_EVENT_SCHEMA = 'sludge_sandbox_free_event_case_v1'


def _event_cancelled(parent: dict[str, Any]) -> None:
    record = parent.get('integration')
    if (parent.get('integration_kind') != 'water_depletion_v1'
            or parent.get('status') != 'cancelled' or type(record) is not dict
            or record.get('schema') != 'sandbox_depletion_result_v1'
            or record.get('status') != 'cancelled' or record.get('reason') != 'cancel_requested'
            or not record.get('steps')):
        raise RunError('resume_requires_cancelled_event_prefix')


def _run_event(built, result: dict[str, Any], parent: dict[str, Any] | None,
               output: Path, cancel: Callable[[], bool] | None) -> None:
    """Adapt complete event evidence without flattening it into ordinary ledgers."""
    from dataclasses import replace
    from .checkpoint import exact_state_equal
    from .depletion_integration import integrate_depletion
    from .event_record import (audit_depletion_record, encode_depletion_result,
                               restore_final_operator, state)
    from .verification_case import encode, snapshot
    result['integration_kind'] = 'water_depletion_v1'
    event_policy = built.depletion_policy
    if event_policy is None:
        raise RunError('event_case_requires_explicit_policy')
    result['depletion_policy'] = encode(event_policy)
    initial, start, operator = built.initial, built.start_s, built.operator
    original_interfaces = tuple(operator.interfaces)
    continuation = None
    boundary = None
    if parent is None:
        result['initial_snapshot'] = encode(snapshot(built, initial, start))
    else:
        _event_cancelled(parent)
        if parent.get('policy') != encode(built.policy) or parent.get('depletion_policy') != encode(event_policy):
            raise RunError('resume_event_original_policy_mismatch')
        record = parent['integration']
        if not exact_state_equal(state(record['states'][0]), built.initial):
            raise RunError('resume_live_initial_mismatch')
        if not exact_state_equal(state(parent['initial_snapshot']['state']), built.initial):
            raise RunError('resume_initial_snapshot_binding_mismatch')
        # Source/case/runtime/manifest checks precede this point. Reconstruct
        # actual modes from the freshly built original operator, never saved code.
        operator = restore_final_operator(built.operator, record)
        continuation = audit_depletion_record(record, built.initial, built.policy, event_policy,
            original_interfaces, operator=operator, start_s=built.start_s, end_s=built.end_s)
        restored = continuation.restore_result(operator)
        initial, start = restored.states[-1], restored.times_s[-1]
        if start >= built.end_s:
            raise RunError('resume_requires_interior_event_prefix')
        boundary = {key:len(record[key]) for key in ('times_s','states','steps','events','corrections','refinements')}
        boundary.update(schema='sandbox_depletion_continuation_boundary_v1',
            checkpoint_time_s=start, semantics='Core returns complete cumulative history; counts mark historical prefix, not a locally accepted suffix.',
            prior_attempted_steps=restored.attempted_steps, prior_evaluations=restored.evaluations,
            prior_rejected_trials=restored.rejected_trials, prior_elapsed_seconds=restored.elapsed_seconds)
        result['continuation_boundary'] = boundary
        result['checkpoint_snapshot'] = encode(snapshot(replace(built,operator=operator), initial, start))
    _json(output/'result.json', result)
    run = integrate_depletion(initial, operator, start_s=start, end_s=built.end_s,
        integration_policy=built.policy, event_policy=event_policy, cancel=cancel, continuation=continuation)
    record = encode_depletion_result(run, original_interfaces=original_interfaces)
    # This raw complete result survives audit or diagnostic failure. It is not
    # mislabeled as a suffix and cannot be merged a second time.
    _json(output/'depletion_result.json', record)
    audit_depletion_record(record,built.initial,built.policy,event_policy,original_interfaces,
        operator=run.operator,start_s=built.start_s,end_s=built.end_s)
    result.update(status=run.status, reason=run.reason, integration=record)
    _json(output/'result.json', result)
    if run.status == 'completed':
        result['final_snapshot'] = encode(snapshot(replace(built,operator=run.operator), run.states[-1],run.times_s[-1]))


'''
s=s[:pos]+helper+s[pos:]
s=s.replace("        catalog_raw = catalog_bytes(case.payload['model_id'])", "        catalog_raw = (catalog_bytes(case.payload['model_id'],case_schema=case.payload['schema'])\n            if case.payload['schema']==_EVENT_SCHEMA else catalog_bytes(case.payload['model_id']))")
start=s.index('            if _resume is None:\n                initial = built.initial')
end=s.index('    except KeyboardInterrupt:',start)
block=s[start:end]
s=s[:start]+"            if case.payload['schema'] == _EVENT_SCHEMA:\n                _run_event(built, result, parent if _resume is not None else None, output, cancel)\n            else:\n"+''.join('    '+line if line.strip() else line for line in block.splitlines(True))+s[end:]
s=s.replace("    catalog_sha = current['catalogs'].get(catalog_filename(case.payload['model_id']))", "    catalog_name = (catalog_filename(case.payload['model_id'],case_schema=case.payload['schema'])\n        if case.payload['schema']==_EVENT_SCHEMA else catalog_filename(case.payload['model_id']))\n    catalog_sha = current['catalogs'].get(catalog_name)")
s=s.replace("        validate_cancelled(result, policy, start_s=case.payload['numerics']['start_s'],\n                           end_s=case.payload['numerics']['end_s'])", "        if case.payload['schema']==_EVENT_SCHEMA:\n            from .verification_case import _build_depletion_policy\n            _event_cancelled(result)\n            if result.get('depletion_policy') != encode(_build_depletion_policy(case.payload['numerics']['depletion'])):\n                raise RunError('resume_case_event_policy_mismatch')\n        else:\n            validate_cancelled(result, policy, start_s=case.payload['numerics']['start_s'],\n                               end_s=case.payload['numerics']['end_s'])")
s=s.replace("        anchors = _FREE_EQUATIONS", "        anchors = _FREE_EQUATIONS\n        if case.get('schema')==_EVENT_SCHEMA:\n            anchors = [('depletion_integration.py','integrate_depletion','Event-aware mechanical continuation with full original-prefix accounting.'),\n                       ('depletion_roundoff.py','depletion_writeback','Paired depletion correction and exact storage-roundoff evidence.'),*_FREE_EQUATIONS[1:]]")
p.write_text(s)
