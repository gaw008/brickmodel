from pathlib import Path
import shutil,sys
HERE=Path(__file__).resolve().parent
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
overlay=HERE/'baseline-overlay';package=overlay/'sludge_sandbox'
shutil.copytree(ROOT/'src/sludge_sandbox',package,dirs_exist_ok=True)
for name,path in {
 'run_service.py':HERE/'run_service.py',
 'verification_case.py':Path('/private/tmp/brick-free-event-case-candidate/verification_case.py'),
 'depletion_integration.py':Path('/private/tmp/brick-depletion-continuation-candidate/depletion_integration.py'),
 'event_record.py':Path('/private/tmp/brick-event-record-candidate/event_record.py'),
 'run_provenance.py':Path('/private/tmp/brick-free-event-provenance-candidate/run_provenance.py'),
 'catalogs/free-wet-event-slab-equations-v1.json':Path('/private/tmp/brick-free-event-provenance-candidate/free-wet-event-slab-equations-v1.json'),
}.items():shutil.copyfile(path,package/name)
sys.path.insert(0,str(overlay));sys.path.insert(1,str(ROOT/'tests/sandbox'))
import pytest
raise SystemExit(pytest.main([str(ROOT/'tests/sandbox/test_run_service.py'),str(ROOT/'tests/sandbox/test_checkpoint.py'),'-q','--junitxml='+str(HERE/'baseline-tests.xml')]))
