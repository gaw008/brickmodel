# Independent explicit event-case review

Verdict: **APPROVE as an isolated case/policy candidate; do not enable it in the application until explicit event dispatch is present.** No blocking defect found in the reviewed parser/builder changes. Current ordinary service fallback would ignore the new field, so standalone application is not approved.

## Inspected SHA-256

- `verification_case.py`: `4fac2bb7617366c587e40e7719ccc18b79eb598808baa7fa26b30f9b47aea805`
- `test_event_case.py`: `c67633ebddf4c6e93abe91cfe1251fb3f479895b00001eda779ab2c504c54aec`

The supplied before.py is byte-identical to current production. Review was read-only; no EOS, tests, installs, or repository edits.

## Parser and policy review

The new root schema is accepted only with the existing free model. Only that schema extends numerics with depletion; the original root schema retains its exact key set and rejects an attached depletion object. Depletion and roundoff objects have complete exact field sets. Nested approach permits only null or the exact three named fields.

The finite-tree boolean exception is restricted to the exact nested reuse path and requires both the new schema and free model ID. The nested validator then requires a real bool, rejecting integer 1. Booleans remain rejected as scalar tolerances, mass, or refinement counts. Existing number validation rejects nonfinite/unrepresentable values. Maximum refinements requires a true integer >=2. All policy scalars are explicitly positive. Actual policy constructors retain safe fraction <0.5, correction fraction <=1e-8, and exact nested strategy constraints; constructor ValueErrors become CaseError. The service-admitted method is exactly affine_midpoint, with no implicit Euler fallback.

The helper imports the existing numerical policy modules, which do not perform EOS work. Event parsing consequently imports numerical dependencies such as NumPy; unlike the legacy parse branch, it should not be described as standard-library-only parsing. This is not a native thermodynamic evaluation.

## Builder and source semantics

BuiltCase adds a trailing optional field, preserving existing positional arguments. Ordinary cases return depletion_policy=None. Event builds construct the explicit policy, then compare its declared molar mass exactly with the actual operator chemical reference before forward initialization. Existing case-byte checks, free geometry, conservative initial reconstruction, and source identity remain unchanged. The mass check occurs after _make_model, so it guarantees rejection before forward initialization, not necessarily before every provider-constructor operation; the supplied test correctly isolates that boundary using a mock operator.

## Application boundary

Current production run_service.py:201 invokes ordinary integrate without consulting BuiltCase.depletion_policy. Applying this parser alone would let an event-schema input be accepted but run under the ordinary algorithm. Keep the candidate isolated until the service explicitly selects event integration, event-aware catalog/schema binding, raw result serialization, final-interface snapshot and continuation audit. If an intermediate combined build is needed, it must reject event cases explicitly rather than run ordinary integration. This requirement preserves full resume scope; it is not permission to omit resume.

## Test evidence

The supplied tests cover policy roundtrip, nested boolean opt-in, incomplete/unknown policy objects, invalid schema/method/refinement/fractions, nonpositive time, roundoff cap, bool mass, malformed nested objects, legacy schema extra-field rejection, prescribed-model rejection, ordinary payload preservation and source-mass mismatch before forward. The parent reports 15 dry tests passing; no tests were rerun by this reviewer. The first rejected nested-boolean attempt is retained separately and the fix is appropriately path-scoped. Successful event builder/dispatch and actual continuation are outside these parser tests and require their own integration coverage.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass within isolated scope |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **APPROVE for the frozen isolated candidate**, conditional on coordinated explicit event service admission before application use.
