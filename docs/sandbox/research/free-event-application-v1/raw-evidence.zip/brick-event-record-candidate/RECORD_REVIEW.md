# Independent full event-record review

Verdict: **WARNING — two HIGH validation gaps must be resolved before continuation admission.** The previous phase-operator content binding gap is structurally fixed.

The review began from the supplied frozen candidate but the file changed during inspection: the final inspected SHA-256 is `b29012faf6d1ea9c85004ebc274afd30cb6b1147b45f9f7f863f4a08c038cb43` (the base energy identity now uses a getattr fallback). Findings below refer to that snapshot. No EOS, tests, installs or repository edits were performed.

## [HIGH] Missing exact raw terminal reconstruction permits a correction to disappear

File: event_record.py:230–249 and 326–375.

audit_affine verifies clock samples, integrated ledger fields and midpoint prediction, but never reconstructs the represented raw endpoint inventories from the terminal start plus separately rounded ledger terms and binds that raw endpoint to after. The non-null correction branch reconstructs raw values from the correction's own before fields; the null branch performs only ordinary tolerance-based local/cumulative conservation checks.

A real small terminal writeback can therefore be removed together with its correction list/totals, while cumulative N is adjusted to the uncorrected ledgers. The remaining liquid discrepancy can still lie below the ordinary amount tolerance. Clock.inventory_residual checks a valid bounded terminal residual; it does not require that represented liquid was already exactly zero. This can erase the numerical phase correction and its cumulative resource charge while retaining a declared depleted mode.

Fix: independently reproduce the kernel's binary64 advance for the terminal panel, including every represented species/energy increment and mechanical endpoint. If correction is null, require reconstructed raw liquid exactly zero and the saved after state exactly the raw state. Otherwise require correction before fields equal reconstructed raw values, then replay writeback from that independently reconstructed state and require the full resulting state/record/totals. Keep exact-zero/no-correction acceptance. Add a corruption test that removes event.correction, corrections and roundoff totals and adjusts stored cumulative N consistently; it must still fail. Existing correction tamper only empties the list, so cardinality catches it without exercising this gap.

## [HIGH] Retained observations/refinement numerics are not strictly validated

File: event_record.py:77–81 and 277–306.

observation checks finite numbers but not complete per-cell vector lengths or nonnegative temperature/pressure errors. DepletionEvaluation has no validating constructor. Empty temperature arrays or negative error entries can survive the record audit because audit_affine only consumes evaporation/rate fields. The actual kernel observe() requires all five observation vectors to match the cell count and both error vectors nonnegative.

Refinement diagnostics also bypass numeric_tree: math.isfinite accepts booleans, and np.asarray(..., dtype=float) silently converts booleans or numeric strings in comparison arrays. Several finite/shape constraints are skipped entirely when differences is null. That violates the stated strict JSON scientific-record contract and lets malformed retained evidence be certified despite not matching the kernel's emitted shapes/types.

Fix: validate complete observation shapes against the corresponding stage state and enforce the kernel's finite/nonnegative-error rules (do not invent extra manufactured T/P constraints). Validate every numeric refinement field, difference array, observation-error array, approach clock and index using exact JSON numeric types before coercion, with expected dimensions and valid enums/optional fields. Add malformed observation length/negative-error and boolean/string comparison regressions, including a refinement with differences=null.

## Previous binding finding resolved in structure

binding now hashes all actual WaterPhaseTransfer dataclass configuration except the sanctioned interface_modes transition and records chemical method/reference/range/constants and water implementation identity. Numeric coefficients, coefficient identity/version, dry policy and nested base configuration now influence the binding even when source labels are unchanged. chemical._check_identity runs before recording it. Original/final modes remain separately constrained. The supplied source-backed construction test covers same-source changed coefficients/IDs/version/dry policy but has not been run by this reviewer; native construction compatibility remains parent-owned evidence.

The ManufacturedDepletionAdapter callback is intentionally not a serialized executable identity; its declared deterministic contract and external test/service provenance remain the boundary. The application must continue admitting the exact real operator type rather than restore arbitrary callbacks from records.

## Reviewed sound portions

Exact dataclass field sets, positive-denominator Fraction parsing, immutable serialized bytes and duplicate JSON-key rejection provide useful guardrails. Derived StepLedger fields are reconstructed and compared rather than passed as init fields. The audit recomputes local and original-initial N/E changes, cumulative component residuals, represented/exact/absolute mechanical increments, and writeback totals. It retains unique event cells ordered by time, supports reverse cell-index order, and correctly pairs only non-null event corrections. Final mode transitions are one-way and require zero liquid through the actual operator helper.

Resource counters retain discarded-panel accounting and are checked against phase-cost totals and original step/rejection limits. Repeated restore re-audits bytes rather than trusting the dataclass type. Original initial/case/source-file authority still belongs to service; self-consistent JSON and hashes are not authentication or thermodynamic validation.

Refinement audit checks consecutive terminal passes, event aggregate differences and an independent halved-control/distinct-grid branch when nested approach is enabled. This retains useful arithmetic evidence but does not rerun omitted speculative trajectories or prove native T/P values. These scientific limits should remain visible.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 2 | resolve before admission |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: **WARNING** — exact terminal correction binding and strict retained-evidence validation remain required. No rerun or approval of native execution is implied.

## Follow-up inspection: endpoint and observation fixes

The author subsequently supplied SHA `822b56e3326fea20d685e033f819aa8c3f5253ff89c0f2967006de1df939fc90`. Read-only inspection confirms the new exact full raw N/E/stretch reconstruction, comparison to correction-before fields, and explicit null-correction raw-liquid-equals-zero requirement resolve the first finding structurally. Observation vectors now match the rates' cell count and error vectors must be nonnegative. These address the observation portion of the second finding.

The remaining refinement numeric/type validation portion was sent directly to the author and is still pending final inspection. Therefore combined approval remains pending; the historical findings above are retained rather than erased.

## Final follow-up: findings closed

Verified final SHA `32213ca1ae0083cb2298b0470fbcbe054486df5767ec0bcfb61866b7b33c13e7`. The final read-only inspection confirms strict numeric validation of all optional refinement scalars before the differences-null branch, recursive validation of comparison leaves before NumPy coercion, and explicit text types. numeric_tree supports decoded immutable tuples while continuing to reject booleans and strings. The earlier exact endpoint/observation fixes remain; correction clock start/end/tolerance is additionally bound to the terminal ledger and original policy.

Both reported HIGH findings are closed in this exact snapshot. Final scoped verdict: **APPROVE**, with 0 CRITICAL and 0 HIGH outstanding. The parent/author reports 24 passing no-EOS tests; this reviewer did not rerun them. Full source-backed operator construction and combined application/native lifecycle remain separately owned evidence.
