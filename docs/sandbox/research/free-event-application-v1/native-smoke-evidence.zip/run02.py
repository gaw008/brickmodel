from pathlib import Path
import json
from sludge_sandbox.run_service import run_case
root=Path('/Users/wanggaoying/Desktop/brickmodel-github');out=Path('/private/tmp/brick-free-event-native-smoke')
r=run_case(out/'case.json',root/'data/sandbox/water',out/'run02',evidence_directory=root/'data/sandbox')
(out/'summary02.json').write_text(json.dumps({'status':r['status'],'reason':r.get('reason'),'steps':len(r.get('integration',{}).get('steps',[])),'events':len(r.get('integration',{}).get('events',[])),'elapsed_seconds':r['elapsed_seconds']},indent=2)+'\n')
print((out/'summary02.json').read_text())
