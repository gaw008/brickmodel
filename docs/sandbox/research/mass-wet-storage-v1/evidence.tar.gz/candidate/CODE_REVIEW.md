# Independent Python / numerical review

## Final repaired freeze — APPROVE

Source 60f6ec5d87c6f65d10bc4d644ae67c80c27f2bf6b73dce8b905c75781811da99 and formal tests 481e23788f384cfa11d0b6ede76bfda0ec3c23728f702b9d302cb1ae5dab909b were independently re-read and executed. Both prior findings are resolved: inventory() checks the original Fraction sign and refuses nonzero-to-zero conversion in each physical inventory; source_ids includes the declared fluid envelope and mechanical constants. Legacy dry code remains unchanged.

Actual final execution: **23 passed in 0.50 s**, including all six previously failing reviewer underflow probes, all 14 formal cases, and independent nonzero du/dp pressure/energy coverage. See independent-final-tests.log/XML. Final py_compile passed; file SHA256 values were rechecked after execution. No unresolved numerical or security HIGH/CRITICAL finding. APPROVE this limited wet-storage layer for integration, conditional on the same declared numerical envelope; native EOS validation, transport, depletion events and real material admission remain separate gates.

## Preserved initial review and failures

Initial frozen source: ea187d156a836c5871f95f01617ef784c02116ec2179d39d8854fc0479d21fc3. Formal tests: abe8675f4fce7e3ee987702424a2d0ef34e830c33569a357c817dbdb9b8619b0.

Verdict for this freeze: BLOCK pending inventory-underflow repair.

[HIGH] Nonzero inventories silently become exact zero
File: mass_wet_storage.py:31
Issue: WetMixedState accepts positive and negative Fraction(1,10**400) in kg solids, liquid mol, and gas mol. All become signed float zero before sign validation. This bypasses negative-inventory rejection and can falsely represent phase exhaustion. Six independent parameterized tests actually fail on the frozen implementation; see independent-underflow-red.log/XML.
Fix: Validate original numeric type/sign and reject nonzero-to-zero conversion for all three inventory categories in the new wet interface, without silently changing legacy dry behavior.

[MEDIUM] Flattened source list omits numerical and constant provenance
File: mass_wet_storage.py:146
Issue: source_ids omits fluid_template.envelope.source_ids and mechanical.constant_source_ids even though binding retains these objects.
Fix: Include these declared sources in the aggregate property and assert their presence.

The design's kg solids, liquid mol, gas mol and total U remain distinct. Solid reference uses h_ref + Cp*(T-Tref) - p_ref*v, fluid closure alone subtracts liquid occupancy. The global pressure-domain proof precedes local bound tightening, and additional liquid energy uncertainty uses Nl*|du/dp|*extra_p without replacing existing fluid error. Fixed water formation reference and zero chemical-water coefficients prevent unsupported water chemistry/gauge admission. These positive findings do not clear the identified input defect.

Executed independent tests before underflow probes: 10 passed in 0.48 s (independent-tests02.log/XML), including nonzero du/dp manufactured compressible-liquid response, +/- bulk perturbations enclosed in pressure/energy bounds, source mutation, and inverse/domain rejection. Original independent-tests01 is retained: one reviewer-authored negative probe used an uncertainty still inside the valid pressure domain; corrected that probe from 1e-5 to 5e-5 without modifying production policy. This was not a production failure.

No native EOS, installation, repository change, or material certification was performed. Fixtures replace liquid calls with explicitly artificial responses; real RigidStorage mechanical/thermal logic and source-derived ideal functions run. py_compile passed. ruff, mypy, pylint and black are unavailable both on PATH and in the designated venv; no static checker was installed. Repository git diff was inspected at entry. Local applicable AGENTS.md files were absent; Goal section 2 supplies delegation authorization.
