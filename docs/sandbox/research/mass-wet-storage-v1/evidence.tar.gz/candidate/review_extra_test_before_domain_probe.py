"""Independent review probes; artificial liquid only, never native EOS."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_mass_wet_storage import setup
from sludge_sandbox.water_properties import WaterProperties, WaterState, WaterResponse
from sludge_sandbox.phase_storage import InversePolicy


def test_pressure_dependent_liquid_error_reaches_total_energy(monkeypatch):
    storage, state, _ = setup(monkeypatch)
    compressibility = 1e-13

    def liquid(water, temperature, pressure, *, phase):
        assert phase == 'liquid'
        volume = 1.8e-5 - compressibility * pressure
        energy = 75 * temperature - 300000 + .5 * compressibility * pressure**2
        mass = water.reference.molar_mass_kg_mol
        offset = water.reference.energy_offset_j_mol
        return WaterState(temperature, (energy + pressure * volume - offset) / mass,
                          (energy - offset) / mass, 75 / mass, 75 / mass,
                          water.reference, 'independent-compressible-liquid-seam',
                          pressure, phase, mass / volume, 0., 0., 0.,
                          implementation=water.implementation)

    def response(water, temperature, pressure, *, phase):
        point = liquid(water, temperature, pressure, phase=phase)
        volume = point.molar_mass_kg_mol / point.density_kg_m3
        return WaterResponse(point, 0., compressibility / volume, 0.,
                             -compressibility, compressibility * pressure, 0.)

    monkeypatch.setattr(WaterProperties, 'state_tp', liquid)
    monkeypatch.setattr(WaterProperties, 'state_tp_response', response)
    envelope = replace(storage.fluid_template.envelope,
                       liquid_abs_du_dp_bound_j_mol_pa=1e-6)
    storage = replace(storage, fluid_template=replace(storage.fluid_template, envelope=envelope),
                      bulk_volume_error_m3=1e-9)
    state = storage.state(state.solid_mass_kg, state.liquid_water_mol, state.gas_amounts_mol, 0.)
    point = storage.evaluate(state, 305.)
    extra_energy = F(state.liquid_water_mol) * F(1e-6) * F(point.extra_pressure_error_pa)
    assert extra_energy > 0
    assert F(point.energy_error_j) >= F(point.fluid.energy_error_bound_j) + extra_energy
    for sign in (-1, 1):
        other = replace(storage, bulk_volume_m3=storage.bulk_volume_m3 + sign * 1e-9,
                        bulk_volume_error_m3=0.)
        other_state = other.state(state.solid_mass_kg, state.liquid_water_mol, state.gas_amounts_mol, 0.)
        exact_other = other.evaluate(other_state, 305.)
        assert abs(F(exact_other.pressure_pa) - F(point.pressure_pa)) <= F(point.pressure_error_pa) + F(exact_other.pressure_error_pa)
        assert abs(F(exact_other.total_internal_energy_j) - F(point.total_internal_energy_j)) <= F(point.energy_error_j) + F(exact_other.energy_error_j)


def test_inverse_excludes_outside_target_and_volume_pressure_domain(monkeypatch):
    storage, state, _ = setup(monkeypatch)
    with pytest.raises(ValueError, match='energy_target_outside_domain'):
        storage.invert(replace(state, internal_energy_j=1e20), InversePolicy(1e-6, 1e-6, 100))
    uncertain = replace(storage, bulk_volume_error_m3=1e-5)
    with pytest.raises(ValueError, match='global_pressure_uncertainty_outside_domain'):
        uncertain.evaluate(uncertain.state(state.solid_mass_kg, .2, state.gas_amounts_mol, 0.), 305.)


def test_mutated_water_source_rejected_before_forward(monkeypatch):
    storage, state, _ = setup(monkeypatch)
    original = storage.water.source_asset_sha256
    try:
        object.__setattr__(storage.water, 'source_asset_sha256', {'unexpected': 'a' * 64})
        with pytest.raises(ValueError, match='provider_content_changed'):
            storage.evaluate(state, 305.)
    finally:
        object.__setattr__(storage.water, 'source_asset_sha256', original)
