"""Independent manufactured-seam review; no native EOS."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from test_mass_wet_transport import setup
from sludge_sandbox.mass_wet_transport import WetPair, integrate_wet_pair


def test_unequal_half_width_face_reversal(monkeypatch):
    pair, states = setup(monkeypatch)
    pair = replace(pair, face=replace(pair.face, half_widths_m=(.03, .07)))
    original = pair.evaluate(states)
    reverse = replace(pair, storages=pair.storages[::-1],
                      inverse_policies=pair.inverse_policies[::-1],
                      rate_constants_per_s=pair.rate_constants_per_s[::-1],
                      oxygen_references_mol=pair.oxygen_references_mol[::-1],
                      transfer_coefficients_mol_s_pa=pair.transfer_coefficients_mol_s_pa[::-1],
                      face=replace(pair.face, half_widths_m=pair.face.half_widths_m[::-1],
                                   conductivities_w_m_k=pair.face.conductivities_w_m_k[::-1]))
    reversed_out = reverse.evaluate(states[::-1])
    assert reversed_out.face_energy_w == pytest.approx(-original.face_energy_w, rel=1e-12)
    assert reversed_out.exchange.face_temperature_k == pytest.approx(original.exchange.face_temperature_k, rel=1e-14)
    for key in pair.storages[0].gas_ids:
        assert reversed_out.exchange.net_mol_s[key] == pytest.approx(-original.exchange.net_mol_s[key], rel=1e-12, abs=1e-20)
    for index, row in enumerate(original.cells):
        assert reversed_out.cells[1-index].phase_water_mol_s == row.phase_water_mol_s


def test_second_midpoint_failure_keeps_exactly_first_committed_prefix(monkeypatch):
    pair, states = setup(monkeypatch)
    evaluate = WetPair.evaluate
    calls = [0]
    def fail_on_fifth(self, state):
        calls[0] += 1
        if calls[0] == 5:
            raise ValueError('independent_second_midpoint_failure')
        return evaluate(self, state)
    monkeypatch.setattr(WetPair, 'evaluate', fail_on_fifth)
    result = integrate_wet_pair(pair, states, duration_s=.01, steps=4)
    assert result.status == 'failed' and result.reason == 'independent_second_midpoint_failure'
    assert len(result.states) == 2 and len(result.ledgers) == len(result.observations) == 1
    assert result.times_s == (F(), F(.01)/4)
    assert result.evaluations_attempted == 5 and result.evaluations_completed == 4
    monkeypatch.setattr(WetPair, 'evaluate', evaluate)
    reference = integrate_wet_pair(pair, states, duration_s=.01/4, steps=1)
    assert result.states == reference.states and result.ledgers == reference.ledgers


def test_same_timestep_split_and_zero_transfer_stationarity(monkeypatch):
    pair, states = setup(monkeypatch)
    duration = .015625
    whole = integrate_wet_pair(pair, states, duration_s=duration, steps=4)
    first = integrate_wet_pair(pair, states, duration_s=duration/2, steps=2)
    second = integrate_wet_pair(pair, first.states[-1], duration_s=duration/2, steps=2)
    assert whole.status == first.status == second.status == 'completed'
    assert whole.states == first.states + second.states[1:]
    assert whole.ledgers == first.ledgers + second.ledgers
    assert whole.times_s[-1] == F(duration)
    still = replace(pair, rate_constants_per_s=(0.,0.), transfer_coefficients_mol_s_pa=(0.,0.),
                    face=replace(pair.face, conductivities_w_m_k=(0.,0.),
                                 diffusivities_m2_s=(0.,0.,0.), permeability_m2=0.))
    result = integrate_wet_pair(still, states, duration_s=duration, steps=2)
    assert result.status == 'completed' and all(value == states for value in result.states)


def test_end_of_callback_source_mutation_is_rejected(monkeypatch):
    pair, states = setup(monkeypatch)
    from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
    original = WaterChemicalPotential.equilibrium_at_liquid_tp
    def mutate(self, *args, **kwargs):
        output = original(self, *args, **kwargs)
        object.__setattr__(pair, 'coefficient_source_ids', ('changed-after-actual-chemical-call',))
        return output
    monkeypatch.setattr(WaterChemicalPotential, 'equilibrium_at_liquid_tp', mutate)
    with pytest.raises(ValueError, match='wet_pair_source_changed'):
        pair.evaluate(states)
