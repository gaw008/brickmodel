import sys
from pathlib import Path
import sludge_sandbox
HERE=Path(__file__).parent
sludge_sandbox.__path__.extend((str(HERE),str(HERE.parent/'candidate')))
sys.path[:0]=[str(HERE.parent/'candidate'),str(Path.cwd()/'tests/sandbox')]
