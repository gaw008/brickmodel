"""Analytic-liquid seam only; actual storage/pressure/gas/chemical framework."""
from dataclasses import replace
from fractions import Fraction as F
import math
import pytest
from test_mass_wet_storage import setup as storage_setup
from test_mass_storage_bridge import REPOSITORY,MO,MN,R
from sludge_sandbox.mass_wet_transport import WetPair,WetFace,integrate_wet_pair
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.phase_storage import InversePolicy


def setup(monkeypatch):
    st,initial,calls=storage_setup(monkeypatch)
    old=WaterProperties.state_tp
    def manufactured_liquid(w,t,p,*,phase):
        raw=old(w,t,p,phase=phase)
        # Test-only adapter supplies a declared analytic liquid to the strict
        # chemical framework. No real-fluid thermodynamic evidence is claimed.
        entropy=(75*math.log(t/300)+75)/w.reference.molar_mass_kg_mol
        return replace(raw,native_entropy_j_kg_k=entropy,method_id='iapws95_real_fluid_helmholtz')
    monkeypatch.setattr(WaterProperties,'state_tp',manufactured_liquid)
    chemical=WaterChemicalPotential(REPOSITORY/'data/sandbox/water')
    face=WetFace(.01,(.05,.05),(.5,.7),(1e-5,2e-5,1.5e-5),1e-13,1.8e-5,('manufactured-wet-face',))
    pair=WetPair((st,st),(InversePolicy(1e-6,1e-6,100),)*2,chemical,(.2,.2),(.2,.2),(1e-8,1e-8),('manufactured-reaction-phase-coefficients',),face)
    a=replace(initial,internal_energy_j=st.evaluate(initial,305.).total_internal_energy_j)
    b=st.state((.007,.002),.18,(.08,.25,.07),0.)
    b=replace(b,internal_energy_j=st.evaluate(b,310.).total_internal_energy_j)
    return pair,(a,b)


def totals(pair,states):
    st=pair.storages[0];net=st.reference.network;out=[F() for _ in net.elements];mass=F();water=F()
    mw=F(st.water.reference.molar_mass_kg_mol)
    for s in states:
        values=[*map(F,s.solid_mass_kg),*(F(n)*F(st.fluid_template.gas_phases[k].molar_mass_kg_mol) for k,n in zip(st.gas_ids,s.gas_amounts_mol))]
        values[-1]+=F(s.liquid_water_mol)*mw;mass+=sum(values)
        for v,c in zip(values,net.components):
            for i,w in enumerate(c.element_mass_fractions):out[i]+=v*w
        water+=F(s.liquid_water_mol)+F(s.gas_amounts_mol[2])
    return tuple(out),mass,water,sum(F(s.internal_energy_j) for s in states)


def test_positive_liquid_coupled_prefixes(monkeypatch):
    pair,initial=setup(monkeypatch);original=totals(pair,initial)
    observation=pair.evaluate(initial)
    assert observation.cells[0].phase_water_mol_s>0 and observation.cells[1].phase_water_mol_s<0
    for count in (4,8):
        run=integrate_wet_pair(pair,initial,duration_s=.01,steps=count)
        assert run.status=='completed',run.reason
        cs=[[F(),F()] for _ in range(2)];cg=[[F(),F(),F()] for _ in range(2)];cl=[F(),F()];ce=[F(),F()]
        for states,obs,l in zip(run.states[1:],run.observations,run.ledgers):
            el,m,w,e=totals(pair,states)
            assert max(abs(a-b) for a,b in zip(el,original[0]))<F(2e-15)
            assert abs(m-original[1])<F(2e-15) and abs(w-original[2])<F(2e-15)
            assert abs(e-original[3])<F(2e-10)
            assert obs.conduction_w!=0 and any(v!=0 for v in obs.exchange.advective_mol_s.values())
            assert any(v!=0 for v in obs.exchange.diffusive_mol_s.values())
            assert all(c.entropy_production_w_k>=0 for c in obs.cells)
            for i,sign in enumerate((-1,1)):
                cl[i]-=F(l.phase_water_mol[i]);ce[i]+=sign*F(l.face_energy_j)
                assert abs(F(states[i].liquid_water_mol)-F(initial[i].liquid_water_mol)-cl[i])<F(1e-15)
                assert abs(F(states[i].internal_energy_j)-F(initial[i].internal_energy_j)-ce[i])<F(1e-10)
                for j in range(2):
                    cs[i][j]+=F(l.solid_kg[i][j])
                    assert abs(F(states[i].solid_mass_kg[j])-F(initial[i].solid_mass_kg[j])-cs[i][j])<F(1e-16)
                for j in range(3):
                    cg[i][j]+=F(l.chemical_gas_mol[i][j])+sign*F(l.face_mol[j])+(F(l.phase_water_mol[i]) if j==2 else 0)
                    assert abs(F(states[i].gas_amounts_mol[j])-F(initial[i].gas_amounts_mol[j])-cg[i][j])<F(1e-15)
                assert l.chemical_gas_mol[i][2]==0 and states[i].liquid_water_mol>0
            assert abs(F(l.face_energy_j)-F(l.conduction_j)-sum(map(F,l.diffusive_enthalpy_j))-sum(map(F,l.advective_enthalpy_j)))<F(1e-12)
        assert run.evaluations_attempted==run.evaluations_completed==3*count
        assert run.times_s[-1]==F(.01)


def test_zero_oxygen_and_failure_prefix(monkeypatch):
    pair,initial=setup(monkeypatch);st=pair.storages[0]
    states=[]
    for s in initial:
        p=replace(s,gas_amounts_mol=(0.,s.gas_amounts_mol[1],s.gas_amounts_mol[2]))
        states.append(replace(p,internal_energy_j=st.evaluate(p,305.).total_internal_energy_j))
    obs=pair.evaluate(tuple(states));assert all(c.extent_kg_s==0 for c in obs.cells)
    run=integrate_wet_pair(pair,initial,duration_s=10000.,steps=1)
    assert run.status=='failed' and run.states==(initial,) and not run.ledgers
    stopped=integrate_wet_pair(pair,initial,duration_s=.01,steps=4,cancel=lambda:True)
    assert stopped.status=='cancelled' and stopped.evaluations_attempted==0 and stopped.states==(initial,)


def test_source_change_and_undeclared_dry_refused(monkeypatch):
    pair,states=setup(monkeypatch)
    with pytest.raises(ValueError,match='positive_liquid_segment_only'):pair.evaluate((replace(states[0],liquid_water_mol=0.),states[1]))
    object.__setattr__(pair,'transfer_coefficients_mol_s_pa',(2e-8,1e-8))
    with pytest.raises(ValueError,match='wet_pair_source_changed'):pair.evaluate(states)
