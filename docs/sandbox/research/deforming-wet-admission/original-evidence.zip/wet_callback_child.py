from pathlib import Path
from dataclasses import replace
from decimal import Decimal,localcontext
from fractions import Fraction as F
import json,time,traceback
import numpy as np
from test_solid_fluid_heat import solid_host
from test_water_phase_transfer import transfer,DATA
from sludge_sandbox.water_properties import load_water_properties
from sludge_sandbox.ideal_water_vapor import IdealWaterVapor
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.geometry import ReferenceSlab
from sludge_sandbox.deformation_program import PrescribedSlabMotion
from sludge_sandbox.skeleton_energy import DiagonalSkeletonEnergy
from sludge_sandbox.deforming_solid_storage import DeformingSolidStorage,DeformationErrorBounds,solid_provider_identity
from sludge_sandbox.deforming_solid_heat import DeformingSolidHeat
r=Path(__file__).resolve().parent;started=time.monotonic();result={'attempt_id':'source-matched-wet-callback-01'}
try:
    ingredients=(load_water_properties(DATA),IdealWaterVapor(DATA),WaterChemicalPotential(DATA))
    base=solid_host(ingredients)
    reference=ReferenceSlab(half_thickness_m=.01,reference_area_m2=.01,cells=1)
    motion=PrescribedSlabMotion(reference=reference,knot_times_s=(0.,1.),
        normal_stretches_at_knots=((1.,),(.9,)),tangential_stretches_at_knots=(1.,.9),
        motion_id='manufactured-wet-callback-motion',version='1',classification='manufactured_test_fixture',
        source_ids=('manufactured-wet-callback-motion',),source_asset_sha256=())
    skeleton=DiagonalSkeletonEnergy(reference=reference,cell_index=0,fixed_solid_inventory_mol=(('fixture_solid',2.),),
        solid_provider_identity=solid_provider_identity(base.storages[0].solid_phases),bulk_modulus_pa=1000.,
        shear_modulus_pa=400.,viscosity_pa_s=3.,interface_energy_j_m2=.5,reference_interface_area_m2=.003,
        stretch_range=(.5,2.),maximum_absolute_log_rate_per_s=2.,model_id='manufactured-wet-callback-skeleton',version='1',
        source_ids=('manufactured-wet-callback-skeleton',),classification='manufactured_test_fixture',allow_manufactured=True)
    point=DeformingSolidStorage(template=base.storages[0],motion=motion,skeleton=skeleton,
        error_bounds=DeformationErrorBounds((0.,1.),0.,0.,('manufactured-callback-extra-bounds',),'conditional_declared_not_material_admission'),
        model_id='manufactured-wet-callback-point',version='1',allow_manufactured=True)
    host=DeformingSolidHeat(base_model=base,point_storages=(point,),
        mechanical_regime='prescribed_cellwise_quasistatic_incompressible_skeleton',
        transport_regime='manufactured_relative_moving_faces',model_id='manufactured-wet-callback-host',version='1',
        source_ids=('manufactured-wet-callback-host',),allow_manufactured=True)
    op=transfer(ingredients,base_model=host)
    state=host.state_from_temperatures([[2.,1e-8,1e-4,.001]],[300.],time_s=.5)
    calls=[];old=DeformingSolidStorage.temperature_from_total_energy
    def counted(self,*a,**k):calls.append(1);return old(self,*a,**k)
    DeformingSolidStorage.temperature_from_total_energy=counted
    out=op.evaluate(state,.5)
    DeformingSolidStorage.temperature_from_total_energy=old
    assert len(calls)==1
    baseout=out.base_evaluation;closed=baseout.storage_states[0];m=closed.mechanical;cell=out.cell_transfers[0]
    chemistry=ingredients[2]
    # Independent assembly from source-linked mu at standard pressure; do not
    # use callback equilibrium pressure or call its equilibrium helper as oracle.
    liquid=chemistry.liquid_tp(m.temperature_k,m.liquid_pressure_pa)
    standard=chemistry.ideal_vapor(m.temperature_k,chemistry.reference_pressure_pa)
    with localcontext() as ctx:
        ctx.prec=60
        D=Decimal.from_float
        peq=float(D(chemistry.reference_pressure_pa)*((D(liquid.chemical_potential_j_mol)-D(standard.chemical_potential_j_mol))/(D(chemistry.gas_constant_j_mol_k)*D(m.temperature_k))).exp())
    pv=float(F(float(state.amounts_mol[0,1]))*F(chemistry.gas_constant_j_mol_k)*F(m.temperature_k)/F(m.gas_volume_m3))
    expected=float(F(1e-7)*(F(peq)-F(pv)))
    assert abs(peq-cell.equilibrium.equilibrium_partial_pressure_pa)<=1e-6
    assert abs(expected-cell.rate_mol_s)<=1e-13 and cell.rate_mol_s>0
    difference=out.rates.reaction_species_mol_s-baseout.rates.reaction_species_mol_s
    assert difference[0,2]==-cell.rate_mol_s and difference[0,1]==cell.rate_mol_s
    assert difference[0,0]==difference[0,3]==0 and F(float(difference[0,1]))+F(float(difference[0,2]))==0
    assert np.array_equal(out.rates.cell_power_w,baseout.rates.cell_power_w)
    assert set(out.rates.cell_power_components_w)=={'elastic','interface','dissipation','pore','body'}
    for key in out.rates.cell_power_components_w:assert np.array_equal(out.rates.cell_power_components_w[key],baseout.rates.cell_power_components_w[key])
    assert state.energy_model_identity==host.energy_model_identity
    assert baseout.storage_inverses[0] is baseout.total_inverses[0].thermal_inverse
    assert baseout.storage_inverses[0].temperature_error_bound_k==baseout.total_inverses[0].temperature_error_bound_k
    assert baseout.current_host.storages[0] is baseout.total_inverses[0].state.current_storage
    assert baseout.current_host.transport.face_area_m2==float(baseout.motion.current.face_areas_m2[0])
    result.update(status='passed',temperature_k=m.temperature_k,liquid_pressure_pa=m.liquid_pressure_pa,
        gas_volume_m3=m.gas_volume_m3,peq_independent_pa=peq,peq_callback_pa=cell.equilibrium.equilibrium_partial_pressure_pa,
        vapor_pressure_pa=pv,rate_mol_s=cell.rate_mol_s,rate_independent_mol_s=expected,
        source_difference_mol_s=difference.tolist(),cell_power_w=out.rates.cell_power_w.tolist(),
        components_w={k:v.tolist() for k,v in out.rates.cell_power_components_w.items()},total_inverse_calls=len(calls),
        current_area_m2=baseout.current_host.transport.face_area_m2,current_width_m=baseout.current_host.transport.cell_widths_m[0],
        source_ids=out.source_ids,energy_model_identity=state.energy_model_identity,
        inverse_temperature_error_k=baseout.total_inverses[0].temperature_error_bound_k,
        inverse_policy=vars(base.transport.inverse_policy),chemical_method=chemistry.method_id,
        source_assets=dict(chemistry.source_asset_sha256),qualification='one_source_matched_nonzero_K_callback_not_trajectory_not_entropy_certificate')
except Exception as exc:
    result.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
finally:
    result['elapsed_s']=time.monotonic()-started
    (r/'wet-callback-01-result.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
    print(json.dumps(result,default=str))
