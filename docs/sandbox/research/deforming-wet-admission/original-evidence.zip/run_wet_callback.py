from pathlib import Path
import subprocess,os,time,json,hashlib
r=Path(__file__).resolve().parent;repo=Path('/Users/wanggaoying/Desktop/brickmodel-github')
files=list((r/'candidate/sludge_sandbox').glob('*.py'))+[r/'wet_callback_plan.json',r/'wet_callback_child.py']+list((repo/'data/sandbox/water').rglob('*'))
files=[p for p in files if p.is_file()]
def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
before=hashes();(r/'wet-callback-01-input-hashes.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ,PYTHONPATH=f'{r}/candidate:{repo}/tests/sandbox')
started=time.monotonic()
with (r/'wet-callback-01.log').open('w') as log:
    try:
        process=subprocess.run([str(repo/'.venv/bin/python'),str(r/'wet_callback_child.py')],cwd=repo,env=env,
            stdout=log,stderr=subprocess.STDOUT,timeout=30)
        result={'status':'finished','returncode':process.returncode}
    except subprocess.TimeoutExpired:result={'status':'resource_limit','reason':'external_30_second_limit'}
result.update(attempt_id='source-matched-wet-callback-01',elapsed_s=time.monotonic()-started,source_hashes_unchanged=before==hashes())
(r/'wet-callback-01-status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
