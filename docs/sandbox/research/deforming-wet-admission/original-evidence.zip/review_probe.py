from dataclasses import replace
import json
from test_admission import wrapped
from sludge_sandbox.water_properties import load_water_properties,WaterProperties
from pathlib import Path
w=load_water_properties(Path('data/sandbox/water'))
WaterProperties.state_tp=lambda *a,**k:(_ for _ in ()).throw(AssertionError('EOS forbidden'))
proto=wrapped(w);p=proto.base_model.point_storages[0]
p=replace(p,error_bounds=replace(p.error_bounds,additional_mechanical_energy_error_j=1e-7))
op=replace(proto,base_model=replace(proto.base_model,point_storages=(p,)))
s=op.base_model.state_from_temperatures([[0.,.01,2.]],[300.],time_s=.5)
e=op.evaluate(s,.5);inv=e.base_evaluation.total_inverses[0]
assert e.storage_inverses[0] is inv.thermal_inverse
assert inv.thermal_inverse.target_energy_error_bound_j>=1e-7
assert e.storage_inverses[0].temperature_error_bound_k==inv.temperature_error_bound_k
try:proto._check_state(s)
except ValueError:pass
else:raise AssertionError('changed mechanical-error identity accepted')
# Independent program values at two internal knots, actual current geometry.
program=replace(op.program,gas_temperature_k=(310.,320.,340.,350.))
op=replace(op,program=program)
rows=[]
for t,Tgas in ((.25,320.),(.75,340.)):
 s=op.base_model.state_from_temperatures([[0.,.01,2.]],[300.],time_s=t)
 e=op.evaluate(s,t);m=e.base_evaluation.motion
 A=float(m.current.face_areas_m2[0]);d=float(m.current.widths_m[0])
 exact=A*(Tgas-300)/(d/2+1/20)
 assert abs(e.conductive_into_cell_w-exact)<=1e-8
 rows.append({'time':t,'boundary_T':e.boundary.gas_temperature_k,'actual_area':A,'actual_width':d,'heat_error':e.conductive_into_cell_w-exact})
assert op.breakpoints_s(0.,1.)==(.25,.75)
print(json.dumps({'mechanical_error_j':1e-7,'propagated_target_error_j':inv.thermal_inverse.target_energy_error_bound_j,'temperature_error_bound_k':inv.temperature_error_bound_k,'two_program_nodes':rows,'status':'passed_no_EOS'},indent=2))
