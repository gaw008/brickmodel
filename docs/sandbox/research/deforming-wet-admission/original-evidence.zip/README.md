# Isolated explicit deforming wet-host admission candidate

2026-09-07. Only three candidate modules changed: deforming_solid_heat.py, programmed_solid_fluid_heat.py and water_phase_transfer.py. No repository source/test edits, water EOS runs or trajectory integrations were performed. The original implementations are retained under baseline/. The complete dependency snapshot under candidate/sludge_sandbox is for reproducible imports; only the three listed files are proposed changes.

## Actual verification and preserved failures

- red.log: initial test-fixture mistake, SurfacePolicy was passed positional arguments despite its existing keyword-only API. Corrected the fixture without changing policy values.
- feature-red.log: meaningful preimplementation RED, exact old ProgrammedSolidFluidHeat constructor rejects DeformingSolidHeat.
- attempt01.log: 1 failed,2 passed; the duplicate-boundary fixture omitted required source identity for its already-present Dirichlet boundary. Added its explicit manufactured source; no guard was weakened.
- attempt02.log: 6 passed in0.39 s.
- final.log/final.xml: **7 passed in0.38 s** after adding actual motion-domain rejection and the exact AST source-policy comparison. These are lightweight no-EOS tests. No real evaporation or wet trajectory result is claimed.

Command: `PYTHONPATH=/private/tmp/brick-deforming-wet-admission/candidate:tests/sandbox .venv/bin/python -m pytest /private/tmp/brick-deforming-wet-admission/tests -q --junitxml=/private/tmp/brick-deforming-wet-admission/final.xml` from repository root, stdout/stderr redirected to final.log. final-manifest.json records all proposed source/test/output hashes and original baseline hashes.

## What actually executes

The dry boundary test constructs an actual DeformingSolidHeat with source-gated water container and manufactured solid/ideal-gas thermal laws. water.state_tp is forbidden. It counts one total inverse and checks original inverse/error object projections. At lambda=.95, reference A=.014 and width=.01, actual A=.014*.95² and width=.01*.95 determine an independent half-cell-plus-convection oracle. Nonzero gas influx uses independent fixture donor h=30*320; the resulting exterior energy combines enthalpy and heat exactly once. Five mechanical power components and the total state identity are retained.

Knot tests cover the actual union of different motion and boundary knots and independently reject a requested interval outside either domain. Wrong exact host type, lost total tag, missing source IDs, manufactured opt-in and existing boundary guards remain active.

The direct/programmed WaterPhaseTransfer routing cases use K=0 and an explicitly constructor-bypassed UNUSED chemical sentinel. They exercise the actual wrapper methods and real dry total storage, but do not certify chemical-source admission. A manufactured H2O caloric is deliberately rejected when K becomes nonzero. This is not a replacement for a real source-gated active water-phase test. The unchanged active matching loop (including JoinedWaterVapor.low_model), evaluate, dry diagnostic and mode-switch method are independently compared as AST against the retained pre-admission source, demonstrating no edits to phase source, latent-heat or strict/metastable logic.

A separate actual old fixed-solid ProgrammedSolidFluidHeat.evaluate AST is executed on the same valid dry fixture. Old versus new face/species/reaction/power arrays are exactly equal, None components stay None, and old boundary-only knots are unchanged.

## Runtime and scientific qualification

The new program branch uses current_host.transport from the SAME returned total inverse context for actual area, distance, reservoir exchange and enthalpy. It does not call another inverse, forge a thermal state from total E or replace original inverse errors. Evaluation projections preserve original thermal inverse object/state semantics, with total inverses separately retained.

Water configuration lookup explicitly unwraps admitted program/deforming types only for identity and inventory access. Actual execution/checking still uses the canonical total-energy host. No generic duck-typed admission was introduced. Water contribution remains liquid/H2O-gas source only; power components are copied unchanged. No depletion source change was needed because its current explicit WaterPhaseTransfer adapter already consumes these projections.

Actual active wet source callbacks, wet dynamics, entropy and wet depletion continuation remain UNVERIFIED for this new admitted composition. They require the independently costed source-gated tests described in DESIGN.md. These no-EOS cases must not be cited as a completed wet simulation or free-sintering validation.

## Unique real source-matched wet callback attempt01: FAILED

Following separate root authorization, exactly ONE actual nonzero-K callback subprocess was executed, with an external30 s limit. `wet_callback_plan.json` froze inputs/gates. It used actual source-loaded water, IdealWaterVapor and WaterChemicalPotential, the real solid_host/transfer helpers, fixed Ns2, NL1e-4, gas-water1e-8 and tracer.001 mol, T300 K initialized at t=.5 of prescribed isotropic compression. K retained the helper's1e-7 mol/(s Pa). No trajectory integration was called.

`wet-callback-01-status.json`: subprocess exited0 after1.237679834 s, source hashes unchanged. **That process exit is NOT a successful scientific check.** `wet-callback-01-result.json` records `status=failed`, RigidFluidHeatError, `cell_available_volume_exceeds_bulk_or_unresolvable_width`, after0.815337416 s of child execution. The unique failure traceback and original output are retained; no retry was made.

The observed failure occurs after the current total-inverse tuple has been computed, while reconstructing current transport. The retained `current_storage` changes bulk volume but keeps its original `fluid_template.mechanical.available_pore_volume_m3`. For this legitimate fixture the reference fluid capacity is1e-4 m3, whereas current bulk is8.57375e-5 m3. The transport constructor correctly rejects that incompatible configuration. The earlier dry fixture's larger reference bulk did not expose this limit. Closing current thermodynamics does not by itself update the transport configuration identity/context.

This attempt did NOT reach water-transfer chemistry or independently computed peq/r assertions. It therefore proves neither nonzero-K wet callback correctness nor latent-heat/phase bookkeeping for the new composition. The candidate requires a physically consistent current fluid-template context before it can pass this actual admission check; the guard must not be disabled, the source fixture must not be changed merely to avoid it, and no second inverse should be introduced as a workaround.

`wet-callback-01-input-hashes.json` records candidate Python sources, the child and input plan, and water source files before launch; the outer supervisor checked their hashes again after the process. Candidate source and qualification text were left unchanged. In particular, the old conservative `not_wrapper_admitted` label was not replaced by a wet-runtime success claim after this failure. Root was notified immediately. All further implementation or runs require a separately bounded task.


## Current-pore context repair after callback attempt 01

The actual callback failure was reproduced without water EOS: `pore-red.log/xml`
record one failed test (0.39 s), the identical available-volume guard. Before
editing, all three admission modules and point storage were copied verbatim to
`pre-pore-fix/`, with hashes. Only `candidate/sludge_sandbox/deforming_solid_storage.py`
changed in this repair; the three admission sources stayed byte-identical.

`_prepare` now attaches a fluid template whose mechanical available volume is
Fraction(current bulk) minus the fixed solid inventory times its intrinsic
molar volume. The resulting current storage is the actual inverse context and
is shared by current host/transport. Reference objects are unchanged. Existing
SolidFluidStorage still computes volume from bulk minus solids independently;
it does not subtract solids from the template's available volume, so there is
no double subtraction. Its original volume uncertainty propagation and positive
available-volume refusal remain untouched; no additional inverse is called.

`pore-green.log/xml` records 8 passed in 0.36 s. Additional domain refusal
coverage (negative pore and error excluding positive pore) produced
`pore-final.log/xml`: 9 passed in 0.38 s. All are dry/no-EOS and under the 10 s
budget. The final regression checks same current storage/template identity,
actual gas volume, unchanged reference/envelope, and exactly one total inverse.
No wet callback retry or integration was executed. Attempt 01 remains failed;
this repair has not yet demonstrated successful active wet chemistry admission.
The old conservative qualification string is unchanged.
