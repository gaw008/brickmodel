import sys,json,time,signal,hashlib,platform,importlib.metadata as md,cProfile,pstats,io
from pathlib import Path
signal.signal(signal.SIGALRM,lambda *a: (_ for _ in ()).throw(TimeoutError('30 second cap')))
signal.alarm(30)
t0=time.perf_counter()
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
sys.path.insert(0,str(ROOT/'src'))
import CoolProp, CoolProp.CoolProp as CP
from iapws import IAPWS95
from sludge_sandbox.water_properties import load_water_properties
outdir=Path(__file__).parent
water=load_water_properties(ROOT/'data/sandbox/water')
a=CoolProp.AbstractState('HEOS','Water')
fluid=json.loads(CP.get_fluid_param_string('Water','JSON'))
(outdir/'coolprop-water-fluid.json').write_text(json.dumps(fluid,indent=2))
rows=[]
for p in (304469.31354,567435.65536):
    raw=IAPWS95(T=300,P=p/1e6)
    r=water.state_tp_response(300,p,phase='liquid')
    a.update(CP.PT_INPUTS,p,300)
    names=['rho','h','u','s','cp','cv','alpha','kappa','dv_dT','dv_dP','du_dP']
    old=[raw.rho,raw.h*1000,raw.u*1000,raw.s*1000,raw.cp*1000,raw.cv*1000,r.thermal_expansion_k_inverse,r.isothermal_compressibility_pa_inverse,r.molar_dv_dt_m3_mol_k,r.molar_dv_dp_m3_mol_pa,r.molar_du_dp_j_mol_pa]
    v=a.molar_mass()/a.rhomass(); al=a.isobaric_expansion_coefficient();ka=a.isothermal_compressibility()
    new=[a.rhomass(),a.hmass(),a.umass(),a.smass(),a.cpmass(),a.cvmass(),al,ka,v*al,-v*ka,a.first_partial_deriv(CP.iUmolar,CP.iP,CP.iT)]
    rows.append(dict(T=300,P=p,phase=int(a.phase()),is_liquid=a.phase()==CP.iphase_liquid,values={k:dict(iapws=x,coolprop=y,difference=y-x,relative_difference=(y-x)/x) for k,x,y in zip(names,old,new)},h_u_pv_residual=a.hmass()-a.umass()-p/a.rhomass()))
a.update(CP.QT_INPUTS,0,300); psat=a.p()
pair=water.saturation_pair(300)
def bench(fun,n):
    start=time.perf_counter()
    for i in range(n): fun((304469.31354,567435.65536)[i%2])
    return dict(n=n,total_s=time.perf_counter()-start)
def cp(p):
    a.update(CP.PT_INPUTS,p,300)
    return (a.rhomass(),a.hmass(),a.umass(),a.smass(),a.cpmass(),a.cvmass(),a.isobaric_expansion_coefficient(),a.isothermal_compressibility())
timings={'iapws_raw':bench(lambda p:IAPWS95(T=300,P=p/1e6),20),'water_validated_response':bench(lambda p:water.state_tp_response(300,p,phase='liquid'),20),'coolprop_unimposed_HEOS_response':bench(cp,1000)}
prof=cProfile.Profile();prof.enable();water.state_tp_response(300,304469.31354,phase='liquid');prof.disable()
buf=io.StringIO();pstats.Stats(prof,stream=buf).sort_stats('cumulative').print_stats(25);(outdir/'profile.txt').write_text(buf.getvalue())
for key,val in timings.items():val['seconds_per_call']=val['total_s']/val['n']
result=dict(scope='two liquid points feasibility only; no production backend substitution; no reference shifts; timings exclude imports',versions={k:md.version(k) for k in ('CoolProp','iapws','numpy','scipy')},python=sys.version,platform=platform.platform(),coolprop_git=CP.get_global_param_string('gitrevision'),constants=dict(coolprop_R_molar=a.gas_constant(),coolprop_M=a.molar_mass(),iapws_R_molar=water.reference.native_molar_gas_constant_j_mol_k,iapws_M=water.reference.molar_mass_kg_mol),psat=dict(coolprop=psat,iapws=pair.pressure_pa),points=rows,timings=timings,wall_s=time.perf_counter()-t0,hashes={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in (Path(__file__),ROOT/'src/sludge_sandbox/water_properties.py')})
(outdir/'result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
