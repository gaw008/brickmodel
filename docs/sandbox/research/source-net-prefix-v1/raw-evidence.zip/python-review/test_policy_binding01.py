"""Independent evidence probes for source-prefix numerical-policy binding."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.source_net_prefix import build_source_prefix
from test_source_net_prefix import POLICY, bound, remap
from test_source_net_panel import panel, sample


def test_caller_policy_mutation_cannot_silently_rewrite_saved_budget():
    policy = replace(POLICY)
    original = policy.energy_absolute_tolerance_j
    out = build_source_prefix(panel(), T(F(1, 4)), policy=policy)
    object.__setattr__(policy, 'energy_absolute_tolerance_j', original*10)
    if out.policy.energy_absolute_tolerance_j == original:
        # An independent policy snapshot is an equally valid protection.
        out.check()
    else:
        with pytest.raises(ValueError):
            out.check()


def test_saved_policy_mutation_invalidates_prefix_even_if_values_stay_in_budget():
    out = build_source_prefix(panel(), T(F(1, 4)), policy=replace(POLICY))
    object.__setattr__(out.policy, 'amount_absolute_tolerance_mol', 1.)
    with pytest.raises(ValueError):
        out.check()


def test_replacing_only_saved_policy_cannot_relabel_original_evidence():
    out = build_source_prefix(panel(), T(F(1, 4)), policy=replace(POLICY))
    changed = replace(out, policy=replace(POLICY, maximum_steps=40))
    with pytest.raises(ValueError):
        changed.check()


def test_source_diagnostic_face_identifier_rejects_bool_alias():
    def changed(s):
        faces = list(s.evaluation.source_evaluation.faces)
        faces[1] = replace(faces[1], face_id=True)
        return remap(s, faces=faces)
    saved = bound(changed(sample(F())), changed(sample(F(1, 2), role='interior')))
    with pytest.raises(ValueError):
        build_source_prefix(saved, T(F(1, 4)), policy=replace(POLICY))
