"""Independent typed aggregate-evidence and numerical-qualification probes."""
from dataclasses import replace
from fractions import Fraction as F
import pytest
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.source_net_prefix import build_source_prefix, audit_source_prefixes
from test_source_net_prefix import POLICY
from test_source_net_panel import panel


@pytest.mark.parametrize('field,value', [
    ('qualification', 'physical_stage_accepted'),
    ('state_roundoff_mol', (F(),)),
    ('state_roundoff_j', (0.,)*3),
    ('full_residual_mol', (False,)*12),
    ('full_residual_j', (0,)*3),
    ('liquid_direction_reversal_faces', (True,)),
    ('policy_binding', ()),
])
def test_typed_prefix_and_qualification_fields_rebuild(field, value):
    prefix = build_source_prefix(panel(), T(F(1, 4)), policy=replace(POLICY))
    changed = replace(prefix, **{field: value})
    with pytest.raises(ValueError):
        changed.check()


@pytest.mark.parametrize('field,value', [
    ('qualification', 'accepted_trajectory'),
    ('cumulative_exact_inventory_exchange_mol', (F(),)*12),
    ('cumulative_exact_energy_exchange_j', (F(),)*3),
    ('full_inventory_residual_mol', (0,)*12),
    ('full_energy_residual_j', (False,)*3),
    ('inventory_residual_mol', (0.,)*12),
    ('energy_residual_j', (0,)*3),
    ('prefixes', []),
])
def test_cumulative_exact_records_types_and_qualification_are_rechecked(field, value):
    prefix = build_source_prefix(panel(), T(F(1, 4)), policy=replace(POLICY))
    audit = audit_source_prefixes((prefix,))
    changed = replace(audit, **{field: value})
    with pytest.raises(ValueError):
        changed.check()


def test_negative_internal_energy_reference_is_not_a_positivity_gate():
    from test_source_net_prefix import bound, remap
    from test_source_net_panel import sample, ENERGY
    from sludge_sandbox.integration import ConservedState
    def shifted(s):
        return remap(s, state=ConservedState(s.state.amounts_mol,
                     s.state.internal_energy_j-200., ENERGY))
    positive = build_source_prefix(panel(), T(F(1, 4)), policy=replace(POLICY))
    negative = build_source_prefix(bound(shifted(sample(F())),
                    shifted(sample(F(1, 2), role='interior'))),
                    T(F(1, 4)), policy=replace(POLICY))
    assert negative.full_residual_j == positive.full_residual_j
    assert negative.minima == positive.minima
    assert (negative.raw_state.internal_energy_j < 0).all()
    negative.check()
