"""Check that original state and rate arrays retain the declared f64 schema."""
from dataclasses import replace
from fractions import Fraction as F
import numpy as np
import pytest
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.source_net_prefix import build_source_prefix
from test_source_net_prefix import POLICY
from test_source_net_panel import panel


@pytest.mark.parametrize('role', ['first', 'interior'])
@pytest.mark.parametrize('field', ['amounts_mol', 'internal_energy_j'])
def test_state_array_dtype_mutation_cannot_hide_behind_equal_list_values(role, field):
    saved = panel()
    state = getattr(saved, role).state
    original = getattr(state, field)
    changed = original.astype(np.float32)
    assert original.tolist() == changed.tolist()
    object.__setattr__(state, field, changed)
    with pytest.raises(ValueError):
        build_source_prefix(saved, T(F(1, 4)), policy=replace(POLICY))


@pytest.mark.parametrize('role', ['first', 'interior'])
@pytest.mark.parametrize('field', ['face_species_mol_s', 'face_energy_w',
                                   'reaction_species_mol_s', 'cell_power_w'])
def test_rate_array_dtype_mutation_cannot_hide_behind_equal_list_values(role, field):
    saved = panel()
    rates = getattr(saved, role).evaluation.rates
    original = getattr(rates, field)
    changed = original.astype(np.float32)
    assert original.tolist() == changed.tolist()
    object.__setattr__(rates, field, changed)
    with pytest.raises(ValueError):
        build_source_prefix(saved, T(F(1, 4)), policy=replace(POLICY))
