from fractions import Fraction as F
from dataclasses import replace
from test_source_net_prefix import POLICY,bound,remap
from test_source_net_panel import sample
from sludge_sandbox.source_net_prefix import build_source_prefix,audit_source_prefixes
from sludge_sandbox.exact_event_clock import ExactEventTime as T
h=F(2**54+1,2**54);policy=replace(POLICY,amount_absolute_tolerance_mol=1.5)
def build(start,state=None):
 a=sample(start,liquid_faces=(0.,float(2**54),0.,0.),liquid=float(2**56))
 b=sample(start+h/2,liquid_faces=(0.,float(2**54),0.,0.),liquid=float(2**56),role='interior')
 if state is not None:a=remap(a,state=state);b=remap(b,state=state)
 return build_source_prefix(bound(a,b,upper=start+h),T(start+h),policy=policy)
a=build(F());b=build(h,a.raw_state);audit=audit_source_prefixes((a,b))
print('perprefix full residual cell0',a.full_residual_mol[0],b.full_residual_mol[0])
print('audit accepted represented residual cell0',audit.inventory_residual_mol[0])
print('cumulative full exact residual',a.full_residual_mol[0]+b.full_residual_mol[0],'budget',policy.amount_absolute_tolerance_mol)
