"""Independent Fraction oracle; no project imports."""
from fractions import Fraction as F
import json,time
from pathlib import Path
checks=0
def ck(v):
    global checks
    checks+=1
    assert v
h,hm=F(1,3),F(1,5)
def integral(a,b):return a*h+(b-a)*h*h/(2*hm)
def minimum(n,r,q,H):
    c=[(n,F()),(n+r*H+q*H*H,H)]
    if q>0 and 0 < -r/(2*q) < H:
        t=-r/(2*q);c.append((n+r*t+q*t*t,t))
    return min(c)
t0=time.monotonic()
# Exact rate values can all be represented as binary64.
f0=[[F((i+1)*(j+1),128)*(-1 if i==2 else 1) for j in range(4)] for i in range(4)]
fm=[[x*F(3,2) for x in row] for row in f0]
for i in (0,3): f0[i][0]=fm[i][0]=F()
u0=[F(3,8),F(-5,4),F(7,8),F(-1,8)];um=[x*F(5,4) for x in u0]
phase=[F(1,256),F(-3,256),F(5,256)]
face=[[integral(a,b) for a,b in zip(x,y)] for x,y in zip(f0,fm)]
energy=[integral(a,b) for a,b in zip(u0,um)]
local=[[-integral(p,p*2),F(),F(),integral(p,p*2)] for p in phase]
initial=[[F(1) for _ in range(4)] for _ in range(3)];initialU=[F(1024+i) for i in range(3)]
state=initial;U=initialU;cum=[[F() for _ in range(4)] for _ in range(3)];cumU=[F()]*3;sumstate=[[F() for _ in range(4)] for _ in range(3)];sumstateU=[F()]*3;resources=F();globalrecords=[]
for step in range(2):
    ff=[[F(float(x)) for x in row] for row in face];ll=[[F(float(x)) for x in row] for row in local];ee=[F(float(x)) for x in energy]
    new=[];newU=[];res=[];resU=[]
    for i in range(3):
        row=[];rr=[]
        ck(ll[i][0]+ll[i][3]==0)
        for j in range(4):
            exact=state[i][j]+face[i][j]-face[i+1][j]+local[i][j]
            represented=state[i][j]+ff[i][j]-ff[i+1][j]+ll[i][j]
            out=F(float(represented));estate=out-represented
            eface=(ff[i][j]-face[i][j])-(ff[i+1][j]-face[i+1][j])+(ll[i][j]-local[i][j])
            ck(out-exact==eface+estate);row.append(out);rr.append(out-exact)
            cum[i][j]+=ff[i][j]-ff[i+1][j]+ll[i][j]
            sumstate[i][j]+=estate
            ck(out-initial[i][j]-cum[i][j]==sumstate[i][j])
            resources+=abs(estate)+abs(eface)
        new.append(row);res.append(rr)
        exact=U[i]+energy[i]-energy[i+1];rep=U[i]+ee[i]-ee[i+1];out=F(float(rep))
        ck(out-exact==(ee[i]-energy[i])-(ee[i+1]-energy[i+1])+out-rep)
        newU.append(out);resU.append(out-exact);cumU[i]+=ee[i]-ee[i+1];sumstateU[i]+=out-rep
        ck(out-initialU[i]-cumU[i]==sumstateU[i])
    for slots in ((1,),(2,),(0,3)):
        change=sum((new[i][j]-state[i][j] for i in range(3) for j in slots),F())
        boundary=sum((face[0][j]-face[3][j] for j in slots),F())
        ck(change==boundary+sum((res[i][j] for i in range(3) for j in slots),F()))
    ck(sum(newU)-sum(U)==energy[0]-energy[3]+sum(resU))
    globalrecords.append({'water_residual':str(sum(res[i][j] for i in range(3) for j in (0,3))),'energy_residual':str(sum(resU))})
    state,U=new,newU
# Negative scientific/domain controls and exact near-cancellation counterexample.
ck(minimum(F(3),F(-8),F(4),F(2))[0]==-1)
ck(minimum(F(1),F(-2),F(1),F(1))[0]==0)
ck(F(1,4)<F(1,2)) # prescribed gas root precedes prescribed liquid root
ck(all(minimum(F(),r,q,F(1))[0]<=0 for r,q in ((F(),F()),(F(1),F()),(F(-1),F()))))
# Once rounding a large integral loses 1; final aggregation itself is exact.
I=F(2**54+1);Ihat=F(float(I));before=F(2**54+2);out=F(float(before-Ihat));exact=before-I
ck(out-(before-Ihat)==0 and out-exact==1)
result={'status':'passed','checks':checks,'elapsed_s':time.monotonic()-t0,'steps':2,'records':globalrecords,'absolute_resources':str(resources),'scope':'Independent algebra only; production comparison pending.'}
Path(__file__).with_name('ALGEBRA.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
