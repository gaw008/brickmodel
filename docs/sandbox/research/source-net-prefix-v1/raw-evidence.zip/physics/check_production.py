"""Independent arithmetic expectations; fixture reuse is metadata only, no EOS."""
from fractions import Fraction as F
from dataclasses import replace
from pathlib import Path
import hashlib,json,runpy,time
import numpy as np
from sludge_sandbox.source_net_prefix import build_source_prefix,audit_source_prefixes
from sludge_sandbox.exact_terminal_panel import affine_integral,affine_update
from sludge_sandbox.integration import ConservedState
from test_source_net_prefix import sample,remap,bound,POLICY,ENERGY
from sludge_sandbox.exact_event_clock import ExactEventTime as T
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github');OUT=Path(__file__).parent
files=[ROOT/'src/sludge_sandbox'/x for x in ('source_net_prefix.py','source_net_panel.py','exact_terminal_panel.py')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hashes={str(p):sha(p) for p in files}
a=runpy.run_path(str(OUT/'algebra.py'));count=0;t0=time.monotonic()
def ck(x):
 global count
 count+=1
 assert x
h,hm=a['h'],a['hm']
def configure(at, rates, powers, phases, state, role):
 s=sample(at,phase=tuple(map(float,phases)),role=role)
 fs=[]
 for i,f in enumerate(s.evaluation.source_evaluation.faces):
  liquidH=2*rates[i][0];diff=(F(1,128),F(-1,64),F(3,128));adv=(F(-1,128),F(1,64),F(-3,128))
  fs.append(replace(f,liquid_mol_s=float(rates[i][0]),gas_mol_s=tuple(map(float,rates[i][1:])),energy_w=float(powers[i]),conduction_w=float(powers[i]-liquidH),liquid_enthalpy_w=float(liquidH),diffusive_enthalpy_w=tuple(map(float,diff)),advective_enthalpy_w=tuple(map(float,adv)),liquid_enthalpy_projection_w=F(1,2**50)))
 return remap(s,faces=fs,state=state)
state=ConservedState(np.array(a['initial'],dtype=float),np.array(a['initialU'],dtype=float),ENERGY)
start=F();outs=[];totals=[[F()]*4 for _ in range(3)];totU=[F()]*3
for step in range(2):
 first=configure(start,a['f0'],a['u0'],a['phase'],state,'first')
 mid=configure(start+hm,a['fm'],a['um'],[p*2 for p in a['phase']],state,'interior')
 panel=bound(first,mid,upper=start+h)
 out=build_source_prefix(panel,T(start+h),policy=POLICY);outs.append(out)
 records={name:(exact,errors) for name,exact,errors in out.integrals}
 for name,key,ledger in [('face_species_mol_s','face',out.ledger.face_species_mol),('reaction_species_mol_s','local',out.ledger.reaction_species_mol),('face_energy_w','energy',out.ledger.face_energy_j)]:
  exact=tuple(x for row in a[key] for x in row) if key!='energy' else tuple(a[key])
  ck(records[name][0]==exact)
  ck(tuple(map(float,exact))==tuple(ledger.flat))
  ck(records[name][1]==tuple(F(float(v))-e for v,e in zip(ledger.flat,exact)))
 for i in range(3):
  for j in range(4):
   delta=a['face'][i][j]-a['face'][i+1][j]+a['local'][i][j];totals[i][j]+=delta
   represented=F(float(state.amounts_mol[i,j]))+F(float(a['face'][i][j]))-F(float(a['face'][i+1][j]))+F(float(a['local'][i][j]))
   actual=F(float(out.raw_state.amounts_mol[i,j]));k=4*i+j
   ck(actual==F(float(represented)))
   ck(out.state_roundoff_mol[k]==actual-represented)
   ck(out.full_residual_mol[k]==actual-F(float(state.amounts_mol[i,j]))-delta)
  delta=a['energy'][i]-a['energy'][i+1];totU[i]+=delta
  ck(out.full_residual_j[i]==F(float(out.raw_state.internal_energy_j[i]))-F(float(state.internal_energy_j[i]))-delta)
 for i,d in enumerate(out.face_diagnostics):
  ck(d.energy_j==a['energy'][i]);ck(d.liquid_mol==a['face'][i][0]);ck(d.liquid_enthalpy_j==2*a['face'][i][0]);ck(d.energy_decomposition_roundoff_j==0);ck(d.liquid_enthalpy_projection_j==h/F(2**50))
 out.check();state=out.raw_state;start+=h
au=audit_source_prefixes(tuple(outs));au.check()
ck(au.cumulative_exact_inventory_exchange_mol==tuple(x for row in totals for x in row));ck(au.cumulative_exact_energy_exchange_j==tuple(totU))
ck(tuple(F(float(x)) for x in state.amounts_mol.flat)==tuple(x for row in a['state'] for x in row));ck(tuple(F(float(x)) for x in state.internal_energy_j)==tuple(a['U']))
# Independently specified two integral errors of +1 with zero state projection;
# individual tolerance1.5 accepts each, cumulative exact2 must fail.
policy=replace(POLICY,amount_absolute_tolerance_mol=1.5);duration=F(2**54+1,2**54)
def big(at,old=None):
 s=sample(at,liquid_faces=(0.,float(2**54),0.,0.),liquid=float(2**56));m=sample(at+duration/2,liquid_faces=(0.,float(2**54),0.,0.),liquid=float(2**56),role='interior')
 if old is not None:s=remap(s,state=old);m=remap(m,state=old)
 return build_source_prefix(bound(s,m,upper=at+duration),T(at+duration),policy=policy)
x=big(F());y=big(duration,x.raw_state)
ck(x.full_residual_mol[0]==y.full_residual_mol[0]==1);ck(x.state_roundoff_mol[0]==y.state_roundoff_mol[0]==0)
try:audit_source_prefixes((x,y))
except ValueError as e:ck(str(e)=='source_prefix_cumulative_full_inventory_budget')
else:raise AssertionError('missing cumulative full guard')
ck(hashes=={str(p):sha(p) for p in files})
result={'status':'passed','independent_baseline_checks':a['checks'],'production_checks':count,'elapsed_s':time.monotonic()-t0,'hashes':hashes,'scope':'Manufactured saved observations, independent Fraction expectation; no EOS or physical validation.'}
(OUT/'PRODUCTION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
