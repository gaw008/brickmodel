"""Fixed-domain eight-cell event support; no spatial convergence claim."""
from pathlib import Path
from fractions import Fraction as F
import copy
from dataclasses import fields,is_dataclass,replace
from collections.abc import Mapping
import json,hashlib,time,traceback
from sludge_sandbox.verification_case import read_case,build_case,encode
from sludge_sandbox.exact_event_clock import ExactEventTime
from sludge_sandbox.exact_free_host import ExactFreeWaterTransfer
from sludge_sandbox.exact_depletion_integration import integrate_exact_depletion
from sludge_sandbox.water_phase_transfer import WaterTransferEvaluation
from sludge_sandbox.deforming_solid_storage import _canonical
from sludge_sandbox.run_service import runtime_identity
root=Path(__file__).parent
out=root/'attempt01';out.mkdir(exist_ok=False)
prior=Path('/private/tmp/brick-exact-packet-native-v1/attempt01')
def save(name,v):(out/name).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def capture(v):
    if type(v) is ExactFreeWaterTransfer:
        return {'schema':'research_exact_operator_reference_v1','identity':encode(v._identity),'modes':list(v.operator.interfaces)}
    if type(v) is WaterTransferEvaluation:
        # Snapshot exactly the numerical observation vectors used by the core,
        # phase diagnostics and Rates. Do not duplicate live current_host trees.
        b=v.base_evaluation
        return {'schema':'research_depletion_observation_v1','rates':encode(v.rates),
          'temperatures_k':[x.mechanical.temperature_k for x in b.storage_states],
          'temperature_errors_k':[x.temperature_error_bound_k for x in b.storage_inverses],
          'pressures_pa':[x.mechanical.pressure_pa for x in b.storage_states],
          'pressure_errors_pa':[x.pressure_error_bound_pa for x in b.storage_states],
          'cell_transfers':encode(v.cell_transfers),'interface_modes':list(v.interface_modes),
          'source_ids':list(v.source_ids),'coefficient_set_id':v.coefficient_set_id,
          'coefficient_version':v.coefficient_version,'coefficient_classification':v.coefficient_classification,
          'dry_policy':v.dry_policy,'qualification':v.qualification}
    if is_dataclass(v):return {f.name:capture(getattr(v,f.name)) for f in fields(v)}
    if isinstance(v,Mapping):return {str(k):capture(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [capture(x) for x in v]
    return encode(v)
started=time.monotonic();before=runtime_identity();save('runtime-before.json',before)
casebytes=(root/'case.json').read_bytes();(out/'case.json').write_bytes(casebytes)
originalbytes=(root/'original-four-cell-case.json').read_bytes()
report={'capture_status':'started','qualification':'Eight-cell exact event support at fixed original domain/horizon; actual water EOS with manufactured solid. Not spatial convergence, legacy resume or material validation.'}
try:
    original=json.loads(originalbytes);case=json.loads(casebytes)
    assert originalbytes==(prior/'case.json').read_bytes()
    assert before==json.loads((prior/'runtime-before.json').read_text())
    expected=copy.deepcopy(original)
    expected['grid']['cells']=8
    expected['case_id']='reacting-wet-free-slab-v1-exact-eight-cell-events-v1'
    for key in ('amount_absolute_tolerance_mol','energy_absolute_tolerance_j','amount_scale_mol','energy_scale_j'):
        expected['numerics']['integration'][key]*=.5
    assert case==expected
    built=build_case(read_case(out/'case.json'),Path('/private/tmp/brick-free-native-events-v1/attempt01/water'))
    assert encode(built.policy)==case['numerics']['integration']  # refinement remains zero
    oldpolicy=json.loads((prior/'integration-policy.json').read_text())
    assert oldpolicy==original['numerics']['integration']
    assert 8*F(built.policy.energy_absolute_tolerance_j)==4*F(oldpolicy['energy_absolute_tolerance_j'])==F(2e-8)
    assert 8*F(built.policy.amount_absolute_tolerance_mol)==4*F(oldpolicy['amount_absolute_tolerance_mol'])
    policy=replace(built.depletion_policy,ordered_event_policy='ordered_affine_packet_v1')
    oldevent=json.loads((prior/'event-policy.json').read_text());newevent=encode(policy)
    oldevent.pop('pressure_comparison');newevent.pop('pressure_comparison')
    assert oldevent==newevent
    assert len(policy.pressure_comparison.cell_boxes)==8
    initial=encode(built.initial);oldinitial=json.loads((prior/'initial.json').read_text())
    assert len(initial['amounts_mol'])==8 and len(initial['mechanical_stretches'])==9
    mapping=[]
    for i in range(4):
        children=(2*i,2*i+1)
        for j in range(len(oldinitial['amounts_mol'][i])):
            assert sum((F(initial['amounts_mol'][k][j]) for k in children),F())==F(oldinitial['amounts_mol'][i][j])
        assert sum((F(initial['internal_energy_j'][k]) for k in children),F())==F(oldinitial['internal_energy_j'][i])
        assert all(initial['mechanical_stretches'][k]==oldinitial['mechanical_stretches'][i] for k in children)
        mapping.append({'four_cell':i,'eight_children':list(children),'amount_energy_conservative':True})
    assert initial['mechanical_stretches'][-1]==oldinitial['mechanical_stretches'][-1]
    save('initial-grid-mapping.json',mapping)
    save('registered-global-gates.json',{'closed_energy_absolute_j':2e-8,'cumulative_absolute_constraint_sum_j':2e-8,'qualification':'Fixed original parent-domain targets, not relaxed with grid size; separate all-prefix audits required.'})
    assert built.start_s==.5 and built.end_s==.50032
    assert built.policy.maximum_steps==512 and built.policy.maximum_wall_seconds==800.
    op=ExactFreeWaterTransfer(built.operator);identity=op.operator_identity
    save('initial.json',encode(built.initial));save('initialization.json',built.initialization)
    save('original-operator-inputs.json',_canonical(built.operator))
    save('operator-identity.json',encode(identity));save('integration-policy.json',encode(built.policy));save('event-policy.json',encode(policy))
    start=ExactEventTime.from_float(built.start_s);end=ExactEventTime.from_float(built.end_s)
    save('times.json',{'start':start.to_record(),'end':end.to_record()})
    core_started=time.monotonic()
    result=integrate_exact_depletion(built.initial,op,start=start,end=end,integration_policy=built.policy,event_policy=policy)
    report['core_elapsed_s']=time.monotonic()-core_started
    save('core-result.json',capture(result))
    assert identity==op.operator_identity
    assert encode(built.initial)==initial
    report.update(capture_status='captured',core_status=result.status,core_reason=result.reason,
        accepted_steps=len(result.steps),packets=len(result.packets),events=sum(len(x) for x in result.packets),
        terminal_attempts=len(result.terminal_attempts),final_time=result.times_s[-1].to_record(),costs=encode(result.costs))
except BaseException:
    report.update(capture_status='failed',traceback=traceback.format_exc())
finally:
    try:
        after=runtime_identity();save('runtime-after.json',after);assert before==after
        assert casebytes==(root/'case.json').read_bytes()==(out/'case.json').read_bytes()
        assert originalbytes==(root/'original-four-cell-case.json').read_bytes()==(prior/'case.json').read_bytes()
    except BaseException:report.update(capture_status='failed',integrity_error=traceback.format_exc())
    report.update(elapsed_s=time.monotonic()-started,modules=len(before['modules']),case_sha256=hashlib.sha256(casebytes).hexdigest(),runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    save('report.json',report)
assert report['capture_status']=='captured',report
