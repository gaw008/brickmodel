from pathlib import Path
import importlib.util,json,sys
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location("bounded_supervisor", "/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/research-process-supervisor/supervisor.py")
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
result=m.run_attempt(root/"supervised01",["/private/tmp/brick-water-backend-probe/venv/bin/python",str(root/"run.py")],cwd="/private/tmp",input_paths=[root/"run.py",root/"case.json",root/"PLAN.md",root/"original-four-cell-case.json","/private/tmp/brick-exact-packet-native-v1/installed-identity.json"],timeout_s=840,cleanup_grace_s=.1)
print(json.dumps(result,indent=2))
