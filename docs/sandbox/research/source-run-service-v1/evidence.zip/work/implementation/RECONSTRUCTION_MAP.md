# Actual source N3 reconstruction map

Read-only baseline a493619. No model constructor, water evaluator, native import, installation or production edit was performed. INPUT_ASSET_INVENTORY.json records actual file existence, byte counts and SHA-256 values. This mapping is for a real HEOS/source-caloric execution service; the present geometry/transport remain explicitly manufactured because the installed source host requires that classification.

## 1. Exact call chain

1. source-wet-shared-pressure-v1/run_native.py (a1116c16…) loads the fixed N3 parent (1250733f…) and serializer (b0b87396…). It patches transition entry to add two wet declarations, patches wet collection to record public water requests, and patches comparison so an accidental EOS call fails.
2. source-multicell-transition-v1/run_native.py loads source-wet-storage-v1.make_case (9a8bbf40…). make_case creates actual water, ideal vapor, NIST gas phases, rigid liquid/gas mechanics, declared numerical envelope, source dry-mass Cp, fixed volume and disabled chemistry.
3. N3 parent creates WaterChemicalPotential separately. Storage liquid and storage ideal-vapor providers account for two HEOS constructions; chemical liquid and chemical ideal-vapor account for another two. A successful HEOSCandidate constructor performs the original reference-anchor checks. Initial U is evaluated once per actual cell, three separate attempts. Neither the three storage copies nor the zero-energy temporary state is a native evaluation.
4. Parent copies storage and its volume into three distinct spatial objects while sharing original providers/Cp. It creates SourceWetColumn and ExactSourceColumn, with wet modes in all three cells. It declares shared dry volume only for cell 1.
5. Actual initial RHS probe → H from actual net liquid loss → seed → positive proposal/approach → shifted seed/root refinement → two terminal/writeback/mixed-mode candidates to seed.end → wet shared-pressure evidence for both remaining wet cells at event/common endpoints → existing final comparison. This is one root/event study, not an arbitrary time-course controller.

The final installed transition API already accepts both `shared_volume` and `shared_wet_volumes`; no strategy monkeypatch is necessary in a formal service.

## 2. All construction inputs and existing owners

| Group | Actual input/choice | Installed owner | Script-only responsibility |
|---|---|---|---|
| Real water | HEOS hybrid, approved manifest 5f9e39bf…, source water assets | load_water_properties, HEOSWaterProperties, HEOSCandidate | Select asset root and manifest; record actual construction attempts |
| Ideal vapor | pinned Python ideal IAPWS law with source offset, fixed mixture R=8.31446261815324 | IdealWaterVapor | Construct separately for storage and chemical model; do not change R/reference |
| O2/N2 | NIST Shomate catalog; mass facts 0.0319988 and 0.0280134 kg/mol, source/cache identifiers, zero caloric correction | load_thermochemistry, IdealGasPhase | Read the two fact rows and assemble phases in fixed O2/N2/H2O order |
| Mechanics | available V .001 m3, P bracket [1e5,1e7] Pa, planar no-capillary pressure, PressurePolicy(1e-12,1e-5,100) | RigidWaterGas, PressurePolicy | Assemble explicit constructor values |
| Conditional error envelope | T [310,350] K, P [1e5,1e7] Pa; liquid u/v/abs-uP values 1e-8,1e-16,1e-4; each gas error 1e-7 and cv lower 20 | DeclaredNumericalEnvelope, RigidStorage | Preserve exact field meanings and condition label; these are declared test bounds, not certified EOS error |
| Source solid | Arlabosse 2005 dry-mass Cp, fixed mass .2 kg/cell; reference T=Fraction('313.15'); fixed-composition incompressible approximation | ArlabosseDryCaloric, ArlabosseMassCaloric | Bind reviewed source plus its four assets and fixed-mass choice; no pseudo-molar solid or invented density |
| Chemistry | disabled with original rationale and actual gas/component IDs | ReactionDisabled | Retain rationale; no reaction kinetics enabled |
| Water bookkeeping | original CIAAW-derived nominal mass-fraction convention | WaterElementConvention.load | Bind facts and excerpt; never replace EOS molar mass with nominal formula mass |
| Per-cell volume | three independent .001 ± 1e-12 m3 fluid-available-volume objects | ManufacturedFixedFluidVolume, SourceWetStorage | Instantiate/copy distinct objects; equal values do not mean a common spatial parameter |
| Grid | widths (.25,.3125,.375) m; area .01 m2; exact half widths; closed/no-flux ends | SourceWetColumn, WetFace | Assemble N=3 arrays and geometry |
| Gas/heat transport | zero thermal conductivities, gas diffusivities and gas permeability; gas viscosity 1.8e-5 Pa s | WetFace and original column evaluator | Explicit isolation scenario, no furnace program or heat source |
| Liquid law | saturation knots (0,1e-18,1), intrinsic k=(1e-18,)*3, kr=(0,.5,.5), mu=(.001,)*3; T [310,350], P [1e4,1e7]; tabulated relation | SaturationMobilityTable, LiquidConnection, LiquidTransportConfig | Face 0/1 disabled; face 1/2 connected; same table at all cells; actual source asset becomes reviewed config identity rather than runner bytes |
| Phase transfer | coefficients (0,1e-9,0) mol/s/Pa | WaterChemicalPotential, SourceWetColumn | Select coefficients; no source activity/sorption closure |
| Initial state | liquid (.25,1e-11,.25); gases ((.125,.25,1e-12),(.1875,.25,1e-12),(.125,.25,1e-12)); T=325 K per cell | storage.state/evaluate, ExactSourceColumn.pack | Evaluate actual initial U for each cell; retain every partial attempt |
| Inversion | InversePolicy(1e-5,1e-6,100) per cell | InversePolicy, SourceWetStorage.invert | Explicit policy values |
| Horizon | Fraction(3,2)*Nl[1]/(E[1]+Jright−Jleft), using exact Fractions of actual saved binary64 probe | Existing rates and ExactEventTime | Derive after actual probe; transport is not gross evaporation |
| Integration | h0=hmax=float(H), hmin=2^-30; relative1e-8, Nabs1e-7 mol, Uabs1e-3 J; scales1 mol/1e5 J; 4 steps/4 rejects/180s | IntegrationPolicy; existing source trial/integrate_exact | Preserve explicit names, not ambiguous positional JSON |
| Event | time1e-8s, N1e-11mol, U1e-7J, T1e-5K, P1e-4Pa; window.001s; 32 refinements; affine_midpoint; original default horizon.01/safe fraction.25 | DepletionPolicy, original proposal/root/terminal/writeback | Save all effective policy defaults; no hidden policy replacement |
| Roundoff | correction1e-15mol, fractional1e-8; storage1e-15/cumulative1e-14; elements2e-15/cumulative2e-14; mass1e-16/cumulative1e-15kg; cumulative correction1e-14mol | DepletionRoundoffPolicy | Bind M from actual shared water/chemical reference, not old 1-ULP-different test literal |
| Pressure strategy | same live volume for both paths at a given cell; distinct volumes across cells; dry selected cell plus wet cells0/2 | declare/enclose dry pair; declare/collect wet pair; evaluate_source_dry_transition | Explicit choice of per-cell declarations; preserve old independent pressure gates even when new joint gate passes |
| Resources | 510s outer; max16 each seed/approach/shifted; max24 each dry path; total97 RHS; max16 extra wet public requests | Existing per-trial policies/cancel; wet collector dedup within pair | Whole-run budget, persistent attempt accounting and external stop handling |

Exact dataclass field names for envelope and policies must come from the installed classes; the above numbers are mappings of the frozen current script, not alternative defaults.

## 3. Assets and what is not in the wheel

The source classes are installable. The repository's `data/sandbox/...` input files and `.tools/source-cache/...` publisher assets are not listed as wheel package data (pyproject packages only catalogs JSON and UI assets). A formal installed runner must take an explicit local `assets_root`, preserving the relative tree expected by the existing loaders, and verify a frozen manifest before constructing a backend.

Necessary material/gas extras are in INPUT_ASSET_INVENTORY.json. All are present in the current workspace. Arlabosse source.json is hard-pinned in code to 2f9caf23… and its four original publisher assets are checked on construction/every operation. The stored metadata explicitly says those publisher assets are private, ignored and not redistributed; silently copying them into a wheel would change the distribution contract. The installed API can use a separately supplied local asset bundle. No automatic downloading or bypass of unavailable source bytes is needed for this slice.

The old make_case only reads gas_molar_mass_facts.json and carries its cache SHA strings; it does not open those two source caches there. A new preflight should bind both fact-file bytes and their referenced actual cached bytes. Both current caches match their declared hashes. This adds provenance checking, not a changed molar mass. Water providers and Arlabosse retain their existing stronger original checks.

Do not add a hook to _heos_kernel.py merely to count anchors: its own SHA is inside the approved HEOS manifest and changing it invalidates construction. Place a recording seam around the existing HEOSCandidate call in water_heos.HEOSWaterProperties.__init__, keeping kernel/manifest bytes and numerical operations unchanged. Record wrapper-construction attempts separately from actual kernel/anchor completion so a failure after the kernel returns is not miscounted.

## 4. Current script interception to remove

- `importlib.util` loads executable research files selected by fixed paths/hashes. A production builder should directly import installed classes and use a closed config schema; config must never select Python code.
- Global patches of ExactSourceColumn.evaluate and HEOSCandidate.__init__ observe attempts and enforce run caps. They are not necessary physics. A task-local recording scope with explicit hooks can replace them without constructing proxy/subclass adapters (current solvers intentionally require exact adapter types).
- Patches of evaluate_source_dry_transition and collect_source_wet_pressure_pair only add strategy/observation behavior; the former is replaced by its existing keyword arguments, the latter needs an explicit observation hook.
- Patching comparison to forbid EOS is a verification guard; keep it in tests/acceptance, not as the service implementation.
- The script's `seed has exactly 2 captures and negative-prefix reason`, four constructors, and expected middle root checks are this profile's expectations. A service must persist an actual unexpected outcome and stop, not alter inputs until expectations hold. EXPECTED_CALLBACKS=32 remains a planning estimate.
- SIGALRM is Unix/main-thread/process-global and cannot guarantee interruption inside a native call. The smallest robust CLI execution is one isolated worker per run, cooperative cancel/deadline checks at the existing callbacks/request boundaries, and a parent process able to terminate a stuck worker after the declared budget; the last durable started attempt must remain distinguishable from a known numerical failure.

## 5. Smallest useful installed interface

Suggested modules: source_run_config.py (closed JSON schema and frozen profile), source_run_builder.py (direct constructor assembly and source asset validation), source_run_observer.py (task-local attempt sink), and Root-owned source_run_service.py (lifecycle/publication/CLI). Keep source_study_record as the complete final evidence codec; do not create another summary-only result format or loader for Python factories.

```python
load_source_run_config(raw: bytes) -> SourceRunConfig
validate_source_run_assets(config, *, assets_root: Path) -> SourceRunAssetManifest
build_source_run(config, assets, *, observer, cancel=None) -> BuiltSourceRun
execute_source_run(config, *, assets_root: Path, run_directory: Path,
                   cancel=None) -> SourceRunResult
```

`SourceRunConfig` must carry schema/profile version; backend selector and manifest/source hashes; all explicit model/error/geometry/transport/initial/policy fields above; a horizon rule with exact factor, selected cell and net-loss expression; shared-volume selections; and resource caps. Keep both user input canonical bytes/hash and all derived effective inputs (actual H, effective policy, source-bound M, provider descriptors, initial-U points). Use strict finite binary64/explicit Fraction representations; booleans are not numbers. Unsupported combinations fail before native construction where possible. The first version can name this exact `heos_source_N3_selected_depletion_v1` profile while permitting explicitly validated numeric scenario fields; it must actually construct the real backend and execute the existing solvers, not dispatch to a test fixture.

`BuiltSourceRun` contains only new live objects created from the config and verified assets: original three storages/volumes, chemical provider, column, adapter and initialized state. Corresponding new path adapters must keep these same objects. It is not returned by decode_source_study and must never be described as resuming an archived study. Rebuilding identical config is a new run with fresh object identities, reference checks and actual U/RHS evaluations.

Use the actual solver sequence above. For the smallest first executable slice, retain closed boundaries, current SourceWetColumn and single unique first-liquid event; expose a clear unsupported state for general chemistry/furnace/repeated events. Do not relabel the installed host's mandatory manufactured geometry/transport as measured material. Real HEOS/source Cp execution and complete evidence persistence are nevertheless genuine runtime capabilities.

## 6. Minimum recording seams and lifecycle

A task-local context (e.g. ContextVar) avoids global monkeypatches and lets exact runtime types remain unchanged. The active sink is run-owned, not supplied by untrusted JSON. Hooks should be a no-op outside an active run, and observer failures must propagate with the last actually returned record retained.

1. Around existing HEOSCandidate construction within HEOSWaterProperties.__init__: started/kernel-returned/wrapper-returned/failure. Do not alter the pinned kernel.
2. ExactSourceColumn.evaluate: append original packed input/time/operator/energy/mode and per-cell same-object assertions before work; retain raw return immediately, then any post-return validation failure. This covers the separate probe and all existing internal source trial/dry callbacks without threading an extra observer through every solver function.
3. Wet collector: each unique request started, returned WaterState, validation failure and complete pair return. Preserve its current cancel-before-request behavior and count these separately from RHS callbacks and constructor anchors.
4. Service construction and stage calls: initial-U per-cell attempts and completed points; every returned seed/proposal/approach/refinement/candidate/pressure pair before later assessment. The existing SourceApproachAssessmentError, SourceRootStudyError and SourceDryTransitionError already carry returned records; keep those complete on failure. A narrow candidate-return notification in evaluate_source_dry_transition is needed for durable success-before-later-failure publication.

Create the exclusive run directory and durable `started` configuration envelope before asset/native construction. Write each attempt atomically before executing it; update completed/failed status only with actual evidence. Use the existing bounded regular-file/exclusive publication helpers for configuration/final outputs; controlled atomic replacement inside that run's owned directory is needed for progress. A final SourceStudyRecord stores all reached roots, contexts, original ordered captures, constructor/U/pressure attempts, effective config and full exception chain. Original status, comparison completion, numerical event acceptance and material=false are separate fields.

Terminal states: completed (comparison executed, gate may be false), cancelled (caller stop), resource_limit (declared cap/deadline), domain_exit/failed (original exception and stage), and interrupted/worker_terminated when no clean numerical return exists. Never invent a final state after hard termination. A returned evaluation with validation failure remains raw failure evidence and yields observation=None, as implemented by the latest study codec. No active attempt is silently dropped or counted as a return.

One residual codec boundary matters before claiming every conceivable failure: the research serializer tags nonfinite floats, but the formal study codec intentionally rejects nonfinite numeric records and unknown classes. For an actual malformed/nonfinite provider return, retain a bounded explicitly tagged failure payload in SourceStudyFailure metadata (class/field path/raw representation), not a valid SourceExactEvaluation or successful observation. This is failure evidence only and does not weaken the valid numeric schema. A worker killed before a return has only its durable started input, not a fabricated raw value.

## 7. Minimum meaningful verification

- Pure config round trip, forbidden unknown fields/code selectors/bool/nonnumeric/oversized shapes, wrong hashes/missing private assets, and all explicit original values/defaults.
- One manufactured seam run of the same installed builder/service to prove hook order, cancelled before first model / during initial U / between callbacks, returned-before-validation error, failed second candidate and wet request failures retain partial records. This is a test backend seam only; public profile continues selecting real HEOS.
- Builder parity against the frozen old constructor inputs and source identities (allow new wrapper provenance/object IDs to differ only as explicitly recorded); no changed bounds, transport direction law or zero-mobility parameter.
- Independent reviewer of source/type bindings, caps/observer exceptions, worker interruption, and persistence at every irreversible native boundary.
- After installation and byte identity checks, one preregistered actual HEOS N3 service run, with real constructor/initial-U/RHS/extra-request counts and complete SourceStudyRecord read/query verification. No promise that P/event gates pass and no automatic retry. This is the required end-to-end completion gate; a codec-only or manufactured-only result does not finish the slice.
