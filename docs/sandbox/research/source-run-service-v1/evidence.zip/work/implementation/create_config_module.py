from pathlib import Path
import json,pprint
c=json.loads(Path('data/sandbox/cases/source-multicell-heos-v1.json').read_text())
def shape(v):
 if isinstance(v,dict): return {k:shape(x) for k,x in v.items()}
 if isinstance(v,list):return [shape(x) for x in v]
 return type(v).__name__
spec=shape(c);spec.pop('assets')
head='''"""Closed, bounded configuration for an explicitly virtual three-cell source run.

Reading and asset validation are passive. Source assets are pinned independently
of scenario values. Binary64 numbers and exact rational clocks are not coerced.
No material, geometry, transport or full-cycle qualification is granted here.
"""
from collections.abc import Mapping
from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
from types import MappingProxyType

from .source_record_io import read_record_bytes

CONFIG_BYTE_LIMIT = 65536
SCHEMA = 'source_run_config_v1'
PROFILE = 'source_multicell_wet_to_dry_heos_v1'

'''
Path('src/sludge_sandbox/source_run_config.py').write_text(head+'_SHAPE = '+pprint.pformat(spec,sort_dicts=False,width=100)+'\n\nREQUIRED_ASSETS = '+pprint.pformat(tuple((x['path'],x['bytes'],x['sha256']) for x in c['assets']),width=100)+'\n')
