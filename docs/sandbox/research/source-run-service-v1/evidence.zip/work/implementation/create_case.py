from pathlib import Path
import hashlib,json
root=Path.cwd()
items=json.loads(Path('/private/tmp/brick-source-run-service-v1/implementation/INPUT_ASSET_INVENTORY.json').read_text())
assets=[{k:v for k,v in item.items() if k!='exists'} for item in items if not item['path'].startswith('docs/')]
for name in ('IAPWS95-2018.pdf','iapws-1.5.5-py3-none-any.whl','iapws-1.5.5-iapws95.py','iapws-1.5.5-LICENSE','source_facts.json'):
 p=Path('data/sandbox/water')/name; raw=p.read_bytes(); assets.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
assets.sort(key=lambda x:x['path'])
c={
 'schema':'source_run_config_v1','profile':'source_multicell_wet_to_dry_heos_v1','classification':'manufactured_test_fixture',
 'assets':assets,
 'storage':{'dry_mass_kg':.2,'fluid_volume_m3':.001,'fluid_volume_error_m3':1e-12,'temperature_domain_k':[310.,350.], 'pressure_domain_pa':[1e5,1e7], 'caloric_reference_temperature_k':{'numerator':6263,'denominator':20}, 'pressure_closure':'planar_interface_no_capillary_pressure','geometry_rationale':'Test-only constant available liquid-plus-gas volume; no source material density supplied','chemistry_rationale':'Low-temperature fixed-composition numerical storage test; no chemical conversion'},
 'envelope':{'temperature_range_k':[310.,350.],'pressure_range_pa':[1e5,1e7],'liquid_u_error_j_mol':1e-8,'liquid_v_error_m3_mol':1e-16,'liquid_abs_du_dp_bound_j_mol_pa':1e-4,'gas_u_error_j_mol':{'O2':1e-7,'N2':1e-7,'H2O':1e-7},'gas_cv_lower_j_mol_k':{'O2':20.,'N2':20.,'H2O':20.},'method':'explicit_conditional_numerical_test_envelope_not_independent_eos_certificate','source_ids':['manufactured:source-wet-native-test-envelope-v1']},
 'grid':{'cell_widths_m':[.25,.3125,.375],'face_area_m2':.01,'conductivities_w_m_k':[[0.,0.],[0.,0.]],'diffusivities_m2_s':[[0.,0.,0.],[0.,0.,0.]],'gas_permeability_m2':[0.,0.],'gas_viscosity_pa_s':[1.8e-5,1.8e-5],'source_ids':['manufactured:source-column-transport']},
 'liquid_transport':{'saturation_knots':[0.,1e-18,1.],'permeability_m2':[1e-18,1e-18,1e-18],'relative_permeability':[0.,.5,.5],'viscosity_pa_s':[.001,.001,.001],'temperature_range_k':[310.,350.],'pressure_range_pa':[1e4,1e7],'model_id':'manufactured:source-multicell-native-liquid-mobility','version':'1','source_ids':['manufactured:source-multicell-native-liquid-mobility'],'connection_statuses':['disabled','connected'],'connection_ids':['manufactured:source-multicell-native-liquid-link-0','manufactured:source-multicell-native-liquid-link-1'],'connection_source_ids':['manufactured:source-multicell-native-liquid-links']},
 'initial':{'liquid_water_mol':[.25,1e-11,.25],'gas_amounts_mol':[[.125,.25,1e-12],[.1875,.25,1e-12],[.125,.25,1e-12]],'temperature_k':[325.,325.,325.],'interface_modes':['existing_liquid','existing_liquid','existing_liquid']},
 'transfer_coefficients_mol_s_pa':[0.,1e-9,0.],
 'pressure_policy':{'volume_tolerance_m3':1e-12,'pressure_tolerance_pa':1e-5,'maximum_iterations':100,'strategy':None},
 'inverse_policy':{'energy_tolerance_j':1e-5,'temperature_tolerance_k':1e-6,'maximum_iterations':100},
 'integration_policy':{'minimum_step_s':2**-30,'relative_tolerance':1e-8,'amount_absolute_tolerance_mol':1e-7,'energy_absolute_tolerance_j':1e-3,'amount_scale_mol':1.,'energy_scale_j':1e5,'maximum_steps':4,'maximum_rejections':4,'maximum_wall_seconds':180.,'stretch_absolute_tolerance':None,'stretch_scale':None},
 'event_policy':{'time_absolute_s':1e-8,'amount_absolute_mol':1e-11,'energy_absolute_j':1e-7,'temperature_absolute_k':1e-5,'pressure_absolute_pa':1e-4,'terminal_window_s':.001,'maximum_refinements':32,'common_time_horizon_s':.01,'safe_inventory_fraction':.25,'nested_approach':None,'terminal_method':'affine_midpoint','pressure_comparison':None,'ordered_event_policy':None},
 'roundoff_policy':{'correction_absolute_mol':1e-15,'correction_fraction_evaporated':1e-8,'storage_absolute_mol':1e-15,'cumulative_storage_absolute_mol':1e-14,'element_absolute_mol':2e-15,'cumulative_element_absolute_mol':2e-14,'mass_absolute_kg':1e-16,'cumulative_mass_absolute_kg':1e-15,'cumulative_correction_absolute_mol':1e-14},
 'study':{'selected_cell_index':1,'start_seconds':{'numerator':0,'denominator':1},'horizon_multiplier':{'numerator':3,'denominator':2},'shared_dry_cell_index':1,'shared_wet_cell_indices':[0,2]},
 'resources':{'callback_cap':16,'dry_path_callback_cap':24,'total_callback_cap':97,'wet_pressure_request_cap':16,'outer_seconds':510.}
}
p=Path('data/sandbox/cases/source-multicell-heos-v1.json');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(c,indent=2,allow_nan=False)+'\n')
Path('/private/tmp/brick-source-run-service-v1/implementation/REQUIRED_ASSETS.py.txt').write_text(repr(tuple((x['path'],x['bytes'],x['sha256']) for x in assets)))
print(p, len(p.read_bytes()), len(assets))
