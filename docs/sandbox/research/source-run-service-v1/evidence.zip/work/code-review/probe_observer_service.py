"""Bounded no-EOS control/persistence probes; no physical-model success claim."""
from pathlib import Path
from types import SimpleNamespace as NS
import hashlib
import json
import time
import traceback
import pytest
from sludge_sandbox.source_run_observer import observer_scope
import sludge_sandbox.source_wet_shared_pressure as wet
import sludge_sandbox.source_run_service as service
from sludge_sandbox.run_service import read_run, _json, _seal

O=Path(__file__).parent/'observer-service-probe01';O.mkdir(exist_ok=False)
result={'scope':'pure notification control plus actual missing-input service; no EOS', 'cases':[],
 'sha256':{name:hashlib.sha256(Path('src/sludge_sandbox',name).read_bytes()).hexdigest() for name in ('source_run_observer.py','source_wet_shared_pressure.py','source_run_service.py','source_run_journal.py')}}
start=time.monotonic()
try:
 events=[];calls=[];returned=object()
 requests=((325.,100000.,'liquid'),(325.,100001.,'liquid'))
 def state_tp(*a,**kw):calls.append((a,kw));return returned
 storage=NS(water=NS(state_tp=state_tp),fluid_template=NS(envelope=NS(liquid_v_error_m3_mol=0.)))
 cancellations=iter((False,True))
 with pytest.MonkeyPatch.context() as patch:
  patch.setattr(wet,'_inputs',lambda *a:'constant-pure-control-binding')
  patch.setattr(wet,'_support',lambda *a:NS(requests=requests))
  patch.setattr(wet,'_water_metadata',lambda *a:(123,'water-binding',()))
  patch.setattr(wet,'_validate_observation',lambda observation,*a:observation)
  with observer_scope(lambda event,**payload:events.append((event,payload))):
   try:wet.collect_source_wet_pressure_pair(object(),object(),shared_volume=NS(storage=storage),cancel=lambda:next(cancellations))
   except wet.SourceWetPairCollectionError as exc:
    assert len(exc.attempts)==1 and exc.attempts[0].state is returned
   else:raise AssertionError('expected cancellation')
 assert [x[0] for x in events]==['wet_started','wet_returned','wet_failed']
 assert events[-1][1]['request']==requests[1]
 assert events[-1][1]['state'] is None
 result['cases'].append({'name':'second_wet_cancel_does_not_alias_prior_state','passed':True,'control_stub_returns':len(calls),'EOS_calls':0})
 # A genuine service preflight failure. Neither config nor any provider is constructed.
 output=O/'missing-input-run'
 run=service.run_source_case(O/'does-not-exist.json',O/'no-assets',output)
 result['missing_input_result_status']=run['status']
 original,manifest=read_run(output)
 assert original['status']!='completed'
 result['cases'].append({'name':'actual_missing_input_readable','passed':True,'counts':original['counts']})
 original['numerical_comparison_completed']=True
 original['numerical_event_accepted']=True
 _json(output/'result.json',original);_seal(output)
 try:
  forged,_=read_run(output)
  accepted=True;error=None
 except Exception as exc:
  accepted=False;error=type(exc).__name__+':'+str(exc)
 result['cases'].append({'name':'failure_summary_forged_numerical_acceptance','forged_summary_accepted':accepted,'error':error})
 result['completed']=True
except BaseException as exc:
 result.update(completed=False,harness_error=type(exc).__name__+':'+str(exc),traceback=traceback.format_exc())
finally:
 result['elapsed_seconds']=time.monotonic()-start
 (O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
