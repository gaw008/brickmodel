"""Original runtime statuses from real manufactured objects; zero water EOS.

The dry case reuses exactly recorded manufactured seed observations, never a
native source study or an archived live provider. Only constructors, passive
checks, original terminal arithmetic and an injected IntegrationError execute.
"""
from pathlib import Path
from dataclasses import fields
from fractions import Fraction as F
import hashlib
import json
import time
import traceback
import pytest
from test_source_wet_storage import setup as storage_setup
from test_source_prefix_trial import POLICY
from test_mass_storage_bridge import REPOSITORY
from sludge_sandbox.source_study_record import _legacy, encode_source_study, decode_source_study
from sludge_sandbox.source_study_schema import reify, SourceStudyFailure
from sludge_sandbox.source_observation_record import SourceObservationContext
from sludge_sandbox.source_wet_column import SourceWetColumn
from sludge_sandbox.water_chemical_potential import WaterChemicalPotential
from sludge_sandbox.water_properties import WaterProperties
from sludge_sandbox.phase_storage import InversePolicy
from sludge_sandbox.exact_source_column import ExactSourceColumn
from sludge_sandbox.exact_event_clock import ExactEventTime as T
from sludge_sandbox.integration import IntegrationError
from sludge_sandbox.source_prefix_trial import SourcePrefixTrial, evaluate_source_prefix_trial
from sludge_sandbox.source_dry_transition import execute_source_dry_candidate

OUT=Path(__file__).parent/'status-closure-red'
OUT.mkdir(exist_ok=False)
source=Path('/private/tmp/brick-source-dry-transition-v1/root/manufactured-result.json')
result={'scope':'actual runtime classification with recorded manufactured seed and injected first dry callback failure; no physical prediction',
        'input_path':str(source),'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'audit_sha256':hashlib.sha256(Path('src/sludge_sandbox/source_study_audit.py').read_bytes()).hexdigest(),
        'forbidden_water_calls':0,'injected_dry_callbacks':0,'cases':[]}
start=time.monotonic()
def forbidden(*args,**kwargs):
    result['forbidden_water_calls']+=1
    raise AssertionError('water_EOS_forbidden')
def context(adapter):
    return SourceObservationContext(adapter.operator_identity,adapter.energy_model_identity,
        tuple(s.dry_mass_kg for s in adapter.column.storages),adapter.interfaces)
def probe(name,roots,contexts,description):
    t=time.monotonic(); item={'name':name,**description}
    try:
        raw=encode_source_study(roots,contexts=contexts)
        record=decode_source_study(raw)
        (OUT/(name+'.json')).write_bytes(raw)
        item.update(accepted=True,canonical_sha256=record.sha256)
    except Exception as exc:
        item.update(accepted=False,error_type=type(exc).__name__,error=str(exc))
    item['elapsed_seconds']=time.monotonic()-t
    result['cases'].append(item)
try:
    with pytest.MonkeyPatch.context() as patch:
        storage,_,liquid_calls=storage_setup(patch)
        assert not liquid_calls
        for name in ('state_tp','state_tp_response','_solve','saturation_at_temperature'):
            if hasattr(WaterProperties,name):patch.setattr(WaterProperties,name,forbidden)
        column=SourceWetColumn((storage,),(InversePolicy(1e-6,1e-6,100),),
            WaterChemicalPotential(REPOSITORY/'data/sandbox/water'),(1e-9,),(),(.25,),.01,
            ('existing_liquid',),('manufactured:source-column-transport',))
        adapter=ExactSourceColumn(column)
        initial=adapter.pack((storage.state(0.,(.125,.25,1e-12),0.),))
        unsupported=evaluate_source_prefix_trial(adapter,initial,start=T(F()),end=T(F(1,16384)),
            integration_policy=POLICY,maximum_callbacks=16)
        assert unsupported.status=='unsupported' and unsupported.reason=='source_trial_nonpositive_initial_inventory'
        assert not unsupported.captures
        unsupported.check()
        probe('unsupported_trial',{'seed':unsupported},(context(adapter),),
              dict(runtime_status=unsupported.status,runtime_reason=unsupported.reason,actual_source_attempts=0))
        raw=json.loads(source.read_text())['cases']['closed']['fields']
        proposal=raw['refinement']['fields']['approach']['fields']['proposal']['fields']
        saved=_legacy(proposal['original_trial'])
        assert saved.operator_identity==adapter.operator_identity
        assert saved.energy_identity==adapter.energy_model_identity
        values={f.name:(adapter if f.name=='adapter' else reify(saved.values[f.name])) for f in fields(SourcePrefixTrial)}
        seed=SourcePrefixTrial(**values)
        seed.check()
        event=reify(_legacy(proposal['event_policy']))
        end=_legacy(raw['candidates'][0]['fields']['end'])
        def fail_dry(self,state,at):
            assert self is not adapter and self.interfaces==('depleted_no_nucleation',)
            result['injected_dry_callbacks']+=1
            raise IntegrationError('injected first dry numerical failure; no EOS')
        patch.setattr(ExactSourceColumn,'evaluate',fail_dry)
        candidate=execute_source_dry_candidate(seed,event_policy=event,end=end,maximum_callbacks=24)
        assert candidate.status=='numerical_failure',candidate.reason
        assert candidate.reference.status=='numerical_failure' and candidate.reference.evaluations==1
        assert len(candidate.captures)==1 and candidate.captures[0].evaluation is None
        candidate.check()
        failure=SourceStudyFailure('review.InjectedRuntimeFailure','original candidate failed','dry_candidate',{'candidate':candidate})
        probe('numerical_failure_candidate',{'failure':failure},(context(adapter),context(candidate.terminal.dry_adapter)),
              dict(runtime_status=candidate.status,runtime_reason=candidate.reason,actual_source_attempts=len(candidate.captures),
                   reference_status=candidate.reference.status,accepted_steps=len(candidate.reference.steps)))
    assert result['forbidden_water_calls']==0 and result['injected_dry_callbacks']==1
    assert len(result['cases'])==2
    result['probe_completed']=True
except BaseException as exc:
    result.update(probe_completed=False,harness_error_type=type(exc).__name__,harness_error=str(exc),traceback=traceback.format_exc())
finally:
    result['elapsed_seconds']=time.monotonic()-start
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
