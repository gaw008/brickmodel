"""Actual HEOS wrapper preflight failure, no native kernel construction."""
from pathlib import Path
import hashlib
import json
import time
import pytest
from sludge_sandbox.source_run_observer import observer_scope
from sludge_sandbox.source_run_service import _Recorder
import sludge_sandbox.water_heos as module

out = Path(__file__).parent / 'partial-constructor03'
out.mkdir(exist_ok=False)
recorder = _Recorder(out, None, time.monotonic())
recorder.limits = {'outer_seconds': 60.0}
kernel_calls = []
def forbidden(*args, **kwargs):
    kernel_calls.append((args, kwargs))
    raise AssertionError('native kernel construction prohibited')
with pytest.MonkeyPatch.context() as patch:
    patch.setattr(module, 'HEOSCandidate', forbidden)
    with observer_scope(recorder):
        try:
            module.HEOSWaterProperties(out / 'missing-source', out / 'missing-manifest')
        except module.WaterSourceError as exc:
            error = str(exc)
        else:
            raise AssertionError('required manifest error missing')
events = [json.loads(path.read_bytes()) for path in sorted((out / 'events').glob('*.json'))]
assert [event['event'] for event in events] == ['heos_started', 'heos_failed']
nodes = events[-1]['payload']['nodes']
wrapper = [node for node in nodes.values() if node['type'] == 'sludge_sandbox.water_heos.HEOSWaterProperties']
assert len(wrapper) == 1
assert wrapper[0]['fields'] == {}
assert wrapper[0]['uninitialized_fields'] == ['reference', 'source_asset_sha256', 'numerical_limits', 'implementation', '_kernel', '_ideal']
assert not kernel_calls
result = {'status': 'passed', 'scope': 'actual missing-manifest preflight only', 'error': error,
          'events': [event['event'] for event in events], 'counts': recorder.counts,
          'native_kernel_calls': 0, 'EOS_calls': 0,
          'uninitialized_fields': wrapper[0]['uninitialized_fields'],
          'journal_sha256': hashlib.sha256(Path('src/sludge_sandbox/source_run_journal.py').read_bytes()).hexdigest()}
(out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
