"""No-EOS service controls; only isolated reviewer output is mutated."""
from pathlib import Path
from types import SimpleNamespace as NS
import hashlib
import json
import shutil
import time
import pytest
import sludge_sandbox.source_run_service as service
from sludge_sandbox.integration import DomainExit
from sludge_sandbox.run_service import read_run, _json, _seal

OUT = Path(__file__).parent / 'service-control02'
OUT.mkdir(exist_ok=False)
result = {'scope': 'actual missing-input service; synthetic failure routing only; zero EOS',
          'cases': [], 'source_sha256': hashlib.sha256(Path(service.__file__).read_bytes()).hexdigest()}
begin = time.monotonic()
base = OUT / 'original-missing'
original = service.run_source_case(OUT / 'absent', OUT / 'no-assets', base)
assert read_run(base)[0] == original
for name, changes in (
    ('failed_flags_only', {'numerical_comparison_completed': True, 'numerical_event_accepted': True}),
    ('kind_bypass', {'integration_kind': 'unrecognized_source_kind',
                     'numerical_comparison_completed': True, 'numerical_event_accepted': True}),
):
    target = OUT / name
    shutil.copytree(base, target)
    altered = dict(original, **changes)
    _json(target / 'result.json', altered)
    _seal(target)
    try:
        read_run(target)
    except Exception as exc:
        result['cases'].append({'name': name, 'accepted': False, 'error': type(exc).__name__ + ':' + str(exc)})
    else:
        result['cases'].append({'name': name, 'accepted': True})

primary = DomainExit('actual-initial-domain-exit-control')
secondary = OSError('secondary-initial-failure-journal-control')
class FailingStorage:
    def evaluate(self, *args):
        raise primary
class FailureRecorder:
    phase = None
    def context(self, adapter):
        pass
    def __call__(self, event, **payload):
        if event == 'initial_energy_failed':
            assert payload['exception'] is primary
            raise secondary
fake = NS(adapter=object(), storages=(FailingStorage(),),
          unset_energy_states=(object(),), initial_temperatures_k=(325.,))
try:
    service._execute(fake, FailureRecorder(), NS(values={'study': {}, 'resources': {}}))
except Exception as exc:
    result['cases'].append({'name': 'initial_failure_notification_does_not_replace_primary',
                           'primary_preserved': exc is primary,
                           'raised': type(exc).__name__ + ':' + str(exc),
                           'context_preserved': exc.__context__ is primary})
else:
    raise AssertionError('missing injected failure')

result['elapsed_seconds'] = time.monotonic() - begin
result['EOS_calls'] = 0
(OUT / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
