# 来源运行服务：失败、取消与正式记录衔接

基线 `a493619`；首次检查 staged / unstaged diff 均为空。本报告只读原实现，不改生产文件。最初范围为静态接口审查；随后按 Root 明确追加授权执行了两个无水 EOS 的运行状态准入探针，结果单独保存在 `status-closure-red/RESULT.json`。没有运行旧套件、原生实验或安装。逐文件 SHA 见 `READONLY_MANIFEST.json`。

## 两项已经复现的导出缺口

[HIGH] 合法的 unsupported 试算不能导出

- `src/sludge_sandbox/source_prefix_trial.py:319` / `:320` / `:331` 保留原 `unsupported` 结果；例如非正初始库存零回调拒绝。
- `src/sludge_sandbox/source_study_audit.py:177` 的非成功状态白名单遗漏它。
- 实际探针使用原 fixture storage 和真实 column / adapter，零液库存经原 `evaluate_source_prefix_trial` 返回 `unsupported/source_trial_nonpositive_initial_inventory`，`trial.check()` 通过；正式编码以 `source_study_trial_failure_status` 拒绝。
- 修复应保留原状态、reason、绑定和捕获，不在服务层改名为 `numerical_failure`。

[HIGH] 合法的 numerical_failure 干候选不能导出

- `source_dry_transition.py:183` 把实际 reference.status 原样变为 `_TrialStop`；`exact_integration.py:276` 与 `:397` 遇原 `IntegrationError` 返回 `numerical_failure`。
- `source_study_audit.py:259` 的候选状态白名单遗漏它。
- 实际探针复用已保存的制造 seed 初/中点数据及同内容真实 fixture column，原 terminal 纯算术写回后，第一个实际 dry callback 注入 `IntegrationError`。原 candidate/reference 自行返回 `numerical_failure`，保留 1 个失败捕获、0 个接受步，`candidate.check()` 通过；正式编码以 `source_study_candidate_status` 拒绝。
- 总探针时间 0.55153 s，水 `state_tp` / `_solve` 等调用 0。没有篡改状态，也没有从旧 native 档案重建 live 对象。探针是控制与记录互操作证据，不是新的物理验证。

## 可直接使用的原接口

| 原接口 | 已保留内容 | 服务接入位置 |
|---|---|---|
| `_capture_source_observation` (`source_prefix_trial.py:259`) | 调用前 append `TrialCapture`；返回后先保存完整 evaluation，再校验 binding；最后 guard 的失败也保留该返回 | 捕获级观察/持久化应沿此顺序，不能只在顶层函数返回后开始记账 |
| `SourcePrefixTrial` (`:94`, `:287`) | 原完整 integration policy 与剩余 reference policy、controls/outcome bindings、所有实际初/中/端/参考捕获、predictor/prefix、部分 reference、discrepancy、elapsed | 每次返回立即保存完整对象与精确输入；失败不删除已有 prefix/reference |
| `SourceApproachAssessmentError` (`source_approach.py:210`) | proposal、已返回 trial、已生成 comparison / pressure、stage、原异常类型和消息、显式 cause | 直接放正式 `failure` 根；不重复 trial 来补证据 |
| `SourceRootStudyError` (`source_root_comparison.py:133`) | shifted assessment 的 approach/trial；共同端点失败的 refinement 与所有已经返回的 coarse/shifted trial | 记录 `stage` 和原 `records` 次序，不能把失败的第二条路径省略 |
| `SourceDryCandidate` (`source_dry_transition.py:26`, `:137`) | terminal、dry adapter 模式、原 dry policy、partial reference、captures、逐时间/逐格已返回压力条目、原 status/reason | 每个 candidate 返回后先入服务记录，再判其是否可进入下一路径 |
| `SourceDryTransitionError` (`:518`, `:545`) | refinement、已返回 candidates、带 phase/cell 的逐 pair 记录、已返回 pair 或失败 attempts，显式 cause | 异常本身可作为 `failure`；终端/干态候选放其 records/metadata，不新增假 runtime 根 |
| `SourceWetPairCollectionError` (`source_wet_shared_pressure.py:171`, `:305`) | 原 endpoints、shared declaration、完整共同 support、每个唯一请求的输入及先返回后校验的 WaterState、stage、显式 cause | 单独计额外点调用；已请求未返回与未发起请求不可混计 |
| `ExactIntegrationResult` (`exact_integration.py:129`, `:200`) | 已接受 times/states/steps、实际 integrator evaluate 次数、rejected/attempted trials、累计 component residual 和耗时 | 合作取消返回时原样保存；未返回的局部 ledger 不能凭捕获数编造 |

## 取消和异常的确切边界

1. **正常取消宜由服务自身锁存并返回严格 bool。** prefix / exact integrator 在求值前后检查 cancel 和 monotonic wall deadline。干候选也有总局部 wall guard，reference 使用原数值 policy 加剩余 wall allowance。保留原 gate，服务另记总 wall / 全阶段调用预算；每次 stage 之间也检查服务锁存。不得把每 trial / 每 path 的预算当成全运行额度。
2. **取消函数抛异常不是正常取消协议。** prefix 的外层只捕获 `_TrialStop`、`DomainExit`、`_Reject` 和有限 `ValueError/TypeError/AttributeError/OverflowError`（`:349`）。`RuntimeError` / `TimeoutError` 若从 capture 外的 guard、`integrate_exact` guard 或纯后处理穿出，会让当前 trial 未返回。相同异常若出现在 capture 内，通常会被包装为 `IntegrationError` 并保留该捕获。干候选外层虽 catch Exception，但若 integrator 未返回，`reference` 仍为 None，已接受局部 ledger 不在候选中。服务只能报告实际已经取得的证据，不能伪称拥有未返回 reference。
3. **KeyboardInterrupt/SystemExit 与强杀不受上述 Exception 包装保护。** 服务外层应保留最后已经持久化的调用/返回/阶段记录，并明确硬中断时未完成记录的范围。若接现成 supervisor，只复用其运行/取消与回收机制；不能宣称任意 SIGKILL 后可恢复完整 live solver。恢复中断运行不是当前 `source_study_record` 的授权能力。
4. **不能依据 cancel 检查次数计物理成本。** 每轮含多次 guard。integrator 在调 source callback 前先增加 `evaluations`（`exact_integration.py:215`），source callback 可能因自己的 cap 拒绝实际调用，因此失败 reference 的 evaluations 可以大于 `len(captures)`；旧干态测试 `test_source_dry_transition.py:151` 明确覆盖此差别。原实际 source attempts 取启动捕获数；provider 构造、初 U 与额外压力点另计，内部 EOS 更新不可冒称等于 source callback 数。
5. **后处理返回对象的保留还有窄缺口。** `evaluate_source_root_refinement`、`evaluate_source_common_endpoint`、`evaluate_source_dry_transition` 在得到 `result` 后再 `result.check()`；若 check 抛错，现异常携带其上游/输入记录，但不携带该本地 result。其已生成 derived comparison 不等于完整遗失物理捕获，但“保存每个已返回阶段对象”的服务合同需要先留存它或补一个明确的 partial-result 字段。纯 compare 内部尚未返回的局部中间量同样未承诺可取回。
6. **局部失败记录不总等于完整原异常链。** 干候选常规失败变为 `status/reason`；不保存原异常对象/traceback。已知 assessment 异常的显式 `raise ... from exc` 可由正式 codec 保留。codec `_snapshot` (`source_study_record.py:99`) 保存 `__cause__`，并不自动遍历仅存在的 `__context__`。如服务承诺隐式异常链，也应另行有界显式保存，不宣称现 codec 已做到。
7. **纯 check 仍有 CPU/序列化成本。** 完成 reference 的被动复核调用原积分器重放已保存 RHS（`source_prefix_trial.py:222`），零 EOS 但不是常数时间。不要每个捕获都反复完整 encode/decode 所有先前 DAG；最终ization与必要检查算入明确服务/保存阶段预算。总预算到期不能为了导出篡改原 reference 的数值或 wall policy 字段。

## 与 source_study_record 的最小衔接

- 直接调用公开 `encode_source_study(roots, contexts=..., captures=..., metadata=..., provenance=...)` (`source_study_record.py:303`)；它 snapshot 后执行正式 decode/audit。新运行不应先伪造 `source_multicell_native_v1` legacy JSON 再导入，也无需另造平行 solver/controller。
- 根名只使用 `seed/proposal/approach/refinement/common_endpoint/transition/failure`；保留真正已返回对象。未返回对象保持缺失；失败例外可用实际异常或 `SourceStudyFailure(exception_type, message, stage, records)`。不要用普通 dict、假的 check 或 ArchivedTrialView 冒充已验证 stage。
- capture 正式字段至少为 `ordinal`（全局 1 起连续）、`phase`、`packed_input`、精确 `time`、`operator_identity`、`energy_identity`、`interface_modes`、实际 `evaluation` 或显式失败。增加 stage / 原局部 ordinal / role 可用额外原始元数据，不能重写嵌套 TrialCapture 的局部次序。独立 service 全局 journal 不应通过汇总嵌套对象重复计数。
- 原 wet 与新 dry adapter 各自的 `SourceObservationContext` 从本次真实 adapter 得到：完整 operator/energy identity、固定干质量和 modes。dry 只改原允许的选中 cell mode，其能量身份保持原值。不能拿材料 hash 相同代替声明所需的本次 live storage/volume identity。
- `has_capture_failure` (`source_study_schema.py:277`) 是四字段统一判定；`failure/failure_kind/exception/exception_type` 任何字符串，包括空字符串，都表示显式失败。finite closed-schema 的失败返回可以完整保留但不进入成功 observation 索引；无返回必须有实际失败/中断描述。
- 正式 codec 仍会拒绝未知类、非有限数据、坏 fieldset、过大记录和不成立的 typed-stage 绑定。把这种无效对象嵌在 `SourceStudyFailure.records` 内，并不会跳过其闭合 schema / stage 审计。服务应保存独立的有界原始诊断与具体归档失败原因，不能为使失败可导出而放宽科学/关联检查，或谎称正式完整记录已经生成。
- `SourceLiveReference.available=True` 只说明编码时拿到了真实 live 字段；解码后仍是不可执行引用记录，不是可恢复 live 对象。材料资格和 resume 均仍为 False；保留所有旧 P 未过与新 selected 证据的各自 gate，不把程序完成当作科学接受。
- 文件发布直接复用 `publish_record_bytes` (`source_record_io.py:26`) 的同目录临时文件/fsync/排他 link。它不覆盖已有输出，也不是每次运行进度自动持久化协议；服务需要明确启动、每次返回、异常、最终化的保存时机。保存失败需与原运行错误并列，不能触发自动重跑。

## 可执行验收清单

`FAILURE_CANCEL_ACCEPTANCE.json` 给出 20 个可直接转换为测试的场景：注入点、安排、必须断言、原代码/测试定位、优先级。R18 与 R14 已由本轮窄探针确认 RED；其余列为新服务验收要求，**本轮未执行**。现有测试可复用实际制造 fixture，但控制错误注入只验证保存与分支，不产生新的材料物理事实。

重点先执行：R02/R03 合作取消；R04/R05 原始错误与坏返回；R06/R07 原预算；R12/R13/R15/R16 后处理及晚失败；R14/R18 真实状态闭包；R19 输出异常；R20 零物理正式编码与 CLI 一致。其余只在有新实现或未覆盖问题时追加，不重复旧大套件。

## Review Summary

| Severity | Count | Status |
|---|---:|---|
| CRITICAL | 0 | pass |
| HIGH | 2 | confirmed RED |
| MEDIUM | 0 | scope boundaries documented |
| LOW | 0 | pass |

Verdict: WARNING — 两项已复现的合法状态导出缺口需在本阶段关闭。此为新服务前的接口审查，不是对尚未编写实现的最终批准。
