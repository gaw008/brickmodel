# Derived evidence revalidation

Original source/test retained as *.before-derived-check.py. After parent confirmed original native experiment terminal, the new tamper case was actually run against that original source in isolated red-derived import directory with the installed package: 1 test, 5 negative subcases failed (0.005s). This reproduced check accepting altered legal inventory/U polynomials, shared history and both valid/invalid upper times.

check now reconstructs the complete panel using original sample validation and shared builder, which rechecks time order, and compares all derived histories/inventory/U tuples plus exact types and unchanged qualification. The caller-supplied upper boundary is retained in the existing binding tuple, so a replacement valid upper time cannot silently redefine the domain. No duplicate minimum/root algebra or new provenance framework.

Actual complete artificial suite after fix: 9 tests passed in 0.016s (see derived-green.log for authoritative time), no EOS/provider construction. Retained original evidence. No repo edits, installs or native reruns. Physical trajectory/provider authenticity limits from README still apply; this is only saved numerical affine interpolation.
