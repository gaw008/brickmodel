from dataclasses import replace
from fractions import Fraction as F
import unittest
from test_source_net_panel import panel
class IndependentTamperTests(unittest.TestCase):
 def test_equal_numeric_wrong_coefficient_type_rejected(self):
  p=panel();changed=replace(p.inventories[0],linear=float(p.inventories[0].linear))
  with self.assertRaises(ValueError):replace(p,inventories=(changed,*p.inventories[1:])).minima()
 def test_energy_and_history_cannot_be_silently_dropped(self):
  p=panel()
  for name in ('energies','shared_rate_history'):
   with self.subTest(field=name):
    with self.assertRaises(ValueError):replace(p,**{name:getattr(p,name)[:-1]}).check()
 def test_qualification_cannot_claim_acceptance(self):
  with self.assertRaises(ValueError):replace(panel(),qualification='accepted_event').minima()
if __name__=='__main__':unittest.main()
