# Source net panel candidate static review

Static read only of candidate module, eight prepared unittest methods and README; AST parse performed, no imports/test execution/EOS while frozen native run continues. Hashes in STATIC_FREEZE.json. Candidate has not been applied to repository.

Shared N+1 face incidence and liquid/gas phase pairing produce correct exact represented Fraction r0/rm; quadratic coefficient(rm-r0)/(2*hm) is appropriate for affine rate interpolation at unequal strict interior time. U uses total face energy once and is not positivity checked. Same samples retain full typed raw observation and packed state; fixed dry mass, source/energy IDs, redundant rates and exact time are checked for internal consistency. Existing InventoryPolynomial minimum is reused. Prepared tests cover listed cases but have not been executed by reviewer.

[HIGH] Derived panel values can be changed without invalidating check().
File: source_net_panel.py SourceAffinePanel.check/minima.
check revalidates only retained sample hashes; it never compares inventories, energies or shared_rate_history with reconstruction from those samples. Public dataclasses.replace(panel,inventories=(arbitrary valid InventoryPolynomial,...)) preserves samples/bindings; minima then passes check and uses the substituted polynomials. This defeats the stated relationship between saved evidence and queried minima. Static finding, not an executed exploit.
Fix: have check compare all derived tuples with a shared pure reconstruction from validated samples (including ordered upper time), or expose derived values as computed properties/validated private cached values. Reuse current arithmetic/InventoryPolynomial; no new hash or provenance framework needed. Add a bounded manufactured-record negative for changed polynomial/history/energy after native experiment terminates.

No other actionable algebraic defect identified. Source observation provider authentication and physical stage consistency are intentionally not established; README explicitly says samples are manufactured typed records with unused None slots and do not prove a real trajectory/physical admissibility. That limitation is accurate. No event root/writeback/mode authorization is introduced. Approval pending derived-evidence integrity correction and actual post-native tests; no numerical pass claimed here.

## Final derived-evidence repair review

Candidate check now calls the same builder to reconstruct original samples/time-derived history, all fluid inventories and U polynomials, validates tuple/value/exact types and qualification, and compares unchanged upper bound retained in sample_bindings. Thus changing coefficients, dropping entries or replacing the valid upper horizon cannot pass input-only checking. It does not duplicate root/minimum algorithms or create a new hash system.

After parent confirmed native terminal, reviewer actually ran9prepared cases plus3independent negatives:12tests passed0.021s. Additional negatives cover numerically equal float coefficient replacing exact Fraction, dropped energy/history entries and fraudulent acceptance qualification. Explicit manufactured typed records only, no EOS/provider construction. Used current source package plus tmp candidate/review imports; no installed-package qualification asserted by reviewer. Initial static finding remains above; producer preserves original five-subcase RED separately.

Final source5452ffd... and test326955... hashes match notified freeze; recorded FINAL_FREEZE.json. No remaining high correctness finding in this candidate scope. Approve temporary numerical candidate for next controlled integration review, not automatic repository application, physical stage authentication, event/root authorization or model-goal completion.
