"""Independent saved affine-panel audit: stdlib only, no tested panel imports."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github');OUT=Path('/private/tmp/brick-source-net-panel-v1/physics')
paths={'replay':Path('/private/tmp/brick-source-net-panel-native-replay/RESULT.json'),'native':ROOT/'docs/sandbox/research/exact-source-column-v1/native-result.json','audit':ROOT/'docs/sandbox/research/exact-source-column-v1/native-audit.json'}
raw={k:p.read_bytes() for k,p in paths.items()};hashes={k:hashlib.sha256(v).hexdigest() for k,v in raw.items()}
def un(v):
 if isinstance(v,list):return [un(x) for x in v]
 if isinstance(v,dict):
  if set(v)=={'numerator','denominator'}:return F(v['numerator'],v['denominator'])
  if 'type' in v and 'fields' in v:return un(v['fields'])
  if 'dtype' in v and 'values' in v:return un(v['values'])
  return {k:un(x) for k,x in v.items()}
 return v
replay,native,audit=(un(json.loads(raw[k])) for k in ('replay','native','audit'));caps=native['captures'];checks={};results=[];started=time.monotonic()
def check(k,v):checks[k]=bool(v);assert v,k
check('replay_hash',hashes['replay']=='b1652b5b9c0e6887592bee70a0927637df78ea4213eb1411c4ffc87bd274a643')
check('native_hash',hashes['native']==replay['input_sha256']=='033dccd09ed268eeb2ce9570a37d52f66d4eb5da18b68f2f44a89bd01054c4f2')
check('audit_hash',hashes['audit']==replay['audit_sha256'])
check('trial_count',len(replay['trials'])==len(audit['trials'])==7)
expected=[[1,4],[7,10],[14,17],[20,23],[27,30],[33,36],[40,43]]
def derivative(rate,family,i,k):
 if family=='energy':return F(rate['face_energy_w'][i])-F(rate['face_energy_w'][i+1])+F(rate['cell_power_w'][i])
 return F(rate['face_species_mol_s'][i][k])-F(rate['face_species_mol_s'][i+1][k])+F(rate['reaction_species_mol_s'][i][k])
def value(p,x):return p['initial']+p['linear']*x+p['quadratic']*x*x
for j,(trial,prior) in enumerate(zip(replay['trials'],audit['trials'])):
 check(f'{j}_original_status',trial['original_trial']==prior)
 check(f'{j}_capture_selection',trial['capture_indices']==expected[j])
 check(f'{j}_no_admission',trial['material_qualified'] is False and trial['physical_trajectory_or_event_admitted'] is False)
 aa,bb=(caps[i] for i in expected[j]);a=aa['evaluation']['rates'];b=bb['evaluation']['rates'];start=aa['time']['seconds'];hm=bb['time']['seconds']-start;span=F(prior['end'])-start
 check(f'{j}_times',hm>0 and hm<span and start==F(prior['start']) and trial['sample_bindings'][2]['seconds']==F(prior['end']))
 polys=trial['inventory_polynomials']+trial['U_polynomials'];check(f'{j}_layout',len(polys)==15 and len({(p['family'],p['cell'],p['index']) for p in polys})==15)
 bykey={(p['family'],p['cell'],p['index']):p for p in polys}
 for k,p in enumerate(polys):
  fam,i,ix=p['family'],p['cell'],p['index'];initial=aa['packed_input']['internal_energy_j'][i] if fam=='energy' else aa['packed_input']['amounts_mol'][i][ix]
  d0=derivative(a,fam,i,ix);dm=derivative(b,fam,i,ix)
  check(f'{j}_{k}_coefficients',p['initial']==F(initial) and p['linear']==d0 and p['quadratic']==(dm-d0)/(2*hm))
  check(f'{j}_{k}_two_actual_derivatives',p['linear']==d0 and p['linear']+2*p['quadratic']*hm==dm)
 minima=[]
 for entry in trial['minima']:
  fam,i,k,saved_min,saved_at=entry;p=bykey[(fam,i,k)];locations=[F(),span]
  if p['quadratic']>0:
   vertex=-p['linear']/(2*p['quadratic'])
   if 0<vertex<span:locations.append(vertex)
  minimum,at=min((value(p,x),x) for x in locations)
  check(f'{j}_{fam}_{i}_{k}_minimum',minimum==saved_min and at==saved_at);minima.append((minimum,at))
 check(f'{j}_all_minima',len(minima)==12)
 for k,x in enumerate((F(),span/4,span/2,3*span/4,span)):
  def integ(v0,vm):return F(v0)*x+(F(vm)-F(v0))*x*x/(2*hm)
  inv=trial['inventory_polynomials'];up=trial['U_polynomials']
  water_change=sum(value(p,x)-p['initial'] for p in inv if p['index'] in (0,3))
  water_boundary=sum(integ(a['face_species_mol_s'][0][idx],b['face_species_mol_s'][0][idx])-integ(a['face_species_mol_s'][-1][idx],b['face_species_mol_s'][-1][idx]) for idx in (0,3))
  phase=sum(integ(a['reaction_species_mol_s'][i][idx],b['reaction_species_mol_s'][i][idx]) for i in range(3) for idx in (0,3))
  check(f'{j}_{k}_phase_zero',phase==0)
  check(f'{j}_{k}_global_water',water_change==water_boundary)
  uc=sum(value(p,x)-p['initial'] for p in up)
  ue=integ(a['face_energy_w'][0],b['face_energy_w'][0])-integ(a['face_energy_w'][-1],b['face_energy_w'][-1])+sum(integ(a['cell_power_w'][i],b['cell_power_w'][i]) for i in range(3))
  check(f'{j}_{k}_global_U',uc==ue)
 results.append({'trial':j,'prior_status':prior['status'],'sample_span_s':str(hm),'panel_horizon_s':str(span),'min_inventory':str(min(m for m,t in minima)),'minima_checked':len(minima),'polynomials_checked':len(polys),'conservation_times_checked':5})
result={'checks_passed':len(checks),'checks':checks,'input_hashes':hashes,'trials':results,'elapsed_s':time.monotonic()-started,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Saved exact numerical affine panels only. No polynomial-to-Euler/accepted trajectory match asserted, no physical root or material admission, no EOS/model imports.'};(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
