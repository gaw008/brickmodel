"""Independent pure saved-record checks; no physics evaluation or provider."""
from dataclasses import replace
from fractions import Fraction as F
import unittest

from test_source_net_panel import panel, sample


class IndependentSourcePanelTests(unittest.TestCase):
    def test_retained_evaluation_qualification_is_bound(self):
        first = sample(F())
        built = panel(first)
        object.__setattr__(first.evaluation, "material_qualified", True)
        with self.assertRaises(ValueError):
            built.check()

    def test_total_water_and_U_telescope_in_quadratic_term(self):
        first = sample(F(), liquid_faces=(0., .13, -.77, 0.), phase=(.11, -.31, .23))
        middle = sample(F(2, 7), liquid_faces=(0., -.17, .97, 0.), phase=(-.21, .43, -.71), role="interior")
        built = panel(first, middle)
        liquid_and_vapor = [p for p in built.inventories if p.index in (0, 3)]
        self.assertEqual(sum((p.linear for p in liquid_and_vapor), F()), F())
        self.assertEqual(sum((p.quadratic for p in liquid_and_vapor), F()), F())
        self.assertEqual(sum((p.quadratic for p in built.energies), F()), F())
        self.assertEqual(sum((p.linear for p in built.energies), F()), F(-3))

    def test_wrong_exact_coefficient_type_and_dropped_history_are_rejected(self):
        built = panel()
        changed = replace(built.inventories[0], linear=float(built.inventories[0].linear))
        for forged in (
            replace(built, inventories=(changed, *built.inventories[1:])),
            replace(built, shared_rate_history=built.shared_rate_history[:-1]),
        ):
            with self.assertRaises(ValueError):
                forged.minima()


if __name__ == "__main__":
    unittest.main()
