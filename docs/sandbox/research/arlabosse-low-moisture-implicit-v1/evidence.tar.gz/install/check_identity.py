import hashlib,json,sys
from pathlib import Path
ROOT=Path('/Users/wanggaoying/Desktop/brickmodel-github')
WORK=Path('/private/tmp/arlabosse-low-moisture-implicit-v1/install')
INSTALLED=Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
def snapshot(directory):
    return {str(p.relative_to(directory)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
source=snapshot(ROOT/'src/sludge_sandbox')
if sys.argv[1]=='freeze':
    destination=WORK/'SOURCE_FREEZE.json'
    if destination.exists(): raise FileExistsError(destination)
    destination.write_text(json.dumps({'base_commit':'8d104d9','files':source},indent=2)+'\n')
    print({'files':len(source),'python_modules':sum(n.endswith('.py') for n in source)})
else:
    installed=snapshot(INSTALLED)
    frozen=json.loads((WORK/'SOURCE_FREEZE.json').read_bytes())['files']
    result={'passed':source==installed==frozen,'file_count':len(source),'source':source,'installed':installed,'frozen':frozen}
    (WORK/sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
    print({'passed':result['passed'],'files':len(source)})
    assert result['passed']
