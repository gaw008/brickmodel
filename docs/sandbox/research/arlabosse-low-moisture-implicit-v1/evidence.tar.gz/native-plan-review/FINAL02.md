# 预登记增量复核 FINAL02

**APPROVE：上一报告两项 MEDIUM 和一项 LOW 已关闭。** 本结论仅允许按预登记进入唯一监督短程验收；不是已运行、已收敛或材料资格结论。保留原 `NATIVE_PLAN_REVIEW.md`，本次未执行 EOS、驱动或测试。

新增检查逐格从保存的实际 pure pressure、join activity、T/Vg、M/md 与已绑定 Kph/Kv/pe/hv 重算 alpha/beta 和 BE 系数；以原库存核 J/E 的 BE 与共享库存等式、H=hv·E。静态核对正式 host 中 phase tuple 确由同一 local J 构造，外面使用同一 E/H，因此可与原逐格 U/Nc/Nv 及累计账核验相接，不产生第二 latent 热。

热浴检查采用慢阶段真实反解 T，精确 Fraction 计算 h·G·(Tbath−T)，并核实际外面热量 = 该值 + 保存的 heat projection；符号与原 energy=-Q 相符。step fee 现独立累加两次实际状态投影绝对值、heat projection、slow face 分解和 moisture H/mol 投影，再与 step fee、累计 fee 和原预算比较。此费用只覆盖实际算术投影，不是冻结、Lie 截断或材料误差界。

监督 inputs 已加入实际读取的旧 fast 阶段 INITIAL.json。报告已输出 T/P/Nc/Nv/E/H/Q 的两组“细减粗”差，以及两端 T 反解界/P 解码界之和；这些界不能解释为全程传播或时间离散误差界。原同 case、一次构造、2/4/8 步、.05 s、5/9/17 调用、U/T/P/资源门和两个 [1.5,2.5] 主比值门未删除或放宽；全场、空间、材料结论仍 false。

最终审查 SHA256：
- native_driver.py：`f67a0a584df2fb29cdb8528c9c15177fe7a60aa3fcc2d08476e80ff34edd8b40`
- run_supervised_native01.py：`4b36ca9fbb00f86018395cd3abbe64b7123bc284e71e964d493666e3eb91a739`
- NATIVE_PLAN.md：`db8e8cac0e8fe8ea136b68c0761c28e8eeb318d3cd7609869cc83a269057f87b`

两份修改后的 Python AST 解析成功；本次 git diff Python 为空，未更改正式源码或原报告。
