# 唯一短程 native 预登记静态复核

结论：**有条件 APPROVE；下列运行前证据缺口需闭合。** 未发现本次静态范围内确定的物理符号或时间推进错误；本结论不是运行通过。未执行 EOS 或测试。

已核：`native_case.py` 与上一 fast-inverse 阶段逐字相同；driver 只调用一次 make_case，三路都从同一 initial 开始，.05 s、2/4/8 步，完成/尝试 RHS 均要求 5/9/17。m/q、L95、M、R 来自当前构造对象，再与旧 INITIAL 比较，不是复制旧节点充当新读取。两阶段各推进 h、物理时钟只增 h；local/end observations 对应正确。逐格 Nc、三个气体库存、U 与实际面/phase/投影账，以及累计 E/H/Q 守恒已核；没有要求有符号 Hout>0，也无额外 latent 热。实际反解 U≤1e−5 J、T≤1e−6 K、325–338 K、完整 P 误差包络 90–110 kPa、原 1e−8 J/1e−12 mol 算术预算保持；60/80/100+5 s 资源层级保持。两个比值门只对外格 Nv 与累计 E，以非零相邻差绝对值之比要求 [1.5,2.5]；全场/空间/材料资格显式 false，不能把该门扩称完整收敛或误差上界。

[MEDIUM] 分项费用和共享积分的原生独立验收尚不完整。
File: `native_driver.py:46–76`。
Issue: 状态守恒核对成立，但 fee_sum 只累加 ledger 自报 step fee。尚未独立验证 local J/E 的 BE 方程、H=hv·E、phase tuple 与 local steps 对应，以及热浴 Q=h·G(Tbath−Tlocal)。这些错误可在相互一致但错误的 ledger 内仍满足守恒。
Fix: 从已保存对象用 Fraction 复核以上等式；能量费按两次 state energy 投影绝对值 + 实际 heat projection + slow faces 的 decomposition 与 moisture-enthalpy projection 绝对值复算；库存费按两次所有库存投影绝对值 + slow moisture-molar projection 复算。系数应与已有真实 origin、join/P/Vg/K/control 对应，保留舍入残差与物理/冻结误差的区别，无需新增 EOS。

[MEDIUM] 读取的比较基准未绑定监督输入。
File: `native_driver.py:22`、`run_supervised_native01.py:17`。
Issue: OLD/INITIAL.json 实际影响 acceptance，却不在 input_paths。
Fix: 将 `/private/tmp/arlabosse-low-moisture-fast-inverse-v1/native01/INITIAL.json` 加入监督 inputs；不能把当前目录中未冻结的比较数据当已绑定证据。

[LOW] 报告字段尚未完全兑现预登记。
File: `native_driver.py:81–94`。
Issue: 当前只输出各场原值、T_error 和两个主比值；预登记还要求其他场差值及 P 数值界。
Fix: 增加 T/P/Nc/Nv/H/Q 等两组相邻差及 P_error（不新增通过门、不事后调整主比值范围）。比较旧 midpoint 可仅标诊断，不作为精确解。

版本 SHA256：driver `1fdfd64d6a4948f2bfc4a909318d2b49a2354685e7e479c5b2db4a75e4f42d6c`；plan `db8e8cac0e8fe8ea136b68c0761c28e8eeb318d3cd7609869cc83a269057f87b`；case `1f775b7536168141a30996011315898b0a63ebdea83d4045e1c70f72989b20c6`；supervisor wrapper `69a3e2e7175fcb67f089bc835eb6cd76746a62ec4edaf3c5d450067053e634ff`。相关 Python AST 解析成功；ruff/mypy/pylint/black 不可用，未安装。git diff Python 为空；现有未跟踪源码归其他作者，未修改。
