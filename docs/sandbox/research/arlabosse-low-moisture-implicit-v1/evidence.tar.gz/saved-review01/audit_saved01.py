"""Bounded passive review of the one saved short split refinement; no app imports."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import time
import traceback
import xml.etree.ElementTree as ET

WORK = Path('/private/tmp/arlabosse-low-moisture-implicit-v1')
OLD = Path('/private/tmp/arlabosse-low-moisture-fast-inverse-v1')
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
INSTALLED = Path('/private/tmp/brick-cooling-thermoelastic-v1/installed-venv/lib/python3.12/site-packages/sludge_sandbox')
OUT = WORK/'saved-review01'
checks, metrics = [], []
started = time.monotonic()


def hook(d):
    return F(d['numerator'], d['denominator']) if set(d) == {'numerator','denominator'} and all(type(v) is int for v in d.values()) else d


def read(path):
    return json.loads(path.read_text(), object_hook=hook)


def check(name, value):
    checks.append({'id': name, 'passed': bool(value)})


def total(states, water=False):
    return sum((F(s['liquid_water_mol'])+F(s['gas_amounts_mol'][2]) if water else F(s['internal_energy_j']) for s in states), F())


def main():
    initial = read(WORK/'native01/INITIAL.json')
    report = read(WORK/'native01/ACCEPTANCE.json')
    old = read(OLD/'native01/INITIAL.json')
    check('original_826_distinct_gates_passed', report['passed'] is True and len(report['checks']) == 826 and len({x['id'] for x in report['checks']}) == 826 and all(x['passed'] is True for x in report['checks']))
    check('common_original_initial_source_and_provenance', initial == old and (WORK/'native_case.py').read_bytes() == (OLD/'native_case.py').read_bytes())
    check('qualification_and_driver_limit', all(report[k] is False for k in ('material_qualified','all_field_temporal_convergence_demonstrated','spatial_convergence_demonstrated')) and report['driver_seconds'] < 80)
    M, R = map(F, (initial['actual_source_nodes']['M'], initial['actual_source_nodes']['R']))
    inverse_allowances, inverse_bounds = [], []
    for steps, metric in zip((2,4,8), report['metrics']):
        run = read(WORK/f'native01/RUN_{steps}.json')
        check(f'n{steps}_shape_clock_counts_scope', run['status'] == 'completed' and run['reason'] is None and run['failed_trial'] is None and run['states'][0] == initial['states'] and run['times_s'] == [F(.05)*i/steps for i in range(steps+1)] and len(run['states']) == steps+1 and len(run['ledgers']) == len(run['observations']) == steps and run['evaluations_attempted'] == run['evaluations_completed'] == 1+2*steps and run['elapsed_seconds'] < 60 and run['material_qualified'] is False and run['numerical_policy']['order'] == 1)
        E = H = Q = dU = dN = feeU = feeN = F()
        for j, (before, after, ledger, endpoint) in enumerate(zip(run['states'],run['states'][1:],run['ledgers'],run['observations'])):
            key = f'n{steps}_step{j}'
            local = ledger['local_steps']; h = ledger['duration_s']
            check(key+'_single_h_and_reused_context', h == F(.05)/steps and (j == 0 or ledger['origin_rates'] == run['observations'][j-1]))
            for tag, old_states, new_states, faces, phase, error in (
                ('local',before,ledger['local_states'],ledger['local_faces'],ledger['phase_water_mol'],ledger['local_roundoff']),
                ('slow',ledger['local_states'],after,ledger['slow_faces'],(F(),)*2,ledger['slow_roundoff'])):
                valid = True
                for i, (o,n) in enumerate(zip(old_states,new_states)):
                    l,r = faces[i:i+2]
                    valid &= F(n['internal_energy_j'])-F(o['internal_energy_j']) == l['energy_j']-r['energy_j']+error['energy_j'][i]
                    valid &= F(n['liquid_water_mol'])-F(o['liquid_water_mol']) == l.get('moisture_mol',F())-r.get('moisture_mol',F())-phase[i]+error['liquid_mol'][i]
                    for k in range(3):
                        valid &= F(n['gas_amounts_mol'][k])-F(o['gas_amounts_mol'][k]) == l['gas_mol'][k]-r['gas_mol'][k]+(phase[i] if k == 2 else F())+error['gas_mol'][i][k]
                    valid &= min(n['liquid_water_mol'],*n['gas_amounts_mol']) >= 0
                check(key+'_'+tag+'_all_cell_balances_and_positivity', valid)
                dU += sum(error['energy_j'],F()); dN += sum(error['liquid_mol'],F())+sum((row[2] for row in error['gas_mol']),F())
            E += local[-1]['outlet_transfer_mol']; H += local[-1]['outlet_enthalpy_j']; Q -= ledger['slow_faces'][-1]['energy_j']
            check(key+'_water_U_prefix', total(after,True)-total(initial['states'],True) == -E+dN and total(after)-total(initial['states']) == Q-H+dU)
            valid = True
            for i,(s,w,v) in enumerate(zip(before,ledger['coefficients'],local)):
                c = v['coefficients']; a,b,c0,f,hv = [c[k] for k in ('a_s_inv','b_s_inv','c_s_inv','forcing_mol_s','vapor_enthalpy_j_mol')]
                point = w['inverse']['point']; mech = point['fluid']['mechanical']; pure = w['phase']['equilibrium']['pure_equilibrium']
                alpha = F(pure['equilibrium_partial_pressure_pa'])*F(w['join_point']['activity'])*M/(F(.01)*F(.15)); beta = R*F(mech['temperature_k'])/F(mech['gas_volume_m3'])
                kv = F(1e-8) if i == 1 else F()
                valid &= w['state'] == s and w['inverse'] == ledger['origin_rates']['cells'][i]['inverse'] and w['phase'] == ledger['origin_rates']['cells'][i]['phase'] and w['source_state_binding_verified'] is True
                valid &= c == w['coefficients'] and a == F(1e-10)*alpha and b == F(1e-10)*beta and c0 == kv*beta and f == 0 and hv == F(pure['vapor']['enthalpy_j_mol'])
                valid &= v['duration_s'] == h and v['determinant'] == 1+h*(a+b+c0)+h*h*a*c0 and v['nc0_mol'] == F(s['liquid_water_mol']) and v['nv0_mol'] == F(s['gas_amounts_mol'][2])
                valid &= v['phase_transfer_mol'] == h*(a*v['nc1_mol']-b*v['nv1_mol']) and v['outlet_transfer_mol'] == h*(c0*v['nv1_mol']-f) and v['outlet_enthalpy_j'] == hv*v['outlet_transfer_mol']
                valid &= v['nc1_mol'] == v['nc0_mol']-v['phase_transfer_mol'] and v['nv1_mol'] == v['nv0_mol']+v['phase_transfer_mol']-v['outlet_transfer_mol']
                valid &= c['input_classification'] == 'manufactured_test_fixture' and dict(w['origin_classifications'])['local_phase_coefficient'] == 'manufactured_test_fixture' and v['frozen_coefficient_model_error'] is None and v['time_discretization_error'] is None
            check(key+'_actual_coefficients_shared_BE_and_classification',valid)
            bathT = ledger['slow_rates']['cells'][-1]['inverse']['point']['fluid']['mechanical']['temperature_k']
            check(key+'_selected_local_and_slow_terms', local[0]['outlet_transfer_mol'] == 0 and all(f['gas_mol'] == [F()]*3 for f in ledger['slow_faces']) and ledger['slow_faces'][-1]['energy_j'] == ledger['slow_faces'][-1]['conduction_j'] and ledger['local_faces'][-1]['energy_j'] == local[-1]['outlet_enthalpy_j'] and -ledger['slow_faces'][-1]['energy_j'] == h*F(.001)*(F(350.)-F(bathT))+ledger['heat_projection_j'])
            eU = abs(ledger['heat_projection_j']); eN = F()
            for error in (ledger['local_roundoff'],ledger['slow_roundoff']):
                eU += sum(map(abs,error['energy_j']),F()); eN += sum(map(abs,error['liquid_mol']),F())+sum((abs(x) for row in error['gas_mol'] for x in row),F())
            for face in ledger['slow_faces']:
                eU += abs(face['energy_decomposition_roundoff_j'])+abs(face.get('moisture_enthalpy_projection_j',F())); eN += abs(face.get('moisture_molar_projection_mol',F()))
            check(key+'_independent_fees',eU == ledger['step_energy_roundoff_j'] and eN == ledger['step_inventory_roundoff_mol']); feeU += eU; feeN += eN
            valid = True
            for states,rates in ((ledger['local_states'],ledger['slow_rates']),(after,endpoint)):
                for s,cell in zip(states,rates['cells']):
                    inv=cell['inverse']; p=inv['point']; m=p['fluid']['mechanical']; residual=F(p['total_internal_energy_j'])-F(s['internal_energy_j']); allowance=abs(residual)+F(p['energy_error_j'])
                    baseU=float(F(p['fluid']['internal_energy_j'])+F(p['solid_internal_energy_j']))
                    valid &= inv['target_energy_j'] == s['internal_energy_j'] and inv['energy_residual_j'] == residual and float(F(baseU)+p['excess_internal_energy_j']) == p['total_internal_energy_j']
                    valid &= allowance <= F(1e-5) and allowance/F(p['minimum_heat_capacity_j_k']) <= F(inv['temperature_error_bound_k']) <= F(1e-6) and 325 <= m['temperature_k'] <= 338
                    valid &= F(90000) <= F(m['pressure_pa'])-F(p['pressure_error_pa']) and F(m['pressure_pa'])+F(p['pressure_error_pa']) <= F(110000)
                    valid &= p['excess']['moisture_kg_water_per_kg_dry'] == F(s['liquid_water_mol'])*M/F(.01) <= F(.15) and p['excess_internal_energy_j'] == F(.01)*p['excess']['h_ex_j_kg_dry'] and p['material_qualified'] is False
                    inverse_allowances.append(float(allowance)); inverse_bounds.append(inv['temperature_error_bound_k'])
            check(key+'_actual_nested_full_U_and_original_inverse_gates',valid)
        endcells=run['observations'][-1]['cells']; end=run['states'][-1]
        reconstructed={'steps':steps,'integrator_seconds':run['elapsed_seconds'],'RHS':1+2*steps,'T_k':[c['inverse']['point']['fluid']['mechanical']['temperature_k'] for c in endcells],'P_pa':[c['inverse']['point']['fluid']['mechanical']['pressure_pa'] for c in endcells],'T_error_k':[c['inverse']['temperature_error_bound_k'] for c in endcells],'P_error_pa':[c['inverse']['point']['pressure_error_pa'] for c in endcells],'Nc_mol':[s['liquid_water_mol'] for s in end],'Nv_mol':[s['gas_amounts_mol'][2] for s in end],'E_mol':E,'H_j':H,'Q_j':Q,'energy_roundoff_j':feeU,'inventory_roundoff_mol':feeN}
        check(f'n{steps}_metrics_and_total_fees',reconstructed == metric and feeU == run['energy_roundoff_used_j'] <= F(run['energy_roundoff_budget_j']) == F(1e-8) and feeN == run['inventory_roundoff_used_mol'] <= F(run['inventory_roundoff_budget_mol']) == F(1e-12))
        metrics.append(reconstructed)
    ratios={}
    for name,values in [('outer_Nv',[F(m['Nv_mol'][-1]) for m in metrics]),('cumulative_E',[m['E_mol'] for m in metrics])]:
        d=[abs(a-b) for a,b in zip(values,values[1:])]; ratio=float(d[0]/d[1]); ratios[name]=ratio
        check(name+'_original_refinement_gate',min(d)>0 and 1.5<=ratio<=2.5 and report['refinement'][name] == {'successive_differences':d,'ratio':ratio})
    for left,right,saved in zip(metrics,metrics[1:],report['field_differences']):
        check(f'n{left["steps"]}_field_differences_and_bounds',all(saved[k+'_fine_minus_coarse'] == [F(b)-F(a) for a,b in zip(left[k],right[k])] for k in ('T_k','P_pa','Nc_mol','Nv_mol')) and all(saved[k+'_fine_minus_coarse'] == right[k]-left[k] for k in ('E_mol','H_j','Q_j')) and all(saved[k+'_sum_of_endpoint_bounds'] == [F(a)+F(b) for a,b in zip(left[k],right[k])] for k in ('T_error_k','P_error_pa')))
    meta=read(WORK/'supervised-native01/metadata.json'); status=read(WORK/'supervised-native01/status.json')
    normalized={k:v['sha256'] if isinstance(v,dict) else v for k,v in meta['inputs_before'].items()}
    check('supervision_terminal_deadline_and_inputs',status['status']=='complete' and status['returncode']==0 and status['cleanup']['leader_reaped'] is True and status['elapsed_s']<105 and meta['timeout_s']==100 and meta['cleanup_grace_s']==5 and '-I' in meta['command'] and status['inputs_unchanged'] is True and normalized==status['inputs_after'])
    check('plan_driver_case_saved_input_identity',all(normalized[str(WORK/n)] == hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in ('NATIVE_PLAN.md','native_driver.py','native_case.py','run_supervised_native01.py')))
    frozen=read(WORK/'install/SOURCE_FREEZE.json')['files']
    check('184_files_177_modules_and_runtime_input_coverage',len(frozen)==184 and sum(k.endswith('.py') for k in frozen)==177 and all(normalized[str(base/k)]==sha for base in (ROOT/'src/sludge_sandbox',INSTALLED) for k,sha in frozen.items()))
    for name in ('BEFORE_TESTS.json','AFTER_TESTS.json','AFTER_NATIVE01.json'):
        d=read(WORK/'install'/name); check('install_'+name,d['passed'] is True and d['source']==d['installed']==d['frozen']==frozen and d['file_count']==184)
    suites=ET.parse(WORK/'install/INSTALLED_TESTS01.xml').getroot().findall('.//testsuite')
    test_count=sum(int(s.attrib['tests']) for s in suites); test_seconds=sum(float(s.attrib['time']) for s in suites)
    check('actual_installed_regression_xml',test_count==46 and all(int(s.attrib.get(k,0))==0 for s in suites for k in ('failures','errors','skipped')))
    return {'ratios':ratios,'integrator_seconds':[m['integrator_seconds'] for m in metrics],'driver_seconds':report['driver_seconds'],'supervisor_seconds':status['elapsed_s'],'tracked_inputs':len(normalized),'installed_tests':test_count,'installed_test_seconds':test_seconds,'inverse_records_checked':len(inverse_bounds),'maximum_U_allowance_j':max(inverse_allowances),'maximum_T_bound_k':max(inverse_bounds),'energy_fees_j':[float(m['energy_roundoff_j']) for m in metrics],'inventory_fees_mol':[float(m['inventory_roundoff_mol']) for m in metrics]}


try:
    summary=main()
except Exception:
    summary={'exception':traceback.format_exc()}; check('audit_exception',False)
result={'passed':all(c['passed'] for c in checks),'checks':checks,'summary':summary,'elapsed_seconds':time.monotonic()-started,'scope':'Saved JSON/Fraction/XML only; no application import, EOS, native or test execution. Original 826 gate records read; independent grouped checks recomputed below.'}
with (OUT/'SAVED_REVIEW01.json').open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False); f.write('\n')
print(json.dumps({'passed':result['passed'],'check_count':len(checks),'failures':[c['id'] for c in checks if not c['passed']],'summary':summary,'elapsed_seconds':result['elapsed_seconds']},indent=2))
raise SystemExit(0 if result['passed'] else 1)
