# Initial independent split-host review

Scope: the new pure algebra leaf and explicit low-moisture split host, plus their calls into unchanged source-state, full-U inverse, phase, shared integral and projection helpers. No EOS, native execution, installation, old trajectory replay or author-test rerun. All writes are confined to this review directory. This initial report and actual failing probes remain even if later candidates fix them.

## Findings

[HIGH] Completed source observation is lost on post-return cancellation

File: `src/sludge_sandbox/low_moisture_split_column.py:193`

The helper increments `evaluations_completed` after `column.evaluate` returns, then calls the cancellation/time guard before returning the actual observation to its caller. A cancellation arriving during this first source evaluation leaves only the original inventories and a blank `origin_decode` failed trial. The actual first dry-state inverse/phase/boundary observation, which the completed counter says was produced, is absent from the result. The same ordering affects later decodes. Save the completed state and the same actual rates object into the incomplete trial before running the post-call guard. Do not rerun the observation or commit an incomplete macrostep.

Actual evidence: `FAILURE_RED01.log/.xml`, first test: `cancelled`, one attempted and one completed RHS, no accepted step, but no saved actual observation. The probe uses the actual host with manufactured EOS fixtures.

[HIGH] Final source identity work can exceed the wall limit and still commit completion

File: `src/sludge_sandbox/low_moisture_split_column.py:233`

The last post-RHS guard is followed by the full final model/source identity calculation and atomic acceptance without another resource gate. Time consumed by this final check can push the run beyond `maximum_wall_seconds`, yet the result is `completed` and accepts the step. Check cancellation/deadline after final identity validation and before acceptance; use a consistent final elapsed measurement when returning a completed result.

Actual evidence: `FAILURE_RED01.log/.xml`, second test: a deterministic clock advances to 2 s during the final digest while the limit remains 1 s. The actual host returns `completed` with `elapsed_seconds == 2.0`, failing the expected resource-limit/non-acceptance assertion. This is a clock seam, not a claim of a measured two-second native source check.

[MEDIUM] Derived coefficient label hides manufactured and virtual inputs

File: `src/sludge_sandbox/low_moisture_split_column.py:111`

The derived a/b values include a manufactured Kph; c/f include explicit virtual Kv and external vapor pressure. Their combined leaf record currently says only `input_classification='derived_from_evidence'`. Source IDs and false material qualification remain, but do not explicitly expose these input categories. Record a small origin-classification mapping on the bound coefficient witness (source pressure/activity/hv, manufactured Kph, virtual contact, numerical freezing), and conservatively classify the combined declared coefficients as manufactured. No change to numbers, source scope or error policy is needed.

## Confirmed mechanics

- The rational BE matrix, positive determinant and shared J/E/H update agree with the stated two-pool equations. Zero coefficients, h=0, signed vapor reference and exact values remain admitted; optional float readouts preserve independent projection residuals and reject overflow/underflow.
- The host passes exact J/E/H into one actual state projection. It adds no second phase latent-energy term. Only the last cell gets nonzero contact c/f; phase redistributes Nc/Nv within each cell.
- Each suboperator uses h and accepted physical time advances only h. The second stage uses the new actual local full-U decode, internal closed-column transport and heat-only external face; its phase rates and boundary vapor rates are discarded from the update.
- Both state-writeback fees, used internal decomposition/carried-energy/moisture projection fees and heat-bath projection are included. Unused optional leaf readout projections are not charged. Failed candidate costs remain separate from accepted cumulative costs.
- Exact ControlledVaporColumn admission preserves the existing exact low-moisture storage/column checks. Full original U, per-cell inverse energy/minimum-Cv tolerance, pressure intervals, original source identity and low-W inventory bounds remain. Prior midpoint/exact-event/programmed paths are unchanged.
- Successful fixed steps require one initial plus two fresh RHS calls per step. The last accepted observation is reused as the next origin and revalidated against actual state/source context before coefficient freezing.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 2 | warn |
| MEDIUM | 1 | info |
| LOW | 0 | pass |

Verdict: WARNING — resolve the two failure/resource findings and explicit coefficient metadata before final freeze. Algebra/host structure approval does not establish whole-step entropy, coupled convergence, material qualification or a completed Goal.

Snapshot note: READ_SNAPSHOT01.json/HOST_REVIEWED01.py.txt were captured after the RED execution while ROOT was applying fixes, and describe that post-run candidate. They are not claimed to freeze the pre-fix RED source bytes. The original failure outputs and original probe source remain separate and unchanged.
