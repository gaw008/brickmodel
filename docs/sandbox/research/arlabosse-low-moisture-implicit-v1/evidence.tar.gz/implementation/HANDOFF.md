# Frozen local moisture backward-Euler leaf

Scratch-only implementation based on `long-drying-design/LONG_DRYING_DESIGN.md`. No production files, source data, installation, native process or EOS were changed or run. The module has only standard-library imports.

`FrozenLocalMoistureCoefficients(a_s_inv,b_s_inv,c_s_inv,forcing_mol_s,vapor_enthalpy_j_mol,energy_reference_id,source_ids,input_classification)` accepts exact Fraction/int/finite float/finite Decimal values. a/b/c/f are nonnegative; hv is finite and signed because a common formation reference need not have positive enthalpy. Coefficients remain declared inputs. This leaf does not verify that a/b derive from one actual Kph or c/f from one Kv, nor does it authenticate frozen T/P/Vg or donor applicability.

`backward_euler_local_moisture(Nc0,Nv0,h,coefficients)` returns immutable `LocalMoistureStep`. Nc0/Nv0/h must be nonnegative. Inputs are not projected to float. Exact fields are `nc1_mol`, `nv1_mol`, `phase_transfer_mol` (Jphase), `outlet_transfer_mol` (Eout), and `outlet_enthalpy_j` (Hout). `energy_change_j=-Hout`; `additional_latent_energy_j=0`. Coefficient and step identities record the declared frozen input and numerical policy. The coefficients are copied/revalidated at entry.

The rational solve uses the positive determinant `1+h(a+b+c)+h²ac`. It checks the shared exact identities:

- `Nc1=Nc0-Jphase`
- `Nv1=Nv0+Jphase-Eout`
- `Hout=hv*Eout`

All exact states stay nonnegative for nonnegative frozen coefficients and h. Closed c=f=0 preserves total water; humid f>0 allows negative net Eout and rewetting. For positive finite a/b/c/h and original water, the vacuum remainder stays strictly positive, including very large steps. This is a backward-Euler map, not an exact exponential solution or a physical finite drying-out event.

`step.project()` is a separate optional readout. It projects Nc1, Nv1, J, E and H independently and retains each signed rational roundoff and its exact absolute error. With errors δNc,δNv,δJ,δE,δH, the reported stock/transfer residuals are δNc+δJ and δNv−δJ+δE; the shared enthalpy readout residual is δH−hv·δE. These are not declarations that a host update or complete budget passed. ROOT can use the same exact J/E to update actual inventory/U and then account for that host's own final projections. Positive-to-zero underflow and overflow reject the optional projection; the exact step remains available for failure records. No clipping or threshold deletion occurs.

`numerical_policy()` exposes ID `FROZEN_LOCAL_MOISTURE_BACKWARD_EULER_V1`, formal order 1, exact-rational discrete algebra, optional projection policy, and explicit nonclaims. Every record marks source-state binding, complete host budget, material and training qualification false; frozen-coefficient and time-discretization errors remain unknown. Common hv→hv+C shifts H by C·E and is consistent with Δtotal-water=−E. No second latent contribution is present.

Evidence:

- `RED01.log/xml`: tests were written first; module absence caused collection failure. This is not a claim about a pre-existing material defect.
- `GREEN01.log/xml`: 36 pure manufactured tests passed in 0.03 s. Includes an independently eliminated 2×2 numerical solution, true zero coefficients/time, closed and humid systems, degenerate singular-A cases, large-h positivity, signed-reference covariance, independent projection residuals, rejection with exact result retained, bad inputs and metadata isolation.
- `FIRST_ORDER.json`: independently evaluated forced matrix exponential for `A=[[-2,1],[2,-4]]`, forcing `(0,5)`, initial `(3,1)`, final t=1. At 8/16/32/64 steps, max inventory errors were 0.0507171/0.0254331/0.0127239/0.00636230; consecutive refinement ratios were 1.994139/1.998844/1.999889. These establish observed first-order behavior for this manufactured frozen problem only.
- `SHA01.json`: module `14498567279698b677da131bac019767a8ee024bde5d5fa5106292f09f570e72` (11,213 bytes); tests `f5f705453b5c19c2a01c02f12f78d94d1df6e14a806c34452248087f5e60e537`. AST parsing passed.

No actual source trajectory, real-material long drying, coupled splitting stability, full-step entropy, temporal/spatial convergence, or native performance result is claimed. ROOT owns source coefficient binding, shared host application, fresh full-U inverse/domain checks, adaptive rejection and later independent review/native validation.
