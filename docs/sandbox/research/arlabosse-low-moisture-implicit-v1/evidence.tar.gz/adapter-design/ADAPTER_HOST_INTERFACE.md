# 最小来源适配与 Lie 主机接口建议

结论：可直接复用现有 `ControlledVaporColumn.evaluate`、`low_moisture_water_point`、`_integrals`、`_advance` 和 `SourceColumnRun`，仅新增来源系数适配、分步 ledger 与一个独立积分函数。以下是待实现接口设计；没有运行 EOS、实现/迁入源码、安装或启动 native。读取的实际版本见 `READ_SNAPSHOT.json`。

## 来源适配：只解码现有见证，不重算 EOS

建议入口：`freeze_local_coefficients(column, states, rates) -> tuple[BoundLocalCoefficients, ...]`。只接实际 `ControlledVaporColumn`、`ControlledVaporRates` 和对应原状态；要求 wrapper/base identities 匹配、`rates.cells` 对应 `rates.closed_rates.cells`，格数/气体顺序正确。逐格复用

`low_moisture_water_point(storage, column.base.chemical, state, cell.inverse, cell.phase)`

来检查库存、完整 U target/residual、实际 excess、pure-liquid T/P/参考及 phase 对应关系，无新增 EOS。另按原 inverse policy 验证保存的 U allowance 与 T bound，正 minimum Cv、完整压力包络不降级。原实例/见证只作进程内对应检查，不叫序列化认证。系数只允许当前 exact W∈[0,F(W_MIN)]，不能用已投影的 `point.moisture_kg_water_per_kg_dry` float 替代库存比。

从 `cell.inverse.point` 取 T、P、Vg；从 `cell.phase.equilibrium.pure_equilibrium` 取已算 pure_peq。实际 `storage.excess.evaluate(T,F(W_MIN))` 只做源节点/自由能代数，保留其接点 activity。全部先将实际 float 转 Fraction：

```
Wj=F(W_MIN); M=F(storage.wet._mass); md=F(storage.dry_mass_kg)
alpha = F(pure_peq)*F(join_point.activity)*M/(md*Wj)
beta  = F(chemical.gas_constant_j_mol_k)*F(T)/F(Vg)
Kph_i = F(column.base.transfer_coefficients_mol_s_pa[i])
Kv_i,pe_i = 外格的 F(column.control.Kv),F(column.control.pe)；内格为0,0
```

上面 Kv/pe 为简写；实际字段是 `transfer_coefficient_mol_s_pa` / `vapor_pressure_pa`。α>0、β>0，系数非负；Nc=0 也用接点式，绝不 `peq/Nc`。内格0是“没有连接外槽”的拓扑选择，不是测得系数。M/R与同一源热力学实例一致。

hv 可直接取保存的 `pure_equilibrium.vapor.enthalpy_j_mol`，因同温理想蒸气 h 不依赖其压力；外格要求它与 `rates.boundary.common_vapor_enthalpy_j_mol` 及 boundary T 一致。同一 reference id 可复用解码水点的 `energy_reference_id`；保存原 inverse/phase、join_point、column/storage/excess identities 与来源。禁止再调 `equilibrium_at_liquid_tp` 或 `ideal_vapor(T,0)`。

**保留起始 RHS 差，而非声称逐字相同。** 令 c=原 `phase`、x=原 `state`：

```
dpeq = alpha*F(x.Nc) - F(c.equilibrium.equilibrium_partial_pressure_pa)
dpv  = beta*F(x.Nv) - F(c.water_partial_pressure_pa)
r_lin = Kph*(alpha*F(x.Nc)-beta*F(x.Nv))
r_readout_residual = r_lin-F(c.phase_water_mol_s)
外格 n_lin=Kv*(beta*F(x.Nv)-pe)
n_readout_residual=n_lin-F(rates.boundary.outward_water_mol_s)
H_readout_residual=hv*n_lin-F(rates.boundary.outward_carried_energy_w)
```

Nc/Nv 也是简写，对应 `liquid_water_mol` / `gas_amounts_mol[water_index]`。这些精确“表示值之差”包含源 aw/peq/pv/速率的不同舍入顺序；误差符号约定固定为新减旧。它们既不是物理误差界，也不是沿整个子步的冻结误差界，不能用 h|起始残差|假造全程证书。总物理/冻结模型误差仍未知，时间误差以后用收敛验证。

`BoundLocalCoefficients` 最少字段：cell index，origin state/inverse/phase 的见证引用，T/P/Vg/W/M/md/R，join point、pure_peq，α/β/Kph/Kv/pe/hv，reference/source ids，origin rates identity，上述5项残差。适配器自身不更新状态；参数命名映射到已审 BE 叶子即可，不再做第二套线性求解器。

## 主机：一个完整宏步 h，两段各推进其所属项 h

新增显式 `integrate_low_moisture_lie(column, initial, ..., inverse_strategy 由已绑定 base 决定)`；新数值 policy identity 组合原 column identity、BE policy、分步顺序与域规则。原 `integrate_source_column` 中点路径保持其含义，不在旧函数内悄悄换算法。

1. `r0=column.evaluate(x0)`。构造系数，BE 叶子逐格求 exact NcA/NvA、Jphase、Eout；E仅外格可以非零。把叶子**精确积分**组装为 N+1 个 `ColumnFaceIntegral`：中心/内部全零，外格 gas=(0,0,E)、energy=hv*E、diffusive_enthalpy=(0,0,hv*E)、conduction/advective=0、decomposition=0。以 Jphase tuple 调 `_advance(column.base,x0,local_faces,Jphase)` 得 xA 和 local `ColumnRoundoff`。核其未投影 Nc/Nv 与叶子结果一致。局部无热浴、无内部流、无 latent U源。
2. 检查 xA 的 exact W≤Wj，再 `rA=column.evaluate(xA)`：实际 full-U inverse 同时重算 T/P/Vg/phase/k/D；失败则整个宏步失败。这里的 xA 是算法阶段，不是已接受的 t+h 状态，也不是 midpoint。
3. 从 `_integrals(rA.closed_rates,h)` 仅取内部 k/D 的 faces，**舍弃它返回的 phase tuple**，给 `_advance` 的 phase 全零。外侧另建纯热面：`Q=h*F(rA.boundary.heat_into_cell_w)`，gas/diffusive/advective全零、energy=conduction=−Q；记录 `Q-h*rA.faces[-1].exact_heat_into_cell_w`。不要复制含蒸气流的完整外侧面积分。保留内部 `SorptionMoistureColumnFaceIntegral` 类型及见证，以便原 `_liquid_integral` 处理唯一 Nc 水流。调用 `_advance(base,xA,slow_faces,zero_phase)` 得 x1 和 slow roundoff。
4. 检查 x1 W≤Wj、`r1=column.evaluate(x1)`、两个阶段预算、全步/累计账和 identity；均通过才一次性追加 x1、t+h、r1和新 ledger。两算子各用 h，宏步物理时长仍为 h，不能累加为2h。可先维持每步3次 evaluate；任何复用 r1 作下一 r0 的优化必须另核状态/来源 identity，不能加入不透明缓存。

建议新 `LieStepLedger` 字段为：duration、origin_rates、coefficients/local_leaf_results、local_faces/J、after_local_states/rates、local_roundoff、slow_faces/zero_phase、slow_roundoff、宏步费用、分步 policy id。复用 `SourceColumnRun` 作为返回容器，其 ledger 使用新明确类型；不要借旧 `midpoint_states`/`predictor_roundoff` 字段掩盖分步语义，也不把旧瞬时相变/面熵当 BE 全步熵积分。

## 账、费用与失败原子性

每子步逐格核 `ΔNc=左凝聚水−右凝聚水−J+δNc`、`ΔNv=左汽−右汽+J+δNv`、`ΔU=左能量−右能量+δU`，惰性气体与固体不变。宏步/前缀：`ΔNtotal=−E+ΣδN_A+ΣδN_B`，`ΔUtotal=Q−hv*E+ΣδU_A+ΣδU_B`。H可为负，原 full-U干参考保持。

局部叶子 exact Fraction 积分若直接进 `_advance`，仅收费实际库存/U投影，不能把未使用的显示float再算一次。慢步继续列明并累加内部面积分 decomposition、moisture mol/H投影、热浴 Q投影和状态投影的绝对值，不能正负抵消；若新预算声称包含导热名义公式到实际 flux 的差，也应显式收取 h|conduction_arithmetic_residual_w|。源系数读数差、反解误差、log/物理未知与时间截断误差分别记录，不冒充上述算术预算已覆盖。

局部 BE 的正性不保护慢显式 D 步：库存为负、正库存underflow、W跨接点、反解/源域失败均拒绝，不截断水，不覆写 T/P。任何阶段失败，accepted states/times/ledgers/累计E/H/Q/已接受费用不变；可单独保存 rejected attempt 的完整阶段/费用/失败原因。首版固定步数直接返回失败最简单；若以后采用缩步，须预登记重试规则、计入所有耗时/调用数并保留失败尝试。取消与墙钟门覆盖每次实际 evaluate 和子步边界。当前封闭内面/选择性汽槽与热浴资格不变，不新增完整炉边界、事件清零或材料/训练资格。
