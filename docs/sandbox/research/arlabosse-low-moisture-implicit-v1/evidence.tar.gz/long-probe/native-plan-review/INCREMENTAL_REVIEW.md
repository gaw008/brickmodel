# 500 s probe：相对已审短程驱动的增量静态复核

**APPROVE，无需阻止本次预登记 probe 的增量缺陷。** 只比较 case/driver/plan/supervisor 改动；未重新审核全框架，未执行 EOS、驱动或测试。前一短程运行成绩由主代理提供，本记录不重新验证其保存结果。

case 仅修改 fixture 标识、两格相同的 O₂=0.0000714/N₂=0.0002686/Nv=0.000001 mol，以及热浴 333 K、G=0.1 W/K 和对应 virtual 标识。Nc=(0,0.06)、T=(330,333)、md/V/A/宽度、源模型、Kph=1e−10、Kv=1e−8、pe=0 均保持。名义每格载气和 0.00034 mol 与实际 binary64 分量之和有明确区分；几何和相变系数仍 manufactured，载气/热浴仍设计选择。旧 case 文件未改。

driver 由三路细化改为一次 500 s/5 步，预期 11 次完成/尝试 RHS，时钟为 0,100,…,500 s。新初态和控制有显式检查。删除旧初态相等检查及三路一阶比值判定符合新工况用途；新增净排水 E>0、总水减少和载气保留检查没有将有符号 Hout 强制为正。已审的实际系数、BE/shared J/E/H、热浴 Q/projection、两阶段逐格 U/Nc/Nv、前缀守恒和费用分项核验保持。

U=1e−5 J、T=1e−6 K、100 candidates，325–338 K、含误差的 90–110 kPa，算术 1e−8 J/1e−12 mol 及 60/80/100+5 s 资源门保持。只有实际通过才能说明此单一 h/终时的可计算性与排湿；不证明长程精度、完成干燥、全场/空间收敛或材料资格。原报告 false 标志及新的 only-viability scope 一致。先前短程两个比值通过不能迁移为本 probe 的精度证据。

supervisor 已改为独立 long-probe 输出，引用父目录实际存在的 install/SOURCE_FREEZE.json；driver 已不读取 OLD/INITIAL，因此移除该 input 合理。其余已审实际源码/安装/来源/数值依赖输入集合保持，新的本地 case/driver/plan/wrapper 被绑定。没有隐藏重试或在失败后扩域。

审查 SHA256：case `08724a3317226809125d5407ad302994856e3a6804f1774cb1663e75ffdd9bb6`；driver `a6e9f43ecb712649278bb92b4e1ead46fb58593c67d83f1d5fef23f815d2d955`；plan `d6c350bf04b5a7f1a4db96312eea2bcb0264fbdddfc6db1c2780d30a56a3ac24`；wrapper `01ef88bc4a580575f12aed41110568c454e4d921a9f74a645b8f609a8a3efd5b`；父 freeze `a75fc3ef09cb727fe344a74c7f42de18c33b779f9f4bfce8723f995b982a10af`。三份 Python AST 解析成功；git diff Python 为空，未改生产。
