"""One bounded same-source split refinement, with all accepted substage ledgers."""
from fractions import Fraction as F
from pathlib import Path
import importlib.util
import json
import time
import traceback
from sludge_sandbox.low_moisture_split_column import integrate_low_moisture_split

WORK=Path('/private/tmp/arlabosse-low-moisture-implicit-v1/long-probe')
spec=importlib.util.spec_from_file_location('split_native_case',WORK/'native_case.py')
case=importlib.util.module_from_spec(spec);spec.loader.exec_module(case)
OUT=WORK/'native01';OUT.mkdir(exist_ok=False)
start=time.monotonic();checks=[];metrics=[]
def save(name,value):(OUT/name).write_text(json.dumps(case.serialize(value),indent=2,allow_nan=False)+'\n')
def check(name,value):checks.append({'id':name,'passed':bool(value)})
def water(states):return sum((F(s.liquid_water_mol)+F(s.gas_amounts_mol[2]) for s in states),F())
def U(states):return sum((F(s.internal_energy_j) for s in states),F())
try:
    column,initial,points=case.make_case(lambda p:save('CONSTRUCTION_PREFIX.json',p))
    initial_record={'states':initial,'points':points,'provenance':column.provenance(),
        'actual_source_nodes':{'m':column.storages[0].wet._m,'q':column.storages[0].wet._q,
            'L95':column.storages[0].wet._latent_reference,'M':column.storages[0].wet._mass,
            'R':column.base.chemical.gas_constant_j_mol_k}}
    save('INITIAL.json',initial_record)
    check('declared_initial_Nc',tuple(s.liquid_water_mol for s in initial)==(0.,.06))
    check('declared_initial_gas',all(s.gas_amounts_mol==(.0000714,.0002686,.000001) for s in initial))
    check('declared_initial_T',tuple(p.temperature_k for p in points)==(330.,333.))
    check('declared_bath_contact',column.control.heat_bath_temperature_k==333. and column.control.heat_conductance_w_k==.1 and column.control.transfer_coefficient_mol_s_pa==1e-8 and column.control.vapor_pressure_pa==0.)
    for steps in (5,):
        run=integrate_low_moisture_split(column,initial,duration_s=500.,steps=steps,
            maximum_wall_seconds=60.,energy_roundoff_budget_j=1e-8,inventory_roundoff_budget_mol=1e-12)
        save(f'RUN_{steps}.json',run)
        key=f'n{steps}'
        check(key+'_complete',run.status=='completed' and run.reason is None)
        check(key+'_clock',run.times_s==tuple(F(500.)*i/steps for i in range(steps+1)))
        check(key+'_RHS',run.evaluations_completed==run.evaluations_attempted==1+2*steps)
        check(key+'_energy_budget',run.energy_roundoff_used_j<=F(1e-8))
        check(key+'_inventory_budget',run.inventory_roundoff_used_mol<=F(1e-12))
        check(key+'_no_material_claim',not run.material_qualified and run.failed_trial is None)
        E=H=Q=correction_U=correction_N=F()
        for j,(before,after,ledger,last) in enumerate(zip(run.states,run.states[1:],run.ledgers,run.observations)):
            sk=key+f'_step{j}'
            for name,old_states,new_states,faces,phase,error in (
                ('local',before,ledger.local_states,ledger.local_faces,ledger.phase_water_mol,ledger.local_roundoff),
                ('slow',ledger.local_states,after,ledger.slow_faces,(F(),)*2,ledger.slow_roundoff)):
                for i,(o,n) in enumerate(zip(old_states,new_states)):
                    prefix=sk+'_'+name+f'_cell{i}'
                    lf,rf=faces[i:i+2]
                    check(prefix+'_U',F(n.internal_energy_j)-F(o.internal_energy_j)==lf.energy_j-rf.energy_j+error.energy_j[i])
                    check(prefix+'_Nc',F(n.liquid_water_mol)-F(o.liquid_water_mol)==getattr(lf,'moisture_mol',F())-getattr(rf,'moisture_mol',F())-phase[i]+error.liquid_mol[i])
                    for k in range(3):
                        check(prefix+f'_gas{k}',F(n.gas_amounts_mol[k])-F(o.gas_amounts_mol[k])==lf.gas_mol[k]-rf.gas_mol[k]+(phase[i] if k==2 else F())+error.gas_mol[i][k])
                    check(prefix+'_nonnegative',n.liquid_water_mol>=0 and all(v>=0 for v in n.gas_amounts_mol))
                correction_U+=sum(error.energy_j,F())
                correction_N+=sum(error.liquid_mol,F())+sum((r[2] for r in error.gas_mol),F())
            E+=ledger.local_steps[-1].outlet_transfer_mol
            H+=ledger.local_steps[-1].outlet_enthalpy_j
            Q-=ledger.slow_faces[-1].energy_j
            check(sk+'_prefix_water',water(after)-water(initial)==-E+correction_N)
            check(sk+'_prefix_U',U(after)-U(initial)==Q-H+correction_U)
            for i,(w,local,state) in enumerate(zip(ledger.coefficients,ledger.local_steps,before)):
                c=w.coefficients;pinv=w.inverse.point;pure=w.phase.equilibrium.pure_equilibrium
                alpha=F(pure.equilibrium_partial_pressure_pa)*F(w.join_point.activity)*F(column.storages[i].wet._mass)/(F(column.storages[i].dry_mass_kg)*F(.15))
                beta=F(column.base.chemical.gas_constant_j_mol_k)*F(pinv.temperature_k)/F(pinv.gas_volume_m3)
                kp=F(column.base.transfer_coefficients_mol_s_pa[i]);kv=F(column.control.transfer_coefficient_mol_s_pa) if i==1 else F()
                pe=F(column.control.vapor_pressure_pa) if i==1 else F()
                check(sk+f'_local{i}_actual_coefficients',c.a_s_inv==kp*alpha and c.b_s_inv==kp*beta and c.c_s_inv==kv*beta and c.forcing_mol_s==kv*pe and c.vapor_enthalpy_j_mol==F(pure.vapor.enthalpy_j_mol))
                check(sk+f'_local{i}_shared_BE',local.phase_transfer_mol==ledger.duration_s*(c.a_s_inv*local.nc1_mol-c.b_s_inv*local.nv1_mol) and local.outlet_transfer_mol==ledger.duration_s*(c.c_s_inv*local.nv1_mol-c.forcing_mol_s) and local.nc1_mol==F(state.liquid_water_mol)-local.phase_transfer_mol and local.nv1_mol==F(state.gas_amounts_mol[2])+local.phase_transfer_mol-local.outlet_transfer_mol)
                check(sk+f'_local{i}_common_H',local.outlet_enthalpy_j==c.vapor_enthalpy_j_mol*local.outlet_transfer_mol)
            nominal_bath=ledger.duration_s*F(column.control.heat_conductance_w_k)*(F(column.control.heat_bath_temperature_k)-F(ledger.slow_rates.cells[-1].inverse.point.temperature_k))
            check(sk+'_actual_bath_and_projection',-ledger.slow_faces[-1].energy_j==nominal_bath+ledger.heat_projection_j)
            expected_fee_U=abs(ledger.heat_projection_j)
            expected_fee_N=F()
            for error in (ledger.local_roundoff,ledger.slow_roundoff):
                expected_fee_U+=sum((abs(v) for v in error.energy_j),F())
                expected_fee_N+=sum((abs(v) for v in error.liquid_mol),F())+sum((abs(v) for row in error.gas_mol for v in row),F())
            for face in ledger.slow_faces:
                expected_fee_U+=abs(face.energy_decomposition_roundoff_j)+abs(getattr(face,'moisture_enthalpy_projection_j',F()))
                expected_fee_N+=abs(getattr(face,'moisture_molar_projection_mol',F()))
            check(sk+'_independent_step_fees',expected_fee_U==ledger.step_energy_roundoff_j and expected_fee_N==ledger.step_inventory_roundoff_mol)
            check(sk+'_internal_reservoir_absent' ,ledger.local_steps[0].outlet_transfer_mol==0)
            check(sk+'_no_slow_vapor',all(f.gas_mol==(F(),)*3 for f in ledger.slow_faces))
            check(sk+'_heat_only_boundary',ledger.slow_faces[-1].energy_j==ledger.slow_faces[-1].conduction_j)
            for tag,states,rates in (('local',ledger.local_states,ledger.slow_rates),('end',after,last)):
                for i,(state,cell,storage,policy) in enumerate(zip(states,rates.cells,column.storages,column.base.inverse_policies)):
                    p=cell.inverse.point;inv=cell.inverse;ex=p.excess
                    prefix=sk+'_'+tag+f'_decode{i}'
                    check(prefix+'_U',inv.target_energy_j==state.internal_energy_j and abs(inv.energy_residual_j)+F(p.energy_error_j)<=F(policy.energy_tolerance_j))
                    check(prefix+'_T',inv.temperature_error_bound_k<=policy.temperature_tolerance_k and 325<=p.temperature_k<=338)
                    check(prefix+'_P',90000<=p.pressure_pa-p.pressure_error_pa and p.pressure_pa+p.pressure_error_pa<=110000)
                    check(prefix+'_W',ex.moisture_kg_water_per_kg_dry==F(state.liquid_water_mol)*F(storage.wet._mass)/F(storage.dry_mass_kg) and 0<=ex.moisture_kg_water_per_kg_dry<=F(.15))
                    check(prefix+'_dry_reference',p.excess_internal_energy_j==F(storage.dry_mass_kg)*ex.h_ex_j_kg_dry)
        check(key+'_fee_sum',run.energy_roundoff_used_j==sum((l.step_energy_roundoff_j for l in run.ledgers),F()) and run.inventory_roundoff_used_mol==sum((l.step_inventory_roundoff_mol for l in run.ledgers),F()))
        if run.status!='completed':
            save('ACCEPTANCE.json',{'passed':False,'checks':checks,'reason':run.reason,'metrics':metrics})
            raise ValueError('split_native_incomplete_'+str(steps))
        last=run.observations[-1]
        metrics.append({'steps':steps,'integrator_seconds':run.elapsed_seconds,'RHS':run.evaluations_completed,
            'T_k':[c.inverse.point.temperature_k for c in last.cells],
            'T_error_k':[c.inverse.temperature_error_bound_k for c in last.cells],
            'P_pa':[c.inverse.point.pressure_pa for c in last.cells],
            'P_error_pa':[c.inverse.point.pressure_error_pa for c in last.cells],
            'Nc_mol':[s.liquid_water_mol for s in run.states[-1]],
            'Nv_mol':[s.gas_amounts_mol[2] for s in run.states[-1]],
            'E_mol':E,'H_j':H,'Q_j':Q,'energy_roundoff_j':run.energy_roundoff_used_j,
            'inventory_roundoff_mol':run.inventory_roundoff_used_mol})
    refinement={};field_differences=[]
    check('net_water_removed',metrics[0]['E_mol']>0 and water(run.states[-1])<water(initial))
    check('carrier_retained',all(s.gas_amounts_mol[:2]==i.gas_amounts_mol[:2] for s,i in zip(run.states[-1],initial)))
    check('driver_wall' ,time.monotonic()-start<80.)
    report={'passed':all(c['passed'] for c in checks),'checks':checks,'metrics':metrics,'refinement':refinement,'field_differences':field_differences,
        'driver_seconds':time.monotonic()-start,'material_qualified':False,
        'probe_scope':'new design 500s cost/domain viability only, no long-time convergence or material claim',
        'all_field_temporal_convergence_demonstrated':False,'spatial_convergence_demonstrated':False}
    save('ACCEPTANCE.json',report)
    print(json.dumps(case.serialize({k:v for k,v in report.items() if k!='checks'})))
    assert report['passed'],'split_native_acceptance_failed'
except BaseException as exc:
    save('FAILURE.json',{'type':type(exc).__name__,'message':str(exc),'elapsed_seconds':time.monotonic()-start,'traceback':traceback.format_exc()})
    raise
