# Frozen local moisture BE leaf: independent mathematical review

**APPROVE** the scratch leaf; no unresolved mathematical finding. Reviewed source SHA-256 `14498567279698b677da131bac019767a8ee024bde5d5fa5106292f09f570e72`. No source adapter, host, installation, EOS or native trajectory was executed or approved by this leaf review. All writes are confined to the assigned scratch review/design directories.

## Positivity and shared physical accounting

For nonnegative a,b,c,f,h, the matrix of the BE solve is `B=[[1+ha,-hb],[-ha,1+h(b+c)]]`. Its determinant is exactly `1+h(a+b+c)+h²ac >= 1`; its inverse has nonnegative entries `[[1+h(b+c),hb],[ha,1+ha]]/det`. Acting on `(Nc0,Nv0+hf)` therefore proves nonnegative exact output stocks without a step-size restriction for this frozen local problem. The implementation's numerator and determinant expressions match this inverse, including all zero-coefficient and h=0 limits. It never requires an inverse of the possibly singular continuous generator A.

The quantities `J=h(aNc1-bNv1)` and `E=h(cNv1-f)` are the same endpoint quadrature used in the solve. The two exact identities `Nc1=Nc0-J` and `Nv1=Nv0+J-E` follow from the two BE equations and are checked in the returned result. Thus total-water change is exactly `-E`, with the useful bound `-hf <= E <= Nc0+Nv0`. Vacuum f=0 implies nonnegative outward transfer; positive forcing permits inward net transfer. For positive finite a,b,c,h and a nonempty initial pool, the vacuum remainder is strictly positive. A very large step may be inaccurate but cannot justify a finite-time deletion event.

`H=hv*E` and `delta_U=-H` use the same signed E. The sign of hv is unrestricted as required by the shared energy reference; incoming water with negative referenced hv need not raise the numerical U coordinate. Phase transfer alone creates no extra U or latent term. Shifting the common water reference by C leaves the stock/J/E map unchanged, shifts H by C*E, and agrees with shifting U by C*(Nc+Nv). This is the appropriate open-energy covariance; it does not construct a new dry-material or formation reference.

The leaf intentionally accepts declared nonnegative a/b/c/f without asserting that they derive from a common Kph/Kv or an actual T/P/Vg. A combination such as c=0,f>0 is a valid affine mathematical problem, even though the planned physical adapter cannot obtain it from f=Kv*pe,c=Kv*beta with positive beta. Keeping source-state binding false and assigning that restriction to the adapter is correct.

## Numerical scope and projections

This is exact rational algebra for one BE discretization of represented coefficients, **not** the exact frozen matrix exponential. Expansion of the resolvent gives local error O(h²) and global first order for the fixed smooth affine system. The handoff, numerical policy and result fields distinguish this from freezing error, host splitting error, EOS bounds and material uncertainty. The existing forced-example exponential formula has the correct equilibrium and eigenvalues; its stored refinement evidence was inspected, not regenerated.

The optional projection function deliberately projects Nc1, Nv1, J, E and H independently. Its reported stock/transfer residuals are respectively `deltaNc+deltaJ`, `deltaNv-deltaJ+deltaE`, and `deltaH-hv*deltaE`; direct algebra confirms all signs. Overflow and positive-to-zero underflow reject the readout, while the exact result remains available. These readouts are not permission to assign both independently rounded stocks and independently rounded transfers to a host. The proposed host should consume exact J/E/H and let its existing `_advance` perform and charge its single final projection, as stated in the leaf's scope.

## New evidence and limits

`MATH01.log/.xml`: **2 new pure rational tests passed in 0.02 s**, using only the standalone leaf and standard-library data. No author test was rerun.

1. The independently derived humid equilibrium `Nv*=f/c`, `Nc*=bf/(ac)` is preserved exactly for h=0, a very small positive h and a very large finite h, for negative, zero and positive hv. It produces no spurious J/E/H.
2. Independent unit-column responses of the affine map are nonnegative and have column sums <=1. Their linear combination reproduces a signed initial-stock difference under common forcing and satisfies the one-norm nonexpansion bound. The check includes closed exchange and pure-forcing degeneracies and verifies the signed E bounds. This is a frozen local stability property, not a coupled nonisothermal or full-step entropy guarantee.

The original 36-test source, GREEN01 record and FIRST_ORDER.json were read. AST parsing passed; ruff/mypy/pylint/black were unavailable and not installed. Exact file identities are recorded in `READ_SNAPSHOT.json`. Host coefficient authentication, current source readout residuals, shared projected energy/inventory budgets, after-local/final full-U inverses, macrostep atomicity and real temporal/spatial convergence remain separate requirements. Material/training qualification remains false.
