"""Two new exact-algebra properties; standalone leaf only, no source/EOS imports."""
from fractions import Fraction as F
from dataclasses import replace
import implicit_local_moisture as leaf


def coefficients(a=F(2,7),b=F(3,11),c=F(5,13),f=F(17,19),hv=-240000):
    return leaf.FrozenLocalMoistureCoefficients(a,b,c,f,hv,'manufactured:common_reference',
        ('manufactured:independent_BE_algebra',),'manufactured_test_fixture')


def test_humid_equilibrium_is_exact_for_any_finite_step_and_signed_enthalpy():
    for hv in (-240000,0,240000):
        q=coefficients(hv=hv)
        nc=q.b_s_inv*q.forcing_mol_s/(q.a_s_inv*q.c_s_inv)
        nv=q.forcing_mol_s/q.c_s_inv
        for h in (F(0),F(1,10**90),F(10**90,7)):
            s=leaf.backward_euler_local_moisture(nc,nv,h,q)
            assert s.determinant>=1
            assert (s.nc1_mol,s.nv1_mol)==(nc,nv)
            assert s.phase_transfer_mol==s.outlet_transfer_mol==s.outlet_enthalpy_j==0
            assert s.energy_change_j==0


def test_resolvent_order_positivity_and_one_norm_bound_with_same_forcing():
    for q in (coefficients(),coefficients(c=0,f=0),coefficients(a=0,b=0,c=0,f=5)):
        h=F(13,7)
        zero=leaf.backward_euler_local_moisture(0,0,h,q)
        columns=[]
        for nc,nv in ((1,0),(0,1)):
            s=leaf.backward_euler_local_moisture(nc,nv,h,q)
            column=(s.nc1_mol-zero.nc1_mol,s.nv1_mol-zero.nv1_mol)
            assert all(x>=0 for x in column)
            assert sum(column)<=1
            columns.append(column)
        x=leaf.backward_euler_local_moisture(3,1,h,q)
        y=leaf.backward_euler_local_moisture(2,3,h,q)
        dx,dy=(F(1),F(-2)),(x.nc1_mol-y.nc1_mol,x.nv1_mol-y.nv1_mol)
        assert dy==tuple(columns[0][i]*dx[0]+columns[1][i]*dx[1] for i in (0,1))
        assert sum(map(abs,dy))<=sum(map(abs,dx))
        for s in (zero,x,y):
            assert -h*q.forcing_mol_s<=s.outlet_transfer_mol<=s.nc0_mol+s.nv0_mol
            assert s.nc1_mol+s.nv1_mol==s.nc0_mol+s.nv0_mol-s.outlet_transfer_mol
