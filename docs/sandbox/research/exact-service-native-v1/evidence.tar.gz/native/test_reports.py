"""Stdlib-only runner utility tests. No package/service/EOS imports or execution."""
import importlib.util
from pathlib import Path
import json
import sys
import unittest
import tempfile

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('prospective_service_runner',ROOT/'run.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)

class ReportTests(unittest.TestCase):
    def test_action_and_integrity_failures_both_persist(self):
        with tempfile.TemporaryDirectory() as name:
            out=Path(name)
            def action():
                m.save(out/'before-failure.json',{'canonical_text':'{"n":9007199254740993}'});raise ValueError('original action')
            def finish():raise RuntimeError('later integrity')
            report=m.capture(out,action,finish)
            self.assertEqual(report['capture_status'],'failed')
            self.assertEqual(report['error'],'original action');self.assertEqual(report['integrity_error'],'later integrity')
            self.assertEqual(json.loads((out/'report.json').read_text()),report)
            self.assertEqual(json.loads((out/'before-failure.json').read_text())['canonical_text'],'{"n":9007199254740993}')
    def test_large_exact_integer_is_preserved_as_text(self):
        with tempfile.TemporaryDirectory() as name:
            path=Path(name)/'output.json';text='{"fraction":[123456789012345678901234567890,7]}'
            m.save(path,{'text':text});self.assertEqual(m.read(path)['text'].encode(),text.encode())
    def test_nonfinite_report_refuses_without_overwrite(self):
        with tempfile.TemporaryDirectory() as name:
            path=Path(name)/'output.json';m.save(path,{'original':True})
            with self.assertRaises(ValueError):m.save(path,{'bad':float('nan')})
            self.assertEqual(m.read(path),{'original':True})
    def test_input_membership_and_precise_differences(self):
        with tempfile.TemporaryDirectory() as name:
            path=Path(name);(path/'a').write_bytes(b'a');before=m.hashes(path)
            (path/'b').write_bytes(b'b');self.assertNotEqual(m.hashes(path),before)
        self.assertEqual(m.differences({'x':1},{'x':True})[0]['pointer'],'/x')

if __name__=='__main__':unittest.main()
