"""Read saved cancel/resume data only; no production imports, EOS or replay reads."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
H=Path(__file__).parent
C=H/'cancel';B=H/'resume';R=B/'run'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unpack(x):
    if isinstance(x,list):return [unpack(v) for v in x]
    if not isinstance(x,dict):return x
    if set(x)=={'float_hex'}:return float.fromhex(x['float_hex'])
    if set(x)=={'mapping'}:return {k:unpack(v) for k,v in x['mapping'].items()}
    if set(x)=={'sequence'}:return [unpack(v) for v in x['sequence']]
    if 'record' in x and 'fields' in x:return unpack(x['fields'])
    return {k:unpack(v) for k,v in x.items()}
def seconds(t):
    v=t.get('exact_time',t.get('seconds',t))
    return F(int(v['numerator']),int(v['denominator']))
def check_files(root,expected,exclude=()):
    actual={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and p.relative_to(root).as_posix() not in exclude}
    assert actual==expected,(set(actual)^set(expected))
freeze=read(H/'freeze.json');assert sha(H/'freeze.json')=='17771500235c84eb0bcd368fdd1368a6c231afdb374793acea6a03be93a485d2'
check_files(H/'inputs',freeze['files'])
for root in (C/'run',R):check_files(root,read(root/'manifest.json')['files'],('manifest.json',))
for stage in (C,B):
    assert read(stage/'runtime-before.json')==read(stage/'runtime-after.json')==freeze['runtime']
    assert read(stage/'inputs-before.json')==read(stage/'inputs-after.json')
assert len(freeze['runtime']['modules'])==87
raw=(R/'exact-run-record.json').read_bytes();assert raw==(B/'canonical-record.json').read_bytes()
assert sha(R/'exact-run-record.json')=='935d38fd7398bddd6d718fe0f0fe53e2ac861847ae5a8bcc02133fa27b8b902d'
record=unpack(read(R/'exact-run-record.json'));parent=unpack(read(C/'run/exact-run-record.json'));core=record['result'];prior=parent['result']
result=read(R/'result.json');oldresult=read(C/'run/result.json')
assert result==read(B/'service-return.json')
assert read(B/'verified-manifest.json')==read(R/'manifest.json')
export=read(B/'export.json');assert export['canonical_exact_record']['text'].encode()==raw
assert export['result']==result and export['manifest']==read(R/'manifest.json')
assert export['canonical_exact_record']['sha256']==sha(R/'exact-run-record.json')
assert result['status']==result['core_status']==core['status']=='completed' and core['reason'] is None
assert record['binding']['runtime_identity']==freeze['runtime']
assert record['binding']['case_sha256']==sha(H/'inputs/case.json')==sha(R/'case.json')
assert record['start']==parent['start'] and record['end']==parent['end']
case=read(R/'case.json');assert seconds(record['start'])==F(case['numerics']['start_s']) and seconds(record['end'])==F(case['numerics']['end_s'])
for key in ('initial_policy','event_policy'):assert core[key]==prior[key]
assert core['initial_policy']==case['numerics']['integration']
for key in ('times_s','states','steps','packets','refinements','terminal_attempts'):
    assert core[key][:len(prior[key])]==prior[key],key
assert len(prior['steps'])==1 and len(prior['states'])==2
assert len(core['steps'])==30 and len(core['states'])==31 and len(core['times_s'])==31
assert len(core['packets'])==2 and sum(len(p) for p in core['packets'])==2
assert result['initial_snapshot']==oldresult['initial_snapshot']
assert (R/'parent/exact-run-record.json').read_bytes()==(C/'run/exact-run-record.json').read_bytes()
assert (R/'parent/result.json').read_bytes()==(C/'run/result.json').read_bytes()
assert (R/'parent/manifest.json').read_bytes()==(C/'run/manifest.json').read_bytes()
assert result['resume_of']['exact_record_sha256']==sha(C/'run/exact-run-record.json')
assert result['resume_of']['manifest_sha256']==sha(C/'run/manifest.json')
assert result['resume_of']['result_sha256']==sha(C/'run/result.json')
assert result['continuation_boundary']['prior_costs']==prior['costs']
assert result['continuation_boundary']['prior_elapsed_seconds']==prior['elapsed_seconds']
times=[seconds(t) for t in core['times_s']]
assert times[0]==seconds(record['start']) and times[-1]==seconds(record['end']) and all(a<b for a,b in zip(times,times[1:]))
for i,step in enumerate(core['steps']):assert seconds(step['start_s'])==times[i] and seconds(step['end_s'])==times[i+1]
assert seconds(result['final_snapshot']['exact_time'])==times[-1]
assert result['final_snapshot']['state']==result['integration']['states'][-1]
assert [seconds(t) for t in result['integration']['exact_times']]==times
reports=result['exact_audits'];assert set(reports)=={'prefix','terminal_proofs','comparisons','resources'}
for n,a in reports.items():assert a['record_sha256']==sha(R/'exact-run-record.json') and a==read(R/('exact-audit-'+n+'.json'))
assert reports['prefix']['accepted_prefixes']==30 and reports['prefix']['committed_events']==2
assert reports['terminal_proofs']['committed_terminals']==2
assert reports['comparisons']['comparisons']==6 and reports['comparisons']['pressure_certificates']==24
resource=reports['resources'];costs=core['costs'];policy=core['initial_policy']
assert costs==resource['cumulative_counters'] and all(costs[k]>=v for k,v in prior['costs'].items())
assert costs['evaluations_attempted']==costs['evaluations_completed']==685
assert resource['charged_panels']==costs['ordinary_panels']+costs['stage_replans']+costs['terminal_attempts']==79
assert resource['remaining_panels']==policy['maximum_steps']-79==433
assert resource['remaining_rejections']==policy['maximum_rejections']-costs['ordinary_rejected']==100
assert F(**resource['remaining_wall_seconds'])+F(core['elapsed_seconds'])==F(policy['maximum_wall_seconds'])==800
assert F(**resource['cumulative_elapsed_seconds'])==F(core['elapsed_seconds'])>F(prior['elapsed_seconds'])
s=read(H/'supervised-resume/status.json');assert s['status']=='complete' and s['returncode']==0 and s['cleanup']['leader_reaped'] and s['inputs_unchanged']
for p,d in s['inputs_after'].items():assert sha(Path(p))==d,p
out={'status':'passed_saved_resume_associations_and_budget_arithmetic','record_sha256':sha(R/'exact-run-record.json'),'parent_sha256':sha(C/'run/exact-run-record.json'),'runtime_modules':87,'accepted_steps':30,'packets':2,'events':2,'evaluations':685,'charged_panels':79,'remaining_panels':433,'remaining_rejections':100,'cumulative_core_wall_s':core['elapsed_seconds'],'supervisor_wall_s':s['elapsed_s'],'parent_history_prefix_verified':True,'exact_end':str(times[-1]),'four_reports_bound':True,'raw_export_identical':True,'scope':'Saved record/input/prefix/ledger-time/report and cumulative budget associations; no independent fresh physical RHS or repeat proof audit.'}
(B/'independent-resume-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
