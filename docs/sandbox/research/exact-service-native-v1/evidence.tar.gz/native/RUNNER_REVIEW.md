# Independent prospective runner review

Reviewed run.py SHA256 53e023427feb8d5a9bf05df797cfe74df776ae6e43f7f3321f650ce000b2e9f8, supervise.py 5d40741583b89fff2dfedfdf91f25631a802d6437484604afa872388a5749d59, and PLAN.md 89820ffb48c363163cf810060fbd3eefb192970e98479ee8bea9e9d4726e9135. Read the complete scripts and four stdlib tests; inspected utility-tests-final.log (4 passed). No preparation, build, service or EOS execution was performed by this reviewer.

No blocking findings. Preparation checks actual noneditable installed module bytes against repository and runtime, copies catalog/source/evidence/case/water inputs, and restricts the case differences to the five explicitly declared exact-interface changes. Original physical values, interval, integration and event tolerances and resource policy remain unchanged. Freeze identity is supplied externally and complete copied-input membership plus script/runtime identity is checked before and after each phase. This is same-version execution, not an old-runtime compatibility exception.

Resume/replay require the preceding supervised process to be terminal, successful and reaped, with its manifest and supervisor status hashes passed to the child. Actual shared service APIs own continuation/replay and fresh audits. The runner separately verifies complete preserved parent history and nondecreasing cost/wall, retained canonical parent bytes, original policies, actual event cells, raw export bytes and canonical trace links. Replay grid/state equality is recorded descriptively, not manufactured into a success gate.

Failure evidence is retained before success assertions: service-return and service bundle, then canonical and observed outcomes where available. A later final integrity failure is saved separately from the original action error. External timeout can interrupt finalization; the plan correctly treats an unsealed/capped run as failed and does not promise final reports after forced termination. The wrapper never launches subsequent phases or retries automatically. The 90/180/180-second outer caps preserve the original 800-second cumulative core policy.

Approval concerns the bounded research runner and its explicit lifecycle assertions. It does not establish browser/HTTP operation, independent thermophysical validation, material qualification or a successful native run. Freeze preparation must use the finally reviewed installed service/catalog; current native outcomes remain to be measured by root.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

Verdict: APPROVE for the planned bounded, sequential native lifecycle experiment.
