# Independent saved exact-service replay review

PASS for the saved replay associations and observed numerical reproducibility. Pure standard-library verifier verify_replay_saved.py executed once successfully; output replay/independent-replay-review.json and independent-review01.log. No production imports, EOS calls, integration or frozen input changes.

Actual supervised-replay status: complete, returncode0, leader_reaped=true, inputs_unchanged=true,92.99299120801152s. Runner report92.75736816701829s is the inner runner duration, not supervisory duration. Core completed in81.14099070898374s with30accepted steps,2packets/2events,685attempted/completed evaluations. Canonical SHA9ffd6b1b1f71c068a57d90645ec4f682f1ccdf8cce99413377f920934fa4f5b6.

The full original frozen input membership and sealed resume/replay manifests were rehashed. Saved runtime before/after equals the same87-module frozen runtime; every saved supervisor input path still has its recorded hash. Original case SHA and typed canonical binding match. replay_parent preserves the complete prior resume canonical/result/manifest bytes exactly (resume canonical935d38fd...). replay_of points to its actual result hash; no continuation boundary or resume lineage is claimed for this fresh replay.

All accepted rational times, conserved states and typed ledgers exactly equal the resumed run, not only the final endpoint. Initial snapshot, original full integration/event policies and counters also match. Ledger endpoints bind every consecutive exact time and end at the original requested rational endpoint. Full typed core comparison found19differences, all specifically elapsed_seconds/float_hex fields (top-level and retained terminal diagnostics). All paths and old/new values are retained in the independent JSON; no other physical/numerical fields were excluded. This is observed equality for this execution, not a guarantee that replay and resumed adaptive paths always coincide.

All four bound audit reports match their files and this canonical SHA:30prefixes/2events,2terminal proofs,6comparisons/24pressure certificates, resource charged79/remaining433 and100remaining rejections. Independently checked exact Fraction cumulative wall plus remaining equals the original800s budget. These are saved report associations and resource arithmetic, not a second independent physical proof computation.

The export canonical text reproduces all4189324canonical bytes unchanged; exported result/manifest match the sealed verified files. The final snapshot conserved state and exact time equal resume's actual endpoint.

Scope remains manufactured wet exact-service lifecycle validation. This does not constitute real material qualification, a full wet-to-fired cycle, spatial convergence, or a standalone source bundle.
