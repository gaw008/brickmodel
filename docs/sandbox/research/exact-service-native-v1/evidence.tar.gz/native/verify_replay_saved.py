"""Read saved cancel/resume data only; no production imports, EOS or replay reads."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
H=Path(__file__).parent
C=H/'resume';B=H/'replay';R=B/'run'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unpack(x):
    if isinstance(x,list):return [unpack(v) for v in x]
    if not isinstance(x,dict):return x
    if set(x)=={'float_hex'}:return float.fromhex(x['float_hex'])
    if set(x)=={'mapping'}:return {k:unpack(v) for k,v in x['mapping'].items()}
    if set(x)=={'sequence'}:return [unpack(v) for v in x['sequence']]
    if 'record' in x and 'fields' in x:return unpack(x['fields'])
    return {k:unpack(v) for k,v in x.items()}
def seconds(t):
    v=t.get('exact_time',t.get('seconds',t))
    return F(int(v['numerator']),int(v['denominator']))
def check_files(root,expected,exclude=()):
    actual={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and p.relative_to(root).as_posix() not in exclude}
    assert actual==expected,(set(actual)^set(expected))
freeze=read(H/'freeze.json')
assert sha(H/'freeze.json')=='17771500235c84eb0bcd368fdd1368a6c231afdb374793acea6a03be93a485d2'
check_files(H/'inputs',freeze['files'])
for root in (C/'run',R):check_files(root,read(root/'manifest.json')['files'],('manifest.json',))
assert read(B/'runtime-before.json')==read(B/'runtime-after.json')==freeze['runtime']
assert len(freeze['runtime']['modules'])==87
assert read(B/'inputs-before.json')==read(B/'inputs-after.json')
raw=(R/'exact-run-record.json').read_bytes();assert raw==(B/'canonical-record.json').read_bytes()
assert sha(R/'exact-run-record.json')=='9ffd6b1b1f71c068a57d90645ec4f682f1ccdf8cce99413377f920934fa4f5b6'
record=unpack(read(R/'exact-run-record.json'));parent=unpack(read(C/'run/exact-run-record.json'));core=record['result'];prior=parent['result']
result=read(R/'result.json');assert result==read(B/'service-return.json')
assert result['status']==result['core_status']==core['status']=='completed' and core['reason'] is None
assert record['binding']['runtime_identity']==freeze['runtime']
assert record['binding']['case_sha256']==sha(H/'inputs/case.json')==sha(R/'case.json')
assert record['binding']==parent['binding'] and record['start']==parent['start'] and record['end']==parent['end']
for key in ('initial_policy','event_policy','times_s','states','steps','costs'):assert core[key]==prior[key],key
for name in ('exact-run-record.json','result.json','manifest.json'):
 assert (R/'replay_parent'/name).read_bytes()==(C/'run'/name).read_bytes()
assert result['replay_of']['result_sha256']==sha(C/'run/result.json')
assert result['replay_of']['case_sha256']==sha(C/'run/case.json')
assert not result.get('resume_of') and not result.get('continuation_boundary')
assert len(core['steps'])==30 and len(core['packets'])==2 and sum(map(len,core['packets']))==2
assert core['costs']['evaluations_attempted']==core['costs']['evaluations_completed']==685
assert result['initial_snapshot']==read(C/'run/result.json')['initial_snapshot']
times=[seconds(t) for t in core['times_s']]
assert times[-1]==seconds(record['end']) and times[0]==seconds(record['start'])
assert all(a<b for a,b in zip(times,times[1:]))
for i,s in enumerate(core['steps']):assert seconds(s['start_s'])==times[i] and seconds(s['end_s'])==times[i+1]
assert result['final_snapshot']['state']==read(C/'run/result.json')['final_snapshot']['state']
assert seconds(result['final_snapshot']['exact_time'])==times[-1]
reports=result['exact_audits'];assert set(reports)=={'prefix','terminal_proofs','comparisons','resources'}
for n,a in reports.items():assert a['record_sha256']==sha(R/'exact-run-record.json') and a==read(R/('exact-audit-'+n+'.json'))
assert reports['prefix']['accepted_prefixes']==30 and reports['prefix']['committed_events']==2
assert reports['terminal_proofs']['committed_terminals']==2
assert reports['comparisons']['comparisons']==6 and reports['comparisons']['pressure_certificates']==24
resource=reports['resources'];assert resource['cumulative_counters']==core['costs']
assert resource['charged_panels']==79 and resource['remaining_panels']==433 and resource['remaining_rejections']==100
assert F(**resource['remaining_wall_seconds'])+F(core['elapsed_seconds'])==F(core['initial_policy']['maximum_wall_seconds'])==800
export=read(B/'export.json');assert export['canonical_exact_record']['text'].encode()==raw
assert export['result']==result and export['manifest']==read(R/'manifest.json')==read(B/'verified-manifest.json')
s=read(H/'supervised-replay/status.json');assert s['status']=='complete' and s['returncode']==0 and s['cleanup']['leader_reaped'] and s['inputs_unchanged']
for p,d in s['inputs_after'].items():assert sha(Path(p))==d,p
# Enumerate every typed raw core difference, permitting ONLY named elapsed fields.
diffs=[]
def compare(a,b,path=''):
 if type(a)!=type(b):diffs.append((path,a,b));return
 if isinstance(a,dict):
  if a.keys()!=b.keys():diffs.append((path,a,b));return
  for k in a:compare(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):diffs.append((path,a,b));return
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
 elif a!=b:diffs.append((path,a,b))
compare(read(C/'run/exact-run-record.json')['result'],read(R/'exact-run-record.json')['result'])
nonwall=[d for d in diffs if not d[0].endswith('/elapsed_seconds/float_hex')]
assert not nonwall,nonwall[:3]
out={'status':'passed_saved_replay_review','record_sha256':sha(R/'exact-run-record.json'),'parent_resume_sha256':sha(C/'run/exact-run-record.json'),'runtime_modules':87,'accepted_steps':30,'packets':2,'events':2,'evaluations':685,'core_wall_s':core['elapsed_seconds'],'supervisor_wall_s':s['elapsed_s'],'all_accepted_states_times_ledgers_equal':True,'all_nonwall_core_fields_equal':True,'named_wall_differences':diffs,'raw_export_byte_equal':True,'four_reports_bound':True,'scope':'Saved identity, exact history, declared audit reports and resource arithmetic; no new solver/EOS execution or general replay equivalence claim.'}
(B/'independent-replay-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='named_wall_differences'}));print('Named wall differences:',len(diffs))
