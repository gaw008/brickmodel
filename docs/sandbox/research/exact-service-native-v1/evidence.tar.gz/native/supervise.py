"""Root-operated external supervisor; one phase, no automatic retries."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
SOURCE=Path('/Users/wanggaoying/Desktop/brickmodel-github/docs/sandbox/research/research-process-supervisor/supervisor.py')
EXPECTED='939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1'
PYTHON='/private/tmp/brick-water-backend-probe/venv/bin/python'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=('cancel','resume','replay'),required=True);parser.add_argument('--freeze-sha256',required=True)
    args=parser.parse_args()
    if sha(SOURCE)!=EXPECTED:raise ValueError('supervisor_identity_changed')
    if sha(HERE/'freeze.json')!=args.freeze_sha256:raise ValueError('authoritative_freeze_hash_mismatch')
    frozen=json.loads((HERE/'freeze.json').read_bytes())
    if frozen.get('status')!='FROZEN':raise ValueError('freeze_unfilled')
    for name,digest in frozen['scripts'].items():
        if sha(HERE/name)!=digest:raise ValueError('reviewed_script_changed')
    command=[PYTHON,str(HERE/'run.py'),'phase','--phase',args.phase,'--freeze-sha256',args.freeze_sha256]
    inputs=[HERE/'freeze.json',SOURCE]+[HERE/name for name in frozen['scripts']]+[HERE/'inputs'/name for name in frozen['files']]
    if args.phase!='cancel':
        parent='cancel' if args.phase=='resume' else 'resume'
        manifest=HERE/parent/'run/manifest.json';status=HERE/('supervised-'+parent)/'status.json'
        # Child checks terminal/reap and the captured hashes again before service.
        command+=['--parent-manifest-sha256',sha(manifest),'--parent-supervision-sha256',sha(status)]
        inputs.extend(p for p in (HERE/parent).rglob('*') if p.is_file())
        inputs.extend([status])
    spec=importlib.util.spec_from_file_location('reviewed_research_supervisor',SOURCE)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    result=module.run_attempt(HERE/('supervised-'+args.phase),command,cwd='/private/tmp',input_paths=inputs,
        timeout_s=frozen['limits'][args.phase],cleanup_grace_s=frozen['limits']['cleanup_grace_s'])
    print(json.dumps(result,indent=2))
    if result['returncode']!=0:raise SystemExit(1)

if __name__=='__main__':main()
