"""Saved-data identity/budget/export review only; no package imports or EOS."""
from pathlib import Path
import json,hashlib
from fractions import Fraction as F
H=Path(__file__).parent;C=H/'cancel';R=C/'run'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unpack(x):
 if isinstance(x,list):return [unpack(v) for v in x]
 if not isinstance(x,dict):return x
 if set(x)=={'float_hex'}:return float.fromhex(x['float_hex'])
 if set(x)=={'mapping'}:return {k:unpack(v) for k,v in x['mapping'].items()}
 if set(x)=={'sequence'}:return [unpack(v) for v in x['sequence']]
 if 'record' in x and 'fields' in x:return unpack(x['fields'])
 return {k:unpack(v) for k,v in x.items()}
freeze=read(H/'freeze.json');assert sha(H/'freeze.json')=='17771500235c84eb0bcd368fdd1368a6c231afdb374793acea6a03be93a485d2'
for root,expected in [(H/'inputs',freeze['files']),(R,read(R/'manifest.json')['files'])]:
 files={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and p!=R/'manifest.json'}
 assert files==expected
before=read(C/'runtime-before.json');assert before==read(C/'runtime-after.json')==freeze['runtime'];assert len(before['modules'])==87
record=unpack(read(C/'canonical-record.json'));raw=(R/'exact-run-record.json').read_bytes();assert raw==(C/'canonical-record.json').read_bytes()
assert record['binding']['runtime_identity']==before
assert record['binding']['case_sha256']==sha(H/'inputs/case.json')==sha(R/'case.json')
result=read(R/'result.json');assert result==read(C/'service-return.json')
assert read(C/'export.json')['canonical_exact_record']['text'].encode()==raw
assert result['status']==record['result']['status']=='cancelled'
assert result['reason']==record['result']['reason']=='cancel_requested'
core=record['result'];assert len(core['steps'])==1 and len(core['states'])==2 and not core['packets']
policy=core['initial_policy'];assert policy==read(H/'inputs/case.json')['numerics']['integration']
resources=result['exact_audits']['resources'];assert resources['charged_panels']==1 and resources['remaining_panels']==511
assert core['costs']==resources['cumulative_counters'];assert core['costs']['evaluations_attempted']==core['costs']['evaluations_completed']==9
assert F(**resources['remaining_wall_seconds'])==F(policy['maximum_wall_seconds'])-F(core['elapsed_seconds'])
for name,a in result['exact_audits'].items():
 assert a['record_sha256']==sha(R/'exact-run-record.json');assert a==read(R/('exact-audit-'+name+'.json'))
for t in read(C/'traces.json').values():assert t['value'] is None and t['canonical_exact_record']['sha256']==sha(R/'exact-run-record.json')
s=read(H/'supervised-cancel/status.json');assert s['status']=='complete' and s['returncode']==0 and s['cleanup']['leader_reaped'] and s['inputs_unchanged']
report={'status':'passed_saved_identity_budget_export_review','record_sha256':sha(R/'exact-run-record.json'),'record_bytes':len(raw),'modules':87,'accepted_steps':1,'events':0,'charged_panels':1,'remaining_panels':511,'supervisor_elapsed_s':s['elapsed_s'],'scope':'Saved identity, manifest, policy, cost arithmetic and raw export association; no independent RHS or event proof.'}
(C/'independent-cancel-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
