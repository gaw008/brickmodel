# Prospective native exact-service lifecycle — NOT EXECUTED

Root owns all native execution and installation. This directory contains only preparation, supervision and read/verify code. The service/code/catalog must finish independent review and be installed non-editably before `prepare`. No historical 78/84-module record is execution authority for this new version.

## Frozen inputs and unchanged science

Use reviewed `reacting-wet-free-exact-events-v1.json` with the original two-cell paired physical case. Preparation checks the original reference case: only case ID/schema, exact policy schema, explicit ordered policy and explicit no-spine-reuse declaration may differ. Original `.5 → .50032` interval, all original numerical/physical/source parameters, full 512-panel/800-second policy and original paired shared-constant declaration remain unchanged. No tuning after failure.

`run.py prepare` performs no build/EOS. It requires the actual installed package under the selected interpreter's site-packages, rejects editable installs/PYTHONPATH, and compares ALL actual installed module hashes with repository source and runtime metadata. It copies the full regular water directory, all catalog-required evidence/licenses, case, original reference case, installed implementation bytes and the exact catalog into fresh `inputs/`. Frozen metadata records versions/nonmodule runtime, paths, exact input hashes, script/PLAN/supervisor hashes and documented case diff. Every phase checks the externally supplied SHA of `freeze.json`, complete input membership/hashes, all runtime/source equality and script identities before and after. No old-runtime compatibility exception exists.

`freeze.json` is intentionally absent until root prepares the final installed version; no invented module count or SHA is inserted now. Root must record its actual digest and supply it to each supervisor invocation. No permission, retry or changed basis is inferred from a timeout.

## Sequential phases

1. **cancel**, outer 90 s + 0.1 s cleanup: actual shared `run_case` with `_exact_on_commit`. Only after the first globally committed ordinary prefix does the immutable notification arm cooperative cancellation. No RHS-call threshold is used. Save actual commits, returned result, full sealed service bundle, canonical bytes, all four audits, read/trace/export outputs before outcome assertions. Required result is `cancelled/cancel_requested`, nonempty accepted interior prefix and no committed packet. Unavailable final trace values are checked explicitly.
2. **resume**, separate process outer 180 s + 0.1 s cleanup: only after the first supervisor reports actual returncode0, complete status and reaped leader, and the phase report passed. Supervisor captures parent manifest and supervision hashes; child verifies those same hashes and termination fields. Call actual `resume_run` on the cancelled run. No manual state reconstruction, changed policy, artificial continuation token or duplicate suffix merge. Check exact canonical initial/start/end/policies, retained parent bytes/hash, every original accepted time/state/ledger/packet/refinement/terminal-attempt prefix once, nondecreasing cumulative cost/wall, completed final exact time and exactly the two initial wet cell events. All four service audits must bind the resulting canonical SHA.
3. **replay**, another process outer 180 s + 0.1 s cleanup: only after resume phase termination/reap and successful evidence checks. Call actual `replay_run` from the completed resumed run; verify original state, interval, policies, copied canonical parent bytes and new four-audit outputs. Save observed final-state/grid equality with the resumed run, but do not turn adaptive-restart differences into fabricated equality or add a new tolerance gate. Both runs independently satisfy their unchanged original service/core gates.

The 180 s cap is over twice the previously measured approximately 84 s completion cost plus observed build/audit/record overhead. It is NOT a prediction of this new version's runtime. It is deliberately below the original 800 s cumulative solver allowance; that allowance remains unchanged. A cap-triggered or unsealed result is retained as a failed experiment, not automatically retried. Only one supervisor/owned native process runs at a time; no install or source edits between phases.

The fixed reviewed supervisor SHA is `939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1`. Its process-group/reap limitations remain explicit in its own records; the child never signals a saved PID.

## Commands after review/application/installation (not run here)

With PYTHONPATH unset and the approved interpreter:

```
python run.py prepare --case <reviewed exact case> --water <complete approved water directory> --evidence <complete evidence directory>
python supervise.py --phase cancel --freeze-sha256 <actual newly frozen digest>
python supervise.py --phase resume --freeze-sha256 <same digest>
python supervise.py --phase replay --freeze-sha256 <same digest>
```

Use `/private/tmp/brick-water-backend-probe/venv/bin/python` for `python`; wrapper children pin that same interpreter. Phase outputs are fresh `cancel/`, `resume/`, `replay/`; supervisory outputs are separate `supervised-*`. Scripts do not launch the next phase automatically or overwrite an existing attempt.

## Evidence and limitations

Each phase retains runtime/input before-after records, original service-return JSON, sealed run artifacts, duplicate byte-exact canonical record, read manifest, complete raw-text export, seven quantity traces, observed outcome before gate assertions and final report. Action failures and later integrity failures occupy separate report fields, so a finalization failure cannot erase the original cause. Export roundtrip requires UTF-8 bytes exactly equal canonical bytes; the full text is not parsed as a JavaScript floating-point clock. Traces retain canonical SHA/source graph; cancelled values remain unavailable.

This validates a fresh installed shared-service lifecycle, not browser layout/HTTP socket operation, scientific material qualification, spatial convergence, or the full wet-to-fired/cooled process. Four audits are real source-bound service audits; they are not a substitute for independent physical validation. Historical timing motivates the external budget only.
