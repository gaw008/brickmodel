"""Prospective installed exact-service lifecycle probe; root alone launches native.

No package imports at module import time, allowing stdlib-only report tests.
"""
from pathlib import Path, PurePosixPath
from fractions import Fraction
import argparse
import hashlib
import importlib.metadata
import json
import os
import shutil
import sys
import sysconfig
import time
import traceback

HERE=Path(__file__).resolve().parent
REPO=Path('/Users/wanggaoying/Desktop/brickmodel-github')
SUPERVISOR=REPO/'docs/sandbox/research/research-process-supervisor/supervisor.py'
SUPERVISOR_SHA='939a86f4a8a45a127e49c18009c8fc9f7bd296d79243741bf3f3d2e6fb2f36d1'
CASE_SCHEMA='sludge_sandbox_free_exact_event_case_v1'
AUDITS={'prefix','terminal_proofs','comparisons','resources'}


def require(ok,reason):
    if not ok:raise ValueError(reason)


def sha(raw):return hashlib.sha256(raw).hexdigest()


def save(path,value):
    path=Path(path);raw=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(raw);temp.replace(path)


def read(path):return json.loads(Path(path).read_bytes())


def hashes(root):
    root=Path(root);result={}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(),'symlink_input')
        if path.is_file():result[path.relative_to(root).as_posix()]=sha(path.read_bytes())
    return result


def differences(a,b,pointer=''):
    if type(a) is dict and type(b) is dict:
        return [row for key in sorted(set(a)|set(b)) for row in differences(a.get(key,{'missing':True}),b.get(key,{'missing':True}),pointer+'/'+key)]
    return [] if type(a) is type(b) and a==b else [{'pointer':pointer,'before':a,'after':b}]


def installed():
    require(not os.environ.get('PYTHONPATH'),'native_PYTHONPATH_must_be_unset')
    import sludge_sandbox.run_service as service
    package=Path(service.__file__).resolve().parent
    require(package.is_relative_to(Path(sysconfig.get_paths()['purelib']).resolve()),'installed_package_required')
    dist=importlib.metadata.distribution('sludge-vme');direct=dist.read_text('direct_url.json')
    metadata=None if direct is None else json.loads(direct)
    require(not metadata or metadata.get('dir_info',{}).get('editable') is not True,'editable_install_forbidden')
    runtime=service.runtime_identity()
    actual={p.name:sha(p.read_bytes()) for p in package.glob('*.py')}
    source={p.name:sha(p.read_bytes()) for p in (REPO/'src/sludge_sandbox').glob('*.py')}
    require(actual==source==runtime['modules'],'actual_installed_source_module_identity')
    require(all(not p.is_symlink() for p in package.glob('*.py')),'installed_source_symlink')
    return service,package,runtime,{'python':sys.executable,'package':str(package),'distribution_direct_url':metadata,'module_count':len(actual)}


def prepare(case_path,water_directory,evidence_directory):
    service,package,runtime,environment=installed()
    from sludge_sandbox.verification_case import read_case
    from sludge_sandbox.run_provenance import catalog_bytes,evidence_paths
    require(sha(SUPERVISOR.read_bytes())==SUPERVISOR_SHA,'supervisor_source_identity')
    case=read_case(case_path);payload=case.payload
    require(payload['schema']==CASE_SCHEMA and payload['grid']['cells']==2,'explicit_two_cell_exact_case_required')
    reference=REPO/'data/sandbox/cases/reacting-wet-free-paired-events-endpoint-root-v1.json'
    original=read(reference);delta=differences(original,payload)
    allowed={'/case_id','/schema','/numerics/depletion/schema','/numerics/depletion/ordered_event_policy','/numerics/depletion/nested_approach/reuse_ordinary_spine'}
    require({r['pointer'] for r in delta}<=allowed,'scientific_inputs_changed')
    require(payload['numerics']['start_s']==.5 and payload['numerics']['end_s']==.50032,'original_interval_required')
    require(payload['numerics']['integration']['maximum_wall_seconds']==800. and payload['numerics']['integration']['maximum_steps']==512,'original_resource_policy_required')
    require(payload['numerics']['depletion']['pressure_comparison'] is not None,'original_paired_declaration_required')
    inputs=HERE/'inputs';inputs.mkdir(exist_ok=False)
    (inputs/'case.json').write_bytes(Path(case_path).read_bytes());(inputs/'original-reference-case.json').write_bytes(reference.read_bytes())
    (inputs/'water').mkdir()
    for src in sorted(Path(water_directory).iterdir()):
        require(src.is_file() and not src.is_symlink(),'regular_water_files_required')
        shutil.copyfile(src,inputs/'water'/src.name)
    raw=catalog_bytes(payload['model_id'],case_schema=CASE_SCHEMA)
    (inputs/'equation_catalog.json').write_bytes(raw)
    for name in evidence_paths(json.loads(raw)):
        source=Path(evidence_directory)/name
        require(source.is_file() and not source.is_symlink() and source.resolve().is_relative_to(Path(evidence_directory).resolve()),'complete_known_evidence_required:'+name)
        dest=inputs/'evidence'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
    (inputs/'implementation').mkdir()
    for src in package.glob('*.py'):shutil.copyfile(src,inputs/'implementation'/src.name)
    frozen={'schema':'exact_service_native_freeze_v1','status':'FROZEN','runtime':runtime,'environment':environment,
        'files':hashes(inputs),'case_sha256':sha((inputs/'case.json').read_bytes()),'source_case_diff':delta,
        'scripts':{name:sha((HERE/name).read_bytes()) for name in ('run.py','supervise.py','PLAN.md')},
        'supervisor_sha256':SUPERVISOR_SHA,'limits':{'cancel':90.,'resume':180.,'replay':180.,'cleanup_grace_s':.1},
        'qualification':'Fresh installed same-version lifecycle only; no historical runtime execution compatibility; manufactured verification, not material validation.'}
    save(HERE/'freeze.json',frozen)
    return {'freeze_sha256':sha((HERE/'freeze.json').read_bytes()),'modules':len(runtime['modules']),'status':'prepared_no_EOS'}


def verified_freeze(expected):
    raw=(HERE/'freeze.json').read_bytes();require(sha(raw)==expected,'authoritative_freeze_hash_mismatch')
    frozen=json.loads(raw);require(frozen.get('status')=='FROZEN','freeze_unfilled')
    require(hashes(HERE/'inputs')==frozen['files'],'frozen_input_changed')
    for name,digest in frozen['scripts'].items():require(sha((HERE/name).read_bytes())==digest,'runner_or_plan_changed')
    require(sha(SUPERVISOR.read_bytes())==frozen['supervisor_sha256']==SUPERVISOR_SHA,'supervisor_changed')
    service,_,runtime,environment=installed()
    require(runtime==frozen['runtime'],'fresh_execution_runtime_mismatch')
    return service,frozen,runtime,environment


def terminal_parent(phase,expected_manifest,expected_supervision):
    previous='cancel' if phase=='resume' else 'resume'
    directory=HERE/previous
    require(sha((directory/'run/manifest.json').read_bytes())==expected_manifest,'authoritative_parent_manifest_mismatch')
    status=HERE/('supervised-'+previous)/'status.json'
    require(sha(status.read_bytes())==expected_supervision,'authoritative_parent_supervision_mismatch')
    record=read(status)
    require(record.get('status')=='complete' and record.get('returncode')==0 and record.get('cleanup',{}).get('leader_reaped') is True,'parent_not_terminal_reaped_success')
    require(read(directory/'report.json').get('capture_status')=='passed','parent_phase_not_passed')
    return directory/'run'


def prefix_relation(parent,child,pack):
    checks={}
    pairs=(('times',parent.times,child.times),('states',parent.states,child.states),('ledgers',parent.ledgers,child.ledgers),
        ('packets',parent.result.packets,child.result.packets),('refinements',parent.result.refinements,child.result.refinements),('terminal_attempts',parent.result.terminal_attempts,child.result.terminal_attempts))
    for name,a,b in pairs:
        require(pack(tuple(b[:len(a)]))==pack(tuple(a)),'original_prefix_changed:'+name);checks[name]=len(a)
    require(child.start==parent.start and child.end==parent.end,'original_interval_changed')
    require(pack(child.result.initial_policy)==pack(parent.result.initial_policy) and pack(child.result.event_policy)==pack(parent.result.event_policy),'original_policies_changed')
    require(all(child.result.costs[k]>=v for k,v in parent.result.costs.items()),'cumulative_cost_reset')
    require(Fraction(child.result.elapsed_seconds)>=Fraction(parent.result.elapsed_seconds),'cumulative_wall_reset')
    return checks


def capture(out,action,finalize):
    """Preserve action failure separately from later integrity/report failures."""
    report={'capture_status':'started'};save(out/'report.json',report);start=time.monotonic()
    try:
        report.update(action());report['capture_status']='passed'
    except BaseException as exc:
        report.update(capture_status='failed',error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
    finally:
        try:report.update(finalize())
        except BaseException as exc:
            report.update(capture_status='failed',integrity_error_type=type(exc).__name__,integrity_error=str(exc),integrity_traceback=traceback.format_exc())
        report['runner_elapsed_s']=time.monotonic()-start;save(out/'report.json',report)
    return report


def run_phase(phase,expected_freeze,expected_parent_manifest=None,expected_parent_supervision=None):
    out=HERE/phase;out.mkdir(exist_ok=False)
    state={}
    def action():
        service,frozen,before,environment=verified_freeze(expected_freeze)
        state['before']=before;save(out/'runtime-before.json',before);save(out/'environment.json',environment)
        save(out/'inputs-before.json',hashes(HERE/'inputs'))
        parent=None if phase=='cancel' else terminal_parent(phase,expected_parent_manifest,expected_parent_supervision)
        if parent is not None:save(out/'parent-binding.json',{'manifest_sha256':expected_parent_manifest,'supervision_sha256':expected_parent_supervision,'directory':str(parent)})
        from sludge_sandbox.exact_record import read_exact_run,pack
        commits=[];cancelled=[False]
        def on_commit(info):
            steps,packets,t=info
            require(type(steps) is int and type(packets) is int and steps>=1,'actual_commit_notification')
            commits.append({'accepted_steps':steps,'committed_packets':packets,'time':{'numerator':str(t.seconds.numerator),'denominator':str(t.seconds.denominator)}})
            save(out/'commits.json',commits);cancelled[0]=True
        if phase=='cancel':result=service.run_case(HERE/'inputs/case.json',HERE/'inputs/water',out/'run',evidence_directory=HERE/'inputs/evidence',cancel=lambda:cancelled[0],_exact_on_commit=on_commit)
        elif phase=='resume':result=service.resume_run(parent,out/'run')
        else:result=service.replay_run(parent,out/'run')
        save(out/'service-return.json',result)
        verified,manifest=service.read_run(out/'run')
        save(out/'verified-manifest.json',manifest)
        raw=(out/'run/exact-run-record.json').read_bytes();(out/'canonical-record.json').write_bytes(raw)
        record=read_exact_run(raw)
        evidence={'service_status':result['status'],'service_reason':result.get('reason'),'core_status':record.result.status,'core_reason':record.result.reason,
            'record_sha256':record.sha256,'record_bytes':len(raw),'accepted_steps':len(record.ledgers),'packets':len(record.result.packets),'events':sum(map(len,record.result.packets)),
            'costs':dict(record.result.costs),'core_elapsed_s':record.result.elapsed_seconds,'service_elapsed_s':result['elapsed_seconds']}
        save(out/'actual-outcome-before-gates.json',evidence)
        require(verified==result,'service_return_saved_result_mismatch')
        require(set(result.get('exact_audits',{}))==AUDITS,'four_audits_missing')
        require(all(v['record_sha256']==record.sha256 for v in result['exact_audits'].values()),'audit_record_binding')
        require(record.binding['runtime_identity']==before,'record_execution_runtime_binding')
        exported=service.export_run(out/'run');save(out/'export.json',exported)
        require(exported['canonical_exact_record']['text'].encode('utf-8')==raw,'export_raw_record_changed')
        traces={q:service.trace_run(out/'run',q) for q in ('amounts_mol','internal_energy_j','temperature_k','pressure_pa','mechanical_stretches','geometry','free')}
        save(out/'traces.json',traces)
        require(all(t['canonical_exact_record']['sha256']==record.sha256 for t in traces.values()),'trace_canonical_record_binding')
        if phase=='cancel':
            require(result['status']==record.result.status=='cancelled' and record.result.reason=='cancel_requested','actual_cooperative_cancel_required')
            require(commits and len(record.ledgers)>=1 and record.times[-1]<record.end and not record.result.packets,'first_ordinary_committed_prefix_required')
            require(all(t['value'] is None for t in traces.values()),'cancelled_final_value_must_be_unavailable')
        else:
            require(result['status']==record.result.status=='completed' and record.times[-1]==record.end,'actual_completed_required')
            cells=[frame.terminal.root_order.selected_cell for p in record.result.packets for frame in p]
            require(sorted(cells)==[0,1],'each_actual_initial_wet_cell_event_required')
            prior=read_exact_run((parent/'exact-run-record.json').read_bytes())
            if phase=='resume':
                evidence['original_prefix_counts']=prefix_relation(prior,record,pack)
                require(result['resume_of']['exact_record_sha256']==prior.sha256,'resume_parent_record_hash')
                require((out/'run/parent/exact-run-record.json').read_bytes()==prior.canonical_bytes,'retained_parent_bytes_changed')
            else:
                require(pack(record.states[0])==pack(prior.states[0]) and record.start==prior.start and record.end==prior.end,'replay_original_state_interval')
                require(pack(record.result.initial_policy)==pack(prior.result.initial_policy) and pack(record.result.event_policy)==pack(prior.result.event_policy),'replay_original_policies')
                require((out/'run/replay_parent/exact-run-record.json').read_bytes()==prior.canonical_bytes,'replay_parent_record_copy')
                evidence['replay_comparison']={'final_conserved_states_bit_equal':pack(record.states[-1])==pack(prior.states[-1]),'accepted_times_equal':record.times==prior.times,
                    'qualification':'Observed comparison with resumed trajectory only; restarted adaptivity need not match uninterrupted replay, no new tolerance or physical pass inferred.'}
        return evidence
    def finalize():
        _,_,after,_=verified_freeze(expected_freeze);save(out/'runtime-after.json',after);save(out/'inputs-after.json',hashes(HERE/'inputs'))
        require('before' not in state or state['before']==after,'runtime_changed_during_phase')
        return {'runtime_unchanged':True,'runner_sha256':sha(Path(__file__).read_bytes()),'freeze_sha256':expected_freeze}
    return capture(out,action,finalize)


def main():
    parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='operation',required=True)
    p=sub.add_parser('prepare');p.add_argument('--case',required=True);p.add_argument('--water',required=True);p.add_argument('--evidence',required=True)
    p=sub.add_parser('phase');p.add_argument('--phase',choices=('cancel','resume','replay'),required=True);p.add_argument('--freeze-sha256',required=True)
    p.add_argument('--parent-manifest-sha256');p.add_argument('--parent-supervision-sha256')
    a=parser.parse_args()
    if a.operation=='prepare':
        preparation=HERE/'preparation';preparation.mkdir(exist_ok=False)
        result=capture(preparation,lambda:prepare(a.case,a.water,a.evidence),lambda:{'runner_sha256':sha(Path(__file__).read_bytes())})
    else:result=run_phase(a.phase,a.freeze_sha256,a.parent_manifest_sha256,a.parent_supervision_sha256)
    print(json.dumps(result,indent=2,allow_nan=False))
    if result.get('capture_status')=='failed':raise SystemExit(1)

if __name__=='__main__':main()
