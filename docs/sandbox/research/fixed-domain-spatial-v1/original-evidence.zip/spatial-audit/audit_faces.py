"""Independent saved callback arithmetic; standard library only, no model imports."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import traceback
from typing import Any

HERE = Path(__file__).resolve().parent
POLICY = {'relative_tolerance': 1e-12, 'ulp_sum_multiplier': 64,
          'timing': 'fixed before new fixed-domain native execution; inherited unchanged from reviewed two-cell algebra audit'}


def audit(data: dict[str, Any], plan: dict[str, Any], policy: dict[str, Any], result: dict[str, Any]) -> None:
    checks: list[dict[str, Any]] = []
    result['checks'] = checks
    prefix = ''

    def require(condition: bool, label: str) -> None:
        label = prefix+label
        checks.append({'name': label, 'passed': bool(condition)})
        if not condition:
            raise ValueError(label)

    def close(actual: float, expected: float, label: str, terms: tuple[float, ...] = ()) -> None:
        label = prefix+label
        values = (actual, expected, *terms)
        if not all(math.isfinite(v) for v in values):
            raise ValueError('nonfinite:'+label)
        bound = policy['relative_tolerance']*max(abs(actual), abs(expected))
        bound += policy['ulp_sum_multiplier']*math.fsum(math.ulp(v) for v in values)
        error = abs(actual-expected)
        checks.append({'name': label, 'actual': actual, 'expected': expected,
                       'absolute_error': error, 'bound': bound, 'passed': error <= bound})
        if error > bound:
            raise ValueError('arithmetic_mismatch:'+label)

    require(data['status'] == 'passed', 'callback_passed')
    cells, profile = data['cells'], data['profile']
    require(cells in (2, 4) and profile in ('gradient', 'uniform'), 'declared_grid_profile')
    s = data['snapshot']
    inventory = s['state']['amounts_mol']
    require(s['state'] == data['initial'], 'snapshot_is_initial')
    parent_rows = [list(row) for row in plan['initialization']['gradient_parent_rows_mol']]
    if profile == 'uniform':
        parent_rows[1] = list(parent_rows[0])
    expected_inventory = [[value*(2/cells) for value in parent_rows[index//(cells//2)]] for index in range(cells)]
    require(inventory == expected_inventory, 'registered_scaled_inventory')
    require(s['time_s'] == plan['time_interval_s'][0], 'registered_time')
    names = tuple(s['gas_states'][0]['concentrations_mol_m3'])
    require(set(names) == {'fixture', 'H2O'}, 'gas_species')
    masses, gas_r = s['molar_masses_kg_mol'], s['gas_constant_j_mol_k']
    layout = ['A', 'B', 'H2O', 'H2O_liquid', 'fixture']
    gases = []
    for cell, stored in enumerate(s['gas_states']):
        m = s['cells'][cell]['thermal']['mechanical']
        t, volume = m['temperature_k'], m['gas_volume_m3']
        require(volume > 0 and t > 0, f'cell{cell}:positive_domain')
        close(stored['temperature_k'], t, f'cell{cell}:T')
        close(stored['gas_constant_j_mol_k'], gas_r, f'cell{cell}:R')
        concentrations = {k: inventory[cell][layout.index(k)]/volume for k in names}
        total = math.fsum(concentrations.values())
        x = {k: concentrations[k]/total for k in names}
        mean = math.fsum(x[k]*masses[k] for k in names)
        rho, pressure = total*mean, total*gas_r*t
        y = {k: x[k]*masses[k]/mean for k in names}
        for k in names:
            close(stored['molar_masses_kg_mol'][k], masses[k], f'cell{cell}:mass:{k}')
            for field, values in [('concentrations_mol_m3', concentrations), ('mole_fractions', x), ('mass_fractions', y)]:
                close(stored[field][k], values[k], f'cell{cell}:{field}:{k}')
        for field, value in [('mean_molar_mass_kg_mol', mean), ('density_kg_m3', rho), ('pressure_pa', pressure)]:
            close(stored[field], value, f'cell{cell}:{field}')
        gases.append({'t': t, 'p': pressure, 'x': x, 'y': y})
    require(len(gases) == cells and len(s['cells']) == cells, 'declared_gases_and_cells')
    area = s['face_area_m2']
    widths = s['cell_widths_m']
    require(len(widths) == cells, 'declared_widths')
    for i in range(cells):
        close(widths[i], s['motion']['current']['widths_m'][i], f'current_width:{i}')
    for i, value in enumerate(s['motion']['current']['face_areas_m2']):
        close(area, value, f'current_area:{i}')
    require(len(s['internal_faces']) == cells-1, 'all_internal_faces_recorded')
    require([row['face_index'] for row in s['internal_faces']] == list(range(1, cells)), 'ordered_internal_face_indices')
    result['reconstruction'] = []
    for face_record in s['internal_faces']:
        face = face_record['face_index']
        prefix = f'face{face}:'
        dl, dr = widths[face-1]/2, widths[face]/2
        distance, weight = dl+dr, dr/(dl+dr)
        left, right = gases[face-1], gases[face]
        face_t = weight*left['t']+(1-weight)*right['t']
        face_p = weight*left['p']+(1-weight)*right['p']
        xinput = {k: weight*left['x'][k]+(1-weight)*right['x'][k] for k in names}
        xsum = math.fsum(xinput.values())
        # Reservoir construction normalizes its interpolated composition, then
        # derives gas intensives from its represented species concentrations.
        face_c = {k: (face_p/(gas_r*face_t))*xinput[k]/xsum for k in names}
        face_total = math.fsum(face_c.values())
        face_x = {k: face_c[k]/face_total for k in names}
        mean = math.fsum(face_x[k]*masses[k] for k in names)
        face_rho = face_total*mean
        diffusion = {}
        for k in names:
            dleft, dright = s['diffusivities_m2_s'][k][face-1:face+1]
            registered_value = plan['inherited_physics']['transport_coupled']['H2O_diffusivities_m2_s'][0] if k == 'H2O' else plan['inherited_physics']['carrier_diffusivity']
            require(s['diffusivities_m2_s'][k] == [registered_value]*cells, 'registered_diffusion:'+k)
            diffusion[k] = 0. if dleft == 0 or dright == 0 else distance/(dl/dleft+dr/dright)
        require(plan['inherited_physics']['permeability'] == 0, 'registered_zero_Darcy_scope')
        star = {k: -face_rho*(masses[k]/mean)*diffusion[k]*(right['x'][k]-left['x'][k])/distance for k in names}
        total_star = math.fsum(star.values())
        donor = left if total_star < 0 else right if total_star > 0 else None
        correction = {k: -total_star*donor['y'][k] if donor else 0. for k in names}
        molar = {k: area*(star[k]+correction[k])/masses[k] for k in names}
        ex = face_record['exchange_reconstructed']
        close(ex['face_temperature_k'], face_t, 'face_T')
        close(ex['face_density_kg_m3'], face_rho, 'face_rho')
        close(ex['diffusion_correction_velocity_m_s'], -total_star/face_rho, 'correction_velocity')
        require(ex['diffusion_correction_donor'] == ('left' if total_star < 0 else 'right' if total_star > 0 else None), 'correction_donor')
        require(ex['darcy_velocity_m_s'] == 0 and ex['advective_donor'] is None, 'zero_Darcy_observed')
        fn, fe = s['rates']['face_species_mol_s'], s['rates']['face_energy_w']
        require(len(fn) == len(fe) == cells+1 and all(len(row) == 5 for row in fn), 'face_shapes')
        require(all(v == 0 for row in (fn[0], fn[-1]) for v in row) and fe[0] == fe[-1] == 0, 'external_faces_zero')
        require(all(fn[face][layout.index(k)] == 0 for k in ('A', 'B', 'H2O_liquid')), 'immobile_columns')
        for k in names:
            require(ex['advective_mol_s'][k] == 0, 'zero_advection:'+k)
            close(ex['diffusive_mol_s'][k], molar[k], 'diffusive:'+k)
            close(ex['net_mol_s'][k], molar[k], 'net:'+k)
            close(fn[face][layout.index(k)], molar[k], 'assembled_molar:'+k)
        mass_terms = tuple(molar[k]*masses[k] for k in names)
        close(math.fsum(mass_terms), 0., 'mass_frame_sum', mass_terms)
        kleft, kright = s['conductivities_w_m_k'][face-1:face+1]
        registered_k = plan['inherited_physics']['transport_coupled']['conductivities_w_m_k'][0]
        require(s['conductivities_w_m_k'] == [registered_k]*cells, 'registered_conductivity')
        heat = 0. if kleft == 0 or kright == 0 else area*(left['t']-right['t'])/(dl/kleft+dr/kright)
        enthalpy_terms = tuple(molar[k]*face_record['enthalpy_j_mol_at_face_temperature'][k] for k in names)
        expected_energy = math.fsum((heat, *enthalpy_terms))
        close(fe[face], expected_energy, 'assembled_energy', (heat, *enthalpy_terms))
        central_jump = profile == 'gradient' and face == cells//2
        require((molar['H2O'] != 0 and heat != 0 and fn[face][layout.index('H2O')] != 0) if central_jump
                else all(v == 0 for v in (*molar.values(), heat, fe[face], *fn[face])), 'initial_profile_face_effect')
        result['reconstruction'].append({'face_index': face, 'profile': profile, 'face_temperature_k': face_t, 'face_pressure_pa': face_p,
            'face_density_kg_m3': face_rho, 'j_star_kg_m2_s': star, 'correction_kg_m2_s': correction,
            'species_mol_s': molar, 'fourier_w': heat, 'species_enthalpy_w': math.fsum(enthalpy_terms),
            'assembled_energy_w': expected_energy})


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--plan', type=Path, default=Path('/private/tmp/brick-fixed-spatial-v1/PLAN.json'))
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Preserve existing audit output')
    result: dict[str, Any] = {'status': 'started', 'inputs': [], 'policy': POLICY,
        'qualification': 'independent saved arithmetic; source caloric samples reused, no EOS or trajectory accuracy claim'}
    try:
        records = []
        for path in (args.input, args.plan):
            entry = {'path': str(path), 'exists': path.is_file()}
            result['inputs'].append(entry)
            raw = path.read_bytes()
            entry.update(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
            records.append(json.loads(raw))
        data, plan = records
        policy = POLICY
        if policy['relative_tolerance'] != 1e-12 or policy['ulp_sum_multiplier'] != 64:
            raise ValueError('unexpected_frozen_policy')
        audit(data, plan, policy, result)
        result['status'] = 'passed'
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        temporary = args.output.with_suffix(args.output.suffix+'.tmp')
        temporary.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
        temporary.replace(args.output)
    print(json.dumps({'status': result['status'], 'checks': len(result.get('checks', [])), 'output': str(args.output)}))
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
