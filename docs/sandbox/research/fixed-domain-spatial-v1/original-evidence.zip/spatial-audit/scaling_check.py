"""No-EOS extensive skeleton scaling experiment using the actual installed API."""
from dataclasses import replace
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
import traceback
from sludge_sandbox.geometry import ReferenceSlab
from sludge_sandbox.skeleton_energy import DiagonalSkeletonEnergy
from sludge_sandbox.reacting_skeleton_energy import ManufacturedReactingSkeletonEnergy

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
EXTENSIVE = {'elastic_energy_j', 'interface_energy_j', 'elastic_rate_w', 'interface_rate_w',
             'dissipation_w', 'rayleigh_potential_w'}


def model(cells):
    split = cells // 2
    base = DiagonalSkeletonEnergy(reference=ReferenceSlab(.02, .01, cells), cell_index=0,
        fixed_solid_inventory_mol=(('A', 2./split), ('B', 0.)),
        solid_provider_identity=('manufactured-scaling-no-eos', 'v1'),
        bulk_modulus_pa=1000., shear_modulus_pa=400., viscosity_pa_s=3.,
        interface_energy_j_m2=100., reference_interface_area_m2=.003/split,
        stretch_range=(.5, 2.), maximum_absolute_log_rate_per_s=2.,
        model_id='scaling-reference', version='1', source_ids=('manufactured-scaling',),
        classification='manufactured_test_fixture', allow_manufactured=True)
    return ManufacturedReactingSkeletonEnergy(reference_model=base, composition_offset=1.,
        composition_weights_per_mol=(('A', 0.), ('B', 10.*split)),
        model_id='scaling-q', version='1', classification='manufactured_test_fixture', allow_manufactured=True)


def flatten(value, bounds, prefix):
    if isinstance(value, tuple):
        return [(prefix+f'[{i}]', v, bounds[i]) for i, v in enumerate(value)]
    if hasattr(value, 'items'):
        return [(prefix+'['+key+']', v, bounds[key]) for key, v in value.items()]
    return [(prefix, value, bounds)]


def run(report):
    parent, child = model(2), model(4)
    assert F(parent.reference_volume_m3) == 2*F(child.reference_volume_m3)
    assert F(parent.reference_model.reference_interface_area_m2) == 2*F(child.reference_model.reference_interface_area_m2)
    assert F(1e-6) == 2*F(1e-6/2)  # manufactured lumped phase conductance
    report['checks'] = []
    report['negative_controls'] = []
    for b in (0., .125, 1.):
        amounts = {'A': 2.-b, 'B': b}
        smaller = {key: value/2 for key, value in amounts.items()}
        assert all(F(amounts[key]) == 2*F(smaller[key]) for key in amounts)
        assert 1+F(10.)*F(b) == 1+F(20.)*F(smaller['B'])
        # Same concentrations and k mean an extensive first-order source.
        assert F(amounts['A'])/F(parent.reference_volume_m3) == F(smaller['A'])/F(child.reference_volume_m3)
        assert F(.1)*F(amounts['A']) == 2*F(.1)*F(smaller['A'])
        for ln, lt, dn, dt in ((1., 1., 0., 0.), (.95, .95, -.15, -.15), (1.1, .9, .03, -.02)):
            kwargs = dict(normal_stretch=ln, tangential_stretch=lt, normal_rate_per_s=dn, tangential_rate_per_s=dt)
            p = parent.evaluate(**kwargs, solid_inventory_mol=amounts)
            c = child.evaluate(**kwargs, solid_inventory_mol=smaller)
            for key in p.numerical_error_bounds:
                pvals = flatten(getattr(p, key), p.numerical_error_bounds[key], key)
                cvals = flatten(getattr(c, key), c.numerical_error_bounds[key], key)
                factor = 2 if key in EXTENSIVE else 1
                for (name, pv, pb), (cname, cv, cb) in zip(pvals, cvals, strict=True):
                    assert name == cname
                    error = abs(F(pv)-factor*F(cv)); bound = F(pb)+factor*F(cb)
                    record = dict(B_mol=b, stretches=[ln,lt], rates=[dn,dt], quantity=name,
                                  factor=factor, parent=pv, child=cv, error=float(error), bound=float(bound), passed=error<=bound)
                    report['checks'].append(record)
                    assert error <= bound, record
            # Independent exact interface law, not another API evaluation as oracle.
            exact = (1+F(10.)*F(b))*F(100.)*F(.003)*F(lt)**2
            assert abs(F(p.interface_energy_j)-exact) <= F(p.numerical_error_bounds['interface_energy_j'])
            if b > 0:
                wrong = replace(child, composition_weights_per_mol=(('A',0.),('B',10.))).evaluate(**kwargs, solid_inventory_mol=smaller)
                gap = abs(F(p.interface_energy_j)-2*F(wrong.interface_energy_j))
                bound = F(p.numerical_error_bounds['interface_energy_j'])+2*F(wrong.numerical_error_bounds['interface_energy_j'])
                report['negative_controls'].append(dict(B_mol=b, stretch_t=lt, wrong_weight_gap_j=float(gap), bound_j=float(bound), rejected=gap>bound))
                assert gap > bound
    report['installed_modules'] = []
    for name, module in tuple(sys.modules.items()):
        if name == 'sludge_sandbox' or name.startswith('sludge_sandbox.'):
            path = Path(module.__file__).resolve()
            assert 'site-packages' in path.parts
            source = ROOT/'src'/Path(*path.parts[path.parts.index('sludge_sandbox'):])
            assert path.read_bytes() == source.read_bytes()
            report['installed_modules'].append(dict(name=name,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    report['status'] = 'passed'


def main():
    output = HERE/'scaling-result.json'
    if output.exists():
        raise SystemExit('Preserve existing scaling result')
    report = {'status':'started','qualification':'Manufactured extensive API scaling and exact interface oracle; no EOS, phase or reaction API evaluation and no material validation.',
              'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    try:
        run(report)
    except BaseException as exc:
        report.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
    finally:
        output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(report['status'],len(report.get('checks',[])),len(report.get('negative_controls',[])))
    return 0 if report['status']=='passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
