"""Conservative fixed-domain grid discrepancies; no solver import or convergence claim."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import traceback

HERE = Path(__file__).resolve().parent
COARSE = Path('/private/tmp/brick-reacting-wet-two-cell-v1')
FINE = Path('/private/tmp/brick-fixed-spatial-v1')
SPECIES = ('A','B','H2O','H2O_liquid','fixture')


def number(x):
    assert type(x) in (float,int) and math.isfinite(x)
    return F(x)


def read(path, report):
    raw = path.read_bytes()
    report['inputs'].append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()})
    return json.loads(raw)


def compare(report):
    runs = {}
    for grid in (2,4):
        for ref in (0,1):
            path = COARSE/f'wet-coupled-{ref}-result.json' if grid==2 else FINE/f'wet-4-gradient-{ref}-result.json'
            d = read(path,report); sha=report['inputs'][-1]['sha256']
            auditpath = Path('/private/tmp/brick-two-cell-audit-v1')/f'ledger-coupled-{ref}.json' if grid==2 else HERE/f'ledger-4-gradient-{ref}.json'
            audit=read(auditpath,report)
            assert audit['status']=='prefix_audit_passed' and audit['trajectory_completed'] and audit['sha256']==sha
            assert d['status']=='passed_pending_independent_ledger_audit' and d['run']['status']=='completed'
            assert d['refinement']==ref
            if grid==4:
                assert d['cells']==4 and d['profile']=='gradient'
            else:
                assert d['mode']=='coupled'
            assert d['run']['states'][0]==d['initial']
            assert d['final_snapshot']['state']==d['run']['states'][-1]
            assert len(d['initial']['amounts_mol'])==grid
            assert d['run']['times_s'][0]==.5 and d['run']['times_s'][-1]==.5+1/65536
            assert d['final_snapshot']['time_s']==d['run']['times_s'][-1]
            runs[grid,ref]=d
    report['initial_pair_checks']=[]
    for ref in (0,1):
        c,f = runs[2,ref],runs[4,ref]
        assert c['policy']==f['policy'], 'time-control policies must match per cap'
        assert c['final_snapshot']['implementation']==f['final_snapshot']['implementation']
        assert c['final_snapshot']['water_source_asset_sha256']==f['final_snapshot']['water_source_asset_sha256']
        assert c['final_snapshot']['face_area_m2']==f['final_snapshot']['face_area_m2']
        for parent in (0,1):
            for column in range(5):
                cn=number(c['initial']['amounts_mol'][parent][column])
                fn=sum((number(f['initial']['amounts_mol'][child][column]) for child in (2*parent,2*parent+1)),F())
                assert cn==fn, 'nonconservative initial species'
            ce=number(c['initial']['internal_energy_j'][parent])
            fe=sum((number(f['initial']['internal_energy_j'][child]) for child in (2*parent,2*parent+1)),F())
            assert ce==fe, 'nonconservative initial energy'
            cw=number(c['final_snapshot']['cell_widths_m'][parent])
            fw=sum((number(f['final_snapshot']['cell_widths_m'][child]) for child in (2*parent,2*parent+1)),F())
            assert cw==fw, 'different physical domain'
            report['initial_pair_checks'].append({'refinement':ref,'parent':parent,'passed':True})
    for grid in (2,4):
        assert runs[grid,0]['initial']==runs[grid,1]['initial']
        for field in ('initial_step_s','maximum_step_s'):
            assert number(runs[grid,0]['policy'][field])==2*number(runs[grid,1]['policy'][field])
    report['conservative_discrepancies']=[]
    report['temperature_diagnostics']=[]
    for parent in (0,1):
        for kind,column in [('amount',i) for i in range(5)]+[('energy',None)]:
            def value(grid,ref):
                state=runs[grid,ref]['final_snapshot']['state']
                indices=(parent,) if grid==2 else (2*parent,2*parent+1)
                vals=state['internal_energy_j'] if kind=='energy' else [row[column] for row in state['amounts_mol']]
                return sum((number(vals[i]) for i in indices),F())
            c0,c1,f0,f1=(value(g,r) for g,r in ((2,0),(2,1),(4,0),(4,1)))
            report['conservative_discrepancies'].append({'parent':parent,'quantity':'energy_j' if kind=='energy' else SPECIES[column]+'_mol',
                'grid4_minus_grid2_coarse_time':float(f0-c0),'grid4_minus_grid2_fine_time':float(f1-c1),
                'grid2_fine_minus_coarse_time':float(c1-c0),'grid4_fine_minus_coarse_time':float(f1-f0),
                'resolution':'diagnostic_only_no_mesh_convergence_gate'})
        vals={}; bounds={}
        for grid in (2,4):
            for ref in (0,1):
                snap=runs[grid,ref]['final_snapshot']; indices=(parent,) if grid==2 else (2*parent,2*parent+1)
                # Equal reference volumes on each grid; diagnostic average only.
                vals[grid,ref]=sum((number(snap['cells'][i]['thermal']['mechanical']['temperature_k']) for i in indices),F())/len(indices)
                bounds[grid,ref]=sum((number(snap['cells'][i]['inverse_temperature_error_k']) for i in indices),F())/len(indices)
        report['temperature_diagnostics'].append({'parent':parent,'qualification':'reference-volume-weighted diagnostic average, not temperature decoded from aggregate energy',
            'grid4_minus_grid2_fine_time_k':float(vals[4,1]-vals[2,1]),
            'grid2_time_cap_difference_k':float(vals[2,1]-vals[2,0]),'grid4_time_cap_difference_k':float(vals[4,1]-vals[4,0]),
            'sum_fine_decoding_bounds_k':float(bounds[4,1]+bounds[2,1]),
            'mesh_convergence':'unproven_two_grids_and_discontinuous_initial_field'})
    report['status']='comparison_completed'


if __name__=='__main__':
    output=HERE/'grid-comparison.json'
    if output.exists():
        raise SystemExit('Preserve existing comparison')
    report={'status':'started','inputs':[],'qualification':'Same-domain conservative aggregation, time and spatial discrepancies separate; no material validation or asymptotic convergence proof.'}
    try:
        compare(report)
    except BaseException as exc:
        report.update(status='failed',error_type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc())
    finally:
        output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    raise SystemExit(0 if report['status']=='comparison_completed' else 1)
