"""Fixed-domain conservative spatial prolongation and source storage checks."""
from __future__ import annotations
import argparse
from fractions import Fraction
import time
import traceback
from typing import Any
import numpy as np
from fixture import build, snapshot, installed_identity, save_result, START, COMPONENTS


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cells', type=int, choices=(2, 4), default=4)
    parser.add_argument('--profile', choices=('gradient', 'uniform'), default='gradient')
    args = parser.parse_args()
    started = time.monotonic()
    name = f'callback-{args.cells}-{args.profile}-result.json'
    result: dict[str, Any] = {'status': 'started', 'cells': args.cells, 'profile': args.profile}
    try:
        result['installed_before'] = installed_identity()
        operator, initial, initialization = build(args.cells, args.profile)
        result.update(initial=initial, initialization=initialization)
        save_result(name, result)
        assert all(check['within_enclosure'] for check in initialization['extensive_storage_checks'])
        observed = snapshot(operator, initial, START)
        result['snapshot'] = observed
        result['initial_temperature_checks'] = []
        result['child_energy_checks'] = []
        save_result(name, result)
        rates = observed['rates']
        assert rates.face_species_mol_s.shape == (args.cells+1, 5)
        assert rates.face_energy_w.shape == (args.cells+1,)
        assert np.all(rates.face_species_mol_s[[0, -1]] == 0) and np.all(rates.face_energy_w[[0, -1]] == 0)
        if args.profile == 'gradient':
            assert rates.face_species_mol_s[args.cells//2, 2] != 0
        else:
            assert np.all(rates.face_species_mol_s == 0) and np.all(rates.face_energy_w == 0)
        assert set(rates.cell_power_components_w) == COMPONENTS
        assert np.array_equal(rates.cell_power_w, observed['base_rates'].cell_power_w)
        children_per_parent = args.cells//2
        for index, cell in enumerate(observed['cells']):
            forward = initialization['child_forward'][index]
            parent = initialization['parent_forward'][index//children_per_parent]
            discrepancy = abs(Fraction(forward['total_energy_j'])-Fraction(float(initial.internal_energy_j[index])))
            source_bound = Fraction(forward['energy_error_bound_j'])+Fraction(parent['energy_error_bound_j'])/children_per_parent
            result['child_energy_checks'].append(dict(cell=index, discrepancy_j=discrepancy,
                source_numerical_enclosure_j=source_bound, within_enclosure=discrepancy <= source_bound))
            capacity = Fraction(forward['minimum_heat_capacity_j_k'])
            assert capacity > 0
            bound = Fraction(cell['inverse_temperature_error_k'])+(discrepancy+source_bound)/capacity
            difference = abs(Fraction(cell['thermal'].mechanical.temperature_k)-Fraction(initialization['inherited_temperatures_k'][index]))
            result['initial_temperature_checks'].append(dict(cell=index, absolute_difference_k=difference,
                inverse_source_reconstruction_bound_k=bound, within_bound=difference <= bound,
                qualification='conditional inverse plus source/initial reconstruction bound, not ODE error'))
            save_result(name, result)
            assert discrepancy <= source_bound and difference <= bound
            assert cell['reaction_binding_same_object'] and cell['current_storage_same_object'] and cell['thermal_inverse_reused']
            assert abs(cell['total_energy_residual_j']) <= 1e-6
            assert cell['inverse_temperature_error_k'] <= 1e-6
            row = rates.reaction_species_mol_s[index]
            assert row[0] < 0 and row[1] == -row[0]
            assert abs(row[1]-.2*2/args.cells) <= 1e-14
            assert row[2] == -row[3] == observed['transfers'][index].rate_mol_s > 0
            assert row[4] == 0
        result['status'] = 'passed'
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        try:
            result['installed_after'] = installed_identity()
        except BaseException as exc:
            result.update(status='failed', identity_error=str(exc))
        result['elapsed_s'] = time.monotonic()-started
        save_result(name, result)
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
