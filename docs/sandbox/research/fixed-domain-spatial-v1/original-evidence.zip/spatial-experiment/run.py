"""Bounded supervisor; callback/depletion execution requires explicit invocation."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

ROOT = Path('/Users/wanggaoying/Desktop/brickmodel-github')
HERE = Path(__file__).resolve().parent
PYTHON = Path('/private/tmp/brick-water-backend-probe/venv/bin/python')
PACKAGE = PYTHON.parent.parent/'lib/python3.12/site-packages/sludge_sandbox'


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('callback', 'wet'))
    parser.add_argument('--cells', type=int, choices=(2, 4), default=4)
    parser.add_argument('--profile', choices=('gradient', 'uniform'), default='gradient')
    parser.add_argument('attempt')
    parser.add_argument('--refinement', type=int, choices=(0, 1), default=0)
    args = parser.parse_args()
    if Path(args.attempt).name != args.attempt or args.attempt in ('.', '..'):
        parser.error('attempt must be a single directory name')
    result_name = (f'callback-{args.cells}-{args.profile}-result.json' if args.mode == 'callback'
                   else f'wet-{args.cells}-{args.profile}-{args.refinement}-result.json')
    if (HERE/result_name).exists():
        parser.error('Preserve existing result; use a separately reviewed experiment directory')
    supervisor_path = ROOT/'docs/sandbox/research/research-process-supervisor'
    sys.path.insert(0, str(supervisor_path))
    from supervisor import run_attempt
    command = ['/usr/bin/env', f'PYTHONPATH={ROOT}/tests/sandbox', 'PYTHONDONTWRITEBYTECODE=1', str(PYTHON)]
    if args.mode == 'callback':
        command.extend([str(HERE/'callback.py'), '--cells', str(args.cells), '--profile', args.profile])
        timeout = 30
    else:
        command.extend([str(HERE/'wet_run.py'), '--cells', str(args.cells), '--profile', args.profile, '--refinement', str(args.refinement)])
        timeout = 150
    inputs = (list(PACKAGE.glob('*.py'))+list((ROOT/'src/sludge_sandbox').glob('*.py'))
              +list((ROOT/'tests/sandbox').glob('*.py'))+list((ROOT/'data/sandbox/water').rglob('*'))
              +list(HERE.glob('*.py'))+[HERE/'PLAN.json', supervisor_path/'supervisor.py',
                Path('/private/tmp/brick-reacting-wet-two-cell-v1/callback-coupled-result.json')])
    if args.mode != 'callback':
        inputs.append(HERE/f'callback-{args.cells}-{args.profile}-result.json')
    result = run_attempt(HERE/args.attempt, command, cwd='/private/tmp',
                         input_paths=[path for path in inputs if path.is_file()], timeout_s=timeout)
    print(json.dumps({key: result[key] for key in ('status', 'returncode', 'elapsed_s', 'cleanup')}, indent=2))
    return 0 if result['status'] == 'complete' and result['returncode'] == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
