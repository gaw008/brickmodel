"""Bounded entirely wet trajectory; full original ledger saved before assertions."""
from __future__ import annotations
import argparse
import json
import time
import traceback
from typing import Any
import numpy as np
from sludge_sandbox.integration import integrate
from fixture import build, snapshot, installed_identity, save_result, encode, integration_policy, HERE, START, END


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cells', type=int, choices=(2, 4), default=4)
    parser.add_argument('--profile', choices=('gradient', 'uniform'), default='gradient')
    parser.add_argument('--refinement', type=int, choices=(0, 1), default=0)
    args = parser.parse_args()
    cells, profile, refinement = args.cells, args.profile, args.refinement
    name = f'wet-{cells}-{profile}-{refinement}-result.json'
    started = time.monotonic()
    result: dict[str, Any] = {'status': 'started', 'cells': cells, 'profile': profile, 'refinement': refinement}
    try:
        result['installed_before'] = installed_identity()
        operator, initial, initialization = build(cells, profile)
        result['initialization'] = initialization
        callback = json.loads((HERE/f'callback-{cells}-{profile}-result.json').read_text())
        assert callback['status'] == 'passed' and callback['cells'] == cells and callback['profile'] == profile
        assert encode(initial) == callback['initial']
        assert encode(initialization) == callback['initialization']
        assert encode(operator.base_model.energy_model_identity) == callback['snapshot']['energy_identity']
        policy = integration_policy(refinement)
        result.update(initial=initial, policy=policy)
        run = integrate(initial, operator, start_s=START, end_s=END, policy=policy)
        result['run'] = run
        save_result(name, result)
        assert run.status == 'completed', (run.status, run.reason)
        assert run.times_s[-1] == END
        assert all(np.all(state.amounts_mol[:, 3] > 0) for state in run.states)
        result['final_snapshot'] = snapshot(operator, run.states[-1], END)
        save_result(name, result)
        assert result['final_snapshot']['interfaces'] == ('existing_liquid',)*cells
        result['status'] = 'passed_pending_independent_ledger_audit'
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, reason=str(exc), traceback=traceback.format_exc())
    finally:
        try:
            result['installed_after'] = installed_identity()
        except BaseException as exc:
            result.update(status='failed', identity_error=str(exc))
        result['elapsed_s'] = time.monotonic()-started
        save_result(name, result)
    return 0 if result['status'] == 'passed_pending_independent_ledger_audit' else 1


if __name__ == '__main__':
    raise SystemExit(main())
