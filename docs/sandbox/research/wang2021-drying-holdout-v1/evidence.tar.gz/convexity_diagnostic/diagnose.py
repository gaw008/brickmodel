"""Posthoc envelope incompatibility witness, exact decimal-to-Fraction arithmetic.
No optimization, model prediction or experimental-confidence claim.
"""
import csv, hashlib, itertools, json
from fractions import Fraction as F
from pathlib import Path

ROOT=Path('/private/tmp/brick-wang-drying-holdout-v1')
SOURCE=Path('/Users/wanggaoying/Desktop/brickmodel-github/data/sandbox/research/wang_drying_digitized.csv')
EXPECTED='87ba4cccd037a530092720f9ba522eb0eb3710865be769aec5ef39b26e3743cd'
ALLOWANCE=F('0.000001')


def value(q):return {'fraction':str(q),'decimal_approximation':float(q)}

def witness(a,b,c):
    assert a['t']<b['t']<c['t']
    lam=(b['t']-a['t'])/(c['t']-a['t'])
    upper=(1-lam)*(a['y']+a['e'])+lam*(c['y']+c['e'])
    lower=b['y']-b['e']
    return lower-upper,lam,lower,upper


def scan(rows):
    triples=list(itertools.combinations(rows,3))
    if not triples:return {'triple_count':0,'positive_witness_count':0,'strongest':None}
    scored=[(witness(*t),t) for t in triples]
    (margin,lam,lo,hi),triple=max(scored,key=lambda x:x[0][0])
    points=[]
    for r in triple:
        points.append(dict(csv_line=r['line'],source_row=r['raw'],time_seconds=value(60*r['t']),
                           value=value(r['y']),readout_bound=value(r['e']-ALLOWANCE),
                           numerical_allowance=value(ALLOWANCE),lo=value(r['y']-r['e']),hi=value(r['y']+r['e'])))
    return dict(triple_count=len(triples),positive_witness_count=sum(x[0][0]>0 for x in scored),
                strongest=dict(points=points,lambda_right=value(lam),mid_lower=value(lo),
                               interpolated_upper=value(hi),positive_margin=value(margin),
                               incompatible=margin>0))


def tests():
    def r(t,y,e=F()):return dict(t=F(t),y=F(y),e=F(e))
    assert all(witness(*t)[0]<=0 for t in itertools.combinations([r(i,F(1,1+i)) for i in range(5)],3))
    assert witness(r(0,1),r(1,F(9,10)),r(2,0))[0]==F(2,5)
    assert witness(r(0,1),r(2,F(2,3)),r(6,0))[0]==0
    assert witness(r(0,1,F(1,2)),r(1,F(9,10),F(1,2)),r(2,0,F(1,2)))[0]<0
    return 'four exact synthetic controls passed'


def main():
    test_result=tests();before=SOURCE.read_bytes()
    assert hashlib.sha256(before).hexdigest()==EXPECTED
    binding=ROOT/'execution01/training/binding.json'
    assert json.loads(binding.read_text())['files'][str(SOURCE)]==EXPECTED
    groups={}
    for line,raw in enumerate(csv.DictReader(before.decode().splitlines()),2):
        key=(int(raw['temperature_C']),int(raw['relative_humidity_percent']))
        t,y,e=map(F,(raw['time_min'],raw['moisture_ratio'],raw['readout_bound_MR']))
        assert t>=0 and e>=0
        groups.setdefault(key,[]).append(dict(t=t,y=y,e=e+ALLOWANCE,line=line,raw=raw))
    results=[]
    for (temperature,rh),rows in sorted(groups.items()):
        rows.sort(key=lambda r:r['t']);assert len({r['t'] for r in rows})==len(rows)
        zeros=[r for r in rows if r['t']==0]
        assert len(zeros)==1 and zeros[0]['y']==1 and zeros[0]['raw']['method']=='initial_normalization_defined_by_source_eq2'
        results.append(dict(temperature_C=temperature,RH_percent=rh,
                            positive_time_only=scan([r for r in rows if r['t']>0]),
                            including_defined_t0=scan(rows)))
    assert SOURCE.read_bytes()==before
    output=dict(schema='posthoc_convex_MR_pixel_envelope_diagnostic_v1',source=str(SOURCE),source_sha256=EXPECTED,
                binding_sha256=hashlib.sha256(binding.read_bytes()).hexdigest(),
                script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),synthetic_tests=test_result,
                allowance=value(ALLOWANCE),qualification='Posthoc structure diagnosis; pixel readout envelope, experimental scatter unknown; no new holdout validation.',curves=results)
    Path(__file__).with_name('result.json').write_text(json.dumps(output,indent=2)+'\n')
    for r in results:
        print(r['temperature_C'],r['RH_percent'],*[f"{k}: count={r[k]['positive_witness_count']} margin={r[k]['strongest']['positive_margin']['decimal_approximation']:.9g}" for k in ('positive_time_only','including_defined_t0')])

if __name__=='__main__':main()
