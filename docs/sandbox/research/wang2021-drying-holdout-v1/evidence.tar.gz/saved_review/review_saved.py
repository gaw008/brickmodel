"""Saved observations/predictions audit: no fit, optimizer, EOS or model imports."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from collections import defaultdict
import csv,hashlib,json,math
R=Path(__file__).parent;E=R.parent/'execution01';C=R.parent/'candidate'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(value,message):
    if not value:raise AssertionError(message)
def fd(f):return D(f.numerator)/D(f.denominator)
freeze=read(E/'EXECUTION_FREEZE.json');current={p:sha(p) for p in freeze['files']}
require(len(current)==28 and current==freeze['files'],'28 frozen source files')
params=read(E/'training/parameters.json');training=read(E/'training/training.json');lock=read(E/'TRAINING_LOCK.json');report=read(E/'holdout/report.json');token=read(E/'training/HOLDOUT_UNLOCKED.json')
pinned='288564642ecee9f99c561b806493c2276a638569f2fbcbc0d3f3a0a44efb03fd'
require(sha(E/'training/parameters.json')==pinned==lock['parameters_sha256']==report['parameters_sha256']==token['parameters_sha256'],'frozen parameter chain')
require(lock['source_and_code_unchanged'] and lock['holdout_not_yet_unlocked'],'saved prerelease lock')
require(token['output']==str(E/'holdout'),'single training-parent unlock target')
require(report['status']=='evaluated' and all(report[k] is True for k in ('holdout_values_parsed','holdout_access_started','holdout_parse_complete')),'completed access status')
require(report['parameters']==params['parameters'],'no post-holdout parameter changes')
require(params['training_report_sha256']==sha(E/'training/training.json') and params['training_metrics_sha256']==sha(E/'training/training-metrics.json'),'training output lock')
require(read(E/'training/binding.json')==params['binding'],'original training binding')
for p,h in params['binding']['files'].items():require(sha(p)==h==freeze['files'][p],'training bound source')
require(params['training_temperatures']==[40,60] and params['holdout_temperature']==50 and training['holdout_values_parsed'] is False,'original split')
phases={}
for phase in ('training','holdout'):
    s=read(E/(phase+'-supervisor.json'));command=read(E/(phase+'-started.json'))['command']
    require(s['returncode']==0 and not s['external_timeout'] and s['child_reaped'] and s['elapsed_seconds']<s['external_limit_seconds']==135,'phase reaped within external budget')
    require(command[0]==freeze['runtime']['executable'],'actual interpreter')
    require(command[1]==str(C/('train.py' if phase=='training' else 'holdout.py')),'actual phase script')
    if phase=='holdout':require(command[command.index('--parameters-sha256')+1]==pinned,'external preholdout parameter pin')
    phases[phase]=s
require(training['status']=='training_complete' and training['elapsed_seconds']<120 and report['elapsed_seconds']<120,'original internal phase budget')
require(training['policy']=={'maximum_total_wall_s':120,'max_nfev_per_start':200,'xtol':1e-9,'ftol':1e-9,'gtol':1e-9,'near_best_objective_absolute':1e-8,'bound_scaled_distance':1e-6},'registered optimizer policy')
starts=training['starts'];expected=[(d,k,40000.) for d in (1e-10,1e-9,1e-8) for k in (1e-7,1e-6,1e-5)]
require(len(starts)==9,'all nine starts retained')
for i,(s,start) in enumerate(zip(starts,expected,strict=True)):
    require(s['index']==i and s['initial']==list(start) and s['status']=='converged','fixed starts and complete outcomes')
    require(s['nfev']<=200 and s['residual_calls_attempted']==s['residual_calls_completed']==s['nfev']+3*s['njev'],'actual residual counters include Jacobian calls')
    require(1e-12<=s['parameters']['dref']<=1e-7 and 1e-10<=s['parameters']['kref']<=1e-4 and 0<=s['parameters']['ea']<=150000,'original search bounds')
best=min(starts,key=lambda s:(s['objective'],s['index']))
require(best['index']==training['selected_start']==params['selected_start']==2 and best['parameters']==params['parameters'] and best['objective']==params['objective'],'minimum training objective fixed index')
require(training['near_best']==[s for s in starts if s['objective']<=best['objective']+1e-8],'registered nearbest set')
require(best['near_search_boundary'] and abs(params['parameters']['ea']-150000)<1e-6,'Ea upper boundary recorded')
csvpath=next(Path(p) for p in freeze['files'] if p.endswith('wang_drying_digitized.csv'))
with csvpath.open(newline='') as stream:original=list(csv.DictReader(stream))
lookup={};excluded=[]
for line,row in enumerate(original,2):
    key=(int(row['temperature_C']),int(row['relative_humidity_percent']),F(row['time_min']))
    require(key not in lookup,'unique original source rows');lookup[key]=(line,row)
    if key[2]==0:excluded.append(key)
require(len(excluded)==12,'t0 excluded once each condition')
metric_differences=[]
def check_metric(saved,exact,label):
    discrepancy=abs(D.from_float(saved)-exact);metric_differences.append(discrepancy)
    require(discrepancy<D('1e-14'),'binary64 summary rounding '+label)
def statistics(rows):
    residual=[F(p['prediction'])-F(p['observed']) for p in rows];n=len(rows)
    return {'n':n,'rmse':fd(sum((r*r for r in residual),F())/n).sqrt(),'mae':fd(sum(map(abs,residual),F())/n),'max_abs':fd(max(map(abs,residual))),'bias':fd(sum(residual,F())/n),'outside_readout_count':sum(abs(r)>F(p['readout_bound']) for r,p in zip(residual,rows,strict=True)),'outside_readout_plus_numeric_count':sum(abs(r)>F(p['readout_bound'])+F(1e-6) for r,p in zip(residual,rows,strict=True))}
outputs={};training_objective=F()
with localcontext() as context:
    context.prec=80
    for phase,temps,count in [('training',(40,60),117),('holdout',(50,),57)]:
        saved=read(E/phase/(phase+'-metrics.json'));points=saved['points'];expected={key for key in lookup if key[0] in temps and key[2]>0};seen=set();groups=defaultdict(list);source_rows=[]
        require(len(points)==count==len(expected),'full selected point count')
        for point in points:
            key=(point['temperature_C'],point['relative_humidity_percent'],F(point['time_min']));require(key in expected and key not in seen,'selected unique point');seen.add(key)
            line,row=lookup[key];source_rows.append(line)
            for field,raw in row.items():require(point[field]==(int(raw) if field in ('temperature_C','relative_humidity_percent') else raw),'original source column '+field)
            require(F(point['time_s'])==F(row['time_min'])*60 and point['observed']==float(row['moisture_ratio']) and point['readout_bound']==float(row['readout_bound_MR']),'minutes/seconds and actual observation')
            require(math.isfinite(point['prediction']),'finite saved prediction')
            raw_residual=point['prediction']-point['observed'];require(point['residual']==raw_residual,'literal residual')
            require(point['outside_readout_bound']==max(0.,abs(raw_residual)-point['readout_bound']) and point['outside_readout_plus_numeric']==max(0.,abs(raw_residual)-point['readout_bound']-1e-6),'literal readout diagnostics')
            groups[key[:2]].append(point)
        require(seen==expected,'no omitted source row')
        condition_reports=[]
        require(len(saved['conditions'])==len(groups),'full condition metrics')
        for condition in saved['conditions']:
            key=(condition['temperature_C'],condition['rh_percent']);rows=groups[key];stats=statistics(rows)
            require(condition['n']==stats['n'],'condition count')
            for metric in ('rmse','mae','max_abs','bias'):check_metric(condition[metric],stats[metric],str(key)+metric)
            require(0<=condition['independent_max_abs_delta']<=1e-6,'saved MP discrepancy allowance')
            if phase=='training':training_objective+=sum(((F(p['prediction'])-F(p['observed']))**2 for p in rows),F())/(8*len(rows))
            condition_reports.append({'temperature_C':key[0],'rh_percent':key[1],**{k:(str(v) if isinstance(v,D) else v) for k,v in stats.items()},'saved_MP_max_difference':condition['independent_max_abs_delta']})
        total=statistics(points)
        for metric in ('rmse','mae','max_abs','bias'):check_metric(saved['overall'][metric],total[metric],phase+metric)
        require(saved['overall']['n']==total['n'] and saved['overall']['all_points_within_readout_plus_numeric']==(total['outside_readout_plus_numeric_count']==0),'overall descriptive status')
        outputs[phase]={'overall':{k:(str(v) if isinstance(v,D) else v) for k,v in total.items()},'conditions':condition_reports,'source_line_numbers':source_rows}
    check_metric(params['objective'],fd(training_objective),'equal-curve train objective')
result={'status':'PASS_saved_accounting_not_model_validation','frozen_files':28,'parameter_sha256':pinned,'selected_start':2,'equal_curve_training_objective_exact':str(training_objective),'equal_curve_training_objective':float(training_objective),'residual_calls_attempted':sum(s['residual_calls_attempted'] for s in starts),'residual_calls_completed':sum(s['residual_calls_completed'] for s in starts),'nfev_total':sum(s['nfev'] for s in starts),'njev_total':sum(s['njev'] for s in starts),'excluded_t0_rows':len(excluded),'max_summary_decimal_discrepancy':str(max(metric_differences)),'phases':phases,'metrics':outputs,'fit_or_EOS_calls':0,'limitations':'Saved counters and launch/lock chain inspected, not independently re-executed fit or a cryptographic proof of no other access. Saved MP maxima reviewed, not raw MP vectors or fresh oracle. Readout bounds are not confidence intervals; Ea at search upper boundary is an effective constrained fit, not intrinsic measured parameter.'}
with (R/'RESULT.json').open('x') as stream:json.dump(result,stream,indent=2)
print(json.dumps(result,indent=2))
