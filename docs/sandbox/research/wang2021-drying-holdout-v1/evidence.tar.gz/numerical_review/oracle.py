"""Independent manufactured-input modal/FV cross-check; no experimental files.
Double precision checks are not rigorous interval error certificates.
"""
import json, math
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
from scipy.linalg import eigh_tridiagonal


def modal(bi, fo, modes=64):
    values=[]
    for n in range(modes):
        # Shifted sine/cosine residual has no tangent pole.
        base=n*math.pi
        f=lambda d:(base+d)*math.sin(d)-bi*math.cos(d)
        d=brentq(f,0.,math.pi/2,xtol=5e-324,rtol=4*np.finfo(float).eps)
        mu=base+d
        # Positive coefficient; use shifted sin(d) rather than sin(n*pi+d).
        a=4*math.sin(d)**2/(mu*(2*mu+math.sin(2*d)))
        values.append(a*math.exp(-mu*mu*fo))
    tail=4/(math.pi**2*(modes-1))*math.exp(-(modes*math.pi)**2*fo)
    return math.fsum(values),tail


def fv(bi, fo, cells):
    h=1/cells
    # Cell-centred flux, includes half-cell diffusion resistance to Robin face.
    g=bi/(1+bi*h/2)
    diag=np.full(cells,-2/h**2);diag[0]=-1/h**2;diag[-1]=-1/h**2-g/h
    off=np.full(cells-1,1/h**2)
    lam,q=eigh_tridiagonal(diag,off)
    weights=q.sum(axis=0)**2/cells
    mr=float(weights @ np.exp(lam*fo))
    # Discrete telescoping exactly gives d(mean)/dFo=-g*u_last.
    colsum=diag.copy();colsum[:-1]+=off;colsum[1:]+=off
    assert np.all(colsum[:-1]==0) and abs(colsum[-1]+g/h)<1e-9
    assert lam[-1]<0 and abs(weights.sum()-1)<1e-12
    return mr


def main():
    rows=[]
    for bi in (1e-6,1.,1e6):
        for fo in (.01,.1,1.):
            exact,tail=modal(bi,fo)
            approx=[fv(bi,fo,n) for n in (256,512,1024,2048)]
            errors=[abs(v-exact) for v in approx]
            assert 0<exact<1 and tail<1e-6
            # Semidiscrete eigenproblem rounding dominates tiny-Bi finest differences.
            assert errors[-1]<1e-6
            if errors[0]>1e-8:assert errors[-1]<errors[0]/20
            rows.append(dict(Bi=bi,Fo=fo,modal=exact,tail_bound=tail,
                             grids=[256,512,1024,2048],fv=approx,absolute_differences=errors))
    out=dict(scope='manufactured dimensionless inputs only; no fit or experimental curve reads',
             numerical_precision='float64, independent consistency not rigorous certification',cases=rows)
    Path(__file__).with_name('oracle-results.json').write_text(json.dumps(out,indent=2)+'\n')
    print('9 manufactured cases passed; max finest discrepancy',max(x['absolute_differences'][-1] for x in rows))

if __name__=='__main__':main()
