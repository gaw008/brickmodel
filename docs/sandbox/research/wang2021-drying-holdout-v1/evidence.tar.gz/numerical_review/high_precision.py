"""Manufactured-only root/coefficient check, independent bracket bisection."""
import json
from pathlib import Path
import mpmath as mp
from oracle import modal
mp.mp.dps=65
rows=[]
for text in ('0.000001','1','1000000'):
    bi=mp.mpf(text);fo=mp.mpf('.01');total=mp.mpf(0)
    for n in range(32):
        lo=mp.mpf(0);hi=mp.pi/2;base=n*mp.pi
        for _ in range(190):
            mid=(lo+hi)/2
            if (base+mid)*mp.sin(mid)-bi*mp.cos(mid)>0:hi=mid
            else:lo=mid
        mu=base+(lo+hi)/2
        a=(mp.sin(mu)/mu)**2/(mp.mpf('.5')+mp.sin(2*mu)/(4*mu))
        total+=a*mp.exp(-mu*mu*fo)
    tail=4/(mp.pi**2*31)*mp.exp(-(32*mp.pi)**2*fo)
    value,_=modal(float(bi),float(fo))
    difference=abs(mp.mpf(value)-total)
    assert tail<mp.mpf('1e-40') and difference<mp.mpf('1e-13')
    rows.append({'Bi':text,'Fo':str(fo),'modal_65digits':str(total),'tail':str(tail),'float_difference':str(difference)})
Path(__file__).with_name('high-precision-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('3 artificial parameter cases passed; no experimental files accessed')
