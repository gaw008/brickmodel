# D1 candidate, not fitted

Only synthetic numerical validation has run. No dataset fit, holdout prediction,50°C CSV value access, source CSV mutation, repository edit or installation by the author. The first test collection failed because mpmath was absent; that log is preserved. Root installed the dependency before the successful pure tests.

Model: L=.002m, bottom reflecting, top Robin, uniform unit initial condition. Dref/kref/Ea and all fixed source label/unit conventions follow PREREGISTRATION_DRAFT. Positive time modal roots are bracketed in original branches using continuous mu*sin(mu)−Bi*cos(mu), scipy brentq max100 iterations, xtol5e-15/rtol4eps. Exactt0 returns1, not normalized truncated weights. The conservative positive-mode tail target1e-9 has max512 modes; inability to prove it fails explicitly. This bound covers omitted modes only.

Independent80-digit reference uses110 bisections per original branch, tail1e-12 and up to1024 modes. It separately reconstructs coefficients and is called after training selection for all eight training conditions and after holdout unlock for all four heldout conditions. Each actual prediction must differ by at most1e-6MR before its numeric comparison is accepted. This is a pointwise independent numerical cross-check, not a universal floating-point error theorem. Synthetic finite-volume checks use bottom no-flow and the exact top half-cell+film resistances in series,32/64/128/256 spatial cells; the cell mean converges to the modal average. Both checks are required evidence for the1e-6 numerical allowance, distinct from readout or experimental errors.

Formal scripts are standalone local imports, no production package is changed. Dependencies numpy/scipy/mpmath are recorded alongside Python version and all five implementation file hashes. Parameter endpoint conversion maps exact optimizer log-bound coordinates to their exact declared physical bound, avoiding roundoff just outside the search box; it does not clip general inputs.

Stage1 (root only, after review/freeze):

    python train.py --csv /absolute/wang_drying_digitized.csv --prereg /absolute/PREREGISTRATION_DRAFT.md --output /new/training

The raw CSV is hashed opaquely. Its temperature prefix is filtered before MR fields are parsed; only40/60 values enter training. All selected t>0 observations remain;117 rows/eight curves required. Residual scaling1/sqrt(8*n_curve) implements the equal-curve MSE exactly. Nine fixed D/k starts with Ea40000, bounds and scaled coordinates,200max_nfev per start,1e-9 optimizer tolerances,120s cumulative wall. Actual residual call attempts/completions include finite-difference calls separately from scipy nfev; every start is saved before execution and updated after failure. Source change, numeric verification failure, timeout or absence of a converged start prevents parameters.json creation. Converged starts are ranked only by training objective then fixed start index. Reports retain nonconverged/failed starts, active bounds, Jacobian singular values and all near-best parameters.

Near-best means converged training objective within1e-8 absolute MSE of best; near-boundary means optimizer-coordinate distance<=1e-6. These are explicit diagnostic thresholds, not physical acceptance gates or statistical confidence. They are fixed here before any fit and must not be tuned on holdout. A flat/ill-conditioned fit does not establish unique intrinsic material parameters. The training-only high-precision verification occurs before the immutable parameter file is written, with no alternative parameter chosen if it fails.

Stage2 (root only, after retaining the parameter digest):

    python holdout.py --training /training --parameters-sha256 DIGEST --csv /same/original.csv --output /new/holdout

This checks all bindings and training output hashes first. It creates an exclusive HOLDOUT_UNLOCKED.json token inside the training directory before any50°C MR parsing; a different output directory cannot bypass single-use. Any failed unlocked attempt remains consumed, not silently retried. It then evaluates the57 nonzero-time points at exactly frozen parameters with independent high-precision checks. No optimization or parameter mutation occurs. A separately declared120s holdout-only wall limit bounds evaluation; it is not an additional training budget.

Per point preserve original source row,MR/readout bound,prediction/signed residual and excess over both raw readout and readout+1e-6 numerical allowance. Per curve/overall preserve RMSE,MAE,maxabsolute andbias. The all-points readout-plus-numeric criterion is descriptive under the declared numerical cross-check, never an experimental confidence statement. Weak identifiability, no internal heat equation, no shrinkage/adsorption/steel thermal capacity and source-specific effective labels remain the original limitations.

Neither script is an immutable security boundary against arbitrary user edits; its purpose is explicit local two-stage scientific workflow with externally pinned parameter/source bytes. Final source review and root registration precede actual execution. No fitted output or observed50°C value is included in this candidate.

## Tail representation and partial access evidence correction

The original numerical values/root counts are unchanged. A positive-time tail that underflows to binary64 zero is now stored as the least positive float, with the finite logarithmic bound and an explicit tail_underflow flag; t0/no modes alone retain zero tail. This is a conservative representation of an underflowed positive tail, not a new claim about total machine error. Per-condition reports retain the log and flag.

Holdout reports set holdout_access_started before entering the loader, set the legacy holdout_values_parsed flag to null while access is incomplete or unknown, then true only when the loader returns, and set holdout_parse_complete only after a successful full loader return. Partial parsing failure can no longer claim the heldout values were untouched. The single-use token is still consumed before access and cannot be retried with another output directory.
