import math
from pathlib import Path
import numpy as np
import pytest
from scipy.linalg import eigh_tridiagonal
from wang_d1 import Parameters,mean_curve,coefficients,L
from independent_check import reference_curve
from study_io import load_curves


@pytest.mark.parametrize('p,t,h',[(Parameters(1e-7,1e-10,150000),60,.6),(Parameters(1e-12,1e-4,150000),40,.3),(Parameters(1e-9,1e-6,40000),40,.3),(Parameters(1e-9,1e-6,40000),60,.6)])
def test_independent_high_precision_extremes(p,t,h):
    times=[0.,600.,3600.,16000.]
    actual,diag=mean_curve(p,t,h,times)
    ref=reference_curve(p,t,h,times)
    assert np.max(np.abs(actual-ref))<1e-6
    assert actual[0]==1 and diag['tail_bound']<=1e-9
    assert np.all(np.diff(actual)<=0)
    assert 0<=actual[-1]<=actual[1]<=1


def fv(p,t,h,times,cells):
    d,k=coefficients(p,t,h);dx=L/cells;a=d/dx**2
    diagonal=np.full(cells,-2*a);diagonal[0]=-a
    # Surface half-cell diffusion and film resistances in series.
    diagonal[-1]=-a-1/(dx/(2*d)+1/k)/dx
    eig,vec=eigh_tridiagonal(diagonal,np.full(cells-1,a))
    amplitudes=np.sum(vec,axis=0)**2/cells
    return np.array([np.sum(amplitudes*np.exp(eig*time)) for time in times])


@pytest.mark.parametrize('k',(1e-8,1e-6,1e-4))
def test_independent_fv_refinement_boundary_average(k):
    p=Parameters(1e-9,k,40000);times=[600.,1200.,3600.]
    modal,_=mean_curve(p,40,.4,times)
    errors=[max(abs(fv(p,40,.4,times,n)-modal)) for n in (32,64,128,256)]
    assert all(b<a for a,b in zip(errors,errors[1:])),errors
    assert errors[-1]<1e-5


def test_initial_identity_no_renormalization_and_tail_refusal():
    p=Parameters(1e-12,1e-4,150000)
    a,diag=mean_curve(p,40,.3,[0.]);assert a.tolist()==[1.] and diag['modes']==0
    with pytest.raises(ValueError,match='512'):mean_curve(p,40,.3,[1e-20])


@pytest.mark.parametrize('bad',(True,float('nan'),float('inf'),-1))
def test_invalid_time_rejected(bad):
    with pytest.raises(ValueError):mean_curve(Parameters(1e-9,1e-6,40000),40,.3,[bad])


def test_split_never_parses_other_temperature_mr(tmp_path):
    # Synthetic fixture only. Invalid50 values must not affect training loader.
    f=tmp_path/'synthetic.csv';lines=['temperature_C,relative_humidity_percent,time_min,moisture_ratio,readout_bound_MR']
    for t in (40,50,60):
        for rh in (30,40,50,60):
            lines.append(f'{t},{rh},10,'+('FORBIDDEN_VALUE' if t==50 else '.7')+',.01')
    f.write_text('\n'.join(lines)+'\n')
    assert len(load_curves(f,(40,60)))==8
    with pytest.raises(ValueError):load_curves(f,(50,))


def test_guard_can_stop_root_work():
    def guard():raise TimeoutError('stop')
    with pytest.raises(TimeoutError):mean_curve(Parameters(1e-9,1e-6,40000),40,.4,[600],guard=guard)


def test_log_parameter_boundaries_are_exact_declared_endpoints():
    from train import parameters,LOWER,UPPER
    assert parameters(LOWER)==Parameters(1e-12,1e-10,0.)
    assert parameters(UPPER)==Parameters(1e-7,1e-4,150000.)


@pytest.mark.parametrize('bad',(True,10**1000,float('nan')))
def test_invalid_parameters_fail_cleanly(bad):
    with pytest.raises(ValueError):Parameters(bad,1e-6,40000)


def test_tail_underflow_keeps_positive_representation_and_log():
    a,info=mean_curve(Parameters(1e-7,1e-4,150000),60,.3,[16000.])
    assert info['tail_bound']==math.nextafter(0.,math.inf)
    assert info['tail_underflow'] is True
    assert math.isfinite(info['log_tail_bound']) and info['log_tail_bound']<math.log(info['tail_bound'])


@pytest.mark.parametrize('first_value_read',(False,True))
def test_holdout_failed_access_is_unknown_and_token_consumed(tmp_path,monkeypatch,first_value_read):
    import sys,json
    import holdout
    from study_io import binding,save,sha
    csv=tmp_path/'manufactured.csv';csv.write_text('synthetic fixture only; no experiment values')
    prereg=tmp_path/'plan';prereg.write_text('synthetic')
    parent=tmp_path/'training';parent.mkdir()
    save(parent/'training.json',{});save(parent/'training-metrics.json',{})
    save(parent/'parameters.json',dict(schema='wang_d1_training_parameters_v1',training_temperatures=[40,60],holdout_temperature=50,binding=binding(csv,prereg),training_report_sha256=sha(parent/'training.json'),training_metrics_sha256=sha(parent/'training-metrics.json'),parameters=dict(dref=1e-9,kref=1e-6,ea=40000.)))
    accessed=[]
    def failing_loader(*args):
        if first_value_read:accessed.append(float('.7'))
        raise ValueError('synthetic parse failure')
    monkeypatch.setattr(holdout,'load_curves',failing_loader)
    output=tmp_path/'output'
    monkeypatch.setattr(sys,'argv',['holdout.py','--training',str(parent),'--parameters-sha256',sha(parent/'parameters.json'),'--csv',str(csv),'--output',str(output)])
    assert holdout.main()==1
    result=json.loads((output/'report.json').read_text())
    assert result['holdout_access_started'] is True
    assert result['holdout_values_parsed'] is None
    assert result['holdout_parse_complete'] is False
    assert (parent/'HOLDOUT_UNLOCKED.json').exists()
    assert bool(accessed)==first_value_read
