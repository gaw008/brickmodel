"""Synthetic-only numerical evidence; never opens a dataset."""
from pathlib import Path
import json
import numpy as np
from wang_d1 import Parameters,mean_curve
from independent_check import reference_curve
from test_wang_d1 import fv
rows=[]
for p,t,h in ((Parameters(1e-7,1e-10,150000),60,.6),(Parameters(1e-12,1e-4,150000),40,.3),(Parameters(1e-9,1e-6,40000),40,.3),(Parameters(1e-9,1e-6,40000),60,.6)):
 a,info=mean_curve(p,t,h,[0.,600.,3600.,16000.]);b=reference_curve(p,t,h,[0.,600.,3600.,16000.]);delta=float(max(abs(a-b)));assert delta<=1e-6
 rows.append({'parameters':vars(p),'temperature_c':t,'rh':h,'max_abs_high_precision_difference':delta,'modes':info['modes'],'tail_bound':info['tail_bound']})
fvrows=[]
for k in (1e-8,1e-6,1e-4):
 p=Parameters(1e-9,k,40000);times=[600.,1200.,3600.];a,_=mean_curve(p,40,.4,times)
 errors=[float(max(abs(fv(p,40,.4,times,n)-a))) for n in (32,64,128,256)]
 assert all(b<a for a,b in zip(errors,errors[1:])) and errors[-1]<1e-5
 fvrows.append({'kref':k,'cells':[32,64,128,256],'max_abs_errors':errors})
Path(__file__).with_name('NUMERICAL_CHECK.json').write_text(json.dumps({'status':'passed_synthetic_only','high_precision':rows,'finite_volume':fvrows,'qualification':'posterior sample checks, not a universal machine-error theorem','real_dataset_opened':False},indent=2)+'\n')
