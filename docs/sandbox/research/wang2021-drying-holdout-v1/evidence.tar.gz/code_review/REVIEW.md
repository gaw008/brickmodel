# Independent D1 implementation review (before any real fit)

Scope: the frozen standalone candidate only. Read HANDOFF, original preregistration, source and mathematical reviews, and all five executable implementation files plus tests. Inspected repository diff scope; unrelated ongoing controller edits are not reviewed or modified here. No actual experimental CSV, Midilli coefficients, 50°C observations, optimizer fit, actual prediction, source mutation or installation was performed. All negative controls below use manufactured values and do not execute least_squares.

## Confirmed findings

[MEDIUM] Positive mathematical tail is recorded as exact zero after machine underflow
File: candidate/wang_d1.py:88 (also selection expression at68)
Issue: With valid artificial parameters Dref=1e-7, kref=1e-4, Ea=150000, T=60°C, RH=.3 and t=16000s, mean_curve returns modes=2 and tail_bound=0.0. Every omitted term of this finite-Bi positive-time modal series is strictly positive. The field is documented as mathematical omitted-mode bound, so zero is not a valid bound. The independent mathematical review explicitly requested that exp underflow not be called zero. This does not indicate a practically significant MR discrepancy or failure of the1e-6 numerical target; it is an incorrect reported mathematical certificate.
Fix: Compare a logarithmic tail expression to the fixed target and preserve a conservative positive representation/bound when exponentiation underflows; distinguish an analytic zero-time identity from a positive-time underflow. Retain the original target and mode cap.
Evidence: test_independent.py::test_positive_finite_time_tail_is_not_exact_zero, RED output in negative-controls-RED.log.

[MEDIUM] Partially accessed holdout can be falsely reported as unparsed
File: candidate/holdout.py:30
Issue: holdout_values_parsed becomes true only after load_curves returns. A manufactured first50°C row with valid MR followed by an invalid second MR causes the first value to be parsed, then the report records holdout_values_parsed=false. The exclusive token is correctly retained, so this does not bypass the one-shot guard. It does make the saved access history misleading in precisely the failed-unlock case that must remain consumed.
Fix: Explicitly save unlock/access-start state before entering the loader and independently track completed parsing, or retain progressive row-access counters. A failed partial read must never claim the observations remained unaccessed. Preserve the consumed token and failure details.
Evidence: test_independent.py::test_partial_holdout_parse_is_not_reported_as_unaccessed, RED output in negative-controls-RED.log. Fake training artifacts are explicitly marked manufactured; no real fit was run.

## Checks with no confirmed finding

The2mm value is full slab thickness. Robin eigenvalue intervals, positive spatial-average coefficients, Arrhenius units, RH fraction, min-to-sec conversion, exact t0 return, and explicit512-mode refusal match the registered finite model. Tests compare several extreme synthetic inputs to independent MP and FV. The MP implementation uses independent bisection and high precision but is a consistency check, not an interval proof or experimental uncertainty.

Training filters the raw temperature prefix before parsing unselected MR, keeps positive-time rows, requires8 curves/117 observations, uses equal per-curve MSE via residual scaling1/sqrt(8*n), nine fixed starts, fixed bounded coordinates and max_nfev200. Residual attempted/completed counters include finite-difference calls separately from scipy nfev. A cumulative120s cooperative deadline is used throughout optimization and final numerical checks; this is not an external hard process-kill mechanism. Caller should preserve actual process exit and supervise wall time if enforcing a hard operational deadline. Converged starts are selected using only training objective/index. Final selected predictions receive MP check before the parameter artifact. Source hashes and package version labels are retained; the scripts disclaim adversarial immutable-runtime security.

Holdout checks external parameter SHA and original binding before its exclusive unlock token. Parameters are never optimized in stage2. The token lives in the training directory and remains after a failed unlocked attempt. Metrics retain source rows, signed residuals, raw readout bounds, per-condition/overall RMSE/MAE/max/bias and excess bounds; they do not reinterpret pixel bounds as experimental sigma or claim intrinsic material admission.

The HANDOFF's near-best1e-8 MSE and boundary-coordinate1e-6 are diagnostic thresholds only; root must finish their preregistration before any actual fit, as already planned. Numerical wall budgets and failure accounting are not statistical validation. Unknown material, heat, shrinkage and adsorption remain excluded explicitly rather than invented.

## Executed evidence

Candidate18pure tests:18 passed in0.90s, process exit0. Independent2 manufactured negative controls:2 failed in0.28s, expected RED, original detailed output retained. No real CSV was opened. The shell wrapper used to print RED output returned0 after cat; the pytest output itself records the2 failing tests. Frozen file membership and SHA are independently verified in freeze-check.json; all10 entries match after review.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL |0|pass|
| HIGH |0|pass|
| MEDIUM |2|info|
| LOW |0|pass|

Verdict: No HIGH/CRITICAL found. Resolve these two reproducible evidence-integrity issues before freezing the actual scientific run. No real-material or full-Goal qualification is granted.
