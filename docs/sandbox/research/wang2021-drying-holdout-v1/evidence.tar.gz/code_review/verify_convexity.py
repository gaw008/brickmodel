"""Independent read-only saved-result audit, no solver or fitting imports."""
from pathlib import Path
from fractions import Fraction as F
import csv,json,hashlib,itertools,importlib.util
base=Path('/private/tmp/brick-wang-drying-holdout-v1')
diag=base/'convexity_diagnostic'
r=json.loads((diag/'result.json').read_text());source=Path(r['source']);raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()==r['source_sha256']
assert hashlib.sha256((diag/'diagnose.py').read_bytes()).hexdigest()==r['script_sha256']
assert hashlib.sha256((base/'execution01/training/binding.json').read_bytes()).hexdigest()==r['binding_sha256']
# Each physical source line is one complete CSV record; verify actual locators.
lines=raw.decode().splitlines();header=next(csv.reader([lines[0]]));groups={}
for lineno,line in enumerate(lines[1:],2):
 row=dict(zip(header,next(csv.reader([line])),strict=True));key=(int(row['temperature_C']),int(row['relative_humidity_percent']))
 groups.setdefault(key,[]).append((F(row['time_min']),F(row['moisture_ratio']),F(row['readout_bound_MR'])+F(1,1000000),lineno,row))
summary=[]
for curve in r['curves']:
 key=(curve['temperature_C'],curve['RH_percent']);rows=sorted(groups[key]);zeros=[x for x in rows if x[0]==0]
 assert len(zeros)==1 and zeros[0][1]==1 and zeros[0][4]['method']=='initial_normalization_defined_by_source_eq2'
 for mode in ('positive_time_only','including_defined_t0'):
  selected=[x for x in rows if mode=='including_defined_t0' or x[0]>0]
  margins=[]
  for a,b,c in itertools.combinations(selected,3):
   # Cross-multiply convexity against unequal time spacings, separately from author lambda expression.
   margin=((c[0]-a[0])*(b[1]-b[2])-(c[0]-b[0])*(a[1]+a[2])-(b[0]-a[0])*(c[1]+c[2]))/(c[0]-a[0])
   margins.append(margin)
  saved=curve[mode];assert len(margins)==saved['triple_count'];assert sum(x>0 for x in margins)==saved['positive_witness_count'];assert max(margins)==F(saved['strongest']['positive_margin']['fraction'])
  for point in saved['strongest']['points']:
   actual=dict(zip(header,next(csv.reader([lines[point['csv_line']-1]])),strict=True));assert actual==point['source_row'];assert F(point['time_seconds']['fraction'])==60*F(actual['time_min'])
  summary.append(dict(condition=key,mode=mode,triples=len(margins),positive=sum(x>0 for x in margins)))
w=next(x for x in r['curves'] if (x['temperature_C'],x['RH_percent'])==(40,60))['including_defined_t0']['strongest']
assert [p['csv_line'] for p in w['points']]==[127,129,137]
assert F(w['lambda_right']['fraction'])==F(1,5)
assert F(w['mid_lower']['fraction'])==F('0.913845')
assert F(w['interpolated_upper']['fraction'])==F('0.9092318')
assert F(w['positive_margin']['fraction'])==F(11533,2500000)
assert sum(s['triples'] for s in summary if s['mode']=='positive_time_only')==7824
assert sum(s['triples'] for s in summary if s['mode']=='including_defined_t0')==9189
assert [(s['condition'],s['positive']) for s in summary if s['positive']]==[((40,60),27)]
spec=importlib.util.spec_from_file_location('diagnostic_readonly',diag/'diagnose.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);assert module.tests()=='four exact synthetic controls passed'
assert source.read_bytes()==raw
out={'status':'pass','no_fit_no_prediction_no_eos':True,'independent_cross_multiplied_triples':17013,'author_synthetic_controls':4,'witness_lines':[127,129,137],'exact_margin':'11533/2500000','source_sha256':r['source_sha256'],'script_sha256':r['script_sha256'],'result_sha256':hashlib.sha256((diag/'result.json').read_bytes()).hexdigest(),'summary':summary}
(base/'code_review/CONVEXITY_CHECK.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='summary'}))
