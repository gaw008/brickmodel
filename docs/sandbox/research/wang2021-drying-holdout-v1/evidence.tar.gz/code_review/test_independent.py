"""Only manufactured observations; no source experiment read or fit."""
import hashlib
import json
from pathlib import Path
import sys
import pytest
sys.path.insert(0, '/private/tmp/brick-wang-drying-holdout-v1/candidate')
from wang_d1 import Parameters, mean_curve
from study_io import binding, save, sha
import holdout


def test_positive_finite_time_tail_is_not_exact_zero():
    _, info = mean_curve(Parameters(1e-7, 1e-4, 150000.), 60, .3, [16000.])
    assert info['modes'] == 2
    # Every omitted positive coefficient/exponential is mathematically positive.
    assert info['tail_bound'] > 0, info


def test_partial_holdout_parse_is_not_reported_as_unaccessed(tmp_path, monkeypatch):
    csv = tmp_path / 'manufactured.csv'
    csv.write_text('temperature_C,relative_humidity_percent,time_min,moisture_ratio,readout_bound_MR\n50,30,10,.7,.01\n50,30,20,INVALID_AFTER_FIRST_VALUE,.01\n')
    prereg = tmp_path / 'prereg.md'; prereg.write_text('manufactured workflow negative; not actual registered execution')
    parent = tmp_path / 'training'; parent.mkdir()
    save(parent/'training.json', {'status':'manufactured_not_a_fit'})
    save(parent/'training-metrics.json', {'status':'manufactured_not_predictions'})
    frozen = dict(schema='wang_d1_training_parameters_v1', training_temperatures=[40,60], holdout_temperature=50,
                  binding=binding(csv,prereg), training_report_sha256=sha(parent/'training.json'),
                  training_metrics_sha256=sha(parent/'training-metrics.json'), parameters=dict(dref=1e-9,kref=1e-6,ea=40000.))
    save(parent/'parameters.json',frozen)
    out=tmp_path/'holdout'
    monkeypatch.setattr(sys,'argv',['holdout.py','--training',str(parent),'--parameters-sha256',sha(parent/'parameters.json'),'--csv',str(csv),'--output',str(out)])
    assert holdout.main() == 1
    assert (parent/'HOLDOUT_UNLOCKED.json').exists()
    report=json.loads((out/'report.json').read_text())
    assert 'INVALID_AFTER_FIRST_VALUE' in report['reason']
    assert report['holdout_access_started'] is True
    assert report['holdout_parse_complete'] is False
    assert report['holdout_values_parsed'] is None, report
