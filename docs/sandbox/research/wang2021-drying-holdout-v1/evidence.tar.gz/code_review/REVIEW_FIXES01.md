# Narrow review of tail/access fixes

Reviewed modal0263c3bc, IOc5a9d65c, holdoutf23581b6 and unchanged train035d3de1 against preserved before-tail-access-fixes. No actual dataset, real fit or holdout prediction accessed.

The original tail underflow issue is resolved: mode selection and coefficients/root/prediction arithmetic remain unchanged; positive-time zero representation becomes least positive binary64, with log_tail_bound and tail_underflow saved through metrics. This corrects false literal zero without changing the1e-9 tail target,512mode cap,1e-6 numerical allowance or model. It remains an analytically conservative omitted-tail formula evaluated in machine arithmetic, not a certified total floating error bound. For underflow cases the least positive float is conservative at the relevant tiny scale. The previously required log comparison is not essential to fixing admission because underflow is far below the unchanged1e-9 target.

[MEDIUM] holdout.py:34 still assigns holdout_values_parsed=true before the parser is called. Source comments redefine it as possible access, but the machine-readable field still claims actual parsing. A manufactured reader which raises immediately, before any observation read, reproduces the false true flag. Explicit access_started and parse_complete fields are correct and the exclusive token is retained; no one-shot bypass exists. Minimal fix: initial false; set values_parsed=null with access_started=true before entering loader; set values_parsed=true and parse_complete=true only after successful return. Preserve null on partial/unknown failure. Alternatively remove/rename the ambiguous legacy field, adjusting consumers explicitly. No scientific threshold change is needed.

Executed: unchanged19author+2original negative controls now21passed0.92s. New independent test_access_unknown.py gives1passed/1failed0.27s, process exit1; preserved access-state-RED.log. The original negative checking 'true' after a partial read was too specific for a conservative workflow without progress callbacks; its archival RED remains valid evidence of the old false field, but revised regression should require unknown rather than forcing true. No test assertions or candidate files modified by reviewer.

## Review Summary

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL |0|pass|
| HIGH |0|pass|
| MEDIUM |1|info|
| LOW |0|pass|

Verdict: Tail fix accepted; remaining access-state semantics need the minimal correction before actual execution freeze.
