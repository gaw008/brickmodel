"""Root-run single phase with a fixed external process-group deadline."""
from pathlib import Path
import subprocess,os,signal,time,json,sys
here=Path(__file__).resolve().parent
phase=sys.argv[1]
if phase not in ('training','holdout'):raise ValueError('explicit phase required')
command=[sys.executable,*sys.argv[2:]]
start=time.monotonic()
with (here/(phase+'-started.json')).open('x') as f:
 json.dump({'command':command,'external_limit_seconds':135},f,indent=2)
env=os.environ.copy();env.pop('PYTHONPATH',None)
with (here/(phase+'.log')).open('x') as log:
 child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 killed=False
 try:code=child.wait(timeout=135.)
 except subprocess.TimeoutExpired:
  killed=True
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  code=child.wait()
result={'returncode':code,'external_timeout':killed,'elapsed_seconds':time.monotonic()-start,'external_limit_seconds':135,'child_reaped':True}
with (here/(phase+'-supervisor.json')).open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
raise SystemExit(124 if killed else code)
