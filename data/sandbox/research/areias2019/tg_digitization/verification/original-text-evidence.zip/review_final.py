from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,hashlib,csv,importlib.util
from PIL import Image
root=Path('/Users/wanggaoying/Desktop/brickmodel-github');d=root/'data/sandbox/research/areias2019/tg_digitization'
s=importlib.util.spec_from_file_location('digitize_review',d/'digitize.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
from decimal import ROUND_FLOOR,ROUND_CEILING
for sign,delta in product((-1,1),(-1,1)):
 x=F(sign)+F(delta,10**100)
 assert F(m.decimal(x,ROUND_FLOOR))<=x<=F(m.decimal(x,ROUND_CEILING))
c=json.loads(m.CALIBRATION.read_text());p=json.loads((d/'picks.json').read_text());out=json.loads((d/'points.json').read_text());csvrows=list(csv.DictReader((d/'points.csv').open()))
assert len(csvrows)==len(out['points'])==39
checks=[];unknown=[]
def exactvals(pixel,axis):
 ts=[(F(t['pixel_center']),F(t['value'])) for t in axis['ticks']];a,b=ts[0],ts[-1]
 def f(x,aa,bb):return ((bb[0]-x)*aa[1]+(x-aa[0])*bb[1])/(bb[0]-aa[0])
 residual=max(abs(f(x,a,b)-y) for x,y in ts)
 vs=[f(pixel+i,(a[0]+j,a[1]),(b[0]+k,b[1])) for i,j,k in product((-2,2),(-1,1),(-1,1))]
 return f(pixel,a,b),min(vs)-residual,max(vs)+residual
for plot,cal in zip(p['plots'],c['plots']):
 image=root/f"runs/sandbox/source-cache/areias2019-20260907/tg-native-{plot['figure']-38:03}.png"
 assert hashlib.sha256(image.read_bytes()).hexdigest()==plot['source_sha256']==cal['source_sha256']
 im=Image.open(image).convert('RGB')
 for j,point in enumerate(plot['points']):
  row=next(r for r in out['points'] if r['figure']==plot['figure'] and r['target_temperature_c']==point['target_temperature_c'])
  x=point['pixel_x'];green=[{'y':y,'rgb':list(im.getpixel((x,y)))} for y in range(int(cal['x_axis_crossing_y'])+1) if im.getpixel((x,y))[1]>max(im.getpixel((x,y))[0],im.getpixel((x,y))[2])]
  assert green==point['footprint']['green_pixels'],(plot['figure'],j,'incomplete green column')
  for prefix,axis,pixel in [('temperature_c',cal['x_axis'],F(x))]+([('plotted_weight_percent',cal['green_y_axis'],F(str(point['pixel_y'])))] if point['status']=='picked' else []):
   n,l,u=exactvals(pixel,axis)
   assert F(row[prefix])==F(round(n*100),100)
   assert F(row[prefix+'_lower'])==F((l*100).__floor__(),100)
   assert F(row[prefix+'_upper'])==F((u*100).__ceil__(),100)
  if point['status']=='unknown':
   assert point['pixel_y'] is None and all(row[k] is None for k in ('plotted_weight_percent','plotted_weight_percent_lower','plotted_weight_percent_upper'))
   unknown.append([plot['figure'],point['target_temperature_c']])
  else:
   assert all(abs(F(g['y'])-F(str(point['pixel_y'])))<=2 for g in green)
  checks.append({'figure':plot['figure'],'target':point['target_temperature_c'],'full_column_green_rows':[g['y'] for g in green],'status':point['status']})
for r,cr in zip(out['points'],csvrows):
 for k,v in r.items():assert cr[k]==('' if v is None else str(v))
for a in out['upstream']:assert hashlib.sha256((root/a['path']).read_bytes()).hexdigest()==a['sha256']
assert hashlib.sha256((root/out['source_pdf']['path']).read_bytes()).hexdigest()==out['source_pdf']['sha256']
assert len(unknown)==4
result={'status':'passed','targets':39,'picked':35,'unknown':unknown,'full_green_column_checks':checks,'extreme_rounding_cases':4,'hashes':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (d/'digitize.py',d/'picks.json',d/'points.json',d/'points.csv')}}
Path('/private/tmp/brick-areias2019-tg-picks/review-final-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='full_green_column_checks'}))
